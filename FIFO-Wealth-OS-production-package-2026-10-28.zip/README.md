# FIFO Wealth OS

A bilingual (English/Thai) Next.js wealth application, Node/Express API, and SQLite/Prisma database. The package separates `frontend/`, `backend/`, and `database/` while preserving their relative source imports.

## Requirements

- Node.js 20.x and npm
- SQLite is managed by Prisma; no separate database server is needed
- Optional: Docker Engine with Docker Compose v2

## 1. Configure local secrets

From this directory, create a private local environment file and edit the required secrets:

```sh
cp .env.example .env
# Generate two different values, then place them in .env:
openssl rand -base64 48   # JWT_SECRET
openssl rand -hex 32      # ENCRYPTION_KEY
```

Never commit or distribute `.env`. `DATABASE_URL="file:./dev.db"` is relative to `database/schema.prisma`, so the local SQLite file is `database/dev.db`. Do not use `schema.postgresql.prisma` for deployment; SQLite is the validated provider.

## 2. Install dependencies and initialize SQLite

```sh
npm --prefix backend ci
npm --prefix frontend ci
# Load the root environment before Prisma commands:
set -a && . ./.env && set +a
npm --prefix backend run prisma:generate
npm --prefix backend run prisma:migrate
```

For an existing database in production, use `npm --prefix backend run prisma:deploy` instead of the development migration command.

## 3. Run the API and frontend (two terminals)

Terminal 1 — API on port 3000:

```sh
set -a && . ./.env && set +a
npm --prefix backend run dev
```

Terminal 2 — Next.js on port 3001; requests to `/api` are proxied to the API:

```sh
cd frontend
set -a && . ../.env && set +a
npm run dev
```

Open <http://127.0.0.1:3001>. API health is at <http://127.0.0.1:3000/api/health>; interactive API docs are at <http://127.0.0.1:3000/api-docs>.

## Build and tests

```sh
set -a && . ./.env && set +a
npm --prefix backend run typecheck
npm --prefix backend test
npm --prefix backend run build
npm --prefix frontend run typecheck
npm --prefix frontend run lint
cd frontend && npx playwright install chromium && npm test
```

For a production frontend build, set `BACKEND_ORIGIN` to the API server before building, for example `BACKEND_ORIGIN=http://127.0.0.1:3000 npm --prefix frontend run build`.

## Docker Compose

```sh
cp .env.example .env
# Replace JWT_SECRET and ENCRYPTION_KEY with unique values.
docker compose up --build -d
./scripts/healthcheck.sh
docker compose ps
```

Compose builds both components from the package root and stores SQLite data in the persistent `fifo-wealth-os_fifo_sqlite_data` volume. Use `docker compose down` to stop services; do not add `-v` unless you intend to delete persistent data. `scripts/deploy.sh` runs dependency audits, builds, starts the stack, and checks health.

## Package contents and exclusions

- `frontend/`: Next.js application, localized catalogs, static assets, and Playwright tests.
- `backend/`: API, business services, tests, package files, and server assets.
- `database/`: SQLite Prisma schema, migrations, and a clean schema-only test fixture.
- `docs/`, `scripts/`, `.github/`: project/API documentation, deployment checks, and CI workflows.

The archive excludes installed dependencies, build caches, screenshots, `.env` secrets, the populated local `dev.db`, generated reports, and uploaded customer files.
