import fs from 'fs';
import os from 'os';
import path from 'path';
import Decimal from 'decimal.js';
import request from 'supertest';
import {
  BitkubReadOnlyAdapter,
  DimeOpenApiAdapter,
  STREAMING_SET_OPEN_API_ROADMAP_TEXT,
  StreamingPartnerModule,
} from './thaiBrokerAdapters';
import { createApp } from '../api/app';
import { getPrismaClient, setPrismaClient } from '../db/prisma';
import { calculateFIFO } from '../fifoEngine';
import { decryptData, encryptData } from '../services/encryptionService';

const ProofDec = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

describe('Thai Local Broker Integration Hub — Bitkub, Dime!, Streaming & Thai SEC / PDPA Compliance', () => {
  test('1. BitkubReadOnlyAdapter follows API v3 BUY/SELL amount semantics, applies fee credits, and feeds exact CDM values into Core FIFO', async () => {
    const adapter = new BitkubReadOnlyAdapter();

    // Reject non-Read-Only scopes immediately
    expect(() =>
      adapter.validateCredentials({
        broker: 'BITKUB',
        apiKey: 'btk_live_key_12345',
        apiSecret: 'btk_live_secret_67890',
        permissionsScope: 'WITHDRAW',
      })
    ).toThrow(/SECURITY_SCOPE_REJECTED/);

    // Verify deterministic HMAC-SHA256 signing for Bitkub API v3
    const sig1 = adapter.signReadOnlyRequest(
      1761500000000,
      'GET',
      '/api/v3/market/my-order-history?sym=BTC_THB&p=1&lmt=100',
      '',
      'btk_secret_readonly_key'
    );
    expect(sig1).toMatch(/^[a-f0-9]{64}$/);

    const parsed = await adapter.syncReadOnly({
      broker: 'BITKUB',
      apiKey: 'btk_readonly_key_8899',
      apiSecret: 'btk_readonly_secret_key_998877',
      permissionsScope: 'READ_ONLY',
    });

    expect(parsed.broker).toBe('BITKUB');
    expect(parsed.transactions).toHaveLength(3);

    // Inspect Trade 1: BUY 0.05 BTC @ 2,250,000 THB = 112,500 THB + 281.25 fee = 112,781.25 THB
    const btcBuy = parsed.transactions[0]!;
    expect(btcBuy.symbol).toBe('BTC');
    expect(btcBuy.type).toBe('BUY');
    expect(btcBuy.exchange).toBe('BITKUB');
    expect(btcBuy.qty).toBe(0.05);
    expect(btcBuy.price).toBe(2250000);
    expect(btcBuy.gross).toBe(112500);
    expect(btcBuy.originalNet).toBe('112781.25');
    expect(btcBuy.netTHB).toBe('112781.25');

    // API supplies the observed THB fee, but not a trade-level VAT split: preserve it as fee and do not infer VAT.
    const feeCheck1 = new ProofDec(btcBuy.comm).plus(new ProofDec(btcBuy.vat));
    expect(feeCheck1.toFixed(2)).toBe('281.25');
    expect(btcBuy.vat).toBe(0);

    // Inspect Trade 2: BUY 1.50 ETH @ 88,000 THB = 132,000 THB + (330 - 30 KUB credit = 300) = 132,300.00 THB
    const ethBuy = parsed.transactions[1]!;
    expect(ethBuy.symbol).toBe('ETH');
    expect(ethBuy.originalNet).toBe('132300.00');

    // Inspect Trade 3: SELL 0.02 BTC @ 2,410,000 THB = 48,200 THB - 120.50 fee = 48,079.50 THB
    const btcSell = parsed.transactions[2]!;
    expect(btcSell.symbol).toBe('BTC');
    expect(btcSell.type).toBe('SELL');
    expect(btcSell.originalNet).toBe('48079.50');

    // Feed into untouched Core `calculateFIFO`
    const buys = parsed.transactions.filter((t) => t.type === 'BUY');
    const sells = parsed.transactions.filter((t) => t.type === 'SELL');
    const fifo = calculateFIFO(buys, sells, {
      BTC: 2450000,
      ETH: 91000,
    });

    // Cost of 0.02 BTC sold = (0.02 / 0.05) * 112,781.25 = 45,112.50 THB
    // Proceeds = 48,079.50 THB -> Realized G/L = +2,967.00 THB exact!
    expect(fifo.totalRealizedGL).toBe(2967);

    // UTC timestamps crossing midnight are assigned to the correct Thai tax date (Asia/Bangkok).
    const taxYearBoundary = adapter.parseApiResponseToCDM({
      error: 0,
      result: [
        {
          txn_id: 'BTK-THAI-DATE-01',
          sym: 'BTC_THB',
          side: 'buy',
          rate: '100.00',
          amount: '100.00',
          fee: '0',
          ts: Date.parse('2026-12-31T18:00:00.000Z'),
        },
      ],
    });
    expect(taxYearBoundary.transactions[0]?.date).toBe('2027-01-01');
  });

  test('2. DimeOpenApiAdapter (Fractional US/TH) & StreamingPartnerModule (SET Secure Statement Automation + Open API Roadmap)', async () => {
    const dime = new DimeOpenApiAdapter();
    const dimeParsed = await dime.syncReadOnly({
      broker: 'DIME',
      dimeAccountRef: 'DIME-99881122',
    });
    expect(dimeParsed.transactions).toHaveLength(3);
    expect(dimeParsed.dividends).toHaveLength(1);
    expect(dimeParsed.transactions[0]?.symbol).toBe('NVDA');
    expect(dimeParsed.transactions[0]?.qty).toBe(0.5);
    expect(dimeParsed.transactions[0]?.exchange).toBe('DIME');

    const streaming = new StreamingPartnerModule();
    expect(streaming.futureOpenApiNotice).toBe(
      STREAMING_SET_OPEN_API_ROADMAP_TEXT
    );
    const strmParsed = await streaming.syncReadOnly({
      broker: 'STREAMING',
      memberBrokerCode: 'INVX',
      accountRef: '023-456789-0',
      statementSyncToken: 'SET-AUTO-STMT-2026',
    });
    expect(strmParsed.transactions).toHaveLength(3);
    expect(strmParsed.dividends).toHaveLength(1);
    expect(strmParsed.transactions[0]?.exchange).toBe('STREAMING');
    expect(strmParsed.dividends[0]?.symbol).toBe('ADVANC');
    // 500 * 4.87 = 2,435.00 gross, 10% WHT = 243.50, net = 2,191.50 THB
    expect(strmParsed.dividends[0]?.grossTHB).toBe('2435.00');
    expect(strmParsed.dividends[0]?.whtTHB).toBe('243.50');
    expect(strmParsed.dividends[0]?.netTHB).toBe('2191.50');
  });

  test('3. AES-256-GCM Credential Encryption / Decryption & Tamper Detection', () => {
    const rawCredentialPayload = JSON.stringify({
      broker: 'BITKUB',
      apiKey: 'BITKUB_SECRET_API_KEY_DO_NOT_LEAK',
      apiSecret: 'BITKUB_SUPER_SECRET_HMAC_KEY_999',
    });

    const ciphertext = encryptData(
      rawCredentialPayload,
      'thai-sec-compliance-test-secret-key-2026'
    );
    expect(ciphertext.startsWith('v1:')).toBe(true);
    expect(ciphertext).not.toContain('BITKUB_SECRET_API_KEY');
    expect(ciphertext).not.toContain('BITKUB_SUPER_SECRET_HMAC_KEY');

    const decrypted = decryptData(
      ciphertext,
      'thai-sec-compliance-test-secret-key-2026'
    );
    expect(decrypted).toBe(rawCredentialPayload);

    // Tampered GCM Auth Tag or Ciphertext must fail authentication immediately
    const tampered = `${ciphertext.slice(0, -4)}ffff`;
    expect(() =>
      decryptData(tampered, 'thai-sec-compliance-test-secret-key-2026')
    ).toThrow();
  });

  test('4. Full REST API Compliance Flow: PDPA Consent Enforcement ->Encrypted Connect -> Idempotent Sync -> Immediate "Disconnect & Purge Data" (Right to be Forgotten)', async () => {
    const tmpDir = fs.mkdtempSync(
      path.join(os.tmpdir(), 'fifo-thai-brokers-')
    );
    const tmpDbPath = path.join(tmpDir, 'thai-brokers.db');
    fs.copyFileSync(path.resolve(__dirname, '../../../database/test-template.db'), tmpDbPath);

    const prevDbUrl = process.env['DATABASE_URL'];
    process.env['DATABASE_URL'] = `file:${tmpDbPath}`;
    process.env['JWT_SECRET'] = 'thai-broker-hub-jwt-secret';
    process.env['ENCRYPTION_KEY'] =
      'thai-sec-pdpa-aes-256-gcm-encryption-key-2026';
    setPrismaClient(null);

    const RAW_API_KEY = 'BTK_LIVE_READONLY_KEY_778899';
    const RAW_API_SECRET = 'BTK_LIVE_READONLY_SECRET_1122334455';

    try {
      const app = createApp();
      const regRes = await request(app).post('/api/auth/register').send({
        email: 'pdpa-auditor@wealthos.th',
        password: 'Password123!',
        name: 'SEC Thailand Compliance Auditor',
      });
      const token = regRes.body.token as string;

      const portRes = await request(app)
        .post('/api/portfolios')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'Thai Multi-Broker Wealth Hub', baseCurrency: 'THB' });
      const portfolioId = portRes.body.id as string;

      // Preserve pre-existing/manual Bitkub CSV data: purge must remove only records tagged by this connector.
      await getPrismaClient().transaction.create({
        data: {
          portfolioId,
          date: '2026-01-15',
          symbol: 'BTC',
          type: 'BUY',
          exchange: 'BITKUB',
          qty: 0.001,
          price: 1000000,
          gross: '1000.00',
          comm: '0',
          vat: '0',
          net: '1000.00',
          originalCurrency: 'THB',
        },
      });

      // 4A. Attempting to connect WITHOUT PDPA Consent (`accepted: false`) MUST fail with 400 PDPA_CONSENT_REQUIRED
      const noConsentRes = await request(app)
        .post('/api/thai-brokers/BITKUB/connect')
        .set('Authorization', `Bearer ${token}`)
        .send({
          portfolioId,
          apiKey: RAW_API_KEY,
          apiSecret: RAW_API_SECRET,
          pdpaConsent: { accepted: false },
        });
      expect(noConsentRes.status).toBe(400);
      expect(noConsentRes.body.error.code).toBe('PDPA_CONSENT_REQUIRED');

      // 4B. Connect WITH explicit PDPA Consent -> 201 Created, encrypted in DB, zero credential leak
      const connectRes = await request(app)
        .post('/api/thai-brokers/BITKUB/connect')
        .set('Authorization', `Bearer ${token}`)
        .send({
          portfolioId,
          apiKey: RAW_API_KEY,
          apiSecret: RAW_API_SECRET,
          permissionsScope: 'READ_ONLY',
          pdpaConsent: {
            accepted: true,
            consentVersion: 'PDPA-SEC-TH-2026.1',
            purposes: ['READ_ONLY_PORTFOLIO_SYNC', 'THAI_TAX_FIFO_CALCULATION'],
          },
        })
        .expect(201);

      expect(connectRes.body.connection.connected).toBe(true);
      expect(connectRes.body.connection.pdpaConsented).toBe(true);
      expect(connectRes.body.connection.partnerBadge).toBe(
        'Official Partner Integration Ready'
      );
      expect(JSON.stringify(connectRes.body)).not.toContain(RAW_API_KEY);
      expect(JSON.stringify(connectRes.body)).not.toContain(RAW_API_SECRET);

      // Verify encrypted storage in SQLite DB
      const prisma = getPrismaClient();
      const dbConn = await prisma.brokerConnection.findFirst({
        where: { brokerName: 'BITKUB' },
      });
      expect(dbConn?.flexQueryTokenEncrypted.startsWith('v1:')).toBe(true);
      expect(dbConn?.flexQueryTokenEncrypted).not.toContain(RAW_API_SECRET);

      // 4C. Sync Now -> imports 3 Bitkub trades; 2nd Sync Now -> 0 duplicates
      const sync1 = await request(app)
        .post('/api/thai-brokers/BITKUB/sync')
        .set('Authorization', `Bearer ${token}`)
        .send({ portfolioId })
        .expect(200);
      expect(sync1.body.addedTransactions).toBe(3);
      expect(sync1.body.dataSource).toBe('SANDBOX_MOCK');

      const sync2 = await request(app)
        .post('/api/thai-brokers/BITKUB/sync')
        .set('Authorization', `Bearer ${token}`)
        .send({ portfolioId })
        .expect(200);
      expect(sync2.body.addedTransactions).toBe(0);
      expect(sync2.body.skippedTransactions).toBe(3);

      // 4D. Execute "Disconnect & Purge Data" (Right to be Forgotten) -> Purges both credentials & all 3 synced Bitkub trades immediately!
      const purgeRes = await request(app)
        .delete('/api/thai-brokers/BITKUB/disconnect?purgeData=true')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(purgeRes.body.disconnected).toBe(true);
      expect(purgeRes.body.credentialsPurged).toBe(true);
      expect(purgeRes.body.pdpaConsentRevoked).toBe(true);
      expect(purgeRes.body.purgedTransactionsCount).toBe(3);
      expect(purgeRes.body.purgedDividendsCount).toBe(0);

      const remainingConn = await prisma.brokerConnection.findFirst({
        where: { brokerName: 'BITKUB', userId: regRes.body.user.id },
      });
      expect(remainingConn).toBeNull();

      const remainingSyncedTxs = await prisma.transaction.count({
        where: { portfolioId, sourceConnector: 'BITKUB' },
      });
      expect(remainingSyncedTxs).toBe(0);

      // Explicit purge never deletes unrelated/manual CSV records from the same broker.
      const retainedManualTx = await prisma.transaction.findFirst({
        where: { portfolioId, exchange: 'BITKUB', sourceConnector: null },
      });
      expect(retainedManualTx).not.toBeNull();

      // 4E. Dime! consent/sync/purge also removes linked dividends, while preserving the append-only audit trail.
      await request(app)
        .post('/api/thai-brokers/DIME/connect')
        .set('Authorization', `Bearer ${token}`)
        .send({
          portfolioId,
          dimeAccountRef: 'DIME-PDPA-884420',
          pdpaConsent: {
            accepted: true,
            consentVersion: 'PDPA-SEC-TH-2026.1',
            purposes: ['READ_ONLY_PORTFOLIO_SYNC'],
          },
        })
        .expect(201);

      const dimeSync = await request(app)
        .post('/api/thai-brokers/DIME/sync')
        .set('Authorization', `Bearer ${token}`)
        .send({ portfolioId })
        .expect(200);
      expect(dimeSync.body.addedTransactions).toBe(3);
      expect(dimeSync.body.addedDividends).toBe(1);

      const dimePurge = await request(app)
        .delete('/api/thai-brokers/DIME/disconnect?purgeData=true')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(dimePurge.body.purgedTransactionsCount).toBe(3);
      expect(dimePurge.body.purgedDividendsCount).toBe(1);

      expect(
        await prisma.dividend.count({
          where: { portfolioId, sourceConnector: 'DIME' },
        })
      ).toBe(0);
      expect(
        await prisma.transaction.count({
          where: { portfolioId, sourceConnector: 'DIME' },
        })
      ).toBe(0);

      // Verify PDPA Purge AuditLog entry was recorded
      const purgeAudit = await prisma.auditLog.findFirst({
        where: {
          userId: regRes.body.user.id,
          action: 'PURGE_RIGHT_TO_BE_FORGOTTEN',
        },
      });
      expect(purgeAudit).not.toBeNull();
    } finally {
      await getPrismaClient().$disconnect();
      setPrismaClient(null);
      if (prevDbUrl) {
        process.env['DATABASE_URL'] = prevDbUrl;
      } else {
        delete process.env['DATABASE_URL'];
      }
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });
});
