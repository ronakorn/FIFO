import fs from 'fs';
import os from 'os';
import path from 'path';
import Decimal from 'decimal.js';
import request from 'supertest';
import {
  fetchAndParseIBKRFlexData,
  parseIBKRCorporateActions,
  parseIBKRDividends,
  parseIBKRFlexXml,
} from './ibkrFlexAdapter';
import { createApp } from '../api/app';
import { defaultApiFXProvider } from '../api/fxProvider';
import { getPrismaClient, setPrismaClient } from '../db/prisma';
import { calculateFIFO } from '../fifoEngine';
import { defaultBotFxProvider } from '../services/botFxProvider';
import {
  applySplitToLots,
  calculateLotDaysHeld,
  previewSplitOnLots,
} from '../services/corporateActionProcessor';
import { enrichTransactionsWithFX } from '../services/transactionEnricher';

const TestDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

const SAMPLE_IBKR_FULL_LIFECYCLE_XML = `<?xml version="1.0" encoding="UTF-8"?>
<FlexQueryResponse queryName="Institutional_IBKR_Flex_Test" type="AF">
  <FlexStatements count="1">
    <FlexStatement accountId="U1234567" fromDate="20240501" toDate="20241031" period="Custom" whenGenerated="20261026;100000">
      <Trades>
        <!-- Pre-split NVDA BUY lot on 2024-05-15: 10 shares @ $900.00 + $2.00 comm = $9,002.00 -->
        <Trade tradeID="T-NVDA-01" symbol="NVDA" currency="USD" tradeDate="20240515" buySell="BUY" quantity="10.0000" tradePrice="900.00" ibCommission="-2.00" netCash="-9002.00" />
        <!-- Post-split NVDA BUY lot on 2024-07-01 (after 2024-06-10 effectiveDate): 5 shares @ $124.00 -->
        <Trade tradeID="T-NVDA-02" symbol="NVDA" currency="USD" tradeDate="20240701" buySell="BUY" quantity="5.0000" tradePrice="124.00" ibCommission="-1.00" netCash="-621.00" />
        <!-- Pre-reverse-split LCID BUY lot on 2024-08-01: 250 shares @ $3.20 + $1.00 comm = $801.00 -->
        <Trade tradeID="T-LCID-01" symbol="LCID" currency="USD" tradeDate="20240801" buySell="BUY" quantity="250.0000" tradePrice="3.20" ibCommission="-1.00" netCash="-801.00" />
      </Trades>
      <Dividends>
        <!-- Explicit <Dividends> tag: exDate 2024-09-12 (BOT USD=33.75) vs payDate 2024-10-01 (BOT USD=36.75) -->
        <Dividend actionID="D-AAPL-01" symbol="AAPL" currency="USD" exDate="20240912" payDate="20241001" quantity="100" grossRate="0.25" grossAmount="25.00" withholdingTax="-3.75" netAmount="21.25" />
      </Dividends>
      <CashTransactions>
        <!-- Duplicate of AAPL dividend in <CashTransactions> to verify cross-section SHA-256 idempotency -->
        <CashTransaction transactionID="CT-AAPL-DUP" type="Dividends" symbol="AAPL" currency="USD" exDate="20240912" payDate="20241001" quantity="100" amount="25.00" withholdingTax="-3.75" />
        <!-- Separate NVDA Cash Dividend with sibling Withholding Tax row -->
        <CashTransaction transactionID="CT-NVDA-DIV" type="Dividends" symbol="NVDA" currency="USD" exDate="20240905" dateTime="20241001;093000" quantity="105" divPerShare="0.10" amount="10.50" />
        <CashTransaction transactionID="CT-NVDA-WHT" type="Withholding Tax" symbol="NVDA" currency="USD" dateTime="20241001;093000" amount="-1.58" />
      </CashTransactions>
      <CorporateActions>
        <!-- Forward Stock Split 10:1 on NVDA effective 2024-06-10 -->
        <CorporateAction actionID="CA-NVDA-10X" symbol="NVDA" type="Stock Split" ratio="10" effectiveDate="20240610" description="NVDA(US67066G1040) SPLIT 10 FOR 1 (NVIDIA CORP)" />
        <!-- Duplicate CorporateAction entry to verify idempotency -->
        <CorporateAction actionID="CA-NVDA-10X-DUP" symbol="NVDA" type="FS" ratio="10:1" effectiveDate="2024-06-10" description="NVDA SPLIT 10 FOR 1" />
        <!-- Reverse Stock Split 1:10 on LCID effective 2024-09-10 -->
        <CorporateAction actionID="CA-LCID-REV" symbol="LCID" type="Reverse Split" ratio="1:10" effectiveDate="20240910" description="LCID SPLIT 1 FOR 10 REVERSE SPLIT" />
        <!-- Non-split corporate action (should be ignored cleanly) -->
        <CorporateAction actionID="CA-NAME-CHG" symbol="META" type="IC" effectiveDate="20240601" description="CUSIP / NAME CHANGE" />
      </CorporateActions>
    </FlexStatement>
  </FlexStatements>
</FlexQueryResponse>`;

describe('IBKR Flex XML Adapter (Trades + Dividends + Corporate Actions) & corporateActionProcessor', () => {
  test('1. parseIBKRDividends extracts <Dividends> & <CashTransactions type="Dividends">, deduplicates, and converts THB via botFxProvider on Pay Date', async () => {
    const dividends = await parseIBKRDividends(
      SAMPLE_IBKR_FULL_LIFECYCLE_XML,
      defaultBotFxProvider
    );

    // Duplicate AAPL dividend across <Dividends> and <CashTransactions> must be deduplicated -> 2 unique dividends
    expect(dividends).toHaveLength(2);

    const aaplDiv = dividends.find((d) => d.symbol === 'AAPL');
    expect(aaplDiv).toBeDefined();
    expect(aaplDiv?.exDate).toBe('2024-09-12');
    expect(aaplDiv?.payDate).toBe('2024-10-01');
    expect(aaplDiv?.date).toBe('2024-10-01');
    expect(aaplDiv?.grossAmount).toBe('25.00');
    expect(aaplDiv?.withholdingTax).toBe('3.75');
    expect(aaplDiv?.net).toBe('21.25');
    expect(aaplDiv?.currency).toBe('USD');

    // Pay Date 2024-10-01 has BOT USD/THB = 36.75 (NOT exDate 2024-09-12 = 33.75!)
    expect(aaplDiv?.fxRate).toBe('36.75');
    expect(aaplDiv?.grossTHB).toBe('918.75'); // 25.00 * 36.75 = 918.75
    expect(aaplDiv?.whtTHB).toBe('137.81');   // 3.75 * 36.75 = 137.8125 -> 137.81
    expect(aaplDiv?.netTHB).toBe('780.94');   // 21.25 * 36.75 = 780.9375 -> 780.94

    // Sibling Withholding Tax pairing on NVDA CashTransaction
    const nvdaDiv = dividends.find((d) => d.symbol === 'NVDA');
    expect(nvdaDiv).toBeDefined();
    expect(nvdaDiv?.exDate).toBe('2024-09-05');
    expect(nvdaDiv?.payDate).toBe('2024-10-01');
    expect(nvdaDiv?.grossAmount).toBe('10.50');
    expect(nvdaDiv?.withholdingTax).toBe('1.58');
    expect(nvdaDiv?.net).toBe('8.92');
    expect(nvdaDiv?.fxRate).toBe('36.75');
    expect(nvdaDiv?.grossTHB).toBe('385.88'); // 10.50 * 36.75 = 385.875 -> 385.88
    expect(nvdaDiv?.whtTHB).toBe('58.07');    // 1.58 * 36.75 = 58.065 -> 58.07
    expect(nvdaDiv?.netTHB).toBe('327.81');   // 8.92 * 36.75 = 327.81
  });

  test('2. parseIBKRCorporateActions detects Stock Split & Reverse Split with SHA-256 idempotency and ignores non-split events', () => {
    const actions = parseIBKRCorporateActions(SAMPLE_IBKR_FULL_LIFECYCLE_XML);

    expect(actions).toHaveLength(2);

    const nvdaSplit = actions.find((a) => a.symbol === 'NVDA');
    expect(nvdaSplit).toBeDefined();
    expect(nvdaSplit?.type).toBe('STOCK_SPLIT');
    expect(nvdaSplit?.ratio).toBe(10);
    expect(nvdaSplit?.effectiveDate).toBe('2024-06-10');
    expect(nvdaSplit?.source).toBe('IBKR_FLEX');

    const lcidRevSplit = actions.find((a) => a.symbol === 'LCID');
    expect(lcidRevSplit).toBeDefined();
    expect(lcidRevSplit?.type).toBe('REVERSE_SPLIT');
    expect(lcidRevSplit?.ratio).toBe(10);
    expect(lcidRevSplit?.effectiveDate).toBe('2024-09-10');
  });

  test('3. End-to-End XML -> CDM -> FIFO Lots -> applySplitToLots preserves 100% Total Cost Basis and NEVER resets Days Held', async () => {
    const parsed = await fetchAndParseIBKRFlexData(
      'MOCK-READONLY-TOKEN',
      '998877',
      '2024-05-01',
      '2024-10-31',
      {
        xmlOverride: SAMPLE_IBKR_FULL_LIFECYCLE_XML,
        botFxProvider: defaultBotFxProvider,
      }
    );

    expect(parsed.transactions).toHaveLength(3);
    expect(parsed.dividends).toHaveLength(2);
    expect(parsed.corporateActions).toHaveLength(2);

    // Enrich Trades into THB via FX provider and run untouched Core `calculateFIFO`
    const enrichedTxs = await enrichTransactionsWithFX(
      parsed.transactions,
      defaultApiFXProvider,
      'THB'
    );
    const buys = enrichedTxs.filter((t) => t.type === 'BUY');
    const sells = enrichedTxs.filter((t) => t.type === 'SELL');
    const fifoBefore = calculateFIFO(buys, sells, {
      NVDA: 4500,
      LCID: 1050,
    });

    expect(fifoBefore.lots).toHaveLength(3);

    // Apply NVDA 10:1 Stock Split (effective 2024-06-10)
    const nvdaSplit = parsed.corporateActions.find((c) => c.symbol === 'NVDA')!;
    const nvdaPreview = previewSplitOnLots(
      fifoBefore.lots,
      nvdaSplit,
      '2026-10-26'
    );

    expect(nvdaPreview.affectedLotCount).toBe(1); // Only 2024-05-15 lot is <= 2024-06-10; 2024-07-01 lot is untouched
    expect(nvdaPreview.isCostBasisPreserved).toBe(true);
    expect(nvdaPreview.isDaysHeldPreserved).toBe(true);
    expect(nvdaPreview.totalCostBeforeTHB).toBe(nvdaPreview.totalCostAfterTHB);

    const afterNvdaLots = applySplitToLots(fifoBefore.lots, nvdaSplit);

    const preSplitLotBefore = fifoBefore.lots.find(
      (l) => l.symbol === 'NVDA' && l.date === '2024-05-15'
    )!;
    const preSplitLotAfter = afterNvdaLots.find(
      (l) => l.symbol === 'NVDA' && l.date === '2024-05-15'
    )!;

    // Qty scaled 10x (10 -> 100), Cost/Unit divided by 10, Date & Days Held 100% preserved!
    expect(preSplitLotBefore.buyQty).toBe(10);
    expect(preSplitLotAfter.buyQty).toBe(100);
    expect(preSplitLotAfter.qtyRemain).toBe(100);
    expect(preSplitLotAfter.date).toBe('2024-05-15');
    expect(calculateLotDaysHeld(preSplitLotAfter.date, '2026-10-26')).toBe(
      calculateLotDaysHeld(preSplitLotBefore.date, '2026-10-26')
    );

    const costBefore = new TestDecimal(preSplitLotBefore.buyQty).times(
      new TestDecimal(preSplitLotBefore.costPerUnit)
    );
    const costAfter = new TestDecimal(preSplitLotAfter.buyQty).times(
      new TestDecimal(preSplitLotAfter.costPerUnit)
    );
    expect(costAfter.toFixed(2)).toBe(costBefore.toFixed(2));

    // Post-split lot (2024-07-01) must remain completely untouched
    const postSplitLotAfter = afterNvdaLots.find(
      (l) => l.symbol === 'NVDA' && l.date === '2024-07-01'
    )!;
    expect(postSplitLotAfter.buyQty).toBe(5);

    // Apply LCID 1:10 Reverse Split (effective 2024-09-10)
    const lcidSplit = parsed.corporateActions.find((c) => c.symbol === 'LCID')!;
    const afterBothSplits = applySplitToLots(afterNvdaLots, lcidSplit);

    const lcidBefore = fifoBefore.lots.find((l) => l.symbol === 'LCID')!;
    const lcidAfter = afterBothSplits.find((l) => l.symbol === 'LCID')!;

    expect(lcidBefore.buyQty).toBe(250);
    expect(lcidAfter.buyQty).toBe(25);
    expect(lcidAfter.date).toBe('2024-08-01');
    expect(calculateLotDaysHeld(lcidAfter.date, '2026-10-26')).toBe(
      calculateLotDaysHeld(lcidBefore.date, '2026-10-26')
    );

    const lcidCostBefore = new TestDecimal(lcidBefore.buyQty).times(
      new TestDecimal(lcidBefore.costPerUnit)
    );
    const lcidCostAfter = new TestDecimal(lcidAfter.buyQty).times(
      new TestDecimal(lcidAfter.costPerUnit)
    );
    expect(lcidCostAfter.toFixed(2)).toBe(lcidCostBefore.toFixed(2));

    // Verify synchronous parseIBKRFlexXml also exposes all 3 hash maps cleanly
    const syncParsed = parseIBKRFlexXml(SAMPLE_IBKR_FULL_LIFECYCLE_XML);
    expect(Object.keys(syncParsed.transactionHashes)).toHaveLength(3);
    expect(Object.keys(syncParsed.dividendHashes)).toHaveLength(2);
    expect(Object.keys(syncParsed.corporateActionHashes)).toHaveLength(2);
  });

  test('4. Full REST API Lifecycle: IBKR Sync -> Detect Unapplied Corporate Action -> Before/After Preview -> Apply Split -> Post-Split Re-Sync Idempotency', async () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fifo-ca-sync-'));
    const tmpDbPath = path.join(tmpDir, 'ca-sync.db');
    fs.copyFileSync(path.resolve(__dirname, '../../../database/test-template.db'), tmpDbPath);

    const prevDbUrl = process.env['DATABASE_URL'];
    process.env['DATABASE_URL'] = `file:${tmpDbPath}`;
    process.env['JWT_SECRET'] = 'ca-sync-test-jwt-secret';
    process.env['ENCRYPTION_KEY'] =
      'ca-sync-aes-256-gcm-secret-key-2026-secure';
    delete process.env['IBKR_FLEX_BASE_URL'];
    setPrismaClient(null);

    try {
      const app = createApp();
      const regRes = await request(app).post('/api/auth/register').send({
        email: 'ca-sync-auditor@wealthos.th',
        password: 'Password123!',
        name: 'Corporate Action Auditor',
      });
      expect(regRes.status).toBe(201);
      const token = regRes.body.token as string;

      const portRes = await request(app)
        .post('/api/portfolios')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'IBKR Split Audit Portfolio', baseCurrency: 'THB' });
      expect(portRes.status).toBe(201);
      const portfolioId = portRes.body.id as string;

      // Connect IBKR Read-Only & trigger initial sync (imports MSFT + GOOGL 20 shares + MSFT Dividend + GOOGL 2:1 Split)
      await request(app)
        .post('/api/sync/ibkr/connect')
        .set('Authorization', `Bearer ${token}`)
        .send({
          flexQueryId: '887766',
          flexQueryToken: 'SECRET_IBKR_READONLY_TOKEN_CA_TEST',
          portfolioId,
        })
        .expect(201);

      const sync1 = await request(app)
        .post('/api/sync/ibkr/trigger')
        .set('Authorization', `Bearer ${token}`)
        .send({ portfolioId })
        .expect(200);

      expect(sync1.body.addedTransactions).toBe(3);
      expect(sync1.body.addedDividends).toBe(1);
      expect(sync1.body.detectedCorporateActions).toBe(1);

      // Query Portfolio Corporate Actions -> GOOGL 2:1 Stock Split must appear unapplied with Before/After preview
      const caListRes = await request(app)
        .get(`/api/corporate-actions?portfolioId=${portfolioId}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      const googlSplit = (
        caListRes.body.actions as Array<{
          id: string;
          symbol: string;
          applied: boolean;
          preview: {
            affectedLotCount: number;
            totalCostBeforeTHB: string;
            totalCostAfterTHB: string;
            isCostBasisPreserved: boolean;
            isDaysHeldPreserved: boolean;
            lotPreviews: Array<{
              qtyBefore: string;
              qtyAfter: string;
              daysHeldBefore: number;
              daysHeldAfter: number;
            }>;
          };
        }>
      ).find((a) => a.symbol === 'GOOGL');

      expect(googlSplit).toBeDefined();
      expect(googlSplit?.applied).toBe(false);
      expect(googlSplit?.preview.affectedLotCount).toBe(1);
      expect(googlSplit?.preview.isCostBasisPreserved).toBe(true);
      expect(googlSplit?.preview.isDaysHeldPreserved).toBe(true);
      expect(googlSplit?.preview.totalCostBeforeTHB).toBe(
        googlSplit?.preview.totalCostAfterTHB
      );
      expect(googlSplit?.preview.lotPreviews[0]?.qtyBefore).toBe('20');
      expect(googlSplit?.preview.lotPreviews[0]?.qtyAfter).toBe('40');
      expect(googlSplit?.preview.lotPreviews[0]?.daysHeldBefore).toBe(
        googlSplit?.preview.lotPreviews[0]?.daysHeldAfter
      );

      // Apply Adjustment -> GOOGL 20 -> 40 shares, Total Cost Basis 100% preserved, AuditLog written
      const applyRes = await request(app)
        .post('/api/corporate-actions/apply')
        .set('Authorization', `Bearer ${token}`)
        .send({ actionId: googlSplit!.id, portfolioId })
        .expect(200);

      expect(applyRes.body.action.applied).toBe(true);
      expect(applyRes.body.totalCostBeforeTHB).toBe(
        applyRes.body.totalCostAfterTHB
      );
      expect(applyRes.body.adjustedLots[0].buyQty).toBe(40);
      expect(applyRes.body.adjustedLots[0].date).toBe('2026-10-21');

      // Calling Apply Adjustment a second time is idempotent (does NOT double-split to 80 shares!)
      const applyAgainRes = await request(app)
        .post('/api/corporate-actions/apply')
        .set('Authorization', `Bearer ${token}`)
        .send({ actionId: googlSplit!.id, portfolioId })
        .expect(200);
      expect(applyAgainRes.body.alreadyApplied).toBe(true);
      expect(applyAgainRes.body.adjustedLots[0].buyQty).toBe(40);

      // Triggering IBKR Sync AFTER split remembers pre-split SHA-256 trade hashes -> 0 duplicates!
      const sync2 = await request(app)
        .post('/api/sync/ibkr/trigger')
        .set('Authorization', `Bearer ${token}`)
        .send({ portfolioId })
        .expect(200);
      expect(sync2.body.addedTransactions).toBe(0);
      expect(sync2.body.addedDividends).toBe(0);
      expect(sync2.body.skippedTransactions).toBe(3);
      expect(sync2.body.skippedDividends).toBe(1);

      // Verify append-only AuditLog recorded APPLY_SPLIT
      const prisma = getPrismaClient();
      const auditRow = await prisma.auditLog.findFirst({
        where: {
          entityType: 'CORPORATE_ACTION',
          entityId: googlSplit!.id,
          action: 'APPLY_SPLIT',
        },
      });
      expect(auditRow).not.toBeNull();
    } finally {
      await getPrismaClient().$disconnect();
      setPrismaClient(null);
      if (prevDbUrl) {
        process.env['DATABASE_URL'] = prevDbUrl;
      } else {
        delete process.env['DATABASE_URL'];
      }
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });
});
