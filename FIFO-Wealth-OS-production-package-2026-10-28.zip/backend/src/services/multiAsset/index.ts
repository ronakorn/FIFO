import type { MultiAssetTransaction } from '../../types/multiAsset';
import { calculateBondPortfolio, type BondPortfolioSummary } from './bondEngine';
import { calculateCommodityPortfolio, type CommodityPortfolioSummary } from './commodityEngine';
import { calculateForexCashLedger, type ForexPortfolioSummary } from './forexEngine';
import { calculateFundPortfolio, type FundPortfolioSummary } from './fundEngine';

export interface MultiAssetPortfolioSummary {
  asOfDate: string;
  taxYear: number;
  bonds: BondPortfolioSummary;
  funds: FundPortfolioSummary;
  commodities: CommodityPortfolioSummary;
  forex: ForexPortfolioSummary;
}

export function calculateMultiAssetPortfolioSummary(
  transactions: readonly MultiAssetTransaction[],
  options: {
    asOfDate?: string;
    taxYear?: number;
    annualIncomeTHB?: string | null;
    dateOfBirth?: Date | null;
  } = {},
): MultiAssetPortfolioSummary {
  const asOfDate = options.asOfDate ?? new Date().toISOString().slice(0, 10);
  const taxYear = options.taxYear ?? Number(asOfDate.slice(0, 4));
  return {
    asOfDate,
    taxYear,
    bonds: calculateBondPortfolio(transactions, asOfDate),
    funds: calculateFundPortfolio(transactions, {
      asOfDate,
      taxYear,
      annualIncomeTHB: options.annualIncomeTHB,
      dateOfBirth: options.dateOfBirth,
    }),
    commodities: calculateCommodityPortfolio(transactions, asOfDate),
    forex: calculateForexCashLedger(transactions),
  };
}

export * from './bondEngine';
export * from './commodityEngine';
export * from './forexEngine';
export * from './fundEngine';
export * from './common';
export * from './legacyGoldAdapter';
