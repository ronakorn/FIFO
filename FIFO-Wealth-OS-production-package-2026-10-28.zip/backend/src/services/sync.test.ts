import fs from 'fs';
import os from 'os';
import path from 'path';
import { execSync } from 'child_process';
import { rest } from 'msw';
import { setupServer } from 'msw/node';
import {
  computeTransactionHash,
  fetchAndParseIBKRFlexData,
  parseIBKRFlexXml,
} from '../adapters/ibkrFlexAdapter';
import { getPrismaClient, setPrismaClient } from '../db/prisma';
import { decryptData, encryptData } from './encryptionService';
import { triggerManualSync } from './manualSyncEngine';

const MOCK_IBKR_FLEX_BASE_URL = 'https://ibkr-flex.mock.local/FlexWebService';

const mswXmlStatement = `<?xml version="1.0" encoding="UTF-8"?>
<FlexQueryResponse queryName="MSW_Test_Query" type="AF">
  <FlexStatements count="1">
    <FlexStatement accountId="U1234567" fromDate="20261001" toDate="20261026">
      <Trades>
        <Trade tradeID="T-101" symbol="MSFT" currency="USD" tradeDate="20261012" buySell="BUY" quantity="12.0000" tradePrice="415.50" ibCommission="-1.25" netCash="-4987.25" />
        <Trade tradeID="T-102" symbol="MSFT" currency="USD" tradeDate="20261019" buySell="SELL" quantity="-4.0000" tradePrice="438.00" ibCommission="-1.00" netCash="1751.00" />
        <Trade tradeID="T-103" symbol="GOOGL" currency="USD" tradeDate="20261021" buySell="BUY" quantity="20.0000" tradePrice="172.25" ibCommission="-1.50" netCash="-3446.50" />
      </Trades>
      <CashTransactions>
        <CashTransaction transactionID="D-201" type="Dividends" symbol="MSFT" currency="USD" dateTime="20261015" quantity="12.0000" divPerShare="0.75" amount="9.00" withholdingTax="-1.35" />
      </CashTransactions>
    </FlexStatement>
  </FlexStatements>
</FlexQueryResponse>`;

const mswServer = setupServer(
  rest.get(`${MOCK_IBKR_FLEX_BASE_URL}/SendRequest`, (req, res, ctx) => {
    const tokenHeader = req.headers.get('x-ibkr-flex-token');
    if (!tokenHeader) {
      return res(ctx.status(401));
    }
    return res(
      ctx.status(200),
      ctx.xml(`<?xml version="1.0" encoding="UTF-8"?>
<FlexStatementResponse timestamp="26 October, 2026 09:00 AM EDT">
  <Status>Success</Status>
  <ReferenceCode>9988776655</ReferenceCode>
</FlexStatementResponse>`)
    );
  }),
  rest.get(`${MOCK_IBKR_FLEX_BASE_URL}/GetStatement`, (_req, res, ctx) => {
    return res(ctx.status(200), ctx.xml(mswXmlStatement));
  })
);

describe('Direct Broker API Connector (IBKR Flex Web Service) — Unit & Engine Tests', () => {
  beforeAll(() => {
    mswServer.listen({ onUnhandledRequest: 'bypass' });
  });

  afterEach(() => {
    mswServer.resetHandlers();
  });

  afterAll(() => {
    mswServer.close();
  });

  describe('1. Security & Encryption Service (AES-256-GCM)', () => {
    const secretKey =
      '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';

    it('encrypts and decrypts Flex Query Token losslessly with unique random IVs', () => {
      const plainToken = 'IBKR-READONLY-FLEX-TOKEN-99441122';

      const cipherA = encryptData(plainToken, secretKey);
      const cipherB = encryptData(plainToken, secretKey);

      // Must never contain plaintext and must produce distinct ciphertexts per encryption
      expect(cipherA).not.toContain(plainToken);
      expect(cipherA).not.toBe(cipherB);

      expect(decryptData(cipherA, secretKey)).toBe(plainToken);
      expect(decryptData(cipherB, secretKey)).toBe(plainToken);
    });

    it('detects tampered ciphertext or wrong secretKey via GCM Auth Tag', () => {
      const encrypted = encryptData('SENSITIVE-IBKR-TOKEN', secretKey);
      const wrongKey =
        'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff';

      expect(() => decryptData(encrypted, wrongKey)).toThrow();

      const segments = encrypted.split(':');
      const flippedCipher = `${segments[0]}:${segments[1]}:${segments[2]}:00${segments[3]!.slice(2)}`;
      expect(() => decryptData(flippedCipher, secretKey)).toThrow();
    });
  });

  describe('2. IBKR Flex Query XML Adapter (MSW + Canonical Data Model)', () => {
    it('fetches via 2-step IBKR Flex HTTP XML (MSW) and maps to Transaction[] & Dividend[] with strictly positive qty', async () => {
      const parsed = await fetchAndParseIBKRFlexData(
        'MOCK-FLEX-TOKEN-XYZ',
        '884422',
        '2026-10-01',
        '2026-10-26',
        { baseUrl: MOCK_IBKR_FLEX_BASE_URL }
      );

      expect(parsed.transactions).toHaveLength(3);
      expect(parsed.dividends).toHaveLength(1);

      const buyMsft = parsed.transactions[0]!;
      expect(buyMsft.symbol).toBe('MSFT');
      expect(buyMsft.type).toBe('BUY');
      expect(buyMsft.qty).toBe(12);
      expect(buyMsft.price).toBe(415.5);
      expect(buyMsft.comm).toBe(1.25);
      expect(buyMsft.exchange).toBe('IBKR');
      expect(buyMsft.originalCurrency).toBe('USD');
      expect(buyMsft.originalNet).toBe('4987.25');

      const sellMsft = parsed.transactions[1]!;
      expect(sellMsft.symbol).toBe('MSFT');
      expect(sellMsft.type).toBe('SELL');
      // Even though XML had quantity="-4.0000", CDM qty MUST be strictly positive!
      expect(sellMsft.qty).toBe(4);
      expect(sellMsft.qty).toBeGreaterThan(0);
      expect(sellMsft.originalCurrency).toBe('USD');
      expect(sellMsft.originalNet).toBe('1751.00');

      const divMsft = parsed.dividends[0]!;
      expect(divMsft.symbol).toBe('MSFT');
      expect(divMsft.gross).toBe('9.00');
      expect(divMsft.wht).toBe('1.35');
      expect(divMsft.net).toBe('7.65');
      expect(divMsft.originalCurrency).toBe('USD');
    });

    it('produces identical SHA-256 hashes regardless of trailing decimal zeros', () => {
      const h1 = computeTransactionHash({
        date: '20261012',
        symbol: 'msft',
        qty: '12.0000',
        price: '415.50',
        type: 'BUY',
      });
      const h2 = computeTransactionHash({
        date: '2026-10-12',
        symbol: 'MSFT',
        qty: 12,
        price: 415.5,
        type: 'BUY',
      });
      expect(h1).toBe(h2);

      const direct = parseIBKRFlexXml(mswXmlStatement);
      expect(direct.transactions).toHaveLength(3);
    });
  });

  describe('3. Manual Sync Engine & Strict Idempotency Check', () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fifo-sync-engine-'));
    const testDbPath = path.join(tmpDir, 'sync-engine.db');
    let userId = '';
    let portfolioId = '';

    beforeAll(async () => {
      process.env['DATABASE_URL'] = `file:${testDbPath}`;
      process.env['ENCRYPTION_KEY'] =
        'fifo-wealth-os-test-encryption-key-32bytes!!';
      setPrismaClient(null);

      execSync('npx prisma db push --schema ../database/schema.prisma --skip-generate --accept-data-loss', {
        cwd: path.resolve(__dirname, '../..'),
        env: { ...process.env, DATABASE_URL: `file:${testDbPath}` },
        stdio: 'pipe',
      });

      const prisma = getPrismaClient();
      const user = await prisma.user.create({
        data: {
          email: 'ibkr-sync@wealthos.th',
          passwordHash: 'hashed',
          name: 'IBKR Sync Tester',
        },
      });
      userId = user.id;

      const portfolio = await prisma.portfolio.create({
        data: {
          userId,
          name: 'IBKR Global Equities',
          baseCurrency: 'THB',
        },
      });
      portfolioId = portfolio.id;

      await prisma.brokerConnection.create({
        data: {
          userId,
          portfolioId,
          brokerName: 'IBKR',
          flexQueryTokenEncrypted: encryptData('IBKR-SECRET-TOKEN-778899'),
          flexQueryId: '908070',
          status: 'CONNECTED',
        },
      });
    });

    afterAll(async () => {
      await getPrismaClient().$disconnect();
      setPrismaClient(null);
      fs.rmSync(tmpDir, { recursive: true, force: true });
    });

    it('enforces Idempotency: 1st triggerManualSync adds records with THB FX enrichment; 2nd consecutive call adds 0 duplicates', async () => {
      const firstRun = await triggerManualSync(userId, {
        portfolioId,
        flexBaseUrl: MOCK_IBKR_FLEX_BASE_URL,
      });

      expect(firstRun.status).toBe('CONNECTED');
      expect(firstRun.addedTransactions).toBe(3);
      expect(firstRun.addedDividends).toBe(1);
      expect(firstRun.skippedTransactions).toBe(0);

      // Verify FX enrichment into THB in SQLite DB
      const dbTxsAfterFirst = await getPrismaClient().transaction.findMany({
        where: { portfolioId },
      });
      expect(dbTxsAfterFirst).toHaveLength(3);
      expect(dbTxsAfterFirst[0]!.exchange).toBe('IBKR');
      expect(Number(dbTxsAfterFirst[0]!.fxRate)).toBeGreaterThan(30);
      expect(Number(dbTxsAfterFirst[0]!.netTHB)).toBeGreaterThan(0);

      // 2nd consecutive Sync -> MUST add 0 transactions and 0 dividends!
      const secondRun = await triggerManualSync(userId, {
        portfolioId,
        flexBaseUrl: MOCK_IBKR_FLEX_BASE_URL,
      });

      expect(secondRun.addedTransactions).toBe(0);
      expect(secondRun.addedDividends).toBe(0);
      expect(secondRun.skippedTransactions).toBe(3);
      expect(secondRun.skippedDividends).toBe(1);

      const dbTxsAfterSecond = await getPrismaClient().transaction.findMany({
        where: { portfolioId },
      });
      expect(dbTxsAfterSecond).toHaveLength(3);
    });
  });
});
