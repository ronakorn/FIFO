import fs from 'fs';
import os from 'os';
import path from 'path';
import { execSync } from 'child_process';
import request from 'supertest';
import { createApp } from './app';
import { getPrismaClient, setPrismaClient } from '../db/prisma';

describe('IBKR Direct Broker Sync REST API (/api/sync)', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fifo-sync-api-'));
  const testDbPath = path.join(tmpDir, 'sync-api.db');
  let token = '';
  let userId = '';
  let portfolioId = '';

  const SENSITIVE_FLEX_TOKEN = 'PLAIN_IBKR_FLEX_SECRET_TOKEN_DO_NOT_LEAK_9911';

  beforeAll(async () => {
    process.env['DATABASE_URL'] = `file:${testDbPath}`;
    process.env['JWT_SECRET'] = 'sync-api-jwt-secret';
    process.env['ENCRYPTION_KEY'] =
      'sync-api-aes-256-gcm-secret-key-2026-secure';
    delete process.env['IBKR_FLEX_BASE_URL'];
    setPrismaClient(null);

    execSync('npx prisma db push --schema ../database/schema.prisma --skip-generate --accept-data-loss', {
      cwd: path.resolve(__dirname, '../..'),
      env: { ...process.env, DATABASE_URL: `file:${testDbPath}` },
      stdio: 'pipe',
    });

    const app = createApp();
    const regRes = await request(app).post('/api/auth/register').send({
      email: 'sync-api@wealthos.th',
      password: 'Password123!',
      name: 'Sync Security Auditor',
    });
    expect(regRes.status).toBe(201);
    token = regRes.body.token as string;
    userId = regRes.body.user.id as string;

    const portRes = await request(app)
      .post('/api/portfolios')
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'IBKR Direct Sync Portfolio', baseCurrency: 'THB' });
    expect(portRes.status).toBe(201);
    portfolioId = portRes.body.id as string;
  });

  afterAll(async () => {
    await getPrismaClient().$disconnect();
    setPrismaClient(null);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('POST /api/sync/ibkr/connect encrypts credentials in DB and NEVER leaks plaintext or encrypted token in response', async () => {
    const app = createApp();
    const res = await request(app)
      .post('/api/sync/ibkr/connect')
      .set('Authorization', `Bearer ${token}`)
      .send({
        flexQueryToken: SENSITIVE_FLEX_TOKEN,
        flexQueryId: '775533',
        portfolioId,
      });

    expect(res.status).toBe(201);
    const serializedResponse = JSON.stringify(res.body);
    expect(serializedResponse).not.toContain(SENSITIVE_FLEX_TOKEN);
    expect(serializedResponse).not.toContain('flexQueryTokenEncrypted');

    expect(res.body.connection.status).toBe('CONNECTED');
    expect(res.body.connection.readOnly).toBe(true);
    expect(res.body.connection.encryption).toBe('AES-256-GCM');

    // Verify DB stores AES-256-GCM ciphertext, NOT plaintext
    const dbRow = await getPrismaClient().brokerConnection.findUnique({
      where: { userId_brokerName: { userId, brokerName: 'IBKR' } },
    });
    expect(dbRow).not.toBeNull();
    expect(dbRow!.flexQueryTokenEncrypted).not.toContain(SENSITIVE_FLEX_TOKEN);
    expect(dbRow!.flexQueryTokenEncrypted.startsWith('v1:')).toBe(true);
  });

  it('GET /api/sync/status & POST /api/sync/ibkr/trigger syncs idempotently into FIFO portfolio', async () => {
    const app = createApp();

    const statusBefore = await request(app)
      .get('/api/sync/status')
      .set('Authorization', `Bearer ${token}`);
    expect(statusBefore.status).toBe(200);
    expect(statusBefore.body.connected).toBe(true);
    expect(statusBefore.body.lastSyncedAt).toBeNull();

    const sync1 = await request(app)
      .post('/api/sync/ibkr/trigger')
      .set('Authorization', `Bearer ${token}`)
      .send({ portfolioId });
    expect(sync1.status).toBe(200);
    expect(sync1.body.addedTransactions).toBe(3);
    expect(sync1.body.addedDividends).toBe(1);

    // Triggering Sync a 2nd time MUST return addedTransactions: 0
    const sync2 = await request(app)
      .post('/api/sync/ibkr/trigger')
      .set('Authorization', `Bearer ${token}`)
      .send({ portfolioId });
    expect(sync2.status).toBe(200);
    expect(sync2.body.addedTransactions).toBe(0);
    expect(sync2.body.addedDividends).toBe(0);

    // Verify FIFO Portfolio endpoint automatically includes synced MSFT & GOOGL lots!
    const portDetail = await request(app)
      .get(`/api/portfolios/${portfolioId}`)
      .set('Authorization', `Bearer ${token}`);
    expect(portDetail.status).toBe(200);
    const lotSymbols = (
      portDetail.body.fifoSummary.lots as { symbol: string }[]
    ).map((l) => l.symbol);
    expect(lotSymbols).toContain('MSFT');
    expect(lotSymbols).toContain('GOOGL');
  });

  it('DELETE /api/sync/ibkr/disconnect purges encrypted credentials (Right to be Forgotten)', async () => {
    const app = createApp();

    const delRes = await request(app)
      .delete('/api/sync/ibkr/disconnect')
      .set('Authorization', `Bearer ${token}`);
    expect(delRes.status).toBe(200);
    expect(delRes.body.disconnected).toBe(true);
    expect(delRes.body.credentialsDeleted).toBe(true);

    const dbCount = await getPrismaClient().brokerConnection.count({
      where: { userId },
    });
    expect(dbCount).toBe(0);

    const statusAfter = await request(app)
      .get('/api/sync/status')
      .set('Authorization', `Bearer ${token}`);
    expect(statusAfter.body.connected).toBe(false);
    expect(statusAfter.body.status).toBe('DISCONNECTED');
  });
});
