import cors from 'cors';
import express, { Express, Request } from 'express';
import swaggerUi from 'swagger-ui-express';
import { authMiddleware } from '../middleware/authMiddleware';
import { checkFeatureEntitlement } from '../middleware/subscriptionGuard';
import { errorHandler, notFoundHandler } from '../middleware/errorHandler';
import { aiRouter } from './ai';
import { familyRouter } from './family';
import { fireRouter } from './fire';
import { journalRouter } from './journal';
import { openApiSpec, postmanCollection } from './openapi';
import { billingRouter } from './billing';
import { analyticsRouter } from './routes/analyticsRoutes';
import { authRouter } from './routes/authRoutes';
import { portfolioRouter } from './routes/portfolioRoutes';
import { taxRouter } from './routes/taxRoutes';
import { transactionRouter } from './routes/transactionRoutes';
import { uploadRouter } from './routes/uploadRoutes';
import { goldRouter } from './gold';
import { auditRouter } from './audit';
import { cryptoRouter } from './crypto';
import { rolloverRouter } from './rollover';
import { syncRouter } from './sync';
import { thaiBrokerRouter } from './thaiBrokers';
import { wave1Router } from './wave1';
import { multiAssetRouter } from './multiAssets';
import { bloombergRouter } from './bloomberg';
import { advancedAssetsRouter } from './advancedAssets';

export function createApp(): Express {
  const app = express();

  app.disable('x-powered-by');
  app.use(
    cors({
      origin: true,
      credentials: true,
    })
  );
  app.use(
    express.json({
      limit: '5mb',
      verify: (req, _res, buffer) => {
        if (req.url?.split('?')[0] === '/api/webhooks/stripe') {
          (req as Request & { rawBody?: Buffer }).rawBody = Buffer.from(buffer);
        }
      },
    })
  );
  app.use(express.urlencoded({ extended: true }));

  // Root redirects to interactive Swagger API Explorer
  app.get('/', (_req, res) => {
    res.redirect('/api-docs');
  });

  // Health & OpenAPI / Postman Contract Discovery
  app.get('/api/health', (_req, res) => {
    res.status(200).json({
      status: 'ok',
      service: 'FIFO Wealth OS - Backend API',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/openapi.json', (_req, res) => {
    res.status(200).json(openApiSpec);
  });

  app.get('/api/postman.json', (_req, res) => {
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="FIFO_Wealth_OS.postman_collection.json"'
    );
    res.status(200).json(postmanCollection);
  });

  // Interactive Swagger UI
  app.use(
    '/api-docs',
    swaggerUi.serve,
    swaggerUi.setup(openApiSpec, {
      customSiteTitle: 'FIFO Wealth OS - API Documentation',
      swaggerOptions: {
        persistAuthorization: true,
      },
    })
  );

  // Domain API Routes
  app.use('/api/auth', authRouter);
  app.use('/api', billingRouter);
  app.use('/api/portfolios', portfolioRouter);
  app.use('/api/multi-assets', multiAssetRouter);
  app.use('/api/upload', uploadRouter);
  app.use('/api', bloombergRouter);
  app.use('/api/advanced-assets', advancedAssetsRouter);
  app.use('/api/transactions', transactionRouter);
  app.use('/api/tax', taxRouter);
  app.use('/api/analytics', authMiddleware, checkFeatureEntitlement('advancedAnalytics'), analyticsRouter);
  app.use('/api/fire', authMiddleware, checkFeatureEntitlement('firePlanner'), fireRouter);
  app.use('/api/journal', journalRouter);
  app.use('/api/ai', authMiddleware, checkFeatureEntitlement('aiAssistant'), aiRouter);
  app.use('/api/family', authMiddleware, checkFeatureEntitlement('familyWealth'), familyRouter);
  app.use('/api/sync', syncRouter);
  app.use('/api/thai-brokers', thaiBrokerRouter);
  app.use('/api/crypto', cryptoRouter);
  app.use('/api/gold/rollover', rolloverRouter);
  app.use('/api/rollover', rolloverRouter);
  app.use('/api/gold', goldRouter);
  app.use('/api/audit-logs', authMiddleware, checkFeatureEntitlement('auditTrail'), auditRouter);
  app.use('/api', wave1Router);

  // Centralized 404 & Error Handling
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
