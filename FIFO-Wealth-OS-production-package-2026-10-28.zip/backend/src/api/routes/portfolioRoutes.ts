import { Portfolio as PrismaPortfolio } from '@prisma/client';
import Decimal from 'decimal.js';
import { Router } from 'express';
import { getPrismaClient } from '../../db/prisma';
import { calculateFIFO } from '../../fifoEngine';
import { authMiddleware } from '../../middleware/authMiddleware';
import { AppError } from '../../middleware/errorHandler';
import { validateRequest } from '../../middleware/validationMiddleware';
import { assertUserUsageWithinLimit } from '../../services/entitlementService';
import { Portfolio as SharedPortfolio, PortfolioFIFOSummary } from '../../types/shared';
import {
  deriveReferencePricesTHB,
  mapPrismaPortfolioToShared,
  mapPrismaTransactionToEngine,
} from '../mappers';
import {
  CreatePortfolioBody,
  createPortfolioBodySchema,
  emptyQuerySchema,
  portfolioIdParamsSchema,
} from '../schemas';

export const portfolioRouter = Router();

const Dec = Decimal.clone({ precision: 34, rounding: Decimal.ROUND_HALF_UP });

/**
 * Loads a portfolio by ID and strictly verifies ownership by `userId`.
 */
export async function requireOwnedPortfolio(
  portfolioId: string,
  userId: string
): Promise<PrismaPortfolio> {
  const prisma = getPrismaClient();
  const portfolio = await prisma.portfolio.findUnique({
    where: { id: portfolioId },
  });

  if (!portfolio) {
    throw new AppError(404, 'PORTFOLIO_NOT_FOUND', `Portfolio "${portfolioId}" not found.`);
  }

  if (portfolio.userId !== userId) {
    throw new AppError(
      403,
      'FORBIDDEN_PORTFOLIO_ACCESS',
      'You do not have permission to access this portfolio.'
    );
  }

  return portfolio;
}

async function hydratePortfolioMetrics(portfolio: PrismaPortfolio): Promise<SharedPortfolio> {
  const prisma = getPrismaClient();
  const [txRows, dividendCount] = await Promise.all([
    prisma.transaction.findMany({
      where: { portfolioId: portfolio.id },
      orderBy: { date: 'asc' },
    }),
    prisma.dividend.count({ where: { portfolioId: portfolio.id } }),
  ]);

  let fifoSummary: PortfolioFIFOSummary = {
    totalRealizedGL: 0,
    totalUnrealizedGL: 0,
    totalCostSold: 0,
    totalProceeds: 0,
    openCostBasisTHB: 0,
    marketValueTHB: 0,
    lots: [],
  };

  if (txRows.length > 0) {
    const engineTxs = txRows.map(mapPrismaTransactionToEngine);
    const buys = engineTxs.filter((t) => t.type === 'BUY');
    const sells = engineTxs.filter((t) => t.type === 'SELL');
    const refPrices = deriveReferencePricesTHB(engineTxs);

    if (buys.length > 0) {
      const fifo = calculateFIFO(buys, sells, refPrices);
      let openCostBasis = new Dec(0);
      for (const lot of fifo.lots) {
        if (lot.qtyRemain > 0) {
          openCostBasis = openCostBasis.plus(new Dec(lot.costPerUnit).times(new Dec(lot.qtyRemain)));
        }
      }
      const marketValue = openCostBasis.plus(new Dec(fifo.totalUnrealizedGL));

      fifoSummary = {
        totalRealizedGL: fifo.totalRealizedGL,
        totalUnrealizedGL: fifo.totalUnrealizedGL,
        totalCostSold: fifo.totalCostSold,
        totalProceeds: fifo.totalProceeds,
        openCostBasisTHB: openCostBasis.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toNumber(),
        marketValueTHB: marketValue.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toNumber(),
        lots: fifo.lots,
      };
    }
  }

  return {
    ...mapPrismaPortfolioToShared(portfolio),
    transactionCount: txRows.length,
    dividendCount,
    fifoSummary,
  };
}

/**
 * GET /api/portfolios
 * Lists all portfolios belonging to the authenticated user with live FIFO summaries.
 */
portfolioRouter.get(
  '/',
  authMiddleware,
  validateRequest({ query: emptyQuerySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const portfolios = await prisma.portfolio.findMany({
        where: { userId: req.user!.id },
        orderBy: { createdAt: 'desc' },
      });

      const hydrated = await Promise.all(portfolios.map(hydratePortfolioMetrics));
      res.status(200).json(hydrated);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/portfolios
 * Creates a new portfolio for the authenticated user.
 */
portfolioRouter.post(
  '/',
  authMiddleware,
  validateRequest({ body: createPortfolioBodySchema }),
  async (req, res, next) => {
    try {
      const { name, baseCurrency } = req.body as CreatePortfolioBody;
      const prisma = getPrismaClient();
      const existingPortfolioCount = await prisma.portfolio.count({
        where: { userId: req.user!.id },
      });
      await assertUserUsageWithinLimit(
        req.user!.id,
        'maxPortfolios',
        existingPortfolioCount,
        1
      );

      const created = await prisma.portfolio.create({
        data: {
          userId: req.user!.id,
          name,
          baseCurrency,
        },
      });

      const hydrated = await hydratePortfolioMetrics(created);
      res.status(201).json(hydrated);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/portfolios/:id
 * Returns portfolio details along with transaction/dividend counts and FIFO summary.
 */
portfolioRouter.get(
  '/:id',
  authMiddleware,
  validateRequest({ params: portfolioIdParamsSchema }),
  async (req, res, next) => {
    try {
      const { id } = (res.locals['validated'] as { params: { id: string } }).params;
      const portfolio = await requireOwnedPortfolio(id, req.user!.id);
      const hydrated = await hydratePortfolioMetrics(portfolio);

      res.status(200).json(hydrated);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * DELETE /api/portfolios/:id
 * Deletes a portfolio owned by the authenticated user (cascading child records).
 */
portfolioRouter.delete(
  '/:id',
  authMiddleware,
  validateRequest({ params: portfolioIdParamsSchema }),
  async (req, res, next) => {
    try {
      const { id } = (res.locals['validated'] as { params: { id: string } }).params;
      await requireOwnedPortfolio(id, req.user!.id);

      const prisma = getPrismaClient();
      await prisma.portfolio.delete({ where: { id } });

      res.status(200).json({
        id,
        message: 'Portfolio deleted successfully.',
      });
    } catch (err) {
      next(err);
    }
  }
);
