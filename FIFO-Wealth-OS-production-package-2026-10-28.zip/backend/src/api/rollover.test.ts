import fs from 'fs';
import os from 'os';
import path from 'path';
import { execSync } from 'child_process';
import request from 'supertest';
import { createApp } from './app';
import { getPrismaClient, setPrismaClient } from '../db/prisma';

describe('Contract Rollover Manager REST API (/api/gold/rollover)', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fifo-rollover-api-'));
  const testDbPath = path.join(tmpDir, 'rollover-api.db');

  let tokenA = '';
  let tokenB = '';
  let portfolioId = '';

  beforeAll(async () => {
    process.env['DATABASE_URL'] = `file:${testDbPath}`;
    process.env['JWT_SECRET'] = 'rollover-api-test-secret';
    setPrismaClient(null);

    execSync('npx prisma db push --schema ../database/schema.prisma --skip-generate --accept-data-loss', {
      cwd: path.resolve(__dirname, '../..'),
      env: { ...process.env, DATABASE_URL: `file:${testDbPath}` },
      stdio: 'pipe',
    });

    const app = createApp();
    const regA = await request(app).post('/api/auth/register').send({
      email: 'rollover.a@wealthos.th',
      password: 'Password123!',
      name: 'Futures Desk A',
    });
    tokenA = regA.body.token as string;

    const regB = await request(app).post('/api/auth/register').send({
      email: 'rollover.b@wealthos.th',
      password: 'Password123!',
      name: 'Futures Desk B',
    });
    tokenB = regB.body.token as string;

    const portRes = await request(app)
      .post('/api/portfolios')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({ name: 'TFEX Gold Derivatives Desk', baseCurrency: 'THB' });
    portfolioId = portRes.body.id as string;

    // Seed real Front-Month GOV26 position (3.00 Troy Oz @ $2,600, FX 34.00)
    const openRes = await request(app)
      .post('/api/gold/transactions')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId,
        date: '2026-09-25',
        symbol: 'GOV26',
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        weight: '3.00',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        spotPricePerUnit: '2600.00',
        premiumPerUnit: '0.00',
        commission: '0.00',
        fxRateAtPurchase: '34.00',
        type: 'BUY',
      });
    expect(openRes.status).toBe(201);
  });

  afterAll(async () => {
    await getPrismaClient().$disconnect();
    setPrismaClient(null);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('GET /api/gold/rollover/overview detects 3-day URGENT_3D alert on GOV26 as of 2026-10-26', async () => {
    const app = createApp();
    const res = await request(app)
      .get('/api/gold/rollover/overview')
      .query({ portfolioId, asOfDate: '2026-10-26' })
      .set('Authorization', `Bearer ${tokenA}`);

    expect(res.status).toBe(200);
    expect(res.body.activeAlerts).toHaveLength(1);
    expect(res.body.activeAlerts[0].symbol).toBe('GOV26');
    expect(res.body.activeAlerts[0].daysToExpiry).toBe(3);
    expect(res.body.activeAlerts[0].severity).toBe('URGENT_3D');
    expect(res.body.activeAlerts[0].shouldPlayAudioAlert).toBe(true);
    expect(res.body.activeAlerts[0].suggestedBackSymbol).toBe('GOZ26');
  });

  it('POST /api/gold/rollover/execute atomically rolls back if weight exceeds open position (Zero partial DB writes)', async () => {
    const app = createApp();

    const failRes = await request(app)
      .post('/api/gold/rollover/execute')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId,
        date: '2026-10-26',
        frontSymbol: 'GOV26',
        frontContractMonth: 'V26',
        frontExpirationDate: '2026-10-29',
        frontClosePriceUSD: '2742.00',
        closeCommissionUSD: '4.00',
        backSymbol: 'GOZ26',
        backContractMonth: 'Z26',
        backExpirationDate: '2026-12-29',
        backOpenPriceUSD: '2758.50',
        openCommissionUSD: '4.00',
        weight: '10.00', // Exceeds 3.00 Oz open!
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        fxRateUSDTHB: '35.60',
      });

    expect(failRes.status).toBe(400);
    expect(failRes.body.error.code).toBe('ROLLOVER_INSUFFICIENT_POSITION');

    // Verify zero orphan rollover records were written to SQLite
    const txCount = await getPrismaClient().goldTransactionRecord.count({
      where: { portfolioId },
    });
    const extCount =
      await getPrismaClient().derivativesContractExtension.count();
    expect(txCount).toBe(1);
    expect(extCount).toBe(0);
  });

  it('POST /api/gold/rollover/preview & /execute atomically closes GOV26 (Sold) and opens GOZ26 (Hold) with shared rolloverGroupId, while blocking User B (403)', async () => {
    const app = createApp();

    // Multi-user isolation check
    const forbidden = await request(app)
      .post('/api/gold/rollover/execute')
      .set('Authorization', `Bearer ${tokenB}`)
      .send({
        portfolioId,
        date: '2026-10-26',
        frontSymbol: 'GOV26',
        frontContractMonth: 'V26',
        frontExpirationDate: '2026-10-29',
        frontClosePriceUSD: '2742.00',
        closeCommissionUSD: '4.00',
        backSymbol: 'GOZ26',
        backContractMonth: 'Z26',
        backExpirationDate: '2026-12-29',
        backOpenPriceUSD: '2758.50',
        openCommissionUSD: '4.00',
        weight: '3.00',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        fxRateUSDTHB: '35.60',
      });
    expect(forbidden.status).toBe(403);

    // Preview dry-run
    const previewRes = await request(app)
      .post('/api/gold/rollover/preview')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId,
        date: '2026-10-26',
        frontSymbol: 'GOV26',
        frontContractMonth: 'V26',
        frontExpirationDate: '2026-10-29',
        frontClosePriceUSD: '2742.00',
        closeCommissionUSD: '4.00',
        backSymbol: 'GOZ26',
        backContractMonth: 'Z26',
        backExpirationDate: '2026-12-29',
        backOpenPriceUSD: '2758.50',
        openCommissionUSD: '4.00',
        weight: '3.00',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        fxRateUSDTHB: '35.60',
      });
    expect(previewRes.status).toBe(200);
    expect(previewRes.body.regime).toBe('CONTANGO');
    expect(previewRes.body.spreadPerUnitUSD).toBe('16.50');

    // Execute Atomic Rollover
    const execRes = await request(app)
      .post('/api/gold/rollover/execute')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId,
        date: '2026-10-26',
        frontSymbol: 'GOV26',
        frontContractMonth: 'V26',
        frontExpirationDate: '2026-10-29',
        frontClosePriceUSD: '2742.00',
        closeCommissionUSD: '4.00',
        backSymbol: 'GOZ26',
        backContractMonth: 'Z26',
        backExpirationDate: '2026-12-29',
        backOpenPriceUSD: '2758.50',
        openCommissionUSD: '4.00',
        weight: '3.00',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        fxRateUSDTHB: '35.60',
      });

    expect(execRes.status).toBe(201);
    expect(execRes.body.rolloverGroupId).toBeTruthy();
    expect(execRes.body.closeExtension.rolloverGroupId).toBe(
      execRes.body.openExtension.rolloverGroupId
    );
    expect(execRes.body.closeExtension.legAction).toBe('CLOSE_LONG');
    expect(execRes.body.openExtension.legAction).toBe('OPEN_LONG');

    // Verify Gold Overview FIFO Lots now show GOV26 = Sold (with Realized G/L) and GOZ26 = Hold!
    const goldOverview = await request(app)
      .get('/api/gold/overview')
      .query({ portfolioId })
      .set('Authorization', `Bearer ${tokenA}`);

    expect(goldOverview.status).toBe(200);
    const gov26Lot = goldOverview.body.lots.find(
      (l: { symbol: string }) => l.symbol === 'GOV26'
    );
    const goz26Lot = goldOverview.body.lots.find(
      (l: { symbol: string }) => l.symbol === 'GOZ26'
    );
    expect(gov26Lot.status).toBe('Sold');
    expect(Number(gov26Lot.realizedGL)).toBeGreaterThan(25000);
    expect(goz26Lot.status).toBe('Hold');
    expect(goz26Lot.weightRemain).toBe('3.0000');

    // Verify Rollover Overview reflects 0 urgent alerts remaining (GOZ26 is 64 days SAFE) & 1 rollover history item
    const afterRollOverview = await request(app)
      .get('/api/gold/rollover/overview')
      .query({ portfolioId, asOfDate: '2026-10-26' })
      .set('Authorization', `Bearer ${tokenA}`);
    expect(afterRollOverview.body.summary.urgentExpiringCount).toBe(0);
    expect(afterRollOverview.body.summary.totalRolloversExecuted).toBe(1);
    expect(afterRollOverview.body.activeAlerts[0].symbol).toBe('GOZ26');
    expect(afterRollOverview.body.activeAlerts[0].severity).toBe('SAFE');
  });
});
