import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = process.env.BASE_URL ?? 'http://localhost:3001';
const OUTPUT_DIRS = [path.resolve(process.env.SCREENSHOT_DIR ?? 'screenshots')];

function saveScreenshot(filename, buffer) {
  for (const directory of OUTPUT_DIRS) {
    fs.mkdirSync(directory, { recursive: true });
    fs.writeFileSync(path.join(directory, filename), buffer);
  }
  console.log(`Saved ${filename}`);
}

async function dismissOnboardingIfVisible(page) {
  const modal = page.locator('[data-testid="onboarding-modal"]');
  if (await modal.isVisible().catch(() => false)) {
    await page.locator('[data-testid="onboarding-skip-btn"]').click();
    await modal.waitFor({ state: 'hidden', timeout: 10000 });
  }
}

async function run() {
  const browserErrors = [];
  const browser = await chromium.launch({ headless: true });
  try {
    const context = await browser.newContext({
      viewport: { width: 1440, height: 1000 },
      deviceScaleFactor: 1,
    });
    await context.addInitScript(() => {
      window.localStorage.setItem('theme', 'light');
      window.localStorage.setItem('fifo_wealth_onboarding_seen_v1', 'true');
    });

    const page = await context.newPage();
    page.on('pageerror', (error) => browserErrors.push(`page: ${error.message}`));
    page.on('console', (message) => {
      if (message.type() === 'error') browserErrors.push(`console: ${message.text()}`);
    });
    page.on('response', (response) => {
      if (response.url().includes('/api/') && response.status() >= 500) {
        browserErrors.push(`api ${response.status()}: ${response.url()}`);
      }
    });

    await page.goto(`${BASE_URL}/th/login`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.locator('#login-email').waitFor({ timeout: 30000 });
    await page.fill('#login-email', 'demo@wealthos.th');
    await page.fill('#login-password', 'WealthOS2024!');
    await Promise.all([
      page.waitForURL(/\/th\/?$/, { timeout: 45000 }),
      page.locator('button[type="submit"]').click(),
    ]);
    await page.locator('[data-testid="dashboard-heading"]').waitFor({ timeout: 30000 });
    await dismissOnboardingIfVisible(page);

    const pricingResponsePromise = page.waitForResponse(
      (response) => response.url().includes('/api/billing/pricing'),
      { timeout: 30000 }
    );
    await page.goto(`${BASE_URL}/th/pricing`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    const pricingResponse = await pricingResponsePromise;
    if (pricingResponse.status() !== 200) throw new Error(`Pricing endpoint returned ${pricingResponse.status()}.`);
    const pricingCatalog = await pricingResponse.json();
    const proPricing = pricingCatalog.pricing?.tiers?.find((tier) => tier.tier === 'PRO');
    if (proPricing?.monthlyPriceTHB !== '290.00' || proPricing?.yearlyPriceTHB !== '2784.00') {
      throw new Error(`Unexpected PRO base pricing: ${JSON.stringify(proPricing)}`);
    }
    if (proPricing?.earlyBirdMonthlyPriceTHB !== '203.00') {
      throw new Error(`Expected exact Early-Bird math ฿290 × 0.7 = ฿203.00; received ${proPricing?.earlyBirdMonthlyPriceTHB}.`);
    }
    await page.locator('[data-testid="pricing-title"]').waitFor({ timeout: 30000 });
    await page.locator('[data-testid="pricing-tier-advisor"]').waitFor({ timeout: 15000 });
    if (await page.locator('[data-testid^="pricing-tier-"]').count() !== 4) {
      throw new Error('Expected four pricing tier cards.');
    }
    await page.locator('[data-testid="pro-recommended-badge"]').waitFor({ state: 'visible' });
    await page.locator('[data-testid="early-bird-banner"]').waitFor({ state: 'visible' });
    await page.getByText('ถึง 30 มิ.ย. 2027', { exact: false }).waitFor({ state: 'visible' }).catch(async () => {
      await page.getByText('30 มิ.ย. 2027', { exact: false }).waitFor({ state: 'visible', timeout: 10000 });
    });
    await page.locator('[data-testid="pricing-amount-pro"]').waitFor({ state: 'visible' });
    const monthlyPro = (await page.locator('[data-testid="pricing-amount-pro"]').textContent())?.trim();
    if (monthlyPro !== '฿203') throw new Error(`Expected Early-Bird Pro monthly price ฿203; received ${monthlyPro}.`);
    await page.locator('[data-testid="pricing-interval-year"]').click();
    await page.waitForFunction(
      () => document.querySelector('[data-testid="pricing-amount-pro"]')?.textContent?.trim() === '฿1,948.80',
      null,
      { timeout: 10000 }
    );
    await page.locator('[data-testid="yearly-savings-badge"]').waitFor({ state: 'visible' });
    await page.locator('[data-testid="pricing-interval-month"]').click();
    await page.waitForFunction(
      () => document.querySelector('[data-testid="pricing-amount-pro"]')?.textContent?.trim() === '฿203',
      null,
      { timeout: 10000 }
    );
    saveScreenshot('54-pricing-page-with-tiers.png', await page.screenshot({ fullPage: true }));
    saveScreenshot('55-early-bird-banner.png', await page.locator('[data-testid="early-bird-banner"]').screenshot());

    const billingResponsePromise = page.waitForResponse(
      (response) => response.url().includes('/api/billing/status'),
      { timeout: 30000 }
    );
    await page.goto(`${BASE_URL}/th/settings/billing`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    const billingResponse = await billingResponsePromise;
    if (billingResponse.status() !== 200) throw new Error(`Billing status endpoint returned ${billingResponse.status()}.`);
    const billingStatus = await billingResponse.json();
    if (billingStatus.status !== 'BETA_ALL_ACCESS' || billingStatus.isBetaAllAccess !== true) {
      throw new Error(`Unexpected billing status response: ${JSON.stringify(billingStatus)}`);
    }
    if (billingStatus.chargesEnabled !== false) throw new Error('Subscription charges must remain disabled during Open Beta.');
    const statusPro = billingStatus.pricing?.tiers?.find((tier) => tier.tier === 'PRO');
    if (statusPro?.monthlyPriceTHB !== '290.00' || statusPro?.yearlyPriceTHB !== '2784.00') {
      throw new Error(`Unexpected Billing Settings Pro prices: ${JSON.stringify(statusPro)}`);
    }
    await page.locator('[data-testid="beta-all-access-card"]').waitFor({ timeout: 30000 });
    await page.locator('[data-testid="open-beta-badge"]').waitFor({ state: 'visible' });
    await page.locator('[data-testid="all-access-green-badge"]').waitFor({ state: 'visible' });
    await page.getByText('BETA_ALL_ACCESS', { exact: true }).waitFor({ timeout: 15000 });
    const planTitle = (await page.locator('[data-testid="billing-plan-title"]').textContent())?.trim();
    if (planTitle !== 'Open Beta (All Access)') throw new Error(`Unexpected billing plan title: ${planTitle}`);
    const upgrade = page.locator('[data-testid="upgrade-to-pro"]');
    await upgrade.waitFor({ state: 'visible' });
    if (!(await upgrade.isDisabled())) throw new Error('Upgrade to Pro must remain disabled during Open Beta.');
    if (!(await page.locator('[data-testid="upgrade-tooltip-wrapper"]').getAttribute('title'))) {
      throw new Error('Upgrade to Pro must expose an explanatory tooltip.');
    }
    if (await page.locator('[data-testid^="billing-price-"]').count() !== 4) {
      throw new Error('Expected four price cards on Billing Settings.');
    }
    await page.locator('[data-testid="billing-feature-comparison"]').waitFor({ state: 'visible' });
    await page.locator('[data-testid="billing-feature-row-maxClients"]').waitFor({ state: 'visible' });
    await page.locator('[data-testid="billing-community-fundraising"]').waitFor({ state: 'visible' });
    saveScreenshot('56-billing-settings-updated.png', await page.screenshot({ fullPage: true }));

    const communityResponsePromise = page.waitForResponse(
      (response) => response.url().includes('/api/billing/community'),
      { timeout: 30000 }
    );
    await page.goto(`${BASE_URL}/th/support`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    const communityResponse = await communityResponsePromise;
    if (communityResponse.status() !== 200) throw new Error(`Community fundraising endpoint returned ${communityResponse.status()}.`);
    const community = await communityResponse.json();
    if (community.baselineTHB !== '127450.00' || community.targetTHB !== '500000.00') {
      throw new Error(`Unexpected community fundraising baseline/goal: ${JSON.stringify(community)}`);
    }
    if (Number(community.totalRaisedTHB) !== Number(community.baselineTHB) + Number(community.successfulDonationsTHB)) {
      throw new Error('Community total must equal baseline plus succeeded database donations.');
    }
    await page.locator('[data-testid="support-title"]').waitFor({ timeout: 30000 });
    await page.locator('[data-testid="community-fundraising-card"]').waitFor({ state: 'visible' });
    await page.locator('[data-testid="donor-pro-year-reward"]').waitFor({ state: 'visible' });
    await page.getByText('฿2,784', { exact: false }).first().waitFor({ state: 'visible' });
    for (const amount of ['100', '500', '1000', '5000']) {
      await page.locator(`[data-testid="donation-preset-${amount}"]`).waitFor({ state: 'visible' });
    }
    await page.locator('[data-testid="donation-preset-1000"]').click();
    await page.locator('[data-testid="donation-message"]').fill('Thank you for building transparent wealth tools.');
    await page.locator('[data-testid="support-stripe-button"]').waitFor({ state: 'visible' });
    if (await page.locator('[data-testid="donation-preset-1000"]').getAttribute('aria-pressed') !== 'true') {
      throw new Error('฿1,000 preset did not become selected.');
    }
    saveScreenshot('57-donation-with-early-bird-perk.png', await page.screenshot({ fullPage: true }));

    if (browserErrors.length > 0) throw new Error(`Browser errors detected:\n${browserErrors.join('\n')}`);
    console.log('Billing, Pricing & Support UI E2E passed: tier pricing, 30% Early-Bird math, deferred trial, all-access Billing, feature matrix, community goal, and donor Pro-year perk.');
  } finally {
    await browser.close();
  }
}

run().catch((error) => {
  console.error('Billing, Pricing & Support verification failed:', error);
  process.exit(1);
});
