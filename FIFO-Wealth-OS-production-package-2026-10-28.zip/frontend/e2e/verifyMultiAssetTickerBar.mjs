import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = process.env.BASE_URL ?? 'http://127.0.0.1:3001';
const OUTPUT_DIR = path.resolve(process.env.SCREENSHOT_DIR ?? 'screenshots');
const pageErrors = [];

function saveScreenshot(filename, buffer) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  fs.writeFileSync(path.join(OUTPUT_DIR, filename), buffer);
  console.log(`Saved ${path.join(OUTPUT_DIR, filename)}`);
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function amountFromText(value) {
  return Number(String(value ?? '').replace(/[^0-9.-]/g, ''));
}

async function run() {
  const browser = await chromium.launch({ headless: true });
  try {
    const context = await browser.newContext({
      viewport: { width: 1600, height: 1120 },
      deviceScaleFactor: 1,
      colorScheme: 'light',
    });
    const page = await context.newPage();
    page.on('pageerror', (error) => pageErrors.push(error.message));
    page.on('console', (message) => {
      if (message.type() === 'error') pageErrors.push(`console: ${message.text()}`);
    });
    await page.addInitScript(() => {
      window.localStorage.setItem('theme', 'light');
      window.localStorage.setItem('fifo_wealth_onboarding_seen_v1', 'true');
    });

    await page.goto(`${BASE_URL}/th`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.locator('[data-testid="dashboard-heading"]').waitFor({ timeout: 30000 });
    await page.locator('[data-testid="multi-asset-ticker-bar"]').waitFor({ timeout: 30000 });
    await page.locator('[data-testid="tax-loss-opportunities-table"]').waitFor({ timeout: 30000 });
    await page.waitForFunction(
      () => document.querySelectorAll('[data-testid^="ticker-item-"]').length === 8
    );
    await page.waitForTimeout(350);

    // Check all four instrument classes and the memoized category filter behavior.
    const categoryCounts = await page.evaluate(() => ({
      tickerCount: document.querySelectorAll('[data-testid^="ticker-item-"]').length,
      categories: [...new Set([...document.querySelectorAll('[data-testid^="ticker-item-"]')].map((element) => element.getAttribute('data-category')))],
    }));
    assert(categoryCounts.tickerCount === 8, 'Expected 8 mock tickers.');
    for (const category of ['TH_STOCK', 'US_STOCK', 'GOLD', 'CRYPTO']) {
      assert(categoryCounts.categories.includes(category), `Missing ticker category ${category}.`);
    }
    for (const [category, expectedCount] of [['TH_STOCK', 2], ['US_STOCK', 2], ['GOLD', 1], ['CRYPTO', 3]]) {
      await page.locator(`[data-testid="ticker-filter-${category}"]`).click();
      assert((await page.locator('[data-testid^="ticker-item-"]').count()) === expectedCount, `${category} filter returned an unexpected instrument count.`);
    }
    await page.locator('[data-testid="ticker-filter-US_STOCK"]').click();
    assert((await page.locator('[data-testid="ticker-item-AAPL"]').count()) === 1, 'US filter should include AAPL.');
    assert((await page.locator('[data-testid="ticker-item-PTT"]').count()) === 0, 'US filter should exclude PTT.');
    await page.locator('[data-testid="ticker-filter-ALL"]').click();

    // Confirm requestAnimationFrame auto-scroll pauses on hover and resumes after pointer exit.
    const track = page.locator('[data-testid="ticker-scroll-track"]');
    const overflow = await track.evaluate((element) => element.scrollWidth - element.clientWidth);
    assert(overflow > 5, `Ticker must overflow horizontally for auto-scroll test (overflow=${overflow}).`);
    await track.evaluate((element) => { element.scrollLeft = 0; });
    await track.hover();
    const hoverStart = await track.evaluate((element) => element.scrollLeft);
    await page.waitForTimeout(450);
    const hoverEnd = await track.evaluate((element) => element.scrollLeft);
    assert(Math.abs(hoverEnd - hoverStart) < 2, `Ticker moved while hovered (${hoverStart} -> ${hoverEnd}).`);
    await page.mouse.move(5, 5);
    await page.waitForTimeout(600);
    const resumedPosition = await track.evaluate((element) => element.scrollLeft);
    assert(resumedPosition > hoverEnd + 2, `Ticker did not resume after hover (${hoverEnd} -> ${resumedPosition}).`);
    await track.evaluate((element) => { element.scrollLeft = 0; });

    // Verify both themes render, then return to light for screenshot 50.
    const themeToggle = page.locator('[data-testid="theme-toggle"]').first();
    await themeToggle.click();
    await page.waitForFunction(() => document.documentElement.classList.contains('dark'));
    const darkBarBackground = await page.locator('[data-testid="multi-asset-ticker-bar"]').evaluate(
      (element) => getComputedStyle(element).backgroundColor
    );
    assert(darkBarBackground !== 'rgba(0, 0, 0, 0)' && darkBarBackground !== 'rgb(255, 255, 255)', `Ticker did not render a dark background: ${darkBarBackground}`);
    await themeToggle.click();
    await page.waitForFunction(() => !document.documentElement.classList.contains('dark'));

    await page.mouse.move(5, 5);
    await page.waitForTimeout(150);
    saveScreenshot(
      '50-multi-asset-ticker-bar-desktop.png',
      await page.screenshot({ fullPage: false })
    );

    // Refresh prices and assert live ticker quote, THB Tax-Loss quote, loss and saving all recalculate.
    const tickerPrice = page.locator('[data-testid="ticker-price-AAPL"]');
    const tlhPrice = page.locator('[data-testid="tlh-price-AAPL"]');
    const tlhLoss = page.locator('[data-testid="tlh-loss-AAPL"]');
    const tlhSaving = page.locator('[data-testid="tlh-saving-AAPL"]');
    const totalPotentialSaving = page.locator('[data-testid="tlh-total-potential-saving"]');
    const before = {
      ticker: (await tickerPrice.textContent())?.trim(),
      price: (await tlhPrice.textContent())?.trim(),
      loss: (await tlhLoss.textContent())?.trim(),
      saving: (await tlhSaving.textContent())?.trim(),
      totalSaving: (await totalPotentialSaving.textContent())?.trim(),
    };
    const beforeQuotes = await page.locator('[data-testid^="ticker-item-"]').evaluateAll((elements) =>
      elements.map((element) => ({
        symbol: element.getAttribute('data-testid')?.replace('ticker-item-', ''),
        price: Number(element.getAttribute('data-price')),
      }))
    );

    const refreshStartedAt = Date.now();
    await page.locator('[data-testid="ticker-refresh-btn"]').click();
    await page.locator('[data-testid="ticker-refresh-status"]').waitFor({ state: 'visible', timeout: 3000 });
    await page.waitForFunction(
      (previousTickerPrice) => document.querySelector('[data-testid="ticker-price-AAPL"]')?.textContent?.trim() !== previousTickerPrice,
      before.ticker,
      { timeout: 10000 }
    );
    await page.waitForFunction(
      (previousPrice) => document.querySelector('[data-testid="tlh-price-AAPL"]')?.textContent?.trim() !== previousPrice,
      before.price,
      { timeout: 10000 }
    );
    await page.waitForFunction(
      (previousLoss) => document.querySelector('[data-testid="tlh-loss-AAPL"]')?.textContent?.trim() !== previousLoss,
      before.loss,
      { timeout: 10000 }
    );
    await page.waitForFunction(
      (previousSaving) => document.querySelector('[data-testid="tlh-saving-AAPL"]')?.textContent?.trim() !== previousSaving,
      before.saving,
      { timeout: 10000 }
    );
    await page.waitForFunction(
      (previousSaving) => document.querySelector('[data-testid="tlh-total-potential-saving"]')?.textContent?.trim() !== previousSaving,
      before.totalSaving,
      { timeout: 10000 }
    );
    const refreshDelayMs = Date.now() - refreshStartedAt;
    assert(refreshDelayMs >= 450, `Mock market fetch returned too quickly (${refreshDelayMs}ms; expected ~500ms).`);

    const afterQuotes = await page.locator('[data-testid^="ticker-item-"]').evaluateAll((elements) =>
      elements.map((element) => ({
        symbol: element.getAttribute('data-testid')?.replace('ticker-item-', ''),
        price: Number(element.getAttribute('data-price')),
      }))
    );
    assert(afterQuotes.length === beforeQuotes.length, 'Refresh changed the instrument count.');
    for (const previous of beforeQuotes) {
      const next = afterQuotes.find((quote) => quote.symbol === previous.symbol);
      assert(Boolean(next), `Refreshed quote missing for ${previous.symbol}.`);
      const movePct = Math.abs(((next.price - previous.price) / previous.price) * 100);
      assert(next.price !== previous.price, `${previous.symbol} price did not change.`);
      assert(movePct <= 1.001, `${previous.symbol} move exceeded the ±1% mock band (${movePct}%).`);
    }

    const after = {
      ticker: (await tickerPrice.textContent())?.trim(),
      price: (await tlhPrice.textContent())?.trim(),
      loss: (await tlhLoss.textContent())?.trim(),
      saving: (await tlhSaving.textContent())?.trim(),
      totalSaving: (await totalPotentialSaving.textContent())?.trim(),
    };
    const rowSavingTotal = (await page.locator('[data-testid^="tlh-saving-"]').allTextContents())
      .reduce((sum, value) => sum + amountFromText(value), 0);
    assert(Math.abs(rowSavingTotal - amountFromText(after.totalSaving)) < 0.011, 'Tax-Loss total saving does not equal the refreshed opportunity savings.');
    console.log('[Ticker refresh -> Tax-Loss recalculation]', JSON.stringify({ before, after }));
    assert(after.ticker !== before.ticker, 'Ticker quote did not change after refresh.');
    assert(after.price !== before.price, 'Tax-Loss current price did not receive the refreshed quote.');
    assert(after.loss !== before.loss, 'Tax-Loss unrealized loss did not recalculate.');
    assert(after.saving !== before.saving, 'Tax-Loss saving potential did not recalculate.');
    assert(after.totalSaving !== before.totalSaving, 'Selected Tax-Loss total saving did not recalculate.');

    // Screenshot while refreshed values are visible and the pending-update status is still active.
    await page.locator('[data-testid="ticker-refresh-status"]').waitFor({ state: 'visible', timeout: 1000 });
    saveScreenshot(
      '51-ticker-refresh-updating-tax-loss.png',
      await page.screenshot({ fullPage: false })
    );

    await page.locator('[data-testid="ticker-refresh-status"]').waitFor({ state: 'detached', timeout: 5000 });
    await context.close();

    assert(pageErrors.length === 0, `Browser errors detected:\n${pageErrors.join('\n')}`);
    console.log('Multi-Asset Ticker E2E passed: filters, RAF hover pause/resume, light/dark, refresh, and Tax-Loss recalculation.');
  } finally {
    await browser.close();
  }
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
