import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const OUTPUT_DIRS = [path.resolve(process.env.SCREENSHOT_DIR ?? 'screenshots')];

function saveScreenshot(filename, buffer) {
  for (const dir of OUTPUT_DIRS) {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, filename), buffer);
  }
  console.log(`Saved ${filename}`);
}

async function runVerification() {
  const pageErrors = [];
  const browser = await chromium.launch({ headless: true });

  try {
    // =========================================================================
    // 1. DESKTOP (1440 x 960): Onboarding -> Journal -> AI Drawer -> Family -> i18n EN + Dark Mode
    // =========================================================================
    const desktopCtx = await browser.newContext({
      viewport: { width: 1440, height: 960 },
      deviceScaleFactor: 1,
    });
    const page = await desktopCtx.newPage();
    page.on('pageerror', (err) => pageErrors.push(`DESKTOP_ERR: ${err.message}`));

    // Sign in on /th/login
    await page.goto(`${BASE_URL}/th/login`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForSelector('#login-email', { timeout: 30000 });
    await page.waitForTimeout(800);
    await Promise.all([
      page.waitForURL(`${BASE_URL}/th`, { timeout: 45000 }),
      page.click('button[type="submit"]'),
    ]);

    // Verify Thai locale & Sarabun font priority
    const thFontAudit = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      bodyFont: getComputedStyle(document.body).fontFamily,
    }));
    console.log('[TH Font Audit]:', JSON.stringify(thFontAudit));
    if (thFontAudit.lang !== 'th' || !thFontAudit.bodyFont.toLowerCase().includes('sarabun')) {
      throw new Error(`Expected Thai lang & Sarabun font, got ${JSON.stringify(thFontAudit)}`);
    }

    // 1A. Verify 3-Step Onboarding Walkthrough automatically opens on first visit!
    await page.waitForSelector('[data-testid="onboarding-modal"]', { timeout: 20000 });
    await page.waitForTimeout(400);
    saveScreenshot(
      '17-onboarding-walkthrough-desktop.png',
      await page.screenshot({ fullPage: false })
    );

    // Step through 1 -> 2 -> 3 -> Finish
    await page.click('[data-testid="onboarding-next-btn"]');
    await page.waitForTimeout(250);
    await page.click('[data-testid="onboarding-next-btn"]');
    await page.waitForTimeout(250);
    await page.click('[data-testid="onboarding-finish-btn"]');
    await page.waitForSelector('[data-testid="onboarding-modal"]', {
      state: 'detached',
      timeout: 10000,
    });

    // 1B. Navigate to Wealth Journal (/th/journal)
    await Promise.all([
      page.waitForURL(`${BASE_URL}/th/journal`, { timeout: 30000 }),
      page.click('[data-testid="desktop-sidebar"] a[href="/th/journal"]'),
    ]);

    await page.waitForSelector('[data-testid="wealth-journal-calendar"]', {
      timeout: 20000,
    });
    await page.waitForSelector('[data-testid="journal-dot-indicator"]', {
      timeout: 20000,
    });

    // Click calendar day 2026-10-28 -> Create new Bullish memo
    await page.click('[data-testid="calendar-day-2026-10-28"]');
    await page.waitForSelector('[data-testid="journal-modal"]', { timeout: 10000 });
    await page.click('[data-testid="mood-btn-BULLISH"]');
    await page.fill(
      '[data-testid="journal-title-input"]',
      'ตรวจสอบสมดุลพอร์ตปลายเดือนตุลาคม'
    );
    await page.fill(
      '[data-testid="journal-content-input"]',
      'พอร์ตหุ้นเทคโนโลยีสหรัฐฯ และคริปโตอยู่ในกรอบความเสี่ยงที่กำหนด พร้อมต่อยอดแผน FIRE'
    );
    await page.click('[data-testid="journal-save-btn"]');
    await page.waitForSelector('[data-testid="journal-modal"]', {
      state: 'detached',
      timeout: 15000,
    });
    await page.waitForTimeout(500);

    saveScreenshot(
      '18-wealth-journal-calendar-light.png',
      await page.screenshot({ fullPage: false })
    );

    // 1C. Open AI Wealth Assistant Drawer & ask "เดือนไหนกำไรสุด"
    await page.click('[data-testid="open-ai-drawer-btn"]');
    await page.waitForSelector('[data-testid="ai-chat-drawer"]', { timeout: 10000 });
    await page.fill(
      '[data-testid="ai-chat-input"]',
      'เดือนไหนกำไรสุด สรุปพอร์ตเดือนนี้ให้หน่อย'
    );
    await page.click('[data-testid="ai-chat-send"]');
    await page.waitForSelector('[data-testid="ai-assistant-message"]', {
      timeout: 20000,
    });
    // Wait for smooth Typing Effect to finish revealing full reply
    await page.waitForTimeout(1600);

    saveScreenshot(
      '19-ai-wealth-assistant-drawer.png',
      await page.screenshot({ fullPage: false })
    );

    // Close AI Drawer
    await page.click('[aria-label="Close AI Drawer"]');
    await page.waitForTimeout(300);

    // 1D. Navigate to Family Wealth (/th/family)
    await Promise.all([
      page.waitForURL(`${BASE_URL}/th/family`, { timeout: 30000 }),
      page.click('[data-testid="desktop-sidebar"] a[href="/th/family"]'),
    ]);

    await page.waitForSelector('[data-testid="household-net-worth-value"]', {
      timeout: 20000,
    });
    await page.waitForTimeout(600);

    saveScreenshot(
      '20-family-wealth-dashboard-light.png',
      await page.screenshot({ fullPage: false })
    );

    // Open Invite QR Modal
    await page.click('[data-testid="open-invite-modal-btn"]');
    await page.waitForSelector('[data-testid="invite-qr-svg"] svg', {
      timeout: 15000,
    });
    await page.click('[data-testid="copy-invite-code-btn"]');
    await page.waitForTimeout(400);

    saveScreenshot(
      '21-family-invite-qr-modal.png',
      await page.screenshot({ fullPage: false })
    );

    // Close Invite Modal
    await page.keyboard.press('Escape').catch(() => {});
    await page.click('[data-testid="family-invite-modal"] button').catch(() => {});
    await page.waitForTimeout(300);

    // 1E. Test LanguageSwitcher -> Switch TH to EN (/en/family) + Dark Mode!
    await Promise.all([
      page.waitForURL(`${BASE_URL}/en/family`, { timeout: 30000 }),
      page.click('[data-testid="lang-btn-en"]'),
    ]);
    await page.waitForSelector('h1:has-text("Family Wealth Overview")', {
      timeout: 20000,
    });

    const enFontAudit = await page.evaluate(() => ({
      lang: document.documentElement.lang,
      bodyFont: getComputedStyle(document.body).fontFamily,
    }));
    console.log('[EN Font Audit]:', JSON.stringify(enFontAudit));
    if (enFontAudit.lang !== 'en' || !enFontAudit.bodyFont.toLowerCase().includes('jakarta')) {
      throw new Error(
        `Expected English lang & Plus Jakarta Sans font, got ${JSON.stringify(enFontAudit)}`
      );
    }

    // Toggle Dark Mode
    await page.click('[data-testid="desktop-sidebar"] [data-testid="theme-toggle"]');
    await page.waitForFunction(
      () => document.documentElement.classList.contains('dark'),
      null,
      { timeout: 10000 }
    );
    await page.waitForTimeout(600);

    saveScreenshot(
      '22-i18n-english-dark-mode.png',
      await page.screenshot({ fullPage: false })
    );

    await desktopCtx.close();

    // =========================================================================
    // 2. MOBILE (390 x 844): Onboarding Flow + Localized Mobile BottomNav
    // =========================================================================
    const mobileCtx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: true,
    });
    const mPage = await mobileCtx.newPage();
    mPage.on('pageerror', (err) => pageErrors.push(`MOBILE_ERR: ${err.message}`));

    await mPage.goto(`${BASE_URL}/en/login`, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await mPage.waitForSelector('#login-email', { timeout: 30000 });
    await mPage.waitForTimeout(800);
    await Promise.all([
      mPage.waitForURL(`${BASE_URL}/en`, { timeout: 45000 }),
      mPage.click('button[type="submit"]'),
    ]);

    // Verify Onboarding Walkthrough works cleanly on Mobile in English!
    await mPage.waitForSelector('[data-testid="onboarding-modal"]', { timeout: 20000 });
    await mPage.click('[data-testid="onboarding-next-btn"]');
    await mPage.waitForTimeout(300);

    saveScreenshot(
      '23-mobile-onboarding-and-i18n.png',
      await mPage.screenshot({ fullPage: false })
    );

    await mPage.click('[data-testid="onboarding-next-btn"]');
    await mPage.waitForTimeout(200);
    await mPage.click('[data-testid="onboarding-finish-btn"]');
    await mPage.waitForSelector('[data-testid="onboarding-modal"]', {
      state: 'detached',
      timeout: 10000,
    });

    // Verify Mobile BottomNav tabs work in English (/en/family)
    await Promise.all([
      mPage.waitForURL(`${BASE_URL}/en/family`, { timeout: 30000 }),
      mPage.click('[data-testid="mobile-bottom-nav"] a[href="/en/family"]'),
    ]);
    await mPage.waitForSelector('[data-testid="household-net-worth-value"]', {
      timeout: 20000,
    });

    await mobileCtx.close();

    if (pageErrors.length > 0) {
      throw new Error(`Runtime errors detected: ${pageErrors.join(' | ')}`);
    }

    console.log('ALL PHASES 10, 11 & 12 PLAYWRIGHT E2E & VISUAL CHECKS PASSED!');
  } finally {
    await browser.close();
  }
}

runVerification().catch((err) => {
  console.error('E2E Verification failed:', err);
  process.exit(1);
});
