import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const OUTPUT_DIRS = [path.resolve(process.env.SCREENSHOT_DIR ?? 'screenshots')];

function saveScreenshot(filename, buffer) {
  for (const dir of OUTPUT_DIRS) {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, filename), buffer);
  }
  console.log(`Saved ${filename}`);
}

async function runFireVerification() {
  const pageErrors = [];
  const browser = await chromium.launch({ headless: true });

  try {
    // =========================================================================
    // 1. Desktop (1440 x 960) — Light Mode Calculator, Success Badge, Dark Mode Monte Carlo
    // =========================================================================
    const desktopCtx = await browser.newContext({
      viewport: { width: 1440, height: 960 },
      deviceScaleFactor: 1,
    });
    const page = await desktopCtx.newPage();
    page.on('pageerror', (err) => pageErrors.push(`DESKTOP_ERROR: ${err.message}`));

    await page.goto(`${BASE_URL}/login`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForSelector('#login-email', { timeout: 30000 });
    await Promise.all([
      page.waitForURL(`${BASE_URL}/`, { timeout: 45000 }),
      page.click('button[type="submit"]'),
    ]);

    // Ensure Light Mode first
    await page.evaluate(() => {
      document.documentElement.classList.remove('dark');
      window.localStorage.setItem('theme', 'light');
    });

    // Navigate to /fire via Desktop Sidebar Item
    await page.waitForSelector('[data-testid="desktop-sidebar"] a[href="/fire"]', {
      timeout: 30000,
    });
    await Promise.all([
      page.waitForURL(`${BASE_URL}/fire`, { timeout: 45000 }),
      page.click('[data-testid="desktop-sidebar"] a[href="/fire"]'),
    ]);

    await page.waitForSelector('text=เส้นทางสู่อิสรภาพทางการเงินของคุณ', {
      timeout: 45000,
    });
    await page.waitForSelector('[data-testid="calculated-fire-number"]', {
      timeout: 30000,
    });
    await page.waitForSelector('[data-testid="monte-carlo-card"]', {
      timeout: 30000,
    });
    await page.waitForSelector('[data-testid="fire-goal-card"]', {
      timeout: 30000,
    });

    // Run 150-path live Monte Carlo simulation with realistic savings rate (~88% Emerald Success Rate)
    await page.fill('#fire-monthly-contrib', '36000');
    await page.click('button:has-text("จำลอง Monte Carlo")');
    await page.waitForSelector('button:has-text("จำลอง Monte Carlo (150 เส้นทาง)")', {
      timeout: 30000,
    });
    await page.waitForSelector('[data-testid="fire-success-badge"]', {
      timeout: 30000,
    });
    await page.waitForTimeout(800);

    // Verify Desktop Sidebar has active FIRE item and Mobile BottomNav is hidden
    const desktopBottomNavVisible = await page
      .locator('[data-testid="mobile-bottom-nav"]')
      .isVisible();
    if (desktopBottomNavVisible) {
      throw new Error('BottomNav should be hidden on Desktop!');
    }

    // 1) Screenshot: 13-fire-calculator-clean-light.png
    const lightBuf = await page.screenshot({ fullPage: true });
    saveScreenshot('13-fire-calculator-clean-light.png', lightBuf);

    // 4) Screenshot: 16-fire-success-badge.png (Clean close-up around Success Rate Badge + Milestones)
    const mcCardBox = await page.locator('[data-testid="monte-carlo-card"]').boundingBox();
    const badgeBox = await page.locator('[data-testid="fire-success-badge"]').boundingBox();
    if (!mcCardBox || !badgeBox) {
      throw new Error('Could not locate Monte Carlo card or Success Badge bounding box.');
    }

    const badgeCloseUpBuf = await page.screenshot({
      clip: {
        x: Math.max(0, mcCardBox.x),
        y: Math.max(0, mcCardBox.y),
        width: mcCardBox.width,
        height: Math.min(210, mcCardBox.height),
      },
    });
    saveScreenshot('16-fire-success-badge.png', badgeCloseUpBuf);

    // Switch to Dark Mode via ThemeToggle in Desktop Sidebar
    await page.click('[data-testid="desktop-sidebar"] [data-testid="theme-toggle"]');
    await page.waitForFunction(
      () => document.documentElement.classList.contains('dark'),
      null,
      { timeout: 10000 }
    );
    await page.waitForTimeout(800);

    // 2) Screenshot: 14-monte-carlo-premium-dark.png (Monte Carlo Chart + FIRE Dashboard in Dark Mode)
    const darkMcCard = page.locator('[data-testid="monte-carlo-card"]');
    await darkMcCard.scrollIntoViewIfNeeded();
    await page.waitForTimeout(400);
    const darkBuf = await page.screenshot({ fullPage: false });
    saveScreenshot('14-monte-carlo-premium-dark.png', darkBuf);

    await desktopCtx.close();

    // =========================================================================
    // 2. Mobile (390 x 844 — iPhone 14 Pro) — FIRE Goals + Bottom Tab Bar
    // =========================================================================
    const mobileCtx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: true,
    });
    const mPage = await mobileCtx.newPage();
    mPage.on('pageerror', (err) => pageErrors.push(`MOBILE_ERROR: ${err.message}`));

    await mPage.goto(`${BASE_URL}/login`, { waitUntil: 'networkidle', timeout: 60000 });
    await mPage.waitForSelector('#login-email', { timeout: 30000 });
    await Promise.all([
      mPage.waitForURL(`${BASE_URL}/`, { timeout: 45000 }),
      mPage.click('button[type="submit"]'),
    ]);

    // Tap the "FIRE" tab in Mobile BottomNav!
    await mPage.waitForSelector('[data-testid="mobile-bottom-nav"] a[href="/fire"]', {
      timeout: 30000,
    });
    await Promise.all([
      mPage.waitForURL(`${BASE_URL}/fire`, { timeout: 45000 }),
      mPage.click('[data-testid="mobile-bottom-nav"] a[href="/fire"]'),
    ]);

    await mPage.waitForSelector('[data-testid="fire-goal-card"]', { timeout: 30000 });
    await mPage.waitForTimeout(800);

    // Scroll smoothly to Goals section so GoalCards + BottomNav ("FIRE" active in #14342a) appear together
    await mPage
      .locator('h2:has-text("เป้าหมายทางการเงินของคุณ")')
      .scrollIntoViewIfNeeded();
    await mPage.waitForTimeout(500);

    // Verify "FIRE" tab is active in BottomNav
    const fireTabState = await mPage.evaluate(() => {
      const link = document.querySelector(
        '[data-testid="mobile-bottom-nav"] a[href="/fire"]'
      );
      if (!link) return null;
      return {
        ariaCurrent: link.getAttribute('aria-current'),
        color: getComputedStyle(link).color,
      };
    });
    console.log('[Mobile FIRE Tab Audit]:', JSON.stringify(fireTabState));
    if (!fireTabState || fireTabState.ariaCurrent !== 'page') {
      throw new Error('Mobile BottomNav FIRE tab is not marked active!');
    }

    // 3) Screenshot: 15-fire-goals-bottom-nav-mobile.png
    const mobileGoalsBuf = await mPage.screenshot({ fullPage: false });
    saveScreenshot('15-fire-goals-bottom-nav-mobile.png', mobileGoalsBuf);

    await mobileCtx.close();

    if (pageErrors.length > 0) {
      throw new Error(`Runtime page errors detected: ${pageErrors.join(' | ')}`);
    }

    console.log('ALL PHASE 9 FIRE PLANNER E2E & VISUAL CHECKS PASSED!');
  } finally {
    await browser.close();
  }
}

runFireVerification().catch((err) => {
  console.error('FIRE Verification failed:', err);
  process.exit(1);
});
