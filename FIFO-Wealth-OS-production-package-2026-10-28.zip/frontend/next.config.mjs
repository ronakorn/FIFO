import createNextIntlPlugin from 'next-intl/plugin';

const withNextIntl = createNextIntlPlugin('./src/i18n.ts');

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  allowedDevOrigins: ['*.e2b.app', 'localhost:3001', '127.0.0.1:3001'],
  async rewrites() {
    const backendOrigin = process.env.BACKEND_ORIGIN || 'http://127.0.0.1:3000';
    return [
      {
        source: '/api/:path*',
        destination: `${backendOrigin}/api/:path*`,
      },
      {
        source: '/api-docs/:path*',
        destination: `${backendOrigin}/api-docs/:path*`,
      },
    ];
  },
};

export default withNextIntl(nextConfig);
