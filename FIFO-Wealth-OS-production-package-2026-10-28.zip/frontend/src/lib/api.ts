import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import { TOKEN_STORAGE_KEY } from './authStorage';
import { useAuthStore } from './stores';

export { TOKEN_STORAGE_KEY, USER_STORAGE_KEY } from './authStorage';

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_BASE_URL || '/api',
  timeout: 30000,
});

// Attach JWT Bearer token from localStorage on every outgoing request (Iron Rule #7)
api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  if (typeof window !== 'undefined') {
    const token = window.localStorage.getItem(TOKEN_STORAGE_KEY);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    const requestHadAuthToken = Boolean(
      error.config?.headers?.Authorization
    );
    if (
      error.response?.status === 401 &&
      requestHadAuthToken &&
      typeof window !== 'undefined'
    ) {
      // Keep Zustand and localStorage in sync when a protected request rejects an expired token.
      useAuthStore.getState().logout();
    }
    return Promise.reject(error);
  }
);

export default api;
