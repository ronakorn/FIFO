'use client';

import React, { FormEvent, useEffect, useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useLocale, useTranslations } from 'next-intl';
import {
  ArrowDownRight,
  ArrowRightLeft,
  Banknote,
  CalendarDays,
  ChartNoAxesCombined,
  CircleDollarSign,
  Clock,
  Coins,
  Layers,
  Landmark,
  Loader2,
  LockKeyhole,
  Plus,
  ShieldCheck,
  Sparkles,
  Trash2,
  WalletCards,
  X,
} from 'lucide-react';
import { Link } from '@/navigation';
import { LegalDisclaimer } from '@/components/common/LegalDisclaimer';
import { usePortfolios } from '@/lib/queries';
import { useAuthStore } from '@/lib/stores';
import api from '@/lib/api';
import { extractApiErrorMessage, formatDateShort } from '@/lib/utils';
import type { MultiAssetApiResponse, MultiAssetTransactionDto } from '@/types/multiAsset';
import { BOND_RULES } from '../../../../backend/src/config/multiAssetRules';

const FinDecimal = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

type AssetTab = 'BOND' | 'FUND' | 'COMMODITY' | 'FOREX';
type BondType = 'BUY' | 'SELL' | 'COUPON' | 'INTEREST';
type FundType = 'BUY' | 'SELL' | 'DIVIDEND';
type CommodityType = 'BUY' | 'SELL';
type ForexType = 'BUY' | 'SELL' | 'CONVERT';

type EntryForm = {
  date: string;
  symbol: string;
  bondType: BondType;
  fundAction: FundType;
  commodityAction: CommodityType;
  forexAction: ForexType;
  qty: string;
  price: string;
  currency: string;
  fxRate: string;
  commission: string;
  vat: string;
  couponRate: string;
  paymentFrequency: 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL';
  maturityDate: string;
  faceValue: string;
  accruedInterest: string;
  yieldToMaturity: string;
  issuer: string;
  creditRating: string;
  fundType: 'SSF' | 'RMF' | 'THAI_ESG' | 'GENERAL' | 'GLOBAL_ETF';
  navPerUnit: string;
  managementFee: string;
  taxDeductible: boolean;
  dividendPolicy: 'DRIP' | 'CASH_PAYOUT';
  weight: string;
  weightUnit: 'TROY_OUNCE' | 'GRAM' | 'KILOGRAM' | 'THAI_BAHT';
  purity: string;
  storageFee: string;
  premium: string;
  spotPricePerUnit: string;
  metalCurrency: string;
  fromCurrency: string;
  toCurrency: string;
  amount: string;
  rateToTHB: string;
  convertedAmount: string;
  annualIncomeTHB: string;
};

const INITIAL_FORM: EntryForm = {
  date: new Date().toISOString().slice(0, 10),
  symbol: '',
  bondType: 'BUY',
  fundAction: 'BUY',
  commodityAction: 'BUY',
  forexAction: 'BUY',
  qty: '1',
  price: '1000',
  currency: 'THB',
  fxRate: '1',
  commission: '0',
  vat: '0',
  couponRate: '0.05',
  paymentFrequency: 'SEMI_ANNUAL',
  maturityDate: '',
  faceValue: '1000',
  accruedInterest: '0',
  yieldToMaturity: '',
  issuer: '',
  creditRating: '',
  fundType: 'SSF',
  navPerUnit: '10',
  managementFee: '0',
  taxDeductible: true,
  dividendPolicy: 'CASH_PAYOUT',
  weight: '1',
  weightUnit: 'TROY_OUNCE',
  purity: '99.9',
  storageFee: '0',
  premium: '0',
  spotPricePerUnit: '1000',
  metalCurrency: 'USD',
  fromCurrency: 'USD',
  toCurrency: 'THB',
  amount: '1000',
  rateToTHB: '35',
  convertedAmount: '35000',
  annualIncomeTHB: '',
};

const EMPTY_TRANSACTIONS: MultiAssetTransactionDto[] = [];

const tabs: Array<{ id: AssetTab; titleKey: 'tabBonds' | 'tabFunds' | 'tabMetals' | 'tabForex'; subtitleKey: 'tabBondsSubtitle' | 'tabFundsSubtitle' | 'tabMetalsSubtitle' | 'tabForexSubtitle'; icon: typeof Landmark }> = [
  { id: 'BOND', titleKey: 'tabBonds', subtitleKey: 'tabBondsSubtitle', icon: Landmark },
  { id: 'FUND', titleKey: 'tabFunds', subtitleKey: 'tabFundsSubtitle', icon: ChartNoAxesCombined },
  { id: 'COMMODITY', titleKey: 'tabMetals', subtitleKey: 'tabMetalsSubtitle', icon: Coins },
  { id: 'FOREX', titleKey: 'tabForex', subtitleKey: 'tabForexSubtitle', icon: CircleDollarSign },
];

const inputClass = 'w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-[#14342a] focus:ring-2 focus:ring-[#14342a]/10 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100';
const labelClass = 'mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-300';

function formatMoney(value: string | undefined): string {
  const decimal = new FinDecimal(value ?? '0');
  const fixed = decimal.toFixed(2);
  const [whole, fraction] = fixed.split('.');
  const withSeparators = (whole ?? '0').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `฿${withSeparators}.${fraction ?? '00'}`;
}

function safeDecimal(value: string, fallback = '0'): Decimal {
  try {
    const result = new FinDecimal(value || fallback);
    return result.isFinite() ? result : new FinDecimal(fallback);
  } catch {
    return new FinDecimal(fallback);
  }
}

function TextField({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
  min,
  max,
  step,
  required,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: 'text' | 'number' | 'date';
  placeholder?: string;
  min?: string;
  max?: string;
  step?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className={labelClass}>{label}</span>
      <input
        className={inputClass}
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        min={min}
        max={max}
        step={step}
        required={required}
      />
    </label>
  );
}

function SelectField<T extends string>({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: T;
  onChange: (value: T) => void;
  options: Array<{ value: T; label: string }>;
}) {
  return (
    <label className="block">
      <span className={labelClass}>{label}</span>
      <select className={inputClass} value={value} onChange={(event) => onChange(event.target.value as T)}>
        {options.map((option) => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
    </label>
  );
}

function SummaryCard({
  label,
  value,
  note,
  icon: Icon,
}: {
  label: string;
  value: string;
  note: string;
  icon: typeof Landmark;
}) {
  return (
    <div className="rounded-2xl border border-gray-200/80 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400">{label}</p>
          <p className="mt-2 text-xl font-bold tabular-nums tracking-tight text-gray-900 dark:text-gray-100">{value}</p>
          <p className="mt-1 text-[11px] text-gray-500 dark:text-gray-400">{note}</p>
        </div>
        <span className="rounded-xl bg-[#14342a]/5 p-2.5 text-[#14342a] dark:bg-emerald-400/10 dark:text-emerald-300">
          <Icon className="h-4 w-4" />
        </span>
      </div>
    </div>
  );
}

function LastUpdatedBadge({ timestamp }: { timestamp: string | null | undefined }) {
  const t = useTranslations('multiAsset');
  const locale = useLocale();
  const date = timestamp ? new Date(timestamp) : null;
  const formatted = date && !Number.isNaN(date.getTime())
    ? new Intl.DateTimeFormat(locale === 'th' ? 'th-TH' : 'en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Asia/Bangkok',
      }).format(date)
    : t('noRecords');
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-2.5 py-1 text-[10px] font-medium text-gray-500 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-400">
      <Clock className="h-3 w-3" aria-hidden="true" />
      <span className="font-semibold">{t('lastUpdated')}</span>
      <span className="tabular-nums">{formatted}</span>
    </span>
  );
}

type YtmResult = {
  symbol: string;
  yieldToMaturity: string | null;
  accruedInterestPerBondTHB: string;
  nextCouponDate: string | null;
};

function buildTransactionPayload(tab: AssetTab, form: EntryForm, validation: { missingSymbol: string; invalidQuantity: string; invalidAmount: string; invalidFxRate: string; invalidReceivedAmount: string; sameCurrency: string }) {
  const quantity = safeDecimal(form.qty);
  const fees = safeDecimal(form.commission).plus(safeDecimal(form.vat));
  const transactionDate = form.date;
  const symbol = form.symbol.trim().toUpperCase();
  if (!symbol) throw new Error(validation.missingSymbol);
  if (!quantity.isPositive()) throw new Error(validation.invalidQuantity);

  if (tab === 'BOND') {
    const price = safeDecimal(form.price);
    const gross = quantity.times(price);
    const isCouponIncome = form.bondType === 'COUPON' || form.bondType === 'INTEREST';
    const withholding = isCouponIncome
      ? gross.times(BOND_RULES.withholdingTaxRate.toString())
      : new FinDecimal(0);
    const net = form.bondType === 'BUY'
      ? gross.plus(fees)
      : isCouponIncome
        ? gross.minus(withholding).minus(fees)
        : gross.minus(fees);
    const accrued = safeDecimal(form.accruedInterest);
    return {
      date: transactionDate,
      symbol,
      assetClass: 'BOND' as const,
      type: form.bondType,
      qty: quantity.toNumber(),
      price: price.toFixed(8),
      gross: gross.toFixed(2),
      comm: safeDecimal(form.commission).toFixed(2),
      vat: safeDecimal(form.vat).toFixed(2),
      net: net.toFixed(2),
      originalCurrency: 'THB',
      originalNet: net.toFixed(2),
      fxRate: '1.00000000',
      netTHB: net.toFixed(2),
      exchange: 'OTC',
      bondExtension: {
        couponRate: safeDecimal(form.couponRate).toFixed(8),
        paymentFrequency: form.paymentFrequency,
        maturityDate: form.maturityDate,
        faceValue: safeDecimal(form.faceValue).toFixed(2),
        accruedInterest: accrued.toFixed(2),
        ...(form.yieldToMaturity ? { yieldToMaturity: safeDecimal(form.yieldToMaturity).toFixed(8) } : {}),
        ...(form.issuer ? { issuer: form.issuer.trim() } : {}),
        ...(form.creditRating ? { creditRating: form.creditRating.trim().toUpperCase() } : {}),
      },
    };
  }

  if (tab === 'FUND') {
    const price = safeDecimal(form.price);
    const gross = quantity.times(price);
    const net = form.fundAction === 'SELL' ? gross.minus(fees) : gross.plus(fees);
    const fx = safeDecimal(form.fxRate, '1');
    const taxDeductible = ['SSF', 'RMF', 'THAI_ESG'].includes(form.fundType) && form.taxDeductible;
    return {
      date: transactionDate,
      symbol,
      assetClass: 'FUND' as const,
      type: form.fundAction,
      qty: quantity.toNumber(),
      price: price.toFixed(8),
      gross: gross.toFixed(2),
      comm: safeDecimal(form.commission).toFixed(2),
      vat: safeDecimal(form.vat).toFixed(2),
      net: net.toFixed(2),
      originalCurrency: form.currency.toUpperCase(),
      originalNet: net.toFixed(2),
      fxRate: fx.toFixed(8),
      netTHB: net.times(fx).toFixed(2),
      exchange: 'FUND',
      fundExtension: {
        fundType: form.fundType,
        holdingPeriodDays: 0,
        taxDeductible,
        dividendPolicy: form.dividendPolicy,
        navPerUnit: safeDecimal(form.navPerUnit || form.price).toFixed(8),
        ...(safeDecimal(form.managementFee).isPositive() ? { managementFee: safeDecimal(form.managementFee).toFixed(8) } : {}),
        purchaseDate: form.fundAction === 'BUY' ? transactionDate : undefined,
      },
    };
  }

  if (tab === 'COMMODITY') {
    const spot = safeDecimal(form.spotPricePerUnit);
    const premiumPerUnit = safeDecimal(form.premium);
    const unitWeight = safeDecimal(form.weight);
    const gross = quantity.times(unitWeight).times(spot.plus(premiumPerUnit));
    const baseNet = form.commodityAction === 'BUY' ? gross.plus(fees) : gross.minus(fees);
    const fx = safeDecimal(form.fxRate, '1');
    const storageFeeTHB = safeDecimal(form.storageFee);
    const netTHB = baseNet.times(fx).plus(form.commodityAction === 'BUY' ? storageFeeTHB : storageFeeTHB.negated());
    return {
      date: transactionDate,
      symbol,
      assetClass: 'COMMODITY' as const,
      type: form.commodityAction,
      qty: quantity.toNumber(),
      price: spot.plus(premiumPerUnit).toFixed(8),
      gross: gross.toFixed(2),
      comm: safeDecimal(form.commission).toFixed(2),
      vat: safeDecimal(form.vat).toFixed(2),
      net: baseNet.toFixed(2),
      originalCurrency: form.metalCurrency.toUpperCase(),
      originalNet: baseNet.toFixed(2),
      fxRate: fx.toFixed(8),
      netTHB: netTHB.toFixed(2),
      exchange: 'METAL',
      commodityExtension: {
        weight: unitWeight.toFixed(8),
        weightUnit: form.weightUnit,
        purity: safeDecimal(form.purity || '100').toFixed(4),
        storageFee: storageFeeTHB.toFixed(2),
        premium: premiumPerUnit.toFixed(8),
        spotPricePerUnit: spot.toFixed(8),
      },
    };
  }

  const fromCurrency = form.fromCurrency.toUpperCase();
  const toCurrency = form.toCurrency.toUpperCase();
  const amount = safeDecimal(form.amount);
  if (!amount.isPositive()) throw new Error(validation.invalidAmount);
  const rateToTHB = safeDecimal(form.rateToTHB);
  if (!rateToTHB.isPositive()) throw new Error(validation.invalidFxRate);
  const feeTHB = fees;
  const receivedAmount = form.forexAction === 'CONVERT'
    ? safeDecimal(form.convertedAmount)
    : amount;
  if (!receivedAmount.isPositive()) throw new Error(validation.invalidReceivedAmount);
  if (form.forexAction === 'CONVERT' && fromCurrency === toCurrency) {
    throw new Error(validation.sameCurrency);
  }
  const fxToTHB = form.forexAction === 'SELL'
    ? amount.times(rateToTHB).minus(feeTHB)
    : amount.times(rateToTHB).plus(form.forexAction === 'BUY' ? feeTHB : feeTHB.negated());
  const pairRate = form.forexAction === 'CONVERT'
    ? receivedAmount.dividedBy(amount)
    : rateToTHB;

  return {
    date: transactionDate,
    symbol: form.forexAction === 'CONVERT' ? `${fromCurrency}-${toCurrency}` : `CASH-${fromCurrency}`,
    assetClass: 'FOREX' as const,
    type: form.forexAction,
    qty: amount.toNumber(),
    price: pairRate.toFixed(8),
    gross: form.forexAction === 'CONVERT' ? receivedAmount.toFixed(8) : amount.times(rateToTHB).toFixed(2),
    comm: safeDecimal(form.commission).toFixed(2),
    vat: safeDecimal(form.vat).toFixed(2),
    net: amount.toFixed(8),
    originalCurrency: fromCurrency,
    originalNet: amount.toFixed(8),
    fxRate: rateToTHB.toFixed(8),
    netTHB: fxToTHB.toFixed(2),
    exchange: 'CASH',
    forexExtension: {
      fromCurrency,
      toCurrency: form.forexAction === 'BUY' || form.forexAction === 'SELL' ? 'THB' : toCurrency,
      fxRateAtTransaction: pairRate.toFixed(8),
      realizedFxGainLoss: '0.00',
    },
  };
}

export function MultiAssetWorkspace() {
  const t = useTranslations('multiAsset');
  const token = useAuthStore((state) => state.token);
  const queryClient = useQueryClient();
  const { data: portfolios = [], isLoading: portfoliosLoading } = usePortfolios();
  const [selectedPortfolioId, setSelectedPortfolioId] = useState('');
  const [activeTab, setActiveTab] = useState<AssetTab>('BOND');
  const [form, setForm] = useState<EntryForm>(INITIAL_FORM);
  const [message, setMessage] = useState<string | null>(null);
  const [annualIncomeTHB, setAnnualIncomeTHB] = useState('');
  const [taxYear, setTaxYear] = useState(new Date().getFullYear());
  const [selectedYtmResult, setSelectedYtmResult] = useState<YtmResult | null>(null);

  useEffect(() => {
    if (!selectedPortfolioId && portfolios[0]) setSelectedPortfolioId(portfolios[0].id);
  }, [portfolios, selectedPortfolioId]);

  const summaryQuery = useQuery<MultiAssetApiResponse>({
    queryKey: ['multi-assets', selectedPortfolioId, taxYear, annualIncomeTHB],
    enabled: Boolean(token && selectedPortfolioId),
    queryFn: async () => {
      const { data } = await api.get<MultiAssetApiResponse>(
        `/multi-assets/portfolios/${selectedPortfolioId}`,
        { params: { taxYear, annualIncomeTHB: annualIncomeTHB || undefined } },
      );
      return data;
    },
    staleTime: 15_000,
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      if (!selectedPortfolioId) throw new Error(t('selectPortfolio'));
      const payload = buildTransactionPayload(activeTab, form, {
        missingSymbol: t('missingSymbol'),
        invalidQuantity: t('invalidQuantity'),
        invalidAmount: t('invalidAmount'),
        invalidFxRate: t('invalidFxRate'),
        invalidReceivedAmount: t('invalidReceivedAmount'),
        sameCurrency: t('sameCurrency'),
      });
      const { data } = await api.post(
        `/multi-assets/portfolios/${selectedPortfolioId}/transactions`,
        payload,
      );
      return data;
    },
    onSuccess: () => {
      setMessage(t('saveSuccess'));
      queryClient.invalidateQueries({ queryKey: ['multi-assets', selectedPortfolioId] });
      queryClient.invalidateQueries({ queryKey: ['portfolios'] });
    },
    onError: (error) => setMessage(extractApiErrorMessage(error, t('apiErrorFallback'))),
  });

  const deleteMutation = useMutation({
    mutationFn: async (transactionId: string) => {
      await api.delete(`/multi-assets/portfolios/${selectedPortfolioId}/transactions/${transactionId}`);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['multi-assets', selectedPortfolioId] }),
    onError: (error) => setMessage(extractApiErrorMessage(error, t('apiErrorFallback'))),
  });

  const data = summaryQuery.data;
  const transactions = data?.transactions ?? EMPTY_TRANSACTIONS;
  const summary = data?.summary;
  const sortedTransactions = useMemo(
    () => [...transactions].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)),
    [transactions],
  );

  const bondValue = summary?.bonds.totalMarketValueTHB ?? '0.00';
  const fundValue = summary?.funds.totalMarketValueTHB ?? '0.00';
  const commodityValue = summary?.commodities.totalMarketValueTHB ?? '0.00';
  const forexValue = summary?.forex.totalCashValueTHB ?? '0.00';

  const setFormField = <K extends keyof EntryForm>(key: K, value: EntryForm[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
    setMessage(null);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessage(null);
    createMutation.mutate();
  };

  if (!token) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-8 text-center dark:border-emerald-900/50 dark:bg-emerald-950/25">
        <LockKeyhole className="mx-auto h-10 w-10 text-[#14342a] dark:text-emerald-300" />
        <h2 className="mt-4 text-lg font-bold text-gray-900 dark:text-gray-100">{t('workspaceTitle')}</h2>
        <p className="mx-auto mt-2 max-w-lg text-sm leading-relaxed text-gray-600 dark:text-gray-300">
          {t('loginRequired')}
        </p>
        <Link href="/login" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#0f261e]">
          {t('loginToStart')} <ArrowRightLeft className="h-4 w-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-2xl border border-gray-200/90 bg-white shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <div className="bg-gradient-to-br from-[#14342a] via-[#1b4538] to-[#14342a] px-6 py-6 text-white sm:px-8 sm:py-8">
          <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-[11px] font-semibold text-emerald-100">
                <Layers className="h-3.5 w-3.5" /> {t('headerBadge')}
              </span>
              <h1 className="mt-3 text-2xl font-bold tracking-tight sm:text-3xl">{t('foundationTitle')}</h1>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-emerald-50/85">
                {t('foundationDescription')}
              </p>
            </div>
            <div className="flex w-full flex-col gap-2 sm:flex-row lg:w-auto">
              <label className="min-w-[240px]">
                <span className="mb-1 block text-[11px] font-semibold text-emerald-50/80">{t('portfolioLabel')}</span>
                <select
                  className="w-full rounded-xl border border-white/20 bg-white/10 px-3 py-2.5 text-sm font-semibold text-white outline-none focus:ring-2 focus:ring-white/50 [&>option]:text-gray-900"
                  value={selectedPortfolioId}
                  onChange={(event) => setSelectedPortfolioId(event.target.value)}
                  disabled={portfoliosLoading || portfolios.length === 0}
                >
                  {portfolios.length === 0 ? <option value="">{t('noPortfolio')}</option> : null}
                  {portfolios.map((portfolio) => <option key={portfolio.id} value={portfolio.id}>{portfolio.name}</option>)}
                </select>
              </label>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 sm:p-5 xl:grid-cols-4">
          <SummaryCard label={t('bondsMarketValue')} value={formatMoney(bondValue)} note={t('realizedGLNote', { amount: formatMoney(summary?.bonds.totalRealizedGLTHB) })} icon={Landmark} />
          <SummaryCard label={t('fundsAndETFs')} value={formatMoney(fundValue)} note={t('taxDeductionEstimate', { amount: formatMoney(summary?.funds.taxDeduction.totalEligibleDeductionTHB) })} icon={ChartNoAxesCombined} />
          <SummaryCard label={t('metalsMarketValue')} value={formatMoney(commodityValue)} note={t('totalWeight', { weight: summary?.commodities.totalWeightGrams ?? '0.00000000' })} icon={Coins} />
          <SummaryCard label={t('multiCurrencyCash')} value={formatMoney(forexValue)} note={t('realizedFxNote', { amount: formatMoney(summary?.forex.totalRealizedFxGainLossTHB) })} icon={WalletCards} />
        </div>
      </section>

      {!selectedPortfolioId && !portfoliosLoading && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-950 dark:border-amber-900/50 dark:bg-amber-950/20 dark:text-amber-200">
          {t('noPortfolioForTransactions')} <Link href="/portfolios" className="font-bold underline underline-offset-2">{t('createPortfolio')}</Link> {t('beforeStarting')}
        </div>
      )}

      {selectedPortfolioId && (
        <section className="rounded-2xl border border-gray-200/90 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] sm:p-6">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
            <div>
              <p className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#14342a] dark:text-emerald-300">
                <Sparkles className="h-3.5 w-3.5" /> {t('phaseOne')}
              </p>
              <h2 className="mt-1 text-lg font-bold text-gray-900 dark:text-gray-100">{t('addTransaction')}</h2>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{t('decimalPrecision')}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => { setActiveTab(tab.id); setMessage(null); }}
                    className={`inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-left transition ${isActive ? 'border-[#14342a] bg-[#14342a] text-white shadow-sm' : 'border-gray-200 bg-white text-gray-600 hover:border-[#14342a]/40 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-300'}`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span><span className="block text-xs font-bold">{t(tab.titleKey)}</span><span className={`block text-[10px] ${isActive ? 'text-emerald-100' : 'text-gray-400'}`}>{t(tab.subtitleKey)}</span></span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(320px,0.9fr)]">
            <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl border border-gray-100 bg-gray-50/70 p-4 dark:border-gray-800 dark:bg-[#16191D] sm:p-5">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <TextField label={t('transactionDate')} type="date" value={form.date} onChange={(value) => setFormField('date', value)} required />
                <TextField label={t('symbol')} value={form.symbol} onChange={(value) => setFormField('symbol', value)} placeholder={activeTab === 'BOND' ? 'BOND-TH-2028' : activeTab === 'FUND' ? 'SSF-TH-001' : activeTab === 'COMMODITY' ? 'SILVER-999' : 'CASH-USD'} required />
                {activeTab === 'BOND' && (
                  <SelectField label={t('action')} value={form.bondType} onChange={(value) => setFormField('bondType', value)} options={[{ value: 'BUY', label: t('buyAction') }, { value: 'SELL', label: t('sellAction') }, { value: 'COUPON', label: t('couponAction') }, { value: 'INTEREST', label: t('interestAction') }]} />
                )}
                {activeTab === 'FUND' && (
                  <SelectField label={t('action')} value={form.fundAction} onChange={(value) => setFormField('fundAction', value)} options={[{ value: 'BUY', label: t('buyAction') }, { value: 'SELL', label: t('sellAction') }, { value: 'DIVIDEND', label: t('dividendAction') }]} />
                )}
                {activeTab === 'COMMODITY' && (
                  <SelectField label={t('action')} value={form.commodityAction} onChange={(value) => setFormField('commodityAction', value)} options={[{ value: 'BUY', label: t('buyAction') }, { value: 'SELL', label: t('sellAction') }]} />
                )}
                {activeTab === 'FOREX' && (
                  <SelectField label={t('cashMovement')} value={form.forexAction} onChange={(value) => setFormField('forexAction', value)} options={[{ value: 'BUY', label: t('buyCashAction') }, { value: 'SELL', label: t('sellCashAction') }, { value: 'CONVERT', label: t('convertAction') }]} />
                )}
              </div>

              {activeTab === 'BOND' && (
                <>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={t('quantity')} type="number" min="0.00000001" step="0.00000001" value={form.qty} onChange={(value) => setFormField('qty', value)} required />
                    <TextField label={form.bondType === 'COUPON' ? t('couponIncomeUnit') : form.bondType === 'INTEREST' ? t('interestIncomeUnit') : t('cleanPriceUnit')} type="number" min="0" step="0.00000001" value={form.price} onChange={(value) => setFormField('price', value)} required />
                    <TextField label={t('faceValueUnit')} type="number" min="0.01" step="0.01" value={form.faceValue} onChange={(value) => setFormField('faceValue', value)} required />
                    <TextField label={t('accruedInterestUnit')} type="number" min="0" step="0.01" value={form.accruedInterest} onChange={(value) => setFormField('accruedInterest', value)} />
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={t('couponRate')} type="number" min="0" step="0.0001" value={form.couponRate} onChange={(value) => setFormField('couponRate', value)} required />
                    <SelectField label={t('couponFrequency')} value={form.paymentFrequency} onChange={(value) => setFormField('paymentFrequency', value)} options={[{ value: 'MONTHLY', label: t('monthly') }, { value: 'QUARTERLY', label: t('quarterly') }, { value: 'SEMI_ANNUAL', label: t('semiAnnual') }, { value: 'ANNUAL', label: t('annual') }]} />
                    <TextField label={t('maturityDate')} type="date" value={form.maturityDate} onChange={(value) => setFormField('maturityDate', value)} required />
                    <TextField label={t('optionalYtm')} type="number" min="0" step="0.0001" value={form.yieldToMaturity} onChange={(value) => setFormField('yieldToMaturity', value)} placeholder={t('calculateAutomatically')} />
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={t('issuer')} value={form.issuer} onChange={(value) => setFormField('issuer', value)} placeholder={t('issuerPlaceholder')} />
                    <TextField label={t('creditRating')} value={form.creditRating} onChange={(value) => setFormField('creditRating', value)} placeholder={t('creditRatingPlaceholder')} />
                    <TextField label={t('commission')} type="number" min="0" step="0.01" value={form.commission} onChange={(value) => setFormField('commission', value)} />
                    <TextField label={t('vat')} type="number" min="0" step="0.01" value={form.vat} onChange={(value) => setFormField('vat', value)} />
                  </div>
                </>
              )}

              {activeTab === 'FUND' && (
                <>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={form.fundAction === 'DIVIDEND' ? t('fundUnitsReceived') : t('fundUnits')} type="number" min="0.00000001" step="0.00000001" value={form.qty} onChange={(value) => setFormField('qty', value)} required />
                    <TextField label={form.fundAction === 'DIVIDEND' ? t('dividendPerUnit') : t('navPerUnit')} type="number" min="0" step="0.00000001" value={form.price} onChange={(value) => setFormField('price', value)} required />
                    <TextField label={t('currentNav')} type="number" min="0.00000001" step="0.00000001" value={form.navPerUnit} onChange={(value) => setFormField('navPerUnit', value)} required />
                    <SelectField label={t('fundType')} value={form.fundType} onChange={(value) => {
                      setFormField('fundType', value);
                      setFormField('taxDeductible', ['SSF', 'RMF', 'THAI_ESG'].includes(value));
                    }} options={[{ value: 'SSF', label: 'SSF' }, { value: 'RMF', label: 'RMF' }, { value: 'THAI_ESG', label: t('thaiESG') }, { value: 'GENERAL', label: t('generalFund') }, { value: 'GLOBAL_ETF', label: t('globalETF') }]} />
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <SelectField label={t('dividendPolicy')} value={form.dividendPolicy} onChange={(value) => setFormField('dividendPolicy', value)} options={[{ value: 'CASH_PAYOUT', label: t('cashPayout') }, { value: 'DRIP', label: t('dripReinvest') }]} />
                    <TextField label={t('managementFee')} type="number" min="0" step="0.0001" value={form.managementFee} onChange={(value) => setFormField('managementFee', value)} />
                    <TextField label={t('commission')} type="number" min="0" step="0.01" value={form.commission} onChange={(value) => setFormField('commission', value)} />
                    <TextField label={t('vat')} type="number" min="0" step="0.01" value={form.vat} onChange={(value) => setFormField('vat', value)} />
                  </div>
                  <div className="flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3 py-2.5 text-xs text-emerald-950 dark:border-emerald-800/50 dark:bg-emerald-950/25 dark:text-emerald-200">
                    <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>{t('fundTaxCaveat')}</span>
                  </div>
                </>
              )}

              {activeTab === 'COMMODITY' && (
                <>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={t('unitCount')} type="number" min="0.00000001" step="0.00000001" value={form.qty} onChange={(value) => setFormField('qty', value)} required />
                    <TextField label={t('weightPerUnit')} type="number" min="0.00000001" step="0.00000001" value={form.weight} onChange={(value) => setFormField('weight', value)} required />
                    <SelectField label={t('weightUnit')} value={form.weightUnit} onChange={(value) => setFormField('weightUnit', value)} options={[{ value: 'TROY_OUNCE', label: t('troyOunce') }, { value: 'GRAM', label: t('gram') }, { value: 'KILOGRAM', label: t('kilogram') }, { value: 'THAI_BAHT', label: t('thaiBahtWeight') }]} />
                    <TextField label={t('purity')} type="number" min="0.01" max="100" step="0.01" value={form.purity} onChange={(value) => setFormField('purity', value)} />
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={t('spotPricePerUnit')} type="number" min="0.00000001" step="0.00000001" value={form.spotPricePerUnit} onChange={(value) => setFormField('spotPricePerUnit', value)} required />
                    <TextField label={t('premiumPerUnit')} type="number" min="0" step="0.00000001" value={form.premium} onChange={(value) => setFormField('premium', value)} />
                    <TextField label={t('storageFee')} type="number" min="0" step="0.01" value={form.storageFee} onChange={(value) => setFormField('storageFee', value)} />
                    <SelectField label={t('quoteCurrency')} value={form.metalCurrency} onChange={(value) => setFormField('metalCurrency', value)} options={[{ value: 'USD', label: 'USD' }, { value: 'THB', label: 'THB' }, { value: 'EUR', label: 'EUR' }]} />
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={t('fxToTHB')} type="number" min="0.00000001" step="0.00000001" value={form.fxRate} onChange={(value) => setFormField('fxRate', value)} />
                    <TextField label={t('commission')} type="number" min="0" step="0.01" value={form.commission} onChange={(value) => setFormField('commission', value)} />
                    <TextField label={t('vat')} type="number" min="0" step="0.01" value={form.vat} onChange={(value) => setFormField('vat', value)} />
                    <div className="flex items-end text-[11px] text-gray-500 dark:text-gray-400">{t('normalizeWeight')}</div>
                  </div>
                </>
              )}

              {activeTab === 'FOREX' && (
                <>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={t('sourceAmount')} type="number" min="0.00000001" step="0.00000001" value={form.amount} onChange={(value) => setFormField('amount', value)} required />
                    <SelectField label={t('fromCurrency')} value={form.fromCurrency} onChange={(value) => setFormField('fromCurrency', value)} options={[{ value: 'USD', label: 'USD' }, { value: 'EUR', label: 'EUR' }, { value: 'JPY', label: 'JPY' }, { value: 'GBP', label: 'GBP' }, { value: 'THB', label: 'THB' }]} />
                    {form.forexAction === 'CONVERT' && <SelectField label={t('toCurrency')} value={form.toCurrency} onChange={(value) => setFormField('toCurrency', value)} options={[{ value: 'THB', label: 'THB' }, { value: 'USD', label: 'USD' }, { value: 'EUR', label: 'EUR' }, { value: 'JPY', label: 'JPY' }, { value: 'GBP', label: 'GBP' }]} />}
                    <TextField label={t('fxRateToTHB')} type="number" min="0.00000001" step="0.00000001" value={form.rateToTHB} onChange={(value) => setFormField('rateToTHB', value)} required />
                  </div>
                  {form.forexAction === 'CONVERT' && (
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                      <TextField label={t('receivedAmount')} type="number" min="0.00000001" step="0.00000001" value={form.convertedAmount} onChange={(value) => setFormField('convertedAmount', value)} required />
                      <div className="flex items-end text-xs font-medium text-gray-600 dark:text-gray-300">{t('effectivePairRate', { rate: safeDecimal(form.convertedAmount).dividedBy(safeDecimal(form.amount, '1')).toFixed(8), to: form.toCurrency, from: form.fromCurrency })}</div>
                      <div className="flex items-end text-[11px] leading-relaxed text-gray-500 dark:text-gray-400">{t('convertExplanation')}</div>
                    </div>
                  )}
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <TextField label={`${t('commission')} (THB)`} type="number" min="0" step="0.01" value={form.commission} onChange={(value) => setFormField('commission', value)} />
                    <TextField label={`${t('vat')} (THB)`} type="number" min="0" step="0.01" value={form.vat} onChange={(value) => setFormField('vat', value)} />
                    <div className="flex items-end text-[11px] leading-relaxed text-gray-500 dark:text-gray-400">{t('buySellExplanation')}</div>
                  </div>
                </>
              )}

              {activeTab === 'FUND' && (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <TextField label={t('fundCurrency')} value={form.currency} onChange={(value) => setFormField('currency', value.toUpperCase())} placeholder="THB" />
                  <TextField label={t('fxToTHB')} type="number" min="0.00000001" step="0.00000001" value={form.fxRate} onChange={(value) => setFormField('fxRate', value)} />
                  <div className="flex items-end text-[11px] text-gray-500 dark:text-gray-400">{t('navFeeCurrency')}</div>
                </div>
              )}

              <div className="flex flex-col justify-between gap-3 border-t border-gray-200 pt-4 dark:border-gray-800 sm:flex-row sm:items-center">
                <p className="text-[11px] leading-relaxed text-gray-500 dark:text-gray-400">
                  {t('ledgerNote')}
                </p>
                <button
                  type="submit"
                  disabled={!selectedPortfolioId || createMutation.isPending}
                  className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                  {t('saveTransaction')}
                </button>
              </div>
              {message && (
                <div className={`rounded-xl border px-3.5 py-2.5 text-xs font-medium ${createMutation.isError || deleteMutation.isError ? 'border-red-200 bg-red-50 text-red-700 dark:border-red-900/50 dark:bg-red-950/25 dark:text-red-300' : 'border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-800/50 dark:bg-emerald-950/25 dark:text-emerald-200'}`}>
                  {message}
                </div>
              )}
            </form>

            <div className="space-y-4">
              {summaryQuery.isLoading ? (
                <div className="flex min-h-52 items-center justify-center rounded-2xl border border-gray-100 bg-gray-50 dark:border-gray-800 dark:bg-[#16191D]">
                  <span className="sr-only">{t('loadingSummary')}</span><Loader2 className="h-6 w-6 animate-spin text-[#14342a] dark:text-emerald-300" />
                </div>
              ) : summaryQuery.isError ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/25 dark:text-red-300">
                  {extractApiErrorMessage(summaryQuery.error, t('apiErrorFallback'))}
                </div>
              ) : (
                <>
                  {activeTab === 'BOND' && (
                    <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4 dark:border-gray-800 dark:bg-[#16191D]">
                      <div className="flex items-center justify-between gap-3">
                        <h3 className="inline-flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-gray-100"><CalendarDays className="h-4 w-4 text-[#14342a] dark:text-emerald-300" /> {t('couponSchedule')}</h3>
                        <div className="flex flex-wrap items-center justify-end gap-2"><LastUpdatedBadge timestamp={data?.lastUpdatedAt.bonds} /><span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">{t('whtConfig')}</span></div>
                      </div>
                      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                        <div className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><p className="text-[10px] text-gray-500">{t('accruedInterest')}</p><p className="mt-1 text-xs font-bold tabular-nums text-gray-900 dark:text-gray-100">{formatMoney(summary?.bonds.totalAccruedInterestTHB)}</p></div>
                        <div className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><p className="text-[10px] text-gray-500">{t('couponIncome')}</p><p className="mt-1 text-xs font-bold tabular-nums text-gray-900 dark:text-gray-100">{formatMoney(summary?.bonds.couponIncomeTHB)}</p></div>
                        <div className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><p className="text-[10px] text-gray-500">{t('realizedGL')}</p><p className="mt-1 text-xs font-bold tabular-nums text-gray-900 dark:text-gray-100">{formatMoney(summary?.bonds.totalRealizedGLTHB)}</p></div>
                        <div className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><p className="text-[10px] text-gray-500">{t('couponWht')}</p><p className="mt-1 text-xs font-bold tabular-nums text-gray-900 dark:text-gray-100">{formatMoney(summary?.bonds.couponWithholdingTaxTHB)}</p></div>
                      </div>
                      <div className="mt-3 space-y-2">
                        {(summary?.bonds.positions ?? []).map((position) => (
                          <div key={position.symbol} className="rounded-xl border border-emerald-100 bg-emerald-50/50 p-3 dark:border-emerald-900/40 dark:bg-emerald-950/15">
                            <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-xs font-bold text-gray-900 dark:text-gray-100">{position.symbol} · {t('positionUnits', { count: position.quantity })}</span><button type="button" disabled={!position.yieldToMaturity} onClick={() => setSelectedYtmResult({ symbol: position.symbol, yieldToMaturity: position.yieldToMaturity, accruedInterestPerBondTHB: position.accruedInterestPerBondTHB, nextCouponDate: position.nextCouponDate })} className="rounded-full px-2 py-1 text-[11px] font-semibold text-gray-600 transition hover:bg-white hover:text-[#14342a] disabled:cursor-default disabled:opacity-60 dark:text-gray-300 dark:hover:bg-[#121212] dark:hover:text-emerald-300" aria-label={t('viewYtmDetails', { symbol: position.symbol })}>{position.yieldToMaturity ? t('ytmDetails', { value: `${safeDecimal(position.yieldToMaturity).times(100).toFixed(3)}%` }) : 'YTM —'}</button></div>
                            <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-gray-500"><span>{t('accrued', { amount: formatMoney(position.accruedInterestTotalTHB) })}</span><span>{t('realized', { amount: formatMoney(position.realizedGLTHB) })}</span><span>{t('unrealized', { amount: formatMoney(position.unrealizedGLTHB) })}</span><span>{t('nextCoupon', { date: position.nextCouponDate ?? '—' })}</span></div>
                          </div>
                        ))}

                        {(summary?.bonds.upcomingCoupons ?? []).length === 0 ? <p className="py-5 text-center text-xs text-gray-500">{t('addBondForSchedule')}</p> : summary?.bonds.upcomingCoupons.slice(0, 5).map((coupon) => (
                          <div key={`${coupon.symbol}-${coupon.date}`} className="flex items-center justify-between gap-3 rounded-xl border border-gray-100 bg-white px-3 py-2 dark:border-gray-800 dark:bg-[#121212]">
                            <div><p className="text-xs font-bold text-gray-900 dark:text-gray-100">{coupon.symbol}</p><p className="text-[11px] text-gray-500">{coupon.date}</p></div>
                            <div className="text-right"><p className="text-xs font-semibold tabular-nums text-gray-900 dark:text-gray-100">{t('netAmount', { amount: formatMoney(coupon.netTHB) })}</p><p className="text-[10px] text-gray-500">{t('grossWht', { gross: formatMoney(coupon.grossTHB), withholding: formatMoney(coupon.withholdingTaxTHB) })}</p></div>
                          </div>
                        ))}
                      </div>
                      <p className="mt-3 text-[10px] leading-relaxed text-gray-500">{t('bondAccrualCaveat')}</p>
                    </div>
                  )}

                  {activeTab === 'FUND' && (
                    <div className="space-y-3 rounded-2xl border border-gray-100 bg-gray-50/70 p-4 dark:border-gray-800 dark:bg-[#16191D]">
                      <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('taxDeductionSummary')}</h3><div className="flex flex-wrap items-center gap-2"><LastUpdatedBadge timestamp={data?.lastUpdatedAt.funds} /><label className="text-[10px] font-semibold text-gray-500">{t('taxYear')} <input className="ml-1 w-16 rounded-lg border border-gray-200 bg-white px-2 py-1 text-xs dark:border-gray-700 dark:bg-[#121212]" type="number" value={taxYear} onChange={(event) => setTaxYear(Number(event.target.value))} /></label></div></div>
                      <TextField label={t('annualIncome')} type="number" min="0" step="0.01" value={annualIncomeTHB} onChange={setAnnualIncomeTHB} placeholder="THB" />
                      {summary?.funds.rmfAgeCondition ? (
                        <div className={`flex flex-wrap items-center justify-between gap-2 rounded-xl border px-3 py-2.5 ${summary.funds.rmfAgeCondition.isEligible ? 'border-emerald-200 bg-emerald-50/70 dark:border-emerald-800/50 dark:bg-emerald-950/20' : 'border-red-200 bg-red-50/70 dark:border-red-900/50 dark:bg-red-950/20'}`}>
                          <div>
                            <p className={`text-xs font-bold ${summary.funds.rmfAgeCondition.isEligible ? 'text-emerald-800 dark:text-emerald-200' : 'text-red-800 dark:text-red-200'}`}>
                              {t('rmfAgeCheck', { status: summary.funds.rmfAgeCondition.isEligible ? t('pass') : t('notYetEligible') })}
                            </p>
                            <p className="mt-0.5 text-[10px] text-gray-600 dark:text-gray-400">
                              {t('ageAsOf', { age: summary.funds.rmfAgeCondition.ageAtAsOf, date: summary.asOfDate, status: summary.funds.rmfAgeCondition.isEligible ? t('reached55') : t('turns55'), year: summary.funds.rmfAgeCondition.ageEligibleDate.slice(0, 4) })}
                            </p>
                          </div>
                          <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${summary.funds.rmfAgeCondition.isEligible ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200' : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200'}`}>
                            {summary.funds.rmfAgeCondition.isEligible ? t('eligible') : t('notEligible')}
                          </span>
                        </div>
                      ) : (
                        <div className="rounded-xl border border-gray-200 bg-gray-50 px-3 py-2.5 text-[11px] text-gray-500 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-400">
                          {t('addDob')} <Link href="/profile" className="font-semibold text-[#14342a] underline underline-offset-2 dark:text-emerald-300">{t('profile')}</Link>
                        </div>
                      )}
                      <div className="grid grid-cols-3 gap-2">
                        {(['SSF', 'RMF', 'THAI_ESG'] as const).map((type) => (
                          <div key={type} className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]">
                            <p className="text-[10px] font-bold text-gray-500">{type}</p>
                            <p className="mt-1 text-xs font-bold tabular-nums text-gray-900 dark:text-gray-100">{formatMoney(summary?.funds.taxDeduction.eligibleDeductionTHB[type])}</p>
                            <p className="mt-1 text-[10px] text-gray-500">{t('limit', { amount: formatMoney(summary?.funds.taxDeduction.appliedLimitsTHB[type]) })}</p>
                          </div>
                        ))}
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><p className="text-[10px] text-gray-500">{t('cashDividends')}</p><p className="mt-1 text-xs font-bold tabular-nums text-gray-900 dark:text-gray-100">{formatMoney(summary?.funds.cashDividendsTHB)}</p></div>
                        <div className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><p className="text-[10px] text-gray-500">{t('dripUnits')}</p><p className="mt-1 text-xs font-bold tabular-nums text-gray-900 dark:text-gray-100">{summary?.funds.dripReinvestedUnits ?? '0.00000000'}</p></div>
                      </div>
                      <p className="text-[10px] leading-relaxed text-gray-500">{summary?.funds.taxDeduction.note}</p>
                      <div className="max-h-44 space-y-2 overflow-auto">
                        {(summary?.funds.holdingLots ?? []).map((lot) => (
                          <div key={lot.transactionId} className="flex items-center justify-between gap-2 rounded-xl border border-gray-100 bg-white px-3 py-2 text-xs dark:border-gray-800 dark:bg-[#121212]">
                            <span className="font-semibold text-gray-800 dark:text-gray-200">{lot.symbol} · {lot.fundType}</span>
                            <div className="flex flex-wrap items-center justify-end gap-1.5">
                              <span className={lot.holdingPeriodComplete ? 'text-emerald-700 dark:text-emerald-300' : 'text-amber-700 dark:text-amber-300'}>{t('holdingDays', { actual: lot.holdingPeriodDays, required: lot.requiredHoldingPeriodDays })}</span>
                              {lot.fundType === 'RMF' && lot.ageConditionMet !== null && (
                                <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${lot.ageConditionMet ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200' : 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200'}`}>
                                  {lot.ageConditionMet ? t('age55Pass') : t('notYetAge', { age: lot.ageAtAsOf ?? '', year: lot.ageEligibleDate?.slice(0, 4) ?? '' })}
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                      {(summary?.funds.redemptionChecks ?? []).length > 0 && (
                        <div className="mt-3 space-y-2">
                          <p className="text-[10px] font-bold uppercase tracking-wide text-gray-500">{t('redemptionChecks')}</p>
                          {(summary?.funds.redemptionChecks ?? []).map((check) => (
                            <div key={`${check.transactionId}-${check.purchaseDate}`} className={`flex flex-wrap items-center justify-between gap-2 rounded-xl border px-3 py-2 text-[11px] ${check.holdingPeriodMet ? 'border-emerald-200 bg-emerald-50/70 text-emerald-900 dark:border-emerald-800/50 dark:bg-emerald-950/20 dark:text-emerald-200' : 'border-amber-200 bg-amber-50/70 text-amber-900 dark:border-amber-800/50 dark:bg-amber-950/20 dark:text-amber-200'}`}>
                              <span>{check.symbol} · {check.fundType}: {check.actualHoldingDays}/{check.requiredHoldingDays} {t('days')} — {check.holdingPeriodMet ? t('periodComplete') : t('earlyRedemption')}</span>
                              {check.fundType === 'RMF' && (
                                <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold ${check.ageConditionMet === true ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200' : check.ageConditionMet === false ? 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300'}`}>
                                  {check.ageConditionMet === true ? t('age55Sale', { age: check.ageAtSale ?? '' }) : check.ageConditionMet === false ? t('notYetSale', { age: check.ageAtSale ?? '', year: check.ageEligibleDate?.slice(0, 4) ?? '' }) : t('addDobShort')}
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {activeTab === 'COMMODITY' && (
                    <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4 dark:border-gray-800 dark:bg-[#16191D]">
                      <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="inline-flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-gray-100"><Coins className="h-4 w-4 text-[#14342a] dark:text-emerald-300" /> {t('multiMetalDashboard')}</h3><div className="flex flex-wrap items-center gap-2"><LastUpdatedBadge timestamp={data?.lastUpdatedAt.metals} /><span className="text-[10px] text-gray-500">{t('normalizedGrams')}</span></div></div>
                      <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                        {(['GOLD', 'SILVER', 'PLATINUM'] as const).map((metal) => {
                          const row = summary?.commodities.multiMetalDashboard.find((item) => item.metal === metal);
                          return <div key={metal} className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><p className="text-xs font-bold text-gray-500">{metal}</p><p className="mt-1 text-sm font-bold text-gray-900 dark:text-gray-100">{row?.weightGrams ?? '0.00000000'} g</p><p className="text-[11px] text-gray-500">{t('valueGl', { value: formatMoney(row?.marketValueTHB), gl: formatMoney(row?.unrealizedGLTHB) })}</p></div>;
                        })}
                      </div>
                      <div className="mt-3 space-y-2">{(summary?.commodities.positions ?? []).map((position) => <div key={position.symbol} className="flex items-center justify-between rounded-xl border border-gray-100 bg-white px-3 py-2 text-xs dark:border-gray-800 dark:bg-[#121212]"><span className="font-semibold text-gray-800 dark:text-gray-200">{position.symbol} · {position.purity ?? '—'}% {t('purityLabel')}</span><span className="tabular-nums text-gray-600 dark:text-gray-300">{position.weightGrams} g · {formatMoney(position.marketValueTHB)}</span></div>)}</div>
                      <p className="mt-3 text-[10px] leading-relaxed text-gray-500">{t('weightConversionCaveat')}</p>
                    </div>
                  )}

                  {activeTab === 'FOREX' && (
                    <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4 dark:border-gray-800 dark:bg-[#16191D]">
                      <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="inline-flex items-center gap-2 text-sm font-bold text-gray-900 dark:text-gray-100"><Banknote className="h-4 w-4 text-[#14342a] dark:text-emerald-300" /> {t('multiCurrencyBalances')}</h3><div className="flex flex-wrap items-center gap-2"><LastUpdatedBadge timestamp={data?.lastUpdatedAt.forex} /><span className="text-[10px] text-gray-500">{t('fifoCostBasis')}</span></div></div>
                      <div className="mt-3 space-y-2">{(summary?.forex.balances ?? []).length === 0 ? <p className="py-5 text-center text-xs text-gray-500">{t('addCashToStart')}</p> : summary?.forex.balances.map((balance) => <div key={balance.currency} className="rounded-xl border border-gray-100 bg-white p-3 dark:border-gray-800 dark:bg-[#121212]"><div className="flex items-center justify-between"><span className="text-sm font-bold text-gray-900 dark:text-gray-100">{balance.currency}</span><span className="font-mono text-sm font-semibold tabular-nums text-gray-900 dark:text-gray-100">{balance.amount}</span></div><div className="mt-1 flex flex-wrap justify-between gap-2 text-[10px] text-gray-500"><span>{t('rateValue', { rate: balance.currentRateTHB })}</span><span>{t('value', { amount: formatMoney(balance.currentValueTHB) })}</span><span>{t('fxGl', { amount: formatMoney(balance.unrealizedFxGainLossTHB) })}</span></div></div>)}</div>
                      {(summary?.forex.realizedEvents ?? []).length > 0 && (
                        <div className="mt-3 space-y-2">
                          <p className="text-[10px] font-bold uppercase tracking-wide text-gray-500">{t('recentRealizedFx')}</p>
                          {(summary?.forex.realizedEvents ?? []).slice(-5).reverse().map((event) => (
                            <div key={event.transactionId} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-gray-100 bg-white px-3 py-2 text-[10px] dark:border-gray-800 dark:bg-[#121212]">
                              <span className="font-semibold text-gray-700 dark:text-gray-300">{event.currency} · {event.amountDisposed}</span>
                              <span className="tabular-nums text-gray-500">{t('basisProceeds', { basis: formatMoney(event.costBasisTHB), proceeds: formatMoney(event.proceedsTHB) })}</span>
                              <span className={`font-bold tabular-nums ${safeDecimal(event.realizedFxGainLossTHB).isNegative() ? 'text-rose-600 dark:text-rose-300' : 'text-emerald-700 dark:text-emerald-300'}`}>{formatMoney(event.realizedFxGainLossTHB)}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3 py-2 text-[10px] leading-relaxed text-emerald-950 dark:border-emerald-800/50 dark:bg-emerald-950/25 dark:text-emerald-200">{t('currentFxCaveat')}</div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </section>
      )}

      <section className="rounded-2xl border border-gray-200/90 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] sm:p-6">
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
          <div>
            <p className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400"><ArrowDownRight className="h-3.5 w-3.5" /> {t('canonicalLedger')}</p>
            <h2 className="mt-1 text-lg font-bold text-gray-900 dark:text-gray-100">{t('transactionList')}</h2>
          </div>
          <span className="text-xs tabular-nums text-gray-500 dark:text-gray-400">{t('transactionsIsolated', { count: transactions.length })}</span>
        </div>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-xs">
            <thead><tr className="border-b border-gray-100 text-gray-500 dark:border-gray-800"><th className="px-3 py-2 font-semibold">{t('date')}</th><th className="px-3 py-2 font-semibold">{t('assetSymbol')}</th><th className="px-3 py-2 font-semibold">{t('action')}</th><th className="px-3 py-2 text-right font-semibold">{t('qty')}</th><th className="px-3 py-2 text-right font-semibold">{t('price')}</th><th className="px-3 py-2 text-right font-semibold">{t('valueTHB')}</th><th className="px-3 py-2 text-right font-semibold">{t('operation')}</th></tr></thead>
            <tbody>
              {summaryQuery.isLoading ? <tr><td colSpan={7} className="px-3 py-8 text-center text-gray-500">{t('loadingLedger')}</td></tr> : sortedTransactions.length === 0 ? <tr><td colSpan={7} className="px-3 py-10 text-center"><div className="mx-auto max-w-md"><p className="font-semibold text-gray-800 dark:text-gray-200">{t('noTransactions')}</p><p className="mt-1 text-gray-500">{t('startWithAssets')}</p></div></td></tr> : sortedTransactions.map((transaction) => <TransactionRow key={transaction.id} transaction={transaction} onDelete={() => deleteMutation.mutate(transaction.id)} isDeleting={deleteMutation.isPending} />)}
            </tbody>
          </table>
        </div>
      </section>

      <div className="flex items-start gap-2 rounded-2xl border border-blue-200/80 bg-blue-50/70 px-4 py-3 text-[11px] leading-relaxed text-blue-950 dark:border-blue-900/50 dark:bg-blue-950/20 dark:text-blue-200">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
        <p><strong>{t('scopeTitle')}</strong> {t('scopeText')}</p>
      </div>
      <LegalDisclaimer />

      {selectedYtmResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-950/50 p-4 backdrop-blur-sm">
          <button
            type="button"
            aria-label={t('closeYtm')}
            className="absolute inset-0 h-full w-full cursor-default"
            onClick={() => setSelectedYtmResult(null)}
          />
          <div role="dialog" aria-modal="true" aria-labelledby="ytm-result-title" className="relative z-10 w-full max-w-lg space-y-4 rounded-2xl border border-gray-200 bg-white p-5 shadow-2xl dark:border-gray-700 dark:bg-[#1E1E1E] sm:p-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider text-[#14342a] dark:text-emerald-300">{t('calculationResult')}</p>
                <h2 id="ytm-result-title" className="mt-1 text-lg font-bold text-gray-900 dark:text-gray-100">{t('yieldToMaturity', { symbol: selectedYtmResult.symbol })}</h2>
              </div>
              <button type="button" onClick={() => setSelectedYtmResult(null)} aria-label={t('closeYtm')} className="rounded-xl p-2 text-gray-500 transition hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800"><X className="h-4 w-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-gray-100 bg-gray-50 p-3 dark:border-gray-800 dark:bg-[#121212]">
                <p className="text-[10px] font-semibold text-gray-500">{t('estimatedYtm')}</p>
                <p className="mt-1 text-xl font-bold tabular-nums text-[#14342a] dark:text-emerald-300">{selectedYtmResult.yieldToMaturity ? `${safeDecimal(selectedYtmResult.yieldToMaturity).times(100).toFixed(3)}%` : '—'}</p>
              </div>
              <div className="rounded-xl border border-gray-100 bg-gray-50 p-3 dark:border-gray-800 dark:bg-[#121212]">
                <p className="text-[10px] font-semibold text-gray-500">{t('accruedPerBond')}</p>
                <p className="mt-1 text-sm font-bold tabular-nums text-gray-900 dark:text-gray-100">{formatMoney(selectedYtmResult.accruedInterestPerBondTHB)}</p>
              </div>
            </div>
            <p className="text-xs leading-relaxed text-gray-500 dark:text-gray-400">{t('ytmEstimateCaveat', { date: summary?.asOfDate ?? t('noRecords') })}{selectedYtmResult.nextCouponDate ? ` · ${t('nextCouponDate', { date: selectedYtmResult.nextCouponDate })}` : ''}</p>
            <LegalDisclaimer />
            <div className="flex justify-end"><button type="button" onClick={() => setSelectedYtmResult(null)} className="rounded-xl bg-[#14342a] px-4 py-2 text-xs font-semibold text-white transition hover:bg-[#1b4538]">{t('close')}</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

function TransactionRow({
  transaction,
  onDelete,
  isDeleting,
}: {
  transaction: MultiAssetTransactionDto;
  onDelete: () => void;
  isDeleting: boolean;
}) {
  const t = useTranslations('multiAsset');
  const locale = useLocale();
  const valueTHB = transaction.netTHB ?? transaction.net;
  return (
    <tr className="border-b border-gray-50 last:border-0 dark:border-gray-800/70">
      <td className="whitespace-nowrap px-3 py-3 text-gray-500">{formatDateShort(transaction.date, locale === 'th' ? 'th-TH' : 'en-GB')}</td>
      <td className="px-3 py-3"><span className="font-semibold text-gray-900 dark:text-gray-100">{transaction.symbol}</span><span className="ml-2 rounded-full bg-gray-100 px-2 py-0.5 text-[9px] font-bold text-gray-600 dark:bg-gray-800 dark:text-gray-300">{transaction.assetClass}</span></td>
      <td className="px-3 py-3"><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${transaction.type === 'SELL' ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-300' : transaction.type === 'CONVERT' ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-300' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300'}`}>{transaction.type}</span></td>
      <td className="px-3 py-3 text-right font-mono tabular-nums text-gray-700 dark:text-gray-300">{transaction.qty}</td>
      <td className="px-3 py-3 text-right font-mono tabular-nums text-gray-700 dark:text-gray-300">{transaction.price} {transaction.originalCurrency}</td>
      <td className="px-3 py-3 text-right font-mono tabular-nums text-gray-800 dark:text-gray-200">{formatMoney(valueTHB)}</td>
      <td className="px-3 py-3 text-right"><button type="button" title={t('deleteTransaction')} onClick={onDelete} disabled={isDeleting} className="rounded-lg p-1.5 text-gray-400 hover:bg-red-50 hover:text-red-600 disabled:opacity-50 dark:hover:bg-red-950/30"><Trash2 className="h-3.5 w-3.5" /></button></td>
    </tr>
  );
}
