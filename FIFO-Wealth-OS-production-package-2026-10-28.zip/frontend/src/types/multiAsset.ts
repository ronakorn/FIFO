import type { MultiAssetTransaction as CanonicalMultiAssetTransaction } from '../../../backend/src/types/multiAsset';
import type { MultiAssetPortfolioSummary } from '../../../backend/src/services/multiAsset';

export type MultiAssetTransactionDto = Omit<CanonicalMultiAssetTransaction, 'createdAt'> & {
  createdAt: string;
};

export type MultiAssetTransactionInput = Omit<
  CanonicalMultiAssetTransaction,
  'id' | 'portfolioId' | 'createdAt'
>;

export interface MultiAssetApiResponse {
  transactions: MultiAssetTransactionDto[];
  summary: MultiAssetPortfolioSummary;
  dateOfBirth: string | null;
  lastUpdatedAt: {
    bonds: string | null;
    funds: string | null;
    metals: string | null;
    forex: string | null;
  };
}
