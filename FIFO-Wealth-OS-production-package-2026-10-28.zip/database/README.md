# Database

SQLite is the validated and authoritative provider. `schema.prisma`, `migrations/`, and `migration_lock.toml` define the database. The populated developer database is intentionally not included.

- Local development: set `DATABASE_URL="file:./dev.db"`; Prisma resolves this relative to `schema.prisma`, so the local file is `database/dev.db`. Run migrations from `backend/`.
- Docker Compose: uses the persistent named volume mounted at `/app/data/fifo_wealth_os.db`.
- `test-template.db` is a clean, empty schema-only fixture for adapter tests; it contains no user records.
- `schema.postgresql.prisma` is a reference only and is not validated for deployment. Do not switch providers without an approved schema/migration conversion plan.
