export const colors = {
  midnight: '#090A10',
  surface: '#12141C',
  raised: '#1B1E28',
  stroke: '#292D3A',
  muted: '#9CA2B2',
  ink: '#F4F5F8',
  accent: '#B42332',
  accentBright: '#D14350',
  gain: '#54D39A',
  loss: '#F17878',
  gold: '#D9B76D',
} as const;
