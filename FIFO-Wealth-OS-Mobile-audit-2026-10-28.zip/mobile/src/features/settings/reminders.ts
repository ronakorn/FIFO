import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { getWeeklyReminderId, setWeeklyReminder } from '@/auth/tokenStore';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: false,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function enableWeeklyTaxReminder(): Promise<boolean> {
  const current = await Notifications.getPermissionsAsync();
  const permission = current.granted ? current : await Notifications.requestPermissionsAsync();
  if (!permission.granted) return false;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('wealth-reminders', {
      name: 'Wealth reminders',
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 180, 100, 180],
      lightColor: '#D14350',
    });
  }

  const oldId = await getWeeklyReminderId();
  if (oldId) await Notifications.cancelScheduledNotificationAsync(oldId).catch(() => undefined);

  const identifier = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'FIFO Wealth OS · weekly review',
      body: 'Review your portfolios and tax summaries when convenient.',
      data: { route: '/(app)/(tabs)/tax' },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
      weekday: 2,
      hour: 9,
      minute: 0,
      channelId: 'wealth-reminders',
    },
  });
  await setWeeklyReminder(true, identifier);
  return true;
}

export async function disableWeeklyTaxReminder(): Promise<void> {
  const identifier = await getWeeklyReminderId();
  if (identifier) await Notifications.cancelScheduledNotificationAsync(identifier).catch(() => undefined);
  await setWeeklyReminder(false);
}
