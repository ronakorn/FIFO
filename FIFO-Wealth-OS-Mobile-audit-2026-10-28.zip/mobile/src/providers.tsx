import { focusManager, onlineManager } from '@tanstack/react-query';
import NetInfo, { type NetInfoState } from '@react-native-community/netinfo';
import { AppState, type AppStateStatus } from 'react-native';
import { useEffect, type PropsWithChildren } from 'react';

function isOnline(state: NetInfoState): boolean {
  return state.isConnected === true && state.isInternetReachable !== false;
}

export function QueryRuntimeProvider({ children }: PropsWithChildren): React.JSX.Element {
  useEffect(() => {
    const unsubscribeNetwork = NetInfo.addEventListener((state) => {
      onlineManager.setOnline(isOnline(state));
    });
    void NetInfo.fetch().then((state) => onlineManager.setOnline(isOnline(state)));

    const appStateSubscription = AppState.addEventListener('change', (state: AppStateStatus) => {
      focusManager.setFocused(state === 'active');
    });
    focusManager.setFocused(AppState.currentState === 'active');

    return () => {
      unsubscribeNetwork();
      appStateSubscription.remove();
    };
  }, []);

  return <>{children}</>;
}
