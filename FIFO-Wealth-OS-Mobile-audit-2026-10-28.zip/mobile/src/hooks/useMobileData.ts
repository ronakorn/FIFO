import { useInfiniteQuery, useQuery } from '@tanstack/react-query';
import { getApiErrorMessage } from '@/api/client';
import { mobileApi } from '@/api/services';
import type {
  DashboardAnalyticsResponse,
  MobileDashboardSummary,
  MobileTransactionPage,
  TaxReport,
} from '@/api/types';
import { readSecureCache, writeSecureCache } from '@/cache/secureCache';

export interface CachedResult<T> {
  value: T;
  stale: boolean;
}

async function fetchOrReadCache<T>(key: string, fetcher: () => Promise<T>): Promise<CachedResult<T>> {
  try {
    const value = await fetcher();
    await writeSecureCache(key, value).catch(() => undefined);
    return { value, stale: false };
  } catch (error) {
    const cached = await readSecureCache<T>(key).catch(() => null);
    if (cached !== null) return { value: cached, stale: true };
    throw new Error(getApiErrorMessage(error));
  }
}

export function useMobileDashboard() {
  return useQuery<CachedResult<MobileDashboardSummary>>({
    queryKey: ['mobile-dashboard-summary'],
    staleTime: 30_000,
    queryFn: () => fetchOrReadCache('dashboard-summary:v1', () => mobileApi.dashboardSummary()),
  });
}

export function useDashboardAnalytics(benchmark: 'SP500' | 'SET50' = 'SP500') {
  return useQuery<CachedResult<DashboardAnalyticsResponse>>({
    queryKey: ['mobile-dashboard-analytics', benchmark],
    staleTime: 60_000,
    queryFn: () => fetchOrReadCache(
      `analytics:${benchmark}:v1`,
      () => mobileApi.dashboardAnalytics(benchmark),
    ),
  });
}

export function useMobileTransactions(
  portfolioId: string | undefined,
  filters: { symbol?: string; type?: 'BUY' | 'SELL' | 'FEE' } = {},
) {
  const normalizedSymbol = filters.symbol?.trim().toUpperCase() || undefined;
  const filterKey = `${filters.type ?? 'ALL'}:${normalizedSymbol ?? 'ALL'}`;

  return useInfiniteQuery({
    queryKey: ['mobile-transactions', portfolioId, filterKey] as const,
    enabled: Boolean(portfolioId),
    initialPageParam: null as string | null,
    staleTime: 15_000,
    queryFn: async ({ pageParam }) => {
      if (!portfolioId) throw new Error('Select a portfolio to view its transactions.');
      const cursor = pageParam;
      const key = `transactions:${portfolioId}:${filterKey}:${cursor ?? 'first'}:v1`;
      try {
        const page = await mobileApi.transactionPage(portfolioId, cursor, 30, {
          ...(normalizedSymbol ? { symbol: normalizedSymbol } : {}),
          ...(filters.type ? { type: filters.type } : {}),
        });
        await writeSecureCache(key, page).catch(() => undefined);
        return { ...page, cached: false };
      } catch (error) {
        const cached = await readSecureCache<MobileTransactionPage>(key).catch(() => null);
        if (cached) return { ...cached, cached: true };
        throw new Error(getApiErrorMessage(error));
      }
    },
    getNextPageParam: (lastPage) => lastPage.hasMore ? lastPage.nextCursor ?? undefined : undefined,
  });
}

export function useTaxSummary(
  portfolioId: string | undefined,
  year: number,
  options: { electFinalTaxOnDividends: boolean; otherNetIncomeTHB?: string },
) {
  const incomeKey = options.otherNetIncomeTHB?.trim() || '0';
  const optionKey = `${options.electFinalTaxOnDividends ? 'final' : 'progressive'}:${incomeKey}`;
  return useQuery<CachedResult<TaxReport>>({
    queryKey: ['mobile-tax-summary', portfolioId, year, optionKey],
    enabled: Boolean(portfolioId && Number.isInteger(year) && year >= 1900 && year <= 3000),
    staleTime: 60_000,
    queryFn: () => {
      if (!portfolioId) throw new Error('Select a portfolio to view tax results.');
      const key = `tax-summary:${portfolioId}:${year}:${optionKey}:v1`;
      return fetchOrReadCache(key, () => mobileApi.taxSummary(portfolioId, year, {
        electFinalTaxOnDividends: options.electFinalTaxOnDividends,
        ...(options.otherNetIncomeTHB?.trim() ? { otherNetIncomeTHB: options.otherNetIncomeTHB.trim() } : {}),
      }));
    },
  });
}
