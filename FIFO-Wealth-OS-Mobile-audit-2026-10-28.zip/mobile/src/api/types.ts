export interface ApiUser {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  dateOfBirth?: string | null;
}

export interface AuthResponse {
  user: ApiUser;
  token: string;
}

export type LotStatus = 'Hold' | 'Partial' | 'Sold';

export interface FifoLot {
  id: string;
  date: string;
  symbol: string;
  buyQty: number;
  costPerUnit: number;
  qtySold: number;
  qtyRemain: number;
  realizedGL: number;
  unrealizedGL: number;
  status: LotStatus;
}

export interface PortfolioFifoSummary {
  totalRealizedGL: number;
  totalUnrealizedGL: number;
  totalCostSold: number;
  totalProceeds: number;
  openCostBasisTHB: number;
  marketValueTHB: number;
  lots: FifoLot[];
}

export interface Portfolio {
  id: string;
  userId: string;
  name: string;
  baseCurrency: string;
  createdAt: string;
  transactionCount?: number;
  dividendCount?: number;
  fifoSummary?: PortfolioFifoSummary;
}

export type TransactionType = 'BUY' | 'SELL' | 'FEE';

export interface Transaction {
  id: string;
  portfolioId: string;
  date: string;
  symbol: string;
  type: TransactionType;
  qty: number;
  price: number;
  gross: string;
  comm: string;
  vat: string;
  net: string;
  originalCurrency: string;
  fxRate: string | null;
  netTHB: string | null;
}

export interface MobileDashboardSummary {
  asOf: string;
  currency: 'THB';
  valuationBasis: 'LATEST_RECORDED_TRANSACTION_PRICE';
  summary: {
    portfolioCount: number;
    transactionCount: number;
    dividendCount: number;
    marketValueTHB: string;
    openCostBasisTHB: string;
    realizedGLTHB: string;
    unrealizedGLTHB: string;
  };
  allocation: {
    symbol: string;
    valueTHB: string;
    openCostBasisTHB: string;
    weightPct: string;
  }[];
  portfolios: Portfolio[];
  recentTransactions: Transaction[];
}

export interface MobileTransactionPage {
  items: Transaction[];
  limit: number;
  hasMore: boolean;
  nextCursor: string | null;
  cached?: boolean;
}

export interface DashboardAnalyticsResponse {
  scope: string;
  benchmark: 'SET50' | 'SP500';
  riskFreeRateAnnual: string;
  asOfDate: string;
  metrics: {
    xirr: string;
    sharpeRatio: string;
    sortinoRatio: string;
    twr: string;
    maxDrawdown: string;
    totalReturn: string;
  };
  benchmarkSeries: {
    date: string;
    portfolioValue: number;
    benchmarkValue: number;
    portfolioReturnPct?: number;
    benchmarkReturnPct?: number;
  }[];
  assetAllocation: {
    category: 'THAI_EQUITY' | 'FOREIGN_EQUITY' | 'CRYPTO' | 'GOLD' | 'CASH';
    label: string;
    enLabel: string;
    valueTHB: string;
    weightPct: string;
    color: string;
  }[];
}

export interface TaxEvent {
  id: string;
  type: 'CAPITAL_GAIN' | 'DIVIDEND';
  date: string;
  symbol: string;
  amountTHB: string;
  taxableIncome: string;
  taxWithheld: string;
  netTaxPayable: string;
}

export interface TaxReport {
  taxYear: number;
  capitalGains: TaxEvent[];
  dividends: TaxEvent[];
  totalTaxableIncome: string;
  totalTaxWithheld: string;
  totalTaxPayable: string;
  generatedAt: string;
}

export interface IbkrConnection {
  id: string | null;
  brokerName: 'IBKR';
  flexQueryId: string | null;
  portfolioId: string | null;
  status: 'CONNECTED' | 'SYNCING' | 'DISCONNECTED' | 'ERROR';
  connected: boolean;
  lastSyncedAt: string | null;
  createdAt: string | null;
  readOnly: true;
  encryption: 'AES-256-GCM';
}

export interface ThaiBrokerConnection {
  broker: string;
  connected: boolean;
  status?: string;
  lastSyncedAt?: string | null;
  portfolioId?: string | null;
}

export interface ThaiBrokerStatusResponse {
  connections: ThaiBrokerConnection[];
  currentConsentVersion?: string;
  hubBadge?: string;
  regulatoryFramework?: string;
  streamingRoadmapNotice?: string;
}

export interface ApiErrorPayload {
  error?: {
    code?: string;
    message?: string;
    details?: unknown;
  };
}
