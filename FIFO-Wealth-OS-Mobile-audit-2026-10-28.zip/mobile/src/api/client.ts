import { create, isAxiosError, type AxiosError, type InternalAxiosRequestConfig } from 'axios';
import { getAccessToken } from '@/auth/tokenStore';
import type { ApiErrorPayload } from '@/api/types';

export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/+$/, '')
  ?? 'http://10.0.2.2:3000/api';

export const api = create({
  baseURL: API_BASE_URL,
  timeout: 20_000,
  headers: { Accept: 'application/json' },
});

let unauthorizedHandler: (() => Promise<void>) | null = null;

export function registerUnauthorizedHandler(handler: () => Promise<void>): () => void {
  unauthorizedHandler = handler;
  return () => {
    if (unauthorizedHandler === handler) unauthorizedHandler = null;
  };
}

api.interceptors.request.use(async (config: InternalAxiosRequestConfig) => {
  const token = await getAccessToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<ApiErrorPayload>) => {
    const requestHadBearer = Boolean(error.config?.headers?.Authorization);
    if (error.response?.status === 401 && requestHadBearer && unauthorizedHandler) {
      await unauthorizedHandler();
    }
    return Promise.reject(error);
  },
);

export function getApiErrorMessage(error: unknown): string {
  if (isAxiosError<ApiErrorPayload>(error)) {
    const serverMessage = error.response?.data?.error?.message;
    if (serverMessage) return serverMessage;
    if (error.code === 'ECONNABORTED') return 'The request timed out. Check your connection and try again.';
    if (!error.response) return 'Unable to reach FIFO Wealth OS. Check your network or API URL.';
  }
  if (error instanceof Error) return error.message;
  return 'Something went wrong. Please try again.';
}
