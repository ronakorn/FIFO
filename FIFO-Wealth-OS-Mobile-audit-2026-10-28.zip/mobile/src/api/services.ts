import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { api, API_BASE_URL } from '@/api/client';
import type {
  AuthResponse,
  DashboardAnalyticsResponse,
  IbkrConnection,
  MobileDashboardSummary,
  MobileTransactionPage,
  Portfolio,
  TaxReport,
  ThaiBrokerStatusResponse,
  ApiUser,
} from '@/api/types';
import { getAccessToken } from '@/auth/tokenStore';

export const authApi = {
  async login(email: string, password: string): Promise<AuthResponse> {
    const { data } = await api.post<AuthResponse>('/auth/login', { email, password });
    return data;
  },
  async register(email: string, password: string, name: string): Promise<AuthResponse> {
    const { data } = await api.post<AuthResponse>('/auth/register', { email, password, name });
    return data;
  },
  async me(): Promise<ApiUser> {
    const { data } = await api.get<{ user: ApiUser }>('/auth/me');
    return data.user;
  },
};

export const portfolioApi = {
  async create(name: string, baseCurrency: string): Promise<Portfolio> {
    const { data } = await api.post<Portfolio>('/portfolios', { name, baseCurrency });
    return data;
  },
};

export const mobileApi = {
  async dashboardSummary(): Promise<MobileDashboardSummary> {
    const { data } = await api.get<MobileDashboardSummary>('/mobile/dashboard-summary');
    return data;
  },
  async dashboardAnalytics(benchmark: 'SP500' | 'SET50' = 'SP500'): Promise<DashboardAnalyticsResponse> {
    const { data } = await api.get<DashboardAnalyticsResponse>('/analytics/dashboard', {
      params: { benchmark },
    });
    return data;
  },
  async transactionPage(
    portfolioId: string,
    cursor: string | null,
    limit: number,
    filters: { symbol?: string; type?: 'BUY' | 'SELL' | 'FEE' },
  ): Promise<MobileTransactionPage> {
    const { data } = await api.get<MobileTransactionPage>(
      `/mobile/transactions/${encodeURIComponent(portfolioId)}`,
      {
        params: {
          limit,
          ...(cursor ? { cursor } : {}),
          ...(filters.symbol ? { symbol: filters.symbol } : {}),
          ...(filters.type ? { type: filters.type } : {}),
        },
      },
    );
    return data;
  },
  async taxSummary(
    portfolioId: string,
    year: number,
    options: { electFinalTaxOnDividends: boolean; otherNetIncomeTHB?: string },
  ): Promise<TaxReport> {
    const { data } = await api.get<TaxReport>(`/tax/summary/${encodeURIComponent(portfolioId)}/${year}`, {
      params: {
        electFinalTaxOnDividends: String(options.electFinalTaxOnDividends),
        ...(options.otherNetIncomeTHB ? { otherNetIncomeTHB: options.otherNetIncomeTHB } : {}),
      },
    });
    return data;
  },
  async downloadTaxReport(
    portfolioId: string,
    year: number,
    options: { electFinalTaxOnDividends: boolean; otherNetIncomeTHB?: string },
  ): Promise<void> {
    const token = await getAccessToken();
    if (!token) throw new Error('Sign in again before downloading this report.');
    if (!FileSystem.cacheDirectory) throw new Error('Device temporary storage is unavailable.');

    const filename = `FIFO_Wealth_OS_Tax_Report_${year}.pdf`;
    const destination = `${FileSystem.cacheDirectory}${filename}`;
    const query = new URLSearchParams({
      electFinalTaxOnDividends: String(options.electFinalTaxOnDividends),
      ...(options.otherNetIncomeTHB ? { otherNetIncomeTHB: options.otherNetIncomeTHB } : {}),
    });
    const response = await FileSystem.downloadAsync(
      `${API_BASE_URL}/tax/report/${encodeURIComponent(portfolioId)}/${year}?${query.toString()}`,
      destination,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    if (response.status < 200 || response.status >= 300) {
      await FileSystem.deleteAsync(destination, { idempotent: true }).catch(() => undefined);
      if (response.status === 401) {
        await authApi.me().catch(() => undefined);
        throw new Error('Your session expired. Sign in again to export this report.');
      }
      throw new Error(`Report export failed with status ${response.status}.`);
    }
    if (!(await Sharing.isAvailableAsync())) {
      await FileSystem.deleteAsync(response.uri, { idempotent: true }).catch(() => undefined);
      throw new Error('The report was created, but sharing is unavailable on this device.');
    }
    try {
      await Sharing.shareAsync(response.uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Share FIFO Wealth OS tax report',
        UTI: 'com.adobe.pdf',
      });
    } finally {
      await FileSystem.deleteAsync(response.uri, { idempotent: true }).catch(() => undefined);
    }
  },
};

export const brokerApi = {
  async ibkrStatus(): Promise<IbkrConnection> {
    const { data } = await api.get<IbkrConnection>('/sync/status');
    return data;
  },
  async connectIbkr(payload: { flexQueryToken: string; flexQueryId: string; portfolioId?: string }): Promise<void> {
    await api.post('/sync/ibkr/connect', payload);
  },
  async disconnectIbkr(): Promise<void> {
    await api.delete('/sync/ibkr/disconnect');
  },
  async syncIbkr(portfolioId?: string): Promise<unknown> {
    const { data } = await api.post<unknown>('/sync/ibkr/trigger', { portfolioId });
    return data;
  },
  async thaiBrokerStatus(): Promise<ThaiBrokerStatusResponse> {
    const { data } = await api.get<ThaiBrokerStatusResponse>('/thai-brokers/status');
    return data;
  },
  async connectBitkub(payload: {
    apiKey: string;
    apiSecret: string;
    portfolioId?: string;
    permissionsScope: 'READ_ONLY';
    pdpaConsent: { accepted: true; consentVersion: string; purposes: string[] };
  }): Promise<void> {
    await api.post('/thai-brokers/BITKUB/connect', payload);
  },
  async disconnectThaiBroker(broker: 'BITKUB' | 'DIME' | 'STREAMING'): Promise<void> {
    await api.delete(`/thai-brokers/${broker}/disconnect`, { params: { purgeData: true } });
  },
};

export async function shareTaxReport(
  portfolioId: string,
  year: number,
  options: { electFinalTaxOnDividends: boolean; otherNetIncomeTHB?: string } = {
    electFinalTaxOnDividends: false,
  },
): Promise<void> {
  await mobileApi.downloadTaxReport(portfolioId, year, options);
}
