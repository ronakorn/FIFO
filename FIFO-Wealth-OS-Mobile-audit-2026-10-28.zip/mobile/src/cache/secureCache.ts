import * as Crypto from 'expo-crypto';
import * as SQLite from 'expo-sqlite';
import { Platform } from 'react-native';
import { getDatabaseEncryptionKey, storeDatabaseEncryptionKey } from '@/auth/tokenStore';

const DATABASE_NAME = 'fifo-wealth-offline-cache.db';
let databasePromise: Promise<SQLite.SQLiteDatabase | null> | null = null;

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function ensureEncryptionKey(): Promise<string> {
  const storedKey = await getDatabaseEncryptionKey();
  if (storedKey) return storedKey;
  const key = bytesToHex(await Crypto.getRandomBytesAsync(32));
  await storeDatabaseEncryptionKey(key);
  return key;
}

async function openSecureDatabase(): Promise<SQLite.SQLiteDatabase | null> {
  if (Platform.OS !== 'android' && Platform.OS !== 'ios') return null;

  const database = await SQLite.openDatabaseAsync(DATABASE_NAME);
  const cipher = await database.getFirstAsync<{ cipher_version: string }>('PRAGMA cipher_version');
  if (!cipher?.cipher_version) {
    await database.closeAsync();
    throw new Error(
      'Encrypted offline storage is unavailable. Build a native development or production binary with expo-sqlite useSQLCipher enabled; Expo Go is not supported.',
    );
  }

  const key = await ensureEncryptionKey();
  await database.execAsync(`PRAGMA key = '${key}'`);
  await database.execAsync('PRAGMA journal_mode = WAL');
  await database.execAsync(`
    CREATE TABLE IF NOT EXISTS cache_entries (
      cache_key TEXT PRIMARY KEY NOT NULL,
      payload TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);
  return database;
}

async function getDatabase(): Promise<SQLite.SQLiteDatabase | null> {
  if (!databasePromise) {
    databasePromise = openSecureDatabase().catch((error: unknown) => {
      databasePromise = null;
      throw error;
    });
  }
  return databasePromise;
}

export async function writeSecureCache<T>(key: string, value: T): Promise<void> {
  const database = await getDatabase();
  if (!database) return;
  await database.runAsync(
    `INSERT INTO cache_entries (cache_key, payload, updated_at)
     VALUES (?, ?, ?)
     ON CONFLICT(cache_key) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at`,
    key,
    JSON.stringify(value),
    Date.now(),
  );
}

export async function readSecureCache<T>(key: string): Promise<T | null> {
  const database = await getDatabase();
  if (!database) return null;
  const row = await database.getFirstAsync<{ payload: string }>(
    'SELECT payload FROM cache_entries WHERE cache_key = ?',
    key,
  );
  if (!row?.payload) return null;
  try {
    return JSON.parse(row.payload) as T;
  } catch {
    await database.runAsync('DELETE FROM cache_entries WHERE cache_key = ?', key);
    return null;
  }
}

export async function clearSecureCache(): Promise<void> {
  const database = await getDatabase();
  if (!database) return;
  await database.runAsync('DELETE FROM cache_entries');
}

export async function isEncryptedCacheAvailable(): Promise<boolean> {
  try {
    return (await getDatabase()) !== null;
  } catch {
    return false;
  }
}
