import * as SecureStore from 'expo-secure-store';
import type { ApiUser } from '@/api/types';

const TOKEN_KEY = 'fifo.mobile.access-token.v1';
const USER_KEY = 'fifo.mobile.user.v1';
const BIOMETRIC_KEY = 'fifo.mobile.biometric-lock.v1';
const LOCK_TIMEOUT_KEY = 'fifo.mobile.lock-timeout.v1';
const DATABASE_KEY_KEY = 'fifo.mobile.sqlcipher-key.v1';
const WEEKLY_REMINDER_KEY = 'fifo.mobile.weekly-tax-reminder.v1';
const REMINDER_ID_KEY = 'fifo.mobile.weekly-tax-reminder-id.v1';
const ONBOARDING_KEY = 'fifo.mobile.onboarding-complete.v1';

export async function getAccessToken(): Promise<string | null> {
  return SecureStore.getItemAsync(TOKEN_KEY);
}

export async function storeSession(token: string, user: ApiUser): Promise<void> {
  await SecureStore.setItemAsync(TOKEN_KEY, token, {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
  });
  await SecureStore.setItemAsync(USER_KEY, JSON.stringify(user), {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
  });
}

export async function getStoredUser(): Promise<ApiUser | null> {
  const raw = await SecureStore.getItemAsync(USER_KEY);
  if (!raw) return null;
  try {
    const parsed: unknown = JSON.parse(raw);
    if (
      typeof parsed === 'object' &&
      parsed !== null &&
      'id' in parsed &&
      'email' in parsed &&
      'name' in parsed &&
      typeof parsed.id === 'string' &&
      typeof parsed.email === 'string' &&
      typeof parsed.name === 'string'
    ) {
      return parsed as ApiUser;
    }
    return null;
  } catch {
    return null;
  }
}

export async function clearSession(): Promise<void> {
  await Promise.all([
    SecureStore.deleteItemAsync(TOKEN_KEY),
    SecureStore.deleteItemAsync(USER_KEY),
  ]);
}

export async function isBiometricLockEnabled(): Promise<boolean> {
  return (await SecureStore.getItemAsync(BIOMETRIC_KEY)) === 'enabled';
}

export async function setBiometricLockEnabled(enabled: boolean): Promise<void> {
  if (enabled) {
    await SecureStore.setItemAsync(BIOMETRIC_KEY, 'enabled');
  } else {
    await SecureStore.deleteItemAsync(BIOMETRIC_KEY);
  }
}

export type LockTimeout = 'immediately' | 'one-minute' | 'five-minutes';

export async function getLockTimeout(): Promise<LockTimeout> {
  const value = await SecureStore.getItemAsync(LOCK_TIMEOUT_KEY);
  if (value === 'one-minute' || value === 'five-minutes') return value;
  return 'immediately';
}

export async function setLockTimeout(value: LockTimeout): Promise<void> {
  await SecureStore.setItemAsync(LOCK_TIMEOUT_KEY, value);
}

export async function getDatabaseEncryptionKey(): Promise<string | null> {
  return SecureStore.getItemAsync(DATABASE_KEY_KEY);
}

export async function storeDatabaseEncryptionKey(key: string): Promise<void> {
  await SecureStore.setItemAsync(DATABASE_KEY_KEY, key, {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
  });
}

export async function getWeeklyReminderId(): Promise<string | null> {
  return SecureStore.getItemAsync(REMINDER_ID_KEY);
}

export async function setWeeklyReminder(enabled: boolean, notificationId?: string): Promise<void> {
  if (enabled && notificationId) {
    await SecureStore.setItemAsync(WEEKLY_REMINDER_KEY, 'enabled');
    await SecureStore.setItemAsync(REMINDER_ID_KEY, notificationId);
    return;
  }
  await Promise.all([
    SecureStore.deleteItemAsync(WEEKLY_REMINDER_KEY),
    SecureStore.deleteItemAsync(REMINDER_ID_KEY),
  ]);
}

export async function isWeeklyReminderEnabled(): Promise<boolean> {
  return (await SecureStore.getItemAsync(WEEKLY_REMINDER_KEY)) === 'enabled';
}

export async function isOnboardingComplete(): Promise<boolean> {
  return (await SecureStore.getItemAsync(ONBOARDING_KEY)) === 'completed';
}

export async function markOnboardingComplete(): Promise<void> {
  await SecureStore.setItemAsync(ONBOARDING_KEY, 'completed');
}
