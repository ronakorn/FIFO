import type { PropsWithChildren, ReactElement } from 'react';
import { ScrollView, View, type RefreshControlProps } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

interface ScreenProps extends PropsWithChildren {
  contentClassName?: string;
  refreshControl?: ReactElement<RefreshControlProps>;
  scroll?: boolean;
}

export function Screen({ children, contentClassName = '', refreshControl, scroll = true }: ScreenProps): React.JSX.Element {
  return (
    <SafeAreaView className="flex-1 bg-midnight" edges={['top']}>
      {scroll ? (
        <ScrollView
          className="flex-1"
          keyboardShouldPersistTaps="handled"
          refreshControl={refreshControl}
          showsVerticalScrollIndicator={false}
        >
          <View className={`px-5 pb-32 pt-5 ${contentClassName}`}>{children}</View>
        </ScrollView>
      ) : (
        <View className={`flex-1 px-5 ${contentClassName}`}>{children}</View>
      )}
    </SafeAreaView>
  );
}
