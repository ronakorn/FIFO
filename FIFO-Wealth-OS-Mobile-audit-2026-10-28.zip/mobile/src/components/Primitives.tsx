import type { PropsWithChildren, ReactNode } from 'react';
import {
  ActivityIndicator,
  Pressable,
  Text,
  TextInput,
  View,
  type KeyboardTypeOptions,
  type TextInputProps,
} from 'react-native';

interface CardProps extends PropsWithChildren {
  className?: string;
}

export function Card({ children, className = '' }: CardProps): React.JSX.Element {
  return <View className={`rounded-3xl border border-stroke bg-surface p-4 ${className}`}>{children}</View>;
}

interface ButtonProps {
  title: string;
  onPress: () => void | Promise<void>;
  loading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  icon?: ReactNode;
  className?: string;
}

const buttonStyles: Record<NonNullable<ButtonProps['variant']>, string> = {
  primary: 'bg-accent active:bg-accent-bright',
  secondary: 'border border-stroke bg-raised active:bg-stroke',
  danger: 'border border-loss/30 bg-loss/10 active:bg-loss/20',
  ghost: 'bg-transparent active:bg-raised',
};

const buttonTextStyles: Record<NonNullable<ButtonProps['variant']>, string> = {
  primary: 'text-white',
  secondary: 'text-ink',
  danger: 'text-loss',
  ghost: 'text-muted',
};

export function Button({
  title,
  onPress,
  loading = false,
  disabled = false,
  variant = 'primary',
  icon,
  className = '',
}: ButtonProps): React.JSX.Element {
  const isDisabled = disabled || loading;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      className={`min-h-12 flex-row items-center justify-center gap-2 rounded-2xl px-4 py-3 ${buttonStyles[variant]} ${isDisabled ? 'opacity-50' : ''} ${className}`}
      disabled={isDisabled}
      onPress={() => { void onPress(); }}
    >
      {loading ? <ActivityIndicator size="small" color={variant === 'primary' ? '#FFFFFF' : '#D8D9E0'} /> : icon}
      <Text className={`font-display text-sm font-bold ${buttonTextStyles[variant]}`}>{title}</Text>
    </Pressable>
  );
}

interface FieldProps extends Omit<TextInputProps, 'onChangeText'> {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  hint?: string;
  error?: string;
  keyboardType?: KeyboardTypeOptions;
}

export function Field({ label, value, onChangeText, hint, error, ...inputProps }: FieldProps): React.JSX.Element {
  return (
    <View className="gap-2">
      <Text className="font-body text-xs font-bold uppercase tracking-widest text-muted">{label}</Text>
      <TextInput
        accessibilityLabel={label}
        autoCorrect={false}
        className="min-h-12 rounded-2xl border border-stroke bg-raised px-4 py-3 font-body text-base text-ink"
        onChangeText={onChangeText}
        placeholderTextColor="#6E7382"
        selectionColor="#D14350"
        value={value}
        {...inputProps}
      />
      {error ? <Text className="font-body text-xs text-loss">{error}</Text> : null}
      {!error && hint ? <Text className="font-body text-xs leading-5 text-muted">{hint}</Text> : null}
    </View>
  );
}

export function SectionTitle({ title, action }: { title: string; action?: ReactNode }): React.JSX.Element {
  return (
    <View className="mb-3 flex-row items-center justify-between">
      <Text className="font-display text-base font-bold text-ink">{title}</Text>
      {action}
    </View>
  );
}

export function Eyebrow({ children }: PropsWithChildren): React.JSX.Element {
  return <Text className="font-body text-[10px] font-bold uppercase tracking-[2px] text-muted">{children}</Text>;
}

export function StatusPill({ label, tone = 'muted' }: { label: string; tone?: 'good' | 'bad' | 'muted' }): React.JSX.Element {
  const style = tone === 'good'
    ? 'border-gain/30 bg-gain/10 text-gain'
    : tone === 'bad'
      ? 'border-loss/30 bg-loss/10 text-loss'
      : 'border-stroke bg-raised text-muted';
  return (
    <View className={`self-start rounded-full border px-2.5 py-1 ${style}`}>
      <Text className="font-body text-[10px] font-bold uppercase tracking-wide">{label}</Text>
    </View>
  );
}

export function InlineError({ message, onRetry }: { message: string; onRetry?: () => void }): React.JSX.Element {
  return (
    <View className="rounded-2xl border border-loss/30 bg-loss/10 p-4">
      <Text className="font-display text-sm font-bold text-loss">Unable to load</Text>
      <Text className="mt-1 font-body text-sm leading-5 text-muted">{message}</Text>
      {onRetry ? (
        <Pressable accessibilityRole="button" className="mt-3 self-start" onPress={onRetry}>
          <Text className="font-body text-sm font-bold text-ink">Try again</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function EmptyState({ title, message }: { title: string; message: string }): React.JSX.Element {
  return (
    <View className="items-center rounded-3xl border border-dashed border-stroke bg-surface px-6 py-10">
      <View className="mb-4 h-12 w-12 items-center justify-center rounded-2xl bg-raised">
        <Text className="font-display text-xl font-bold text-gold">·</Text>
      </View>
      <Text className="font-display text-base font-bold text-ink">{title}</Text>
      <Text className="mt-2 text-center font-body text-sm leading-5 text-muted">{message}</Text>
    </View>
  );
}
