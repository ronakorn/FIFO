/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './src/**/*.{js,jsx,ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        midnight: '#090A10',
        surface: '#12141C',
        raised: '#1B1E28',
        stroke: '#292D3A',
        muted: '#9CA2B2',
        ink: '#F4F5F8',
        accent: '#B42332',
        'accent-bright': '#D14350',
        gain: '#54D39A',
        loss: '#F17878',
        gold: '#D9B76D',
      },
      fontFamily: {
        display: ['System'],
        body: ['System'],
      },
      boxShadow: {
        glow: '0 12px 40px rgba(180, 35, 50, 0.18)',
      },
    },
  },
  plugins: [],
};
