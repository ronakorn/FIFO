# FIFO Wealth OS Mobile

Expo Router mobile client for FIFO Wealth OS, written in strict TypeScript with NativeWind. It calls the existing authenticated API for portfolio values, FIFO lots, transaction pages, broker sync, and Thai tax summaries. Financial calculations remain on the backend.

## Current scope and important limits

- **Valuations are not live market quotes.** The dashboard labels its basis as the latest transaction-price mark recorded by the backend.
- **Tax summaries are Thai tax-engine outputs.** They are not U.S. tax advice or a U.S. tax-filing calculation. The PDF endpoint may require the account's `taxReportPDF` entitlement.
- Advanced benchmark analytics are optional; if unavailable, base portfolio totals and symbol allocation still display.
- Dashboard and transaction snapshots use SQLCipher, with the database key stored in SecureStore. **SQLCipher is not available in Expo Go**; use a development or production native build to validate offline caching.
- The reminder preference schedules a **device-local weekly notification**. No remote push-token registration or push-delivery service is configured in the current backend.
- Broker forms currently cover IBKR Flex Query and Bitkub read-only credentials. Dime and Streaming are not connected in this mobile UI.
- The backend issues seven-day access tokens and has no refresh-token endpoint. An expired session requires a fresh sign-in.

## Requirements

- Node.js **20.19+** for the configured Expo SDK 56 toolchain (the checked workspace used Node 20.20.2).
- npm 10+.
- An API deployment with the mobile routes and existing auth, portfolio, broker, and Thai tax endpoints.
- For local native builds: Android Studio/SDK plus a supported JDK for Android, or Xcode on macOS for iOS.
- For store builds: an Expo account and EAS CLI; Google Play Console and/or Apple Developer/App Store Connect credentials.

## Install and configure

```bash
cd mobile
npm install
cp .env.example .env
```

Set `EXPO_PUBLIC_API_URL` in `.env` to the API base ending in `/api`:

- Android emulator: `http://10.0.2.2:3000/api`
- iOS simulator: `http://127.0.0.1:3000/api`
- Physical device: `http://<development-computer-LAN-IP>:3000/api`
- EAS preview and production: a deployed **HTTPS** URL ending in `/api`.

`EXPO_PUBLIC_*` values are compiled into the JavaScript bundle and are public. **Never** put `JWT_SECRET`, `ENCRYPTION_KEY`, a database password, broker credentials, or other private secrets in `.env` or EAS public variables. The Expo config rejects non-HTTPS API URLs, API URLs without the `/api` suffix, and URLs containing embedded credentials or query strings for EAS preview and production builds. Cleartext development access is limited to the development profile/local tooling.

For the backend, set a private `JWT_SECRET` and a dedicated `ENCRYPTION_KEY` of at least 32 characters in the server environment. Broker credentials are sent to the API and encrypted by the backend using its existing AES-256-GCM contract; they are not persisted in the app's local cache.

## Run locally

### Expo Go (limited inspection only)

```bash
npm run start:go
```

Expo Go can be used to inspect non-SQLCipher UI flows. It does **not** include the configured SQLCipher implementation, so offline-cache validation is not representative. Some native features can also differ from a custom build.

### Development build (recommended)

Create a development client, then start Metro:

```bash
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --profile development --platform android
# On macOS, or with an iOS simulator configured:
# npx eas-cli build --profile development --platform ios
npm start
```

Install the development build on the device/simulator and open the Metro development server. Alternatively, with local Android/iOS toolchains:

```bash
npm run prebuild
npm run android
# macOS with Xcode:
npm run ios
```

`prebuild` generates native projects; `android/` and `ios/` are ignored by Git. The SQLCipher Expo config plugin is enabled in `app.json`.

## Quality checks

```bash
npx expo install --check
npm run typecheck
npm run lint
npm test
```

To smoke-test JS bundling without producing a store binary:

```bash
npx expo export --platform android --platform ios --output-dir /tmp/fifo-mobile-export
```

There is currently a focused formatter unit-test suite. End-to-end device flows, broker-provider sandbox checks, and an SQLCipher custom-build test still need to be run before release.

## EAS builds

1. Run `npx eas-cli login` and `npx eas-cli build:configure` (or `npm run eas:configure`).
2. Attach the project with `npx eas-cli init` if prompted; commit the generated `extra.eas.projectId` in the Expo config.
3. Configure `EXPO_PUBLIC_API_URL` in the EAS preview and production environments as a **public HTTPS API base ending in `/api`**. Non-development profiles intentionally fail if it is missing or insecure.
4. Check native app identifiers before the first store build: `com.fifowealthos.mobile` for Android and `com.fifowealthos.mobile` for iOS. Change them before release if the organization has already claimed either identifier.
5. Run the relevant build command. EAS manages native signing credentials; review and retain them in EAS/your organization's secret manager.

### Google Play

```bash
npm run eas:android:production
# After reviewing the artifact and store listing:
npx eas-cli submit --platform android --profile production
```

The production Android profile creates an **AAB**. The submit profile targets the internal track by default; promote it through Play Console after testing. Provide the Play service-account credentials through EAS/secure configuration when prompted—never commit them.

### Apple App Store

```bash
npm run eas:ios:production
npx eas-cli submit --platform ios --profile production
```

The iOS production profile is a store build. EAS will request Apple Developer/App Store Connect credentials as needed. Review bundle identifier, privacy disclosures, Face ID/notification permission text, export-compliance answers, screenshots, and App Store Connect metadata before submission.

### Internal previews

```bash
npm run eas:android:preview
npx eas-cli build --profile preview --platform ios
```

The Android preview profile creates an APK for internal installation. The iOS preview profile is internal distribution and requires the appropriate Apple provisioning setup.

## Backend/API integration

- `GET /api/mobile/dashboard-summary` returns an authenticated compound summary using existing server-hydrated FIFO results, portfolio totals, symbol allocation, and recent transactions. Market-value basis is `LATEST_RECORDED_TRANSACTION_PRICE`.
- `GET /api/mobile/transactions/:portfolioId` returns newest-first cursor pages and supports `limit`, `cursor`, `type`, and `symbol`; ownership is checked by the API.
- Existing endpoints handle login/registration, portfolio creation, optional analytics, tax summaries/PDFs, IBKR, and Thai-broker status/connect/sync/disconnect.
- Mobile transaction and lot screens display server results; they do not reimplement or round the canonical FIFO engine. Decimal formatting is for display only.
- `GET /api/thai-brokers/status` exposes the current PDPA consent version so the mobile consent submission stays aligned with the backend.

## Security notes

- SecureStore contains the issued session/access token, minimal cached user identity, local lock preferences, reminder ID, and a random SQLCipher database key. The JWT signing secret is never shipped in the app.
- Broker credentials are entered into transient form state, sent to the API, and cleared after a successful response. They are never written to AsyncStorage, SQLite, or SecureStore.
- Tax-report PDFs are downloaded to temporary app cache only for the native share sheet and deleted afterward.
- Biometric unlock is optional and uses the device's enrolled authentication. Lock timeout can be immediate, one minute, or five minutes.
- Offline financial access is read-only and limited to cached dashboard/tax/transaction responses; a cache miss while offline cannot be reconstructed on-device.
- Test production API connectivity and server access controls on a real device before release. Do not distribute with a development API URL or development credentials.

## Troubleshooting

- **Preview/production config refuses to load:** set `EXPO_PUBLIC_API_URL` to the deployed HTTPS endpoint ending exactly in `/api` in the matching EAS environment.
- **Offline cache says unavailable:** install a custom development/production build with the SQLCipher plugin; Expo Go does not ship SQLCipher.
- **API unreachable on a phone:** use the development computer's LAN address, ensure the phone and computer share a network, and allow the API port through the local firewall. `10.0.2.2` is only for the Android emulator.
- **Broker connection fails:** ensure the backend encryption key is configured and use provider credentials with read-only permissions. Bitkub consent is mandatory; provider availability and account entitlement remain server-controlled.
- **PDF export returns an entitlement error:** enable the existing `taxReportPDF` entitlement for the account; no tax calculation is performed locally.
