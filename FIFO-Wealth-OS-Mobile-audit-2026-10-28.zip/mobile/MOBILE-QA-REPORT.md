# FIFO Wealth OS Mobile — QA Health Check

**Date:** 2026-10-28  
**Scope:** `/home/user/mobile` source, Expo configuration, route references, mobile API contracts, and the existing backend mobile API test coverage.  
**Result:** **Conditional pass — 82/100.** Static checks and Android/iOS JS exports pass. Do not treat this as a store-release sign-off until the manual-review items below are resolved.

## 1. Executive summary

- **Safe fixes applied:** 8 grouped fixes, limited to dependency/config alignment and mobile UI validation/error states.
- **Mobile typecheck:** pass.
- **Mobile lint:** pass with no warnings.
- **Mobile unit tests:** 6/6 pass.
- **Expo JS export:** Android and iOS bundles both pass.
- **Native prebuild configuration:** development and production prebuilds pass; production manifests disable cleartext/ATS exceptions.
- **Backend API validation:** root typecheck passes; `src/api/__tests__/api.test.ts` passes 43/43 tests, including the mobile endpoints.
- **Known exception:** Expo Doctor reports the Expo SDK 56 Hermes V1 memory regression. This requires an SDK migration decision; it was not auto-upgraded because that is a major native-toolchain change.
- **No financial engine, tax engine, database schema, backend endpoint, or authentication/session logic was changed during this QA pass.**

## 2. Safe auto-fixes applied

| # | Files | Fix | Why safe |
|---|---|---|---|
| 1 | `package.json`, `package-lock.json` | Restored a consistent Expo SDK 56 dependency tree after a partial SDK 57 install attempt; kept React Native and Expo modules on the SDK 56-compatible versions. | Dependency recovery only; avoids leaving mismatched native modules. |
| 2 | `package.json`, `package-lock.json` | Added SDK-aligned `expo-build-properties`, `expo-font`, and `expo-system-ui`; deduplicated the Expo font/native module tree. | Resolves native config/peer dependency warnings without changing application behavior. |
| 3 | `app.config.js`, `app.json` | Switched to Expo’s dynamic `config` input; moved Android cleartext configuration into the build-properties plugin; require HTTPS `/api` URLs for EAS preview and production, and disable cleartext/ATS exceptions outside development. | Build configuration only. Production and preview transports were verified by prebuild/config checks. |
| 4 | `app.json`, `assets/splash-logo.png` | Migrated splash setup to the `expo-splash-screen` plugin and added its compact logo asset. | Presentation/configuration only; native prebuild succeeded. |
| 5 | `app/(app)/(tabs)/activity.tsx` | Added an inline error and retry for failed next-page requests and prevented `onEndReached` from automatically retrying a failed page in a loop. | UI state/retry behavior only; cursor API and server data are unchanged. |
| 6 | `app/(app)/(tabs)/tax.tsx` | Validate optional other-income input before sending it, suppress stale results while the input is invalid, and disable PDF export when the portfolio/year/input is invalid. | Client-side payload/UI validation only; the Thai tax calculation remains server-side and unchanged. |
| 7 | `app/(app)/(tabs)/settings.tsx` | Catch local lock-timeout and sign-out promise errors in the UI; show a success alert after clearing cached snapshots. | Event/error presentation only; no authentication or lock policy was changed. |
| 8 | `README-MOBILE.md`, `.env.example` | Clarified that EAS preview and production require HTTPS, and documented the local-vs-remote notification boundary. | Documentation only. |

## 3. Navigation, UI, and API verification

### Navigation and UI

- Verified the nine concrete screens exist: onboarding, sign-in, registration, dashboard, activity, tax, settings, portfolio creation, and portfolio detail.
- Expo Router typed-route checks pass through `tsc`; tab and stack route names match the files under `app/`.
- Core screen controls have handlers, loading/error states, and empty states. The ledger now presents a recoverable error for a failed cursor page while retaining already-loaded rows.
- Tax-year and other-income validation prevents malformed optional input from being sent to the backend.

### API alignment

The mobile Axios client uses `EXPO_PUBLIC_API_URL` as the `/api` base; service paths are relative to it. Verified service alignment for:

- Authentication: `/auth/login`, `/auth/register`, `/auth/me`
- Portfolio creation: `/portfolios`
- Mobile summary and ledger: `/mobile/dashboard-summary`, `/mobile/transactions/:portfolioId`
- Thai tax summary/PDF: `/tax/summary/:portfolioId/:year`, `/tax/report/:portfolioId/:year`
- IBKR: `/sync/ibkr/connect`, `/sync/ibkr/trigger`, `/sync/ibkr/disconnect`
- Thai broker status/connect/disconnect: `/thai-brokers/...`

Network requests time out after 20 seconds; user-facing messages cover timeout and unreachable API cases. React Query reads encrypted cache fallbacks for supported snapshots. A bearer-authenticated 401 expires the local session and returns the protected app to sign-in; there is no refresh endpoint, so a seven-day token expiry requires a fresh sign-in. HTTP 403 responses are displayed as server errors rather than treated as sign-out.

The backend API test suite and strict typecheck pass; this QA pass did not alter backend endpoint behavior.

## 4. Build and validation status

| Check | Result |
|---|---|
| `npm run typecheck` (mobile) | **PASS** |
| `npm run lint` (mobile) | **PASS** |
| `npm test -- --runInBand` (mobile) | **PASS — 1 suite, 6 tests** |
| `npx expo install --check` | **PASS — dependencies aligned** |
| `npx expo export --platform android --platform ios --output-dir /tmp/fifo-mobile-export-final-2` | **PASS — Android and iOS bundles exported** |
| `npx expo prebuild --no-install --clean` (development profile) | **PASS**; generated Android cleartext and iOS ATS development allowances as configured |
| `EAS_BUILD_PROFILE=production EXPO_PUBLIC_API_URL=https://api.example.com/api npx expo prebuild --no-install --clean` | **PASS**; Android `usesCleartextTraffic=false`, iOS `NSAllowsArbitraryLoads=false` |
| Preview URL guard | **PASS**; HTTPS `/api` accepted and HTTP rejected |
| Root `npm run typecheck` | **PASS** |
| `npx jest src/api/__tests__/api.test.ts --runInBand --silent` | **PASS — 43 tests** |
| `expo-doctor` (22 checks) | **21/22**; the sole failure is the known SDK 56 Hermes V1 regression listed below |
| Native Android/iOS compile, install, and device E2E | **NOT RUN**; `adb` and `xcodebuild` are unavailable in this environment (JDK 11 only) |

The native prebuild directories generated for configuration verification were removed afterward; the managed Expo workspace remains clean.

## 5. Pending review items — manual action required

1. **Expo SDK 56 Hermes V1 regression:** Expo Doctor flags `expo@56.0.24` / Hermes V1 `250829098.0.10` as affected by a memory regression. Expo’s suggested remediation is SDK 57 / React Native 0.86.2+. That migration requires Node 22.13+ and a separately reviewed native dependency upgrade; it was deliberately not applied automatically.
2. **Dependency advisories:** `npm audit` reports **18 total** (12 low, 3 moderate, 3 high); `npm audit --omit=dev` reports **11** (5 low, 3 moderate, 3 high). High findings include Expo CLI/config and Zod transitives. The available automatic audit remediation is a breaking Expo downgrade or major dependency changes, so no force-fix was applied. Review and plan an SDK-aligned remediation.
3. **Device-level verification:** JS export and native prebuild are not equivalent to compiling/running an APK or IPA. Validate SecureStore, biometrics, SQLCipher offline reads/writes, notification permission/scheduling, PDF sharing, and expired-session redirects on development builds and physical devices. Expo Go does not provide the configured SQLCipher cache.
4. **Push scope:** current notification setting schedules a local weekly reminder only. There is no remote push-token registration/delivery service in the current backend integration.
5. **Broker UI scope:** IBKR has a sync action; Bitkub currently has status/connect/disconnect but no mobile sync action. Dime/Streaming are also not connected in this UI. Review product scope before describing mobile broker coverage as complete.
6. **Backend change review:** the previously added `/api/mobile/*` endpoints passed strict typecheck and their relevant assertions in the 43-test API suite, but remain backend/API changes and should receive the human review required by the project policy. The additive current-consent-version field was not explicitly asserted by that suite and should receive a focused test/review. No backend route or calculation edits were made in this QA pass.
7. **Release setup:** confirm the generic identifiers `com.fifowealthos.mobile`, EAS project linkage, signing credentials, and store privacy/notification disclosures before a store build.
8. **Tax accuracy boundary:** the Tax screen consumes the existing Thai tax engine only; it is not a U.S. tax-filing calculation. PDF export may return 403 when the existing `taxReportPDF` entitlement is absent.

## 6. Release recommendation

**Conditional pass for continued development.** Static checks, the cross-platform JavaScript export, and native config prebuild pass. Do not label the app release-ready until the SDK 56 Hermes issue is reviewed, dependency advisories are triaged, and custom native development builds complete device-level security and end-to-end testing.
