module.exports = ({ config }) => {
  const buildProfile = process.env.EAS_BUILD_PROFILE;
  const isDevelopmentBuild = !buildProfile || buildProfile === 'development';
  const apiUrl = process.env.EXPO_PUBLIC_API_URL?.trim();
  let productionApiUrlIsValid = false;

  if (apiUrl) {
    try {
      const parsed = new URL(apiUrl);
      productionApiUrlIsValid = parsed.protocol === 'https:'
        && parsed.pathname.replace(/\/+$/, '').endsWith('/api')
        && !parsed.username
        && !parsed.password
        && !parsed.search
        && !parsed.hash;
    } catch {
      productionApiUrlIsValid = false;
    }
  }

  if (!isDevelopmentBuild && !productionApiUrlIsValid) {
    throw new Error(
      'Preview and production builds require EXPO_PUBLIC_API_URL to be a deployed HTTPS API base ending in /api, with no embedded credentials or query string.',
    );
  }

  const plugins = (config.plugins ?? []).filter((plugin) => {
    const name = Array.isArray(plugin) ? plugin[0] : plugin;
    return name !== 'expo-build-properties';
  });

  return {
    ...config,
    plugins: [
      ...plugins,
      [
        'expo-build-properties',
        { android: { usesCleartextTraffic: isDevelopmentBuild } },
      ],
    ],
    ios: {
      ...config.ios,
      infoPlist: {
        ...config.ios?.infoPlist,
        NSAppTransportSecurity: {
          NSAllowsArbitraryLoads: isDevelopmentBuild,
        },
      },
    },
  };
};
