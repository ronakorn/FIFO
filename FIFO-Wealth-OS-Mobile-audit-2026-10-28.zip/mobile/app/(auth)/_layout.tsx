import { Redirect, Stack } from 'expo-router';
import { useAuth } from '@/auth/AuthProvider';
import { colors } from '@/theme/colors';

export default function AuthLayout(): React.JSX.Element {
  const { status } = useAuth();
  if (status === 'signed-in') return <Redirect href="/(app)/(tabs)" />;
  return <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.midnight } }} />;
}
