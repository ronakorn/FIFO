import { useLocalSearchParams } from 'expo-router';
import { Search, X } from 'lucide-react-native';
import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Pressable,
  RefreshControl,
  Text,
  TextInput,
  View,
} from 'react-native';
import type { Portfolio, Transaction } from '@/api/types';
import { useAuth } from '@/auth/AuthProvider';
import { Card, EmptyState, Eyebrow, InlineError, StatusPill } from '@/components/Primitives';
import { useMobileDashboard, useMobileTransactions } from '@/hooks/useMobileData';
import { formatDate, formatNumber, formatThb } from '@/lib/formatters';
import { colors } from '@/theme/colors';

const TYPE_FILTERS = ['ALL', 'BUY', 'SELL', 'FEE'] as const;
const EMPTY_PORTFOLIOS: Portfolio[] = [];
type TypeFilter = typeof TYPE_FILTERS[number];

function TransactionDetails({ transaction, onClose }: { transaction: Transaction | null; onClose: () => void }): React.JSX.Element {
  return (
    <Modal animationType="slide" transparent visible={transaction !== null} onRequestClose={onClose}>
      <View className="flex-1 justify-end bg-black/70">
        <View className="rounded-t-3xl border-t border-stroke bg-surface px-5 pb-10 pt-5">
          <View className="mb-5 flex-row items-center justify-between">
            <Text className="font-display text-lg font-bold text-ink">Transaction details</Text>
            <Pressable accessibilityRole="button" accessibilityLabel="Close details" onPress={onClose} className="h-10 w-10 items-center justify-center rounded-xl bg-raised"><X color={colors.ink} size={18} /></Pressable>
          </View>
          {transaction ? (
            <View className="gap-3">
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Asset</Text><Text className="font-body text-sm font-bold text-ink">{transaction.symbol} · {transaction.type}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Date</Text><Text className="font-body text-sm font-semibold text-ink">{formatDate(transaction.date)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Quantity</Text><Text className="font-body text-sm font-semibold text-ink">{formatNumber(transaction.qty, 8)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Unit price</Text><Text className="font-body text-sm font-semibold text-ink">{formatNumber(transaction.price, 4)} {transaction.originalCurrency}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Net amount</Text><Text className="font-body text-sm font-semibold text-ink">{formatThb(transaction.netTHB ?? transaction.net)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Original currency</Text><Text className="font-body text-sm font-semibold text-ink">{transaction.originalCurrency}</Text></View>
              <Text className="mt-2 font-body text-xs leading-5 text-muted">This is an imported ledger record. FIFO matching and tax results are computed by the backend.</Text>
            </View>
          ) : null}
        </View>
      </View>
    </Modal>
  );
}

function PortfolioChips({ portfolios, selectedId, onSelect }: { portfolios: Portfolio[]; selectedId: string; onSelect: (id: string) => void }): React.JSX.Element {
  return (
    <View className="mb-4">
      <Eyebrow>PORTFOLIO</Eyebrow>
      <FlatList
        className="mt-2"
        data={portfolios}
        horizontal
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Pressable
            accessibilityRole="button"
            accessibilityState={{ selected: selectedId === item.id }}
            className={`mr-2 rounded-full border px-3 py-2 ${selectedId === item.id ? 'border-accent bg-accent/20' : 'border-stroke bg-surface'}`}
            onPress={() => onSelect(item.id)}
          >
            <Text className={`font-body text-xs font-bold ${selectedId === item.id ? 'text-accent-bright' : 'text-muted'}`}>{item.name}</Text>
          </Pressable>
        )}
        showsHorizontalScrollIndicator={false}
      />
    </View>
  );
}

export default function ActivityScreen(): React.JSX.Element {
  const params = useLocalSearchParams<{ portfolioId?: string }>();
  const { status } = useAuth();
  const dashboard = useMobileDashboard();
  const portfolios = dashboard.data?.value.portfolios ?? EMPTY_PORTFOLIOS;
  const requestedId = Array.isArray(params.portfolioId) ? params.portfolioId[0] : params.portfolioId;
  const [manuallySelectedId, setManuallySelectedId] = useState('');
  const selectedPortfolioId = portfolios.some((portfolio) => portfolio.id === manuallySelectedId)
    ? manuallySelectedId
    : requestedId && portfolios.some((portfolio) => portfolio.id === requestedId)
      ? requestedId
      : portfolios[0]?.id ?? '';
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('ALL');
  const [symbolInput, setSymbolInput] = useState('');
  const [appliedSymbol, setAppliedSymbol] = useState<string | undefined>();
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  const query = useMobileTransactions(
    selectedPortfolioId || undefined,
    {
      ...(typeFilter !== 'ALL' ? { type: typeFilter } : {}),
      ...(appliedSymbol ? { symbol: appliedSymbol } : {}),
    },
  );
  const items = useMemo(() => query.data?.pages.flatMap((page) => page.items) ?? [], [query.data?.pages]);
  const cached = query.data?.pages.some((page) => page.cached) ?? false;

  const applySearch = (): void => setAppliedSymbol(symbolInput.trim() ? symbolInput.trim().toUpperCase() : undefined);
  const refresh = (): void => { void dashboard.refetch(); void query.refetch(); };

  const header = (
    <View>
      <View className="mb-5">
        <Eyebrow>LEDGER · CURSOR PAGINATION</Eyebrow>
        <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Activity</Text>
        <Text className="mt-1 font-body text-sm text-muted">Newest first · server paginated</Text>
      </View>
      {cached ? <View className="mb-4 rounded-xl border border-gold/30 bg-gold/10 px-3 py-2"><Text className="font-body text-xs text-gold">Offline · encrypted cached ledger pages</Text></View> : null}
      {portfolios.length ? (
        <PortfolioChips portfolios={portfolios} selectedId={selectedPortfolioId} onSelect={setManuallySelectedId} />
      ) : null}
      <View className="mb-3 flex-row gap-2">
        {TYPE_FILTERS.map((filter) => (
          <Pressable
            key={filter}
            accessibilityRole="button"
            accessibilityState={{ selected: typeFilter === filter }}
            className={`rounded-full border px-3 py-2 ${typeFilter === filter ? 'border-accent bg-accent/20' : 'border-stroke bg-surface'}`}
            onPress={() => setTypeFilter(filter)}
          >
            <Text className={`font-body text-[11px] font-bold ${typeFilter === filter ? 'text-accent-bright' : 'text-muted'}`}>{filter === 'ALL' ? 'All' : filter}</Text>
          </Pressable>
        ))}
      </View>
      <View className="mb-4 flex-row items-center rounded-2xl border border-stroke bg-raised px-3">
        <Search color={colors.muted} size={17} />
        <TextInput
          accessibilityLabel="Search transaction symbol"
          className="min-h-11 flex-1 px-3 font-body text-sm text-ink"
          placeholder="Search symbol"
          placeholderTextColor="#6E7382"
          autoCapitalize="characters"
          autoCorrect={false}
          returnKeyType="search"
          value={symbolInput}
          onChangeText={setSymbolInput}
          onSubmitEditing={applySearch}
        />
        <Pressable accessibilityRole="button" accessibilityLabel="Apply symbol filter" onPress={applySearch} className="px-2 py-3"><Text className="font-body text-xs font-bold text-accent-bright">Apply</Text></Pressable>
      </View>
      <Card className="mb-4 py-3"><Text className="font-body text-[11px] leading-4 text-muted">Ledger data is cached only in SQLCipher storage. Offline access is read-only; reconnect to refresh or sync.</Text></Card>
    </View>
  );

  if (dashboard.isPending && !dashboard.data) {
    return <View className="flex-1 items-center justify-center bg-midnight"><ActivityIndicator color={colors.accentBright} /></View>;
  }
  if (dashboard.isError && !dashboard.data) {
    return <View className="flex-1 justify-center bg-midnight px-5"><InlineError message={dashboard.error.message} onRetry={() => { void dashboard.refetch(); }} /></View>;
  }
  if (status !== 'signed-in') return <View className="flex-1 bg-midnight" />;
  if (dashboard.data && portfolios.length === 0) {
    return (
      <View className="flex-1 bg-midnight px-5 pt-10">
        <Eyebrow>LEDGER · CURSOR PAGINATION</Eyebrow>
        <Text className="mb-6 mt-2 font-display text-2xl font-extrabold text-ink">Activity</Text>
        <EmptyState title="Create a portfolio first" message="Once you have a portfolio, imported and connected transactions will appear here." />
      </View>
    );
  }

  return (
    <View className="flex-1 bg-midnight">
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Pressable accessibilityRole="button" className="mb-3 rounded-2xl border border-stroke bg-surface p-4 active:bg-raised" onPress={() => setSelectedTransaction(item)}>
            <View className="flex-row items-center justify-between gap-3">
              <View className="flex-1">
                <View className="flex-row items-center gap-2">
                  <Text className="font-display text-sm font-bold text-ink">{item.symbol}</Text>
                  <StatusPill label={item.type} tone={item.type === 'BUY' ? 'bad' : 'good'} />
                </View>
                <Text className="mt-1 font-body text-xs text-muted">{formatDate(item.date)} · {formatNumber(item.qty, 8)} units</Text>
              </View>
              <View className="items-end">
                <Text className="font-display text-sm font-bold text-ink">{formatThb(item.netTHB ?? item.net)}</Text>
                <Text className="mt-1 font-body text-[10px] text-muted">{item.originalCurrency}</Text>
              </View>
            </View>
          </Pressable>
        )}
        ListHeaderComponent={header}
        ListEmptyComponent={query.isPending ? <View className="py-8"><ActivityIndicator color={colors.accentBright} /></View> : query.isError ? <InlineError message={query.error.message} onRetry={() => { void query.refetch(); }} /> : <EmptyState title="No transactions found" message="Try another symbol filter or import a ledger through the web app." />}
        ListFooterComponent={
          <View className="items-center py-5">
            {query.isFetchingNextPage ? <ActivityIndicator accessibilityLabel="Loading more transactions" color={colors.accentBright} /> : null}
            {query.isFetchNextPageError ? (
              <View className="w-full">
                <InlineError
                  message={query.error?.message ?? 'Could not load the next ledger page.'}
                  onRetry={() => { void query.fetchNextPage(); }}
                />
              </View>
            ) : null}
            {!query.hasNextPage && items.length > 0 ? <Text className="font-body text-xs text-muted">End of ledger</Text> : null}
            {query.hasNextPage && !query.isFetchingNextPage && !query.isFetchNextPageError ? (
              <Pressable accessibilityRole="button" accessibilityLabel="Load more transactions" onPress={() => { void query.fetchNextPage(); }} className="rounded-xl border border-stroke bg-surface px-4 py-2.5">
                <Text className="font-body text-xs font-bold text-ink">Load more</Text>
              </Pressable>
            ) : null}
          </View>
        }
        onEndReached={() => {
          if (query.hasNextPage && !query.isFetchingNextPage && !query.isFetchNextPageError) void query.fetchNextPage();
        }}
        onEndReachedThreshold={0.45}
        refreshControl={<RefreshControl refreshing={dashboard.isRefetching || query.isRefetching} onRefresh={refresh} tintColor={colors.accentBright} colors={[colors.accentBright]} />}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 120, flexGrow: 1 }}
        showsVerticalScrollIndicator={false}
      />
      <TransactionDetails transaction={selectedTransaction} onClose={() => setSelectedTransaction(null)} />
    </View>
  );
}
