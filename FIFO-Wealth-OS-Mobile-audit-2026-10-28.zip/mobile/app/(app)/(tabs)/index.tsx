import { Link, useRouter } from 'expo-router';
import { ArrowDownRight, ArrowUpRight, Plus, RefreshCw, TrendingUp } from 'lucide-react-native';
import { useState } from 'react';
import { Pressable, RefreshControl, Text, View } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import { Button, Card, EmptyState, Eyebrow, InlineError, SectionTitle, StatusPill } from '@/components/Primitives';
import { AllocationDonut, allocationColor, PerformanceChart, type AllocationDatum } from '@/components/Charts';
import { Screen } from '@/components/Screen';
import { useDashboardAnalytics, useMobileDashboard } from '@/hooks/useMobileData';
import { formatDate, formatPercentRatio, formatThb } from '@/lib/formatters';
import { colors } from '@/theme/colors';

export default function DashboardScreen(): React.JSX.Element {
  const router = useRouter();
  const { user } = useAuth();
  const dashboard = useMobileDashboard();
  const [benchmark, setBenchmark] = useState<'SP500' | 'SET50'>('SP500');
  const analytics = useDashboardAnalytics(benchmark);
  const summary = dashboard.data?.value;
  const metrics = analytics.data?.value;
  const allocation: AllocationDatum[] = metrics?.assetAllocation.length
    ? metrics.assetAllocation.map((item) => ({
      key: item.category,
      label: item.enLabel,
      weightPct: item.weightPct,
    }))
    : (summary?.allocation ?? []).map((item) => ({
      key: item.symbol,
      label: item.symbol,
      weightPct: item.weightPct,
    }));

  const refresh = (): void => {
    void dashboard.refetch();
    void analytics.refetch();
  };

  const refreshControl = (
    <RefreshControl
      refreshing={dashboard.isRefetching || analytics.isRefetching}
      onRefresh={refresh}
      tintColor={colors.accentBright}
      colors={[colors.accentBright]}
    />
  );

  if (dashboard.isPending && !summary) {
    return (
      <Screen>
        <View className="h-6 w-32 rounded-lg bg-raised" />
        <View className="mt-5 h-52 rounded-3xl bg-surface" />
        <View className="mt-4 h-44 rounded-3xl bg-surface" />
      </Screen>
    );
  }

  if (dashboard.isError && !summary) {
    return (
      <Screen>
        <InlineError message={dashboard.error.message} onRetry={refresh} />
      </Screen>
    );
  }

  return (
    <Screen refreshControl={refreshControl}>
      <View className="mb-5 flex-row items-start justify-between">
        <View className="flex-1 pr-3">
          <Eyebrow>FIFO WEALTH OS · PRIVATE PORTFOLIO</Eyebrow>
          <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Hello, {user?.name?.split(' ')[0] ?? 'Investor'}</Text>
          <Text className="mt-1 font-body text-sm text-muted">Your wealth at a glance.</Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Refresh dashboard"
          className="h-11 w-11 items-center justify-center rounded-2xl border border-stroke bg-surface"
          onPress={refresh}
        >
          <RefreshCw color={colors.ink} size={18} />
        </Pressable>
      </View>

      {dashboard.data?.stale ? (
        <View className="mb-4 rounded-2xl border border-gold/30 bg-gold/10 px-4 py-3">
          <Text className="font-body text-xs font-semibold text-gold">Offline view · showing your last encrypted snapshot.</Text>
        </View>
      ) : null}

      <Card className="overflow-hidden border-accent/30 bg-[#101118] p-5">
        <View className="flex-row items-center justify-between">
          <Eyebrow>Combined portfolio value · THB</Eyebrow>
          <StatusPill label={dashboard.data?.stale ? 'Cached' : 'As of now'} tone={dashboard.data?.stale ? 'muted' : 'good'} />
        </View>
        <Text className="mt-4 font-display text-3xl font-extrabold tracking-tight text-ink">{formatThb(summary?.summary.marketValueTHB)}</Text>
        <Text className="mt-2 font-body text-xs leading-5 text-muted">Estimated from the latest transaction mark recorded by the backend—not a live quote.</Text>
        <View className="mt-5 flex-row gap-3">
          <View className="flex-1 rounded-2xl bg-raised p-3">
            <Eyebrow>Open cost basis</Eyebrow>
            <Text className="mt-2 font-display text-base font-bold text-ink">{formatThb(summary?.summary.openCostBasisTHB)}</Text>
          </View>
          <View className="flex-1 rounded-2xl bg-raised p-3">
            <Eyebrow>Unrealized G/L</Eyebrow>
            <Text className={`mt-2 font-display text-base font-bold ${Number(summary?.summary.unrealizedGLTHB ?? 0) >= 0 ? 'text-gain' : 'text-loss'}`}>
              {formatThb(summary?.summary.unrealizedGLTHB)}
            </Text>
          </View>
        </View>
        <View className="mt-3 flex-row items-center justify-between border-t border-stroke pt-3">
          <Text className="font-body text-xs text-muted">Realized gain/loss</Text>
          <Text className="font-display text-sm font-bold text-ink">{formatThb(summary?.summary.realizedGLTHB)}</Text>
        </View>
      </Card>

      <View className="mt-7 flex-row items-center justify-between">
        <SectionTitle title="Portfolios" />
        <Link href="/(app)/portfolio/new" asChild>
          <Pressable accessibilityRole="button" className="mb-3 flex-row items-center gap-1 rounded-xl bg-accent/15 px-3 py-2">
            <Plus color={colors.accentBright} size={15} />
            <Text className="font-body text-xs font-bold text-accent-bright">New</Text>
          </Pressable>
        </Link>
      </View>
      {summary?.portfolios.length ? (
        <View className="gap-3">
          {summary.portfolios.map((portfolio) => (
            <Pressable
              key={portfolio.id}
              accessibilityRole="button"
              className="rounded-2xl border border-stroke bg-surface p-4 active:bg-raised"
              onPress={() => router.push({ pathname: '/(app)/portfolio/[id]', params: { id: portfolio.id } })}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-1 pr-3">
                  <Text className="font-display text-sm font-bold text-ink">{portfolio.name}</Text>
                  <Text className="mt-1 font-body text-xs text-muted">{portfolio.transactionCount ?? 0} transactions · {portfolio.baseCurrency}</Text>
                </View>
                <Text className="font-display text-sm font-bold text-ink">{formatThb(portfolio.fifoSummary?.marketValueTHB)}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      ) : (
        <EmptyState title="No portfolios yet" message="Create your first portfolio to start tracking transactions and FIFO lots." />
      )}

      <View className="mt-7">
        <SectionTitle title="Asset mix" />
        {allocation.length ? (
          <Card>
            <View className="flex-row items-center gap-4">
              <AllocationDonut allocation={allocation} />
              <View className="flex-1 gap-3">
                {allocation.slice(0, 5).map((item, index) => (
                  <View key={item.key} className="flex-row items-center gap-2">
                    <View className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: allocationColor(index) }} />
                    <Text numberOfLines={1} className="flex-1 font-body text-xs text-muted">{item.label}</Text>
                    <Text className="font-body text-xs font-bold text-ink">{item.weightPct}%</Text>
                  </View>
                ))}
              </View>
            </View>
            {!metrics ? <Text className="mt-3 font-body text-[11px] leading-4 text-muted">Showing current open holdings by symbol. Category analytics may require the advanced-analytics entitlement.</Text> : null}
          </Card>
        ) : (
          <EmptyState title="No open holdings" message="Allocation appears when your portfolio contains open positions." />
        )}
      </View>

      <View className="mt-7">
        <View className="mb-3 flex-row items-center justify-between">
          <Text className="font-display text-base font-bold text-ink">Performance</Text>
          <View className="flex-row rounded-xl border border-stroke bg-surface p-1">
            {(['SP500', 'SET50'] as const).map((item) => (
              <Pressable
                key={item}
                accessibilityRole="button"
                accessibilityState={{ selected: benchmark === item }}
                className={`rounded-lg px-2.5 py-1.5 ${benchmark === item ? 'bg-raised' : ''}`}
                onPress={() => setBenchmark(item)}
              >
                <Text className={`font-body text-[10px] font-bold ${benchmark === item ? 'text-ink' : 'text-muted'}`}>{item === 'SP500' ? 'S&P 500' : 'SET50'}</Text>
              </Pressable>
            ))}
          </View>
        </View>
        <Card>
          {metrics?.benchmarkSeries.length ? (
            <>
              <PerformanceChart series={metrics.benchmarkSeries} />
              <View className="mt-2 flex-row items-center gap-4">
                <View className="flex-row items-center gap-1.5"><View className="h-2 w-2 rounded-full bg-accent-bright" /><Text className="font-body text-[10px] text-muted">Portfolio</Text></View>
                <View className="flex-row items-center gap-1.5"><View className="h-2 w-2 rounded-full bg-muted" /><Text className="font-body text-[10px] text-muted">{benchmark}</Text></View>
                <Text className="ml-auto font-body text-[10px] text-muted">{metrics.asOfDate}</Text>
              </View>
              <View className="mt-4 flex-row gap-3">
                <View className="flex-1 rounded-xl bg-raised p-3"><Eyebrow>XIRR</Eyebrow><Text className="mt-1 font-display text-sm font-bold text-ink">{formatPercentRatio(metrics.metrics.xirr)}</Text></View>
                <View className="flex-1 rounded-xl bg-raised p-3"><Eyebrow>Total return</Eyebrow><Text className="mt-1 font-display text-sm font-bold text-ink">{formatPercentRatio(metrics.metrics.totalReturn)}</Text></View>
                <View className="flex-1 rounded-xl bg-raised p-3"><Eyebrow>Max drawdown</Eyebrow><Text className="mt-1 font-display text-sm font-bold text-ink">{formatPercentRatio(metrics.metrics.maxDrawdown)}</Text></View>
              </View>
            </>
          ) : analytics.isError ? (
            <Text className="font-body text-sm leading-5 text-muted">Performance analytics are unavailable for this account or network. Portfolio totals remain available.</Text>
          ) : (
            <View className="h-36 items-center justify-center"><TrendingUp color={colors.muted} size={24} /><Text className="mt-3 font-body text-sm text-muted">Loading server-calculated history…</Text></View>
          )}
        </Card>
      </View>

      <View className="mt-7">
        <SectionTitle title="Recent activity" />
        {summary?.recentTransactions.length ? (
          <Card className="gap-4">
            {summary.recentTransactions.slice(0, 5).map((transaction) => {
              const positive = transaction.type === 'BUY';
              const Icon = positive ? ArrowDownRight : ArrowUpRight;
              return (
                <View key={transaction.id} className="flex-row items-center gap-3">
                  <View className={`h-10 w-10 items-center justify-center rounded-xl ${positive ? 'bg-accent/15' : 'bg-gain/10'}`}>
                    <Icon color={positive ? colors.accentBright : colors.gain} size={18} />
                  </View>
                  <View className="flex-1">
                    <Text className="font-display text-sm font-bold text-ink">{transaction.symbol} · {transaction.type}</Text>
                    <Text className="mt-0.5 font-body text-xs text-muted">{formatDate(transaction.date)}</Text>
                  </View>
                  <Text className="font-body text-sm font-semibold text-ink">{formatThb(transaction.netTHB ?? transaction.net)}</Text>
                </View>
              );
            })}
          </Card>
        ) : (
          <EmptyState title="No activity yet" message="Your imported or connected transactions will appear here." />
        )}
        <View className="mt-3">
          <Button title="View transaction ledger" variant="secondary" onPress={() => router.push('/(app)/(tabs)/activity')} />
        </View>
      </View>

      {dashboard.isError && summary ? (
        <View className="mt-4"><InlineError message="Showing encrypted cached values because the latest refresh failed." onRetry={refresh} /></View>
      ) : null}
    </Screen>
  );
}
