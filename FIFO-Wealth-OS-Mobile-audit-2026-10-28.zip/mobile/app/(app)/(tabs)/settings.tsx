import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Alert, Pressable, Switch, Text, View } from 'react-native';
import { brokerApi } from '@/api/services';
import { getApiErrorMessage } from '@/api/client';
import type { LockTimeout } from '@/auth/tokenStore';
import { isWeeklyReminderEnabled } from '@/auth/tokenStore';
import { useAuth } from '@/auth/AuthProvider';
import { Button, Card, Eyebrow, Field, InlineError, SectionTitle, StatusPill } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { clearSecureCache, isEncryptedCacheAvailable } from '@/cache/secureCache';
import { disableWeeklyTaxReminder, enableWeeklyTaxReminder } from '@/features/settings/reminders';
import { useMobileDashboard } from '@/hooks/useMobileData';
import { colors } from '@/theme/colors';
import { useEffect, useState } from 'react';

const LOCK_OPTIONS: { value: LockTimeout; label: string }[] = [
  { value: 'immediately', label: 'Immediately' },
  { value: 'one-minute', label: '1 min' },
  { value: 'five-minutes', label: '5 min' },
];

export default function SettingsScreen(): React.JSX.Element {
  const queryClient = useQueryClient();
  const { user, biometricEnabled, enableBiometricLock, disableBiometricLock, lockTimeout, updateLockTimeout, signOut } = useAuth();
  const dashboard = useMobileDashboard();
  const defaultPortfolioId = dashboard.data?.value.portfolios[0]?.id;
  const [flexQueryToken, setFlexQueryToken] = useState('');
  const [flexQueryId, setFlexQueryId] = useState('');
  const [bitkubApiKey, setBitkubApiKey] = useState('');
  const [bitkubApiSecret, setBitkubApiSecret] = useState('');
  const [pdpaConsent, setPdpaConsent] = useState(false);
  const [brokerMessage, setBrokerMessage] = useState('');
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [encryptedCacheAvailable, setEncryptedCacheAvailable] = useState(false);
  const [localSettingsError, setLocalSettingsError] = useState('');

  const ibkrQuery = useQuery({
    queryKey: ['mobile-ibkr-status'],
    queryFn: () => brokerApi.ibkrStatus(),
    staleTime: 60_000,
    retry: false,
  });
  const thaiBrokerQuery = useQuery({
    queryKey: ['mobile-thai-broker-status'],
    queryFn: () => brokerApi.thaiBrokerStatus(),
    staleTime: 60_000,
    retry: false,
  });

  useEffect(() => {
    let active = true;
    void Promise.all([isWeeklyReminderEnabled(), isEncryptedCacheAvailable()]).then(([reminder, cache]) => {
      if (!active) return;
      setReminderEnabled(reminder);
      setEncryptedCacheAvailable(cache);
    }).catch(() => {
      if (active) setLocalSettingsError('Secure local settings are unavailable on this build.');
    });
    return () => { active = false; };
  }, []);

  const connectIbkr = useMutation({
    mutationFn: () => brokerApi.connectIbkr({
      flexQueryToken: flexQueryToken.trim(),
      flexQueryId: flexQueryId.trim(),
      ...(defaultPortfolioId ? { portfolioId: defaultPortfolioId } : {}),
    }),
    onSuccess: async () => {
      setFlexQueryToken('');
      setFlexQueryId('');
      setBrokerMessage('IBKR credentials were submitted to the server and cleared from the form.');
      await queryClient.invalidateQueries({ queryKey: ['mobile-ibkr-status'] });
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const connectBitkub = useMutation({
    mutationFn: () => brokerApi.connectBitkub({
      apiKey: bitkubApiKey.trim(),
      apiSecret: bitkubApiSecret.trim(),
      ...(defaultPortfolioId ? { portfolioId: defaultPortfolioId } : {}),
      permissionsScope: 'READ_ONLY',
      pdpaConsent: {
        accepted: true,
        consentVersion: thaiBrokerQuery.data?.currentConsentVersion ?? '',
        purposes: ['READ_ONLY_PORTFOLIO_SYNC'],
      },
    }),
    onSuccess: async () => {
      setBitkubApiKey('');
      setBitkubApiSecret('');
      setPdpaConsent(false);
      setBrokerMessage('Bitkub read-only credentials were submitted to the server and cleared from the form.');
      await queryClient.invalidateQueries({ queryKey: ['mobile-thai-broker-status'] });
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const disconnectIbkr = useMutation({
    mutationFn: () => brokerApi.disconnectIbkr(),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['mobile-ibkr-status'] });
      setBrokerMessage('IBKR connection disconnected and encrypted credentials removed.');
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const disconnectBitkub = useMutation({
    mutationFn: () => brokerApi.disconnectThaiBroker('BITKUB'),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['mobile-thai-broker-status'] });
      setBrokerMessage('Bitkub was disconnected. The backend applied its purge-data policy.');
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const syncIbkr = useMutation({
    mutationFn: () => brokerApi.syncIbkr(defaultPortfolioId),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['mobile-ibkr-status'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-dashboard-summary'] }),
      ]);
      setBrokerMessage('IBKR sync completed. Refresh the dashboard to review imported transactions.');
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const handleBiometricToggle = (value: boolean): void => {
    setLocalSettingsError('');
    if (value) {
      void enableBiometricLock().then((enabled) => {
        if (!enabled) setLocalSettingsError('Biometrics are unavailable or not enrolled on this device.');
      }).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    } else {
      void disableBiometricLock().catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    }
  };

  const handleReminderToggle = (value: boolean): void => {
    setLocalSettingsError('');
    if (value) {
      void enableWeeklyTaxReminder().then((enabled) => {
        setReminderEnabled(enabled);
        if (!enabled) setLocalSettingsError('Notification permission was not granted.');
      }).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    } else {
      void disableWeeklyTaxReminder().then(() => setReminderEnabled(false)).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    }
  };

  const confirmDisconnectIbkr = (): void => {
    Alert.alert('Disconnect IBKR?', 'This removes the encrypted Flex Query credentials from the server. Imported transactions remain.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Disconnect', style: 'destructive', onPress: () => disconnectIbkr.mutate() },
    ]);
  };

  const confirmDisconnectBitkub = (): void => {
    Alert.alert('Disconnect Bitkub and purge synced data?', 'The backend will revoke consent, remove encrypted credentials, and purge imported Bitkub transactions and dividends. This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Purge & disconnect', style: 'destructive', onPress: () => disconnectBitkub.mutate() },
    ]);
  };

  const clearOfflineData = (): void => {
    Alert.alert('Clear offline snapshots?', 'This removes cached portfolio and transaction data from this device. Server data is not affected.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: () => {
        void clearSecureCache().then(() => {
          queryClient.removeQueries({ queryKey: ['mobile-dashboard-summary'] });
          queryClient.removeQueries({ queryKey: ['mobile-transactions'] });
          setLocalSettingsError('');
          Alert.alert('Offline snapshots cleared', 'Encrypted portfolio and transaction cache entries were removed from this device.');
        }).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
      } },
    ]);
  };

  const handleSignOut = (): void => {
    Alert.alert('Sign out?', 'Encrypted offline snapshots will be cleared from this device.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: () => {
        void signOut().catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
      } },
    ]);
  };

  const bitkub = thaiBrokerQuery.data?.connections.find((connection) => connection.broker === 'BITKUB');
  const anyBrokerBusy = connectIbkr.isPending || connectBitkub.isPending || disconnectIbkr.isPending || disconnectBitkub.isPending || syncIbkr.isPending;

  return (
    <Screen>
      <Eyebrow>DEVICE & ACCOUNT</Eyebrow>
      <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Settings</Text>
      <Text className="mt-1 font-body text-sm text-muted">{user?.email ?? 'Investor account'}</Text>

      <View className="mt-6">
        <SectionTitle title="App security" />
        <Card className="gap-4">
          <View className="flex-row items-center justify-between gap-4">
            <View className="flex-1"><Text className="font-body text-sm font-bold text-ink">Biometric app lock</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">Use Face ID or fingerprint when reopening the app.</Text></View>
            <Switch value={biometricEnabled} onValueChange={handleBiometricToggle} trackColor={{ false: colors.stroke, true: colors.accent }} thumbColor={biometricEnabled ? '#FFFFFF' : '#D0D2D9'} />
          </View>
          <View className="border-t border-stroke pt-4">
            <Text className="font-body text-xs font-bold uppercase tracking-widest text-muted">Lock after backgrounding</Text>
            <View className="mt-3 flex-row gap-2">
              {LOCK_OPTIONS.map((option) => (
                <Pressable key={option.value} accessibilityRole="button" accessibilityState={{ selected: lockTimeout === option.value }} onPress={() => {
                  setLocalSettingsError('');
                  void updateLockTimeout(option.value).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
                }} className={`flex-1 items-center rounded-xl border px-2 py-2.5 ${lockTimeout === option.value ? 'border-accent bg-accent/15' : 'border-stroke bg-raised'}`}>
                  <Text className={`font-body text-[11px] font-bold ${lockTimeout === option.value ? 'text-accent-bright' : 'text-muted'}`}>{option.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View className="border-t border-stroke pt-4">
            <View className="flex-row items-center justify-between gap-4">
              <View className="flex-1"><Text className="font-body text-sm font-bold text-ink">Weekly tax reminder</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">Device-local reminder every Monday at 9:00. No remote push service is configured.</Text></View>
              <Switch value={reminderEnabled} onValueChange={handleReminderToggle} trackColor={{ false: colors.stroke, true: colors.accent }} thumbColor={reminderEnabled ? '#FFFFFF' : '#D0D2D9'} />
            </View>
          </View>
        </Card>
      </View>

      <View className="mt-7">
        <SectionTitle title="Encrypted offline cache" />
        <Card>
          <View className="flex-row items-center justify-between">
            <View className="flex-1 pr-3"><Text className="font-body text-sm font-bold text-ink">SQLCipher storage</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">Dashboard and ledger snapshots use an installation-specific key kept in SecureStore.</Text></View>
            <StatusPill label={encryptedCacheAvailable ? 'Encrypted' : 'Unavailable'} tone={encryptedCacheAvailable ? 'good' : 'bad'} />
          </View>
          <Button className="mt-4" title="Clear offline snapshots" variant="secondary" onPress={clearOfflineData} />
        </Card>
      </View>

      <View className="mt-7">
        <SectionTitle title="Broker connections" />
        <Card className="gap-4">
          <View className="flex-row items-center justify-between"><View><Text className="font-display text-sm font-bold text-ink">Interactive Brokers</Text><Text className="mt-1 font-body text-xs text-muted">Flex Query · read-only</Text></View><StatusPill label={ibkrQuery.data?.connected ? ibkrQuery.data.status : 'Disconnected'} tone={ibkrQuery.data?.connected ? 'good' : 'muted'} /></View>
          {ibkrQuery.isError ? <InlineError message={getApiErrorMessage(ibkrQuery.error)} onRetry={() => { void ibkrQuery.refetch(); }} /> : null}
          {!ibkrQuery.data?.connected ? (
            <>
              <Field label="Flex Query token" value={flexQueryToken} onChangeText={setFlexQueryToken} secureTextEntry autoCapitalize="none" placeholder="Token" />
              <Field label="Flex Query ID" value={flexQueryId} onChangeText={setFlexQueryId} keyboardType="number-pad" placeholder="Query ID" />
              <Button title="Connect IBKR" loading={connectIbkr.isPending} disabled={!flexQueryToken.trim() || !flexQueryId.trim()} onPress={() => { setBrokerMessage(''); connectIbkr.mutate(); }} />
            </>
          ) : (
            <View className="flex-row gap-2"><Button className="flex-1" title="Sync now" loading={syncIbkr.isPending} onPress={() => syncIbkr.mutate()} /><Button className="flex-1" title="Disconnect" variant="danger" loading={disconnectIbkr.isPending} onPress={confirmDisconnectIbkr} /></View>
          )}
        </Card>

        <Card className="mt-3 gap-4">
          <View className="flex-row items-center justify-between"><View><Text className="font-display text-sm font-bold text-ink">Bitkub</Text><Text className="mt-1 font-body text-xs text-muted">API key · read-only</Text></View><StatusPill label={bitkub?.connected ? bitkub.status ?? 'Connected' : 'Disconnected'} tone={bitkub?.connected ? 'good' : 'muted'} /></View>
          {thaiBrokerQuery.isError ? <InlineError message={getApiErrorMessage(thaiBrokerQuery.error)} onRetry={() => { void thaiBrokerQuery.refetch(); }} /> : null}
          {!bitkub?.connected ? (
            <>
              <Field label="Bitkub API key" value={bitkubApiKey} onChangeText={setBitkubApiKey} secureTextEntry autoCapitalize="none" placeholder="Read-only API key" />
              <Field label="Bitkub API secret" value={bitkubApiSecret} onChangeText={setBitkubApiSecret} secureTextEntry autoCapitalize="none" placeholder="API secret" />
              <Pressable accessibilityRole="checkbox" accessibilityState={{ checked: pdpaConsent }} className="flex-row items-start gap-3 rounded-xl border border-stroke bg-raised p-3" onPress={() => setPdpaConsent((current) => !current)}>
                <View className={`mt-0.5 h-5 w-5 items-center justify-center rounded-md border ${pdpaConsent ? 'border-accent bg-accent' : 'border-muted'}`}>{pdpaConsent ? <Text className="text-xs font-bold text-white">✓</Text> : null}</View>
                <Text className="flex-1 font-body text-xs leading-5 text-muted">I consent to read-only Bitkub sync for portfolio import and understand the broker data privacy notice.</Text>
              </Pressable>
              <Button title="Connect Bitkub" loading={connectBitkub.isPending} disabled={!bitkubApiKey.trim() || !bitkubApiSecret.trim() || !pdpaConsent} onPress={() => { setBrokerMessage(''); connectBitkub.mutate(); }} />
            </>
          ) : (
            <Button title="Disconnect & purge synced data" variant="danger" loading={disconnectBitkub.isPending} onPress={confirmDisconnectBitkub} />
          )}
          <Text className="font-body text-[11px] leading-5 text-muted">Credentials are sent only to the API and never cached on-device. The existing backend encrypts broker credentials at rest using AES-256-GCM. Production requires HTTPS and a configured server ENCRYPTION_KEY.</Text>
          {brokerMessage ? <Text accessibilityRole="alert" className="font-body text-xs leading-5 text-muted">{brokerMessage}</Text> : null}
          {anyBrokerBusy ? <Text className="font-body text-xs text-muted">Securely processing broker request…</Text> : null}
        </Card>
      </View>

      {localSettingsError ? <View className="mt-4"><InlineError message={localSettingsError} /></View> : null}
      <Card className="mt-7">
        <Text className="font-display text-sm font-bold text-ink">Session security</Text>
        <Text className="mt-2 font-body text-xs leading-5 text-muted">The access token stays in the device Keychain/Keystore. The server has no refresh-token endpoint; expired sessions require a fresh sign-in. JWT_SECRET and ENCRYPTION_KEY are server-only and are never included in the app.</Text>
        <Button className="mt-4" title="Sign out" variant="danger" onPress={handleSignOut} />
      </Card>
      <Text className="mt-6 text-center font-body text-[10px] text-muted">FIFO Wealth OS Mobile · API {process.env.EXPO_PUBLIC_APP_ENV ?? 'development'}</Text>
    </Screen>
  );
}
