import { Redirect, Stack } from 'expo-router';
import { useAuth } from '@/auth/AuthProvider';
import { colors } from '@/theme/colors';

export default function ProtectedLayout(): React.JSX.Element {
  const { status } = useAuth();
  if (status !== 'signed-in') return <Redirect href="/(auth)/sign-in" />;
  return (
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.midnight } }}>
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="portfolio/[id]" options={{ presentation: 'card' }} />
    </Stack>
  );
}
