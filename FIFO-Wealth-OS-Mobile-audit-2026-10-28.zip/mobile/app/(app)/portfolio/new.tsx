import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Stack, useRouter } from 'expo-router';
import { useState } from 'react';
import { Text, View } from 'react-native';
import { getApiErrorMessage } from '@/api/client';
import { portfolioApi } from '@/api/services';
import { Button, Card, Field } from '@/components/Primitives';
import { Screen } from '@/components/Screen';

export default function NewPortfolioScreen(): React.JSX.Element {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  const [currency, setCurrency] = useState('THB');
  const [error, setError] = useState('');
  const createPortfolio = useMutation({
    mutationFn: () => portfolioApi.create(name.trim(), currency.trim().toUpperCase()),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['mobile-dashboard-summary'] });
      router.replace('/(app)/(tabs)');
    },
    onError: (reason: unknown) => setError(getApiErrorMessage(reason)),
  });

  const submit = (): void => {
    setError('');
    if (!name.trim()) {
      setError('Enter a portfolio name.');
      return;
    }
    if (!/^[A-Za-z]{3,5}$/.test(currency.trim())) {
      setError('Enter a 3–5 letter currency code, such as THB or USD.');
      return;
    }
    createPortfolio.mutate();
  };

  return (
    <Screen>
      <Stack.Screen options={{ title: 'New portfolio', headerShown: true, headerTintColor: '#F4F5F8', headerStyle: { backgroundColor: '#090A10' }, headerTitleStyle: { color: '#F4F5F8' } }} />
      <Text className="font-display text-2xl font-extrabold text-ink">Create portfolio</Text>
      <Text className="mt-2 font-body text-sm leading-6 text-muted">Portfolio creation uses the existing API and server-side usage limits.</Text>
      <Card className="mt-6 gap-4">
        <Field label="Portfolio name" value={name} onChangeText={setName} autoCapitalize="words" maxLength={120} placeholder="Long-term wealth" />
        <Field label="Base currency" value={currency} onChangeText={setCurrency} autoCapitalize="characters" maxLength={5} placeholder="THB" />
        {error ? <Text accessibilityRole="alert" className="font-body text-sm text-loss">{error}</Text> : null}
        <Button title="Create portfolio" loading={createPortfolio.isPending} onPress={submit} />
        <View className="rounded-xl border border-gold/20 bg-gold/10 p-3">
          <Text className="font-body text-xs leading-5 text-gold">FIFO cost basis, gain/loss, and tax calculations stay on the existing backend. The app does not calculate financial results locally.</Text>
        </View>
      </Card>
    </Screen>
  );
}
