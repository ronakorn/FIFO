import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { ChevronDown, ChevronUp } from 'lucide-react-native';
import { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import type { FifoLot } from '@/api/types';
import { Card, EmptyState, Eyebrow, InlineError, SectionTitle, StatusPill } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { useMobileDashboard } from '@/hooks/useMobileData';
import { formatDate, formatNumber, formatThb } from '@/lib/formatters';
import { colors } from '@/theme/colors';

function LotRow({ lot }: { lot: FifoLot }): React.JSX.Element {
  const [expanded, setExpanded] = useState(false);
  const statusTone = lot.status === 'Sold' ? 'muted' : lot.status === 'Partial' ? 'bad' : 'good';
  return (
    <Card className="p-0">
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ expanded }}
        className="flex-row items-center justify-between p-4"
        onPress={() => setExpanded((current) => !current)}
      >
        <View className="flex-1 pr-3">
          <View className="flex-row items-center gap-2">
            <Text className="font-display text-sm font-bold text-ink">{lot.symbol}</Text>
            <StatusPill label={lot.status} tone={statusTone} />
          </View>
          <Text className="mt-1 font-body text-xs text-muted">Opened {formatDate(lot.date)} · {formatNumber(lot.qtyRemain, 6)} remaining</Text>
        </View>
        <View className="items-end">
          <Text className="font-display text-sm font-bold text-ink">{formatThb(lot.unrealizedGL)}</Text>
          {expanded ? <ChevronUp color={colors.muted} size={16} /> : <ChevronDown color={colors.muted} size={16} />}
        </View>
      </Pressable>
      {expanded ? (
        <View className="border-t border-stroke px-4 pb-4 pt-3">
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Original quantity</Text><Text className="font-body text-xs font-semibold text-ink">{formatNumber(lot.buyQty, 6)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Quantity matched to sells</Text><Text className="font-body text-xs font-semibold text-ink">{formatNumber(lot.qtySold, 6)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Cost per unit (THB)</Text><Text className="font-body text-xs font-semibold text-ink">{formatThb(lot.costPerUnit)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Realized G/L for this lot</Text><Text className="font-body text-xs font-semibold text-ink">{formatThb(lot.realizedGL)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Unrealized G/L</Text><Text className="font-body text-xs font-semibold text-ink">{formatThb(lot.unrealizedGL)}</Text></View>
          <Text className="mt-2 font-body text-[10px] leading-4 text-muted">Lot matching and gain/loss values come from the existing backend FIFO engine.</Text>
        </View>
      ) : null}
    </Card>
  );
}

export default function PortfolioDetailScreen(): React.JSX.Element {
  const params = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  const dashboard = useMobileDashboard();
  const portfolio = dashboard.data?.value.portfolios.find((item) => item.id === id);
  const lots = portfolio?.fifoSummary?.lots ?? [];
  const openLots = lots.filter((lot) => lot.qtyRemain > 0);
  const closedLots = lots.filter((lot) => lot.qtyRemain <= 0);

  if (dashboard.isPending && !portfolio) {
    return <Screen><View className="h-48 rounded-3xl bg-surface" /></Screen>;
  }
  if (!portfolio && dashboard.isError) {
    return <Screen><InlineError message={dashboard.error.message} onRetry={() => { void dashboard.refetch(); }} /></Screen>;
  }
  if (!portfolio) {
    return <Screen><EmptyState title="Portfolio not found" message="Refresh the dashboard and try opening this portfolio again." /></Screen>;
  }

  return (
    <Screen>
      <Stack.Screen options={{ title: portfolio.name, headerShown: true, headerTintColor: '#F4F5F8', headerStyle: { backgroundColor: '#090A10' }, headerTitleStyle: { color: '#F4F5F8' } }} />
      <Eyebrow>PORTFOLIO · {portfolio.baseCurrency}</Eyebrow>
      <Text className="mt-2 font-display text-2xl font-extrabold text-ink">{portfolio.name}</Text>
      <View className="mt-5 flex-row flex-wrap gap-3">
        <Card className="min-w-[46%] flex-1"><Eyebrow>Market value</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.marketValueTHB)}</Text></Card>
        <Card className="min-w-[46%] flex-1"><Eyebrow>Open cost basis</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.openCostBasisTHB)}</Text></Card>
        <Card className="min-w-[46%] flex-1"><Eyebrow>Realized G/L</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.totalRealizedGL)}</Text></Card>
        <Card className="min-w-[46%] flex-1"><Eyebrow>Unrealized G/L</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.totalUnrealizedGL)}</Text></Card>
      </View>
      <View className="mt-5">
        <Pressable
          accessibilityRole="button"
          className="rounded-2xl bg-accent px-4 py-3"
          onPress={() => router.push({ pathname: '/(app)/(tabs)/activity', params: { portfolioId: portfolio.id } })}
        >
          <Text className="text-center font-display text-sm font-bold text-white">Open transaction ledger</Text>
        </Pressable>
      </View>
      <View className="mt-7">
        <SectionTitle title={`Open FIFO lots (${openLots.length})`} />
        {openLots.length ? <View className="gap-3">{openLots.map((lot) => <LotRow key={lot.id} lot={lot} />)}</View> : <EmptyState title="No open lots" message="Open holdings will appear here with their FIFO cost basis." />}
      </View>
      {closedLots.length ? (
        <View className="mt-7">
          <SectionTitle title={`Closed lots (${closedLots.length})`} />
          <View className="gap-3">{closedLots.slice(0, 20).map((lot) => <LotRow key={lot.id} lot={lot} />)}</View>
        </View>
      ) : null}
    </Screen>
  );
}
