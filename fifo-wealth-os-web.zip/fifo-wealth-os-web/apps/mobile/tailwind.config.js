/** @type {import('tailwindcss').Config} */
const colorVariable = (name) => `rgb(var(--color-${name}) / <alpha-value>)`;

module.exports = {
  darkMode: 'class',
  content: ['./app/**/*.{js,jsx,ts,tsx}', './src/**/*.{js,jsx,ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        midnight: colorVariable('midnight'),
        surface: colorVariable('surface'),
        raised: colorVariable('raised'),
        stroke: colorVariable('stroke'),
        muted: colorVariable('muted'),
        ink: colorVariable('ink'),
        accent: colorVariable('accent'),
        'accent-bright': colorVariable('accent-bright'),
        gain: colorVariable('gain'),
        loss: colorVariable('loss'),
        gold: colorVariable('gold'),
      },
      fontFamily: {
        display: ['System'],
        body: ['System'],
      },
      boxShadow: {
        glow: '0 12px 40px rgba(20, 52, 42, 0.18)',
      },
    },
  },
  plugins: [],
};
