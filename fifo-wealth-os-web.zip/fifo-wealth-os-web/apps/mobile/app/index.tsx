import { Redirect } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import { isOnboardingComplete } from '@/auth/tokenStore';
import { useTheme } from '@/theme/ThemeProvider';

export default function EntryRoute(): React.JSX.Element {
  const { status } = useAuth();
  const { colors } = useTheme();
  const [onboardingComplete, setOnboardingComplete] = useState<boolean | null>(null);

  useEffect(() => {
    let active = true;
    void isOnboardingComplete().then((complete) => {
      if (active) setOnboardingComplete(complete);
    }).catch(() => {
      if (active) setOnboardingComplete(false);
    });
    return () => { active = false; };
  }, []);

  if (status === 'loading' || onboardingComplete === null) {
    return (
      <View className="flex-1 items-center justify-center bg-midnight">
        <ActivityIndicator color={colors.accentBright} size="large" />
        <Text className="mt-4 font-body text-sm text-muted">Preparing your secure workspace…</Text>
      </View>
    );
  }

  if (status === 'signed-in') return <Redirect href="/(app)/(tabs)" />;
  if (!onboardingComplete) return <Redirect href="/(auth)/onboarding" />;
  return <Redirect href="/(auth)/sign-in" />;
}
