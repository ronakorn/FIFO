import { useRouter } from 'expo-router';
import { Text, View } from 'react-native';
import { Button, Eyebrow } from '@/components/Primitives';
import { Screen } from '@/components/Screen';

export default function NativeWindVerificationScreen(): React.JSX.Element {
  const router = useRouter();

  return (
    <Screen>
      <Eyebrow>DESIGN SYSTEM CHECK</Eyebrow>
      <View className="mt-6 rounded-2xl border border-accent/30 bg-surface p-6">
        <Text className="font-display text-2xl font-extrabold text-ink">Hello, NativeWind!</Text>
        <Text className="mt-3 font-body text-sm leading-6 text-muted">
          This separate verification screen confirms NativeWind utility classes and semantic light/dark theme tokens are active without replacing the FIFO app.
        </Text>
        <View className="mt-5 h-2 rounded-full bg-accent" />
      </View>
      <Button className="mt-5" title="Back to Profile" accessibilityHint="Returns to Settings." variant="secondary" onPress={() => router.back()} />
    </Screen>
  );
}
