import { Redirect, Stack } from 'expo-router';
import { useAuth } from '@/auth/AuthProvider';
import { useTheme } from '@/theme/ThemeProvider';

export default function ProtectedLayout(): React.JSX.Element {
  const { status } = useAuth();
  const { colors } = useTheme();
  if (status !== 'signed-in') return <Redirect href="/(auth)/sign-in" />;
  return (
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.midnight } }}>
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="portfolio/[id]" options={{ presentation: 'card' }} />
      <Stack.Screen name="nativewind-verification" options={{ presentation: 'card' }} />
    </Stack>
  );
}
