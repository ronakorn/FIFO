import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { ChevronDown, ChevronUp } from 'lucide-react-native';
import { memo, useCallback, useMemo, useState } from 'react';
import { FlatList, Platform, Pressable, RefreshControl, Text, View, type ListRenderItemInfo } from 'react-native';
import type { FifoLot, Portfolio } from '@/api/types';
import { Button, Card, EmptyState, Eyebrow, InlineError, SectionTitle, StatusPill } from '@/components/Primitives';
import { PortfolioTransactionRow, type PortfolioLedgerEntry } from '@/components/PortfolioTransactionRow';
import { Screen } from '@/components/Screen';
import { useMobileDashboard, useMobileTransactions } from '@/hooks/useMobileData';
import { usePendingManualTransactions } from '@/hooks/usePendingManualTransactions';
import { formatDate, formatNumber, formatThb } from '@/lib/formatters';
import { hapticRefresh } from '@/lib/haptics';
import { useTheme } from '@/theme/ThemeProvider';

const EMPTY_LOTS: FifoLot[] = [];

type PortfolioDetailItem =
  | { kind: 'section'; id: string; title: string; description?: string }
  | { kind: 'transaction'; id: string; entry: PortfolioLedgerEntry }
  | { kind: 'lot'; id: string; lot: FifoLot }
  | { kind: 'empty'; id: string; title: string; message: string }
  | { kind: 'loading'; id: string };

function LotRowComponent({ lot }: { lot: FifoLot }): React.JSX.Element {
  const { colors } = useTheme();
  const [expanded, setExpanded] = useState(false);
  const statusTone = lot.status === 'Sold' ? 'muted' : lot.status === 'Partial' ? 'bad' : 'good';
  return (
    <Card className="p-0">
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${lot.symbol} ${lot.status} lot, ${formatNumber(lot.qtyRemain, 6)} remaining`}
        accessibilityHint={expanded ? 'Hides the FIFO lot details.' : 'Shows the FIFO lot quantities and gain or loss details.'}
        accessibilityState={{ expanded }}
        className="flex-row items-center justify-between p-4"
        onPress={() => setExpanded((current) => !current)}
      >
        <View className="flex-1 pr-3">
          <View className="flex-row items-center gap-2">
            <Text className="font-display text-sm font-bold text-ink">{lot.symbol}</Text>
            <StatusPill label={lot.status} tone={statusTone} />
          </View>
          <Text className="mt-1 font-body text-xs text-muted">Opened {formatDate(lot.date)} · {formatNumber(lot.qtyRemain, 6)} remaining</Text>
        </View>
        <View className="items-end">
          <Text className="font-display text-sm font-bold text-ink">{formatThb(lot.unrealizedGL)}</Text>
          {expanded ? <ChevronUp color={colors.muted} size={16} /> : <ChevronDown color={colors.muted} size={16} />}
        </View>
      </Pressable>
      {expanded ? (
        <View className="border-t border-stroke px-4 pb-4 pt-3">
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Original quantity</Text><Text className="font-body text-xs font-semibold text-ink">{formatNumber(lot.buyQty, 6)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Quantity matched to sells</Text><Text className="font-body text-xs font-semibold text-ink">{formatNumber(lot.qtySold, 6)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Cost per unit (THB)</Text><Text className="font-body text-xs font-semibold text-ink">{formatThb(lot.costPerUnit)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Realized G/L for this lot</Text><Text className="font-body text-xs font-semibold text-ink">{formatThb(lot.realizedGL)}</Text></View>
          <View className="flex-row justify-between py-1.5"><Text className="font-body text-xs text-muted">Unrealized G/L</Text><Text className="font-body text-xs font-semibold text-ink">{formatThb(lot.unrealizedGL)}</Text></View>
          <Text className="mt-2 font-body text-[10px] leading-4 text-muted">Lot matching and gain/loss values come from the existing backend FIFO engine.</Text>
        </View>
      ) : null}
    </Card>
  );
}

const LotRow = memo(LotRowComponent);

function PortfolioDetailSeparator(): React.JSX.Element {
  return <View className="h-3" />;
}

function PortfolioDetailRowComponent({ item }: { item: PortfolioDetailItem }): React.JSX.Element {
  if (item.kind === 'transaction') return <PortfolioTransactionRow entry={item.entry} />;
  if (item.kind === 'lot') return <LotRow lot={item.lot} />;
  if (item.kind === 'section') {
    return (
      <View className="mt-4">
        <SectionTitle title={item.title} />
        {item.description ? <Text className="-mt-1 mb-1 font-body text-xs leading-5 text-muted">{item.description}</Text> : null}
      </View>
    );
  }
  if (item.kind === 'loading') return <Card><Text className="font-body text-sm text-muted">Loading transactions…</Text></Card>;
  return <EmptyState title={item.title} message={item.message} />;
}

const PortfolioDetailRow = memo(PortfolioDetailRowComponent);

function portfolioDetailKey(item: PortfolioDetailItem): string {
  return item.id;
}

function renderPortfolioDetailItem({ item }: ListRenderItemInfo<PortfolioDetailItem>): React.JSX.Element {
  return <PortfolioDetailRow item={item} />;
}

export default function PortfolioDetailScreen(): React.JSX.Element {
  const { colors } = useTheme();
  const params = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  const dashboard = useMobileDashboard();
  const transactionQuery = useMobileTransactions(id);
  const pendingManual = usePendingManualTransactions();
  const { refetch: refetchDashboard, isRefetching: dashboardRefetching } = dashboard;
  const {
    data: transactionData,
    isPending: transactionsPending,
    isError: transactionsError,
    error: transactionError,
    refetch: refetchTransactions,
    isRefetching: transactionsRefetching,
    hasNextPage,
    isFetchingNextPage,
    isFetchNextPageError,
    fetchNextPage,
  } = transactionQuery;
  const portfolio = useMemo<Portfolio | undefined>(
    () => dashboard.data?.value.portfolios.find((item) => item.id === id),
    [dashboard.data?.value.portfolios, id],
  );
  const confirmedTransactions = useMemo(
    () => transactionData?.pages.flatMap((page) => page.items) ?? [],
    [transactionData?.pages],
  );
  const queuedTransactions = useMemo(
    () => pendingManual.transactions.filter((transaction) => transaction.portfolioId === id),
    [id, pendingManual.transactions],
  );
  const ledgerEntries = useMemo<PortfolioLedgerEntry[]>(() => [
    ...queuedTransactions.map((transaction) => ({ status: 'queued' as const, transaction })),
    ...confirmedTransactions.map((transaction) => ({ status: 'confirmed' as const, transaction })),
  ].sort((left, right) => Date.parse(right.transaction.date) - Date.parse(left.transaction.date)), [confirmedTransactions, queuedTransactions]);
  const lots = portfolio?.fifoSummary?.lots ?? EMPTY_LOTS;
  const { openLots, closedLots, closedLotCount } = useMemo(() => {
    const open: FifoLot[] = [];
    const closed: FifoLot[] = [];
    let closedCount = 0;
    for (const lot of lots) {
      if (lot.qtyRemain > 0) open.push(lot);
      else {
        closedCount += 1;
        if (closed.length < 20) closed.push(lot);
      }
    }
    return { openLots: open, closedLots: closed, closedLotCount: closedCount };
  }, [lots]);
  const refresh = useCallback(() => {
    hapticRefresh();
    void Promise.all([refetchDashboard(), refetchTransactions()]);
  }, [refetchDashboard, refetchTransactions]);
  const refreshing = dashboardRefetching || transactionsRefetching;
  const refreshControl = useMemo(() => (
    <RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={colors.accentBright} colors={[colors.accentBright]} />
  ), [colors.accentBright, refresh, refreshing]);
  const rows = useMemo<PortfolioDetailItem[]>(() => {
    const items: PortfolioDetailItem[] = [
      {
        kind: 'section',
        id: 'transactions-heading',
        title: `Transactions (${ledgerEntries.length})`,
        description: 'Confirmed entries come from the server. Queued Quick Add trades are local only and have not synced.',
      },
    ];
    if (transactionsPending && pendingManual.isLoading && ledgerEntries.length === 0) {
      items.push({ kind: 'loading', id: 'transactions-loading' });
    } else if (ledgerEntries.length) {
      ledgerEntries.forEach((entry) => items.push({
        kind: 'transaction',
        id: `transaction-${entry.status}-${entry.transaction.id}`,
        entry,
      }));
    } else {
      items.push({
        kind: 'empty',
        id: 'transactions-empty',
        title: 'No transactions yet',
        message: 'Server-confirmed activity and locally queued Quick Add entries will appear here.',
      });
    }
    items.push({ kind: 'section', id: 'open-lots-heading', title: `Open FIFO lots (${openLots.length})` });
    if (openLots.length) openLots.forEach((lot) => items.push({ kind: 'lot', id: `open-lot-${lot.id}`, lot }));
    else items.push({ kind: 'empty', id: 'open-lots-empty', title: 'No open lots', message: 'Open holdings will appear here with their FIFO cost basis.' });
    if (closedLots.length) {
      items.push({ kind: 'section', id: 'closed-lots-heading', title: `Closed lots (${closedLotCount})` });
      closedLots.forEach((lot) => items.push({ kind: 'lot', id: `closed-lot-${lot.id}`, lot }));
    }
    return items;
  }, [closedLotCount, closedLots, ledgerEntries, openLots, pendingManual.isLoading, transactionsPending]);
  const header = useMemo(() => portfolio ? (
    <View>
      <Stack.Screen options={{ title: portfolio.name, headerShown: true, headerTintColor: colors.ink, headerStyle: { backgroundColor: colors.midnight }, headerTitleStyle: { color: colors.ink } }} />
      <Eyebrow>PORTFOLIO · {portfolio.baseCurrency}</Eyebrow>
      <Text className="mt-2 font-display text-2xl font-extrabold text-ink">{portfolio.name}</Text>
      <View className="mt-5 flex-row flex-wrap gap-3">
        <Card className="min-w-[46%] flex-1"><Eyebrow>Market value</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.marketValueTHB)}</Text></Card>
        <Card className="min-w-[46%] flex-1"><Eyebrow>Open cost basis</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.openCostBasisTHB)}</Text></Card>
        <Card className="min-w-[46%] flex-1"><Eyebrow>Realized G/L</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.totalRealizedGL)}</Text></Card>
        <Card className="min-w-[46%] flex-1"><Eyebrow>Unrealized G/L</Eyebrow><Text className="mt-2 font-display text-lg font-bold text-ink">{formatThb(portfolio.fifoSummary?.totalUnrealizedGL)}</Text></Card>
      </View>
      <View className="mt-5">
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="View all activity for this portfolio"
          accessibilityHint="Opens the transaction ledger filtered to this portfolio."
          className="rounded-2xl bg-accent px-4 py-3"
          onPress={() => router.push({ pathname: '/(app)/(tabs)/activity', params: { portfolioId: portfolio.id } })}
        >
          <Text className="text-center font-display text-sm font-bold text-white">View all activity</Text>
        </Pressable>
      </View>
      {transactionsError ? (
        <View className="mt-4">
          <InlineError message={transactionError.message} onRetry={() => { void refetchTransactions(); }} />
        </View>
      ) : null}
    </View>
  ) : null, [colors.ink, colors.midnight, portfolio, refetchTransactions, router, transactionError, transactionsError]);
  const footer = useMemo(() => isFetchNextPageError ? (
    <View className="mt-3">
      <InlineError
        message={transactionError?.message ?? 'Could not load the next ledger page.'}
        onRetry={() => { void fetchNextPage(); }}
      />
    </View>
  ) : hasNextPage ? (
    <Button
      className="mt-3"
      title="Load more transactions"
      accessibilityHint="Loads the next page of server-confirmed transactions."
      variant="secondary"
      loading={isFetchingNextPage}
      onPress={async () => { await fetchNextPage(); }}
    />
  ) : null, [fetchNextPage, hasNextPage, isFetchingNextPage, isFetchNextPageError, transactionError]);

  if (dashboard.isPending && !portfolio) {
    return <Screen><View className="h-48 rounded-3xl bg-surface" /></Screen>;
  }
  if (!portfolio && dashboard.isError) {
    return <Screen><InlineError message={dashboard.error.message} onRetry={() => { void dashboard.refetch(); }} /></Screen>;
  }
  if (!portfolio) {
    return <Screen><EmptyState title="Portfolio not found" message="Refresh the dashboard and try opening this portfolio again." /></Screen>;
  }

  return (
    <Screen scroll={false} contentClassName="p-0">
      <FlatList
        data={rows}
        keyExtractor={portfolioDetailKey}
        renderItem={renderPortfolioDetailItem}
        ItemSeparatorComponent={PortfolioDetailSeparator}
        ListHeaderComponent={header}
        ListFooterComponent={footer}
        refreshControl={refreshControl}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 40, flexGrow: 1 }}
        initialNumToRender={8}
        maxToRenderPerBatch={8}
        updateCellsBatchingPeriod={50}
        windowSize={7}
        removeClippedSubviews={Platform.OS === 'android'}
        showsVerticalScrollIndicator={false}
      />
    </Screen>
  );
}
