import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Stack, useRouter } from 'expo-router';
import { useState } from 'react';
import { Text, View } from 'react-native';
import { getApiErrorMessage } from '@/api/client';
import { portfolioApi } from '@/api/services';
import { Button, Card, Field } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { hapticWarning } from '@/lib/haptics';
import { useTheme } from '@/theme/ThemeProvider';

export default function NewPortfolioScreen(): React.JSX.Element {
  const { colors } = useTheme();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  const [currency, setCurrency] = useState('THB');
  const [error, setError] = useState('');
  const createPortfolio = useMutation({
    mutationFn: () => portfolioApi.create(name.trim(), currency.trim().toUpperCase()),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['mobile-dashboard-summary'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-portfolios'] }),
      ]);
      router.replace('/(app)/(tabs)');
    },
    onError: (reason: unknown) => setError(getApiErrorMessage(reason)),
  });

  const submit = (): void => {
    setError('');
    if (!name.trim()) {
      hapticWarning();
      setError('Enter a portfolio name.');
      return;
    }
    if (!/^[A-Za-z]{3,5}$/.test(currency.trim())) {
      hapticWarning();
      setError('Enter a 3–5 letter currency code, such as THB or USD.');
      return;
    }
    createPortfolio.mutate();
  };

  return (
    <Screen>
      <Stack.Screen options={{ title: 'New portfolio', headerShown: true, headerTintColor: colors.ink, headerStyle: { backgroundColor: colors.midnight }, headerTitleStyle: { color: colors.ink } }} />
      <Text className="font-display text-2xl font-extrabold text-ink">Create portfolio</Text>
      <Text className="mt-2 font-body text-sm leading-6 text-muted">Portfolio creation uses the existing API and server-side usage limits.</Text>
      <Card className="mt-6 gap-4">
        <Field label="Portfolio name" value={name} onChangeText={setName} autoCapitalize="words" maxLength={120} placeholder="Long-term wealth" />
        <Field label="Base currency" value={currency} onChangeText={setCurrency} autoCapitalize="characters" maxLength={5} placeholder="THB" />
        {error ? <Text accessibilityRole="alert" accessibilityLiveRegion="polite" className="font-body text-sm text-loss">{error}</Text> : null}
        <Button title="Create portfolio" accessibilityHint="Creates this portfolio using the existing server API." loading={createPortfolio.isPending} onPress={submit} />
        <View className="rounded-xl border border-gold/20 bg-gold/10 p-3">
          <Text className="font-body text-xs leading-5 text-gold">FIFO cost basis, gain/loss, and tax calculations stay on the existing backend. The app does not calculate financial results locally.</Text>
        </View>
      </Card>
    </Screen>
  );
}
