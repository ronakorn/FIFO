import { useLocalSearchParams } from 'expo-router';
import { Search, X } from 'lucide-react-native';
import { memo, useCallback, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  Text,
  TextInput,
  View,
  type ListRenderItemInfo,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { Portfolio, Transaction } from '@/api/types';
import { useAuth } from '@/auth/AuthProvider';
import { Card, EmptyState, Eyebrow, InlineError, StatusPill } from '@/components/Primitives';
import { OfflineBanner } from '@/components/Screen';
import { useMobileDashboard, useMobileTransactions } from '@/hooks/useMobileData';
import { formatDate, formatNumber, formatThb } from '@/lib/formatters';
import { hapticRefresh } from '@/lib/haptics';
import { useTheme } from '@/theme/ThemeProvider';

const TYPE_FILTERS = ['ALL', 'BUY', 'SELL', 'FEE'] as const;
const EMPTY_PORTFOLIOS: Portfolio[] = [];
type TypeFilter = typeof TYPE_FILTERS[number];

function TransactionDetailsComponent({ transaction, onClose }: { transaction: Transaction | null; onClose: () => void }): React.JSX.Element {
  const { colors } = useTheme();
  return (
    <Modal animationType="slide" transparent visible={transaction !== null} onRequestClose={onClose}>
      <View className="flex-1 justify-end bg-black/70">
        <View className="rounded-t-3xl border-t border-stroke bg-surface px-5 pb-10 pt-5">
          <View className="mb-5 flex-row items-center justify-between">
            <Text className="font-display text-lg font-bold text-ink">Transaction details</Text>
            <Pressable accessibilityRole="button" accessibilityLabel="Close details" accessibilityHint="Dismisses the transaction details." onPress={onClose} className="h-10 w-10 items-center justify-center rounded-xl bg-raised"><X color={colors.ink} size={18} /></Pressable>
          </View>
          {transaction ? (
            <View className="gap-3">
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Asset</Text><Text className="font-body text-sm font-bold text-ink">{transaction.symbol} · {transaction.type}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Date</Text><Text className="font-body text-sm font-semibold text-ink">{formatDate(transaction.date)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Quantity</Text><Text className="font-body text-sm font-semibold text-ink">{formatNumber(transaction.qty, 8)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Unit price</Text><Text className="font-body text-sm font-semibold text-ink">{formatNumber(transaction.price, 4)} {transaction.originalCurrency}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Net amount</Text><Text className="font-body text-sm font-semibold text-ink">{formatThb(transaction.netTHB ?? transaction.net)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Original currency</Text><Text className="font-body text-sm font-semibold text-ink">{transaction.originalCurrency}</Text></View>
              <Text className="mt-2 font-body text-xs leading-5 text-muted">This is an imported ledger record. FIFO matching and tax results are computed by the backend.</Text>
            </View>
          ) : null}
        </View>
      </View>
    </Modal>
  );
}

const TransactionDetails = memo(TransactionDetailsComponent);

function PortfolioChipsComponent({ portfolios, selectedId, onSelect }: { portfolios: Portfolio[]; selectedId: string; onSelect: (id: string) => void }): React.JSX.Element {
  return (
    <View className="mb-4">
      <Eyebrow>PORTFOLIO</Eyebrow>
      <FlatList
        className="mt-2"
        data={portfolios}
        horizontal
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Select ${item.name} portfolio`}
            accessibilityHint="Filters the activity ledger to this portfolio."
            accessibilityState={{ selected: selectedId === item.id }}
            className={`mr-2 rounded-full border px-3 py-2 ${selectedId === item.id ? 'border-accent bg-accent/20' : 'border-stroke bg-surface'}`}
            onPress={() => onSelect(item.id)}
          >
            <Text className={`font-body text-xs font-bold ${selectedId === item.id ? 'text-accent-bright' : 'text-muted'}`}>{item.name}</Text>
          </Pressable>
        )}
        showsHorizontalScrollIndicator={false}
      />
    </View>
  );
}

const PortfolioChips = memo(PortfolioChipsComponent);

function TransactionListRowComponent({ item, onPress }: { item: Transaction; onPress: (transaction: Transaction) => void }): React.JSX.Element {
  const handlePress = useCallback(() => onPress(item), [item, onPress]);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${item.symbol} ${item.type}, ${formatDate(item.date)}, ${formatNumber(item.qty, 8)} units, ${formatThb(item.netTHB ?? item.net)}`}
      accessibilityHint="Opens the imported server transaction details."
      className="mb-3 rounded-2xl border border-stroke bg-surface p-4 active:bg-raised"
      onPress={handlePress}
    >
      <View className="flex-row items-center justify-between gap-3">
        <View className="flex-1">
          <View className="flex-row items-center gap-2">
            <Text className="font-display text-sm font-bold text-ink">{item.symbol}</Text>
            <StatusPill label={item.type} tone={item.type === 'BUY' ? 'bad' : 'good'} />
          </View>
          <Text className="mt-1 font-body text-xs text-muted">{formatDate(item.date)} · {formatNumber(item.qty, 8)} units</Text>
        </View>
        <View className="items-end">
          <Text className="font-display text-sm font-bold text-ink">{formatThb(item.netTHB ?? item.net)}</Text>
          <Text className="mt-1 font-body text-[10px] text-muted">{item.originalCurrency}</Text>
        </View>
      </View>
    </Pressable>
  );
}

const TransactionListRow = memo(TransactionListRowComponent);

function transactionKey(item: Transaction): string {
  return item.id;
}

export default function ActivityScreen(): React.JSX.Element {
  const { colors } = useTheme();
  const params = useLocalSearchParams<{ portfolioId?: string }>();
  const { status } = useAuth();
  const dashboard = useMobileDashboard();
  const portfolios = useMemo(
    () => dashboard.data?.value.portfolios ?? EMPTY_PORTFOLIOS,
    [dashboard.data?.value.portfolios],
  );
  const requestedId = Array.isArray(params.portfolioId) ? params.portfolioId[0] : params.portfolioId;
  const [manuallySelectedId, setManuallySelectedId] = useState('');
  const selectedPortfolioId = portfolios.some((portfolio) => portfolio.id === manuallySelectedId)
    ? manuallySelectedId
    : requestedId && portfolios.some((portfolio) => portfolio.id === requestedId)
      ? requestedId
      : portfolios[0]?.id ?? '';
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('ALL');
  const [symbolInput, setSymbolInput] = useState('');
  const [appliedSymbol, setAppliedSymbol] = useState<string | undefined>();
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  const query = useMobileTransactions(
    selectedPortfolioId || undefined,
    {
      ...(typeFilter !== 'ALL' ? { type: typeFilter } : {}),
      ...(appliedSymbol ? { symbol: appliedSymbol } : {}),
    },
  );
  const {
    data: transactionData,
    isPending: transactionsPending,
    isError: transactionsError,
    error: transactionsErrorObject,
    refetch: refetchTransactions,
    isFetchingNextPage,
    isFetchNextPageError,
    hasNextPage,
    fetchNextPage,
    isRefetching: transactionsRefetching,
  } = query;
  const { refetch: refetchDashboard, isRefetching: dashboardRefetching } = dashboard;
  const items = useMemo(() => transactionData?.pages.flatMap((page) => page.items) ?? [], [transactionData?.pages]);
  const cached = useMemo(() => transactionData?.pages.some((page) => page.cached) ?? false, [transactionData?.pages]);
  const applySearch = useCallback(() => {
    setAppliedSymbol(symbolInput.trim() ? symbolInput.trim().toUpperCase() : undefined);
  }, [symbolInput]);
  const refresh = useCallback(() => {
    hapticRefresh();
    void refetchDashboard();
    void refetchTransactions();
  }, [refetchDashboard, refetchTransactions]);
  const openTransaction = useCallback((transaction: Transaction) => setSelectedTransaction(transaction), []);
  const closeTransaction = useCallback(() => setSelectedTransaction(null), []);
  const renderTransaction = useCallback(({ item }: ListRenderItemInfo<Transaction>) => (
    <TransactionListRow item={item} onPress={openTransaction} />
  ), [openTransaction]);
  const refreshControl = useMemo(() => (
    <RefreshControl
      refreshing={dashboardRefetching || transactionsRefetching}
      onRefresh={refresh}
      tintColor={colors.accentBright}
      colors={[colors.accentBright]}
    />
  ), [colors.accentBright, dashboardRefetching, refresh, transactionsRefetching]);
  const header = useMemo(() => (
    <View>
      <View className="mb-5">
        <Eyebrow>LEDGER · CURSOR PAGINATION</Eyebrow>
        <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Activity</Text>
        <Text className="mt-1 font-body text-sm text-muted">Newest first · server paginated</Text>
      </View>
      {cached ? <View className="mb-4 rounded-xl border border-gold/30 bg-gold/10 px-3 py-2"><Text className="font-body text-xs text-gold">Offline · encrypted cached ledger pages</Text></View> : null}
      {portfolios.length ? (
        <PortfolioChips portfolios={portfolios} selectedId={selectedPortfolioId} onSelect={setManuallySelectedId} />
      ) : null}
      <View className="mb-3 flex-row gap-2">
        {TYPE_FILTERS.map((filter) => (
          <Pressable
            key={filter}
            accessibilityRole="button"
            accessibilityLabel={`Filter ${filter === 'ALL' ? 'all transaction types' : `${filter} transactions`}`}
            accessibilityHint="Filters the transaction ledger by transaction type."
            accessibilityState={{ selected: typeFilter === filter }}
            className={`rounded-full border px-3 py-2 ${typeFilter === filter ? 'border-accent bg-accent/20' : 'border-stroke bg-surface'}`}
            onPress={() => setTypeFilter(filter)}
          >
            <Text className={`font-body text-[11px] font-bold ${typeFilter === filter ? 'text-accent-bright' : 'text-muted'}`}>{filter === 'ALL' ? 'All' : filter}</Text>
          </Pressable>
        ))}
      </View>
      <View className="mb-4 flex-row items-center rounded-2xl border border-stroke bg-raised px-3">
        <Search color={colors.muted} size={17} />
        <TextInput
          accessibilityLabel="Search transaction symbol"
          accessibilityHint="Enter a ticker symbol to filter the server transaction ledger."
          className="min-h-11 flex-1 px-3 font-body text-sm text-ink"
          placeholder="Search symbol"
          placeholderTextColor={colors.muted}
          autoCapitalize="characters"
          autoCorrect={false}
          returnKeyType="search"
          value={symbolInput}
          onChangeText={setSymbolInput}
          onSubmitEditing={applySearch}
        />
        <Pressable accessibilityRole="button" accessibilityLabel="Apply symbol filter" accessibilityHint="Applies the typed ticker symbol to the transaction list." onPress={applySearch} className="px-2 py-3"><Text className="font-body text-xs font-bold text-accent-bright">Apply</Text></Pressable>
      </View>
      <Card className="mb-4 py-3"><Text className="font-body text-[11px] leading-4 text-muted">Ledger data is cached only in SQLCipher storage. Offline access is read-only; reconnect to refresh or sync.</Text></Card>
    </View>
  ), [applySearch, cached, colors.muted, portfolios, selectedPortfolioId, symbolInput, typeFilter]);
  const emptyList = useMemo(() => transactionsPending
    ? <View className="py-8"><ActivityIndicator color={colors.accentBright} /></View>
    : transactionsError
      ? <InlineError message={transactionsErrorObject.message} onRetry={() => { void refetchTransactions(); }} />
      : <EmptyState title="No transactions found" message="Try another symbol filter or import a ledger through the web app." />,
  [colors.accentBright, refetchTransactions, transactionsError, transactionsErrorObject, transactionsPending]);
  const listFooter = useMemo(() => (
    <View className="items-center py-5">
      {isFetchingNextPage ? <ActivityIndicator accessibilityLabel="Loading more transactions" color={colors.accentBright} /> : null}
      {isFetchNextPageError ? (
        <View className="w-full">
          <InlineError
            message={transactionsErrorObject?.message ?? 'Could not load the next ledger page.'}
            onRetry={() => { void fetchNextPage(); }}
          />
        </View>
      ) : null}
      {!hasNextPage && items.length > 0 ? <Text className="font-body text-xs text-muted">End of ledger</Text> : null}
      {hasNextPage && !isFetchingNextPage && !isFetchNextPageError ? (
        <Pressable accessibilityRole="button" accessibilityLabel="Load more transactions" accessibilityHint="Loads the next page of server-confirmed activity." onPress={() => { void fetchNextPage(); }} className="rounded-xl border border-stroke bg-surface px-4 py-2.5">
          <Text className="font-body text-xs font-bold text-ink">Load more</Text>
        </Pressable>
      ) : null}
    </View>
  ), [colors.accentBright, fetchNextPage, hasNextPage, isFetchingNextPage, isFetchNextPageError, items.length, transactionsErrorObject]);
  const onEndReached = useCallback(() => {
    if (hasNextPage && !isFetchingNextPage && !isFetchNextPageError) void fetchNextPage();
  }, [fetchNextPage, hasNextPage, isFetchingNextPage, isFetchNextPageError]);

  if (dashboard.isPending && !dashboard.data) {
    return <SafeAreaView className="flex-1 bg-midnight" edges={['top']}><OfflineBanner /><View className="flex-1 items-center justify-center"><ActivityIndicator color={colors.accentBright} /></View></SafeAreaView>;
  }
  if (dashboard.isError && !dashboard.data) {
    return <SafeAreaView className="flex-1 bg-midnight" edges={['top']}><OfflineBanner /><View className="flex-1 justify-center px-5"><InlineError message={dashboard.error.message} onRetry={() => { void dashboard.refetch(); }} /></View></SafeAreaView>;
  }
  if (status !== 'signed-in') return <View className="flex-1 bg-midnight" />;
  if (dashboard.data && portfolios.length === 0) {
    return (
      <SafeAreaView className="flex-1 bg-midnight" edges={['top']}>
        <OfflineBanner />
        <View className="flex-1 px-5 pt-10">
          <Eyebrow>LEDGER · CURSOR PAGINATION</Eyebrow>
          <Text className="mb-6 mt-2 font-display text-2xl font-extrabold text-ink">Activity</Text>
          <EmptyState title="Create a portfolio first" message="Once you have a portfolio, imported and connected transactions will appear here." />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-midnight" edges={['top']}>
      <OfflineBanner />
      <FlatList
        data={items}
        keyExtractor={transactionKey}
        renderItem={renderTransaction}
        ListHeaderComponent={header}
        ListEmptyComponent={emptyList}
        ListFooterComponent={listFooter}
        onEndReached={onEndReached}
        onEndReachedThreshold={0.45}
        refreshControl={refreshControl}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 120, flexGrow: 1 }}
        initialNumToRender={12}
        maxToRenderPerBatch={12}
        updateCellsBatchingPeriod={50}
        windowSize={9}
        removeClippedSubviews={Platform.OS === 'android'}
        showsVerticalScrollIndicator={false}
      />
      <TransactionDetails transaction={selectedTransaction} onClose={closeTransaction} />
    </SafeAreaView>
  );
}
