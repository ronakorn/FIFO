import { Link, useRouter } from 'expo-router';
import { useNetInfo } from '@react-native-community/netinfo';
import { ArrowDownRight, ArrowUpRight, Plus, RefreshCw, Trash2, TrendingUp } from 'lucide-react-native';
import { useCallback, useMemo, useState } from 'react';
import { Alert, FlatList, Platform, Pressable, RefreshControl, Text, View, type ListRenderItemInfo } from 'react-native';
import type { Portfolio } from '@/api/types';
import { useAuth } from '@/auth/AuthProvider';
import { AllocationDonut, allocationColor, PerformanceChart, type AllocationDatum } from '@/components/Charts';
import { Button, Card, EmptyState, Eyebrow, InlineError, SectionTitle, StatusPill } from '@/components/Primitives';
import { PortfolioListItem } from '@/components/PortfolioListItem';
import { QuickAddTransaction } from '@/components/QuickAddTransaction';
import { Screen } from '@/components/Screen';
import { useDashboardAnalytics, useMobileDashboard, useMobilePortfolios } from '@/hooks/useMobileData';
import { usePendingManualTransactions } from '@/hooks/usePendingManualTransactions';
import { decimal40, formatDate, formatDateTime, formatNumber, formatPercentRatio, formatThb } from '@/lib/formatters';
import { hapticRefresh } from '@/lib/haptics';
import { useTheme } from '@/theme/ThemeProvider';

const EMPTY_PORTFOLIOS: Portfolio[] = [];

function isNegativeAmount(value: string | undefined): boolean {
  if (!value) return false;
  try {
    return decimal40(value).isNegative();
  } catch {
    return false;
  }
}

function portfolioKey(item: Portfolio): string {
  return item.id;
}

export default function DashboardScreen(): React.JSX.Element {
  const { colors } = useTheme();
  const router = useRouter();
  const { user } = useAuth();
  const dashboard = useMobileDashboard();
  const portfolioQuery = useMobilePortfolios();
  const { refetch: refetchDashboard } = dashboard;
  const { refetch: refetchPortfolios } = portfolioQuery;
  const [benchmark, setBenchmark] = useState<'SP500' | 'SET50'>('SP500');
  const analytics = useDashboardAnalytics(benchmark);
  const { refetch: refetchAnalytics } = analytics;
  const pendingManual = usePendingManualTransactions();
  const { removePendingTransaction: removePendingManualTransaction } = pendingManual;
  const network = useNetInfo();
  const isOffline = network.isConnected === false || network.isInternetReachable === false;
  const summary = dashboard.data?.value;
  const portfolioList = useMemo(() => portfolioQuery.data?.stale
    ? summary?.portfolios ?? portfolioQuery.data.value
    : portfolioQuery.data?.value ?? summary?.portfolios ?? EMPTY_PORTFOLIOS,
  [portfolioQuery.data?.stale, portfolioQuery.data?.value, summary?.portfolios]);
  const metrics = analytics.data?.value;
  const allocation = useMemo<AllocationDatum[]>(() => metrics?.assetAllocation.length
    ? metrics.assetAllocation.map((item) => ({
      key: item.category,
      label: item.enLabel,
      weightPct: item.weightPct,
      color: item.color,
    }))
    : (summary?.allocation ?? []).map((item) => ({
      key: item.symbol,
      label: item.symbol,
      weightPct: item.weightPct,
    })), [metrics, summary]);
  const allocationUpdatedAt = metrics?.assetAllocation.length
    ? analytics.data?.updatedAt
    : dashboard.data?.updatedAt;
  const unrealizedIsNegative = useMemo(
    () => isNegativeAmount(summary?.summary.unrealizedGLTHB),
    [summary?.summary.unrealizedGLTHB],
  );
  const visiblePendingTransactions = useMemo(
    () => pendingManual.transactions.slice(0, 5),
    [pendingManual.transactions],
  );
  const portfolioNameById = useMemo(
    () => new Map(portfolioList.map((portfolio) => [portfolio.id, portfolio.name])),
    [portfolioList],
  );
  const recentTransactions = useMemo(
    () => summary?.recentTransactions.slice(0, 5) ?? [],
    [summary?.recentTransactions],
  );

  const runRefresh = useCallback(() => {
    void refetchDashboard();
    void refetchPortfolios();
    void refetchAnalytics();
  }, [refetchAnalytics, refetchDashboard, refetchPortfolios]);
  const pullToRefresh = useCallback(() => {
    hapticRefresh();
    runRefresh();
  }, [runRefresh]);
  const openPortfolio = useCallback((portfolioId: string) => {
    router.push({ pathname: '/(app)/portfolio/[id]', params: { id: portfolioId } });
  }, [router]);
  const renderPortfolio = useCallback(({ item }: ListRenderItemInfo<Portfolio>) => (
    <PortfolioListItem portfolio={item} onPress={openPortfolio} />
  ), [openPortfolio]);
  const refreshControl = useMemo(() => (
    <RefreshControl
      refreshing={dashboard.isRefetching || portfolioQuery.isRefetching || analytics.isRefetching}
      onRefresh={pullToRefresh}
      tintColor={colors.accentBright}
      colors={[colors.accentBright]}
    />
  ), [analytics.isRefetching, colors.accentBright, dashboard.isRefetching, portfolioQuery.isRefetching, pullToRefresh]);
  const removePendingTransaction = useCallback((transactionId: string) => {
    Alert.alert(
      'Remove local trade?',
      'This permanently deletes the unsynced Quick Add entry from this device.',
      [
        { text: 'Keep', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => { void removePendingManualTransaction(transactionId); } },
      ],
    );
  }, [removePendingManualTransaction]);

  const header = useMemo(() => (
    <View>
      <View className="mb-5 flex-row items-start justify-between">
        <View className="flex-1 pr-3">
          <Eyebrow>FIFO WEALTH OS · PRIVATE PORTFOLIO</Eyebrow>
          <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Hello, {user?.name?.split(' ')[0] ?? 'Investor'}</Text>
          <Text className="mt-1 font-body text-sm text-muted">Your wealth at a glance.</Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Refresh dashboard"
          accessibilityHint="Refreshes your portfolio, allocation, and performance data."
          className="h-11 w-11 items-center justify-center rounded-2xl border border-stroke bg-surface"
          onPress={runRefresh}
        >
          <RefreshCw color={colors.ink} size={18} />
        </Pressable>
      </View>

      {dashboard.data?.stale && !isOffline ? (
        <View className="mb-4 rounded-2xl border border-gold/30 bg-gold/10 px-4 py-3">
          <Text className="font-body text-xs font-semibold text-gold">Refresh unavailable · showing your last encrypted snapshot.</Text>
        </View>
      ) : null}

      <Card className="overflow-hidden border-accent/30 bg-surface p-5">
        <View className="flex-row items-center justify-between">
          <Eyebrow>Total net worth · THB</Eyebrow>
          <StatusPill label={isOffline || dashboard.data?.stale ? 'Cached' : 'As of now'} tone={isOffline || dashboard.data?.stale ? 'muted' : 'good'} />
        </View>
        <Text className="mt-4 font-display text-3xl font-extrabold tracking-tight text-ink">{formatThb(summary?.summary.marketValueTHB)}</Text>
        <Text className="mt-2 font-body text-xs leading-5 text-muted">Estimated from the latest transaction mark recorded by the backend—not a live quote.</Text>
        {(isOffline || dashboard.data?.stale) && dashboard.data?.updatedAt ? (
          <Text className="mt-2 font-body text-[11px] font-semibold text-muted">Last updated: {formatDateTime(dashboard.data.updatedAt)}</Text>
        ) : null}
        <View className="mt-5 flex-row gap-3">
          <View className="flex-1 rounded-2xl bg-raised p-3">
            <Eyebrow>Open cost basis</Eyebrow>
            <Text className="mt-2 font-display text-base font-bold text-ink">{formatThb(summary?.summary.openCostBasisTHB)}</Text>
          </View>
          <View className="flex-1 rounded-2xl bg-raised p-3">
            <Eyebrow>Unrealized G/L</Eyebrow>
            <Text className={`mt-2 font-display text-base font-bold ${unrealizedIsNegative ? 'text-loss' : 'text-gain'}`}>
              {formatThb(summary?.summary.unrealizedGLTHB)}
            </Text>
          </View>
        </View>
        <View className="mt-3 flex-row items-center justify-between border-t border-stroke pt-3">
          <Text className="font-body text-xs text-muted">Realized gain/loss</Text>
          <Text className="font-display text-sm font-bold text-ink">{formatThb(summary?.summary.realizedGLTHB)}</Text>
        </View>
      </Card>

      <View className="mt-7 flex-row items-center justify-between">
        <SectionTitle title="My Portfolios" />
        <Link href="/(app)/portfolio/new" asChild>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Create a new portfolio"
            accessibilityHint="Opens the form to create a portfolio."
            className="mb-3 flex-row items-center gap-1 rounded-xl bg-accent/15 px-3 py-2"
          >
            <Plus color={colors.accentBright} size={15} />
            <Text className="font-body text-xs font-bold text-accent-bright">New</Text>
          </Pressable>
        </Link>
      </View>
    </View>
  ), [colors.accentBright, colors.ink, dashboard.data, isOffline, runRefresh, summary?.summary.marketValueTHB, summary?.summary.openCostBasisTHB, summary?.summary.realizedGLTHB, summary?.summary.unrealizedGLTHB, unrealizedIsNegative, user?.name]);
  const emptyPortfolioState = useMemo(() => (
    <EmptyState title="No portfolios yet" message="Create your first portfolio to start tracking transactions and FIFO lots." />
  ), []);
  const footer = useMemo(() => (
    <View>
      <View className="mt-7">
        <SectionTitle title="Asset Allocation" />
        {allocation.length ? (
          <Card>
            <View className="flex-row items-center gap-4">
              <AllocationDonut allocation={allocation} />
              <View className="flex-1 gap-3">
                {allocation.slice(0, 5).map((item, index) => (
                  <View key={item.key} className="flex-row items-center gap-2">
                    <View className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color ?? allocationColor(index) }} />
                    <Text numberOfLines={1} className="flex-1 font-body text-xs text-muted">{item.label}</Text>
                    <Text className="font-body text-xs font-bold text-ink">{item.weightPct}%</Text>
                  </View>
                ))}
              </View>
            </View>
            {!metrics ? <Text className="mt-3 font-body text-[11px] leading-4 text-muted">Showing current open holdings by symbol. Category analytics may require the advanced-analytics entitlement.</Text> : null}
            {(isOffline || analytics.data?.stale || dashboard.data?.stale) && allocationUpdatedAt ? (
              <Text className="mt-3 font-body text-[11px] font-semibold text-muted">Last updated: {formatDateTime(allocationUpdatedAt)}</Text>
            ) : null}
          </Card>
        ) : (
          <EmptyState title="No open holdings" message="Allocation appears when your portfolio contains open positions." />
        )}
      </View>

      <View className="mt-7">
        <View className="mb-3 flex-row items-center justify-between">
          <Text className="font-display text-base font-bold text-ink">Performance</Text>
          <View className="flex-row rounded-xl border border-stroke bg-surface p-1">
            {(['SP500', 'SET50'] as const).map((item) => (
              <Pressable
                key={item}
                accessibilityRole="button"
                accessibilityLabel={`Show ${item === 'SP500' ? 'S&P 500' : 'SET50'} benchmark`}
                accessibilityHint="Changes the benchmark used for server-calculated performance."
                accessibilityState={{ selected: benchmark === item }}
                className={`rounded-lg px-2.5 py-1.5 ${benchmark === item ? 'bg-raised' : ''}`}
                onPress={() => setBenchmark(item)}
              >
                <Text className={`font-body text-[10px] font-bold ${benchmark === item ? 'text-ink' : 'text-muted'}`}>{item === 'SP500' ? 'S&P 500' : 'SET50'}</Text>
              </Pressable>
            ))}
          </View>
        </View>
        <Card>
          {metrics?.benchmarkSeries.length ? (
            <>
              <PerformanceChart series={metrics.benchmarkSeries} />
              <View className="mt-2 flex-row items-center gap-4">
                <View className="flex-row items-center gap-1.5"><View className="h-2 w-2 rounded-full bg-accent-bright" /><Text className="font-body text-[10px] text-muted">Portfolio</Text></View>
                <View className="flex-row items-center gap-1.5"><View className="h-2 w-2 rounded-full bg-muted" /><Text className="font-body text-[10px] text-muted">{benchmark}</Text></View>
                <Text className="ml-auto font-body text-[10px] text-muted">{metrics.asOfDate}</Text>
              </View>
              <View className="mt-4 flex-row gap-3">
                <View className="flex-1 rounded-xl bg-raised p-3"><Eyebrow>XIRR</Eyebrow><Text className="mt-1 font-display text-sm font-bold text-ink">{formatPercentRatio(metrics.metrics.xirr)}</Text></View>
                <View className="flex-1 rounded-xl bg-raised p-3"><Eyebrow>Total return</Eyebrow><Text className="mt-1 font-display text-sm font-bold text-ink">{formatPercentRatio(metrics.metrics.totalReturn)}</Text></View>
                <View className="flex-1 rounded-xl bg-raised p-3"><Eyebrow>Max drawdown</Eyebrow><Text className="mt-1 font-display text-sm font-bold text-ink">{formatPercentRatio(metrics.metrics.maxDrawdown)}</Text></View>
              </View>
            </>
          ) : analytics.isError ? (
            <Text className="font-body text-sm leading-5 text-muted">Performance analytics are unavailable for this account or network. Portfolio totals remain available.</Text>
          ) : (
            <View className="h-36 items-center justify-center"><TrendingUp color={colors.muted} size={24} /><Text className="mt-3 font-body text-sm text-muted">Loading server-calculated history…</Text></View>
          )}
        </Card>
      </View>

      {pendingManual.transactions.length ? (
        <View className="mt-7">
          <SectionTitle
            title="Quick Add · Pending"
            action={<StatusPill label={`${pendingManual.transactions.length} local`} tone="muted" />}
          />
          <Card className="gap-4">
            <Text className="font-body text-xs leading-5 text-muted">
              These entries are saved locally and excluded from account totals. The current API has no transaction-create route, so they cannot sync yet.
            </Text>
            {visiblePendingTransactions.map((transaction) => {
              const portfolioName = portfolioNameById.get(transaction.portfolioId) ?? 'Portfolio';
              return (
                <View key={transaction.id} className="flex-row items-center gap-3 border-t border-stroke pt-3">
                  <View className={`h-10 w-10 items-center justify-center rounded-xl ${transaction.type === 'BUY' ? 'bg-accent/15' : 'bg-gain/10'}`}>
                    <Text className={`font-display text-xs font-extrabold ${transaction.type === 'BUY' ? 'text-accent-bright' : 'text-gain'}`}>
                      {transaction.type === 'BUY' ? 'B' : 'S'}
                    </Text>
                  </View>
                  <View className="flex-1">
                    <Text className="font-display text-sm font-bold text-ink">{transaction.symbol} · {transaction.type}</Text>
                    <Text className="mt-0.5 font-body text-[11px] text-muted">
                      {formatNumber(transaction.qty, 8)} @ {formatNumber(transaction.price, 8)} · {formatDate(transaction.date)}
                    </Text>
                    <Text className="mt-0.5 font-body text-[10px] text-muted">{portfolioName} · queued locally</Text>
                  </View>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Remove pending ${transaction.symbol} trade`}
                    accessibilityHint="Permanently deletes this unsynced local trade from this device."
                    className="h-9 w-9 items-center justify-center rounded-xl bg-raised"
                    onPress={() => removePendingTransaction(transaction.id)}
                  >
                    <Trash2 color={colors.muted} size={16} />
                  </Pressable>
                </View>
              );
            })}
          </Card>
        </View>
      ) : null}

      <View className="mt-7">
        <SectionTitle title="Recent activity" />
        {recentTransactions.length ? (
          <Card className="gap-4">
            {recentTransactions.map((transaction) => {
              const positive = transaction.type === 'BUY';
              const Icon = positive ? ArrowDownRight : ArrowUpRight;
              return (
                <View key={transaction.id} className="flex-row items-center gap-3">
                  <View className={`h-10 w-10 items-center justify-center rounded-xl ${positive ? 'bg-accent/15' : 'bg-gain/10'}`}>
                    <Icon color={positive ? colors.accentBright : colors.gain} size={18} />
                  </View>
                  <View className="flex-1">
                    <Text className="font-display text-sm font-bold text-ink">{transaction.symbol} · {transaction.type}</Text>
                    <Text className="mt-0.5 font-body text-xs text-muted">{formatDate(transaction.date)}</Text>
                  </View>
                  <Text className="font-body text-sm font-semibold text-ink">{formatThb(transaction.netTHB ?? transaction.net)}</Text>
                </View>
              );
            })}
          </Card>
        ) : (
          <EmptyState title="No activity yet" message="Your imported or connected transactions will appear here." />
        )}
        <View className="mt-3 gap-2">
          <Button title="View transaction ledger" variant="secondary" accessibilityHint="Opens the server-confirmed transaction ledger." onPress={() => router.push('/(app)/(tabs)/activity')} />
          <Button title="Review Thai tax summary" variant="secondary" accessibilityHint="Opens your Thai tax summary." onPress={() => router.push('/(app)/(tabs)/tax')} />
        </View>
      </View>

      {dashboard.isError && summary ? (
        <View className="mt-4"><InlineError message="Showing encrypted cached values because the latest refresh failed." onRetry={runRefresh} /></View>
      ) : null}
    </View>
  ), [allocation, allocationUpdatedAt, analytics.data?.stale, analytics.isError, benchmark, colors.accentBright, colors.gain, colors.muted, dashboard.data?.stale, dashboard.isError, isOffline, metrics, pendingManual.transactions, portfolioNameById, recentTransactions, removePendingTransaction, router, runRefresh, summary, visiblePendingTransactions]);

  if (dashboard.isPending && !summary) {
    return (
      <Screen>
        <View className="h-6 w-32 rounded-lg bg-raised" />
        <View className="mt-5 h-52 rounded-3xl bg-surface" />
        <View className="mt-4 h-44 rounded-3xl bg-surface" />
      </Screen>
    );
  }

  if (dashboard.isError && !summary) {
    return (
      <Screen>
        <InlineError message={dashboard.error.message} onRetry={runRefresh} />
      </Screen>
    );
  }

  return (
    <Screen
      scroll={false}
      contentClassName="p-0"
      floatingAction={<QuickAddTransaction portfolios={portfolioList} />}
    >
      <FlatList
        data={portfolioList}
        keyExtractor={portfolioKey}
        renderItem={renderPortfolio}
        ListHeaderComponent={header}
        ListEmptyComponent={emptyPortfolioState}
        ListFooterComponent={footer}
        refreshControl={refreshControl}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 150, flexGrow: 1 }}
        initialNumToRender={8}
        maxToRenderPerBatch={8}
        updateCellsBatchingPeriod={50}
        windowSize={7}
        removeClippedSubviews={Platform.OS === 'android'}
        showsVerticalScrollIndicator={false}
      />
    </Screen>
  );
}
