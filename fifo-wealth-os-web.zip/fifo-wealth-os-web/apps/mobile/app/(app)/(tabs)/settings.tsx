import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import { Alert, Pressable, Switch, Text, View } from 'react-native';
import { brokerApi } from '@/api/services';
import { getApiErrorMessage } from '@/api/client';
import type { LockTimeout } from '@/auth/tokenStore';
import type { ThaiBrokerId } from '@fifo/types';
import { ConnectedBrokers, type BrokerBusyState, type BrokerTarget } from '@/components/ConnectedBrokers';
import { isWeeklyReminderEnabled } from '@/auth/tokenStore';
import { useAuth } from '@/auth/AuthProvider';
import { Button, Card, Eyebrow, Field, InlineError, SectionTitle, StatusPill } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { clearSecureCache, isEncryptedCacheAvailable } from '@/cache/secureCache';
import { disableWeeklySummaryReminder, enableWeeklySummaryReminder } from '@/features/settings/reminders';
import { PENDING_MANUAL_TRANSACTIONS_QUERY_KEY } from '@/hooks/usePendingManualTransactions';
import { useMobileDashboard } from '@/hooks/useMobileData';
import { useTheme, type ThemePreference } from '@/theme/ThemeProvider';
import { useCallback, useEffect, useMemo, useState } from 'react';

const LOCK_OPTIONS: { value: LockTimeout; label: string }[] = [
  { value: 'immediately', label: 'Immediately' },
  { value: 'one-minute', label: '1 min' },
  { value: 'five-minutes', label: '5 min' },
];

const THEME_OPTIONS: { value: ThemePreference; label: string }[] = [
  { value: 'system', label: 'System' },
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
];

const THAI_BROKER_NAMES: Record<ThaiBrokerId, string> = {
  BITKUB: 'Bitkub',
  DIME: 'Dime',
  STREAMING: 'Streaming',
};

export default function SettingsScreen(): React.JSX.Element {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { colors, preference, setPreference } = useTheme();
  const { user, biometricEnabled, enableBiometricLock, disableBiometricLock, lockTimeout, updateLockTimeout, signOut } = useAuth();
  const dashboard = useMobileDashboard();
  const defaultPortfolioId = dashboard.data?.value.portfolios[0]?.id;
  const [flexQueryToken, setFlexQueryToken] = useState('');
  const [flexQueryId, setFlexQueryId] = useState('');
  const [bitkubApiKey, setBitkubApiKey] = useState('');
  const [bitkubApiSecret, setBitkubApiSecret] = useState('');
  const [pdpaConsent, setPdpaConsent] = useState(false);
  const [brokerMessage, setBrokerMessage] = useState('');
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [encryptedCacheAvailable, setEncryptedCacheAvailable] = useState(false);
  const [localSettingsError, setLocalSettingsError] = useState('');

  const ibkrQuery = useQuery({
    queryKey: ['mobile-ibkr-status'],
    queryFn: () => brokerApi.ibkrStatus(),
    staleTime: 60_000,
    retry: false,
  });
  const thaiBrokerQuery = useQuery({
    queryKey: ['mobile-thai-broker-status'],
    queryFn: () => brokerApi.thaiBrokerStatus(),
    staleTime: 60_000,
    retry: false,
  });

  useEffect(() => {
    let active = true;
    void Promise.all([isWeeklyReminderEnabled(), isEncryptedCacheAvailable()]).then(([reminder, cache]) => {
      if (!active) return;
      setReminderEnabled(reminder);
      setEncryptedCacheAvailable(cache);
    }).catch(() => {
      if (active) setLocalSettingsError('Secure local settings are unavailable on this build.');
    });
    return () => { active = false; };
  }, []);

  const connectIbkr = useMutation({
    mutationFn: () => brokerApi.connectIbkr({
      flexQueryToken: flexQueryToken.trim(),
      flexQueryId: flexQueryId.trim(),
      ...(defaultPortfolioId ? { portfolioId: defaultPortfolioId } : {}),
    }),
    onSuccess: async () => {
      setFlexQueryToken('');
      setFlexQueryId('');
      setBrokerMessage('IBKR credentials were submitted to the server and cleared from the form.');
      await queryClient.invalidateQueries({ queryKey: ['mobile-ibkr-status'] });
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const connectBitkub = useMutation({
    mutationFn: () => brokerApi.connectBitkub({
      apiKey: bitkubApiKey.trim(),
      apiSecret: bitkubApiSecret.trim(),
      ...(defaultPortfolioId ? { portfolioId: defaultPortfolioId } : {}),
      permissionsScope: 'READ_ONLY',
      pdpaConsent: {
        accepted: true,
        consentVersion: thaiBrokerQuery.data?.currentConsentVersion ?? '',
        purposes: ['READ_ONLY_PORTFOLIO_SYNC'],
      },
    }),
    onSuccess: async () => {
      setBitkubApiKey('');
      setBitkubApiSecret('');
      setPdpaConsent(false);
      setBrokerMessage('Bitkub read-only credentials were submitted to the server and cleared from the form.');
      await queryClient.invalidateQueries({ queryKey: ['mobile-thai-broker-status'] });
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const disconnectIbkr = useMutation({
    mutationFn: () => brokerApi.disconnectIbkr(),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['mobile-ibkr-status'] });
      setBrokerMessage('IBKR connection disconnected and encrypted credentials removed.');
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const disconnectThaiBroker = useMutation({
    mutationFn: (broker: ThaiBrokerId) => brokerApi.disconnectThaiBroker(broker),
    onSuccess: async (_data, broker) => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['mobile-thai-broker-status'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-dashboard-summary'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-transactions'] }),
      ]);
      setBrokerMessage(`${THAI_BROKER_NAMES[broker]} disconnected. The existing broker endpoint applied its purge-data policy.`);
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const syncIbkr = useMutation({
    mutationFn: () => brokerApi.syncIbkr(defaultPortfolioId),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['mobile-ibkr-status'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-dashboard-summary'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-transactions'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-portfolios'] }),
      ]);
      setBrokerMessage('IBKR sync completed. Server-confirmed transactions are being refreshed.');
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const syncThaiBroker = useMutation({
    mutationFn: (broker: ThaiBrokerId) => brokerApi.syncThaiBroker(broker, defaultPortfolioId),
    onSuccess: async (result, broker) => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['mobile-thai-broker-status'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-dashboard-summary'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-transactions'] }),
        queryClient.invalidateQueries({ queryKey: ['mobile-portfolios'] }),
      ]);
      setBrokerMessage(
        `${THAI_BROKER_NAMES[broker]} sync complete: ${result.addedTransactions} transactions and ${result.addedDividends} dividends added; ${result.skippedTransactions + result.skippedDividends} duplicates skipped.`,
      );
    },
    onError: (error: unknown) => setBrokerMessage(getApiErrorMessage(error)),
  });

  const { mutate: mutateDisconnectIbkr } = disconnectIbkr;
  const { mutate: mutateDisconnectThaiBroker } = disconnectThaiBroker;
  const { mutate: mutateSyncIbkr } = syncIbkr;
  const { mutate: mutateSyncThaiBroker } = syncThaiBroker;

  const handleBiometricToggle = (value: boolean): void => {
    setLocalSettingsError('');
    if (value) {
      void enableBiometricLock().then((enabled) => {
        if (!enabled) setLocalSettingsError('Biometrics are unavailable or not enrolled on this device.');
      }).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    } else {
      void disableBiometricLock().catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    }
  };

  const handleReminderToggle = (value: boolean): void => {
    setLocalSettingsError('');
    if (value) {
      void enableWeeklySummaryReminder().then((enabled) => {
        setReminderEnabled(enabled);
        if (!enabled) setLocalSettingsError('Notification permission was not granted.');
      }).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    } else {
      void disableWeeklySummaryReminder().then(() => setReminderEnabled(false)).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
    }
  };

  const confirmDisconnectIbkr = useCallback((): void => {
    Alert.alert('Disconnect IBKR?', 'This removes the encrypted Flex Query credentials from the server. Imported transactions remain.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Disconnect', style: 'destructive', onPress: () => mutateDisconnectIbkr() },
    ]);
  }, [mutateDisconnectIbkr]);

  const confirmDisconnectBroker = useCallback((broker: BrokerTarget): void => {
    if (broker === 'IBKR') {
      confirmDisconnectIbkr();
      return;
    }
    const name = THAI_BROKER_NAMES[broker];
    Alert.alert(
      `Disconnect ${name} and purge synced data?`,
      'The existing broker endpoint revokes consent, removes encrypted credentials, and purges imported transactions and dividends. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Purge & disconnect', style: 'destructive', onPress: () => mutateDisconnectThaiBroker(broker) },
      ],
    );
  }, [confirmDisconnectIbkr, mutateDisconnectThaiBroker]);

  const handleSyncBroker = useCallback((broker: BrokerTarget): void => {
    setBrokerMessage('');
    if (broker === 'IBKR') mutateSyncIbkr();
    else mutateSyncThaiBroker(broker);
  }, [mutateSyncIbkr, mutateSyncThaiBroker]);

  const clearOfflineData = (): void => {
    Alert.alert('Clear offline data?', 'This removes cached portfolio and transaction data, plus unsynced Quick Add entries from this device. Server data is not affected.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: () => {
        void clearSecureCache().then(() => {
          queryClient.removeQueries({ queryKey: ['mobile-dashboard-summary'] });
          queryClient.removeQueries({ queryKey: ['mobile-transactions'] });
          queryClient.removeQueries({ queryKey: PENDING_MANUAL_TRANSACTIONS_QUERY_KEY });
          setLocalSettingsError('');
          Alert.alert('Offline data cleared', 'Encrypted snapshots and pending Quick Add entries were removed from this device.');
        }).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
      } },
    ]);
  };

  const handleSignOut = (): void => {
    Alert.alert('Sign out?', 'Encrypted offline snapshots and pending Quick Add entries will be cleared from this device.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: () => {
        void signOut().catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
      } },
    ]);
  };

  const bitkub = thaiBrokerQuery.data?.connections.find((connection) => connection.broker === 'BITKUB');
  const hasIbkrConnection = Boolean(ibkrQuery.data && ibkrQuery.data.status !== 'DISCONNECTED');
  const hasBitkubConnection = Boolean(bitkub && bitkub.status !== 'DISCONNECTED');
  const canShowIbkrSetup = !hasIbkrConnection && !ibkrQuery.isPending && !ibkrQuery.isError;
  const canShowBitkubSetup = !hasBitkubConnection && !thaiBrokerQuery.isPending && !thaiBrokerQuery.isError;
  const anyBrokerBusy = connectIbkr.isPending
    || connectBitkub.isPending
    || disconnectIbkr.isPending
    || disconnectThaiBroker.isPending
    || syncIbkr.isPending
    || syncThaiBroker.isPending;
  const busyAction = useMemo<BrokerBusyState>(() => syncIbkr.isPending
    ? { broker: 'IBKR', action: 'sync' }
    : disconnectIbkr.isPending
      ? { broker: 'IBKR', action: 'disconnect' }
      : syncThaiBroker.isPending && syncThaiBroker.variables
        ? { broker: syncThaiBroker.variables, action: 'sync' }
        : disconnectThaiBroker.isPending && disconnectThaiBroker.variables
          ? { broker: disconnectThaiBroker.variables, action: 'disconnect' }
          : null, [disconnectIbkr.isPending, disconnectThaiBroker.isPending, disconnectThaiBroker.variables, syncIbkr.isPending, syncThaiBroker.isPending, syncThaiBroker.variables]);

  return (
    <Screen>
      <Eyebrow>DEVICE & ACCOUNT</Eyebrow>
      <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Settings</Text>
      <Text className="mt-1 font-body text-sm text-muted">{user?.email ?? 'Investor account'}</Text>

      <View className="mt-6">
        <SectionTitle title="App security" />
        <Card className="gap-4">
          <View className="flex-row items-center justify-between gap-4">
            <View className="flex-1"><Text className="font-body text-sm font-bold text-ink">Biometric app lock</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">Use Face ID or fingerprint when reopening the app.</Text></View>
            <Switch
              accessibilityLabel="Biometric app lock"
              accessibilityHint="Protects the app with Face ID or fingerprint when reopening it."
              accessibilityState={{ checked: biometricEnabled }}
              value={biometricEnabled}
              onValueChange={handleBiometricToggle}
              trackColor={{ false: colors.stroke, true: colors.accent }}
              thumbColor={biometricEnabled ? '#FFFFFF' : '#D0D2D9'}
            />
          </View>
          <View className="border-t border-stroke pt-4">
            <Text className="font-body text-xs font-bold uppercase tracking-widest text-muted">Lock after backgrounding</Text>
            <View className="mt-3 flex-row gap-2">
              {LOCK_OPTIONS.map((option) => (
                <Pressable
                  key={option.value}
                  accessibilityRole="button"
                  accessibilityLabel={`Lock app ${option.label === 'Immediately' ? 'immediately' : `after ${option.label}`}`}
                  accessibilityHint="Selects how quickly the app locks after backgrounding."
                  accessibilityState={{ selected: lockTimeout === option.value }}
                  onPress={() => {
                  setLocalSettingsError('');
                  void updateLockTimeout(option.value).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
                }} className={`flex-1 items-center rounded-xl border px-2 py-2.5 ${lockTimeout === option.value ? 'border-accent bg-accent/15' : 'border-stroke bg-raised'}`}>
                  <Text className={`font-body text-[11px] font-bold ${lockTimeout === option.value ? 'text-accent-bright' : 'text-muted'}`}>{option.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View className="border-t border-stroke pt-4">
            <View className="flex-row items-center justify-between gap-4">
              <View className="flex-1"><Text className="font-body text-sm font-bold text-ink">Weekly Wealth Summary</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">A device-local portfolio performance reminder every Monday at 9:00 AM. No remote push service is configured.</Text></View>
              <Switch
                accessibilityLabel="Weekly Wealth Summary reminder"
                accessibilityHint="Schedules or cancels the local Monday portfolio reminder."
                accessibilityState={{ checked: reminderEnabled }}
                value={reminderEnabled}
                onValueChange={handleReminderToggle}
                trackColor={{ false: colors.stroke, true: colors.accent }}
                thumbColor={reminderEnabled ? '#FFFFFF' : '#D0D2D9'}
              />
            </View>
          </View>
        </Card>
      </View>

      <View className="mt-7">
        <SectionTitle title="Appearance" />
        <Card>
          <Text className="font-body text-sm font-bold text-ink">Theme</Text>
          <Text className="mt-1 font-body text-xs leading-5 text-muted">Follow your device or choose a persistent light or dark palette.</Text>
          <View className="mt-3 flex-row gap-2">
            {THEME_OPTIONS.map((option) => (
              <Pressable
                key={option.value}
                accessibilityRole="button"
                accessibilityLabel={`${option.label} appearance`}
                accessibilityHint={`Uses the ${option.label.toLowerCase()} color palette.`}
                accessibilityState={{ selected: preference === option.value }}
                onPress={() => {
                  setLocalSettingsError('');
                  void setPreference(option.value).catch((error: unknown) => setLocalSettingsError(getApiErrorMessage(error)));
                }}
                className={`flex-1 items-center rounded-xl border px-2 py-2.5 ${preference === option.value ? 'border-accent bg-accent/15' : 'border-stroke bg-raised'}`}
              >
                <Text className={`font-body text-[11px] font-bold ${preference === option.value ? 'text-accent-bright' : 'text-muted'}`}>{option.label}</Text>
              </Pressable>
            ))}
          </View>
          <Text className="mt-3 font-body text-[11px] leading-5 text-muted">Brand palette: #14342A with #FAFAFA light surfaces and #121212 dark surfaces.</Text>
          <Button className="mt-4" title="Open NativeWind Hello World" accessibilityHint="Opens the NativeWind styling verification screen." variant="secondary" onPress={() => router.push('/(app)/nativewind-verification')} />
        </Card>
      </View>

      <View className="mt-7">
        <SectionTitle title="Encrypted offline cache" />
        <Card>
          <View className="flex-row items-center justify-between">
            <View className="flex-1 pr-3"><Text className="font-body text-sm font-bold text-ink">SQLCipher storage</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">Dashboard and ledger snapshots use an installation-specific key kept in SecureStore.</Text></View>
            <StatusPill label={encryptedCacheAvailable ? 'Encrypted' : 'Unavailable'} tone={encryptedCacheAvailable ? 'good' : 'bad'} />
          </View>
          <Button className="mt-4" title="Clear offline snapshots" accessibilityHint="Asks for confirmation before deleting cached data and local Quick Add entries from this device." variant="secondary" onPress={clearOfflineData} />
        </Card>
      </View>

      <View className="mt-7">
        <SectionTitle title="Connected brokers" />
        {ibkrQuery.isError ? (
          <View className="mb-3">
            <InlineError message={getApiErrorMessage(ibkrQuery.error)} onRetry={() => { void ibkrQuery.refetch(); }} />
          </View>
        ) : null}
        {thaiBrokerQuery.isError ? (
          <View className="mb-3">
            <InlineError message={getApiErrorMessage(thaiBrokerQuery.error)} onRetry={() => { void thaiBrokerQuery.refetch(); }} />
          </View>
        ) : null}
        <ConnectedBrokers
          ibkr={ibkrQuery.data}
          thaiConnections={thaiBrokerQuery.data?.connections}
          ibkrLoading={ibkrQuery.isPending}
          thaiLoading={thaiBrokerQuery.isPending}
          ibkrUnavailable={ibkrQuery.isError}
          thaiUnavailable={thaiBrokerQuery.isError}
          busyAction={busyAction}
          onSync={handleSyncBroker}
          onDisconnect={confirmDisconnectBroker}
        />
        {brokerMessage ? <Text accessibilityRole="alert" className="mt-3 font-body text-xs leading-5 text-muted">{brokerMessage}</Text> : null}
        {anyBrokerBusy ? <Text className="mt-2 font-body text-xs text-muted">Securely processing broker request…</Text> : null}
      </View>

      {canShowIbkrSetup || canShowBitkubSetup ? (
        <View className="mt-7">
          <SectionTitle title="Connect a broker" />
          {canShowIbkrSetup ? (
            <Card className="gap-4">
              <View>
                <Text className="font-display text-sm font-bold text-ink">Interactive Brokers</Text>
                <Text className="mt-1 font-body text-xs text-muted">Flex Query · read-only credentials</Text>
              </View>
              <Field label="Flex Query token" value={flexQueryToken} onChangeText={setFlexQueryToken} secureTextEntry autoCapitalize="none" placeholder="Token" />
              <Field label="Flex Query ID" value={flexQueryId} onChangeText={setFlexQueryId} keyboardType="number-pad" placeholder="Query ID" />
              <Button title="Connect IBKR" accessibilityHint="Submits the read-only Flex Query credentials to the API." loading={connectIbkr.isPending} disabled={!flexQueryToken.trim() || !flexQueryId.trim() || anyBrokerBusy} onPress={() => { setBrokerMessage(''); connectIbkr.mutate(); }} />
            </Card>
          ) : null}
          {canShowBitkubSetup ? (
            <Card className={`${canShowIbkrSetup ? 'mt-3 ' : ''}gap-4`}>
              <View>
                <Text className="font-display text-sm font-bold text-ink">Bitkub</Text>
                <Text className="mt-1 font-body text-xs text-muted">API key · read-only</Text>
              </View>
              <Field label="Bitkub API key" value={bitkubApiKey} onChangeText={setBitkubApiKey} secureTextEntry autoCapitalize="none" placeholder="Read-only API key" />
              <Field label="Bitkub API secret" value={bitkubApiSecret} onChangeText={setBitkubApiSecret} secureTextEntry autoCapitalize="none" placeholder="API secret" />
              <Pressable accessibilityRole="checkbox" accessibilityLabel="Consent to read-only Bitkub sync" accessibilityHint="Toggles your consent for importing portfolio data from Bitkub." accessibilityState={{ checked: pdpaConsent }} className="flex-row items-start gap-3 rounded-xl border border-stroke bg-raised p-3" onPress={() => setPdpaConsent((current) => !current)}>
                <View className={`mt-0.5 h-5 w-5 items-center justify-center rounded-md border ${pdpaConsent ? 'border-accent bg-accent' : 'border-muted'}`}>{pdpaConsent ? <Text className="text-xs font-bold text-white">✓</Text> : null}</View>
                <Text className="flex-1 font-body text-xs leading-5 text-muted">I consent to read-only Bitkub sync for portfolio import and understand the broker data privacy notice.</Text>
              </Pressable>
              <Button title="Connect Bitkub" accessibilityHint="Submits read-only Bitkub credentials and consent to the API." loading={connectBitkub.isPending} disabled={!bitkubApiKey.trim() || !bitkubApiSecret.trim() || !pdpaConsent || anyBrokerBusy} onPress={() => { setBrokerMessage(''); connectBitkub.mutate(); }} />
              <Text className="font-body text-[11px] leading-5 text-muted">Credentials are sent only to the API and never cached on-device. The existing backend encrypts broker credentials at rest using AES-256-GCM. Production requires HTTPS and a configured server ENCRYPTION_KEY.</Text>
            </Card>
          ) : null}
        </View>
      ) : null}

      {localSettingsError ? <View className="mt-4"><InlineError message={localSettingsError} /></View> : null}
      <Card className="mt-7">
        <Text className="font-display text-sm font-bold text-ink">Session security</Text>
        <Text className="mt-2 font-body text-xs leading-5 text-muted">The access token stays in the device Keychain/Keystore. The server has no refresh-token endpoint; expired sessions require a fresh sign-in. JWT_SECRET and ENCRYPTION_KEY are server-only and are never included in the app.</Text>
        <Button className="mt-4" title="Sign out" accessibilityHint="Asks for confirmation before clearing local encrypted data and ending the session." variant="danger" onPress={handleSignOut} />
      </Card>
      <Text className="mt-6 text-center font-body text-[10px] text-muted">FIFO Wealth OS Mobile · API {process.env.EXPO_PUBLIC_APP_ENV ?? 'development'}</Text>
    </Screen>
  );
}
