import { Tabs } from 'expo-router';
import { BriefcaseBusiness, ChartNoAxesCombined, House, UserRound } from 'lucide-react-native';
import { useTheme } from '@/theme/ThemeProvider';

export default function TabLayout(): React.JSX.Element {
  const { colors } = useTheme();
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.accentBright,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          height: 76,
          paddingTop: 10,
          paddingBottom: 12,
          backgroundColor: colors.surface,
          borderTopColor: colors.stroke,
        },
        tabBarLabelStyle: {
          fontFamily: 'System',
          fontSize: 10,
          fontWeight: '700',
          marginTop: 2,
        },
        tabBarHideOnKeyboard: true,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <House color={color} size={size} strokeWidth={2.1} />,
        }}
      />
      <Tabs.Screen
        name="portfolios"
        options={{
          title: 'Portfolios',
          tabBarIcon: ({ color, size }) => <BriefcaseBusiness color={color} size={size} strokeWidth={2.1} />,
        }}
      />
      <Tabs.Screen
        name="advanced-assets"
        options={{
          title: 'Advanced Assets',
          tabBarIcon: ({ color, size }) => <ChartNoAxesCombined color={color} size={size} strokeWidth={2.1} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Profile',
          tabBarIcon: ({ color, size }) => <UserRound color={color} size={size} strokeWidth={2.1} />,
        }}
      />
      <Tabs.Screen name="activity" options={{ href: null }} />
      <Tabs.Screen name="tax" options={{ href: null }} />
    </Tabs>
  );
}
