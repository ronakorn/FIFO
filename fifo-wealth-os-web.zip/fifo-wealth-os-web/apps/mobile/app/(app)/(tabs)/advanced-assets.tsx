import { useRouter } from 'expo-router';
import { useCallback } from 'react';
import { Alert, Text, View } from 'react-native';
import { AdvancedAssetSummaryCard } from '@/components/AdvancedAssetSummaryCard';
import { Button, Card, Eyebrow, SectionTitle, StatusPill } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { ADVANCED_ASSET_SAMPLE_DATA } from '@/features/advancedAssets/sampleData';
import { openAdvancedAssetsWeb } from '@/features/advancedAssets/webLink';

export default function AdvancedAssetsScreen(): React.JSX.Element {
  const router = useRouter();

  const handleViewWeb = useCallback(async (): Promise<void> => {
    try {
      const result = await openAdvancedAssetsWeb();
      if (result === 'not-configured') {
        Alert.alert(
          'Web app link not configured',
          'Set EXPO_PUBLIC_WEB_URL to the web app origin, then reload the mobile app to enable this link.',
        );
      }
    } catch (error: unknown) {
      Alert.alert(
        'Unable to open the web app',
        error instanceof Error ? error.message : 'Check the web URL configuration and try again.',
      );
    }
  }, []);

  return (
    <Screen>
      <Eyebrow>RESEARCH & RISK</Eyebrow>
      <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Advanced assets</Text>
      <Text className="mt-1 font-body text-sm leading-5 text-muted">
        Read-only snapshot cards for specialized asset classes.
      </Text>

      <Card className="mt-5 gap-3 border-gold/30 bg-gold/5">
        <View className="flex-row items-center gap-2">
          <StatusPill label="Sample Data" tone="warning" />
          <Text className="flex-1 font-body text-xs font-semibold leading-5 text-ink">Illustrative metrics only</Text>
        </View>
        <Text className="font-body text-xs leading-5 text-muted">
          Advanced-asset metrics are not included in the current mobile dashboard summary. These values are examples, not account data; this screen does not run financial calculators.
        </Text>
      </Card>

      <View className="mt-6">
        <SectionTitle title="Illustrative summaries" />
        <View className="gap-3">
          {ADVANCED_ASSET_SAMPLE_DATA.map((summary) => (
            <AdvancedAssetSummaryCard
              key={summary.id}
              summary={summary}
              onViewWeb={handleViewWeb}
            />
          ))}
        </View>
      </View>

      <Button
        className="mt-5"
        title="Go to portfolio overview"
        accessibilityHint="Returns to the main portfolio dashboard."
        variant="secondary"
        onPress={() => router.replace('/(app)/(tabs)')}
      />
    </Screen>
  );
}
