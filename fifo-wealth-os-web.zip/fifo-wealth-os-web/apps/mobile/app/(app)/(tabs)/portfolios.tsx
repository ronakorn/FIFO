import { Stack, useRouter } from 'expo-router';
import { Plus } from 'lucide-react-native';
import { useCallback, useMemo } from 'react';
import { FlatList, Platform, RefreshControl, Text, View } from 'react-native';
import type { Portfolio } from '@/api/types';
import { Button, Card, EmptyState, Eyebrow, InlineError, SectionTitle } from '@/components/Primitives';
import { PortfolioListItem } from '@/components/PortfolioListItem';
import { Screen } from '@/components/Screen';
import { useMobileDashboard } from '@/hooks/useMobileData';
import { hapticRefresh } from '@/lib/haptics';
import { useTheme } from '@/theme/ThemeProvider';

const EMPTY_PORTFOLIOS: Portfolio[] = [];

export default function PortfoliosScreen(): React.JSX.Element {
  const router = useRouter();
  const { colors } = useTheme();
  const dashboard = useMobileDashboard();
  const { refetch: refetchDashboard } = dashboard;
  const portfolios = useMemo(
    () => dashboard.data?.value.portfolios ?? EMPTY_PORTFOLIOS,
    [dashboard.data?.value.portfolios],
  );
  const openPortfolio = useCallback((portfolioId: string) => {
    router.push({ pathname: '/(app)/portfolio/[id]', params: { id: portfolioId } });
  }, [router]);
  const refresh = useCallback(() => {
    hapticRefresh();
    void refetchDashboard();
  }, [refetchDashboard]);
  const refreshControl = useMemo(() => (
    <RefreshControl
      refreshing={dashboard.isRefetching}
      onRefresh={refresh}
      tintColor={colors.accentBright}
      colors={[colors.accentBright]}
    />
  ), [colors.accentBright, dashboard.isRefetching, refresh]);
  const header = useMemo(() => (
    <View>
      <Stack.Screen options={{ title: 'Portfolios', headerShown: true, headerTintColor: colors.ink, headerStyle: { backgroundColor: colors.midnight }, headerTitleStyle: { color: colors.ink } }} />
      <Eyebrow>PORTFOLIO MANAGEMENT</Eyebrow>
      <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Portfolios</Text>
      <Text className="mt-1 font-body text-sm leading-5 text-muted">Open server-calculated FIFO holdings and manage your portfolio spaces.</Text>
      {dashboard.data?.stale ? (
        <View className="mt-4 rounded-2xl border border-gold/30 bg-gold/10 px-4 py-3">
          <Text className="font-body text-xs font-semibold text-gold">Offline view · showing the last encrypted portfolio snapshot.</Text>
        </View>
      ) : null}
      <Button
        className="mt-5"
        title="Create portfolio"
        accessibilityHint="Opens the form to create a portfolio."
        icon={<Plus color="#FFFFFF" size={17} />}
        onPress={() => router.push('/(app)/portfolio/new')}
      />
      <View className="mt-7">
        <SectionTitle title={`Your portfolios (${portfolios.length})`} />
      </View>
    </View>
  ), [colors.ink, colors.midnight, dashboard.data?.stale, portfolios.length, router]);
  const empty = useMemo(() => (
    <Card><EmptyState title="No portfolios yet" message="Create a portfolio to begin tracking server-calculated holdings and activity." /></Card>
  ), []);
  const footer = useMemo(() => portfolios.length ? (
    <View className="mt-7 gap-3">
      <Button title="Open transaction ledger" variant="secondary" accessibilityHint="Opens the server-confirmed transaction ledger." onPress={() => router.push('/(app)/(tabs)/activity')} />
      <Button title="Review Thai tax summary" variant="secondary" accessibilityHint="Opens your Thai tax summary." onPress={() => router.push('/(app)/(tabs)/tax')} />
    </View>
  ) : null, [portfolios.length, router]);

  if (dashboard.isPending && !dashboard.data) {
    return (
      <Screen>
        <View className="h-6 w-32 rounded-lg bg-raised" />
        <View className="mt-5 h-32 rounded-3xl bg-surface" />
        <View className="mt-4 h-32 rounded-3xl bg-surface" />
      </Screen>
    );
  }

  if (dashboard.isError && !dashboard.data) {
    return <Screen><InlineError message={dashboard.error.message} onRetry={() => { void dashboard.refetch(); }} /></Screen>;
  }

  return (
    <Screen scroll={false} contentClassName="p-0">
      <FlatList
        data={portfolios}
        keyExtractor={(portfolio) => portfolio.id}
        renderItem={({ item }) => <PortfolioListItem portfolio={item} onPress={openPortfolio} />}
        ItemSeparatorComponent={PortfolioSeparator}
        ListHeaderComponent={header}
        ListEmptyComponent={empty}
        ListFooterComponent={footer}
        refreshControl={refreshControl}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 20, paddingBottom: 32, flexGrow: 1 }}
        initialNumToRender={8}
        maxToRenderPerBatch={8}
        updateCellsBatchingPeriod={50}
        windowSize={7}
        removeClippedSubviews={Platform.OS === 'android'}
        showsVerticalScrollIndicator={false}
      />
    </Screen>
  );
}

function PortfolioSeparator(): React.JSX.Element {
  return <View className="h-3" />;
}
