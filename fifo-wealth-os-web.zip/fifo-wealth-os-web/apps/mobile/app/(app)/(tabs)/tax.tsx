import { useEffect, useState } from 'react';
import { Alert, Pressable, Text, TextInput, View } from 'react-native';
import { useAuth } from '@/auth/AuthProvider';
import { Button, Card, EmptyState, Eyebrow, InlineError, SectionTitle } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { mobileApi } from '@/api/services';
import { useMobileDashboard, useTaxSummary } from '@/hooks/useMobileData';
import { formatDate, formatThb } from '@/lib/formatters';
import { getApiErrorMessage } from '@/api/client';
import type { Portfolio } from '@/api/types';
import { useTheme } from '@/theme/ThemeProvider';

const EMPTY_PORTFOLIOS: Portfolio[] = [];

export default function TaxScreen(): React.JSX.Element {
  const { status } = useAuth();
  const { colors } = useTheme();
  const dashboard = useMobileDashboard();
  const portfolios = dashboard.data?.value.portfolios ?? EMPTY_PORTFOLIOS;
  const [manuallySelectedPortfolioId, setManuallySelectedPortfolioId] = useState('');
  const portfolioId = portfolios.some((portfolio) => portfolio.id === manuallySelectedPortfolioId)
    ? manuallySelectedPortfolioId
    : portfolios[0]?.id ?? '';
  const [taxYear, setTaxYear] = useState(String(new Date().getFullYear()));
  const [otherIncome, setOtherIncome] = useState('');
  const [stableIncome, setStableIncome] = useState('');
  const [electFinalTax, setElectFinalTax] = useState(false);
  const [exportBusy, setExportBusy] = useState(false);
  const [exportError, setExportError] = useState('');
  const year = Number(taxYear);
  const incomePattern = /^(?:\d+\.?\d*|\.\d+)$/;
  const validOtherIncome = !otherIncome.trim() || incomePattern.test(otherIncome.trim());
  const validStableIncome = !stableIncome || incomePattern.test(stableIncome);
  const taxQuery = useTaxSummary(portfolioId || undefined, year, {
    electFinalTaxOnDividends: electFinalTax,
    ...(validStableIncome && stableIncome ? { otherNetIncomeTHB: stableIncome } : {}),
  });

  useEffect(() => {
    const timer = setTimeout(() => setStableIncome(otherIncome.trim()), 350);
    return () => clearTimeout(timer);
  }, [otherIncome]);

  const report = validOtherIncome ? taxQuery.data?.value : undefined;
  const validYear = Number.isInteger(year) && year >= 1900 && year <= 3000;

  const exportReport = async (): Promise<void> => {
    if (!portfolioId || !validYear || !validOtherIncome) return;
    setExportBusy(true);
    setExportError('');
    try {
      await mobileApi.downloadTaxReport(portfolioId, year, {
        electFinalTaxOnDividends: electFinalTax,
        ...(otherIncome.trim() ? { otherNetIncomeTHB: otherIncome.trim() } : {}),
      });
    } catch (error) {
      const message = getApiErrorMessage(error);
      setExportError(message);
      Alert.alert('Report unavailable', message);
    } finally {
      setExportBusy(false);
    }
  };

  if (status !== 'signed-in') return <View className="flex-1 bg-midnight" />;

  return (
    <Screen>
      <Eyebrow>SERVER-CALCULATED · THB</Eyebrow>
      <Text className="mt-2 font-display text-2xl font-extrabold text-ink">Tax overview</Text>
      <Text className="mt-1 font-body text-sm leading-5 text-muted">Thai investment tax summary from the existing tax engine.</Text>

      <View className="mt-6">
        <Eyebrow>PORTFOLIO</Eyebrow>
        {portfolios.length ? (
          <View className="mt-2 flex-row flex-wrap gap-2">
            {portfolios.map((portfolio) => (
              <Pressable
                key={portfolio.id}
                accessibilityRole="button"
                accessibilityLabel={`Select ${portfolio.name} portfolio`}
                accessibilityHint="Changes which portfolio is used for the tax summary."
                accessibilityState={{ selected: portfolioId === portfolio.id }}
                className={`rounded-full border px-3 py-2 ${portfolioId === portfolio.id ? 'border-accent bg-accent/20' : 'border-stroke bg-surface'}`}
                onPress={() => setManuallySelectedPortfolioId(portfolio.id)}
              >
                <Text className={`font-body text-xs font-bold ${portfolioId === portfolio.id ? 'text-accent-bright' : 'text-muted'}`}>{portfolio.name}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}
      </View>

      <View className="mt-5 flex-row items-end gap-3">
        <View className="flex-1">
          <Eyebrow>Tax year</Eyebrow>
          <TextInput
            accessibilityLabel="Tax year"
            accessibilityHint={validYear ? 'Enter a four-digit tax year for the backend tax summary.' : 'Invalid year. Enter a four-digit year between 1900 and 3000.'}
            className="mt-2 min-h-12 rounded-2xl border border-stroke bg-raised px-4 py-3 font-display text-base font-bold text-ink"
            value={taxYear}
            onChangeText={setTaxYear}
            keyboardType="number-pad"
            maxLength={4}
            placeholder="2026"
            placeholderTextColor={colors.muted}
          />
        </View>
        <View className="flex-[2]">
          <Eyebrow>Other net income (optional)</Eyebrow>
          <TextInput
            accessibilityLabel="Other net assessable income in Thai baht"
            accessibilityHint={validOtherIncome ? 'Optionally enter a non-negative decimal amount in Thai baht.' : 'Invalid amount. Enter a non-negative decimal value.'}
            className="mt-2 min-h-12 rounded-2xl border border-stroke bg-raised px-4 py-3 font-body text-base text-ink"
            value={otherIncome}
            onChangeText={setOtherIncome}
            keyboardType="decimal-pad"
            placeholder="THB"
            placeholderTextColor={colors.muted}
          />
        </View>
      </View>
      {!validYear || !validOtherIncome ? <Text accessibilityRole="alert" className="mt-2 font-body text-xs text-loss">Enter a valid year and a non-negative decimal income amount.</Text> : null}

      <Pressable
        accessibilityRole="checkbox"
        accessibilityLabel="Elect final tax for eligible dividends"
        accessibilityHint="Toggles the backend-supported dividend tax treatment option."
        accessibilityState={{ checked: electFinalTax }}
        onPress={() => setElectFinalTax((value) => !value)}
        className="mt-4 flex-row items-start gap-3 rounded-2xl border border-stroke bg-surface p-4"
      >
        <View className={`mt-0.5 h-5 w-5 items-center justify-center rounded-md border ${electFinalTax ? 'border-accent bg-accent' : 'border-muted'}`}>
          {electFinalTax ? <Text className="font-display text-xs font-bold text-white">✓</Text> : null}
        </View>
        <View className="flex-1">
          <Text className="font-body text-sm font-bold text-ink">Elect final tax for eligible dividends</Text>
          <Text className="mt-1 font-body text-xs leading-5 text-muted">Uses the same dividend treatment option supported by the backend. Review your eligibility with a tax professional.</Text>
        </View>
      </Pressable>

      {!portfolios.length && dashboard.data ? <View className="mt-5"><EmptyState title="No portfolios yet" message="Create a portfolio and add transactions before opening a tax summary." /></View> : null}
      {portfolios.length > 0 && validYear && taxQuery.isPending && !report ? <View className="mt-5 h-32 rounded-3xl bg-surface" /> : null}
      {portfolios.length > 0 && taxQuery.isError && !report ? <View className="mt-5"><InlineError message={taxQuery.error.message} onRetry={() => { void taxQuery.refetch(); }} /></View> : null}

      {report ? (
        <>
          {taxQuery.data?.stale ? <View className="mt-4 rounded-xl border border-gold/30 bg-gold/10 px-3 py-2"><Text className="font-body text-xs text-gold">Offline · cached tax summary for these options.</Text></View> : null}
          <Card className="mt-5 border-accent/30 bg-surface">
            <View className="flex-row items-center justify-between">
              <Eyebrow>Estimated tax · {report.taxYear}</Eyebrow>
              <Text className="font-body text-[10px] text-muted">THB</Text>
            </View>
            <Text className="mt-4 font-display text-3xl font-extrabold text-ink">{formatThb(report.totalTaxPayable)}</Text>
            <View className="mt-4 gap-3 border-t border-stroke pt-4">
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Taxable income</Text><Text className="font-body text-sm font-semibold text-ink">{formatThb(report.totalTaxableIncome)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Tax withheld</Text><Text className="font-body text-sm font-semibold text-ink">{formatThb(report.totalTaxWithheld)}</Text></View>
              <View className="flex-row justify-between"><Text className="font-body text-sm text-muted">Net tax payable</Text><Text className="font-body text-sm font-bold text-ink">{formatThb(report.totalTaxPayable)}</Text></View>
            </View>
          </Card>

          <View className="mt-5">
            <Button title="Export tax report PDF" accessibilityHint="Downloads a server-generated tax report for the selected portfolio and year." loading={exportBusy} disabled={!portfolioId || !validYear || !validOtherIncome} onPress={exportReport} />
            {exportError ? <Text className="mt-2 font-body text-xs text-loss">{exportError}</Text> : null}
          </View>

          <View className="mt-7">
            <SectionTitle title={`Capital gains (${report.capitalGains.length})`} />
            {report.capitalGains.length ? (
              <Card className="gap-4">
                {report.capitalGains.slice(0, 20).map((event) => (
                  <View key={event.id} className="flex-row items-center justify-between gap-3">
                    <View className="flex-1"><Text className="font-display text-sm font-bold text-ink">{event.symbol}</Text><Text className="mt-1 font-body text-xs text-muted">{formatDate(event.date)}</Text></View>
                    <View className="items-end"><Text className="font-body text-xs text-muted">Gain</Text><Text className="font-body text-sm font-semibold text-ink">{formatThb(event.amountTHB)}</Text></View>
                  </View>
                ))}
              </Card>
            ) : <EmptyState title="No capital gains" message="No taxable capital-gain events were returned for this year." />}
          </View>

          <View className="mt-7">
            <SectionTitle title={`Dividends (${report.dividends.length})`} />
            {report.dividends.length ? (
              <Card className="gap-4">
                {report.dividends.slice(0, 20).map((event) => (
                  <View key={event.id} className="flex-row items-center justify-between gap-3">
                    <View className="flex-1"><Text className="font-display text-sm font-bold text-ink">{event.symbol}</Text><Text className="mt-1 font-body text-xs text-muted">{formatDate(event.date)}</Text></View>
                    <View className="items-end"><Text className="font-body text-xs text-muted">Net income</Text><Text className="font-body text-sm font-semibold text-ink">{formatThb(event.amountTHB)}</Text></View>
                  </View>
                ))}
              </Card>
            ) : <EmptyState title="No dividends" message="No dividend events were returned for this year." />}
          </View>
        </>
      ) : null}

      <View className="mt-7 rounded-2xl border border-gold/20 bg-gold/10 p-4">
        <Text className="font-body text-xs leading-5 text-gold">This is a Thai tax summary from the backend. It is not U.S. tax advice or a U.S. tax-filing calculation. Foreign-equity/crypto treatment follows server tax profiles and should be reviewed with a qualified tax professional.</Text>
      </View>
    </Screen>
  );
}
