import '../global.css';
import { isRunningInExpoGo } from 'expo';
import * as SplashScreen from 'expo-splash-screen';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider, useAuth } from '@/auth/AuthProvider';
import { Button } from '@/components/Primitives';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { migrateWeeklySummaryReminder } from '@/features/settings/reminders';
import { QueryRuntimeProvider } from '@/providers';
import { ThemeProvider, useTheme } from '@/theme/ThemeProvider';

void SplashScreen.preventAutoHideAsync().catch(() => undefined);
if (!isRunningInExpoGo()) SplashScreen.setOptions({ duration: 500, fade: true });

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      gcTime: 12 * 60 * 60 * 1000,
      retry: 1,
      refetchOnWindowFocus: true,
    },
    mutations: { retry: 0 },
  },
});

function BootScreen(): React.JSX.Element {
  const { colors } = useTheme();
  return (
    <View className="flex-1 items-center justify-center bg-midnight">
      <ActivityIndicator color={colors.accentBright} size="large" />
      <Text className="mt-4 font-body text-sm text-muted">Securing your session…</Text>
    </View>
  );
}

function UnlockScreen(): React.JSX.Element {
  const { unlock, signOut } = useAuth();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('Use your device biometrics to continue.');

  const handleUnlock = async (): Promise<void> => {
    setBusy(true);
    try {
      const unlocked = await unlock();
      if (!unlocked) setMessage('Biometric verification did not complete. Try again or use your password instead.');
    } catch {
      setMessage('Biometric authentication is unavailable. Use your password instead.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <View className="flex-1 justify-center bg-midnight px-7">
      <View className="mb-8 h-16 w-16 items-center justify-center rounded-3xl border border-accent/30 bg-accent/15">
        <Text className="font-display text-2xl font-extrabold text-accent-bright">F</Text>
      </View>
      <Text className="font-display text-3xl font-extrabold text-ink">Welcome back</Text>
      <Text className="mt-3 font-body text-base leading-6 text-muted">{message}</Text>
      <Button className="mt-8" title={busy ? 'Authenticating…' : 'Login with Face ID / Touch ID'} accessibilityHint="Starts device biometric authentication to unlock the app." loading={busy} onPress={handleUnlock} />
      <Button className="mt-3" title="Use password instead" accessibilityHint="Signs out so you can continue with your account password." variant="ghost" onPress={signOut} />
    </View>
  );
}

function RouterRoot(): React.JSX.Element {
  const { status, locked } = useAuth();
  const { colors } = useTheme();
  useEffect(() => {
    if (status !== 'loading') void SplashScreen.hideAsync().catch(() => undefined);
  }, [status]);

  if (status === 'loading') return <BootScreen />;
  if (status === 'signed-in' && locked) return <UnlockScreen />;

  return (
    <ErrorBoundary>
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.midnight } }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="(app)" />
      </Stack>
    </ErrorBoundary>
  );
}

export default function RootLayout(): React.JSX.Element {
  useEffect(() => {
    void migrateWeeklySummaryReminder().catch(() => undefined);
  }, []);

  return (
    <ThemeProvider>
      <SafeAreaProvider>
        <QueryClientProvider client={queryClient}>
          <QueryRuntimeProvider>
            <AuthProvider>
              <StatusBar style="auto" />
              <RouterRoot />
            </AuthProvider>
          </QueryRuntimeProvider>
        </QueryClientProvider>
      </SafeAreaProvider>
    </ThemeProvider>
  );
}
