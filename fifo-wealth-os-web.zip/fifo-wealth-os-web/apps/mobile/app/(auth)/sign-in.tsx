import { Link } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Text, View } from 'react-native';
import { getApiErrorMessage } from '@/api/client';
import { useAuth } from '@/auth/AuthProvider';
import { Button, Field, StatusPill } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { hapticWarning } from '@/lib/haptics';

export default function SignInScreen(): React.JSX.Element {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (): Promise<void> => {
    setError('');
    if (!email.includes('@')) {
      hapticWarning();
      setError('Enter a valid email address.');
      return;
    }
    if (!password) {
      hapticWarning();
      setError('Enter your password.');
      return;
    }
    setBusy(true);
    try {
      await signIn(email, password);
    } catch (reason) {
      setError(getApiErrorMessage(reason));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen scroll={false} contentClassName="flex-1 justify-center pb-8 pt-8">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View className="mb-8 h-14 w-14 items-center justify-center rounded-2xl border border-accent/30 bg-accent/15">
          <Text className="font-display text-2xl font-extrabold text-accent-bright">F</Text>
        </View>
        <StatusPill label="Secure portfolio access" tone="good" />
        <Text className="mt-5 font-display text-3xl font-extrabold leading-10 text-ink">Your wealth, in view.</Text>
        <Text className="mt-2 font-body text-base leading-6 text-muted">Sign in to see your portfolios, FIFO lots, and tax summaries.</Text>

        <View className="mt-8 gap-4">
          <Field
            label="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
            textContentType="emailAddress"
            returnKeyType="next"
            placeholder="you@example.com"
          />
          <Field
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            textContentType="password"
            returnKeyType="done"
            onSubmitEditing={() => { void submit(); }}
            placeholder="Your password"
          />
          {error ? <Text accessibilityRole="alert" className="font-body text-sm leading-5 text-loss">{error}</Text> : null}
          <Button title="Sign in" accessibilityHint="Submits your credentials to the existing authentication API." loading={busy} onPress={submit} />
        </View>

        <View className="mt-7 flex-row justify-center gap-1">
          <Text className="font-body text-sm text-muted">New to FIFO Wealth OS?</Text>
          <Link href="/(auth)/register" className="font-body text-sm font-bold text-accent-bright">Create account</Link>
        </View>
        <Text className="mt-8 text-center font-body text-xs leading-5 text-muted">JWT access tokens are stored in device-secure storage. Your password is never saved on this device.</Text>
      </KeyboardAvoidingView>
    </Screen>
  );
}
