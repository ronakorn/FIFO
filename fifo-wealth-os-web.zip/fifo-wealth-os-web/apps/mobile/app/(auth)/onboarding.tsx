import { useRouter } from 'expo-router';
import { ArrowRight, ChartPie, FileText, ShieldCheck } from 'lucide-react-native';
import { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { markOnboardingComplete } from '@/auth/tokenStore';
import { Button, Card, Eyebrow } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { useTheme } from '@/theme/ThemeProvider';

type Destination = '/(auth)/register' | '/(auth)/sign-in';

export default function OnboardingScreen(): React.JSX.Element {
  const router = useRouter();
  const { colors } = useTheme();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const continueTo = async (destination: Destination): Promise<void> => {
    setBusy(true);
    setError('');
    try {
      await markOnboardingComplete();
    } catch {
      setError('Your device could not save the onboarding preference. You can continue, but this introduction may appear again.');
    } finally {
      setBusy(false);
    }
    router.replace(destination);
  };

  return (
    <Screen contentClassName="flex-1 justify-center pt-8">
      <View className="mb-6 h-16 w-16 items-center justify-center rounded-3xl border border-accent/30 bg-accent/15">
        <Text className="font-display text-2xl font-extrabold text-accent-bright">F</Text>
      </View>
      <Eyebrow>FIFO WEALTH OS · MOBILE</Eyebrow>
      <Text className="mt-3 font-display text-3xl font-extrabold text-ink">Your portfolio, in one secure view.</Text>
      <Text className="mt-3 font-body text-base leading-6 text-muted">Inspect server-calculated FIFO holdings, activity, and Thai tax summaries from your phone.</Text>

      <View className="mt-7 gap-3">
        <Card className="flex-row items-center gap-4">
          <View className="h-11 w-11 items-center justify-center rounded-2xl bg-accent/15"><ChartPie color={colors.accentBright} size={21} /></View>
          <View className="flex-1"><Text className="font-display text-sm font-bold text-ink">Portfolio overview</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">See backend valuations, allocation, and FIFO lots—without recreating the financial engine on-device.</Text></View>
        </Card>
        <Card className="flex-row items-center gap-4">
          <View className="h-11 w-11 items-center justify-center rounded-2xl bg-gain/10"><ShieldCheck color={colors.gain} size={21} /></View>
          <View className="flex-1"><Text className="font-display text-sm font-bold text-ink">Private by design</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">Tokens use device SecureStore; optional offline snapshots are SQLCipher-encrypted in a native build.</Text></View>
        </Card>
        <Card className="flex-row items-center gap-4">
          <View className="h-11 w-11 items-center justify-center rounded-2xl bg-gold/10"><FileText color={colors.gold} size={21} /></View>
          <View className="flex-1"><Text className="font-display text-sm font-bold text-ink">Thai tax summary</Text><Text className="mt-1 font-body text-xs leading-5 text-muted">Review the existing Thai tax engine output. This is not a U.S. tax-filing calculation.</Text></View>
        </Card>
      </View>

      {error ? <Text accessibilityRole="alert" className="mt-4 font-body text-xs leading-5 text-gold">{error}</Text> : null}
      <Button className="mt-7" title="Create an account" accessibilityHint="Continues to account registration." loading={busy} icon={<ArrowRight color="#FFFFFF" size={17} />} onPress={() => continueTo('/(auth)/register')} />
      <Pressable accessibilityRole="button" accessibilityLabel="Sign in to an existing account" accessibilityHint="Continues to sign in." accessibilityState={{ disabled: busy }} disabled={busy} className="mt-5 items-center py-2" onPress={() => { void continueTo('/(auth)/sign-in'); }}>
        <Text className="font-body text-sm text-muted">Already have an account? <Text className="font-bold text-accent-bright">Sign in</Text></Text>
      </Pressable>
      <Text className="mt-6 text-center font-body text-[10px] leading-4 text-muted">Your credentials and financial records are handled by your existing FIFO Wealth OS API.</Text>
    </Screen>
  );
}
