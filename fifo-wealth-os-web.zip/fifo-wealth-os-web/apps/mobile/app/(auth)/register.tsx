import { Link } from 'expo-router';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Text, View } from 'react-native';
import { getApiErrorMessage } from '@/api/client';
import { useAuth } from '@/auth/AuthProvider';
import { Button, Field } from '@/components/Primitives';
import { Screen } from '@/components/Screen';
import { hapticWarning } from '@/lib/haptics';

export default function RegisterScreen(): React.JSX.Element {
  const { register } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (): Promise<void> => {
    setError('');
    if (!name.trim()) {
      hapticWarning();
      setError('Enter your name.');
      return;
    }
    if (!email.includes('@')) {
      hapticWarning();
      setError('Enter a valid email address.');
      return;
    }
    if (password.length < 8) {
      hapticWarning();
      setError('Password must contain at least 8 characters.');
      return;
    }
    if (password !== confirmPassword) {
      hapticWarning();
      setError('The passwords do not match.');
      return;
    }
    setBusy(true);
    try {
      await register(email, password, name);
    } catch (reason) {
      setError(getApiErrorMessage(reason));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen contentClassName="flex-1 justify-center pt-8">
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Text className="font-display text-3xl font-extrabold text-ink">Create account</Text>
        <Text className="mt-2 font-body text-base leading-6 text-muted">Start with a private, read-only view of your wealth.</Text>
        <View className="mt-8 gap-4">
          <Field label="Full name" value={name} onChangeText={setName} autoCapitalize="words" textContentType="name" placeholder="Your name" />
          <Field label="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" textContentType="emailAddress" placeholder="you@example.com" />
          <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry textContentType="newPassword" hint="Use at least 8 characters." placeholder="Create a password" />
          <Field label="Confirm password" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry textContentType="newPassword" placeholder="Repeat your password" />
          {error ? <Text accessibilityRole="alert" className="font-body text-sm leading-5 text-loss">{error}</Text> : null}
          <Button title="Create account" accessibilityHint="Creates an account through the existing authentication API." loading={busy} onPress={submit} />
        </View>
        <View className="mt-7 flex-row justify-center gap-1">
          <Text className="font-body text-sm text-muted">Already registered?</Text>
          <Link href="/(auth)/sign-in" className="font-body text-sm font-bold text-accent-bright">Sign in</Link>
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}
