import { Redirect, Stack } from 'expo-router';
import { useAuth } from '@/auth/AuthProvider';
import { useTheme } from '@/theme/ThemeProvider';

export default function AuthLayout(): React.JSX.Element {
  const { status } = useAuth();
  const { colors } = useTheme();
  if (status === 'signed-in') return <Redirect href="/(app)/(tabs)" />;
  return <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.midnight } }} />;
}
