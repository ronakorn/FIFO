# FIFO Wealth OS Mobile

Expo Router mobile client for FIFO Wealth OS, written in strict TypeScript with NativeWind. It calls the existing authenticated API for portfolio values, FIFO lots, transaction pages, broker sync, and Thai tax summaries. Financial calculations remain on the backend.

## Current scope and important limits

- **Valuations are not live market quotes.** The dashboard labels its basis as the latest transaction-price mark recorded by the backend.
- **Tax summaries are Thai tax-engine outputs.** They are not U.S. tax advice or a U.S. tax-filing calculation. The PDF endpoint may require the account's `taxReportPDF` entitlement.
- Advanced benchmark analytics are optional; if unavailable, base portfolio totals and symbol allocation still display.
- Advanced Assets shows Options, REITs, Private Equity, and Futures cards marked **Sample Data** because the current mobile summary has no read-only asset metrics. The cards do not call calculator routes. “View on Web” requires `EXPO_PUBLIC_WEB_URL` and opens the locale-prefixed `/th/advanced-assets` route.
- Profile shows broker status, last sync, and supported sync/disconnect actions for IBKR and the existing Thai-broker connections. Credential setup remains available for IBKR and Bitkub; Dime/Streaming connect flows are not added.
- Portfolio detail includes a refreshable server transaction ledger and separately marked local queued Quick Add items. A queued item is not confirmed or synced.
- Dashboard, transaction, and pending Quick Add snapshots use SQLCipher, with the database key stored in SecureStore. **SQLCipher is not available in Expo Go**; use a development or production native build to validate encrypted offline persistence.
- The reminder preference schedules a **device-local weekly portfolio-performance summary every Monday at 9:00 AM**. No remote push-token registration or push-delivery service is configured in the current backend.
- Quick Add entries remain explicitly local and are excluded from server-calculated totals until a reviewed transaction-create API is available.
- Mobile credential forms cover IBKR and Bitkub; Dime/Streaming connection setup remains in the existing web workflow. The mobile status/actions apply only to connections returned by the current status endpoints.
- The backend issues seven-day access tokens and has no refresh-token endpoint. An expired session requires a fresh sign-in.

## Navigation and visual system

Expo Router uses an auth stack and four primary tabs: **Home**, **Portfolios**, **Advanced Assets**, and **Profile**. Activity and Thai Tax remain routed screens reachable from Home/Portfolio actions. Profile includes a separate **Hello, NativeWind!** verification route, so the requested utility-class check does not replace the existing app. NativeWind v4 provides the shared utility classes and rounded-2xl surfaces. The persisted appearance control supports **System**, **Light**, and **Dark**. Light mode uses the brand ink/accent `#14342A` and `#FAFAFA` canvas; dark mode uses a `#121212` canvas with `#FAFAFA` text. To reconcile the prior FIFO dark-red styling with this M1 palette, red remains the semantic negative/loss color (`#B42332` light, `#F17878` dark) rather than replacing the requested green brand accent. Theme variables are applied through NativeWind CSS variables so class-based surfaces and text update together.

## Phase M2: biometrics and dashboard

- `src/lib/auth.ts` centralizes biometric prompts and JWT storage in `expo-secure-store`. The signed-in app gate offers **Login with Face ID / Touch ID** after a persisted session has its biometric lock enabled; **Use password instead** clears the session and returns to sign-in. Biometrics unavailable, unenrolled, or cancelled do not unlock the session; the user can choose the password sign-in fallback.
- Standard email/password login remains available at `app/(auth)/sign-in.tsx` and stores only the issued access token and minimal user identity; no JWT signing secret is shipped to the app.
- Home reads the authenticated `/api/mobile/dashboard-summary` and `/api/portfolios` endpoints through the shared `@fifo/api` client, using `@fifo/types` for portfolio contracts and `@fifo/utils` for Decimal-safe display formatting.
- The dashboard shows total net worth, semantic unrealized gain/loss, a server-colored allocation donut, and quick portfolio cards. Pull-to-refresh updates the summary, portfolio list, and analytics; encrypted cached portfolio data remains available offline. Allocation categories follow the existing analytics response (Thai/foreign equity, crypto, gold, cash); bond/fund classifications are not fabricated when the current API does not provide them.

## Phase M3: Quick Add and offline-first experience

- Home has a floating Quick Add action with a date picker, portfolio selector, Buy/Sell choice, symbol, quantity, and price. Validation uses shared `@fifo/utils` precision-40 decimals; the local queue contract uses shared `@fifo/types`, preserving quantities and prices as decimal strings.
- Pending manual entries are shown separately from server-confirmed activity and are excluded from FIFO, net-worth, tax, and allocation totals. They are written to the existing SQLCipher cache where the native encrypted database is available; settings can clear them, and sign-out clears the encrypted queue. If SQLCipher is unavailable, the UI warns that an entry lasts only for the current app session.
- **Transaction write limitation:** the existing backend route at `src/api/routes/transactionRoutes.ts` exposes only `GET /api/transactions/:portfolioId`; it has no `POST /api/transactions` handler or create schema. `@fifo/api` likewise has no create endpoint. Under the no-backend-change constraint, the app does not call a nonexistent route or claim a server write. Quick Add remains a clearly labeled local queue until a reviewed backend create contract is added.
- A NetInfo offline banner appears across app screens. Cached net-worth and allocation views retain their last successful snapshot and show a local “Last updated” timestamp when offline or stale.
- The Profile toggle now controls the weekly wealth-summary notification. It reuses the existing SecureStore reminder ID and migrates the previous weekly tax reminder at app startup, avoiding a duplicate schedule.

## Requirements

- Node.js **20.19+** for the configured Expo SDK 56 toolchain (the checked workspace used Node 20.20.2).
- npm 10+.
- An API deployment with the mobile routes and existing auth, portfolio, broker, and Thai tax endpoints.
- For local native builds: Android Studio/SDK plus a supported JDK for Android, or Xcode on macOS for iOS.
- For store builds: an Expo account and EAS CLI; Google Play Console and/or Apple Developer/App Store Connect credentials.

## Install and configure

Install dependencies from the monorepo root so npm uses the shared workspace lockfile; do not run a separate install inside `apps/mobile`:

```bash
npm ci
cp .env.example .env
cp apps/mobile/.env.example apps/mobile/.env
```

The root `.env` configures the API. Set `EXPO_PUBLIC_API_URL` in `apps/mobile/.env` to the API base ending in `/api`:

- Android emulator: `http://10.0.2.2:3000/api`
- iOS simulator: `http://127.0.0.1:3000/api`
- Physical device: `http://<development-computer-LAN-IP>:3000/api`
- EAS preview and production: a deployed **HTTPS** URL ending in `/api`.

Set `EXPO_PUBLIC_WEB_URL` to the public web-app origin only (no `/api`, locale prefix, query, or hash). The mobile action builds `/{locale}/advanced-assets` using the web app's default `th` locale. Use a device-reachable host for local development; an unset or invalid value displays a configuration alert instead of opening a guessed URL. EAS preview and production builds require a valid HTTPS web origin, preventing a shipped build with a silently inactive link.

`EXPO_PUBLIC_*` values are compiled into the JavaScript bundle and are public. **Never** put `JWT_SECRET`, `ENCRYPTION_KEY`, a database password, broker credentials, or other private secrets in `.env` or EAS public variables. The Expo config rejects non-HTTPS API URLs, API URLs without the `/api` suffix, URLs containing embedded credentials or query strings, and missing/non-HTTPS web origins for EAS preview and production builds. Cleartext development access is limited to the development profile/local tooling.

For the backend, set a private `JWT_SECRET` and a dedicated `ENCRYPTION_KEY` of at least 32 characters in the server environment. Broker credentials are sent to the API and encrypted by the backend using its existing AES-256-GCM contract; they are not persisted in the app's local cache.

## Run locally

### Expo Go (limited inspection only)

```bash
npm run start:go --workspace=@fifo/mobile
```

Expo Go can be used to inspect non-SQLCipher UI flows. It does **not** include the configured SQLCipher implementation, so offline-cache validation is not representative. Some native features can also differ from a custom build.

### Development build (recommended)

Create a development client, then start Metro:

```bash
cd apps/mobile
npx eas-cli login
npx eas-cli build:configure
npx eas-cli build --profile development --platform android
# On macOS, or with an iOS simulator configured:
# npx eas-cli build --profile development --platform ios
npm run start
```

Install the development build on the device/simulator and open the Metro development server. Alternatively, with local Android/iOS toolchains:

```bash
cd apps/mobile
npm run expo:prebuild
npm run android
# macOS with Xcode:
npm run ios
```

`prebuild` generates native projects; `android/` and `ios/` are ignored by Git. The SQLCipher Expo config plugin is enabled in `app.json`.

## Quality checks

```bash
cd apps/mobile
npx expo install --check
npm run typecheck
npm run lint
npm test -- --runInBand
```

To smoke-test JS bundling without producing a store binary:

```bash
npx expo export --platform android --platform ios --output-dir /tmp/fifo-mobile-export
```

The focused mobile Jest suites cover the light/dark brand palette, financial formatters, API-client authentication/error handling, Quick Add precision/validation, weekly notification scheduling/migration, broker status/action rendering, advanced-asset sample cards/web links, and queued-versus-confirmed ledger rows. The current mobile suite has 35 passing tests across nine suites. In this workspace, `npx expo install --check` may report root-hoisted Jest/TypeScript versions instead of the mobile-local SDK-aligned versions; do not use `--fix` to upgrade root tools without reviewing the monorepo impact. End-to-end device flows, broker-provider sandbox checks, and an SQLCipher custom-build test still need to be run before release. From the monorepo root, `npm run test:all` runs the backend, web, and mobile suites; `npm run build:all` builds the backend and all workspaces.

## EAS builds

1. Run `npx eas-cli login` and `npx eas-cli build:configure` (or `npm run eas:configure`).
2. Attach the project with `npx eas-cli init` if prompted; commit the generated `extra.eas.projectId` in the Expo config.
3. Configure `EXPO_PUBLIC_API_URL` in the EAS preview and production environments as a **public HTTPS API base ending in `/api`**. Non-development profiles intentionally fail if it is missing or insecure.
4. Configure `EXPO_PUBLIC_WEB_URL` as the public HTTPS web-app origin in the same EAS environments so the Advanced Assets “View on Web” buttons open the correct site.
5. Check native app identifiers before the first store build: `com.fifowealthos.mobile` for Android and `com.fifowealthos.mobile` for iOS. Change them before release if the organization has already claimed either identifier.
6. Run the relevant build command. EAS manages native signing credentials; review and retain them in EAS/your organization's secret manager.

### Google Play

```bash
npm run eas:android:production
# After reviewing the artifact and store listing:
npx eas-cli submit --platform android --profile production
```

The production Android profile creates an **AAB**. The submit profile targets the internal track by default; promote it through Play Console after testing. Provide the Play service-account credentials through EAS/secure configuration when prompted—never commit them.

### Apple App Store

```bash
npm run eas:ios:production
npx eas-cli submit --platform ios --profile production
```

The iOS production profile is a store build. EAS will request Apple Developer/App Store Connect credentials as needed. Review bundle identifier, privacy disclosures, Face ID/notification permission text, export-compliance answers, screenshots, and App Store Connect metadata before submission.

### Internal previews

```bash
npm run eas:android:preview
npx eas-cli build --profile preview --platform ios
```

The Android preview profile creates an APK for internal installation. The iOS preview profile is internal distribution and requires the appropriate Apple provisioning setup.

## Backend/API integration

- `GET /api/mobile/dashboard-summary` returns an authenticated compound summary using existing server-hydrated FIFO results, portfolio totals, symbol allocation, and recent transactions. Market-value basis is `LATEST_RECORDED_TRANSACTION_PRICE`.
- `GET /api/mobile/transactions/:portfolioId` returns newest-first cursor pages and supports `limit`, `cursor`, `type`, and `symbol`; ownership is checked by the API.
- Existing endpoints handle login/registration, portfolio creation, optional analytics, tax summaries/PDFs, IBKR, and Thai-broker status/connect/sync/disconnect. Profile uses the existing `GET /api/sync/status`, `GET /api/thai-brokers/status`, `POST /api/sync/ibkr/trigger`, `DELETE /api/sync/ibkr/disconnect`, `POST /api/thai-brokers/:broker/sync`, and `DELETE /api/thai-brokers/:broker/disconnect` handlers; no backend routes were added.
- Mobile transaction and lot screens display server results; they do not reimplement or round the canonical FIFO engine. Decimal formatting is for display only. Portfolio detail refreshes its transaction page and distinguishes server-confirmed transactions from local queued items. Quick Add remains local-only because the current transaction routes do not support manual creation.
- The mobile dashboard summary and API do not expose read-only advanced-asset metrics; Advanced Assets therefore shows visibly labeled illustrative sample values and never calls the calculator POST routes.
- `GET /api/thai-brokers/status` exposes the current PDPA consent version so the mobile consent submission stays aligned with the backend.

## Security notes

- SecureStore contains the issued session/access token, minimal cached user identity, local lock preferences, reminder ID, and a random SQLCipher database key. The JWT signing secret is never shipped in the app.
- Broker credentials are entered into transient form state, sent to the API, and cleared after a successful response. They are never written to AsyncStorage, SQLite, or SecureStore.
- Tax-report PDFs are downloaded to temporary app cache only for the native share sheet and deleted afterward.
- Biometric unlock is optional and uses the device's enrolled authentication. Lock timeout can be immediate, one minute, or five minutes.
- Offline financial access is read-only for server-calculated dashboard/tax/transaction responses; a cache miss while offline cannot be reconstructed on-device. Manual Quick Add entries are separately encrypted and visibly pending; they are not part of server-calculated financial totals and will not sync until a create endpoint exists.
- Test production API connectivity and server access controls on a real device before release. Do not distribute with a development API URL or development credentials.

## Troubleshooting

- **Preview/production config refuses to load:** set `EXPO_PUBLIC_API_URL` to the deployed HTTPS endpoint ending exactly in `/api` and `EXPO_PUBLIC_WEB_URL` to the deployed HTTPS web origin in the matching EAS environment.
- **Offline cache says unavailable:** install a custom development/production build with the SQLCipher plugin; Expo Go does not ship SQLCipher.
- **Quick Add stays queued:** this is expected until a reviewed `POST /api/transactions` endpoint and matching shared client contract are provided; the current backend route is read-only.
- **API unreachable on a phone:** use the development computer's LAN address, ensure the phone and computer share a network, and allow the API port through the local firewall. `10.0.2.2` is only for the Android emulator.
- **Broker connection fails:** ensure the backend encryption key is configured and use provider credentials with read-only permissions. Bitkub consent is mandatory; provider availability and account entitlement remain server-controlled.
- **PDF export returns an entitlement error:** enable the existing `taxReportPDF` entitlement for the account; no tax calculation is performed locally.
