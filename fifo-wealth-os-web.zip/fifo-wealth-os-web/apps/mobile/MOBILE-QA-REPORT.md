# FIFO Wealth OS Mobile — QA Health Check

**Date:** 2026-10-29  
**Initial scope:** M1 mobile foundation plus the Phase M2 secure-session, biometric unlock, dashboard, and shared mobile portfolio contracts. No backend logic/schema/route or web application source was changed in M2.  
**Initial result:** **Conditional pass — 82/100 for M2.** Mobile static checks, unit tests, and Android/iOS JS exports passed for the M2 scope; device-level biometric verification and the manual-review items below remain required before release.

**Latest update — Phase M3 (2026-10-29):** Mobile Quick Add, offline cache timestamps/banner, and the weekly summary reminder are implemented and pass mobile tests/builds. Manual trade creation remains local-only because the inspected backend exposes no `POST /api/transactions`; no backend or web-app source was changed. No Android/iOS device or emulator is available for visual/E2E verification.

**Latest update — Phase M4 (2026-10-29):** Advanced Assets sample cards and configured web links, broker status/sync/disconnect controls using existing handlers, and a portfolio-scoped refreshable transaction ledger are implemented. Mobile checks and Android/iOS JS exports pass; all 28 prior mobile tests remain passing (35 total). No backend logic/schema/route or web application source was changed. Device/emulator visual verification remains unavailable; the deployment must configure `EXPO_PUBLIC_WEB_URL`.

## 1. Executive summary

- **Safe fixes applied:** 15 grouped fixes across M1 and M2, limited to mobile configuration/UI, secure session handling, shared types, and dashboard presentation; no financial or tax calculations were altered.
- **Mobile typecheck:** pass.
- **Mobile lint:** pass with no warnings.
- **Mobile unit tests:** 19/19 pass across four suites; tests include SecureStore token save/read/clear and biometric availability, cancellation, and success paths.
- **Expo JS export:** Android and iOS bundles both pass after M2 changes.
- **Monorepo regression coverage:** `npm run test:all` passes — 371 backend tests / 28 suites, 14 web Playwright tests, and 19 mobile tests / four suites.
- **Native prebuild configuration:** development and production prebuilds pass; production manifests disable cleartext/ATS exceptions.
- **Backend API validation:** root typecheck passes; `src/api/__tests__/api.test.ts` passes 43/43 tests, including the mobile endpoints.
- **Known exception:** Expo Doctor reports the Expo SDK 56 Hermes V1 memory regression. This requires an SDK migration decision; it was not auto-upgraded because that is a major native-toolchain change.
- **No financial engine, tax engine, database schema, backend route, or web application source was changed in M2.** The mobile SecureStore/AuthProvider flow was updated as requested, and `@fifo/types` received additive mobile portfolio contracts only.

## 2. Safe auto-fixes applied

| # | Files | Fix | Why safe |
|---|---|---|---|
| 1 | `package.json`, `package-lock.json` | Restored a consistent Expo SDK 56 dependency tree after a partial SDK 57 install attempt; kept React Native and Expo modules on the SDK 56-compatible versions. | Dependency recovery only; avoids leaving mismatched native modules. |
| 2 | `package.json`, `package-lock.json` | Added SDK-aligned `expo-build-properties`, `expo-font`, and `expo-system-ui`; deduplicated the Expo font/native module tree. | Resolves native config/peer dependency warnings without changing application behavior. |
| 3 | `app.config.js`, `app.json` | Switched to Expo’s dynamic `config` input; moved Android cleartext configuration into the build-properties plugin; require HTTPS `/api` URLs for EAS preview and production, and disable cleartext/ATS exceptions outside development. | Build configuration only. Production and preview transports were verified by prebuild/config checks. |
| 4 | `app.json`, `assets/splash-logo.png` | Migrated splash setup to the `expo-splash-screen` plugin and added its compact logo asset. | Presentation/configuration only; native prebuild succeeded. |
| 5 | `app/(app)/(tabs)/activity.tsx` | Added an inline error and retry for failed next-page requests and prevented `onEndReached` from automatically retrying a failed page in a loop. | UI state/retry behavior only; cursor API and server data are unchanged. |
| 6 | `app/(app)/(tabs)/tax.tsx` | Validate optional other-income input before sending it, suppress stale results while the input is invalid, and disable PDF export when the portfolio/year/input is invalid. | Client-side payload/UI validation only; the Thai tax calculation remains server-side and unchanged. |
| 7 | `app/(app)/(tabs)/settings.tsx` | Catch local lock-timeout and sign-out promise errors in the UI; show a success alert after clearing cached snapshots. | Event/error presentation only; no authentication or lock policy was changed. |
| 8 | `README-MOBILE.md`, `.env.example` | Clarified that EAS preview and production require HTTPS, and documented the local-vs-remote notification boundary. | Documentation only. |
| 9 | `src/theme/colors.ts`, `src/theme/ThemeProvider.tsx`, `tailwind.config.js`, `app.json`, `app/(app)/(tabs)/settings.tsx` | Added the requested `#14342A`, `#FAFAFA`, and `#121212` palette, System/Light/Dark selection persisted in SecureStore, and NativeWind CSS-variable theming; enabled automatic system UI style while retaining dark-red semantic loss indicators. | Presentation and preference only; no financial, tax, or API behavior changed. |
| 10 | `app/(app)/(tabs)/_layout.tsx`, `portfolios.tsx`, `advanced-assets.tsx`, `index.tsx` | Aligned the main tabs to Home, Portfolios, Advanced Assets, and Profile. Kept Activity and Tax as accessible nested screens linked from Home/Portfolio screens. | Navigation-only change; preserves existing FIFO ledger and Thai tax functionality. |
| 11 | `app/(app)/nativewind-verification.tsx`, `app/(app)/_layout.tsx`, `settings.tsx` | Added a separate, auth-protected “Hello, NativeWind!” screen reachable from Profile to verify NativeWind utility classes and light/dark tokens without replacing the existing app. | Verification/demo route only; no backend or financial behavior changed. |
| 12 | `packages/types/src/mobile.ts`, `packages/types/src/index.ts`, `apps/mobile/src/api/types.ts` | Added shared typed portfolio/FIFO summary contracts and reused them in the mobile client. | Additive TypeScript contract only; no backend schema, route, or web source changed. |
| 13 | `apps/mobile/src/api/services.ts`, `src/hooks/useMobileData.ts`, `app/(app)/(tabs)/index.tsx`, `app/(app)/portfolio/new.tsx` | Added authenticated `GET /portfolios` quick-list fetch through `@fifo/api`, SQLCipher-backed cache fallback, pull-to-refresh, and post-create invalidation. Dashboard-summary data remains a fallback. | Existing endpoint only; no API behavior or financial calculations changed. |
| 14 | `apps/mobile/src/lib/auth.ts`, `src/auth/tokenStore.ts`, `src/auth/AuthProvider.tsx`, `app/_layout.tsx` | Centralized SecureStore JWT helpers and `expo-local-authentication`; added the saved-session biometric gate and password fallback. Deferred `/auth/me` validation until biometric lock is cleared. | Uses existing auth endpoints and opt-in biometric lock; no backend auth/session behavior changed. |
| 15 | `apps/mobile/tests/auth.test.ts`, `src/components/Charts.tsx`, `app/(app)/(tabs)/index.tsx` | Added auth helper unit tests, semantic net-worth labels/Decimal sign checks, and a theme-aware allocation track using server palette colors where available. | Client-side tests and presentation only. |

## 3. Navigation, UI, and API verification

### Navigation and UI

- Verified 12 concrete screens/routes: onboarding, sign-in, registration, Home dashboard, Portfolios, Advanced Assets, Activity, Tax, Profile/Settings, portfolio creation, portfolio detail, and NativeWind Hello World verification.
- The primary tabs are Home, Portfolios, Advanced Assets, and Profile; Activity and Tax remain accessible as routed screens from Home/Portfolios. The separate NativeWind verification route is reachable from Profile.
- Current password route is `app/(auth)/sign-in.tsx` (there is no `login.tsx`). When a saved session has biometric lock enabled, `app/_layout.tsx` shows the biometric unlock button; password fallback clears that session and returns to sign-in. No biometric bypass is shown without a saved locked session.
- Home shows server-derived total net worth, semantic unrealized G/L, allocation donut, and portfolio quick list. Pull-to-refresh updates summary, analytics, and portfolio list; the list comes from `GET /api/portfolios` and uses encrypted cache fallback.
- Expo Router typed-route checks pass through `tsc`; tab and stack route names match the files under `app/`.
- Core screen controls have handlers, loading/error states, and empty states. The ledger now presents a recoverable error for a failed cursor page while retaining already-loaded rows.
- Tax-year and other-income validation prevents malformed optional input from being sent to the backend.

### API alignment

The mobile Axios client uses `EXPO_PUBLIC_API_URL` as the `/api` base; service paths are relative to it. Verified service alignment for:

- Authentication: `/auth/login`, `/auth/register`, `/auth/me`
- Portfolio list/create: `GET /portfolios`, `POST /portfolios` (shared `Portfolio` contract in `@fifo/types`)
- Mobile summary and ledger: `/mobile/dashboard-summary`, `/mobile/transactions/:portfolioId`
- Thai tax summary/PDF: `/tax/summary/:portfolioId/:year`, `/tax/report/:portfolioId/:year`
- IBKR: `/sync/ibkr/connect`, `/sync/ibkr/trigger`, `/sync/ibkr/disconnect`
- Thai broker status/connect/disconnect: `/thai-brokers/...`

Network requests time out after 20 seconds; user-facing messages cover timeout and unreachable API cases. React Query reads encrypted cache fallbacks for supported snapshots. A bearer-authenticated 401 expires the local session and returns the protected app to sign-in; there is no refresh endpoint, so a seven-day token expiry requires a fresh sign-in. HTTP 403 responses are displayed as server errors rather than treated as sign-out.

The backend API test suite and strict typecheck pass; this QA pass did not alter backend endpoint behavior.

## 4. Build and validation status

| Check | Result |
|---|---|
| `npm run typecheck` (mobile) | **PASS** |
| `npm run lint` (mobile) | **PASS** |
| `npm test --workspace=@fifo/mobile -- --runInBand` | **PASS — 4 suites, 19 tests**, including SecureStore session and biometric success/cancel/unavailable paths plus API error handling |
| `npx expo install --check` | **PASS — dependencies aligned** |
| `npm run build --workspace=@fifo/mobile` | **PASS — Expo exported Android and iOS bundles after M2 changes** |
| Light/dark dashboard review | **PASS — source uses semantic NativeWind tokens and theme-aware chart tracks; simulator/device screenshot unavailable** |
| `npx expo prebuild --no-install --clean` (development profile) | **PASS**; generated Android cleartext and iOS ATS development allowances as configured |
| `EAS_BUILD_PROFILE=production EXPO_PUBLIC_API_URL=https://api.example.com/api npx expo prebuild --no-install --clean` | **PASS**; Android `usesCleartextTraffic=false`, iOS `NSAllowsArbitraryLoads=false` |
| Preview URL guard | **PASS**; HTTPS `/api` accepted and HTTP rejected |
| Root `npm run typecheck` | **PASS** |
| `npx jest src/api/__tests__/api.test.ts --runInBand --silent` | **PASS — 43 tests** |
| `expo-doctor` (22 checks) | **21/22**; the sole failure is the known SDK 56 Hermes V1 regression listed below |
| Native Android/iOS compile, install, and device E2E | **NOT RUN**; `adb` and `xcodebuild` are unavailable in this environment (JDK 11 only) |

The native prebuild directories generated for configuration verification were removed afterward; the managed Expo workspace remains clean.

## 5. Monorepo migration verification

- `npm run typecheck`: **PASS** (root backend and shared packages).
- `npm run lint`: **PASS** (8 successful Turbo workspace tasks; Next.js prints only its upstream `next lint` deprecation notice).
- `npm run test:all`: **PASS** — root **371 tests / 28 suites**, web **14 Playwright tests**, mobile **19 tests / 4 suites**.
- `npm run build:all`: **PASS** — root backend build plus all five Turbo workspace builds; Next.js production build and Android/iOS Expo exports completed.
- After the fresh install, Playwright initially lacked its browser binary; Chromium/headless shell was installed and the complete rerun passed.
- `npx expo install --check`: **PASS**.
- React lockfile check: web and mobile now resolve React/ReactDOM **19.2.3**. Removed the stale `apps/web/node_modules/react` and `react-dom` 18.3.1 lock entries, then confirmed the lockfile remains up to date and `npm ls react react-dom --all` resolves the workspaces to 19.2.3.
- **Clean install check:** an isolated manifest-only workspace clone passed `npm ci --ignore-scripts --no-audit --no-fund --prefer-offline --maxsockets=2` (**1,833 packages**); its clean install tree had React/ReactDOM 19.2.3 only, with no web-local 18.3.1 copy. A second clean install with lifecycle scripts enabled exited `-1` after about 95 seconds during reification under sandbox limits. The project install was not altered; hosted CI should still verify full `npm ci`.
- **Container caveat:** Docker is not installed in the sandbox, so local Compose validation/image builds were not possible. `.github/workflows/ci.yml` includes `docker compose config --quiet` and container builds, but a hosted CI run was not available here.
- Current dependency scan: **19** advisories overall (13 low, 3 moderate, 3 high) and **11** runtime (`--omit=dev`) (5 low, 3 moderate, 3 high); see manual-review items.

## 6. Pending review items — manual action required

1. **Expo SDK 56 Hermes V1 regression:** Expo Doctor flags `expo@56.0.24` / Hermes V1 `250829098.0.10` as affected by a memory regression. Expo’s suggested remediation is SDK 57 / React Native 0.86.2+. That migration requires Node 22.13+ and a separately reviewed native dependency upgrade; it was deliberately not applied automatically.
2. **Dependency advisories:** current `npm audit` reports **19 total** (13 low, 3 moderate, 3 high); `npm audit --omit=dev` reports **11** (5 low, 3 moderate, 3 high). High findings include Expo CLI/runtime and a Zod transitive used by Expo tooling. The audit proposes an Expo SDK downgrade or major dependency changes, so no force-fix was applied. Review and plan an SDK-aligned remediation.
3. **Device-level verification:** JS export and native prebuild are not equivalent to compiling/running an APK or IPA. Validate SecureStore, biometrics, SQLCipher offline reads/writes, notification permission/scheduling, PDF sharing, and expired-session redirects on development builds and physical devices. Expo Go does not provide the configured SQLCipher cache.
4. **Push scope:** current notification setting schedules a local weekly reminder only. There is no remote push-token registration/delivery service in the current backend integration.
5. **Broker provider verification:** Profile now shows status, last-synced time, and existing sync/disconnect actions for IBKR and any connected Thai broker. Mobile credential setup remains limited to IBKR and Bitkub; Dime/Streaming setup is not added. Exercise real provider/sandbox connections and confirm account entitlements before describing broker coverage as production-verified.
6. **Backend change review:** the previously added `/api/mobile/*` endpoints passed strict typecheck and their relevant assertions in the 43-test API suite, but remain backend/API changes and should receive the human review required by the project policy. The additive current-consent-version field was not explicitly asserted by that suite and should receive a focused test/review. No backend route or calculation edits were made in this QA pass.
7. **Release setup:** confirm the generic identifiers `com.fifowealthos.mobile`, EAS project linkage, signing credentials, and store privacy/notification disclosures before a store build.
8. **Tax accuracy boundary:** the Tax screen consumes the existing Thai tax engine only; it is not a U.S. tax-filing calculation. PDF export may return 403 when the existing `taxReportPDF` entitlement is absent.
9. **Allocation category coverage:** the existing analytics contract currently reports Thai/foreign equity, crypto, gold, and cash; it does not provide Bond/Fund asset-class totals. The mobile donut uses server-provided categories or falls back to symbol weights instead of inferring unsupported classifications. Extending category coverage requires a separately reviewed backend contract change.

## 7. Phase M3 implementation and validation — 2026-10-29

### Implemented

- Home now has the Quick Add FAB and `src/components/QuickAddTransaction.tsx` sheet with portfolio, symbol, Buy/Sell, precision-preserving quantity/price strings, and a native date picker. Shared `@fifo/types` contracts and `@fifo/utils` Decimal/date/number formatting are used.
- Pending manual entries are immediately reflected in a separate local queue. When SQLCipher is available they persist in the existing encrypted database; otherwise the UI warns that the entry is session-only. Pending entries are never represented as server-confirmed transactions and are not included in FIFO/net-worth/tax totals.
- **Required API limitation:** `src/api/routes/transactionRoutes.ts` contains only `GET /:portfolioId` (mounted at `/api/transactions`) and no `POST /api/transactions` handler or create schema. `@fifo/api` also contains no transaction-create endpoint. In line with the zero-backend-change rule, the app does not call a nonexistent route; queued trades will not sync until a reviewed create endpoint/client contract is added.
- NetInfo drives an app-wide offline banner. Dashboard and allocation cached snapshots retain SQLCipher `updated_at` metadata and display “Last updated” timestamps when stale/offline.
- The Profile/Settings reminder now schedules the exact weekly wealth-summary copy for Monday at 9:00 AM local time. It reuses and replaces the prior weekly reminder ID; startup migration avoids leaving the old tax reminder beside a duplicate summary reminder.
- Added the SDK-aligned `@react-native-community/datetimepicker` dependency and Expo config plugin. No backend route/schema/logic or web-app source was changed; the shared type and utility additions are additive.

### M3 checks

| Check | Result |
|---|---|
| Mobile strict typecheck | **PASS** |
| Mobile ESLint | **PASS** |
| Mobile Jest | **PASS — 6 suites, 28 tests** (the prior 19 tests remain passing; 9 M3 tests cover validation, reminder scheduling/migration, and date-time formatting) |
| Android Expo JS export | **PASS** |
| iOS Expo JS export | **PASS** |
| `npx expo prebuild --no-install --clean` | **PASS** — Android/iOS native config generated with the new date-picker plugin; generated folders removed afterward |
| `npm run test:all` | **PASS — 371 backend tests / 28 suites, 14 web Playwright tests, 28 mobile tests / 6 suites** |
| `npm run build:all` | **PASS — backend/shared/workspace builds, Next.js production build, Android/iOS Expo export** |
| Expo Doctor | **21/22**; remaining failure is the existing SDK 56 Hermes V1 memory regression described above |
| NativeWind utility styling | **Build passes; no code/config limitation identified.** Device-level visual inspection remains unavailable. |
| `npx expo install --check` | **WARNING / nonzero exit:** Expo's checker resolves root-hoisted Jest 30 / TypeScript 5.9 rather than the mobile workspace's installed Jest 29 / TypeScript 6, which match `apps/mobile/package.json`. Mobile typecheck, tests, and export pass; no forced root dependency change was made. |
| Device visual/native E2E | **NOT AVAILABLE:** `adb`, Android `emulator`, and `xcrun` are absent. Expo bundle exports passed but do not replace rendering, SQLCipher, picker, or notification checks on a device. |

### M3 follow-up before release

1. Add a reviewed server transaction-create route/schema and corresponding shared `@fifo/api` contract in a separately authorized backend phase; then implement queue replay, idempotency, ownership checks, and confirmed server reconciliation. Until then, keep all manual entries visibly local-only.
2. Install a custom native development build on Android and iOS to visually inspect FAB/sheet/date picker, verify Monday scheduling and permission flows, and test SQLCipher queue persistence/offline recovery. Expo Go cannot validate SQLCipher.
3. Reassess Expo SDK 56 Hermes, security advisories, and the Expo dependency-check workspace-resolution warning before production.

## 8. Phase M4 implementation and validation — 2026-10-29

### Implemented

- **Advanced Assets:** Replaced the placeholder with Options (Net Delta), REITs (Distribution Yield), Private Equity (TVPI), and Futures (Margin Level) summary cards. The illustrative values `+0.24`, `5.10%`, `1.42×`, and `88.00%` are each marked **Sample Data** and use shared Decimal-safe display formatters. No advanced calculator route or local calculator is called.
- **Web destination:** “View on Web” calls React Native `Linking.openURL` for `EXPO_PUBLIC_WEB_URL` plus `/th/advanced-assets`. The locale prefix is required by the web middleware and `th` is its default. There was no canonical web origin in the workspace, so no host was guessed. Preview/production Expo config now requires a valid HTTPS web origin; development shows a setup alert if unset.
- **Connected Brokers:** Profile renders IBKR, Bitkub, Dime, and Streaming status cards with monogram marks, colored status pills, last-sync timestamps, and actions for existing connections. IBKR uses `GET /sync/status`, `POST /sync/ibkr/trigger`, and `DELETE /sync/ibkr/disconnect`. Thai broker cards use `GET /thai-brokers/status`, `POST /thai-brokers/:broker/sync`, and the existing purge-aware `DELETE /thai-brokers/:broker/disconnect`. Loading/errors are explicit. Existing mobile credential setup remains IBKR and Bitkub only.
- **Portfolio ledger:** Portfolio detail now loads paginated server transactions and local pending entries for the selected portfolio, sorts them by date, and offers pull-to-refresh/load-more. A clock + cloud-off badge and “Queued / Local only” mark local Quick Add entries; a checkmark and “Confirmed” mark server transactions. M3 queue items are not posted or counted as server-confirmed.
- **Scope discipline:** Changes are limited to mobile app code/config/docs/tests, mobile test dependencies/lockfile, and additive shared `@fifo/types`/`@fifo/api` client contracts. No backend logic/schema/route or existing web-app source changed.
- Added UI rendering and link tests with `@testing-library/react-native`; all 28 pre-M4 mobile tests remain included.

### M4 checks

| Check | Result |
|---|---|
| `npm run typecheck --workspace=@fifo/mobile` | **PASS** |
| `npm run lint --workspace=@fifo/mobile` | **PASS** |
| `npm test --workspace=@fifo/mobile -- --runInBand` | **PASS — 9 suites, 35 tests** (28 prior tests plus 7 M4 tests for broker states/actions, sample cards/URL opening, and queued-vs-confirmed ledger rows) |
| Android Expo JS export | **PASS** |
| iOS Expo JS export | **PASS** |
| Production Expo config smoke check | **PASS** — valid HTTPS API + web origins accepted; missing web origin rejected |
| `npm run test:all` | **PASS** — 371 backend tests / 28 suites, 14 web Playwright tests, and 35 mobile Jest tests / 9 suites |
| `npm run build:all` | **PASS** — root/shared builds, Next.js build, and Android/iOS Expo export |
| Advanced Assets link unit check | **PASS** — path resolves to `/th/advanced-assets` and `Linking.openURL` receives the configured URL |
| Live web navigation | **NOT VERIFIED** — `EXPO_PUBLIC_WEB_URL` is intentionally blank in `.env.example` because no canonical host was provided; the prior local web-preview port was not active when checked |
| Device/emulator visual review | **NOT AVAILABLE** — `adb`, Android `emulator`, and `xcrun` are unavailable. Component-render tests and JS bundle exports passed, but are not a substitute for screenshots/device interaction. |

### M4 follow-up before release

1. Set `EXPO_PUBLIC_WEB_URL` in the local environment and each EAS preview/production environment to the actual HTTPS web origin. Production builds intentionally fail without it; the workspace does not guess or embed a host.
2. Review the cards and broker controls on Android and iOS development builds; validate refresh gesture, status colors, dialogs, and external-browser handoff.
3. Exercise IBKR and Thai broker status/sync/disconnect against authorized provider or sandbox accounts. In particular, review the existing Thai disconnect endpoint's purge behavior before use.
4. Keep Advanced Assets labeled as sample-only unless an authorized read-only summary contract is added in a later phase. Do not call calculator POST routes from this dashboard.
5. Quick Add remains local-only until the separately reviewed transaction-create API is available; queued trades must not be portrayed as synced.

## 9. Release recommendation

**Conditional pass for continued development.** Static checks, cross-platform JavaScript exports, and native config checks pass. Do not label the app release-ready until the SDK 56 Hermes issue is reviewed, dependency advisories are triaged, the manual transaction API gap is resolved under an approved backend change, the web origin is configured, and custom native builds complete device-level security and end-to-end testing.
