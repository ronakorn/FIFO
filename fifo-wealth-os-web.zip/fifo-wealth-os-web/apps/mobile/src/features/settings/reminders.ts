import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import {
  getWeeklyReminderId,
  isWeeklyReminderEnabled,
  setWeeklyReminder,
} from '@/auth/tokenStore';

export const WEEKLY_SUMMARY_NOTIFICATION_BODY =
  '📊 Your Weekly Wealth Summary is ready. Tap to view your portfolio performance.';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: false,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

async function cancelSavedWeeklyReminder(): Promise<void> {
  const oldId = await getWeeklyReminderId();
  if (oldId) await Notifications.cancelScheduledNotificationAsync(oldId).catch(() => undefined);
}

async function replaceWeeklySummaryReminder(): Promise<void> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('wealth-reminders', {
      name: 'Wealth reminders',
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 180, 100, 180],
      lightColor: '#14342A',
    });
  }

  // Reuse the existing reminder identifier so the old tax reminder is replaced, not duplicated.
  await cancelSavedWeeklyReminder();
  const identifier = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'Weekly Wealth Summary',
      body: WEEKLY_SUMMARY_NOTIFICATION_BODY,
      data: { route: '/(app)/(tabs)' },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
      weekday: 2,
      hour: 9,
      minute: 0,
      channelId: 'wealth-reminders',
    },
  });
  await setWeeklyReminder(true, identifier);
}

export async function enableWeeklySummaryReminder(): Promise<boolean> {
  const current = await Notifications.getPermissionsAsync();
  const permission = current.granted ? current : await Notifications.requestPermissionsAsync();
  if (!permission.granted) return false;

  await replaceWeeklySummaryReminder();
  return true;
}

export async function disableWeeklySummaryReminder(): Promise<void> {
  await cancelSavedWeeklyReminder();
  await setWeeklyReminder(false);
}

/** Upgrade the previously enabled weekly tax reminder in place without prompting on app launch. */
export async function migrateWeeklySummaryReminder(): Promise<void> {
  if (!(await isWeeklyReminderEnabled())) return;

  const permission = await Notifications.getPermissionsAsync();
  if (!permission.granted) {
    await cancelSavedWeeklyReminder();
    await setWeeklyReminder(false);
    return;
  }

  await replaceWeeklySummaryReminder();
}
