import type { ManualTransactionDraft } from '@fifo/types';
import { decimal40 } from '@fifo/utils';

export type QuickAddField = keyof ManualTransactionDraft;
export type QuickAddValidationErrors = Partial<Record<QuickAddField, string>>;

function isPositiveDecimal(value: string): boolean {
  try {
    const decimal = decimal40(value.trim());
    return decimal.isFinite() && decimal.gt(0);
  } catch {
    return false;
  }
}

function isValidIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

export function validateQuickAddDraft(draft: ManualTransactionDraft): QuickAddValidationErrors {
  const errors: QuickAddValidationErrors = {};
  if (!draft.portfolioId.trim()) errors.portfolioId = 'Select a portfolio.';

  const symbol = draft.symbol.trim().toUpperCase();
  if (!/^[A-Z0-9][A-Z0-9._-]{0,19}$/.test(symbol)) {
    errors.symbol = 'Enter a valid ticker symbol (up to 20 letters, numbers, dots, or hyphens).';
  }

  if (!isPositiveDecimal(draft.qty)) errors.qty = 'Quantity must be a positive decimal.';
  if (!isPositiveDecimal(draft.price)) errors.price = 'Price must be a positive decimal.';
  if (!isValidIsoDate(draft.date)) errors.date = 'Choose a valid trade date.';
  return errors;
}

export function toLocalDateString(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
