import type { PendingManualTransaction } from '@fifo/types';
import { isEncryptedCacheAvailable, readSecureCache, writeSecureCache } from '@/cache/secureCache';

export const PENDING_MANUAL_TRANSACTIONS_CACHE_KEY = 'pending-manual-transactions:v1';

export async function readPendingManualTransactions(): Promise<PendingManualTransaction[]> {
  try {
    return (await readSecureCache<PendingManualTransaction[]>(PENDING_MANUAL_TRANSACTIONS_CACHE_KEY)) ?? [];
  } catch {
    return [];
  }
}

export async function persistPendingManualTransactions(
  transactions: PendingManualTransaction[],
): Promise<boolean> {
  try {
    if (!(await isEncryptedCacheAvailable())) return false;
    await writeSecureCache(PENDING_MANUAL_TRANSACTIONS_CACHE_KEY, transactions);
    return true;
  } catch {
    return false;
  }
}
