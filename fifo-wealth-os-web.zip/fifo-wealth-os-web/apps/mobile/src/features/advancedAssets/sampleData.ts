import type { AdvancedAssetSampleSummary } from '@fifo/types';

/** Sample-only values are intentionally not sourced from account or calculator endpoints. */
export const ADVANCED_ASSET_SAMPLE_DATA: AdvancedAssetSampleSummary[] = [
  {
    id: 'options',
    title: 'Options',
    metricLabel: 'Net Delta',
    value: '0.24',
    metricFormat: 'signed-decimal',
    detail: 'Illustrative portfolio directional exposure.',
    tone: 'positive',
    isSample: true,
  },
  {
    id: 'reits',
    title: 'REITs',
    metricLabel: 'Distribution Yield',
    value: '0.051',
    metricFormat: 'percent-ratio',
    detail: 'Illustrative annual distribution yield.',
    tone: 'positive',
    isSample: true,
  },
  {
    id: 'private-equity',
    title: 'Private Equity',
    metricLabel: 'TVPI',
    value: '1.42',
    metricFormat: 'multiple',
    detail: 'Illustrative total value to paid-in capital.',
    tone: 'neutral',
    isSample: true,
  },
  {
    id: 'futures',
    title: 'Futures',
    metricLabel: 'Margin Level',
    value: '0.88',
    metricFormat: 'percent-ratio',
    detail: 'Illustrative margin level, not a liquidation estimate.',
    tone: 'warning',
    isSample: true,
  },
];
