import { Linking } from 'react-native';

export function getAdvancedAssetsWebUrl(webBaseUrl: string | undefined): string | null {
  if (!webBaseUrl?.trim()) return null;
  try {
    const url = new URL(webBaseUrl.trim());
    if ((url.protocol !== 'https:' && url.protocol !== 'http:') || url.username || url.password || url.search || url.hash) {
      return null;
    }
    const basePath = url.pathname.replace(/\/+$/, '');
    url.pathname = `${basePath}/th/advanced-assets`;
    return url.toString();
  } catch {
    return null;
  }
}

export async function openAdvancedAssetsWeb(webBaseUrl = process.env.EXPO_PUBLIC_WEB_URL): Promise<'opened' | 'not-configured'> {
  const url = getAdvancedAssetsWebUrl(webBaseUrl);
  if (!url) return 'not-configured';
  await Linking.openURL(url);
  return 'opened';
}
