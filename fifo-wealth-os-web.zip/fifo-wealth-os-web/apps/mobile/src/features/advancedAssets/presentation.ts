import type { AdvancedAssetSampleSummary } from '@fifo/types';
import { decimal40, formatNumber, formatPercentRatio } from '@fifo/utils';

export function formatAdvancedAssetMetric(summary: AdvancedAssetSampleSummary): string {
  switch (summary.metricFormat) {
    case 'signed-decimal': {
      const formatted = formatNumber(summary.value, 2);
      return decimal40(summary.value).gt(0) ? `+${formatted}` : formatted;
    }
    case 'percent-ratio':
      return formatPercentRatio(summary.value);
    case 'multiple':
      return `${formatNumber(summary.value, 2)}×`;
  }
}
