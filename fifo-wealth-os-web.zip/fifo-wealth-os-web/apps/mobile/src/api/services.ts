import { API_ENDPOINTS } from '@fifo/api';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { api, API_BASE_URL } from '@/api/client';
import type {
  AuthResponse,
  DashboardAnalyticsResponse,
  IbkrConnection,
  MobileDashboardSummary,
  MobileTransactionPage,
  Portfolio,
  TaxReport,
  ThaiBrokerStatusResponse,
  ThaiBrokerSyncResult,
  ThaiBrokerId,
  ApiUser,
} from '@/api/types';
import { getAccessToken } from '@/auth/tokenStore';

export const authApi = {
  async login(email: string, password: string): Promise<AuthResponse> {
    const { data } = await api.post<AuthResponse>(API_ENDPOINTS.auth.login, { email, password });
    return data;
  },
  async register(email: string, password: string, name: string): Promise<AuthResponse> {
    const { data } = await api.post<AuthResponse>(API_ENDPOINTS.auth.register, { email, password, name });
    return data;
  },
  async me(): Promise<ApiUser> {
    const { data } = await api.get<{ user: ApiUser }>(API_ENDPOINTS.auth.me);
    return data.user;
  },
};

export const portfolioApi = {
  async list(): Promise<Portfolio[]> {
    const { data } = await api.get<Portfolio[]>(API_ENDPOINTS.portfolios.collection);
    return data;
  },
  async create(name: string, baseCurrency: string): Promise<Portfolio> {
    const { data } = await api.post<Portfolio>(API_ENDPOINTS.portfolios.collection, { name, baseCurrency });
    return data;
  },
};

export const mobileApi = {
  async dashboardSummary(): Promise<MobileDashboardSummary> {
    const { data } = await api.get<MobileDashboardSummary>(API_ENDPOINTS.mobile.dashboardSummary);
    return data;
  },
  async dashboardAnalytics(benchmark: 'SP500' | 'SET50' = 'SP500'): Promise<DashboardAnalyticsResponse> {
    const { data } = await api.get<DashboardAnalyticsResponse>(API_ENDPOINTS.analytics.dashboard, {
      params: { benchmark },
    });
    return data;
  },
  async transactionPage(
    portfolioId: string,
    cursor: string | null,
    limit: number,
    filters: { symbol?: string; type?: 'BUY' | 'SELL' | 'FEE' },
  ): Promise<MobileTransactionPage> {
    const { data } = await api.get<MobileTransactionPage>(
      API_ENDPOINTS.mobile.transactions(portfolioId),
      {
        params: {
          limit,
          ...(cursor ? { cursor } : {}),
          ...(filters.symbol ? { symbol: filters.symbol } : {}),
          ...(filters.type ? { type: filters.type } : {}),
        },
      },
    );
    return data;
  },
  async taxSummary(
    portfolioId: string,
    year: number,
    options: { electFinalTaxOnDividends: boolean; otherNetIncomeTHB?: string },
  ): Promise<TaxReport> {
    const { data } = await api.get<TaxReport>(API_ENDPOINTS.tax.summary(portfolioId, year), {
      params: {
        electFinalTaxOnDividends: String(options.electFinalTaxOnDividends),
        ...(options.otherNetIncomeTHB ? { otherNetIncomeTHB: options.otherNetIncomeTHB } : {}),
      },
    });
    return data;
  },
  async downloadTaxReport(
    portfolioId: string,
    year: number,
    options: { electFinalTaxOnDividends: boolean; otherNetIncomeTHB?: string },
  ): Promise<void> {
    const token = await getAccessToken();
    if (!token) throw new Error('Sign in again before downloading this report.');
    if (!FileSystem.cacheDirectory) throw new Error('Device temporary storage is unavailable.');

    const filename = `FIFO_Wealth_OS_Tax_Report_${year}.pdf`;
    const destination = `${FileSystem.cacheDirectory}${filename}`;
    const query = new URLSearchParams({
      electFinalTaxOnDividends: String(options.electFinalTaxOnDividends),
      ...(options.otherNetIncomeTHB ? { otherNetIncomeTHB: options.otherNetIncomeTHB } : {}),
    });
    const response = await FileSystem.downloadAsync(
      `${API_BASE_URL}${API_ENDPOINTS.tax.report(portfolioId, year)}?${query.toString()}`,
      destination,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    if (response.status < 200 || response.status >= 300) {
      await FileSystem.deleteAsync(destination, { idempotent: true }).catch(() => undefined);
      if (response.status === 401) {
        await authApi.me().catch(() => undefined);
        throw new Error('Your session expired. Sign in again to export this report.');
      }
      throw new Error(`Report export failed with status ${response.status}.`);
    }
    if (!(await Sharing.isAvailableAsync())) {
      await FileSystem.deleteAsync(response.uri, { idempotent: true }).catch(() => undefined);
      throw new Error('The report was created, but sharing is unavailable on this device.');
    }
    try {
      await Sharing.shareAsync(response.uri, {
        mimeType: 'application/pdf',
        dialogTitle: 'Share FIFO Wealth OS tax report',
        UTI: 'com.adobe.pdf',
      });
    } finally {
      await FileSystem.deleteAsync(response.uri, { idempotent: true }).catch(() => undefined);
    }
  },
};

export const brokerApi = {
  async ibkrStatus(): Promise<IbkrConnection> {
    const { data } = await api.get<IbkrConnection>(API_ENDPOINTS.sync.status);
    return data;
  },
  async connectIbkr(payload: { flexQueryToken: string; flexQueryId: string; portfolioId?: string }): Promise<void> {
    await api.post(API_ENDPOINTS.sync.ibkrConnect, payload);
  },
  async disconnectIbkr(): Promise<void> {
    await api.delete(API_ENDPOINTS.sync.ibkrDisconnect);
  },
  async syncIbkr(portfolioId?: string): Promise<unknown> {
    const { data } = await api.post<unknown>(API_ENDPOINTS.sync.ibkrTrigger, { portfolioId });
    return data;
  },
  async thaiBrokerStatus(): Promise<ThaiBrokerStatusResponse> {
    const { data } = await api.get<ThaiBrokerStatusResponse>(API_ENDPOINTS.thaiBrokers.status);
    return data;
  },
  async syncThaiBroker(broker: ThaiBrokerId, portfolioId?: string): Promise<ThaiBrokerSyncResult> {
    const { data } = await api.post<ThaiBrokerSyncResult>(API_ENDPOINTS.thaiBrokers.sync(broker), {
      ...(portfolioId ? { portfolioId } : {}),
    });
    return data;
  },
  async connectBitkub(payload: {
    apiKey: string;
    apiSecret: string;
    portfolioId?: string;
    permissionsScope: 'READ_ONLY';
    pdpaConsent: { accepted: true; consentVersion: string; purposes: string[] };
  }): Promise<void> {
    await api.post(API_ENDPOINTS.thaiBrokers.connect('BITKUB'), payload);
  },
  async disconnectThaiBroker(broker: ThaiBrokerId): Promise<void> {
    await api.delete(API_ENDPOINTS.thaiBrokers.disconnect(broker), { params: { purgeData: true } });
  },
};

export async function shareTaxReport(
  portfolioId: string,
  year: number,
  options: { electFinalTaxOnDividends: boolean; otherNetIncomeTHB?: string } = {
    electFinalTaxOnDividends: false,
  },
): Promise<void> {
  await mobileApi.downloadTaxReport(portfolioId, year, options);
}
