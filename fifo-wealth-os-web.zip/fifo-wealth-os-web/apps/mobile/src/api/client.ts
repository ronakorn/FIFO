import { isAxiosError } from 'axios';
import { createAuthenticatedApiClient } from '@fifo/api';
import { getAccessToken } from '@/auth/tokenStore';
import type { ApiErrorPayload } from '@/api/types';

export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/+$/, '')
  ?? 'http://10.0.2.2:3000/api';

const authenticatedClient = createAuthenticatedApiClient({
  baseURL: API_BASE_URL,
  timeoutMs: 20_000,
  headers: { Accept: 'application/json' },
  getAccessToken,
});

export const api = authenticatedClient.client;
export const registerUnauthorizedHandler = authenticatedClient.registerUnauthorizedHandler;

export function getApiErrorMessage(error: unknown): string {
  if (isAxiosError<ApiErrorPayload>(error)) {
    const serverMessage = error.response?.data?.error?.message;
    if (serverMessage) return serverMessage;
    if (error.code === 'ECONNABORTED') return 'The request timed out. Check your connection and try again.';
    if (!error.response) return 'Unable to reach FIFO Wealth OS. Check your network or API URL.';
  }
  if (error instanceof Error) return error.message;
  return 'Something went wrong. Please try again.';
}
