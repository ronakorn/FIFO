import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';

const ACCESS_TOKEN_KEY = 'fifo.mobile.access-token.v1';

/** Authenticate using biometrics when the device has hardware and enrolled data. */
export async function loginWithBiometrics(
  promptMessage = 'Continue securely with biometrics',
): Promise<boolean> {
  const [hasHardware, isEnrolled] = await Promise.all([
    LocalAuthentication.hasHardwareAsync(),
    LocalAuthentication.isEnrolledAsync(),
  ]);
  if (!hasHardware || !isEnrolled) return false;

  const result = await LocalAuthentication.authenticateAsync({
    promptMessage,
    cancelLabel: 'Cancel',
    disableDeviceFallback: false,
  });
  return result.success;
}

/** Persist an issued access JWT in the device Keychain/Keystore. */
export async function saveSession(token: string): Promise<void> {
  if (!token.trim()) throw new Error('Cannot save an empty access token.');
  await SecureStore.setItemAsync(ACCESS_TOKEN_KEY, token, {
    keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
  });
}

/** Read the issued access JWT from device-secure storage. */
export async function getSession(): Promise<string | null> {
  return SecureStore.getItemAsync(ACCESS_TOKEN_KEY);
}

/** Remove the persisted access JWT; AuthProvider owns the in-memory sign-out state. */
export async function clearSession(): Promise<void> {
  await SecureStore.deleteItemAsync(ACCESS_TOKEN_KEY);
}
