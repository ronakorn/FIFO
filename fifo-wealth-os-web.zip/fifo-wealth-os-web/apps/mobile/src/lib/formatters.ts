// Backward-compatible import path for existing screens and tests.
export {
  decimal40,
  FinancialDecimal,
  formatDate,
  formatDateTime,
  formatNumber,
  formatPercentRatio,
  formatThb,
  toChartNumber,
} from '@fifo/utils';
