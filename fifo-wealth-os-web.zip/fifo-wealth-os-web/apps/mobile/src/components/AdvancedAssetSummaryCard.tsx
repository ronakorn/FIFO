import type { AdvancedAssetSampleSummary } from '@fifo/types';
import { memo } from 'react';
import { Text, View } from 'react-native';
import { Button, Card, StatusPill } from '@/components/Primitives';
import { formatAdvancedAssetMetric } from '@/features/advancedAssets/presentation';
import { useTheme } from '@/theme/ThemeProvider';

function AdvancedAssetSummaryCardComponent({
  summary,
  onViewWeb,
}: {
  summary: AdvancedAssetSampleSummary;
  onViewWeb: () => void;
}): React.JSX.Element {
  const { colors } = useTheme();
  const valueColor = summary.tone === 'positive'
    ? colors.gain
    : summary.tone === 'warning'
      ? colors.gold
      : colors.ink;

  return (
    <Card className="gap-3 rounded-2xl">
      <View className="flex-row items-start justify-between gap-3">
        <View className="flex-1">
          <Text className="font-display text-base font-bold text-ink">{summary.title}</Text>
          <Text className="mt-1 font-body text-xs text-muted">{summary.metricLabel}</Text>
        </View>
        <StatusPill label="Sample Data" tone="warning" />
      </View>
      <Text accessibilityLabel={`${summary.metricLabel}: ${formatAdvancedAssetMetric(summary)}`} className="font-display text-3xl font-extrabold" style={{ color: valueColor }}>
        {formatAdvancedAssetMetric(summary)}
      </Text>
      <Text className="font-body text-xs leading-5 text-muted">{summary.detail}</Text>
      <Button
        accessibilityLabel={`View ${summary.title} on Web`}
        accessibilityHint="Opens this sample asset summary in the web app."
        title="View on Web"
        variant="secondary"
        onPress={onViewWeb}
      />
    </Card>
  );
}

export const AdvancedAssetSummaryCard = memo(AdvancedAssetSummaryCardComponent);
