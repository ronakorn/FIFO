import type { IbkrConnection, ThaiBrokerConnection, ThaiBrokerId } from '@fifo/types';
import { memo, useMemo } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { Button, Card, StatusPill } from '@/components/Primitives';
import { formatDateTime } from '@/lib/formatters';

export type BrokerTarget = 'IBKR' | ThaiBrokerId;
type BrokerAction = 'sync' | 'disconnect';
export type BrokerBusyState = { broker: BrokerTarget; action: BrokerAction } | null;
type DisplayStatus = 'CONNECTED' | 'SYNCING' | 'ERROR' | 'DISCONNECTED' | 'LOADING' | 'UNAVAILABLE';

interface BrokerRow {
  target: BrokerTarget;
  name: string;
  mark: string;
  status: DisplayStatus;
  lastSyncedAt: string | null;
  hasConnection: boolean;
}

interface ConnectedBrokersProps {
  ibkr: IbkrConnection | undefined;
  thaiConnections: ThaiBrokerConnection[] | undefined;
  ibkrLoading: boolean;
  thaiLoading: boolean;
  ibkrUnavailable?: boolean;
  thaiUnavailable?: boolean;
  busyAction?: BrokerBusyState;
  onSync: (broker: BrokerTarget) => void;
  onDisconnect: (broker: BrokerTarget) => void;
}

const THAI_BROKERS: { id: ThaiBrokerId; name: string; mark: string }[] = [
  { id: 'BITKUB', name: 'Bitkub', mark: 'B' },
  { id: 'DIME', name: 'Dime', mark: 'D' },
  { id: 'STREAMING', name: 'Streaming', mark: 'S' },
];

function describeStatus(status: DisplayStatus): { label: string; tone: 'good' | 'bad' | 'muted' | 'warning' } {
  switch (status) {
    case 'CONNECTED': return { label: 'Connected', tone: 'good' };
    case 'SYNCING': return { label: 'Syncing', tone: 'warning' };
    case 'ERROR': return { label: 'Error', tone: 'bad' };
    case 'UNAVAILABLE': return { label: 'Unavailable', tone: 'bad' };
    case 'LOADING': return { label: 'Loading', tone: 'muted' };
    case 'DISCONNECTED': return { label: 'Disconnected', tone: 'muted' };
  }
}

function makeIbkrRow(
  connection: IbkrConnection | undefined,
  loading: boolean,
  unavailable: boolean,
): BrokerRow {
  const status: DisplayStatus = connection?.status
    ?? (loading ? 'LOADING' : unavailable ? 'UNAVAILABLE' : 'DISCONNECTED');
  return {
    target: 'IBKR',
    name: 'Interactive Brokers',
    mark: 'IB',
    status,
    lastSyncedAt: connection?.lastSyncedAt ?? null,
    hasConnection: Boolean(connection && connection.status !== 'DISCONNECTED'),
  };
}

function makeThaiRow(
  config: (typeof THAI_BROKERS)[number],
  connections: ThaiBrokerConnection[] | undefined,
  loading: boolean,
  unavailable: boolean,
): BrokerRow {
  const connection = connections?.find((candidate) => candidate.broker === config.id);
  const status: DisplayStatus = connection?.status
    ?? (loading ? 'LOADING' : unavailable ? 'UNAVAILABLE' : 'DISCONNECTED');
  return {
    target: config.id,
    name: connection?.displayName ?? config.name,
    mark: config.mark,
    status,
    lastSyncedAt: connection?.lastSyncedAt ?? null,
    hasConnection: Boolean(connection && connection.status !== 'DISCONNECTED'),
  };
}

function BrokerCardComponent({
  row,
  busyAction,
  onSync,
  onDisconnect,
}: {
  row: BrokerRow;
  busyAction: BrokerBusyState;
  onSync: (broker: BrokerTarget) => void;
  onDisconnect: (broker: BrokerTarget) => void;
}): React.JSX.Element {
  const status = describeStatus(row.status);
  const isBusy = busyAction !== null;
  const syncing = busyAction?.broker === row.target && busyAction.action === 'sync';
  const disconnecting = busyAction?.broker === row.target && busyAction.action === 'disconnect';

  return (
    <Card className="gap-3">
      <View className="flex-row items-center gap-3">
        <View className="h-11 w-11 items-center justify-center rounded-2xl bg-accent/15">
          <Text className="font-display text-xs font-extrabold text-accent-bright">{row.mark}</Text>
        </View>
        <View className="min-w-0 flex-1">
          <Text className="font-display text-sm font-bold text-ink">{row.name}</Text>
          <Text className="mt-1 font-body text-[11px] text-muted">Read-only connection</Text>
        </View>
        <View className="flex-row items-center gap-2">
          {row.status === 'LOADING' ? <ActivityIndicator accessibilityLabel={`Loading ${row.name} connection`} size="small" color="#D8D9E0" /> : null}
          <StatusPill label={status.label} tone={status.tone} />
        </View>
      </View>
      <Text className="font-body text-xs text-muted">
        Last synced · {row.lastSyncedAt ? formatDateTime(row.lastSyncedAt) : 'Not yet synced'}
      </Text>
      {row.hasConnection ? (
        <View className="flex-row gap-2">
          <Button
            accessibilityLabel={`Sync ${row.name}`}
            accessibilityHint="Requests a read-only import from this broker."
            className="flex-1"
            title="Sync now"
            variant="secondary"
            loading={syncing}
            disabled={isBusy || row.status === 'LOADING' || row.status === 'UNAVAILABLE' || row.status === 'SYNCING'}
            onPress={() => onSync(row.target)}
          />
          <Button
            accessibilityLabel={`Disconnect ${row.name}`}
            accessibilityHint="Opens a confirmation before disconnecting this broker."
            className="flex-1"
            title="Disconnect"
            variant="danger"
            loading={disconnecting}
            disabled={isBusy || row.status === 'LOADING' || row.status === 'UNAVAILABLE'}
            onPress={() => onDisconnect(row.target)}
          />
        </View>
      ) : null}
    </Card>
  );
}

const BrokerCard = memo(BrokerCardComponent);

export function ConnectedBrokers({
  ibkr,
  thaiConnections,
  ibkrLoading,
  thaiLoading,
  ibkrUnavailable = false,
  thaiUnavailable = false,
  busyAction = null,
  onSync,
  onDisconnect,
}: ConnectedBrokersProps): React.JSX.Element {
  const rows = useMemo(() => [
    makeIbkrRow(ibkr, ibkrLoading, ibkrUnavailable),
    ...THAI_BROKERS.map((config) => makeThaiRow(config, thaiConnections, thaiLoading, thaiUnavailable)),
  ], [ibkr, ibkrLoading, ibkrUnavailable, thaiConnections, thaiLoading, thaiUnavailable]);

  return (
    <View className="gap-3">
      {rows.map((row) => (
        <BrokerCard
          key={row.target}
          row={row}
          busyAction={busyAction}
          onSync={onSync}
          onDisconnect={onDisconnect}
        />
      ))}
    </View>
  );
}
