import { memo } from 'react';
import type { PendingManualTransaction } from '@fifo/types';
import { CheckCircle2, Clock3, CloudOff } from 'lucide-react-native';
import { Text, View } from 'react-native';
import type { Transaction } from '@/api/types';
import { Card, StatusPill } from '@/components/Primitives';
import { formatDate, formatNumber, formatThb } from '@/lib/formatters';
import { useTheme } from '@/theme/ThemeProvider';

export type PortfolioLedgerEntry =
  | { status: 'queued'; transaction: PendingManualTransaction }
  | { status: 'confirmed'; transaction: Transaction };

function PortfolioTransactionRowComponent({ entry }: { entry: PortfolioLedgerEntry }): React.JSX.Element {
  const { colors } = useTheme();
  const queued = entry.status === 'queued';
  const transaction = entry.transaction;
  const confirmedTransaction = entry.status === 'confirmed' ? entry.transaction : null;
  const title = `${transaction.symbol} · ${transaction.type}`;
  const description = `${formatNumber(transaction.qty, 6)} @ ${formatNumber(transaction.price, 2)} ${confirmedTransaction?.originalCurrency ?? 'THB'}`;

  return (
    <Card className="flex-row items-center gap-3 rounded-2xl p-3.5">
      <View
        accessible
        accessibilityLabel={queued ? 'Queued locally; not synced' : 'Confirmed on server'}
        className={`h-10 w-10 items-center justify-center rounded-2xl ${queued ? 'bg-gold/10' : 'bg-gain/10'}`}
      >
        {queued ? (
          <View className="flex-row items-center gap-0.5">
            <Clock3 color={colors.gold} size={16} />
            <CloudOff color={colors.gold} size={16} />
          </View>
        ) : <CheckCircle2 color={colors.gain} size={19} />}
      </View>
      <View className="min-w-0 flex-1">
        <Text className="font-display text-sm font-bold text-ink">{title}</Text>
        <Text className="mt-1 font-body text-xs text-muted">{formatDate(transaction.date)}</Text>
        <Text className="mt-1 font-body text-xs text-muted">{description}</Text>
      </View>
      <View className="items-end gap-2">
        <StatusPill label={queued ? 'Queued' : 'Confirmed'} tone={queued ? 'warning' : 'good'} />
        {confirmedTransaction?.netTHB ? (
          <Text className="font-display text-xs font-bold text-ink">{formatThb(confirmedTransaction.netTHB)}</Text>
        ) : null}
        {queued ? <Text className="font-body text-[10px] text-muted">Local only</Text> : null}
      </View>
    </Card>
  );
}

export const PortfolioTransactionRow = memo(PortfolioTransactionRowComponent);
