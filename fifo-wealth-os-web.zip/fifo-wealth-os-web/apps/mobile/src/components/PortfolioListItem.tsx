import { memo, useCallback } from 'react';
import { Pressable, Text, View } from 'react-native';
import type { Portfolio } from '@/api/types';
import { formatThb } from '@/lib/formatters';

interface PortfolioListItemProps {
  portfolio: Portfolio;
  onPress: (portfolioId: string) => void;
}

function PortfolioListItemComponent({ portfolio, onPress }: PortfolioListItemProps): React.JSX.Element {
  const handlePress = useCallback(() => onPress(portfolio.id), [onPress, portfolio.id]);

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Open ${portfolio.name} portfolio`}
      accessibilityHint="Opens server-calculated holdings and activity for this portfolio."
      className="rounded-2xl border border-stroke bg-surface p-4 active:bg-raised"
      onPress={handlePress}
    >
      <View className="flex-row items-center justify-between gap-3">
        <View className="flex-1">
          <Text className="font-display text-sm font-bold text-ink">{portfolio.name}</Text>
          <Text className="mt-1 font-body text-xs text-muted">
            {portfolio.transactionCount ?? 0} transactions · {portfolio.baseCurrency}
          </Text>
        </View>
        <Text className="font-display text-sm font-bold text-ink">
          {formatThb(portfolio.fifoSummary?.marketValueTHB)}
        </Text>
      </View>
    </Pressable>
  );
}

export const PortfolioListItem = memo(PortfolioListItemComponent);
