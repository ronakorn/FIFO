import { useNetInfo } from '@react-native-community/netinfo';
import type { PropsWithChildren, ReactElement, ReactNode } from 'react';
import { ScrollView, Text, View, type RefreshControlProps } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

interface ScreenProps extends PropsWithChildren {
  contentClassName?: string;
  floatingAction?: ReactNode;
  refreshControl?: ReactElement<RefreshControlProps>;
  scroll?: boolean;
}

export function OfflineBanner(): React.JSX.Element | null {
  const network = useNetInfo();
  const isOffline = network.isConnected === false || network.isInternetReachable === false;
  if (!isOffline) return null;

  return (
    <View className="mx-5 mt-2 flex-row items-center rounded-2xl border border-gold/25 bg-gold/10 px-4 py-2.5">
      <View className="mr-2 h-2 w-2 rounded-full bg-gold" />
      <Text className="flex-1 font-body text-xs font-semibold leading-5 text-ink">
        Offline · showing the latest available snapshot; new Quick Add entries stay queued on this device.
      </Text>
    </View>
  );
}

export function Screen({
  children,
  contentClassName = '',
  floatingAction,
  refreshControl,
  scroll = true,
}: ScreenProps): React.JSX.Element {
  return (
    <SafeAreaView className="flex-1 bg-midnight" edges={['top']}>
      <OfflineBanner />
      {scroll ? (
        <ScrollView
          className="flex-1"
          keyboardShouldPersistTaps="handled"
          refreshControl={refreshControl}
          showsVerticalScrollIndicator={false}
        >
          <View className={`px-5 pb-32 pt-5 ${contentClassName}`}>{children}</View>
        </ScrollView>
      ) : (
        <View className={contentClassName ? `flex-1 ${contentClassName}` : 'flex-1 px-5'}>{children}</View>
      )}
      {floatingAction}
    </SafeAreaView>
  );
}
