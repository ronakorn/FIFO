import Svg, { Circle, Path } from 'react-native-svg';
import { View } from 'react-native';
import type { DashboardAnalyticsResponse } from '@/api/types';
import { toChartNumber } from '@/lib/formatters';
import { useTheme } from '@/theme/ThemeProvider';

const ALLOCATION_COLORS = ['#D14350', '#D9B76D', '#54D39A', '#6F83D8', '#40B7BD', '#9D7ED4', '#E28D58'];

export function allocationColor(index: number): string {
  return ALLOCATION_COLORS[index % ALLOCATION_COLORS.length] ?? ALLOCATION_COLORS[0] ?? '#D14350';
}

export interface AllocationDatum {
  key: string;
  label: string;
  weightPct: string;
  color?: string;
}

function allocationWeight(value: string): number {
  return Math.max(0, Math.min(100, toChartNumber(value)));
}

export function AllocationDonut({ allocation }: { allocation: AllocationDatum[] }): React.JSX.Element {
  const { colors } = useTheme();
  const radius = 44;
  const stroke = 15;
  const circumference = 2 * Math.PI * radius;
  const segments = allocation.map((item, index) => {
    const consumedPct = allocation.slice(0, index).reduce((total, previous) => total + allocationWeight(previous.weightPct), 0);
    const weight = allocationWeight(item.weightPct);
    return { item, index, weight, consumedPct };
  });

  return (
    <View className="items-center justify-center">
      <Svg width={132} height={132} viewBox="0 0 132 132" accessibilityLabel="Portfolio allocation chart">
        <Circle cx={66} cy={66} r={radius} stroke={colors.raised} strokeWidth={stroke} fill="transparent" />
        {segments.map(({ item, index, weight, consumedPct }) => {
          const segment = circumference * (weight / 100);
          const offset = circumference * (consumedPct / 100);
          return (
            <Circle
              key={item.key}
              cx={66}
              cy={66}
              r={radius}
              stroke={item.color ?? allocationColor(index)}
              strokeDasharray={`${segment} ${circumference - segment}`}
              strokeDashoffset={-offset}
              strokeLinecap="round"
              strokeWidth={stroke}
              fill="transparent"
              rotation={-90}
              origin="66, 66"
            />
          );
        })}
      </Svg>
    </View>
  );
}

function makePath(values: number[], width: number, height: number, min: number, max: number): string {
  if (values.length < 2) return '';
  const range = max - min || 1;
  return values.map((value, index) => {
    const x = (index / (values.length - 1)) * width;
    const y = height - ((value - min) / range) * height;
    return `${index === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
  }).join(' ');
}

export function PerformanceChart({ series }: { series: DashboardAnalyticsResponse['benchmarkSeries'] }): React.JSX.Element {
  if (series.length < 2) {
    return (
      <View className="h-36 items-center justify-center rounded-2xl bg-raised px-5">
        <View className="h-1 w-12 rounded-full bg-accent" />
      </View>
    );
  }

  const width = 320;
  const height = 124;
  const portfolio = series.map((point) => point.portfolioValue);
  const benchmark = series.map((point) => point.benchmarkValue);
  const allValues = [...portfolio, ...benchmark].filter(Number.isFinite);
  const min = Math.min(...allValues);
  const max = Math.max(...allValues);
  const portfolioPath = makePath(portfolio, width, height, min, max);
  const benchmarkPath = makePath(benchmark, width, height, min, max);

  return (
    <Svg width="100%" height={148} viewBox={`0 0 ${width} ${height}`} accessibilityLabel="Portfolio and benchmark historical performance">
      <Path d={benchmarkPath} fill="none" stroke="#7E8496" strokeDasharray="5 5" strokeWidth={2} />
      <Path d={portfolioPath} fill="none" stroke="#D14350" strokeWidth={3} />
    </Svg>
  );
}
