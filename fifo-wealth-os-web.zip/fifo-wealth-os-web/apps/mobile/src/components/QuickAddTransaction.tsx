import DateTimePicker, { type DateTimePickerEvent } from '@react-native-community/datetimepicker';
import { useNetInfo } from '@react-native-community/netinfo';
import type { ManualTransactionDraft, ManualTransactionSide, PendingManualTransaction, Portfolio } from '@fifo/types';
import * as Crypto from 'expo-crypto';
import { Plus, X } from 'lucide-react-native';
import { useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button, Field } from '@/components/Primitives';
import { usePendingManualTransactions } from '@/hooks/usePendingManualTransactions';
import { formatDate } from '@/lib/formatters';
import { hapticSuccess, hapticWarning } from '@/lib/haptics';
import { toLocalDateString, validateQuickAddDraft } from '@/features/transactions/validation';

interface QuickAddTransactionProps {
  portfolios: Portfolio[];
}

function getDateLabel(date: Date): string {
  return formatDate(`${toLocalDateString(date)}T12:00:00`);
}

export function QuickAddTransaction({ portfolios }: QuickAddTransactionProps): React.JSX.Element {
  const network = useNetInfo();
  const insets = useSafeAreaInsets();
  const { addPendingTransaction } = usePendingManualTransactions();
  const [visible, setVisible] = useState(false);
  const [preferredPortfolioId, setPreferredPortfolioId] = useState(portfolios[0]?.id ?? '');
  const [symbol, setSymbol] = useState('');
  const [side, setSide] = useState<ManualTransactionSide>('BUY');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');
  const [tradeDate, setTradeDate] = useState(new Date());
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const selectedPortfolioId = portfolios.some((portfolio) => portfolio.id === preferredPortfolioId)
    ? preferredPortfolioId
    : portfolios[0]?.id ?? '';

  const date = toLocalDateString(tradeDate);
  const draft: ManualTransactionDraft = {
    portfolioId: selectedPortfolioId,
    symbol,
    type: side,
    qty: quantity,
    price,
    date,
  };
  const validationErrors = validateQuickAddDraft(draft);
  const isValid = Object.keys(validationErrors).length === 0;
  const isOffline = network.isConnected === false || network.isInternetReachable === false;

  const showError = (fieldValue: string, error: string | undefined): string | undefined => (
    fieldValue.trim() ? error : undefined
  );

  const closeSheet = (): void => {
    setVisible(false);
    setDatePickerVisible(false);
    setSubmitError('');
  };

  const resetDraft = (): void => {
    setSymbol('');
    setSide('BUY');
    setQuantity('');
    setPrice('');
    setTradeDate(new Date());
    setSubmitError('');
  };

  const handleDateChange = (event: DateTimePickerEvent, selectedDate?: Date): void => {
    if (event.type === 'set' && selectedDate) setTradeDate(selectedDate);
    if (Platform.OS !== 'ios') setDatePickerVisible(false);
  };

  const handleSubmit = async (): Promise<void> => {
    if (saving) return;
    if (!isValid) {
      hapticWarning();
      setSubmitError('Review the highlighted fields and enter a valid symbol, quantity, price, date, and portfolio.');
      return;
    }
    setSaving(true);
    setSubmitError('');

    const transaction: PendingManualTransaction = {
      ...draft,
      id: Crypto.randomUUID(),
      symbol: draft.symbol.trim().toUpperCase(),
      qty: draft.qty.trim(),
      price: draft.price.trim(),
      createdAt: new Date().toISOString(),
      syncStatus: 'queued',
    };

    try {
      const result = await addPendingTransaction(transaction);
      hapticSuccess();
      closeSheet();
      resetDraft();
      const message = result.persisted
        ? isOffline
          ? 'Saved in the encrypted offline queue. The current API has no transaction-create route, so it will remain local until a supported server endpoint is available.'
          : 'Saved securely on this device. The current API supports transaction reads only; this entry will not update portfolio totals or sync until a create endpoint is available.'
        : 'Saved for this app session only. Encrypted SQLCipher storage is unavailable in this build, and the current API has no transaction-create route.';
      Alert.alert('Quick Add saved locally', message);
    } catch (error) {
      setSubmitError(error instanceof Error ? error.message : 'Unable to save this trade locally.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Quick add transaction"
        accessibilityHint="Opens the local buy or sell transaction form."
        className="absolute bottom-5 right-5 z-50 h-14 w-14 items-center justify-center rounded-2xl bg-accent shadow-xl active:bg-accent-bright"
        onPress={() => setVisible(true)}
      >
        <Plus color="#FFFFFF" size={25} strokeWidth={2.5} />
      </Pressable>

      <Modal
        animationType="slide"
        onRequestClose={closeSheet}
        statusBarTranslucent
        transparent
        visible={visible}
      >
        <KeyboardAvoidingView
          className="flex-1 justify-end"
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Close Quick Add"
            accessibilityHint="Dismisses the Quick Add form without saving."
            className="absolute inset-0 bg-black/60"
            onPress={closeSheet}
          />
          <View
            className="max-h-[94%] rounded-t-2xl border border-stroke bg-surface px-5 pt-4"
            style={{ paddingBottom: Math.max(insets.bottom, 16) }}
          >
            <View className="mb-4 h-1 w-10 self-center rounded-full bg-muted/40" />
            <View className="mb-4 flex-row items-start justify-between">
              <View className="flex-1 pr-4">
                <Text className="font-display text-xl font-extrabold text-ink">Quick Add</Text>
                <Text className="mt-1 font-body text-xs text-muted">Add a manual buy or sell entry.</Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close Quick Add"
                accessibilityHint="Dismisses the Quick Add form without saving."
                className="h-10 w-10 items-center justify-center rounded-xl bg-raised"
                onPress={closeSheet}
              >
                <X color="#A7ACB8" size={18} />
              </Pressable>
            </View>

            <View className="mb-4 rounded-2xl border border-gold/25 bg-gold/10 px-3 py-2.5">
              <Text className="font-body text-xs leading-5 text-ink">
                The existing API supports transaction reads only; POST /api/transactions is not implemented. Entries are saved locally, excluded from portfolio totals, and cannot sync yet.
              </Text>
            </View>

            <ScrollView
              className="mb-2"
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ paddingBottom: 16 }}
            >
              {portfolios.length ? (
                <View className="gap-2">
                  <Text className="font-body text-xs font-bold uppercase tracking-widest text-muted">Portfolio</Text>
                  <View className="flex-row flex-wrap gap-2">
                    {portfolios.map((portfolio) => {
                      const selected = selectedPortfolioId === portfolio.id;
                      return (
                        <Pressable
                          key={portfolio.id}
                          accessibilityRole="button"
                          accessibilityLabel={`Select ${portfolio.name} portfolio`}
                          accessibilityHint="Choose where this local trade entry should be organized."
                          accessibilityState={{ selected }}
                          onPress={() => setPreferredPortfolioId(portfolio.id)}
                          className={`rounded-xl border px-3 py-2 ${selected ? 'border-accent bg-accent/15' : 'border-stroke bg-raised'}`}
                        >
                          <Text className={`font-body text-xs font-bold ${selected ? 'text-accent-bright' : 'text-muted'}`}>
                            {portfolio.name}
                          </Text>
                        </Pressable>
                      );
                    })}
                  </View>
                </View>
              ) : (
                <View className="rounded-2xl border border-stroke bg-raised p-3">
                  <Text className="font-body text-sm font-semibold text-ink">Create a portfolio first</Text>
                  <Text className="mt-1 font-body text-xs leading-5 text-muted">Quick Add needs a portfolio to keep the local entry organized.</Text>
                </View>
              )}

              <View className="mt-4 gap-4">
                <Field
                  autoCapitalize="characters"
                  label="Symbol"
                  maxLength={20}
                  onChangeText={setSymbol}
                  placeholder="e.g. AAPL or BTC"
                  value={symbol}
                  error={showError(symbol, validationErrors.symbol)}
                />

                <View className="gap-2">
                  <Text className="font-body text-xs font-bold uppercase tracking-widest text-muted">Side</Text>
                  <View className="flex-row gap-2">
                    {(['BUY', 'SELL'] as const).map((option) => {
                      const selected = side === option;
                      return (
                        <Pressable
                          key={option}
                          accessibilityRole="button"
                          accessibilityLabel={`${option === 'BUY' ? 'Buy' : 'Sell'} transaction side`}
                          accessibilityHint={`Selects ${option === 'BUY' ? 'buy' : 'sell'} for this local entry.`}
                          accessibilityState={{ selected }}
                          onPress={() => setSide(option)}
                          className={`min-h-12 flex-1 items-center justify-center rounded-2xl border ${selected ? 'border-accent bg-accent/15' : 'border-stroke bg-raised'}`}
                        >
                          <Text className={`font-display text-sm font-bold ${selected ? 'text-accent-bright' : 'text-muted'}`}>
                            {option === 'BUY' ? 'Buy' : 'Sell'}
                          </Text>
                        </Pressable>
                      );
                    })}
                  </View>
                </View>

                <Field
                  keyboardType="decimal-pad"
                  label="Quantity"
                  onChangeText={setQuantity}
                  placeholder="0.00"
                  value={quantity}
                  error={showError(quantity, validationErrors.qty)}
                />
                <Field
                  keyboardType="decimal-pad"
                  label="Price per unit"
                  onChangeText={setPrice}
                  placeholder="0.00"
                  value={price}
                  error={showError(price, validationErrors.price)}
                />

                <View className="gap-2">
                  <Text className="font-body text-xs font-bold uppercase tracking-widest text-muted">Trade date</Text>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Trade date, ${getDateLabel(tradeDate)}`}
                    accessibilityHint="Opens or closes the trade date picker."
                    className="min-h-12 flex-row items-center justify-between rounded-2xl border border-stroke bg-raised px-4 py-3"
                    onPress={() => setDatePickerVisible((current) => !current)}
                  >
                    <Text className="font-body text-base text-ink">{getDateLabel(tradeDate)}</Text>
                    <Text className="font-body text-xs font-semibold text-accent-bright">Choose date</Text>
                  </Pressable>
                  {datePickerVisible ? (
                    <View className="overflow-hidden rounded-2xl border border-stroke bg-raised p-2">
                      <DateTimePicker
                        display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                        mode="date"
                        onChange={handleDateChange}
                        value={tradeDate}
                      />
                      {Platform.OS === 'ios' ? (
                        <Button title="Done" accessibilityHint="Closes the date picker and keeps the selected date." variant="secondary" onPress={() => setDatePickerVisible(false)} />
                      ) : null}
                    </View>
                  ) : null}
                </View>

                {submitError ? (
                  <View className="rounded-2xl border border-loss/30 bg-loss/10 p-3">
                    <Text className="font-body text-xs leading-5 text-loss">{submitError}</Text>
                  </View>
                ) : null}

                <Button
                  title={saving ? 'Saving locally…' : 'Save trade to local queue'}
                  accessibilityHint="Saves this manual trade only on this device. It will not sync or affect portfolio totals."
                  loading={saving}
                  disabled={!portfolios.length}
                  onPress={handleSubmit}
                  className="mt-1"
                />
              </View>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </>
  );
}
