import React, { type ErrorInfo, type ReactNode } from 'react';
import { Pressable, Text, View } from 'react-native';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = { hasError: false };

  public static getDerivedStateFromError(_error: Error): ErrorBoundaryState {
    return { hasError: true };
  }

  public componentDidCatch(_error: Error, _info: ErrorInfo): void {
    // Do not log financial payloads or tokens; integrate a redacted crash reporter separately.
  }

  public render(): ReactNode {
    if (this.state.hasError) {
      return (
        <View className="flex-1 items-center justify-center bg-midnight px-8">
          <Text className="font-display text-xl font-bold text-ink">Something went wrong</Text>
          <Text className="mt-3 text-center font-body text-sm leading-6 text-muted">
            Your financial data has not been changed. Restart the screen to try again.
          </Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Retry screen"
            accessibilityHint="Dismisses the error state and retries rendering this screen."
            className="mt-6 rounded-2xl bg-accent px-5 py-3"
            onPress={() => this.setState({ hasError: false })}
          >
            <Text className="font-display text-sm font-bold text-white">Retry</Text>
          </Pressable>
        </View>
      );
    }
    return this.props.children;
  }
}
