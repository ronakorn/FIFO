import type { PendingManualTransaction } from '@fifo/types';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  persistPendingManualTransactions,
  readPendingManualTransactions,
} from '@/features/transactions/pendingQueue';

export const PENDING_MANUAL_TRANSACTIONS_QUERY_KEY = ['mobile-pending-manual-transactions'] as const;

export function usePendingManualTransactions() {
  const queryClient = useQueryClient();
  const query = useQuery<PendingManualTransaction[]>({
    queryKey: PENDING_MANUAL_TRANSACTIONS_QUERY_KEY,
    queryFn: readPendingManualTransactions,
    staleTime: Infinity,
  });

  const addPendingTransaction = async (
    transaction: PendingManualTransaction,
  ): Promise<{ persisted: boolean }> => {
    const loaded = await queryClient.fetchQuery({
      queryKey: PENDING_MANUAL_TRANSACTIONS_QUERY_KEY,
      queryFn: readPendingManualTransactions,
      staleTime: Infinity,
    });
    const previous = queryClient.getQueryData<PendingManualTransaction[]>(
      PENDING_MANUAL_TRANSACTIONS_QUERY_KEY,
    ) ?? loaded;
    const next = [...previous, transaction];

    // Update the visible queue immediately; secure persistence follows before the sheet closes.
    queryClient.setQueryData(PENDING_MANUAL_TRANSACTIONS_QUERY_KEY, next);
    const persisted = await persistPendingManualTransactions(next);
    return { persisted };
  };

  const removePendingTransaction = async (id: string): Promise<boolean> => {
    const loaded = await queryClient.fetchQuery({
      queryKey: PENDING_MANUAL_TRANSACTIONS_QUERY_KEY,
      queryFn: readPendingManualTransactions,
      staleTime: Infinity,
    });
    const previous = queryClient.getQueryData<PendingManualTransaction[]>(
      PENDING_MANUAL_TRANSACTIONS_QUERY_KEY,
    ) ?? loaded;
    const next = previous.filter((transaction) => transaction.id !== id);

    queryClient.setQueryData(PENDING_MANUAL_TRANSACTIONS_QUERY_KEY, next);
    return persistPendingManualTransactions(next);
  };

  return {
    transactions: query.data ?? [],
    isLoading: query.isPending,
    addPendingTransaction,
    removePendingTransaction,
  };
}
