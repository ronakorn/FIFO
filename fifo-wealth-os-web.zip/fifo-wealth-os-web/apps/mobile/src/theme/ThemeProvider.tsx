import * as SecureStore from 'expo-secure-store';
import { vars, useColorScheme } from 'nativewind';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type PropsWithChildren,
} from 'react';
import { View } from 'react-native';
import { getThemeColors, type AppColorScheme, type ThemeColors } from '@/theme/colors';

export type ThemePreference = AppColorScheme | 'system';

interface ThemeContextValue {
  colors: ThemeColors;
  preference: ThemePreference;
  resolvedScheme: AppColorScheme;
  setPreference: (preference: ThemePreference) => Promise<void>;
}

const THEME_PREFERENCE_KEY = 'fifo.mobile.theme-preference.v1';

const ThemeContext = createContext<ThemeContextValue | null>(null);

function toRgbChannels(hexColor: string): string {
  const hex = hexColor.replace('#', '');
  const channels = [0, 2, 4].map((offset) => Number.parseInt(hex.slice(offset, offset + 2), 16));
  return channels.join(' ');
}

function createThemeVariables(colors: ThemeColors): ReturnType<typeof vars> {
  return vars({
    '--color-midnight': toRgbChannels(colors.midnight),
    '--color-surface': toRgbChannels(colors.surface),
    '--color-raised': toRgbChannels(colors.raised),
    '--color-stroke': toRgbChannels(colors.stroke),
    '--color-muted': toRgbChannels(colors.muted),
    '--color-ink': toRgbChannels(colors.ink),
    '--color-accent': toRgbChannels(colors.accent),
    '--color-accent-bright': toRgbChannels(colors.accentBright),
    '--color-gain': toRgbChannels(colors.gain),
    '--color-loss': toRgbChannels(colors.loss),
    '--color-gold': toRgbChannels(colors.gold),
  });
}

const themeVariables: Record<AppColorScheme, ReturnType<typeof vars>> = {
  light: createThemeVariables(getThemeColors('light')),
  dark: createThemeVariables(getThemeColors('dark')),
};

function readStoredPreference(value: string | null): ThemePreference {
  return value === 'light' || value === 'dark' ? value : 'system';
}

export function ThemeProvider({ children }: PropsWithChildren): React.JSX.Element {
  const { colorScheme, setColorScheme } = useColorScheme();
  const [preference, setPreferenceState] = useState<ThemePreference>('system');
  const [preferenceLoaded, setPreferenceLoaded] = useState(false);
  const resolvedScheme: AppColorScheme = colorScheme === 'dark' ? 'dark' : 'light';
  const colors = getThemeColors(resolvedScheme);

  useEffect(() => {
    let active = true;
    void SecureStore.getItemAsync(THEME_PREFERENCE_KEY).then((value) => {
      if (active) setPreferenceState(readStoredPreference(value));
    }).catch(() => undefined).finally(() => {
      if (active) setPreferenceLoaded(true);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (preferenceLoaded) setColorScheme(preference);
  }, [preference, preferenceLoaded, setColorScheme]);

  const setPreference = useCallback(async (nextPreference: ThemePreference): Promise<void> => {
    setPreferenceState(nextPreference);
    await SecureStore.setItemAsync(THEME_PREFERENCE_KEY, nextPreference);
  }, []);

  const contextValue = useMemo<ThemeContextValue>(() => ({
    colors,
    preference,
    resolvedScheme,
    setPreference,
  }), [colors, preference, resolvedScheme, setPreference]);

  return (
    <ThemeContext.Provider value={contextValue}>
      <View className="flex-1" style={themeVariables[resolvedScheme]}>
        {children}
      </View>
    </ThemeContext.Provider>
  );
}

export function useTheme(): ThemeContextValue {
  const theme = useContext(ThemeContext);
  if (!theme) throw new Error('useTheme must be used inside ThemeProvider.');
  return theme;
}
