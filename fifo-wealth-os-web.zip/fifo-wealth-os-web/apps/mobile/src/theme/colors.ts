export type AppColorScheme = 'light' | 'dark';

export interface ThemeColors {
  midnight: string;
  surface: string;
  raised: string;
  stroke: string;
  muted: string;
  ink: string;
  accent: string;
  accentBright: string;
  gain: string;
  loss: string;
  gold: string;
}

const lightColors: ThemeColors = {
  midnight: '#FAFAFA',
  surface: '#FFFFFF',
  raised: '#F1F4F2',
  stroke: '#D9E2DD',
  muted: '#586B62',
  ink: '#14342A',
  accent: '#14342A',
  accentBright: '#285B48',
  gain: '#21734B',
  loss: '#B42332',
  gold: '#8A6410',
};

const darkColors: ThemeColors = {
  midnight: '#121212',
  surface: '#1D1F1E',
  raised: '#292D2B',
  stroke: '#3A433F',
  muted: '#A5B0AA',
  ink: '#FAFAFA',
  accent: '#14342A',
  accentBright: '#69B58D',
  gain: '#69D3A0',
  loss: '#F17878',
  gold: '#D9B76D',
};

export function getThemeColors(scheme: AppColorScheme): ThemeColors {
  return scheme === 'dark' ? darkColors : lightColors;
}
