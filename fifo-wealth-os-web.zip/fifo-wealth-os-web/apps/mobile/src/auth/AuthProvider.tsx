import { AppState, type AppStateStatus } from 'react-native';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PropsWithChildren,
} from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { authApi } from '@/api/services';
import type { ApiUser } from '@/api/types';
import { registerUnauthorizedHandler } from '@/api/client';
import { clearSecureCache } from '@/cache/secureCache';
import { loginWithBiometrics } from '@/lib/auth';
import {
  clearSession,
  getAccessToken,
  getLockTimeout,
  getStoredUser,
  isBiometricLockEnabled,
  setBiometricLockEnabled as persistBiometricLock,
  setLockTimeout as persistLockTimeout,
  storeSession,
  type LockTimeout,
} from '@/auth/tokenStore';

type AuthStatus = 'loading' | 'signed-out' | 'signed-in';

interface AuthContextValue {
  status: AuthStatus;
  user: ApiUser | null;
  locked: boolean;
  biometricEnabled: boolean;
  lockTimeout: LockTimeout;
  signIn: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  signOut: () => Promise<void>;
  unlock: () => Promise<boolean>;
  enableBiometricLock: () => Promise<boolean>;
  disableBiometricLock: () => Promise<void>;
  updateLockTimeout: (timeout: LockTimeout) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function timeoutMilliseconds(timeout: LockTimeout): number {
  if (timeout === 'one-minute') return 60_000;
  if (timeout === 'five-minutes') return 5 * 60_000;
  return 0;
}

export function AuthProvider({ children }: PropsWithChildren): React.JSX.Element {
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<AuthStatus>('loading');
  const [user, setUser] = useState<ApiUser | null>(null);
  const [locked, setLocked] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [lockTimeout, setLockTimeout] = useState<LockTimeout>('immediately');
  const statusRef = useRef(status);
  const biometricRef = useRef(biometricEnabled);
  const timeoutRef = useRef(lockTimeout);
  const backgroundedAt = useRef<number | null>(null);

  useEffect(() => { statusRef.current = status; }, [status]);
  useEffect(() => { biometricRef.current = biometricEnabled; }, [biometricEnabled]);
  useEffect(() => { timeoutRef.current = lockTimeout; }, [lockTimeout]);

  const expireSession = useCallback(async () => {
    await clearSession();
    setUser(null);
    setStatus('signed-out');
    setLocked(false);
    queryClient.clear();
    await clearSecureCache().catch(() => undefined);
  }, [queryClient]);

  useEffect(() => registerUnauthorizedHandler(expireSession), [expireSession]);

  useEffect(() => {
    let mounted = true;
    const restore = async (): Promise<void> => {
      try {
        const [token, storedUser, biometric, timeout] = await Promise.all([
          getAccessToken(),
          getStoredUser(),
          isBiometricLockEnabled(),
          getLockTimeout(),
        ]);
        if (!mounted) return;
        setBiometricEnabled(biometric);
        setLockTimeout(timeout);
        if (!token) {
          setStatus('signed-out');
          return;
        }
        setUser(storedUser);
        setStatus('signed-in');
        setLocked(biometric);
      } catch {
        if (mounted) setStatus('signed-out');
      }
    };
    void restore();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    if (status !== 'signed-in' || locked) return;
    let active = true;
    // Do not send the stored bearer token to the API until an enabled biometric lock has been cleared.
    void authApi.me().then(async (currentUser) => {
      if (!active) return;
      setUser(currentUser);
      const token = await getAccessToken();
      if (active && token) await storeSession(token, currentUser);
    }).catch(() => undefined);
    return () => { active = false; };
  }, [locked, status]);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextState: AppStateStatus) => {
      if (nextState !== 'active') {
        if (statusRef.current === 'signed-in') backgroundedAt.current = Date.now();
        return;
      }
      if (statusRef.current !== 'signed-in' || !biometricRef.current) return;
      const startedAt = backgroundedAt.current;
      backgroundedAt.current = null;
      const timeout = timeoutMilliseconds(timeoutRef.current);
      if (startedAt !== null && Date.now() - startedAt >= timeout) setLocked(true);
    });
    return () => subscription.remove();
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const response = await authApi.login(email.trim(), password);
    await storeSession(response.token, response.user);
    setUser(response.user);
    setStatus('signed-in');
    setLocked(false);
    queryClient.clear();
  }, [queryClient]);

  const register = useCallback(async (email: string, password: string, name: string) => {
    const response = await authApi.register(email.trim(), password, name.trim());
    await storeSession(response.token, response.user);
    setUser(response.user);
    setStatus('signed-in');
    setLocked(false);
    queryClient.clear();
  }, [queryClient]);

  const signOut = useCallback(async () => {
    await expireSession();
  }, [expireSession]);

  const unlock = useCallback(async (): Promise<boolean> => {
    const authenticated = await loginWithBiometrics('Unlock FIFO Wealth OS');
    if (authenticated) setLocked(false);
    return authenticated;
  }, []);

  const enableBiometricLock = useCallback(async (): Promise<boolean> => {
    const authenticated = await loginWithBiometrics('Confirm biometrics to enable app lock');
    if (!authenticated) return false;
    await persistBiometricLock(true);
    setBiometricEnabled(true);
    setLocked(false);
    return true;
  }, []);

  const disableBiometricLock = useCallback(async (): Promise<void> => {
    await persistBiometricLock(false);
    setBiometricEnabled(false);
    setLocked(false);
  }, []);

  const updateLockTimeout = useCallback(async (timeout: LockTimeout): Promise<void> => {
    await persistLockTimeout(timeout);
    setLockTimeout(timeout);
  }, []);

  const refreshProfile = useCallback(async (): Promise<void> => {
    const currentUser = await authApi.me();
    setUser(currentUser);
    const token = await getAccessToken();
    if (token) await storeSession(token, currentUser);
  }, []);

  const value = useMemo<AuthContextValue>(() => ({
    status,
    user,
    locked,
    biometricEnabled,
    lockTimeout,
    signIn,
    register,
    signOut,
    unlock,
    enableBiometricLock,
    disableBiometricLock,
    updateLockTimeout,
    refreshProfile,
  }), [
    status,
    user,
    locked,
    biometricEnabled,
    lockTimeout,
    signIn,
    register,
    signOut,
    unlock,
    enableBiometricLock,
    disableBiometricLock,
    updateLockTimeout,
    refreshProfile,
  ]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside AuthProvider.');
  return context;
}
