import type { ManualTransactionDraft } from '@fifo/types';
import { toLocalDateString, validateQuickAddDraft } from '@/features/transactions/validation';

const validDraft: ManualTransactionDraft = {
  portfolioId: 'portfolio-1',
  symbol: 'aapl',
  type: 'BUY',
  qty: '0.000000000000123456789',
  price: '198.1234567890123456789',
  date: '2026-10-29',
};

describe('Quick Add transaction validation', () => {
  it('accepts positive high-precision decimal strings without converting them to JavaScript numbers', () => {
    expect(validateQuickAddDraft(validDraft)).toEqual({});
  });

  it('requires a portfolio, valid symbol, positive quantity and price, and a real ISO calendar date', () => {
    const errors = validateQuickAddDraft({
      portfolioId: ' ',
      symbol: 'bad ticker!',
      type: 'SELL',
      qty: '0',
      price: '-5',
      date: '2026-02-30',
    });

    expect(errors).toMatchObject({
      portfolioId: 'Select a portfolio.',
      symbol: 'Enter a valid ticker symbol (up to 20 letters, numbers, dots, or hyphens).',
      qty: 'Quantity must be a positive decimal.',
      price: 'Price must be a positive decimal.',
      date: 'Choose a valid trade date.',
    });
  });

  it('rejects malformed decimal input', () => {
    expect(validateQuickAddDraft({ ...validDraft, qty: 'one share' }).qty)
      .toBe('Quantity must be a positive decimal.');
    expect(validateQuickAddDraft({ ...validDraft, price: 'NaN' }).price)
      .toBe('Price must be a positive decimal.');
  });

  it('formats local calendar dates without a UTC day shift', () => {
    const date = new Date(2026, 9, 29, 0, 15);
    expect(toLocalDateString(date)).toBe('2026-10-29');
  });
});
