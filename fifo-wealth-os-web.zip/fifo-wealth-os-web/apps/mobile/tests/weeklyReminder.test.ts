import * as Notifications from 'expo-notifications';
import { getWeeklyReminderId, isWeeklyReminderEnabled, setWeeklyReminder } from '@/auth/tokenStore';
import {
  disableWeeklySummaryReminder,
  enableWeeklySummaryReminder,
  migrateWeeklySummaryReminder,
  WEEKLY_SUMMARY_NOTIFICATION_BODY,
} from '@/features/settings/reminders';

jest.mock('expo-notifications', () => ({
  AndroidImportance: { DEFAULT: 3 },
  SchedulableTriggerInputTypes: { WEEKLY: 'weekly' },
  cancelScheduledNotificationAsync: jest.fn(),
  getPermissionsAsync: jest.fn(),
  requestPermissionsAsync: jest.fn(),
  scheduleNotificationAsync: jest.fn(),
  setNotificationChannelAsync: jest.fn(),
  setNotificationHandler: jest.fn(),
}));

jest.mock('@/auth/tokenStore', () => ({
  getWeeklyReminderId: jest.fn(),
  isWeeklyReminderEnabled: jest.fn(),
  setWeeklyReminder: jest.fn(),
}));

const grantedPermission = { granted: true } as Notifications.NotificationPermissionsStatus;
const deniedPermission = { granted: false } as Notifications.NotificationPermissionsStatus;

beforeEach(() => {
  jest.mocked(Notifications.getPermissionsAsync).mockResolvedValue(grantedPermission);
  jest.mocked(Notifications.requestPermissionsAsync).mockResolvedValue(grantedPermission);
  jest.mocked(Notifications.cancelScheduledNotificationAsync).mockResolvedValue(undefined);
  jest.mocked(Notifications.scheduleNotificationAsync).mockResolvedValue('new-weekly-id');
  jest.mocked(getWeeklyReminderId).mockResolvedValue('old-weekly-id');
  jest.mocked(isWeeklyReminderEnabled).mockResolvedValue(true);
  jest.mocked(setWeeklyReminder).mockResolvedValue(undefined);
});

describe('weekly wealth summary reminder', () => {
  it('requests permission when needed and does not schedule when permission is denied', async () => {
    jest.mocked(Notifications.getPermissionsAsync).mockResolvedValue(deniedPermission);
    jest.mocked(Notifications.requestPermissionsAsync).mockResolvedValue(deniedPermission);

    await expect(enableWeeklySummaryReminder()).resolves.toBe(false);
    expect(Notifications.requestPermissionsAsync).toHaveBeenCalledTimes(1);
    expect(Notifications.scheduleNotificationAsync).not.toHaveBeenCalled();
  });

  it('replaces the existing reminder with one Monday 9 AM local schedule', async () => {
    await expect(enableWeeklySummaryReminder()).resolves.toBe(true);

    expect(Notifications.cancelScheduledNotificationAsync).toHaveBeenCalledWith('old-weekly-id');
    expect(Notifications.scheduleNotificationAsync).toHaveBeenCalledTimes(1);
    expect(Notifications.scheduleNotificationAsync).toHaveBeenCalledWith({
      content: {
        title: 'Weekly Wealth Summary',
        body: WEEKLY_SUMMARY_NOTIFICATION_BODY,
        data: { route: '/(app)/(tabs)' },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
        weekday: 2,
        hour: 9,
        minute: 0,
        channelId: 'wealth-reminders',
      },
    });
    expect(setWeeklyReminder).toHaveBeenCalledWith(true, 'new-weekly-id');
  });

  it('migrates an enabled legacy reminder in place without prompting again', async () => {
    await migrateWeeklySummaryReminder();

    expect(Notifications.requestPermissionsAsync).not.toHaveBeenCalled();
    expect(Notifications.cancelScheduledNotificationAsync).toHaveBeenCalledWith('old-weekly-id');
    expect(Notifications.scheduleNotificationAsync).toHaveBeenCalledTimes(1);
    expect(setWeeklyReminder).toHaveBeenCalledWith(true, 'new-weekly-id');
  });

  it('cancels the scheduled reminder when disabled', async () => {
    await disableWeeklySummaryReminder();

    expect(Notifications.cancelScheduledNotificationAsync).toHaveBeenCalledWith('old-weekly-id');
    expect(setWeeklyReminder).toHaveBeenCalledWith(false);
  });
});
