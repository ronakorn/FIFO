import { render } from '@testing-library/react-native';
import { Text, View } from 'react-native';
import type { Portfolio, Transaction } from '@/api/types';
import { PortfolioListItem } from '@/components/PortfolioListItem';
import { PortfolioTransactionRow, type PortfolioLedgerEntry } from '@/components/PortfolioTransactionRow';

jest.mock('lucide-react-native', () => ({
  CheckCircle2: () => null,
  Clock3: () => null,
  CloudOff: () => null,
}));

jest.mock('@/theme/ThemeProvider', () => ({
  useTheme: () => ({ colors: { gain: '#21734B', gold: '#8A6410', ink: '#14342A' } }),
}));

describe('memoized list rows', () => {
  it('does not re-render a portfolio row for an unrelated parent update', () => {
    let nameReads = 0;
    const portfolio = {
      id: 'portfolio-1',
      userId: 'user-1',
      get name() {
        nameReads += 1;
        return 'Long-term wealth';
      },
      baseCurrency: 'THB',
      createdAt: '2025-01-01T00:00:00.000Z',
      transactionCount: 12,
    } as Portfolio;
    const onPress = jest.fn();
    const view = (parentLabel: string) => (
      <View>
        <PortfolioListItem portfolio={portfolio} onPress={onPress} />
        <Text>{parentLabel}</Text>
      </View>
    );
    const { rerender } = render(view('first parent state'));
    const initialNameReads = nameReads;

    rerender(view('unrelated parent state changed'));

    expect(initialNameReads).toBeGreaterThan(0);
    expect(nameReads).toBe(initialNameReads);
  });

  it('does not re-render a transaction row for an unrelated parent update', () => {
    let symbolReads = 0;
    const transaction = {
      id: 'server-1',
      portfolioId: 'portfolio-1',
      date: '2025-02-05T00:00:00.000Z',
      get symbol() {
        symbolReads += 1;
        return 'PTT';
      },
      type: 'BUY',
      qty: 3,
      price: 32.5,
      gross: '97.50',
      comm: '0.00',
      vat: '0.00',
      net: '97.50',
      originalCurrency: 'THB',
      fxRate: null,
      netTHB: '97.50',
    } as Transaction;
    const entry: PortfolioLedgerEntry = { status: 'confirmed', transaction };
    const view = (parentLabel: string) => (
      <View>
        <PortfolioTransactionRow entry={entry} />
        <Text>{parentLabel}</Text>
      </View>
    );
    const { rerender } = render(view('first parent state'));
    const initialSymbolReads = symbolReads;

    rerender(view('unrelated parent state changed'));

    expect(initialSymbolReads).toBeGreaterThan(0);
    expect(symbolReads).toBe(initialSymbolReads);
  });
});
