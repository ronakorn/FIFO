import { getThemeColors, type AppColorScheme, type ThemeColors } from '@/theme/colors';

function luminance(hex: string): number {
  const channels = [0, 2, 4].map((offset) => Number.parseInt(hex.slice(offset + 1, offset + 3), 16) / 255);
  const linear = channels.map((channel) => channel <= 0.04045
    ? channel / 12.92
    : ((channel + 0.055) / 1.055) ** 2.4);
  return 0.2126 * (linear[0] ?? 0) + 0.7152 * (linear[1] ?? 0) + 0.0722 * (linear[2] ?? 0);
}

function contrastRatio(foreground: string, background: string): number {
  const sorted = [luminance(foreground), luminance(background)].sort((left, right) => right - left);
  const lighter = sorted[0] ?? 0;
  const darker = sorted[1] ?? 0;
  return (lighter + 0.05) / (darker + 0.05);
}

function composite(foreground: string, background: string, alpha: number): string {
  const channels = [0, 2, 4].map((offset) => {
    const front = Number.parseInt(foreground.slice(offset + 1, offset + 3), 16);
    const back = Number.parseInt(background.slice(offset + 1, offset + 3), 16);
    return Math.round(front * alpha + back * (1 - alpha)).toString(16).padStart(2, '0');
  });
  return `#${channels.join('')}`;
}

const TEXT_COLORS: (keyof ThemeColors)[] = ['ink', 'muted', 'accentBright', 'gain', 'loss', 'gold'];
const SURFACES: (keyof ThemeColors)[] = ['midnight', 'surface', 'raised'];

describe('Light and Dark text contrast', () => {
  it.each<AppColorScheme>(['light', 'dark'])('keeps primary and semantic text legible in %s mode', (scheme) => {
    const colors = getThemeColors(scheme);
    for (const foreground of TEXT_COLORS) {
      for (const background of SURFACES) {
        expect(contrastRatio(colors[foreground], colors[background])).toBeGreaterThanOrEqual(4.5);
      }
    }
    expect(contrastRatio('#FFFFFF', colors.accent)).toBeGreaterThanOrEqual(4.5);
  });

  it.each<AppColorScheme>(['light', 'dark'])('keeps tinted badge text legible in %s mode', (scheme) => {
    const colors = getThemeColors(scheme);
    const tintPairs = [
      [colors.accentBright, colors.accent, 0.15],
      [colors.gain, colors.gain, 0.1],
      [colors.loss, colors.loss, 0.1],
      [colors.gold, colors.gold, 0.1],
    ] as const;
    for (const [foreground, tint, alpha] of tintPairs) {
      const background = composite(tint, colors.surface, alpha);
      expect(contrastRatio(foreground, background)).toBeGreaterThanOrEqual(4.5);
    }
  });
});
