import { render, screen } from '@testing-library/react-native';
import type { PendingManualTransaction } from '@fifo/types';
import type { Transaction } from '@/api/types';
import { PortfolioTransactionRow } from '@/components/PortfolioTransactionRow';

jest.mock('lucide-react-native', () => ({
  CheckCircle2: () => null,
  Clock3: () => null,
  CloudOff: () => null,
}));

jest.mock('@/theme/ThemeProvider', () => ({
  useTheme: () => ({
    colors: { gain: '#21734B', gold: '#927120', ink: '#14342A' },
  }),
}));

const queuedTransaction: PendingManualTransaction = {
  id: 'local-1',
  portfolioId: 'portfolio-1',
  symbol: 'AOT',
  type: 'BUY',
  qty: '2.500000000000000001',
  price: '61.25',
  date: '2025-02-06',
  createdAt: '2025-02-06T07:00:00.000Z',
  syncStatus: 'queued',
};

const confirmedTransaction: Transaction = {
  id: 'server-1',
  portfolioId: 'portfolio-1',
  date: '2025-02-05T00:00:00.000Z',
  symbol: 'PTT',
  type: 'BUY',
  qty: 3,
  price: 32.5,
  gross: '97.50',
  comm: '0.00',
  vat: '0.00',
  net: '97.50',
  originalCurrency: 'THB',
  fxRate: null,
  netTHB: '97.50',
};

describe('portfolio transaction ledger rows', () => {
  it('marks queued manual entries as local-only, not synced', () => {
    render(<PortfolioTransactionRow entry={{ status: 'queued', transaction: queuedTransaction }} />);

    expect(screen.getByLabelText('Queued locally; not synced')).toBeTruthy();
    expect(screen.getByText('Queued')).toBeTruthy();
    expect(screen.getByText('Local only')).toBeTruthy();
    expect(screen.getByText('2.500000 @ 61.25 THB')).toBeTruthy();
  });

  it('marks server transactions as confirmed', () => {
    render(<PortfolioTransactionRow entry={{ status: 'confirmed', transaction: confirmedTransaction }} />);

    expect(screen.getByLabelText('Confirmed on server')).toBeTruthy();
    expect(screen.getByText('Confirmed')).toBeTruthy();
    expect(screen.queryByText('Local only')).toBeNull();
    expect(screen.getByText('฿97.50')).toBeTruthy();
  });
});
