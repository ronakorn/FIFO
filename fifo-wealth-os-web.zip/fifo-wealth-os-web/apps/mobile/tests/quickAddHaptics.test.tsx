import { fireEvent, render, screen, waitFor } from '@testing-library/react-native';
import type { Portfolio } from '@/api/types';
import * as Haptics from 'expo-haptics';
import { Alert } from 'react-native';
import { QuickAddTransaction } from '@/components/QuickAddTransaction';

jest.mock('@react-native-community/netinfo', () => ({
  useNetInfo: () => ({ isConnected: true, isInternetReachable: true }),
}));
jest.mock('@react-native-community/datetimepicker', () => ({ __esModule: true, default: () => null }));
jest.mock('expo-crypto', () => ({ randomUUID: () => 'test-id' }));
jest.mock('expo-haptics', () => ({
  notificationAsync: jest.fn(() => Promise.resolve()),
  impactAsync: jest.fn(() => Promise.resolve()),
  NotificationFeedbackType: { Success: 'success', Warning: 'warning' },
  ImpactFeedbackStyle: { Light: 'light' },
}));
jest.mock('lucide-react-native', () => ({ Plus: () => null, X: () => null }));
jest.mock('react-native-safe-area-context', () => ({
  useSafeAreaInsets: () => ({ top: 0, right: 0, bottom: 0, left: 0 }),
}));
jest.mock('@/hooks/usePendingManualTransactions', () => ({
  usePendingManualTransactions: () => ({ addPendingTransaction: jest.fn(async () => ({ persisted: true })) }),
}));
jest.mock('@/theme/ThemeProvider', () => ({
  useTheme: () => ({ colors: { muted: '#586B62', accentBright: '#285B48', gold: '#8A6410' } }),
}));

const portfolio: Portfolio = {
  id: 'portfolio-1',
  userId: 'user-1',
  name: 'Long-term wealth',
  baseCurrency: 'THB',
  createdAt: '2025-01-01T00:00:00.000Z',
};

describe('Quick Add form haptics', () => {
  it('warns when an invalid local trade submission is attempted', () => {
    render(<QuickAddTransaction portfolios={[portfolio]} />);

    fireEvent.press(screen.getByRole('button', { name: 'Quick add transaction' }));
    const submit = screen.getByRole('button', { name: 'Save trade to local queue' });
    expect(submit.props.accessibilityState.disabled).toBe(false);
    fireEvent.press(submit);

    expect(Haptics.notificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Warning);
    expect(screen.getByText(/Review the highlighted fields/)).toBeTruthy();
  });

  it('uses success feedback after a valid trade is saved to the local queue', async () => {
    jest.spyOn(Alert, 'alert').mockImplementation(() => undefined);
    render(<QuickAddTransaction portfolios={[portfolio]} />);
    fireEvent.press(screen.getByRole('button', { name: 'Quick add transaction' }));
    fireEvent.changeText(screen.getByLabelText('Symbol'), 'AAPL');
    fireEvent.changeText(screen.getByLabelText('Quantity'), '2');
    fireEvent.changeText(screen.getByLabelText('Price per unit'), '198.12');
    fireEvent.press(screen.getByRole('button', { name: 'Save trade to local queue' }));

    await waitFor(() => {
      expect(Haptics.notificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Success);
    });
  });
});
