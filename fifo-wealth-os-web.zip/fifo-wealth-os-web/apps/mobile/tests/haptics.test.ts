import * as Haptics from 'expo-haptics';
import { hapticRefresh, hapticSuccess, hapticWarning } from '@/lib/haptics';

jest.mock('expo-haptics', () => ({
  notificationAsync: jest.fn(() => Promise.resolve()),
  impactAsync: jest.fn(() => Promise.resolve()),
  NotificationFeedbackType: { Success: 'success', Warning: 'warning' },
  ImpactFeedbackStyle: { Light: 'light' },
}));

describe('mobile haptics', () => {
  it('uses subtle success feedback after a trade is queued', () => {
    hapticSuccess();
    expect(Haptics.notificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Success);
  });

  it('uses warning feedback for an invalid form submission', () => {
    hapticWarning();
    expect(Haptics.notificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Warning);
  });

  it('uses light impact feedback for pull-to-refresh', () => {
    hapticRefresh();
    expect(Haptics.impactAsync).toHaveBeenCalledWith(Haptics.ImpactFeedbackStyle.Light);
  });
});
