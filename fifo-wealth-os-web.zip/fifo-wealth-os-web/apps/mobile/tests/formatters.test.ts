import {
  formatDate,
  formatDateTime,
  formatNumber,
  formatPercentRatio,
  formatThb,
  toChartNumber,
} from '@/lib/formatters';

describe('financial display formatters', () => {
  it('rounds THB only for display and groups large values', () => {
    expect(formatThb('1234567.895')).toBe('฿1,234,567.90');
    expect(formatThb('-12.345')).toBe('฿-12.35');
  });

  it('preserves the requested precision for quantity display', () => {
    expect(formatNumber('0.000000006', 8)).toBe('0.00000001');
    expect(formatNumber('1200000', 0)).toBe('1,200,000');
  });

  it('converts decimal ratios to percent labels', () => {
    expect(formatPercentRatio('0.012345')).toBe('1.23%');
    expect(formatPercentRatio('-0.25')).toBe('-25.00%');
  });

  it('returns a safe placeholder for missing or invalid monetary values', () => {
    expect(formatThb(null)).toBe('—');
    expect(formatThb(undefined)).toBe('—');
    expect(formatThb('not-a-number')).toBe('—');
  });

  it('creates finite numeric chart coordinates from decimal strings', () => {
    expect(toChartNumber('123456789.123456789')).toBeCloseTo(123456789.12345679);
    expect(toChartNumber('Infinity')).toBe(0);
  });

  it('returns an invalid date unchanged instead of masking the source value', () => {
    expect(formatDate('invalid-date')).toBe('invalid-date');
  });

  it('formats cache timestamps with both date and local time', () => {
    expect(formatDateTime('invalid-date')).toBe('—');
    expect(formatDateTime('2026-10-29T02:00:00.000Z')).toMatch(/\d{1,2}:\d{2}/);
  });
});
