import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';
import { clearSession, getSession, loginWithBiometrics, saveSession } from '@/lib/auth';

jest.mock('expo-local-authentication', () => ({
  hasHardwareAsync: jest.fn(),
  isEnrolledAsync: jest.fn(),
  authenticateAsync: jest.fn(),
}));

jest.mock('expo-secure-store', () => ({
  AFTER_FIRST_UNLOCK: 1,
  getItemAsync: jest.fn(),
  setItemAsync: jest.fn(),
  deleteItemAsync: jest.fn(),
}));

const localAuth = jest.mocked(LocalAuthentication);
const secureStore = jest.mocked(SecureStore);
const ACCESS_TOKEN_KEY = 'fifo.mobile.access-token.v1';

describe('mobile secure authentication helpers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    secureStore.getItemAsync.mockResolvedValue(null);
    secureStore.setItemAsync.mockResolvedValue(undefined);
    secureStore.deleteItemAsync.mockResolvedValue(undefined);
    localAuth.hasHardwareAsync.mockResolvedValue(true);
    localAuth.isEnrolledAsync.mockResolvedValue(true);
    localAuth.authenticateAsync.mockResolvedValue({ success: true });
  });

  it('saves an issued access token in SecureStore with protected keychain accessibility', async () => {
    await saveSession('issued-jwt');

    expect(secureStore.setItemAsync).toHaveBeenCalledWith(ACCESS_TOKEN_KEY, 'issued-jwt', {
      keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK,
    });
  });

  it('rejects empty access tokens rather than persisting an invalid session', async () => {
    await expect(saveSession('   ')).rejects.toThrow('Cannot save an empty access token.');
    expect(secureStore.setItemAsync).not.toHaveBeenCalled();
  });

  it('retrieves and clears the access token from SecureStore', async () => {
    secureStore.getItemAsync.mockResolvedValue('issued-jwt');
    await expect(getSession()).resolves.toBe('issued-jwt');

    await clearSession();
    expect(secureStore.deleteItemAsync).toHaveBeenCalledWith(ACCESS_TOKEN_KEY);
  });

  it('prompts for biometrics only when hardware and an enrollment are available', async () => {
    await expect(loginWithBiometrics('Unlock FIFO Wealth OS')).resolves.toBe(true);

    expect(localAuth.hasHardwareAsync).toHaveBeenCalledTimes(1);
    expect(localAuth.isEnrolledAsync).toHaveBeenCalledTimes(1);
    expect(localAuth.authenticateAsync).toHaveBeenCalledWith({
      promptMessage: 'Unlock FIFO Wealth OS',
      cancelLabel: 'Cancel',
      disableDeviceFallback: false,
    });
  });

  it('fails closed without opening a prompt when biometric hardware is unavailable', async () => {
    localAuth.hasHardwareAsync.mockResolvedValue(false);

    await expect(loginWithBiometrics()).resolves.toBe(false);
    expect(localAuth.authenticateAsync).not.toHaveBeenCalled();
  });

  it('fails closed when no biometric is enrolled', async () => {
    localAuth.isEnrolledAsync.mockResolvedValue(false);

    await expect(loginWithBiometrics()).resolves.toBe(false);
    expect(localAuth.authenticateAsync).not.toHaveBeenCalled();
  });

  it('returns false when the user cancels or does not authenticate', async () => {
    localAuth.authenticateAsync.mockResolvedValue({ success: false, error: 'user_cancel' });

    await expect(loginWithBiometrics()).resolves.toBe(false);
  });
});
