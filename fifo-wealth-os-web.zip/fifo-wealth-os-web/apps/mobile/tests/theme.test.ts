import { getThemeColors } from '@/theme/colors';

describe('mobile design system', () => {
  it('uses the premium minimalist brand colors in light mode', () => {
    const colors = getThemeColors('light');

    expect(colors.ink).toBe('#14342A');
    expect(colors.accent).toBe('#14342A');
    expect(colors.midnight).toBe('#FAFAFA');
    expect(colors.surface).toBe('#FFFFFF');
    expect(colors.loss).toBe('#B42332');
  });

  it('uses the requested charcoal and off-white colors in dark mode', () => {
    const colors = getThemeColors('dark');

    expect(colors.midnight).toBe('#121212');
    expect(colors.ink).toBe('#FAFAFA');
    expect(colors.accent).toBe('#14342A');
    expect(colors.loss).toBe('#F17878');
  });
});
