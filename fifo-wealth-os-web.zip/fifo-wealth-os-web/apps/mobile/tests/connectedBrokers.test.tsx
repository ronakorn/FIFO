import { fireEvent, render, screen } from '@testing-library/react-native';
import type { IbkrConnection, ThaiBrokerConnection } from '@fifo/types';
import { ConnectedBrokers } from '@/components/ConnectedBrokers';

const ibkrConnection: IbkrConnection = {
  id: 'ibkr-connection',
  brokerName: 'IBKR',
  flexQueryId: '12345',
  portfolioId: 'portfolio-1',
  status: 'CONNECTED',
  connected: true,
  lastSyncedAt: '2025-01-03T09:15:00.000Z',
  createdAt: '2025-01-01T00:00:00.000Z',
  readOnly: true,
  encryption: 'AES-256-GCM',
};

const bitkubConnection: ThaiBrokerConnection = {
  id: 'thai-connection',
  broker: 'BITKUB',
  displayName: 'Bitkub',
  regulatoryBadge: 'Sample badge',
  partnerBadge: 'Official Partner Integration Ready',
  connectionMode: 'READ_ONLY_API',
  dataSource: 'NOT_TESTED',
  maskedAccountRef: null,
  portfolioId: 'portfolio-1',
  status: 'SYNCING',
  connected: true,
  readOnly: true,
  encryption: 'AES-256-GCM',
  pdpaConsented: true,
  pdpaConsentedAt: '2025-01-01T00:00:00.000Z',
  pdpaConsentVersion: 'v1',
  lastSyncedAt: null,
  futureRoadmapNote: null,
};

describe('ConnectedBrokers', () => {
  it('renders broker names, color-coded states, last-sync data, and supported actions', () => {
    const onSync = jest.fn();
    const onDisconnect = jest.fn();
    render(
      <ConnectedBrokers
        ibkr={ibkrConnection}
        thaiConnections={[bitkubConnection]}
        ibkrLoading={false}
        thaiLoading={false}
        onSync={onSync}
        onDisconnect={onDisconnect}
      />,
    );

    expect(screen.getByText('Interactive Brokers')).toBeTruthy();
    expect(screen.getByText('Bitkub')).toBeTruthy();
    expect(screen.getByText('Dime')).toBeTruthy();
    expect(screen.getByText('Streaming')).toBeTruthy();
    expect(screen.getByText('Connected')).toBeTruthy();
    expect(screen.getByText('Syncing')).toBeTruthy();
    expect(screen.getAllByText('Disconnected')).toHaveLength(2);
    expect(screen.getAllByText(/Last synced/)).toHaveLength(4);

    fireEvent.press(screen.getByRole('button', { name: 'Sync Interactive Brokers' }));
    fireEvent.press(screen.getByRole('button', { name: 'Disconnect Bitkub' }));

    expect(onSync).toHaveBeenCalledWith('IBKR');
    expect(onDisconnect).toHaveBeenCalledWith('BITKUB');
    expect(screen.queryByRole('button', { name: 'Sync Dime' })).toBeNull();
  });

  it('shows loading and unavailable states without implying brokers are disconnected', () => {
    const { rerender } = render(
      <ConnectedBrokers
        ibkr={undefined}
        thaiConnections={undefined}
        ibkrLoading
        thaiLoading
        onSync={jest.fn()}
        onDisconnect={jest.fn()}
      />,
    );
    expect(screen.getAllByText('Loading')).toHaveLength(4);
    expect(screen.queryByText('Disconnected')).toBeNull();

    rerender(
      <ConnectedBrokers
        ibkr={undefined}
        thaiConnections={undefined}
        ibkrLoading={false}
        thaiLoading={false}
        ibkrUnavailable
        thaiUnavailable
        onSync={jest.fn()}
        onDisconnect={jest.fn()}
      />,
    );
    expect(screen.getAllByText('Unavailable')).toHaveLength(4);
    expect(screen.queryByText('Disconnected')).toBeNull();
  });
});
