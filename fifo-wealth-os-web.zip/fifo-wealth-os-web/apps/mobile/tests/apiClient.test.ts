import {
  AxiosError,
  AxiosHeaders,
  type AxiosAdapter,
  type AxiosResponse,
} from 'axios';
import { createAuthenticatedApiClient } from '@fifo/api';
import { getApiErrorMessage } from '@/api/client';

jest.mock('@/auth/tokenStore', () => ({ getAccessToken: jest.fn() }));

function statusErrorAdapter(status: number, message: string): AxiosAdapter {
  return async (config) => {
    const response: AxiosResponse<unknown> = {
      data: { error: { message } },
      status,
      statusText: status === 401 ? 'Unauthorized' : 'Forbidden',
      headers: new AxiosHeaders(),
      config,
    };
    throw new AxiosError<unknown>(
      `Request failed with status ${status}`,
      'ERR_BAD_REQUEST',
      config,
      undefined,
      response,
    );
  };
}

function createClient(token: string | null) {
  return createAuthenticatedApiClient({
    baseURL: 'https://api.example.test/api',
    timeoutMs: 20_000,
    getAccessToken: async () => token,
  });
}

describe('mobile API authentication and recoverable errors', () => {
  it('sends the issued access token as a bearer credential', async () => {
    const { client } = createClient('issued-access-token');
    let authorization: string | undefined;
    const adapter: AxiosAdapter = async (config) => {
      const header = config.headers.get('Authorization');
      authorization = typeof header === 'string' ? header : undefined;
      const response: AxiosResponse<unknown> = {
        data: { ok: true },
        status: 200,
        statusText: 'OK',
        headers: new AxiosHeaders(),
        config,
      };
      return response;
    };

    await client.get('/private', { adapter });

    expect(authorization).toBe('Bearer issued-access-token');
  });

  it('expires a bearer-authenticated session on 401 but preserves it on 403', async () => {
    const { client, registerUnauthorizedHandler } = createClient('issued-access-token');
    const unauthorizedHandler = jest.fn(async () => undefined);
    registerUnauthorizedHandler(unauthorizedHandler);

    const forbiddenError = await client
      .get('/private', { adapter: statusErrorAdapter(403, 'Access is not permitted.') })
      .catch((error: unknown) => error);

    expect(getApiErrorMessage(forbiddenError)).toBe('Access is not permitted.');
    expect(unauthorizedHandler).not.toHaveBeenCalled();

    await expect(
      client.get('/private', { adapter: statusErrorAdapter(401, 'Session expired.') }),
    ).rejects.toBeInstanceOf(AxiosError);
    expect(unauthorizedHandler).toHaveBeenCalledTimes(1);
  });

  it('does not expire a session for an unauthenticated 401 response', async () => {
    const { client, registerUnauthorizedHandler } = createClient(null);
    const unauthorizedHandler = jest.fn(async () => undefined);
    registerUnauthorizedHandler(unauthorizedHandler);

    await expect(
      client.post('/auth/login', {}, { adapter: statusErrorAdapter(401, 'Invalid credentials.') }),
    ).rejects.toBeInstanceOf(AxiosError);

    expect(unauthorizedHandler).not.toHaveBeenCalled();
  });

  it('maps timeout and unreachable-network failures to actionable messages', () => {
    const timeout = new AxiosError<unknown>('Request timed out', 'ECONNABORTED');
    const offline = new AxiosError<unknown>('Network unavailable', 'ERR_NETWORK');

    expect(getApiErrorMessage(timeout)).toContain('request timed out');
    expect(getApiErrorMessage(offline)).toContain('Unable to reach FIFO Wealth OS');
  });
});
