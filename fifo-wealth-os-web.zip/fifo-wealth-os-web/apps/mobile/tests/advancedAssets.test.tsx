import { fireEvent, render, screen } from '@testing-library/react-native';
import { Linking } from 'react-native';
import { AdvancedAssetSummaryCard } from '@/components/AdvancedAssetSummaryCard';
import { ADVANCED_ASSET_SAMPLE_DATA } from '@/features/advancedAssets/sampleData';
import { formatAdvancedAssetMetric } from '@/features/advancedAssets/presentation';
import { getAdvancedAssetsWebUrl, openAdvancedAssetsWeb } from '@/features/advancedAssets/webLink';

jest.mock('@/theme/ThemeProvider', () => ({
  useTheme: () => ({
    colors: { gain: '#21734B', gold: '#927120', ink: '#14342A' },
  }),
}));

describe('Advanced Assets sample summary cards', () => {
  it('renders all four explicitly labeled sample metrics with shared decimal formatting', () => {
    const onViewWeb = jest.fn();
    render(
      <>
        {ADVANCED_ASSET_SAMPLE_DATA.map((summary) => (
          <AdvancedAssetSummaryCard key={summary.id} summary={summary} onViewWeb={onViewWeb} />
        ))}
      </>,
    );

    expect(screen.getByText('Options')).toBeTruthy();
    expect(screen.getByText('Net Delta')).toBeTruthy();
    expect(screen.getByText('+0.24')).toBeTruthy();
    expect(screen.getByText('REITs')).toBeTruthy();
    expect(screen.getByText('5.10%')).toBeTruthy();
    expect(screen.getByText('Private Equity')).toBeTruthy();
    expect(screen.getByText('1.42×')).toBeTruthy();
    expect(screen.getByText('Futures')).toBeTruthy();
    expect(screen.getByText('88.00%')).toBeTruthy();
    expect(screen.getAllByText('Sample Data')).toHaveLength(4);

    fireEvent.press(screen.getByRole('button', { name: 'View Options on Web' }));
    expect(onViewWeb).toHaveBeenCalledTimes(1);
    const optionsSummary = ADVANCED_ASSET_SAMPLE_DATA.find((summary) => summary.id === 'options');
    expect(optionsSummary).toBeDefined();
    if (optionsSummary) expect(formatAdvancedAssetMetric(optionsSummary)).toBe('+0.24');
  });

  it('builds the Thai-locale web path and opens it through Linking.openURL', async () => {
    expect(getAdvancedAssetsWebUrl('https://wealth.example/')).toBe('https://wealth.example/th/advanced-assets');
    expect(getAdvancedAssetsWebUrl('not a URL')).toBeNull();
    expect(getAdvancedAssetsWebUrl('javascript:alert(1)')).toBeNull();

    const openURL = jest.spyOn(Linking, 'openURL').mockResolvedValue(undefined);
    await expect(openAdvancedAssetsWeb('https://wealth.example')).resolves.toBe('opened');
    expect(openURL).toHaveBeenCalledWith('https://wealth.example/th/advanced-assets');
  });

  it('reports an unset web origin without attempting to open an invalid URL', async () => {
    const openURL = jest.spyOn(Linking, 'openURL').mockResolvedValue(undefined);
    await expect(openAdvancedAssetsWeb('')).resolves.toBe('not-configured');
    expect(openURL).not.toHaveBeenCalled();
  });
});
