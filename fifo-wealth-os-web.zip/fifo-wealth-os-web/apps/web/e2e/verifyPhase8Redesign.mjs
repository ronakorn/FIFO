import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const OUTPUT_DIRS = [
  '/home/user/screenshots',
  '/home/user',
];

function parseRgb(rgbStr) {
  const m = rgbStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (!m) return null;
  return [Number(m[1]), Number(m[2]), Number(m[3])];
}

function relativeLuminance([r, g, b]) {
  const toLinear = (c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
}

function contrastRatio(rgb1, rgb2) {
  const l1 = relativeLuminance(rgb1);
  const l2 = relativeLuminance(rgb2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

function saveToAllTargets(filename, buffer) {
  for (const dir of OUTPUT_DIRS) {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, filename), buffer);
  }
}

async function dismissOnboardingIfOpen(page) {
  const modal = page.locator('[data-testid="onboarding-modal"]');
  if (await modal.isVisible().catch(() => false)) {
    await page.locator('[data-testid="onboarding-skip-btn"]').click();
    await modal.waitFor({ state: 'hidden', timeout: 10000 });
  }
}

async function runPhase8Verification() {
  const consoleErrors = [];
  const browser = await chromium.launch({ headless: true });

  try {
    // =========================================================================
    // 1. Desktop Context (1440 x 960) — Login, Light Mode, Dark Mode, Tax Report
    // =========================================================================
    const desktopCtx = await browser.newContext({
      viewport: { width: 1440, height: 960 },
      deviceScaleFactor: 1,
    });
    const page = await desktopCtx.newPage();
    page.on('pageerror', (err) => consoleErrors.push(`PAGEERROR: ${err.message}`));

    // Sign in with real Demo Investor account
    await page.goto(`${BASE_URL}/login`, { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForSelector('#login-email', { timeout: 30000 });
    await Promise.all([
      page.waitForURL(new RegExp(`^${BASE_URL}/(?:th/?)?$`), { timeout: 45000 }),
      page.click('button[type="submit"]'),
    ]);

    // Wait for Dashboard + Quant Engine + Portfolios to load completely
    await page.waitForSelector('[data-testid="hero-portfolio-value"]', { timeout: 30000 });
    await page.waitForSelector('text=XIRR (Money-Weighted)', { timeout: 30000 });
    await page.waitForSelector('text=ประสิทธิภาพพอร์ตเทียบดัชนีตลาด', { timeout: 30000 });
    await page.waitForSelector('text=สัดส่วนกลุ่มสินทรัพย์', { timeout: 30000 });
    await page.waitForTimeout(800);
    await dismissOnboardingIfOpen(page);

    // Ensure Light Mode is active first
    await page.evaluate(() => {
      document.documentElement.classList.remove('dark');
      window.localStorage.setItem('theme', 'light');
    });
    await page.reload({ waitUntil: 'networkidle', timeout: 45000 });
    await page.waitForSelector('[data-testid="hero-portfolio-value"]', { timeout: 30000 });
    await page.waitForSelector('text=XIRR (Money-Weighted)', { timeout: 30000 });
    await page.waitForTimeout(600);

    // Desktop Audit: BottomNav must be hidden on Desktop (>= 768px)
    const desktopBottomNavVisible = await page
      .locator('[data-testid="mobile-bottom-nav"]')
      .isVisible();
    if (desktopBottomNavVisible) {
      throw new Error('BottomNav should be hidden on Desktop (>= 768px)!');
    }

    // Light Mode WCAG AA Contrast Audit
    const lightStyles = await page.evaluate(() => {
      const bodyBg = getComputedStyle(document.body).backgroundColor;
      const heroEl = document.querySelector('[data-testid="hero-portfolio-value"]');
      const cardEl = heroEl?.closest('div.rounded-2xl');
      const primaryBtn = document.querySelector('main a[href*="/tax/"]');
      const navLink = document.querySelector('header nav a[href*="/tax/"]');
      return {
        bodyBg,
        cardBg: cardEl ? getComputedStyle(cardEl).backgroundColor : 'rgb(255, 255, 255)',
        heroColor: heroEl ? getComputedStyle(heroEl).color : 'rgb(20, 52, 42)',
        heroFontVariant: heroEl ? getComputedStyle(heroEl).fontVariantNumeric : '',
        btnBg: primaryBtn ? getComputedStyle(primaryBtn).backgroundColor : 'rgb(20, 52, 42)',
        btnColor: primaryBtn ? getComputedStyle(primaryBtn).color : 'rgb(255, 255, 255)',
        navColor: navLink ? getComputedStyle(navLink).color : 'rgb(75, 85, 99)',
      };
    });

    const lightHeroContrast = contrastRatio(
      parseRgb(lightStyles.heroColor),
      parseRgb(lightStyles.cardBg)
    );
    const lightBtnContrast = contrastRatio(
      parseRgb(lightStyles.btnColor),
      parseRgb(lightStyles.btnBg)
    );
    console.log(
      `[WCAG Light] Hero (#14342a on #FFFFFF): ${lightHeroContrast.toFixed(2)}:1 | Primary Button (#FFFFFF on #14342a): ${lightBtnContrast.toFixed(2)}:1 | tabular-nums: ${lightStyles.heroFontVariant}`
    );
    if (lightHeroContrast < 4.5 || lightBtnContrast < 4.5) {
      throw new Error(`Light Mode WCAG AA failed! Hero=${lightHeroContrast}, Btn=${lightBtnContrast}`);
    }

    // Screenshot 1: ui-new-dashboard-light.png
    const lightBuf = await page.screenshot({ fullPage: true });
    saveToAllTargets('ui-new-dashboard-light.png', lightBuf);
    console.log('Saved ui-new-dashboard-light.png');

    // Toggle to Dark Mode using ThemeToggle button!
    await page.click('[data-testid="theme-toggle"]');
    await page.waitForFunction(
      () => document.documentElement.classList.contains('dark'),
      null,
      { timeout: 10000 }
    );
    await page.waitForTimeout(700);

    // Dark Mode WCAG AA Contrast Audit
    const darkStyles = await page.evaluate(() => {
      const heroEl = document.querySelector('[data-testid="hero-portfolio-value"]');
      const cardEl = heroEl?.closest('div.rounded-2xl');
      // Find TWR value in #4ade80 on #1E1E1E card
      const twrHeading = Array.from(document.querySelectorAll('span')).find((el) =>
        el.textContent?.includes('TWR (Time-Weighted)')
      );
      const twrCard = twrHeading?.closest('div.rounded-2xl');
      const twrValue = twrCard?.querySelector('p.tabular-nums');
      return {
        cardBg: cardEl ? getComputedStyle(cardEl).backgroundColor : 'rgb(30, 30, 30)',
        heroColor: heroEl ? getComputedStyle(heroEl).color : 'rgb(255, 255, 255)',
        twrCardBg: twrCard ? getComputedStyle(twrCard).backgroundColor : 'rgb(30, 30, 30)',
        twrColor: twrValue ? getComputedStyle(twrValue).color : 'rgb(74, 222, 128)',
      };
    });

    const darkHeroContrast = contrastRatio(
      parseRgb(darkStyles.heroColor),
      parseRgb(darkStyles.cardBg)
    );
    const darkAccentContrast = contrastRatio(
      parseRgb(darkStyles.twrColor),
      parseRgb(darkStyles.twrCardBg)
    );
    console.log(
      `[WCAG Dark] Hero (#FFFFFF on #1E1E1E): ${darkHeroContrast.toFixed(2)}:1 | Accent (#4ade80 on #1E1E1E): ${darkAccentContrast.toFixed(2)}:1`
    );
    if (darkHeroContrast < 4.5 || darkAccentContrast < 4.5) {
      throw new Error(
        `Dark Mode WCAG AA failed! Hero=${darkHeroContrast}, Accent=${darkAccentContrast}`
      );
    }

    // Screenshot 2: ui-new-dashboard-dark.png
    const darkBuf = await page.screenshot({ fullPage: true });
    saveToAllTargets('ui-new-dashboard-dark.png', darkBuf);
    console.log('Saved ui-new-dashboard-dark.png');

    // Switch back to Light Mode and navigate to Tax Report & Portfolio Detail
    await page.click('[data-testid="theme-toggle"]');
    await page.waitForFunction(
      () => !document.documentElement.classList.contains('dark'),
      null,
      { timeout: 10000 }
    );
    await page.waitForTimeout(400);

    // Navigate to Tax Report page via top CTA button
    await Promise.all([
      page.waitForURL(/\/tax\/.+\/\d{4}/, { timeout: 30000 }),
      page.click('a:has-text("รายงานภาษี ภ.ง.ด.90")'),
    ]);
    await page.waitForSelector('[data-testid="download-tax-pdf-btn"]', { timeout: 30000 });
    await page.waitForTimeout(700);

    // Screenshot 4: ui-new-tax-report-clean.png
    const taxBuf = await page.screenshot({ fullPage: true });
    saveToAllTargets('ui-new-tax-report-clean.png', taxBuf);
    console.log('Saved ui-new-tax-report-clean.png');

    // Also visit Portfolio Detail to verify Pastel FIFO Badges & Transaction Table
    await page.goto(`${BASE_URL}/portfolios`, { waitUntil: 'networkidle', timeout: 30000 });
    await page.click('a:has-text("เปิดพอร์ต") >> nth=0');
    await page.waitForSelector('text=ตาราง FIFO Tax Lots', { timeout: 30000 });
    await page.waitForSelector('text=สมุดบัญชีรายการซื้อขาย', { timeout: 30000 });

    await desktopCtx.close();

    // =========================================================================
    // 2. Mobile Context (390 x 844 — iPhone 14 Pro) — BottomNav Verification
    // =========================================================================
    const mobileCtx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: true,
    });
    const mPage = await mobileCtx.newPage();
    mPage.on('pageerror', (err) => consoleErrors.push(`MOBILE_PAGEERROR: ${err.message}`));

    await mPage.goto(`${BASE_URL}/login`, { waitUntil: 'networkidle', timeout: 45000 });
    await mPage.waitForSelector('#login-email', { timeout: 30000 });
    await Promise.all([
      mPage.waitForURL(new RegExp(`^${BASE_URL}/(?:th/?)?$`), { timeout: 45000 }),
      mPage.click('button[type="submit"]'),
    ]);

    await mPage.waitForSelector('[data-testid="hero-portfolio-value"]', { timeout: 30000 });
    await mPage.waitForSelector('[data-testid="mobile-bottom-nav"]', { timeout: 15000 });
    await mPage.waitForTimeout(800);
    await dismissOnboardingIfOpen(mPage);

    const mobileNavInfo = await mPage.evaluate(() => {
      const nav = document.querySelector('[data-testid="mobile-bottom-nav"]');
      if (!nav) return null;
      const cs = getComputedStyle(nav);
      const links = Array.from(nav.querySelectorAll('a')).map((a) => ({
        text: a.textContent?.trim(),
        active: a.getAttribute('aria-current') === 'page',
        color: getComputedStyle(a).color,
      }));
      return {
        display: cs.display,
        position: cs.position,
        bottom: cs.bottom,
        zIndex: cs.zIndex,
        backdropFilter: cs.backdropFilter || cs.webkitBackdropFilter,
        links,
      };
    });

    console.log('[Mobile BottomNav Audit]:', JSON.stringify(mobileNavInfo));
    if (!mobileNavInfo || mobileNavInfo.position !== 'fixed' || mobileNavInfo.links.length !== 6) {
      throw new Error('Mobile BottomNav failed layout/6-tab check!');
    }

    // Screenshot 3: ui-new-bottom-nav-mobile.png (viewport screenshot so fixed BottomNav sits flush at bottom!)
    const mobileBuf = await mPage.screenshot({ fullPage: false });
    saveToAllTargets('ui-new-bottom-nav-mobile.png', mobileBuf);
    console.log('Saved ui-new-bottom-nav-mobile.png');

    // Quick tap test on Profile tab (5th tab) to verify navigation works smoothly
    await Promise.all([
      mPage.waitForURL(/\/(?:th\/)?profile\/?$/, { timeout: 20000 }),
      mPage.click('[data-testid="mobile-bottom-nav"] a[href$="/profile"]'),
    ]);
    await mPage.waitForSelector('text=โปรไฟล์และการตั้งค่าระบบ', { timeout: 15000 });

    await mobileCtx.close();

    if (consoleErrors.length > 0) {
      throw new Error(`Browser page errors detected: ${consoleErrors.join(' | ')}`);
    }

    console.log('ALL PHASE 8 UI, DARK/LIGHT MODE, WCAG AA, AND SCREENSHOT CHECKS PASSED!');
  } finally {
    await browser.close();
  }
}

runPhase8Verification().catch((err) => {
  console.error('Verification failed:', err);
  process.exit(1);
});
