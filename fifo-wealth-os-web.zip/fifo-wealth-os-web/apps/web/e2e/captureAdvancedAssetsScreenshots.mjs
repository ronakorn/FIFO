import { chromium } from '@playwright/test';
import { mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const screenshotsDir = path.resolve(here, '../../screenshots');
const baseUrl = process.env.BASE_URL ?? 'http://127.0.0.1:3001/en/advanced-assets';
await mkdir(screenshotsDir, { recursive: true });

const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 1920, height: 1400 },
  deviceScaleFactor: 1,
  colorScheme: 'light',
});
const page = await context.newPage();
await page.addInitScript(() => localStorage.setItem('fifo_wealth_onboarding_seen_v1', '1'));
await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
await page.getByRole('heading', { name: 'Advanced Assets' }).waitFor();

async function capture(fileName) {
  await page.waitForTimeout(350);
  const filePath = path.join(screenshotsDir, fileName);
  await page.screenshot({ path: filePath, fullPage: true, animations: 'disabled' });
  console.log(`Captured ${filePath}`);
}

await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();
await page.getByTestId('options-chain-table').waitFor();
await capture('72-options-chain.png');

await page.getByRole('tab', { name: 'REITs', exact: true }).click();
await page.getByRole('tab', { name: 'Peer Comparison', exact: true }).click();
await page.getByTestId('reit-yield-chart').waitFor();
await capture('73-reit-peer-comparison.png');

await page.getByRole('tab', { name: 'Private Equity', exact: true }).click();
await page.getByRole('tab', { name: 'Fund Screener', exact: true }).click();
await page.getByTestId('pe-screener-table').waitFor();
await capture('74-pe-fund-screener.png');

await page.getByRole('button', { name: 'View details for Northstar Growth III' }).click();
await page.getByRole('dialog').getByTestId('pe-jcurve-chart').waitFor();
await capture('75-pe-fund-details.png');
await page.getByRole('button', { name: 'Close' }).click();

await page.getByRole('tab', { name: 'Futures', exact: true }).click();
await page.getByText('Margin health gauge').waitFor();
await capture('76-futures-risk-monitor.png');

await context.close();
await browser.close();
