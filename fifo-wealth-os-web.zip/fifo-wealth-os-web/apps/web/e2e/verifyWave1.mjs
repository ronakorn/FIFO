import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const OUTPUT_DIRS = ['/home/user/screenshots', '/home/user'];

function saveScreenshot(filename, buffer) {
  for (const dir of OUTPUT_DIRS) {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, filename), buffer);
  }
  console.log(`Saved ${filename}`);
}

async function runWave1Verification() {
  const pageErrors = [];
  const browser = await chromium.launch({ headless: true });

  try {
    // =========================================================================
    // 1. DESKTOP (1440 x 980) — Login -> /th/planning -> Tax-Loss Harvester -> Corporate Action -> Dividend Calendar
    // =========================================================================
    const desktopCtx = await browser.newContext({
      viewport: { width: 1440, height: 980 },
      deviceScaleFactor: 1,
    });
    const page = await desktopCtx.newPage();
    page.on('pageerror', (err) => pageErrors.push(`DESKTOP_ERR: ${err.message}`));

    // Pre-mark onboarding completed in localStorage so Light Mode screenshots are unobstructed
    await page.goto(`${BASE_URL}/th/login`, {
      waitUntil: 'domcontentloaded',
      timeout: 60000,
    });
    await page.evaluate(() => {
      window.localStorage.setItem('fifo_wealth_onboarding_seen_v1', 'true');
      window.localStorage.setItem('theme', 'light');
    });

    await page.waitForSelector('#login-email', { timeout: 30000 });
    await page.waitForTimeout(500);
    await Promise.all([
      page.waitForURL(`${BASE_URL}/th`, { timeout: 45000 }),
      page.click('button[type="submit"]'),
    ]);

    // Dismiss onboarding modal if visible
    const onboardingSkip = page.locator('[data-testid="onboarding-skip-btn"]');
    if (await onboardingSkip.isVisible({ timeout: 2500 }).catch(() => false)) {
      await onboardingSkip.click();
      await page.waitForTimeout(300);
    }

    // Navigate via Sidebar to /th/planning
    await page.click('[data-testid="desktop-sidebar"] a[href="/th/planning"]');
    await page.waitForURL(`${BASE_URL}/th/planning`, {
      waitUntil: 'domcontentloaded',
      timeout: 45000,
    });

    // Wait for Tax-Loss Harvester table & Corporate Action alert section
    await page.waitForSelector('[data-testid="tax-loss-opportunities-table"]', {
      timeout: 20000,
    });
    await page.waitForSelector('[data-testid="corporate-action-alert-section"]', {
      timeout: 20000,
    });
    await page.waitForTimeout(600);

    // Screenshot 24: Tax-Loss Harvester (Light Mode)
    saveScreenshot(
      '24-tax-loss-harvester-light.png',
      await page.screenshot({ fullPage: false })
    );

    // Exercise "Simulate Harvesting" modal & verify live API calculation
    await page.click('[data-testid="simulate-harvesting-btn"]');
    await page.waitForSelector('[data-testid="harvesting-simulation-modal"]', {
      timeout: 15000,
    });
    const savingText = await page.textContent(
      '[data-testid="modal-total-tax-saving"]'
    );
    console.log('[Tax-Loss Simulation Saving]:', savingText);
    if (!savingText || !savingText.includes('฿')) {
      throw new Error(`Invalid tax saving text: ${savingText}`);
    }
    await page.click('[data-testid="close-simulation-modal-btn"]');
    await page.waitForSelector('[data-testid="harvesting-simulation-modal"]', {
      state: 'detached',
      timeout: 10000,
    });

    // Open Corporate Action Confirmation Modal for NVDA & capture Screenshot 25
    await page.click('[data-testid="corporate-action-apply-btn-NVDA"]');
    await page.waitForSelector('[data-testid="corporate-action-confirm-modal"]', {
      timeout: 10000,
    });
    await page.waitForTimeout(400);

    saveScreenshot(
      '25-corporate-action-alert.png',
      await page.screenshot({ fullPage: false })
    );

    // Confirm adjustment and verify live POST /api/corporate-actions/apply
    await page.click('[data-testid="confirm-apply-corporate-action-btn"]');
    await page.waitForSelector('[data-testid="corporate-action-applied-NVDA"]', {
      timeout: 15000,
    });
    console.log('[Corporate Action Applied]: NVDA 2:1 Split confirmed');

    // Switch to 12-Month Dividend Calendar Tab & capture Screenshot 26
    await page.click('[data-testid="wave1-tab-calendar"]');
    await page.waitForSelector('[data-testid="dividend-calendar-section"]', {
      timeout: 20000,
    });
    await page.waitForSelector('[data-testid="dividend-12month-grid"]', {
      timeout: 20000,
    });
    await page.waitForTimeout(800);

    saveScreenshot(
      '26-dividend-calendar-desktop.png',
      await page.screenshot({ fullPage: true })
    );

    const token = await page.evaluate(() =>
      window.localStorage.getItem('token')
    );
    const userJson = await page.evaluate(() =>
      window.localStorage.getItem('wealth_user')
    );
    await desktopCtx.close();

    // =========================================================================
    // 2. MOBILE (390 x 844 — iPhone 14) — Dividend Calendar Mobile View (Screenshot 27)
    // =========================================================================
    const mobileCtx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      deviceScaleFactor: 2,
      isMobile: true,
      hasTouch: true,
    });
    const mPage = await mobileCtx.newPage();
    mPage.on('pageerror', (err) => pageErrors.push(`MOBILE_ERR: ${err.message}`));

    await mPage.goto(`${BASE_URL}/th/login`, {
      waitUntil: 'domcontentloaded',
      timeout: 60000,
    });
    await mPage.evaluate(
      ({ tok, usr }) => {
        if (tok) window.localStorage.setItem('token', tok);
        if (usr) window.localStorage.setItem('wealth_user', usr);
        window.localStorage.setItem('fifo_wealth_onboarding_seen_v1', 'true');
        window.localStorage.setItem('theme', 'light');
      },
      { tok: token, usr: userJson }
    );

    await mPage.goto(`${BASE_URL}/th/planning?tab=calendar`, {
      waitUntil: 'domcontentloaded',
      timeout: 60000,
    });
    const mSkip = mPage.locator('[data-testid="onboarding-skip-btn"]');
    if (await mSkip.isVisible({ timeout: 2500 }).catch(() => false)) {
      await mSkip.click();
      await mPage.waitForTimeout(300);
    }

    await mPage.waitForSelector('[data-testid="dividend-calendar-section"]', {
      timeout: 20000,
    });
    await mPage.waitForSelector('[data-testid="dividend-monthly-barchart"]', {
      timeout: 20000,
    });
    await mPage.waitForTimeout(800);

    // Check zero horizontal overflow on mobile
    const overflowAudit = await mPage.evaluate(() => ({
      innerWidth: window.innerWidth,
      scrollWidth: document.documentElement.scrollWidth,
    }));
    console.log('[Mobile Overflow Audit]:', JSON.stringify(overflowAudit));
    if (overflowAudit.scrollWidth > overflowAudit.innerWidth + 2) {
      throw new Error(
        `Mobile horizontal overflow detected: ${JSON.stringify(overflowAudit)}`
      );
    }

    // Scroll cleanly to the Dividend Calendar section so KPI cards + BarChart + Calendar Grid + BottomNav are framed
    await mPage.evaluate(() => {
      const el = document.querySelector('[data-testid="dividend-calendar-section"]');
      if (el) {
        const y = el.getBoundingClientRect().top + window.scrollY - 68;
        window.scrollTo(0, Math.max(0, y));
      }
    });
    await mPage.waitForTimeout(400);

    saveScreenshot(
      '27-dividend-calendar-mobile.png',
      await mPage.screenshot({ fullPage: false })
    );

    await mobileCtx.close();

    if (pageErrors.length > 0) {
      throw new Error(`Browser page errors detected:\n${pageErrors.join('\n')}`);
    }
    console.log('ALL WAVE 1 E2E CHECKS & SCREENSHOTS PASSED SUCCESSFULLY!');
  } finally {
    await browser.close();
  }
}

runWave1Verification().catch((err) => {
  console.error(err);
  process.exit(1);
});
