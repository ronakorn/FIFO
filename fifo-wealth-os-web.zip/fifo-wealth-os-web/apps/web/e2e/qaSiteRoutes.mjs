import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from '@playwright/test';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const WEB_ROOT = path.resolve(SCRIPT_DIR, '..');
const ROUTES_ROOT = path.join(WEB_ROOT, 'src/app/[locale]');
const BASE_URL = process.env.BASE_URL ?? 'http://127.0.0.1:3001';
const LOCALE = process.env.QA_LOCALE ?? 'th';

function discoverRoutes(directory = ROUTES_ROOT) {
  const routes = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      routes.push(...discoverRoutes(fullPath));
      continue;
    }
    if (entry.name !== 'page.tsx') continue;

    let route = path
      .relative(ROUTES_ROOT, path.dirname(fullPath))
      .split(path.sep)
      .filter((segment) => segment && segment !== '.')
      .join('/');
    route = route.replace(/\[portfolioId\]/g, 'mock-portfolio-ibkr');
    route = route.replace(/\[id\]/g, 'mock-portfolio-ibkr');
    route = route.replace(/\[year\]/g, '2026');
    returnRoute(routes, route);
  }
  return routes;
}

function returnRoute(routes, route) {
  const suffix = route ? `/${route}` : '';
  routes.push(`/${LOCALE}${suffix}`);
}

function normalizeHref(href, origin) {
  try {
    const url = new URL(href, origin);
    if (url.origin !== origin) return null;
    // Avoid duplicate checks for hash-only navigation and strip hashes from route checks.
    url.hash = '';
    return url.toString();
  } catch {
    return null;
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function run() {
  const routes = [...new Set(discoverRoutes())].sort();
  const browser = await chromium.launch({ headless: true });
  const failures = [];
  const routeResults = [];
  const observedLinks = new Set();
  const browserErrors = [];
  const apiFailures = [];
  const expectedAuthResponses = [];

  try {
    const context = await browser.newContext({
      viewport: { width: 1440, height: 1000 },
      deviceScaleFactor: 1,
    });
    await context.addInitScript(() => {
      if (window.location.origin !== 'null') {
        window.localStorage.setItem('fifo_wealth_onboarding_seen_v1', 'true');
        window.localStorage.setItem('theme', 'light');
      }
    });
    const page = await context.newPage();
    const origin = new URL(BASE_URL).origin;
    page.on('pageerror', (error) => browserErrors.push(error.message));
    page.on('console', (message) => {
      if (message.type() === 'error') browserErrors.push(message.text());
    });
    page.on('response', (response) => {
      const url = response.url();
      if (!url.includes('/api/')) return;
      const item = { status: response.status(), url };
      if (response.status() === 401 || response.status() === 403) {
        expectedAuthResponses.push(item);
      } else if (response.status() >= 400) {
        apiFailures.push(item);
      }
    });

    for (const route of routes) {
      const url = `${origin}${route}`;
      let responseStatus = 0;
      let title = '';
      try {
        const response = await page.goto(url, {
          waitUntil: 'domcontentloaded',
          timeout: 60000,
        });
        responseStatus = response?.status() ?? 0;
        await page.waitForTimeout(350);
        title = (await page.title()).trim();
        const routeLinks = await page.locator('a[href]').evaluateAll((elements) =>
          elements
            .filter((element) => {
              const style = getComputedStyle(element);
              const rect = element.getBoundingClientRect();
              return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
            })
            .map((element) => element.getAttribute('href'))
            .filter(Boolean)
        );
        for (const href of routeLinks) {
          const normalized = normalizeHref(href, origin);
          if (normalized) observedLinks.add(normalized);
        }
      } catch (error) {
        failures.push({ type: 'route-navigation', route, message: String(error) });
      }

      routeResults.push({ route, status: responseStatus, title });
      if (responseStatus >= 400 || responseStatus === 0) {
        failures.push({ type: 'route-status', route, status: responseStatus });
      }
      console.log(`[route] ${responseStatus} ${route} ${title}`);
    }

    const linkResults = [];
    for (const url of [...observedLinks].sort()) {
      try {
        const response = await context.request.get(url, { timeout: 30000 });
        const status = response.status();
        linkResults.push({ url, status });
        if (status >= 400) failures.push({ type: 'internal-link', url, status });
      } catch (error) {
        linkResults.push({ url, status: 0, error: String(error) });
        failures.push({ type: 'internal-link', url, message: String(error) });
      }
    }

    await context.addInitScript(() => {
      if (window.location.origin !== 'null') {
        window.localStorage.setItem('token', 'invalid-expired-jwt-for-qa');
        window.localStorage.setItem(
          'wealth_user',
          JSON.stringify({ id: 'qa-user', name: 'QA Session', email: 'qa@example.test' })
        );
      }
    });
    const authPage = await context.newPage();
    const unauthorizedStatuses = [];
    authPage.on('response', (response) => {
      if (response.url().includes('/api/') && response.status() === 401) {
        unauthorizedStatuses.push(new URL(response.url()).pathname);
      }
    });
    authPage.on('pageerror', (error) => browserErrors.push(error.message));
    await authPage.goto(`${origin}/${LOCALE}`, {
      waitUntil: 'domcontentloaded',
      timeout: 60000,
    });
    await authPage.waitForSelector('[data-testid="dashboard-heading"]', { timeout: 30000 });
    await authPage.waitForFunction(
      () => !window.localStorage.getItem('token') && !window.localStorage.getItem('wealth_user'),
      null,
      { timeout: 15000 }
    );
    const loggedOutPreviewVisible =
      (await authPage.getByText('โหมดสาธิต', { exact: false }).count()) > 0;
    const expiredSessionRecovered = unauthorizedStatuses.length > 0 && loggedOutPreviewVisible;
    if (!expiredSessionRecovered) {
      failures.push({
        type: 'expired-session-state',
        unauthorizedStatuses,
        loggedOutPreviewVisible,
      });
    }

    const interactionResults = {};
    try {
      const themeToggle = authPage.locator('[data-testid="theme-toggle"]').first();
      await themeToggle.click();
      await authPage.waitForFunction(() => document.documentElement.classList.contains('dark'));
      interactionResults.themeSwitchesToDark = true;
      await themeToggle.click();
      await authPage.waitForFunction(() => !document.documentElement.classList.contains('dark'));
      interactionResults.themeSwitchesBackToLight = true;

      await authPage.locator('[data-testid="open-ai-drawer-btn"]').click();
      await authPage.locator('[data-testid="ai-chat-drawer"]').waitFor({ state: 'visible' });
      await authPage.locator('[data-testid="ai-chat-backdrop-close"]').click();
      await authPage.locator('[data-testid="ai-chat-drawer"]').waitFor({ state: 'detached' });
      interactionResults.aiDrawerOpensAndBackdropCloses = true;

      await authPage.locator('[data-testid="open-ai-drawer-btn"]').click();
      await authPage.locator('[data-testid="ai-chat-drawer"]').waitFor({ state: 'visible' });
      await authPage.getByRole('button', { name: 'Close AI Drawer' }).click();
      await authPage.locator('[data-testid="ai-chat-drawer"]').waitFor({ state: 'detached' });
      interactionResults.aiDrawerCloseButtonWorks = true;

      await authPage.locator('[data-testid="ticker-filter-US_STOCK"]').click();
      interactionResults.usTickerFilterCount =
        await authPage.locator('[data-testid^="ticker-item-"]').count();
      if (interactionResults.usTickerFilterCount !== 2) {
        failures.push({ type: 'ticker-filter', actualCount: interactionResults.usTickerFilterCount });
      }
      await authPage.locator('[data-testid="ticker-filter-ALL"]').click();

      const scrollToggle = authPage.locator('[data-testid="ticker-autoscroll-toggle"]');
      await scrollToggle.click();
      const autoScrollPaused = await scrollToggle.getAttribute('aria-pressed');
      await scrollToggle.click();
      const autoScrollResumed = await scrollToggle.getAttribute('aria-pressed');
      interactionResults.autoScrollToggleWorks =
        autoScrollPaused === 'false' && autoScrollResumed === 'true';
      if (!interactionResults.autoScrollToggleWorks) {
        failures.push({ type: 'ticker-autoscroll-toggle', autoScrollPaused, autoScrollResumed });
      }
    } catch (error) {
      failures.push({ type: 'interaction-smoke', message: String(error) });
    }

    const report = {
      baseUrl: origin,
      locale: LOCALE,
      discoveredRouteCount: routes.length,
      internalHrefCount: observedLinks.size,
      routeResults,
      linkResults,
      apiFailures,
      expectedAuthResponses,
      browserErrors,
      sessionHandling: { expiredSessionRecovered, unauthorizedStatuses },
      interactionResults,
      failures,
    };
    console.log('\nQA_ROUTE_AUDIT_RESULT=' + JSON.stringify(report, null, 2));
    assert(failures.length === 0, `${failures.length} route/link audit failure(s).`);
    assert(apiFailures.length === 0, `${apiFailures.length} API 5xx response(s).`);
    assert(browserErrors.length === 0, `${browserErrors.length} browser console/page error(s).`);
    console.log(`PASS: ${routes.length} page routes and ${observedLinks.size} internal live links verified.`);
    await context.close();
  } finally {
    await browser.close();
  }
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
