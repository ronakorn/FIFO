import fs from 'node:fs';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const API_URL = 'http://localhost:3000/api';
const SCREENSHOT_PATH = '/home/user/screenshots/58-upload-page-partner-ready.png';
const DESCRIPTION =
  'รองรับการนำเข้าข้อมูลจาก Interactive Brokers, Bitkub, Dime! และ Streaming (รองรับทั้ง CSV, Flex Query และ Statement Automation พร้อมแปลงอัตราแลกเปลี่ยนย้อนหลังเป็นเงินบาทอัตโนมัติ)';
const PARTNER_NOTE =
  'รองรับ Statement Automation และเตรียมพร้อมสำหรับ Open API ในอนาคต';

async function main() {
  fs.mkdirSync('/home/user/screenshots', { recursive: true });

  const email = `upload-ui-check-${Date.now()}@wealthos.th`;
  const authResponse = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      email,
      password: 'UploadUICheck2026!',
      name: 'Upload UI Check',
    }),
  });
  const auth = await authResponse.json();
  if (!authResponse.ok || !auth.token || !auth.user) {
    throw new Error(`Could not create screenshot session: ${JSON.stringify(auth)}`);
  }

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 1600, height: 1100 },
    deviceScaleFactor: 1,
  });
  await context.addInitScript(
    ({ token, user }) => {
      localStorage.setItem('token', token);
      localStorage.setItem('wealth_user', JSON.stringify(user));
      localStorage.setItem('fifo_wealth_onboarding_seen_v1', 'true');
    },
    { token: auth.token, user: auth.user },
  );

  const page = await context.newPage();
  const serverErrors = [];
  page.on('response', (response) => {
    if (response.url().includes('/api/') && response.status() >= 500) {
      serverErrors.push(`${response.status()} ${response.url()}`);
    }
  });

  try {
    await page.goto(`${BASE_URL}/th/upload`, { waitUntil: 'networkidle' });
    await page.waitForSelector('[data-testid="thai-broker-connection-hub"]', {
      timeout: 30000,
    });
    await page.waitForSelector('[data-testid="thai-broker-card-DIME"]', {
      timeout: 15000,
    });
    await page.waitForSelector('[data-testid="thai-broker-card-STREAMING"]', {
      timeout: 15000,
    });

    if (!(await page.getByText(DESCRIPTION, { exact: true }).isVisible())) {
      throw new Error('The exact requested Thai Upload description is not visible.');
    }

    for (const broker of ['DIME', 'STREAMING']) {
      const badge = page.locator(`[data-testid="partner-ready-badge-${broker}"]`);
      if (!(await badge.isVisible())) {
        throw new Error(`${broker} Partner Integration Ready badge is not visible.`);
      }
      if ((await badge.getAttribute('title')) !== PARTNER_NOTE) {
        throw new Error(`${broker} badge tooltip does not match the requested Thai note.`);
      }
      const className = (await badge.getAttribute('class')) ?? '';
      if (!className.includes('bg-emerald-50') || !className.includes('text-emerald-700')) {
        throw new Error(`${broker} badge does not use the requested emerald styling.`);
      }
    }

    const pageText = await page.locator('body').innerText();
    if (pageText.includes('Official Partner Integration Ready')) {
      throw new Error('A stale official-partnership claim is still visible on the page.');
    }
    if (!pageText.includes('sandbox/scaffold')) {
      throw new Error('The pending partner-access caveat is not visible.');
    }
    if (serverErrors.length) {
      throw new Error(`Unexpected API errors: ${serverErrors.join(', ')}`);
    }

    await page.screenshot({
      path: SCREENSHOT_PATH,
      fullPage: true,
      animations: 'disabled',
    });

    console.log(
      JSON.stringify(
        {
          status: 'UPLOAD_UI_CHECK_PASSED',
          screenshot: SCREENSHOT_PATH,
          verifiedBadges: ['DIME', 'STREAMING'],
          visibleOfficialPartnershipClaim: false,
          serverErrors: serverErrors.length,
        },
        null,
        2,
      ),
    );
  } finally {
    await browser.close();
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
