import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const SCREENSHOT_DIR = '/home/user/screenshots';

async function verifyQuant() {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
  const browser = await chromium.launch({ headless: true });

  try {
    const ctx = await browser.newContext({
      viewport: { width: 1440, height: 950 },
      deviceScaleFactor: 1,
    });
    const page = await ctx.newPage();

    // Log in with Demo Investor account
    await page.goto(`${BASE_URL}/login`, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('#login-email', { timeout: 15000 });
    await Promise.all([
      page.waitForURL(`${BASE_URL}/`, { timeout: 20000 }),
      page.click('button[type="submit"]'),
    ]);

    // Wait for Quant Analytics MetricsGrid + PerformanceChart + AssetAllocationChart
    await page.waitForSelector('text=XIRR (Money-Weighted)', { timeout: 15000 });
    await page.waitForSelector('text=เปรียบเทียบมูลค่าพอร์ตกับดัชนีตลาด', { timeout: 15000 });
    await page.waitForSelector('text=สัดส่วนกลุ่มสินทรัพย์', { timeout: 15000 });
    await page.waitForTimeout(500);

    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '06-quant-dashboard-sp500.png'),
      fullPage: true,
    });

    // Switch benchmark to SET50 AND open Tooltip on XIRR to verify interactive UX
    await page.click('button:has-text("vs SET50")');
    await page.waitForSelector('text=SET50 Index (Rebased THB)', { timeout: 10000 });
    await page.click('button[aria-label*="XIRR"]');
    await page.waitForSelector('[role="tooltip"]', { timeout: 5000 });
    await page.waitForTimeout(300);

    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '07-quant-dashboard-set50-tooltip.png'),
      fullPage: true,
    });

    await ctx.close();

    // Mobile Responsive Verification (390 x 844)
    const mCtx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: true,
    });
    const mPage = await mCtx.newPage();
    await mPage.goto(`${BASE_URL}/login`, { waitUntil: 'domcontentloaded' });
    await mPage.waitForSelector('#login-email', { timeout: 15000 });
    await Promise.all([
      mPage.waitForURL(`${BASE_URL}/`, { timeout: 20000 }),
      mPage.click('button[type="submit"]'),
    ]);
    await mPage.waitForSelector('text=XIRR (Money-Weighted)', { timeout: 15000 });
    await mPage.waitForTimeout(500);
    await mPage.screenshot({
      path: path.join(SCREENSHOT_DIR, '08-quant-dashboard-mobile.png'),
      fullPage: true,
    });

    const overflow = await mPage.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth + 2
    );
    await mCtx.close();

    console.log(
      'QUANT_UI_VERIFIED:',
      JSON.stringify({ desktopSP500: true, desktopSET50Tooltip: true, mobileNoOverflow: !overflow })
    );
  } finally {
    await browser.close();
  }
}

verifyQuant().catch((err) => {
  console.error(err);
  process.exit(1);
});
