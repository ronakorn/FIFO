import { expect, test } from '@playwright/test';
import optionsChainDemo from '../../src/components/advancedAssets/optionsChainDemo.json';

test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem('fifo_wealth_onboarding_seen_v1', '1'));
  await page.goto('/en/advanced-assets');
});

test('shows the options chain with three expiries and five strikes', async ({ page }) => {
  await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();

  const chain = page.getByTestId('options-chain-table');
  await expect(chain).toBeVisible();
  await expect(chain.locator('tbody tr')).toHaveCount(5);
  await expect(page.getByRole('tablist', { name: 'Options expiry dates' }).getByRole('tab')).toHaveCount(3);
  await expect(chain.getByRole('columnheader', { name: 'Call' })).toBeVisible();
  await expect(chain.getByRole('columnheader', { name: 'Put' })).toBeVisible();
  await expect(page.getByText('Modelled · not live')).toBeVisible();
  await expect(chain.locator('tbody tr').first()).toContainText('ITM');
  await expect(chain.locator('tbody tr').first()).toContainText('OTM');
  await expect(chain.locator('tbody tr').nth(4)).toContainText('ATM');
  await expect(chain.getByText('200', { exact: false }).first()).toBeVisible();
});

test('switches AAPL/SPY scenarios and selected expiry', async ({ page }) => {
  await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();
  await page.getByLabel('Underlying symbol').selectOption('SPY');
  await expect(page.getByText('SPY · $610.00')).toBeVisible();
  await expect(page.getByTestId('options-chain-table').locator('tbody tr')).toHaveCount(5);
  await page.getByRole('tab', { name: 'Mar 19, 2027' }).click();
  await expect(page.getByRole('tab', { name: 'Mar 19, 2027' })).toHaveAttribute('aria-selected', 'true');
  await expect(page.getByText('Mar 19, 2027', { exact: false }).first()).toBeVisible();
});

test('selects a chain strike and renders its Decimal payoff profile', async ({ page }) => {
  await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();
  await page.getByLabel('Selected strike').selectOption('220.00');
  await page.getByLabel('Payoff option type').selectOption('PUT');
  await page.getByRole('button', { name: 'Select strike', exact: true }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'AAPL put payoff' })).toBeVisible();
  await expect(page.getByRole('dialog').getByText('Model ask / share')).toBeVisible();
});

test('refreshes the options chain when the model endpoint succeeds', async ({ page }) => {
  await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();
  let refreshWasRequested = false;
  await page.route('**/api/advanced-assets/options/chain', async (route) => {
    refreshWasRequested = true;
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ result: optionsChainDemo.AAPL }),
    });
  });
  await page.getByRole('button', { name: 'Refresh Chain' }).click();
  await expect.poll(() => refreshWasRequested).toBe(true);
  await expect(page.getByTestId('options-chain-table').locator('tbody tr')).toHaveCount(5);
  await expect(page.getByText(/dated sample chain remains visible/i)).toHaveCount(0);
});

test('compares five REIT peers and enforces the five-peer comparison cap', async ({ page }) => {
  await page.getByRole('tab', { name: 'REITs', exact: true }).click();
  await page.getByRole('tab', { name: 'Peer Comparison', exact: true }).click();
  const table = page.getByTestId('reit-comparison-table');
  await expect(table.locator('tbody tr')).toHaveCount(5);
  await expect(page.getByTestId('reit-yield-chart')).toBeVisible();
  await expect(page.getByText('3 of 5', { exact: false })).toBeVisible();
  await page.getByRole('button', { name: 'Add SIRI to comparison' }).click();
  await page.getByRole('button', { name: 'Add LHHOTEL to comparison' }).click();
  await expect(page.getByText('5 of 5', { exact: false })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Add SIRI to comparison' })).toHaveCount(0);
});

test('exports the selected REIT peer set to CSV', async ({ page }) => {
  await page.getByRole('tab', { name: 'REITs', exact: true }).click();
  await page.getByRole('tab', { name: 'Peer Comparison', exact: true }).click();
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export Comparison' }).click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toBe('reit-peer-comparison.csv');
});

test('filters PE funds by stage, vintage and Decimal performance ranges', async ({ page }) => {
  await page.getByRole('tab', { name: 'Private Equity', exact: true }).click();
  await page.getByRole('tab', { name: 'Fund Screener', exact: true }).click();
  const table = page.getByTestId('pe-screener-table');
  await expect(table.locator('tbody tr')).toHaveCount(5);
  await page.getByLabel('Stage').selectOption('BUYOUT');
  await expect(table.locator('tbody tr')).toHaveCount(1);
  await expect(table.getByText('GGV Capital Growth Fund')).toBeVisible();

  await page.getByLabel('Stage').selectOption('ALL');
  await page.getByLabel('Vintage from').selectOption('2022');
  await page.getByLabel('Vintage to').selectOption('2023');
  await page.getByLabel('Min IRR %').fill('7');
  await page.getByLabel('Max IRR %').fill('20');
  await page.getByLabel('Min TVPI').fill('1.2');
  await page.getByLabel('Max TVPI').fill('1.8');
  await expect(table.locator('tbody tr')).toHaveCount(3);
});

test('sorts PE fund results and opens J-curve plus cash-flow details', async ({ page }) => {
  await page.getByRole('tab', { name: 'Private Equity', exact: true }).click();
  await page.getByRole('tab', { name: 'Fund Screener', exact: true }).click();
  const table = page.getByTestId('pe-screener-table');
  await page.getByLabel('Sort by').selectOption('TVPI');
  await expect(table.locator('tbody tr').first()).toContainText('GGV Capital Growth Fund');
  await page.getByRole('button', { name: 'View details for Northstar Growth III' }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog.getByRole('heading', { name: 'Northstar Growth III' })).toBeVisible();
  await expect(dialog.getByTestId('pe-jcurve-chart')).toBeVisible();
  await expect(dialog.getByTestId('pe-cashflow-timeline').locator('> div')).toHaveCount(6);
});

test('retains the Futures risk monitor in the top-level navigation', async ({ page }) => {
  await page.getByRole('tab', { name: 'Futures', exact: true }).click();
  await expect(page.getByText('Margin health', { exact: false }).first()).toBeVisible();
});
