import { expect, test } from '@playwright/test';
import optionsChainDemo from '../../src/components/advancedAssets/optionsChainDemo.json';

const OPTIONS_CHAIN_ENDPOINT = '**/api/advanced-assets/options/chain';

function delay(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem('fifo_wealth_onboarding_seen_v1', '1'));
  await page.goto('/en/advanced-assets');
});

test('shows a recoverable API error and keeps the sample options chain visible', async ({ page }) => {
  await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();
  await page.route(OPTIONS_CHAIN_ENDPOINT, async (route) => {
    await route.fulfill({
      status: 503,
      contentType: 'application/json',
      body: JSON.stringify({ error: { message: 'Options model is temporarily unavailable.' } }),
    });
  });

  await page.getByRole('button', { name: 'Refresh Chain' }).click();

  const alert = page.locator('p[role="alert"]');
  await expect(alert).toContainText('Options model is temporarily unavailable.');
  await expect(alert).toContainText('dated sample chain remains visible');
  await expect(page.getByTestId('options-chain-table').locator('tbody tr')).toHaveCount(5);
  await expect(page.getByRole('button', { name: 'Refresh Chain' })).toBeEnabled();
});

test('applies the client timeout and restores the options chain fallback', async ({ page }) => {
  test.setTimeout(45_000);
  await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();
  let requestSeen = false;
  await page.route(OPTIONS_CHAIN_ENDPOINT, async (route) => {
    requestSeen = true;
    await delay(31_000);
    try {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ result: optionsChainDemo.AAPL }),
      });
    } catch {
      // The browser may have closed the stalled request after Axios timed out.
    }
  });

  await page.getByRole('button', { name: 'Refresh Chain' }).click();

  await expect.poll(() => requestSeen).toBe(true);
  const alert = page.locator('p[role="alert"]');
  await expect(alert).toContainText('timeout of 30000ms exceeded', { timeout: 35_000 });
  await expect(alert).toContainText('dated sample chain remains visible');
  await expect(page.getByTestId('options-chain-table').locator('tbody tr')).toHaveCount(5);
  await expect(page.getByRole('button', { name: 'Refresh Chain' })).toBeEnabled();
});

test('ignores rapid duplicate options-chain refresh submissions', async ({ page }) => {
  await page.getByRole('tab', { name: 'Options Chain', exact: true }).click();
  let requestCount = 0;
  await page.route(OPTIONS_CHAIN_ENDPOINT, async (route) => {
    requestCount += 1;
    await delay(500);
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ result: optionsChainDemo.AAPL }),
    });
  });

  const refreshButton = page.getByRole('button', { name: 'Refresh Chain' });
  await refreshButton.dblclick({ delay: 25 });
  await expect(refreshButton).toBeEnabled();
  await page.waitForTimeout(200);
  expect(requestCount).toBe(1);
});

test('handles blank, inclusive-boundary, invalid-range, and empty PE results', async ({ page }) => {
  await page.getByRole('tab', { name: 'Private Equity', exact: true }).click();
  await page.getByRole('tab', { name: 'Fund Screener', exact: true }).click();
  const table = page.getByTestId('pe-screener-table');
  const minIrr = page.getByLabel('Min IRR %');
  const maxIrr = page.getByLabel('Max IRR %');
  const minTvpi = page.getByLabel('Min TVPI');
  const maxTvpi = page.getByLabel('Max TVPI');

  await minIrr.fill('');
  await maxIrr.fill('');
  await minTvpi.fill('');
  await maxTvpi.fill('');
  await expect(table.locator('tbody tr')).toHaveCount(5);
  await expect(page.locator('p[role="alert"]')).toHaveCount(0);

  await minIrr.fill('0');
  await maxIrr.fill('100');
  await minTvpi.fill('0');
  await maxTvpi.fill('5');
  await expect(table.locator('tbody tr')).toHaveCount(5);

  await minIrr.fill('100');
  await maxIrr.fill('100');
  await expect(table.getByText('No sample funds match these criteria. Adjust the ranges to continue.')).toBeVisible();

  await minIrr.fill('17');
  await maxIrr.fill('16');
  await expect(page.locator('p[role="alert"]')).toContainText('Minimum IRR cannot exceed maximum IRR.');
});

test('blocks empty login submissions with native required-field validation', async ({ page }) => {
  await page.goto('/en/login');
  let requestCount = 0;
  await page.route('**/api/auth/login', async (route) => {
    requestCount += 1;
    await route.fulfill({ status: 200, contentType: 'application/json', body: '{}' });
  });

  const email = page.getByLabel('Email address');
  const password = page.getByLabel('Password');
  await email.fill('');
  await password.fill('');
  await page.getByRole('button', { name: 'Sign in' }).click();

  expect(await email.evaluate((element) => (element as HTMLInputElement).validity.valueMissing)).toBe(true);
  expect(await password.evaluate((element) => (element as HTMLInputElement).validity.valueMissing)).toBe(true);
  expect(requestCount).toBe(0);
});
