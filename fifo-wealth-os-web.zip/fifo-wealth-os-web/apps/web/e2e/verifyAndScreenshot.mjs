import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const SCREENSHOT_DIR = '/home/user/screenshots';

async function runVerification() {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

  const browser = await chromium.launch({ headless: true });
  const results = {};

  try {
    // =========================================================================
    // 1. Desktop E2E Flow (1440 x 900)
    // =========================================================================
    const desktopCtx = await browser.newContext({
      viewport: { width: 1440, height: 900 },
      deviceScaleFactor: 1,
      acceptDownloads: true,
    });
    const page = await desktopCtx.newPage();

    // A) Login Page
    await page.goto(`${BASE_URL}/login`, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('#login-email', { timeout: 20000 });
    await page.waitForTimeout(400);
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '01-login-desktop.png'),
      fullPage: true,
    });
    results.loginPageRendered = true;

    // Submit real Login against Backend :3000 via Next.js /api proxy
    await Promise.all([
      page.waitForURL(`${BASE_URL}/`, { timeout: 25000 }),
      page.click('button[type="submit"]'),
    ]);

    const jwtToken = await page.evaluate(() => window.localStorage.getItem('token'));
    if (!jwtToken || jwtToken.split('.').length !== 3) {
      throw new Error('JWT token was not saved in localStorage after login!');
    }
    results.jwtStoredInLocalStorage = true;

    // Clean up any leftover E2E portfolios from earlier partial runs first
    await page.evaluate(async (token) => {
      const res = await fetch('/api/portfolios', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const list = await res.json();
      for (const p of list) {
        if (p.name === 'E2E Quant Verification Portfolio') {
          await fetch(`/api/portfolios/${p.id}`, {
            method: 'DELETE',
            headers: { Authorization: `Bearer ${token}` },
          });
        }
      }
    }, jwtToken);

    await page.reload({ waitUntil: 'domcontentloaded' });

    // B) Dashboard Page (wait for live API portfolios + Recharts SVG)
    await page.waitForSelector('text=US Tech & Flagship Equities (IBKR)', { timeout: 20000 });
    await page.waitForSelector('.recharts-responsive-container svg', { timeout: 20000 });
    await page.waitForTimeout(800);
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '02-dashboard-desktop.png'),
      fullPage: true,
    });
    results.dashboardLivePortfoliosLoaded = true;

    const portfolios = await page.evaluate(async (token) => {
      const res = await fetch('/api/portfolios', {
        headers: { Authorization: `Bearer ${token}` },
      });
      return res.json();
    }, jwtToken);

    const usPortfolio = portfolios.find((p) => p.name.includes('IBKR')) || portfolios[0];
    if (!usPortfolio) {
      throw new Error('Expected seeded portfolio from Backend API');
    }

    // Create a temporary E2E portfolio via UI Dialog on /portfolios
    await page.goto(`${BASE_URL}/portfolios`, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('button:has-text("สร้างพอร์ตใหม่")', { timeout: 20000 });
    await page.click('button:has-text("สร้างพอร์ตใหม่")');
    await page.fill('input[placeholder*="Bitkub"]', 'E2E Quant Verification Portfolio');
    await page.locator('[role="dialog"] button[type="submit"]').click();
    await page.waitForSelector('text=E2E Quant Verification Portfolio', { timeout: 15000 });

    const updatedPortfolios = await page.evaluate(async (token) => {
      const res = await fetch('/api/portfolios', {
        headers: { Authorization: `Bearer ${token}` },
      });
      return res.json();
    }, jwtToken);
    const e2ePortfolio = updatedPortfolios.find(
      (p) => p.name === 'E2E Quant Verification Portfolio'
    );
    results.createPortfolioLive = Boolean(e2ePortfolio);

    // C) Upload CSV Page — test real multipart CSV upload to Backend FIFO Engine
    await page.goto(`${BASE_URL}/upload?portfolioId=${e2ePortfolio.id}`, {
      waitUntil: 'domcontentloaded',
    });
    await page.waitForSelector('button:has-text("เติมไฟล์ตัวอย่าง IBKR ทันที")', {
      timeout: 20000,
    });
    await page.click('button:has-text("เติมไฟล์ตัวอย่าง IBKR ทันที")');
    await page.waitForSelector('text=sample_ibkr_trades_2024.csv');
    await page.click('button:has-text("อัปโหลดและคำนวณต้นทุน FIFO ทันที")');
    await page.waitForSelector('text=นำเข้าข้อมูลและคำนวณ FIFO สำเร็จ', { timeout: 20000 });
    await page.waitForTimeout(400);
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '03-upload-desktop.png'),
      fullPage: true,
    });
    results.csvUploadLive = true;

    // Clean up temporary E2E portfolio via Backend API
    await page.evaluate(
      async ({ token, id }) => {
        await fetch(`/api/portfolios/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` },
        });
      },
      { token: jwtToken, id: e2ePortfolio.id }
    );

    // D) Portfolio Detail Page (/portfolios/[id])
    await page.goto(`${BASE_URL}/portfolios/${usPortfolio.id}`, {
      waitUntil: 'domcontentloaded',
    });
    await page.waitForSelector('text=ตาราง FIFO Tax Lots', { timeout: 20000 });
    await page.waitForTimeout(800);
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '05-portfolio-detail-desktop.png'),
      fullPage: true,
    });
    results.portfolioDetailLive = true;

    // E) Tax Report Page (/tax/[portfolioId]/2024) + real 5-page PDF download
    await page.goto(`${BASE_URL}/tax/${usPortfolio.id}/2024`, {
      waitUntil: 'domcontentloaded',
    });
    await page.waitForSelector('text=รายงานสรุปภาษีเงินได้ประจำปี พ.ศ. 2567 (2024)', {
      timeout: 20000,
    });

    const [download] = await Promise.all([
      page.waitForEvent('download', { timeout: 20000 }),
      page.click('button:has-text("ดาวน์โหลด PDF 5 หน้า")'),
    ]);

    const downloadedPdfPath = path.join(SCREENSHOT_DIR, 'downloaded_tax_report_2024.pdf');
    await download.saveAs(downloadedPdfPath);
    const pdfBytes = fs.readFileSync(downloadedPdfPath);
    const pdfText = pdfBytes.toString('latin1');
    const pageMatches = pdfText.match(/\/Type\s*\/Page\b/g) || [];
    results.taxPdfDownloaded = {
      header: pdfBytes.subarray(0, 8).toString('utf8'),
      sizeBytes: pdfBytes.length,
      pagesCount: pageMatches.length,
    };

    await page.waitForSelector('text=สร้างและดาวน์โหลดรายงานภาษี PDF 5 หน้า', {
      timeout: 10000,
    });
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '04-tax-report-desktop.png'),
      fullPage: true,
    });

    await desktopCtx.close();

    // =========================================================================
    // 2. Mobile Responsive Verification (iPhone 14 Viewport: 390 x 844)
    // =========================================================================
    const mobileCtx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      deviceScaleFactor: 1,
      isMobile: true,
      hasTouch: true,
    });
    const mPage = await mobileCtx.newPage();

    // Mobile Login
    await mPage.goto(`${BASE_URL}/login`, { waitUntil: 'domcontentloaded' });
    await mPage.waitForSelector('#login-email', { timeout: 20000 });
    await mPage.waitForTimeout(300);
    await mPage.screenshot({
      path: path.join(SCREENSHOT_DIR, '01-login-mobile.png'),
      fullPage: true,
    });

    await Promise.all([
      mPage.waitForURL(`${BASE_URL}/`, { timeout: 25000 }),
      mPage.click('button[type="submit"]'),
    ]);

    // Mobile Dashboard
    await mPage.waitForSelector('text=US Tech & Flagship Equities (IBKR)', { timeout: 20000 });
    await mPage.waitForTimeout(800);
    await mPage.screenshot({
      path: path.join(SCREENSHOT_DIR, '02-dashboard-mobile.png'),
      fullPage: true,
    });

    const hasHorizontalOverflow = await mPage.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth + 2
    );
    results.mobileNoHorizontalOverflow = !hasHorizontalOverflow;

    // Mobile Upload Page
    await mPage.goto(`${BASE_URL}/upload`, { waitUntil: 'domcontentloaded' });
    await mPage.waitForSelector('text=นำเข้าไฟล์ประวัติซื้อขายและเงินปันผล', { timeout: 20000 });
    await mPage.waitForTimeout(400);
    await mPage.screenshot({
      path: path.join(SCREENSHOT_DIR, '03-upload-mobile.png'),
      fullPage: true,
    });

    // Mobile Tax Report Page
    await mPage.goto(`${BASE_URL}/tax/${usPortfolio.id}/2024`, {
      waitUntil: 'domcontentloaded',
    });
    await mPage.waitForSelector('text=รายงานสรุปภาษีเงินได้ประจำปี พ.ศ. 2567 (2024)', {
      timeout: 20000,
    });
    await mPage.waitForTimeout(400);
    await mPage.screenshot({
      path: path.join(SCREENSHOT_DIR, '04-tax-report-mobile.png'),
      fullPage: true,
    });

    await mobileCtx.close();

    console.log('E2E_VERIFICATION_SUCCESS:', JSON.stringify(results, null, 2));
  } finally {
    await browser.close();
  }
}

runVerification().catch((err) => {
  console.error('E2E_VERIFICATION_FAILED:', err);
  process.exit(1);
});
