import fs from 'node:fs';
import path from 'node:path';
import { chromium } from '@playwright/test';

const BASE_URL = 'http://localhost:3001';
const API_URL = 'http://localhost:3000/api';
const SCREENSHOT_DIR = '/home/user/screenshots';

async function assertJson(response, label) {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`${label} failed (${response.status()}): ${JSON.stringify(body)}`);
  }
  return body;
}

async function main() {
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

  const tag = Date.now();
  const email = `thai-broker-pitch-${tag}@wealthos.th`;
  const password = 'PitchDemo2026!';

  const registerRes = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email, password, name: 'Thai Broker Partnership Demo' }),
  });
  const auth = await assertJson(registerRes, 'register demo account');

  const portfolioRes = await fetch(`${API_URL}/portfolios`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${auth.token}`,
    },
    body: JSON.stringify({ name: 'Thai Broker Hub • Pitch Demo', baseCurrency: 'THB' }),
  });
  const portfolio = await assertJson(portfolioRes, 'create demo portfolio');

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 1600, height: 1100 },
    deviceScaleFactor: 1,
  });
  await context.addInitScript(
    ({ token, user }) => {
      localStorage.setItem('token', token);
      localStorage.setItem('wealth_user', JSON.stringify(user));
      localStorage.setItem('fifo_wealth_onboarding_seen_v1', 'true');
    },
    { token: auth.token, user: auth.user }
  );

  const page = await context.newPage();
  const apiErrors = [];
  page.on('response', (response) => {
    if (response.url().includes('/api/') && response.status() >= 500) {
      apiErrors.push(`${response.status()} ${response.url()}`);
    }
  });

  try {
    await page.goto(`${BASE_URL}/upload?portfolioId=${portfolio.id}`, {
      waitUntil: 'load',
    });
    await page.waitForSelector('[data-testid="thai-broker-connection-hub"]', {
      timeout: 30000,
    });
    await page.waitForSelector('[data-testid="thai-broker-card-STREAMING"]', {
      timeout: 15000,
    });

    const hub = page.locator('[data-testid="thai-broker-connection-hub"]');
    await hub.screenshot({
      path: path.join(SCREENSHOT_DIR, '46-thai-broker-hub-overview.png'),
      animations: 'disabled',
    });

    await page.locator('[data-testid="thai-broker-connect-btn-BITKUB"]').click();
    await page.waitForSelector('[data-testid="pdpa-consent-modal"]', { timeout: 10000 });
    await page.locator('[data-testid="demo-fill-credentials-btn"]').click();
    await page.waitForTimeout(150);
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '47-thai-broker-hub-pdpa-consent.png'),
      animations: 'disabled',
    });

    // Consent remains unchecked after demo-fill; explicitly exercise the user's checkbox action.
    const consentCheckbox = page.locator('[data-testid="pdpa-consent-checkbox"]');
    if (await consentCheckbox.isChecked()) {
      throw new Error('PDPA consent must not be pre-checked by demo-fill.');
    }
    await consentCheckbox.check();
    await page.locator('[data-testid="confirm-pdpa-connect-btn"]').click();
    await page.waitForSelector('[data-testid="pdpa-consent-modal"]', {
      state: 'detached',
      timeout: 15000,
    });
    await page.waitForFunction(() => {
      const status = document.querySelector('[data-testid="broker-status-BITKUB"]');
      return status?.textContent?.includes('Credentials Saved');
    }, { timeout: 10000 });

    await page.locator('[data-testid="thai-broker-sync-btn-BITKUB"]').click();
    await page.waitForSelector('[data-testid="thai-broker-sync-result-BITKUB"]', {
      timeout: 25000,
    });
    await page.waitForFunction(() => {
      const status = document.querySelector('[data-testid="broker-status-BITKUB"]');
      return status?.textContent?.includes('Sandbox Demo');
    }, { timeout: 10000 });
    await hub.screenshot({
      path: path.join(SCREENSHOT_DIR, '48-thai-broker-hub-sandbox-sync.png'),
      animations: 'disabled',
    });

    await page.locator('[data-testid="thai-broker-purge-btn-BITKUB"]').click();
    await page.waitForSelector('[data-testid="pdpa-purge-success-banner"]', {
      timeout: 15000,
    });
    await hub.screenshot({
      path: path.join(SCREENSHOT_DIR, '49-thai-broker-hub-purge-confirmed.png'),
      animations: 'disabled',
    });

    if (apiErrors.length) {
      throw new Error(`Unexpected server errors: ${apiErrors.join(', ')}`);
    }

    console.log(
      JSON.stringify(
        {
          status: 'E2E_PASSED',
          demoPortfolioId: portfolio.id,
          screenshots: [
            'screenshots/46-thai-broker-hub-overview.png',
            'screenshots/47-thai-broker-hub-pdpa-consent.png',
            'screenshots/48-thai-broker-hub-sandbox-sync.png',
            'screenshots/49-thai-broker-hub-purge-confirmed.png',
          ],
          apiErrors,
        },
        null,
        2
      )
    );
  } finally {
    await context.close();
    await browser.close();
  }
}

main().catch((err) => {
  console.error('THAI_BROKER_HUB_E2E_FAILED:', err);
  process.exitCode = 1;
});
