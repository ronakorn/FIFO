import Decimal from 'decimal.js';

/** Decimal context for all mock market-price and percentage calculations. */
export const TickerDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type TickerCategory = 'TH_STOCK' | 'US_STOCK' | 'GOLD' | 'CRYPTO';
export type TickerCurrency = 'THB' | 'USD';

export interface TickerItem {
  symbol: string;
  name: string;
  category: TickerCategory;
  /** Quote in its local currency. Kept as a decimal string throughout the UI. */
  price: string;
  currency: TickerCurrency;
  /** FX multiplier to THB; THB quote instruments use "1". */
  fxToTHB: string;
  /** Daily percentage move, stored as a decimal string (for example "1.24"). */
  changePct: string;
  displayDecimals: number;
}

const MOCK_USD_THB = '36.37735849056603773584905660377358490566';

export const INITIAL_MOCK_TICKERS: TickerItem[] = [
  {
    symbol: 'PTT',
    name: 'PTT Public Company Limited',
    category: 'TH_STOCK',
    price: '32.50',
    currency: 'THB',
    fxToTHB: '1',
    changePct: '0.62',
    displayDecimals: 2,
  },
  {
    symbol: 'ADVANC',
    name: 'Advanced Info Service',
    category: 'TH_STOCK',
    price: '287.00',
    currency: 'THB',
    fxToTHB: '1',
    changePct: '1.08',
    displayDecimals: 2,
  },
  {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    category: 'US_STOCK',
    price: '132.50',
    currency: 'USD',
    fxToTHB: MOCK_USD_THB,
    changePct: '-0.48',
    displayDecimals: 2,
  },
  {
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    category: 'US_STOCK',
    price: '90.00',
    currency: 'USD',
    fxToTHB: MOCK_USD_THB,
    changePct: '1.82',
    displayDecimals: 2,
  },
  {
    symbol: 'GOLD965',
    name: 'ทองคำแท่ง 96.5% / บาททอง',
    category: 'GOLD',
    price: '40550.00',
    currency: 'THB',
    fxToTHB: '1',
    changePct: '0.31',
    displayDecimals: 2,
  },
  {
    symbol: 'BTC',
    name: 'Bitcoin',
    category: 'CRYPTO',
    price: '2500000.00',
    currency: 'THB',
    fxToTHB: '1',
    changePct: '2.14',
    displayDecimals: 2,
  },
  {
    symbol: 'ETH',
    name: 'Ethereum',
    category: 'CRYPTO',
    price: '71200.00',
    currency: 'THB',
    fxToTHB: '1',
    changePct: '-1.26',
    displayDecimals: 2,
  },
  {
    symbol: 'SOL',
    name: 'Solana',
    category: 'CRYPTO',
    price: '5400.00',
    currency: 'THB',
    fxToTHB: '1',
    changePct: '0.94',
    displayDecimals: 2,
  },
];

/**
 * Maps quote prices to THB for downstream portfolio/tax dashboards.
 * All FX multiplication uses Decimal.js precision 40 and rounds only to satang.
 */
export function tickerPricesToTHB(
  tickers: readonly TickerItem[]
): Record<string, string> {
  return Object.fromEntries(
    tickers.map((ticker) => [
      ticker.symbol,
      new TickerDecimal(ticker.price)
        .times(new TickerDecimal(ticker.fxToTHB))
        .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
        .toFixed(2),
    ])
  );
}

export interface FetchLatestMarketPricesOptions {
  /** Optional test/demo override. Defaults to the requested 500ms network simulation. */
  delayMs?: number;
  /** Injectable random source for deterministic tests. Must return a value in [0, 1). */
  random?: () => number;
}

/**
 * Simulates a 500ms market-data fetch and applies an independent random price move
 * in [-1%, +1%] per instrument. This is sandbox/demo data, not a live price feed.
 */
export async function fetchLatestMarketPrices(
  tickers: readonly TickerItem[] = INITIAL_MOCK_TICKERS,
  options: FetchLatestMarketPricesOptions = {}
): Promise<TickerItem[]> {
  const delayMs = Math.max(0, options.delayMs ?? 500);
  await new Promise<void>((resolve) => setTimeout(resolve, delayMs));

  const random = options.random ?? Math.random;
  return tickers.map((ticker) => {
    const rawSample = random();
    const safeSample = Number.isFinite(rawSample)
      ? Math.max(0, Math.min(0.999999999999, rawSample))
      : 0.5;
    const movePct = new TickerDecimal(String(safeSample))
      .times(2)
      .minus(1)
      .toDecimalPlaces(6, Decimal.ROUND_HALF_UP);
    const oldPrice = new TickerDecimal(ticker.price);
    const factor = new TickerDecimal(1).plus(
      movePct.dividedBy(100)
    );
    let nextPrice = oldPrice
      .times(factor)
      .toDecimalPlaces(ticker.displayDecimals, Decimal.ROUND_HALF_UP);

    // Tick-size rounding must not push a displayed quote outside the requested ±1% band.
    const upperBand = oldPrice.times('1.01');
    const lowerBand = oldPrice.times('0.99');
    if (nextPrice.gt(upperBand)) {
      nextPrice = upperBand.toDecimalPlaces(ticker.displayDecimals, Decimal.ROUND_DOWN);
    }
    if (nextPrice.lt(lowerBand)) {
      nextPrice = lowerBand.toDecimalPlaces(ticker.displayDecimals, Decimal.ROUND_UP);
    }

    // Ensure a visibly changed quote even if a tiny random move rounds to the old tick.
    if (nextPrice.eq(oldPrice)) {
      const tick = new TickerDecimal(1).dividedBy(
        new TickerDecimal(10).pow(ticker.displayDecimals)
      );
      nextPrice = movePct.gte(0) ? oldPrice.plus(tick) : oldPrice.minus(tick);
    }

    const actualMovePct = nextPrice
      .minus(oldPrice)
      .dividedBy(oldPrice)
      .times(100);
    const nextDailyChange = new TickerDecimal(ticker.changePct)
      .plus(actualMovePct)
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2);

    return {
      ...ticker,
      price: nextPrice.toFixed(ticker.displayDecimals),
      changePct: nextDailyChange,
    };
  });
}
