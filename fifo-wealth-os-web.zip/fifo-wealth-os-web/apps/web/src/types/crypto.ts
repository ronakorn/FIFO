export type SupportedChain = 'EVM' | 'SOLANA' | 'BTC';

export type TokenStandard = 'NATIVE' | 'ERC20' | 'SPL' | 'UTXO';

export interface OnChainTokenBalance {
  chain: SupportedChain;
  symbol: string;
  name: string;
  standard: TokenStandard;
  contractAddress: string | null;
  decimals: number;
  balance: string;
  priceUSD: string;
  valueUSD: string;
}

export interface CryptoWalletPublic {
  id: string;
  portfolioId: string | null;
  chain: SupportedChain;
  addressMasked: string;
  addressHash: string;
  label: string | null;
  isActive: boolean;
  lastSyncedAt: string | null;
  createdAt: string;
  readOnly: true;
  privacyProtection: 'AES-256-GCM + SHA-256';
}

export interface CryptoWalletSyncResult {
  wallet: CryptoWalletPublic;
  providerName: string;
  portfolioId: string;
  tokenBalances: OnChainTokenBalance[];
  discoveredOnChainCount: number;
  generatedCdmCount: number;
  addedTransactions: number;
  skippedTransactions: number;
  breakdown: {
    swaps: number;
    transfers: number;
    buyLegs: number;
    sellLegs: number;
    feeLegs: number;
  };
  syncedAt: string;
}
