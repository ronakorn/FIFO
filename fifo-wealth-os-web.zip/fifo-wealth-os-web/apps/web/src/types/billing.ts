export type BillingTier = 'FREE' | 'PRO' | 'FAMILY' | 'ADVISOR';
export type BillingStatus = 'ACTIVE' | 'CANCELED' | 'BETA_ALL_ACCESS' | 'FREE';
export type BillingInterval = 'month' | 'year';

export interface BillingTierPricing {
  tier: BillingTier;
  id: string;
  nameTH: string;
  nameEN: string;
  monthlyPriceTHB: string;
  yearlyPriceTHB: string;
  earlyBirdMonthlyPriceTHB: string;
  earlyBirdYearlyPriceTHB: string;
  yearlySavingsPercentage: string;
  features: Record<string, boolean | number>;
}

export interface EarlyBirdPricing {
  eligible: boolean;
  canClaim: boolean;
  claimed: boolean;
  canceled: boolean;
  discountActive: boolean;
  discountPercentage: number;
  validUntil: string;
  lifetimeDiscount: boolean;
  endsOnCancellation: boolean;
}

export interface BillingPricingCatalog {
  tiers: BillingTierPricing[];
  earlyBird: EarlyBirdPricing;
}

export interface BillingStatusResponse {
  planName: string;
  tier: BillingTier;
  status: BillingStatus;
  isBetaAllAccess: boolean;
  currentPeriodEnd: string | null;
  access: 'ALL_FEATURES' | 'FREE_FEATURES' | 'PLAN_FEATURES';
  entitlements?: Record<string, boolean | number>;
  pricing?: BillingPricingCatalog;
  chargesEnabled?: boolean;
}

export interface BillingPricingResponse {
  openBeta: boolean;
  chargesEnabled: false;
  pricing: BillingPricingCatalog;
}

export interface CommunityFundraisingResponse {
  currency: 'THB';
  baselineTHB: string;
  successfulDonationsTHB: string;
  totalRaisedTHB: string;
  targetTHB: string;
  remainingTHB: string;
  progressPercentage: string;
  successfulDonationCount: number;
  recordedDonorCount: number;
}

export interface EarlyBirdStatusResponse {
  earlyBird: {
    eligible: boolean;
    canClaim: boolean;
    claimed: boolean;
    canceled: boolean;
    discountActive: boolean;
    discountPercentage: number;
    validUntil: string;
    lifetimeDiscount: boolean;
    endsOnCancellation: boolean;
    claimedAt: string | null;
    canceledAt: string | null;
  };
  donorProYear: {
    currency: 'THB';
    donatedTHB: string;
    thresholdTHB: string;
    remainingTHB: string;
    eligible: boolean;
    qualifiedAt: string | null;
    durationMonths: number;
    status: 'IN_PROGRESS' | 'QUEUED_FOR_SUBSCRIPTION_LAUNCH';
    startsWhen: 'SUBSCRIPTION_LAUNCH';
    autoGranted: boolean;
  };
  trial: {
    reserved: boolean;
    status: 'NOT_REQUESTED' | 'RESERVED_FOR_SUBSCRIPTION_LAUNCH';
    durationDays: number;
    requestedAt: string | null;
    startsWhen: 'SUBSCRIPTION_LAUNCH';
    chargesEnabled: false;
  };
}

export interface EarlyBirdClaimResponse {
  earlyBird: {
    claimed: true;
    alreadyClaimed: boolean;
    discountActive: boolean;
    canceled: boolean;
    discountPercentage: number;
    validUntil: string;
    lifetimeDiscount: boolean;
    endsOnCancellation: boolean;
    claimedAt: string | null;
  };
  chargesEnabled: false;
}

export interface TrialReservationResponse {
  trial: {
    reserved: true;
    status: 'RESERVED_FOR_SUBSCRIPTION_LAUNCH';
    durationDays: number;
    requestedAt: string;
    startsWhen: 'SUBSCRIPTION_LAUNCH';
    chargesEnabled: false;
  };
}

export interface DonationCheckoutResponse {
  donation: {
    id: string;
    userId: string;
    amountTHB: string;
    currency: string;
    stripePaymentId: string | null;
    status: 'PENDING' | 'SUCCEEDED' | 'FAILED';
    message: string | null;
    createdAt: string;
  };
  checkout: {
    id: string;
    url: string;
    mode: 'payment' | 'subscription';
    amountTHB: string;
    currency: 'THB';
    customerId: string;
    paymentIntentId: string | null;
    metadata: Record<string, string>;
  };
}

export interface CustomerPortalResponse {
  portal: {
    id: string;
    url: string;
    customerId: string;
  };
}
