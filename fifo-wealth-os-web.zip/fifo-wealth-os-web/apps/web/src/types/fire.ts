export interface FIREGoal {
  id: string;
  userId: string;
  name: string;
  targetAmount: string;
  currentAmount: string;
  monthlyContribution: string;
  expectedReturn: string;
  inflationRate: string;
  targetYear: number;
  currentAge: number;
  retirementAge: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface SimulationPoint {
  year: number;
  value: string;
}

export type SimulationPath = SimulationPoint[];

export interface MonteCarloPercentilePoint {
  year: number;
  p10: string;
  median: string;
  p90: string;
}

export interface MonteCarloResult {
  successRate: number;
  medianYear: number;
  p10Year: number;
  p90Year: number;
  simulations: SimulationPath[];
  percentileSeries?: MonteCarloPercentilePoint[];
  targetAmount?: string;
}

export interface GoalProgress {
  goalId: string;
  currentAmount: string;
  targetAmount: string;
  progressPct: string;
  yearsRemaining: number;
  onTrack: boolean;
}

export interface FIRESummaryResponse {
  fireNumber: string;
  yearsToFIRE: string;
  successRate: number;
  currentPortfolioValueTHB: string;
  monthlyContributionTHB: string;
  annualExpensesTHB: string;
  withdrawalRate: string;
  expectedReturn: string;
  inflationRate: string;
  volatility: string;
  goalsCount: number;
  onTrackCount: number;
  goals: Array<{
    goal: FIREGoal;
    progress: GoalProgress;
  }>;
  monteCarlo: MonteCarloResult;
}
