export type LotStatus = 'Sold' | 'Partial' | 'Hold';

export interface Lot {
  id: string;
  date: string;
  symbol: string;
  buyQty: number;
  costPerUnit: number;
  qtySold: number;
  qtyRemain: number;
  realizedGL: number;
  unrealizedGL: number;
  status: LotStatus;
}

export type TaxEventType = 'CAPITAL_GAIN' | 'DIVIDEND';

export interface TaxEvent {
  id: string;
  type: TaxEventType;
  date: string;
  symbol: string;
  amountTHB: string;
  taxableIncome: string;
  taxWithheld: string;
  netTaxPayable: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface PortfolioFIFOSummary {
  totalRealizedGL: number;
  totalUnrealizedGL: number;
  totalCostSold: number;
  totalProceeds: number;
  openCostBasisTHB: number;
  marketValueTHB: number;
  lots: Lot[];
}

export interface Portfolio {
  id: string;
  userId: string;
  name: string;
  baseCurrency: string;
  createdAt: string;
  transactionCount?: number;
  dividendCount?: number;
  fifoSummary?: PortfolioFIFOSummary;
}

export interface Transaction {
  id: string;
  portfolioId: string;
  date: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  qty: number;
  price: number;
  gross: string;
  comm: string;
  vat: string;
  net: string;
  originalCurrency: string;
  fxRate: string | null;
  netTHB: string | null;
}

export interface DividendRecord {
  id: string;
  portfolioId: string;
  date: string;
  symbol: string;
  qty: number;
  divPerShare: string;
  gross: string;
  whtRate: number;
  wht: string;
  net: string;
  originalCurrency: string;
  fxRate: string | null;
  grossTHB: string | null;
  whtTHB: string | null;
  netTHB: string | null;
}

export interface UploadedFileRecord {
  id: string;
  userId: string;
  portfolioId: string;
  filename: string;
  type: 'CSV' | 'PDF';
  path: string;
  createdAt: string;
}

export interface TaxReport {
  taxYear: number;
  totalTaxableIncome: string;
  totalTaxWithheld: string;
  totalTaxPayable: string;
  capitalGains: TaxEvent[];
  dividends: TaxEvent[];
  generatedAt?: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export interface UploadCSVResponse {
  transactions: Transaction[];
  summary: {
    count: number;
    totalRealizedGL: number;
    totalUnrealizedGL: number;
    totalCostSold: number;
    totalProceeds: number;
  };
  uploadedFile: UploadedFileRecord;
}

export interface UploadDividendsResponse {
  dividends: DividendRecord[];
  summary: {
    count: number;
    totalGrossTHB: string;
    totalWhtTHB: string;
    totalNetTHB: string;
  };
  uploadedFile: UploadedFileRecord;
}
