export type GoldAssetSubclass =
  | 'PHYSICAL_GOLD'
  | 'GOLD_ONLINE_FUTURES'
  | 'XAU_SPOT';
export type GoldWeightUnit = 'THAI_BAHT' | 'GRAM' | 'TROY_OUNCE';
export type GoldPurity = '96.5' | '99.99' | '99.9' | '99.5';

export interface GoldTransaction {
  id: string;
  portfolioId: string;
  date: string;
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  weight: string;
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
  spotPricePerUnit: string;
  premiumPerUnit: string;
  commission: string;
  totalCost: string;
  fxRateAtPurchase: string;
  type: 'BUY' | 'SELL';
  createdAt: string;
}

export interface GoldLot {
  id: string;
  transactionId: string;
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  weight: string;
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
  costPerUnit: string;
  weightSold: string;
  weightRemain: string;
  realizedGL: string;
  unrealizedGL: string;
  status: 'Hold' | 'Partial' | 'Sold';
  isTaxExempt?: boolean;
}

export interface GoldTaxHandoffRecord {
  lotId: string;
  transactionId: string;
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  purity: GoldPurity;
  realizedGLTHB: string;
  isTaxExempt: boolean;
  taxableCapitalGainTHB: string;
  exemptionCode: 'TH_RD_SEC_42_9_PHYSICAL_GOLD' | null;
}

export type GoldDriverState =
  | 'WORLD_GOLD_RALLY'
  | 'WORLD_GOLD_PULLBACK'
  | 'WORLD_GOLD_FLAT';

export type FxDriverState =
  | 'THB_WEAKENING'
  | 'THB_STRENGTHENING'
  | 'THB_FLAT';

export type BrinsonPrimaryDriver = 'GOLD_ALPHA' | 'FX_IMPACT' | 'BALANCED';

export interface GtaGold965ParityBreakdown {
  xauUsdSpot: string;
  usdThbRate: string;
  conversionFactor965: string;
  gtaParityPriceTHB: string;
  rawGtaParityPriceTHB: string;
  gtaAssociationSellTHB?: string;
  domesticPremiumTHB?: string;
  domesticPremiumPct?: string;
}

export interface MultiplicativeBrinsonItem {
  symbol: string;
  assetSubclass?: GoldAssetSubclass;
  mode: 'UNREALIZED' | 'REALIZED';
  costBasisTHB: string;
  endingValueTHB: string;
  totalGLTHB: string;
  entryUsdThb: string;
  currentUsdThb: string;
  entryImpliedXauUsd?: string;
  currentImpliedXauUsd?: string;
  totalReturnRatio: string;
  goldReturnRatio: string;
  fxReturnRatio: string;
  totalReturnPct: string;
  goldAlphaPct: string;
  fxImpactPct: string;
  goldPriceContributionTHB: string;
  fxContributionTHB: string;
  rawGoldPriceContributionTHB: string;
  rawFxContributionTHB: string;
  unexplainedResidualTHB: string;
  isZeroResidualVerified: boolean;
  goldDriverState: GoldDriverState;
  goldDriverLabelTH: string;
  goldDriverLabelEN: string;
  fxDriverState: FxDriverState;
  fxDriverLabelTH: string;
  fxDriverLabelEN: string;
  primaryDriver: BrinsonPrimaryDriver;
  driverSummaryTH: string;
  driverSummaryEN: string;
  formulaProof: {
    multiplicativeIdentity: string;
    goldContributionFormula: string;
    fxContributionFormula: string;
    zeroResidualCheck: string;
  };
}

export interface PortfolioGoldBrinsonReport {
  gtaParity: GtaGold965ParityBreakdown;
  unrealizedItems: MultiplicativeBrinsonItem[];
  unrealizedSummary: MultiplicativeBrinsonItem;
  realizedItems: MultiplicativeBrinsonItem[];
  realizedSummary: MultiplicativeBrinsonItem;
}

export interface GoldFXSensitivity {
  symbol: string;
  assetSubclass?: GoldAssetSubclass;
  costBasisTHB?: string;
  marketValueTHB?: string;
  totalGLTHB?: string;
  entryUsdThb?: string;
  currentUsdThb?: string;
  totalReturnPct: string;
  goldAlphaPct: string;
  fxImpactPct: string;
  goldReturnRatio?: string;
  fxReturnRatio?: string;
  totalReturnRatio?: string;
  goldDriverState?: GoldDriverState;
  goldDriverLabelTH?: string;
  goldDriverLabelEN?: string;
  fxDriverState?: FxDriverState;
  fxDriverLabelTH?: string;
  fxDriverLabelEN?: string;
  primaryDriver?: BrinsonPrimaryDriver;
  driverSummaryTH?: string;
  driverSummaryEN?: string;
  unexplainedResidualTHB?: string;
  isZeroResidualVerified?: boolean;
  attribution: {
    goldPriceContribution: string;
    fxContribution: string;
  };
}

export interface GoldPortfolioBreakdown {
  physicalGold: {
    totalWeight: string;
    totalValueTHB: string;
    percentage: string;
  };
  paperGold: {
    totalWeight: string;
    totalValueTHB: string;
    percentage: string;
    marginRequirement?: string;
  };
}

export interface GoldMarketEnvironment {
  xauUsdSpot: string;
  usdThbRate: string;
  gtaGold965SellTHB: string;
  theoreticalGold965THB: string;
  domesticPremiumTHB: string;
  domesticPremiumPct: string;
}

export interface GoldSensitivityMatrixCell {
  goldShockPct: string;
  fxShockPct: string;
  projectedXauUsd: string;
  projectedUsdThb: string;
  projectedGold965THB: string;
  projectedPortfolioValueTHB: string;
  projectedNetGLTHB: string;
  projectedReturnPct: string;
}

export interface GoldOverviewSummary {
  portfolioId: string;
  market: GoldMarketEnvironment;
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  taxExemptRealizedGLTHB?: string;
  taxableRealizedGLTHB?: string;
  totalUnrealizedGLTHB: string;
  totalPremiumPaidTHB: string;
  premiumDragPct: string;
  totalEquivalentBaht965: string;
  totalFineGoldGrams: string;
  lots: GoldLot[];
  taxHandoffRecords?: GoldTaxHandoffRecord[];
  transactions: GoldTransaction[];
  fxSensitivities: GoldFXSensitivity[];
  brinsonAttribution?: PortfolioGoldBrinsonReport;
  breakdown: GoldPortfolioBreakdown;
  sensitivityMatrix: GoldSensitivityMatrixCell[];
}
