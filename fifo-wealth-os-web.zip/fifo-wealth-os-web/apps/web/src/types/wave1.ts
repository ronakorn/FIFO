import { Lot } from './shared';

export type HarvestingOpportunityStatus = 'AVAILABLE' | 'WASH_SALE_RISK';

export interface HarvestingInput {
  symbol: string;
  avgCost: string;
  currentPrice: string;
  qty: number;
  daysHeld: number;
  marginalTaxRate?: string;
  lotId?: string;
}

export interface TaxLossHarvestingOpportunity {
  lotId: string;
  symbol: string;
  qtyRemain?: string;
  currentPrice: string;
  avgCost: string;
  unrealizedLoss: string;
  daysHeld: number;
  taxSavingPotential: string;
  marginalTaxRate: string;
  washSaleRisk: boolean;
  status: HarvestingOpportunityStatus;
  washSaleNote?: string | null;
}

export interface HarvestingSimulation {
  totalTaxSaving: string;
  newTaxLiability: string;
  harvestedLots: string[];
  washSaleWarnings: string[];
  totalHarvestedLoss: string;
  currentTaxLiability?: string;
  selectedCount?: number;
}

export type HarvestingSimulationResult = HarvestingSimulation;

export type CorporateActionType = 'STOCK_SPLIT' | 'REVERSE_SPLIT';

export interface CorporateActionLot {
  id: string;
  symbol: string;
  qty: number;
  costPerUnit: string;
  date: string;
}

export interface LotBeforeAfterPreview {
  lotId: string;
  symbol: string;
  date: string;
  daysHeldBefore: number;
  daysHeldAfter: number;
  qtyBefore: string;
  qtyAfter: string;
  costPerUnitBefore: string;
  costPerUnitAfter: string;
  totalCostBasisBefore: string;
  totalCostBasisAfter: string;
  affected: boolean;
}

export interface SplitAdjustmentPreview {
  actionId: string;
  symbol: string;
  type: CorporateActionType;
  ratio: number;
  effectiveDate: string;
  affectedLotCount: number;
  totalCostBeforeTHB: string;
  totalCostAfterTHB: string;
  isCostBasisPreserved: boolean;
  isDaysHeldPreserved: boolean;
  lotPreviews: LotBeforeAfterPreview[];
}

export interface CorporateAction {
  id: string;
  symbol: string;
  type: CorporateActionType;
  ratio: number;
  effectiveDate: string;
  announcementDate?: string;
  adjustmentFactor: number | string;
  description?: string;
  title?: string;
  applied?: boolean;
  source?: 'IBKR_FLEX' | 'MARKET_FEED';
  preview?: SplitAdjustmentPreview;
}

export interface ApplyCorporateActionResult {
  action: CorporateAction;
  preview?: SplitAdjustmentPreview;
  alreadyApplied?: boolean;
  beforeLots: Lot[];
  adjustedLots: Lot[];
  totalCostBeforeTHB: string;
  totalCostAfterTHB: string;
}

export interface DividendForecast {
  symbol: string;
  exDate: string;
  payDate: string;
  amountPerShare: string;
  sharesHeld: number | string;
  currency: string;
  fxRate?: string;
}

export type DividendFrequency =
  | 'MONTHLY'
  | 'QUARTERLY'
  | 'SEMI_ANNUAL'
  | 'ANNUAL';

export interface DividendEvent {
  id?: string;
  symbol: string;
  exDate: string;
  payDate: string;
  amountPerShare: string;
  currency: string;
  estimatedTHB: string;
  frequency?: DividendFrequency;
  isForecast?: boolean;
  sharesHeld?: string;
}

export interface MonthlyDividendSummary {
  month: number;
  year: number;
  totalDividends: string;
  dividendCount: number;
  averageMonthlyIncome: string;
}

export interface MonthlyDividendBucket {
  month: number;
  monthKey: string;
  monthNameTH: string;
  actualTHB: string;
  forecastTHB: string;
  totalTHB: string;
  eventCount: number;
  events: DividendEvent[];
}

export interface DividendCalendarReport {
  year: number;
  events: DividendEvent[];
  monthlyIncome: MonthlyDividendBucket[];
  yearlyDividendTHB: string;
  averageMonthlyTHB: string;
  upcomingDividends: DividendEvent[];
}
