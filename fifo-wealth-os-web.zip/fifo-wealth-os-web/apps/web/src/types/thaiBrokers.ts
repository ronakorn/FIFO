export type ThaiBrokerId = 'BITKUB' | 'DIME' | 'STREAMING';

export type ThaiBrokerConnectionMode =
  | 'READ_ONLY_API'
  | 'OPEN_API_HYBRID'
  | 'SECURE_STATEMENT_AUTOMATION';

export type ThaiBrokerDataSource =
  | 'NOT_TESTED'
  | 'SANDBOX_MOCK'
  | 'LIVE_PARTNER_API';

export type ThaiBrokerSyncStatus =
  | 'CONNECTED'
  | 'SYNCING'
  | 'ERROR'
  | 'DISCONNECTED';

export interface ThaiBrokerConnectionPublic {
  id: string | null;
  broker: ThaiBrokerId;
  displayName: string;
  regulatoryBadge: string;
  partnerBadge: string;
  connectionMode: ThaiBrokerConnectionMode;
  dataSource: ThaiBrokerDataSource;
  maskedAccountRef: string | null;
  portfolioId: string | null;
  status: ThaiBrokerSyncStatus;
  connected: boolean;
  readOnly: true;
  encryption: 'AES-256-GCM';
  pdpaConsented: boolean;
  pdpaConsentedAt: string | null;
  pdpaConsentVersion: string | null;
  lastSyncedAt: string | null;
  futureRoadmapNote: string | null;
}

export interface ThaiBrokerSyncResult {
  broker: ThaiBrokerId;
  connectionMode: ThaiBrokerConnectionMode;
  dataSource: ThaiBrokerDataSource;
  portfolioId: string;
  addedTransactions: number;
  addedDividends: number;
  skippedTransactions: number;
  skippedDividends: number;
  status: ThaiBrokerSyncStatus;
  lastSyncedAt: string;
}

export interface ThaiBrokerDisconnectResult {
  broker: ThaiBrokerId;
  disconnected: true;
  credentialsPurged: true;
  pdpaConsentRevoked: true;
  purgedTransactionsCount: number;
  purgedDividendsCount: number;
  connection: ThaiBrokerConnectionPublic;
}
