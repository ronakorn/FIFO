export type BrokerSyncStatus =
  | 'CONNECTED'
  | 'SYNCING'
  | 'ERROR'
  | 'DISCONNECTED';

export interface BrokerConnectionPublic {
  id: string | null;
  brokerName: 'IBKR';
  flexQueryId: string | null;
  portfolioId: string | null;
  status: BrokerSyncStatus;
  connected: boolean;
  lastSyncedAt: string | null;
  createdAt: string | null;
  readOnly: true;
  encryption: 'AES-256-GCM';
}

export interface ManualSyncResult {
  addedTransactions: number;
  addedDividends: number;
  skippedTransactions: number;
  skippedDividends: number;
  portfolioId: string;
  status: BrokerSyncStatus;
  lastSyncedAt: string;
}
