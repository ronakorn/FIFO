import type { GoldPurity, GoldTransaction, GoldWeightUnit } from './gold';

export type RolloverLegAction =
  | 'OPEN_LONG'
  | 'CLOSE_LONG'
  | 'OPEN_SHORT'
  | 'CLOSE_SHORT';

export type ExpiryAlertSeverity =
  | 'EXPIRED'
  | 'CRITICAL_1D'
  | 'URGENT_3D'
  | 'WARNING_7D'
  | 'UPCOMING_30D'
  | 'SAFE';

export type MarketStructureRegime = 'CONTANGO' | 'BACKWARDATION' | 'FLAT';

export interface FuturesContractSpec {
  symbol: string;
  exchange: 'TFEX' | 'COMEX';
  contractMonth: string;
  expirationDate: string;
  noticeDate: string;
  suggestedNextSymbol: string;
  suggestedNextMonth: string;
  suggestedNextExpirationDate: string;
  currentMarketPriceUSD: string;
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
}

export interface ExpiringContractAlert {
  lotId: string;
  transactionId: string;
  symbol: string;
  contractMonth: string;
  expirationDate: string;
  daysToExpiry: number;
  severity: ExpiryAlertSeverity;
  shouldPlayAudioAlert: boolean;
  openWeight: string;
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
  entryCostPerUnitTHB: string;
  currentFrontPriceUSD: string;
  suggestedBackSymbol: string;
  suggestedBackMonth: string;
  suggestedBackExpirationDate: string;
  suggestedBackPriceUSD: string;
  estimatedSpreadPerUnitUSD: string;
  regime: MarketStructureRegime;
  alertMessageTH: string;
  alertMessageEN: string;
}

export interface RolloverSpreadAnalytics {
  frontSymbol: string;
  backSymbol: string;
  weight: string;
  weightUnit: GoldWeightUnit;
  frontClosePriceUSD: string;
  backOpenPriceUSD: string;
  fxRateUSDTHB: string;
  spreadPerUnitUSD: string;
  spreadPerUnitTHB: string;
  regime: MarketStructureRegime;
  totalSpreadCostUSD: string;
  totalSpreadCostTHB: string;
  totalCommissionTHB: string;
  netRolloverFrictionTHB: string;
  estimatedCloseRealizedGLTHB: string;
  newBackContractCostBasisTHB: string;
}

export interface RolloverHistoryItem {
  rolloverGroupId: string;
  executedDate: string;
  frontSymbol: string;
  frontContractMonth: string;
  backSymbol: string;
  backContractMonth: string;
  rolledWeight: string;
  weightUnit: GoldWeightUnit;
  frontClosePriceUSD: string;
  backOpenPriceUSD: string;
  rolloverSpreadUSD: string;
  regime: MarketStructureRegime;
  spreadCostTHB: string;
  realizedGLClosedLegTHB: string;
  newOpenCostBasisTHB: string;
}

export interface ExecuteRolloverResult {
  rolloverGroupId: string;
  closeTransaction: GoldTransaction;
  openTransaction: GoldTransaction;
  analytics: RolloverSpreadAnalytics;
}

export interface ContractRolloverOverview {
  portfolioId: string;
  asOfDate: string;
  usdThbRate: string;
  contractCatalog: FuturesContractSpec[];
  activeAlerts: ExpiringContractAlert[];
  rolloverHistory: RolloverHistoryItem[];
  summary: {
    activeFuturesContractsCount: number;
    urgentExpiringCount: number;
    totalRolloversExecuted: number;
    cumulativeSpreadCostTHB: string;
    cumulativeRealizedOnRolloversTHB: string;
    netRolloverImpactPct: string;
  };
}
