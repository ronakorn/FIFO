export interface CashFlow {
  date: string;
  amount: string;
}

export interface PortfolioMetrics {
  /** Extended Internal Rate of Return as decimal string (e.g. "0.2000" = 20.00%) */
  xirr: string;
  /** Time-Weighted Return as decimal string (e.g. "0.1540" = 15.40%) */
  sharpeRatio: string;
  sortinoRatio: string;
  twr: string;
  /** Maximum Peak-to-Trough decline as decimal string (e.g. "0.1250" = 12.50% max drop) */
  maxDrawdown: string;
  /** Simple cumulative return over period as decimal string */
  totalReturn: string;
}

export type BenchmarkSymbol = 'SET50' | 'SP500';

export interface BenchmarkData {
  date: string;
  portfolioValue: number;
  benchmarkValue: number;
  portfolioReturnPct?: number;
  benchmarkReturnPct?: number;
}

export type AssetClassCategory =
  | 'THAI_EQUITY'
  | 'FOREIGN_EQUITY'
  | 'CRYPTO'
  | 'GOLD'
  | 'CASH';

export interface AssetClassAllocation {
  category: AssetClassCategory;
  label: string;
  enLabel: string;
  valueTHB: string;
  weightPct: string;
  color: string;
}

export interface DashboardAnalyticsResponse {
  scope: string;
  benchmark: BenchmarkSymbol;
  riskFreeRateAnnual: string;
  asOfDate: string;
  metrics: PortfolioMetrics;
  benchmarkSeries: BenchmarkData[];
  assetAllocation: AssetClassAllocation[];
}
