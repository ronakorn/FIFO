export type FamilyRole = 'OWNER' | 'VIEWER';

export interface FamilyPermissions {
  canSeeTransactions: boolean;
  canSeeTotalNetWorth: boolean;
}

export interface FamilyMemberSummary {
  memberId: string;
  userId: string;
  name: string;
  role: FamilyRole;
  netWorthTHB: string;      // Decimal string
  sharePercent: string;     // Decimal string "0.00" - "100.00"
  portfolioCount: number;
  permissions: FamilyPermissions;
  isCurrentUser: boolean;
}

export interface FamilyGroupInfo {
  id: string;
  name: string;
  inviteCode: string;
  createdByUserId: string;
  currentUserRole: FamilyRole;
  currentUserPermissions: FamilyPermissions;
  createdAt: string;
}

export interface FamilyDashboardResponse {
  hasGroup: boolean;
  group: FamilyGroupInfo | null;
  householdNetWorthTHB: string; // Decimal string SUM across members
  memberCount: number;
  members: FamilyMemberSummary[];
  privacyGuarantee: {
    transactionsExposed: false;
    aggregationEngine: 'Decimal.js-40';
  };
}
