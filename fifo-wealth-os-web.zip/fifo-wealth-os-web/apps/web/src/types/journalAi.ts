export type JournalMood = 'BULLISH' | 'BEARISH' | 'NEUTRAL';

export interface JournalEntryItem {
  id: string;
  userId: string;
  portfolioId: string | null;
  portfolioName?: string | null;
  date: string; // YYYY-MM-DD
  title: string;
  content: string;
  mood: JournalMood;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface ChatSessionItem {
  id: string;
  userId: string;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt?: string;
}

export interface AIChatResponse {
  sessionId: string;
  reply: string;
  messages: ChatMessage[];
  contextSummary: {
    netWorthTHB: string;
    totalRealizedGLTHB: string;
    bestMonth: string;
    bestMonthGainTHB: string;
    xirr: string;
    sharpeRatio: string;
  };
}
