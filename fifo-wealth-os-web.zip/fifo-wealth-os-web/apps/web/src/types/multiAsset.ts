import type { MultiAssetPortfolioSummary, MultiAssetTransaction } from '@fifo/types';

export type MultiAssetTransactionDto = Omit<MultiAssetTransaction, 'createdAt'> & {
  createdAt: string;
};

export type MultiAssetTransactionInput = Omit<
  MultiAssetTransaction,
  'id' | 'portfolioId' | 'createdAt'
>;

export interface MultiAssetApiResponse {
  transactions: MultiAssetTransactionDto[];
  summary: MultiAssetPortfolioSummary;
  dateOfBirth: string | null;
  lastUpdatedAt: {
    bonds: string | null;
    funds: string | null;
    metals: string | null;
    forex: string | null;
  };
}
