'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import Decimal from 'decimal.js';

export const LiveGoldDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type LiveTickDirection = 'UP' | 'DOWN' | 'FLAT';
export type LiveFeedStatus = 'LIVE' | 'PAUSED';

export interface UseLiveGoldPricesOptions {
  initialXauUsd?: string;
  initialUsdThb?: string;
  intervalMs?: number;
  autoStart?: boolean;
}

export interface LiveGoldPriceFeed {
  xauUsd: string;
  usdThb: string;
  xauDelta: string;
  fxDelta: string;
  xauDirection: LiveTickDirection;
  fxDirection: LiveTickDirection;
  status: LiveFeedStatus;
  tickCount: number;
  lastUpdatedTime: string | null;
  intervalMs: number;
  toggleLiveFeed: () => void;
  simulateNextTick: () => void;
  setBaselinePrices: (nextXauUsd: string, nextUsdThb: string) => void;
}

const XAU_TICK_BPS: readonly string[] = [
  '0.0008',
  '-0.0005',
  '0.0011',
  '-0.0007',
  '0.0006',
  '-0.0009',
  '0.0012',
  '-0.0004',
];

const FX_TICK_BPS: readonly string[] = [
  '0.0005',
  '0.0003',
  '-0.0006',
  '0.0004',
  '-0.0003',
  '0.0007',
  '-0.0005',
  '0.0002',
];

/**
 * Custom React Hook simulating a real-time WebSocket / 10-second polling feed
 * for World Gold Spot (`xauUsd`) and Thai Baht FX (`usdThb`) using `Decimal.js` (precision: 40).
 */
export function useLiveGoldPrices(
  options: UseLiveGoldPricesOptions = {}
): LiveGoldPriceFeed {
  const {
    initialXauUsd = '2740.00',
    initialUsdThb = '35.6000',
    intervalMs = 10_000,
    autoStart = true,
  } = options;

  const anchorXauRef = useRef<InstanceType<typeof LiveGoldDecimal>>(
    new LiveGoldDecimal(initialXauUsd)
  );
  const anchorFxRef = useRef<InstanceType<typeof LiveGoldDecimal>>(
    new LiveGoldDecimal(initialUsdThb)
  );
  const stepIndexRef = useRef<number>(0);

  const [xauUsd, setXauUsd] = useState<string>(() =>
    new LiveGoldDecimal(initialXauUsd).toFixed(2)
  );
  const [usdThb, setUsdThb] = useState<string>(() =>
    new LiveGoldDecimal(initialUsdThb).toFixed(4)
  );
  const [xauDelta, setXauDelta] = useState<string>('0.00');
  const [fxDelta, setFxDelta] = useState<string>('0.0000');
  const [xauDirection, setXauDirection] = useState<LiveTickDirection>('FLAT');
  const [fxDirection, setFxDirection] = useState<LiveTickDirection>('FLAT');
  const [status, setStatus] = useState<LiveFeedStatus>(
    autoStart ? 'LIVE' : 'PAUSED'
  );
  const [tickCount, setTickCount] = useState<number>(0);
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string | null>(null);

  const setBaselinePrices = useCallback(
    (nextXauUsd: string, nextUsdThb: string) => {
      const cleanXau = new LiveGoldDecimal(nextXauUsd);
      const cleanFx = new LiveGoldDecimal(nextUsdThb);
      anchorXauRef.current = cleanXau;
      anchorFxRef.current = cleanFx;
      setXauUsd(cleanXau.toFixed(2));
      setUsdThb(cleanFx.toFixed(4));
      setXauDelta('0.00');
      setFxDelta('0.0000');
      setXauDirection('FLAT');
      setFxDirection('FLAT');
    },
    []
  );

  const simulateNextTick = useCallback(() => {
    const idx = stepIndexRef.current % XAU_TICK_BPS.length;
    stepIndexRef.current += 1;

    const xauMoveRatio = new LiveGoldDecimal(XAU_TICK_BPS[idx] ?? '0.0005');
    const fxMoveRatio = new LiveGoldDecimal(FX_TICK_BPS[idx] ?? '0.0003');
    const meanReversionWeight = new LiveGoldDecimal('0.25');

    setXauUsd((prevXauStr) => {
      const prevXau = new LiveGoldDecimal(prevXauStr);
      const pullToAnchor = anchorXauRef.current
        .minus(prevXau)
        .times(meanReversionWeight);
      const rawStep = prevXau.times(xauMoveRatio).plus(pullToAnchor);
      const nextXau = LiveGoldDecimal.max(
        new LiveGoldDecimal('100'),
        prevXau.plus(rawStep)
      );
      const diff = nextXau.minus(prevXau);

      setXauDelta(diff.toFixed(2));
      setXauDirection(diff.gt(0) ? 'UP' : diff.lt(0) ? 'DOWN' : 'FLAT');
      return nextXau.toFixed(2);
    });

    setUsdThb((prevFxStr) => {
      const prevFx = new LiveGoldDecimal(prevFxStr);
      const pullToAnchor = anchorFxRef.current
        .minus(prevFx)
        .times(meanReversionWeight);
      const rawStep = prevFx.times(fxMoveRatio).plus(pullToAnchor);
      const nextFx = LiveGoldDecimal.max(
        new LiveGoldDecimal('10'),
        prevFx.plus(rawStep)
      );
      const diff = nextFx.minus(prevFx);

      setFxDelta(diff.toFixed(4));
      setFxDirection(diff.gt(0) ? 'UP' : diff.lt(0) ? 'DOWN' : 'FLAT');
      return nextFx.toFixed(4);
    });

    setTickCount((c) => c + 1);
    const now = new Date();
    setLastUpdatedTime(
      now.toLocaleTimeString('th-TH', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      })
    );
  }, []);

  const toggleLiveFeed = useCallback(() => {
    setStatus((prev) => (prev === 'LIVE' ? 'PAUSED' : 'LIVE'));
  }, []);

  useEffect(() => {
    if (status !== 'LIVE') return;
    const timerId = window.setInterval(() => {
      simulateNextTick();
    }, intervalMs);

    return () => {
      window.clearInterval(timerId);
    };
  }, [status, intervalMs, simulateNextTick]);

  return {
    xauUsd,
    usdThb,
    xauDelta,
    fxDelta,
    xauDirection,
    fxDirection,
    status,
    tickCount,
    lastUpdatedTime,
    intervalMs,
    toggleLiveFeed,
    simulateNextTick,
    setBaselinePrices,
  };
}
