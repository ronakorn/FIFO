import { createAuthenticatedApiClient } from '@fifo/api';
import { TOKEN_STORAGE_KEY } from './authStorage';
import { useAuthStore } from './stores';

export { TOKEN_STORAGE_KEY, USER_STORAGE_KEY } from './authStorage';

const authenticatedClient = createAuthenticatedApiClient({
  baseURL: process.env.NEXT_PUBLIC_API_BASE_URL || '/api',
  timeoutMs: 30_000,
  getAccessToken: async () => {
    if (typeof window === 'undefined') return null;
    return window.localStorage.getItem(TOKEN_STORAGE_KEY);
  },
});

export const api = authenticatedClient.client;

// Keep Zustand and localStorage in sync when a protected request rejects an expired token.
authenticatedClient.registerUnauthorizedHandler(() => {
  if (typeof window !== 'undefined') useAuthStore.getState().logout();
});

export default api;
