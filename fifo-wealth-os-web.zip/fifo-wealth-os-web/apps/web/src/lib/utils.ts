import axios from 'axios';
import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

export function formatTHB(value: number | string | null | undefined): string {
  const num = typeof value === 'string' ? Number(value) : (value ?? 0);
  const safe = Number.isFinite(num) ? num : 0;
  return new Intl.NumberFormat('th-TH', {
    style: 'currency',
    currency: 'THB',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(safe);
}

export function formatSignedTHB(value: number | string | null | undefined): string {
  const num = typeof value === 'string' ? Number(value) : (value ?? 0);
  const safe = Number.isFinite(num) ? num : 0;
  const formatted = new Intl.NumberFormat('th-TH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Math.abs(safe));
  if (safe > 0) return `+฿${formatted}`;
  if (safe < 0) return `-฿${formatted}`;
  return `฿${formatted}`;
}

export function formatCurrencyAmount(
  value: number | string | null | undefined,
  currency = 'THB'
): string {
  const num = typeof value === 'string' ? Number(value) : (value ?? 0);
  const safe = Number.isFinite(num) ? num : 0;
  return `${new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(safe)} ${currency}`;
}

export function formatQuantity(qty: number): string {
  if (!Number.isFinite(qty)) return '0';
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: qty % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 6,
  }).format(qty);
}

export function formatDateShort(isoDate: string, locale = 'en-GB'): string {
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return isoDate;
  return new Intl.DateTimeFormat(locale, {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(parsed);
}

export function extractApiErrorMessage(error: unknown, fallback = 'เกิดข้อผิดพลาดในการเชื่อมต่อระบบ'): string {
  if (axios.isAxiosError(error)) {
    const data = error.response?.data as
      | { error?: { message?: string; code?: string }; message?: string }
      | undefined;
    if (data?.error?.message) {
      return data.error.message;
    }
    if (data?.message) {
      return data.message;
    }
    if (error.message) {
      return error.message;
    }
  }
  if (error instanceof Error) {
    return error.message;
  }
  return fallback;
}
