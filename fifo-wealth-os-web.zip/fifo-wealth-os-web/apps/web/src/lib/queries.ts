import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import api from './api';
import { useAuthStore } from './stores';
import {
  AuthResponse,
  Portfolio,
  TaxReport,
  Transaction,
  UploadCSVResponse,
  UploadDividendsResponse,
  User,
} from '@/types/shared';
import { BenchmarkSymbol, DashboardAnalyticsResponse } from '@/types/analytics';
import {
  FIREGoal,
  FIRESummaryResponse,
  GoalProgress,
  MonteCarloResult,
} from '@/types/fire';
import { FamilyDashboardResponse, FamilyPermissions } from '@/types/family';
import {
  AIChatResponse,
  JournalEntryItem,
  JournalMood,
} from '@/types/journalAi';

// ============================================================================
// Authentication Hooks
// ============================================================================

export function useCurrentUser() {
  const token = useAuthStore((s) => s.token);
  const setUser = useAuthStore((s) => s.setUser);

  return useQuery<User>({
    queryKey: ['currentUser', token],
    enabled: Boolean(token),
    retry: false,
    staleTime: 60_000,
    queryFn: async () => {
      const { data } = await api.get<{ user: User }>('/auth/me');
      setUser(data.user);
      return data.user;
    },
  });
}

export function useLoginMutation() {
  const setAuth = useAuthStore((s) => s.setAuth);
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { email: string; password: string }) => {
      const { data } = await api.post<AuthResponse>('/auth/login', payload);
      return data;
    },
    onSuccess: (data) => {
      setAuth(data.user, data.token);
      queryClient.invalidateQueries({ queryKey: ['portfolios'] });
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });
}

export function useRegisterMutation() {
  const setAuth = useAuthStore((s) => s.setAuth);
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { email: string; password: string; name: string }) => {
      const { data } = await api.post<AuthResponse>('/auth/register', payload);
      return data;
    },
    onSuccess: (data) => {
      setAuth(data.user, data.token);
      queryClient.invalidateQueries({ queryKey: ['portfolios'] });
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });
}

// ============================================================================
// Portfolio Hooks
// ============================================================================

export function usePortfolios() {
  const token = useAuthStore((s) => s.token);

  return useQuery<Portfolio[]>({
    queryKey: ['portfolios'],
    enabled: Boolean(token),
    staleTime: 30_000,
    queryFn: async () => {
      const { data } = await api.get<Portfolio[]>('/portfolios');
      return data;
    },
  });
}

export function usePortfolio(portfolioId: string | undefined) {
  const token = useAuthStore((s) => s.token);

  return useQuery<Portfolio>({
    queryKey: ['portfolio', portfolioId],
    enabled: Boolean(token && portfolioId && !portfolioId.startsWith('mock-')),
    staleTime: 20_000,
    queryFn: async () => {
      const { data } = await api.get<Portfolio>(`/portfolios/${portfolioId}`);
      return data;
    },
  });
}

export function useCreatePortfolio() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { name: string; baseCurrency: string }) => {
      const { data } = await api.post<Portfolio>('/portfolios', payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['portfolios'] });
    },
  });
}

export function useDeletePortfolio() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (portfolioId: string) => {
      const { data } = await api.delete<{ id: string; message: string }>(
        `/portfolios/${portfolioId}`
      );
      return data;
    },
    onSuccess: (_res, portfolioId) => {
      queryClient.invalidateQueries({ queryKey: ['portfolios'] });
      queryClient.removeQueries({ queryKey: ['portfolio', portfolioId] });
      queryClient.removeQueries({ queryKey: ['transactions', portfolioId] });
    },
  });
}

// ============================================================================
// Transactions & CSV Upload Hooks
// ============================================================================

export interface TransactionFilterParams {
  symbol?: string;
  type?: 'BUY' | 'SELL' | 'ALL';
  startDate?: string;
  endDate?: string;
}

export function useTransactions(
  portfolioId: string | undefined,
  filters?: TransactionFilterParams
) {
  const token = useAuthStore((s) => s.token);

  return useQuery<Transaction[]>({
    queryKey: ['transactions', portfolioId, filters ?? {}],
    enabled: Boolean(token && portfolioId && !portfolioId.startsWith('mock-')),
    staleTime: 15_000,
    queryFn: async () => {
      const params: Record<string, string> = {};
      if (filters?.symbol && filters.symbol.trim()) {
        params['symbol'] = filters.symbol.trim().toUpperCase();
      }
      if (filters?.type && filters.type !== 'ALL') {
        params['type'] = filters.type;
      }
      if (filters?.startDate) {
        params['startDate'] = filters.startDate;
      }
      if (filters?.endDate) {
        params['endDate'] = filters.endDate;
      }

      const { data } = await api.get<
        | Transaction[]
        | {
            portfolioId: string;
            count: number;
            transactions: Transaction[];
          }
      >(`/transactions/${portfolioId}`, { params });
      return Array.isArray(data) ? data : data.transactions;
    },
  });
}

export function useUploadCSV() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      file,
      portfolioId,
      exchange,
    }: {
      file: File;
      portfolioId: string;
      exchange: 'BITKUB' | 'IBKR';
    }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('portfolioId', portfolioId);
      formData.append('exchange', exchange);

      const { data } = await api.post<UploadCSVResponse>('/upload/csv', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return data;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['portfolios'] });
      queryClient.invalidateQueries({ queryKey: ['portfolio', variables.portfolioId] });
      queryClient.invalidateQueries({ queryKey: ['transactions', variables.portfolioId] });
      queryClient.invalidateQueries({ queryKey: ['taxSummary', variables.portfolioId] });
      queryClient.invalidateQueries({ queryKey: ['dashboardAnalytics'] });
    },
  });
}

export function useUploadDividends() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ file, portfolioId }: { file: File; portfolioId: string }) => {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('portfolioId', portfolioId);

      const { data } = await api.post<UploadDividendsResponse>('/upload/dividends', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      return data;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['portfolios'] });
      queryClient.invalidateQueries({ queryKey: ['portfolio', variables.portfolioId] });
      queryClient.invalidateQueries({ queryKey: ['taxSummary', variables.portfolioId] });
    },
  });
}

// ============================================================================
// Quantitative Portfolio Analytics Hook
// ============================================================================

export function useDashboardAnalytics(
  benchmark: BenchmarkSymbol = 'SP500',
  portfolioId?: string
) {
  const token = useAuthStore((s) => s.token);

  return useQuery<DashboardAnalyticsResponse>({
    queryKey: ['dashboardAnalytics', benchmark, portfolioId ?? 'ALL'],
    enabled: Boolean(token),
    staleTime: 20_000,
    queryFn: async () => {
      const params: Record<string, string> = { benchmark };
      if (portfolioId && !portfolioId.startsWith('mock-')) {
        params['portfolioId'] = portfolioId;
      }
      const { data } = await api.get<DashboardAnalyticsResponse>(
        '/analytics/dashboard',
        { params }
      );
      return data;
    },
  });
}

// ============================================================================
// Thai Tax Compliance & PDF Report Hooks
// ============================================================================

export function useTaxSummary(portfolioId: string | undefined, year: number) {
  const token = useAuthStore((s) => s.token);

  return useQuery<TaxReport>({
    queryKey: ['taxSummary', portfolioId, year],
    enabled: Boolean(
      token &&
        portfolioId &&
        !portfolioId.startsWith('mock-') &&
        Number.isInteger(year) &&
        year >= 2000
    ),
    staleTime: 15_000,
    queryFn: async () => {
      const { data } = await api.get<TaxReport>(`/tax/summary/${portfolioId}/${year}`);
      return data;
    },
  });
}

export async function downloadTaxReportPDF(portfolioId: string, year: number): Promise<void> {
  const response = await api.get<Blob>(`/tax/report/${portfolioId}/${year}`, {
    responseType: 'blob',
  });

  const blob = new Blob([response.data], { type: 'application/pdf' });
  const downloadUrl = window.URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = `FIFO_Wealth_OS_Tax_Report_${year}_${portfolioId.slice(0, 8)}.pdf`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.URL.revokeObjectURL(downloadUrl);
}

// ============================================================================
// Goals & FIRE Planner Hooks (/api/fire)
// ============================================================================

export function useFireSummary() {
  const token = useAuthStore((s) => s.token);

  return useQuery<FIRESummaryResponse>({
    queryKey: ['fireSummary'],
    enabled: Boolean(token),
    staleTime: 15_000,
    queryFn: async () => {
      const { data } = await api.get<FIRESummaryResponse>('/fire/summary');
      return data;
    },
  });
}

export function useFireGoals() {
  const token = useAuthStore((s) => s.token);

  return useQuery<FIREGoal[]>({
    queryKey: ['fireGoals'],
    enabled: Boolean(token),
    staleTime: 15_000,
    queryFn: async () => {
      const { data } = await api.get<FIREGoal[]>('/fire/goals');
      return data;
    },
  });
}

export function useFireGoalProgress(goalId: string | undefined) {
  const token = useAuthStore((s) => s.token);

  return useQuery<GoalProgress & { livePortfolioValueTHB: string }>({
    queryKey: ['fireGoalProgress', goalId],
    enabled: Boolean(token && goalId && !goalId.startsWith('mock-')),
    staleTime: 15_000,
    queryFn: async () => {
      const { data } = await api.get<GoalProgress & { livePortfolioValueTHB: string }>(
        `/fire/goals/${goalId}/progress`
      );
      return data;
    },
  });
}

export interface UpsertFireGoalPayload {
  name: string;
  targetAmount: string;
  currentAmount?: string;
  monthlyContribution: string;
  expectedReturn: string;
  inflationRate?: string;
  targetYear: number;
  currentAge: number;
  retirementAge: number;
}

export function useCreateFireGoal() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: UpsertFireGoalPayload) => {
      const { data } = await api.post<FIREGoal>('/fire/goals', payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fireGoals'] });
      queryClient.invalidateQueries({ queryKey: ['fireSummary'] });
    },
  });
}

export function useUpdateFireGoal() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      payload,
    }: {
      id: string;
      payload: Partial<UpsertFireGoalPayload>;
    }) => {
      const { data } = await api.put<FIREGoal>(`/fire/goals/${id}`, payload);
      return data;
    },
    onSuccess: (_res, vars) => {
      queryClient.invalidateQueries({ queryKey: ['fireGoals'] });
      queryClient.invalidateQueries({ queryKey: ['fireSummary'] });
      queryClient.invalidateQueries({ queryKey: ['fireGoalProgress', vars.id] });
    },
  });
}

export function useDeleteFireGoal() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (goalId: string) => {
      const { data } = await api.delete<{ id: string; message: string }>(
        `/fire/goals/${goalId}`
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fireGoals'] });
      queryClient.invalidateQueries({ queryKey: ['fireSummary'] });
    },
  });
}

export function useRunMonteCarloMutation() {
  return useMutation({
    mutationFn: async (payload: {
      currentAmount: string;
      monthlyContribution: string;
      expectedReturn: string;
      volatility: string;
      years: number;
      numSimulations: number;
      seed?: string;
      targetAmount?: string;
    }) => {
      const { data } = await api.post<MonteCarloResult>('/fire/monte-carlo', payload);
      return data;
    },
  });
}

// ============================================================================
// Wealth Journal & AI Wealth Assistant Hooks
// ============================================================================

export function useJournalEntries(month?: string, portfolioId?: string) {
  const token = useAuthStore((s) => s.token);

  return useQuery<JournalEntryItem[]>({
    queryKey: ['journalEntries', month ?? 'ALL', portfolioId ?? 'ALL', token],
    enabled: Boolean(token),
    staleTime: 10_000,
    queryFn: async () => {
      const params: Record<string, string> = {};
      if (month) params['month'] = month;
      if (portfolioId && !portfolioId.startsWith('mock-')) {
        params['portfolioId'] = portfolioId;
      }
      const { data } = await api.get<JournalEntryItem[]>('/journal', { params });
      return data;
    },
  });
}

export function useCreateJournalEntry() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: {
      date: string;
      title: string;
      content: string;
      mood: JournalMood;
      portfolioId?: string | null;
    }) => {
      const { data } = await api.post<JournalEntryItem>('/journal', payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['journalEntries'] });
    },
  });
}

export function useDeleteJournalEntry() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (entryId: string) => {
      const { data } = await api.delete<{ deleted: boolean; id: string }>(
        `/journal/${entryId}`
      );
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['journalEntries'] });
    },
  });
}

export function useAIChatMutation() {
  return useMutation({
    mutationFn: async (payload: {
      message: string;
      sessionId?: string;
      locale?: 'th' | 'en';
    }) => {
      const { data } = await api.post<AIChatResponse>('/ai/chat', payload);
      return data;
    },
  });
}

// ============================================================================
// Family Wealth Module Hooks (Privacy-First Aggregation)
// ============================================================================

export function useFamilyDashboard(familyGroupId?: string) {
  const token = useAuthStore((s) => s.token);

  return useQuery<FamilyDashboardResponse>({
    queryKey: ['familyDashboard', familyGroupId ?? 'DEFAULT', token],
    enabled: Boolean(token),
    staleTime: 15_000,
    queryFn: async () => {
      const params: Record<string, string> = {};
      if (familyGroupId) params['familyGroupId'] = familyGroupId;
      const { data } = await api.get<FamilyDashboardResponse>('/family/dashboard', {
        params,
      });
      return data;
    },
  });
}

export function useCreateFamilyGroup() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { name: string }) => {
      const { data } = await api.post<{
        id: string;
        name: string;
        inviteCode: string;
      }>('/family/create', payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['familyDashboard'] });
    },
  });
}

export function useJoinFamilyGroup() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: { inviteCode: string }) => {
      const { data } = await api.post<{
        familyGroupId: string;
        name: string;
        inviteCode: string;
      }>('/family/join', payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['familyDashboard'] });
    },
  });
}

export function useUpdateFamilyPrivacy() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (payload: {
      hideTransactions?: boolean;
      canSeeTransactions?: boolean;
      canSeeTotalNetWorth?: boolean;
    }) => {
      const { data } = await api.patch<{
        updatedCount: number;
        permissions: FamilyPermissions;
      }>('/family/privacy', payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['familyDashboard'] });
    },
  });
}
