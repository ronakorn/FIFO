import { create } from 'zustand';
import { TOKEN_STORAGE_KEY, USER_STORAGE_KEY } from './authStorage';
import { User } from '@/types/shared';

interface AuthState {
  user: User | null;
  token: string | null;
  isHydrated: boolean;
  setAuth: (user: User, token: string) => void;
  setUser: (user: User | null) => void;
  logout: () => void;
  hydrate: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  isHydrated: false,

  setAuth: (user: User, token: string) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(TOKEN_STORAGE_KEY, token);
      window.localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
    }
    set({ user, token, isHydrated: true });
  },

  setUser: (user: User | null) => {
    if (typeof window !== 'undefined') {
      if (user) {
        window.localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      } else {
        window.localStorage.removeItem(USER_STORAGE_KEY);
      }
    }
    set({ user });
  },

  logout: () => {
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem(TOKEN_STORAGE_KEY);
      window.localStorage.removeItem(USER_STORAGE_KEY);
    }
    set({ user: null, token: null, isHydrated: true });
  },

  hydrate: () => {
    if (typeof window === 'undefined') {
      set({ isHydrated: true });
      return;
    }
    const storedToken = window.localStorage.getItem(TOKEN_STORAGE_KEY);
    const storedUserRaw = window.localStorage.getItem(USER_STORAGE_KEY);
    let parsedUser: User | null = null;
    if (storedUserRaw) {
      try {
        parsedUser = JSON.parse(storedUserRaw) as User;
      } catch {
        parsedUser = null;
      }
    }
    set({
      token: storedToken,
      user: storedToken ? parsedUser : null,
      isHydrated: true,
    });
  },
}));

interface PortfolioUIState {
  selectedPortfolioId: string | null;
  selectedTaxYear: number;
  setSelectedPortfolioId: (id: string | null) => void;
  setSelectedTaxYear: (year: number) => void;
}

export const usePortfolioStore = create<PortfolioUIState>((set) => ({
  selectedPortfolioId: null,
  selectedTaxYear: 2024,
  setSelectedPortfolioId: (id) => set({ selectedPortfolioId: id }),
  setSelectedTaxYear: (year) => set({ selectedTaxYear: year }),
}));

export interface FirePlannerUIState {
  monthlyExpenses: string;
  withdrawalRatePct: string;
  currentSavings: string;
  monthlyContribution: string;
  expectedReturnPct: string;
  inflationRatePct: string;
  volatilityPct: string;
  horizonYears: number;
  setField: <K extends keyof Omit<FirePlannerUIState, 'setField'>>(
    key: K,
    value: FirePlannerUIState[K]
  ) => void;
}

export const useFirePlannerStore = create<FirePlannerUIState>((set) => ({
  monthlyExpenses: '40000',
  withdrawalRatePct: '4.0',
  currentSavings: '2550000',
  monthlyContribution: '35000',
  expectedReturnPct: '8.5',
  inflationRatePct: '3.0',
  volatilityPct: '15.0',
  horizonYears: 18,
  setField: (key, value) => set({ [key]: value } as Partial<FirePlannerUIState>),
}));

interface AssistantAndUXState {
  isChatOpen: boolean;
  chatSessionId: string | null;
  isOnboardingOpen: boolean;
  hideFamilyTransactions: boolean;
  openChat: () => void;
  closeChat: () => void;
  setChatSessionId: (id: string | null) => void;
  openOnboarding: () => void;
  closeOnboarding: () => void;
  setHideFamilyTransactions: (hide: boolean) => void;
}

export const useAssistantStore = create<AssistantAndUXState>((set) => ({
  isChatOpen: false,
  chatSessionId: null,
  isOnboardingOpen: false,
  hideFamilyTransactions: true,
  openChat: () => set({ isChatOpen: true }),
  closeChat: () => set({ isChatOpen: false }),
  setChatSessionId: (id) => set({ chatSessionId: id }),
  openOnboarding: () => set({ isOnboardingOpen: true }),
  closeOnboarding: () => set({ isOnboardingOpen: false }),
  setHideFamilyTransactions: (hide) => set({ hideFamilyTransactions: hide }),
}));
