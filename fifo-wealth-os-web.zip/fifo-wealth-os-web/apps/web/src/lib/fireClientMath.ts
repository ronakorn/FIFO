import Decimal from 'decimal.js';

const Dec = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export function calculateFIRENumberClient(
  monthlyExpensesTHB: string,
  withdrawalRatePct: string
): string {
  try {
    const monthly = new Dec(monthlyExpensesTHB || '0');
    const ratePct = new Dec(withdrawalRatePct || '4');
    if (monthly.lte(0) || ratePct.lte(0) || ratePct.gt(100)) {
      return '0.00';
    }
    const annual = monthly.times(new Dec(12));
    const rateDecimal = ratePct.dividedBy(new Dec(100));
    return annual
      .dividedBy(rateDecimal)
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2);
  } catch {
    return '0.00';
  }
}

export function calculateYearsToFIREClient(
  currentAmountTHB: string,
  monthlyContributionTHB: string,
  targetAmountTHB: string,
  expectedReturnPct: string,
  inflationRatePct: string
): string {
  try {
    const pv = new Dec(currentAmountTHB || '0');
    const pmt = new Dec(monthlyContributionTHB || '0');
    const fv = new Dec(targetAmountTHB || '0');
    const nomReturn = new Dec(expectedReturnPct || '0').dividedBy(new Dec(100));
    const inflation = new Dec(inflationRatePct || '0').dividedBy(new Dec(100));

    if (fv.lte(0) || pv.isNegative() || pmt.isNegative()) {
      return '0.0';
    }
    if (pv.gte(fv)) {
      return '0.0';
    }

    const one = new Dec(1);
    const twelve = new Dec(12);
    const realAnnual = one
      .plus(nomReturn)
      .dividedBy(one.plus(inflation))
      .minus(one);

    if (realAnnual.isZero()) {
      if (pmt.lte(0)) return '99.0';
      return fv
        .minus(pv)
        .dividedBy(pmt)
        .dividedBy(twelve)
        .toDecimalPlaces(1, Decimal.ROUND_HALF_UP)
        .toFixed(1);
    }

    const monthlyRate = one
      .plus(realAnnual)
      .pow(one.dividedBy(twelve))
      .minus(one);

    const num = fv.times(monthlyRate).plus(pmt);
    const den = pv.times(monthlyRate).plus(pmt);
    if (den.lte(0) || num.lte(0) || num.dividedBy(den).lte(one)) {
      return '99.0';
    }

    const months = num
      .dividedBy(den)
      .ln()
      .dividedBy(one.plus(monthlyRate).ln());
    return months
      .dividedBy(twelve)
      .toDecimalPlaces(1, Decimal.ROUND_HALF_UP)
      .toFixed(1);
  } catch {
    return '99.0';
  }
}
