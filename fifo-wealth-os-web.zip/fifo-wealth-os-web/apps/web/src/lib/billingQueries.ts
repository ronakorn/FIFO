'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import api from './api';
import {
  BillingPricingResponse,
  BillingStatusResponse,
  CommunityFundraisingResponse,
  CustomerPortalResponse,
  DonationCheckoutResponse,
  EarlyBirdClaimResponse,
  EarlyBirdStatusResponse,
  TrialReservationResponse,
} from '@/types/billing';

export function useBillingStatus() {
  return useQuery<BillingStatusResponse>({
    queryKey: ['billingStatus'],
    staleTime: 5 * 60 * 1000,
    retry: false,
    queryFn: async () => {
      const { data } = await api.get<BillingStatusResponse>('/billing/status');
      return data;
    },
  });
}

export function useBillingPricing(enabled = true) {
  return useQuery<BillingPricingResponse>({
    queryKey: ['billingPricing'],
    staleTime: 5 * 60 * 1000,
    retry: false,
    enabled,
    queryFn: async () => {
      const { data } = await api.get<BillingPricingResponse>('/billing/pricing');
      return data;
    },
  });
}

export function useCommunityFundraising() {
  return useQuery<CommunityFundraisingResponse>({
    queryKey: ['billingCommunityFundraising'],
    staleTime: 60 * 1000,
    retry: false,
    queryFn: async () => {
      const { data } = await api.get<CommunityFundraisingResponse>('/billing/community');
      return data;
    },
  });
}

export function useEarlyBirdStatus(enabled = true) {
  return useQuery<EarlyBirdStatusResponse>({
    queryKey: ['earlyBirdStatus'],
    staleTime: 60 * 1000,
    retry: false,
    enabled,
    queryFn: async () => {
      const { data } = await api.get<EarlyBirdStatusResponse>('/billing/early-bird/status');
      return data;
    },
  });
}

export function useClaimEarlyBird() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const { data } = await api.post<EarlyBirdClaimResponse>('/billing/early-bird/claim');
      return data;
    },
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['earlyBirdStatus'] }),
        queryClient.invalidateQueries({ queryKey: ['billingPricing'] }),
        queryClient.invalidateQueries({ queryKey: ['billingStatus'] }),
      ]);
    },
  });
}

export function useReserveProTrial() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const { data } = await api.post<TrialReservationResponse>('/billing/trial/reserve');
      return data;
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['earlyBirdStatus'] });
    },
  });
}

export function useCreateDonation() {
  return useMutation({
    mutationFn: async (payload: { amountTHB: string; message?: string }) => {
      const { data } = await api.post<DonationCheckoutResponse>('/donate/create', payload);
      return data;
    },
  });
}

export function useCreateBillingPortal() {
  return useMutation({
    mutationFn: async () => {
      const { data } = await api.post<CustomerPortalResponse>('/billing/portal');
      return data;
    },
  });
}
