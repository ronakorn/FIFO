export const TOKEN_STORAGE_KEY = 'token';
export const USER_STORAGE_KEY = 'wealth_user';
