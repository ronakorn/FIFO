'use client';

import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft,
  ArrowRight,
  Calculator,
  CheckCircle2,
  Sparkles,
  Target,
  UploadCloud,
  X,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { useAssistantStore } from '@/lib/stores';
import { cn } from '@/lib/utils';

export const ONBOARDING_STORAGE_KEY = 'fifo_wealth_onboarding_seen_v1';

export function OnboardingWalkthrough() {
  const t = useTranslations('onboarding');
  const isOpen = useAssistantStore((s) => s.isOnboardingOpen);
  const openOnboarding = useAssistantStore((s) => s.openOnboarding);
  const closeOnboarding = useAssistantStore((s) => s.closeOnboarding);

  const [step, setStep] = useState<number>(0);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('onboarding') === '1') {
      setStep(0);
      openOnboarding();
      return;
    }
    const seen = window.localStorage.getItem(ONBOARDING_STORAGE_KEY);
    // Do not auto-block /login screen before authentication unless requested
    if (!seen && !window.location.pathname.endsWith('/login')) {
      setStep(0);
      openOnboarding();
    }
  }, [openOnboarding]);

  const handleComplete = () => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ONBOARDING_STORAGE_KEY, 'true');
    }
    setStep(0);
    closeOnboarding();
  };

  const steps = [
    {
      icon: UploadCloud,
      title: t('step1Title'),
      description: t('step1Desc'),
      accent: 'bg-[#14342a]/10 text-[#14342a] dark:bg-[#4ade80]/15 dark:text-[#4ade80]',
    },
    {
      icon: Calculator,
      title: t('step2Title'),
      description: t('step2Desc'),
      accent: 'bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400',
    },
    {
      icon: Target,
      title: t('step3Title'),
      description: t('step3Desc'),
      accent: 'bg-[#14342a]/10 text-[#14342a] dark:bg-[#4ade80]/15 dark:text-[#4ade80]',
    },
  ];

  const current = steps[step] ?? steps[0]!;
  const Icon = current.icon;

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          data-testid="onboarding-modal"
          role="dialog"
          aria-modal="true"
          aria-label={t('badge')}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.22 }}
            className="relative w-full max-w-md rounded-2xl border border-gray-100 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]"
          >
            {/* Dismiss Icon */}
            <button
              type="button"
              onClick={handleComplete}
              aria-label={t('skipBtn')}
              className="absolute right-4 top-4 rounded-xl p-1.5 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-gray-200"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Top Pill */}
            <div className="inline-flex items-center gap-1.5 rounded-full bg-[#14342a]/5 px-3 py-1 text-[11px] font-semibold text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <Sparkles className="h-3.5 w-3.5" />
              <span>{t('badge')}</span>
            </div>

            {/* Step Progress Dots */}
            <div className="mt-4 flex items-center justify-between">
              <div className="flex gap-1.5">
                {steps.map((_, idx) => (
                  <span
                    key={idx}
                    className={cn(
                      'h-1.5 rounded-full transition-all duration-300',
                      idx === step
                        ? 'w-8 bg-[#14342a] dark:bg-[#4ade80]'
                        : idx < step
                          ? 'w-3 bg-[#059669]'
                          : 'w-3 bg-gray-200 dark:bg-gray-700'
                    )}
                  />
                ))}
              </div>
              <span className="text-[11px] font-semibold text-gray-400 tabular-nums">
                {t('stepOf', { current: step + 1, total: steps.length })}
              </span>
            </div>

            {/* Step Content */}
            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.18 }}
                className="mt-6"
              >
                <div
                  className={cn(
                    'flex h-14 w-14 items-center justify-center rounded-2xl',
                    current.accent
                  )}
                >
                  <Icon className="h-7 w-7 stroke-[2.1]" />
                </div>

                <h3
                  data-testid="onboarding-step-title"
                  className="mt-4 text-lg font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]"
                >
                  {current.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-gray-600 dark:text-gray-300">
                  {current.description}
                </p>
              </motion.div>
            </AnimatePresence>

            {/* Footer Controls */}
            <div className="mt-7 flex items-center justify-between gap-3 border-t border-gray-100 pt-4 dark:border-gray-800">
              {step > 0 ? (
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.95 }}
                  data-testid="onboarding-back-btn"
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-gray-100 px-3.5 py-2 text-xs font-semibold text-gray-700 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  {t('backBtn')}
                </motion.button>
              ) : (
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.95 }}
                  data-testid="onboarding-skip-btn"
                  onClick={handleComplete}
                  className="rounded-xl px-2.5 py-2 text-xs font-medium text-gray-500 transition hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  {t('skipBtn')}
                </motion.button>
              )}

              {step < steps.length - 1 ? (
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.95 }}
                  data-testid="onboarding-next-btn"
                  onClick={() => setStep((s) => s + 1)}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
                >
                  <span>{t('nextBtn')}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </motion.button>
              ) : (
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.95 }}
                  data-testid="onboarding-finish-btn"
                  onClick={handleComplete}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>{t('finishBtn')}</span>
                </motion.button>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default OnboardingWalkthrough;
