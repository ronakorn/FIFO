'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import { cn } from '@/lib/utils';

interface EmptyStateProps {
  title?: string;
  description?: string;
  actionLabel?: string;
  actionHref?: string;
  onActionClick?: () => void;
  className?: string;
}

export function EmptyState({
  title,
  description,
  actionLabel,
  actionHref = '/upload',
  onActionClick,
  className,
}: EmptyStateProps) {
  const t = useTranslations('emptyState');

  const resolvedTitle = title ?? t('defaultTitle');
  const resolvedDesc = description ?? t('defaultDescription');
  const resolvedCta = actionLabel ?? t('uploadCta');

  return (
    <motion.div
      data-testid="empty-state"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.28 }}
      className={cn(
        'flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-200 bg-white px-6 py-12 text-center shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]',
        className
      )}
    >
      {/* Bespoke Clean Minimalist Wealth SVG Illustration */}
      <div className="mb-5 flex h-24 w-24 items-center justify-center rounded-3xl bg-[#14342a]/5 dark:bg-[#4ade80]/10">
        <svg
          viewBox="0 0 96 96"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="h-16 w-16"
          aria-hidden="true"
        >
          <rect
            x="14"
            y="22"
            width="68"
            height="52"
            rx="12"
            className="stroke-[#14342a] dark:stroke-[#4ade80]"
            strokeWidth="2.4"
          />
          <path
            d="M26 58L40 44L52 51L70 33"
            stroke="#059669"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="70" cy="33" r="4" fill="#059669" />
          <line
            x1="26"
            y1="65"
            x2="54"
            y2="65"
            className="stroke-gray-300 dark:stroke-gray-600"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      </div>

      <h3 className="text-base font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
        {resolvedTitle}
      </h3>
      <p className="mt-1.5 max-w-md text-xs leading-relaxed text-gray-500 dark:text-gray-400">
        {resolvedDesc}
      </p>

      <div className="mt-6">
        {onActionClick ? (
          <motion.button
            type="button"
            whileTap={{ scale: 0.95 }}
            onClick={onActionClick}
            className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
          >
            <span>{resolvedCta}</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </motion.button>
        ) : (
          <Link href={actionHref}>
            <motion.span
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
            >
              <span>{resolvedCta}</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </motion.span>
          </Link>
        )}
      </div>
    </motion.div>
  );
}

export default EmptyState;
