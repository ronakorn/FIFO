'use client';

import React, { useState } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import {
  CheckCircle2,
  Download,
  FileCheck2,
  Landmark,
  Receipt,
  Scale,
  ShieldCheck,
} from 'lucide-react';
import { ErrorMessage } from './ErrorMessage';
import { LoadingSpinner } from './LoadingSpinner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { downloadTaxReportPDF } from '@/lib/queries';
import {
  cn,
  extractApiErrorMessage,
  formatDateShort,
  formatSignedTHB,
  formatTHB,
} from '@/lib/utils';
import { TaxReport } from '@/types/shared';

interface TaxReportViewerProps {
  report: TaxReport;
  portfolioId: string;
  portfolioName?: string;
  isMock?: boolean;
}

const THAI_PIT_BRACKETS = [
  { key: 'exempt', min: 0, max: 150_000, rate: '0%', maxTax: 0, isExempt: true },
  { key: 'five', min: 150_001, max: 300_000, rate: '5%', maxTax: 7_500 },
  { key: 'ten', min: 300_001, max: 500_000, rate: '10%', maxTax: 20_000 },
  { key: 'fifteen', min: 500_001, max: 750_000, rate: '15%', maxTax: 37_500 },
  { key: 'twenty', min: 750_001, max: 1_000_000, rate: '20%', maxTax: 50_000 },
  { key: 'twentyFive', min: 1_000_001, max: 2_000_000, rate: '25%', maxTax: 250_000 },
  { key: 'thirty', min: 2_000_001, max: 5_000_000, rate: '30%', maxTax: 900_000 },
  { key: 'thirtyFive', min: 5_000_001, max: null, rate: '35%', maxTax: null },
] as const;

export function TaxReportViewer({
  report,
  portfolioId,
  portfolioName,
  isMock = false,
}: TaxReportViewerProps) {
  const t = useTranslations('taxReport');
  const locale = useLocale();
  const numberLocale = locale === 'th' ? 'th-TH' : 'en-US';
  const formatTaxNumber = (value: number) => new Intl.NumberFormat(numberLocale).format(value);
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [pdfError, setPdfError] = useState<string | null>(null);

  const taxableIncomeNum = Number(report.totalTaxableIncome);
  const taxWithheldNum = Number(report.totalTaxWithheld);
  const taxPayableNum = Number(report.totalTaxPayable);

  const totalCapGainsTHB = report.capitalGains.reduce(
    (sum, ev) => sum + Number(ev.taxableIncome),
    0
  );
  const totalDivGrossTHB = report.dividends.reduce(
    (sum, ev) => sum + Number(ev.amountTHB),
    0
  );

  const handleDownloadPdf = async () => {
    setPdfError(null);
    setDownloadSuccess(false);

    if (isMock) {
      setPdfError(
        t('mockDownloadError')
      );
      return;
    }

    try {
      setDownloading(true);
      await downloadTaxReportPDF(portfolioId, report.taxYear);
      setDownloadSuccess(true);
    } catch (err) {
      setPdfError(extractApiErrorMessage(err, t('pdfErrorFallback')));
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Clean Minimalist Official Header Card with Full Primary PDF Button */}
      <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full bg-green-100 px-3 py-1 text-xs font-bold text-green-800 dark:bg-emerald-950/70 dark:text-emerald-300">
              <ShieldCheck className="h-3.5 w-3.5" />
              {t('complianceBadge')}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
              {t('title', { beYear: report.taxYear + 543, ceYear: report.taxYear })}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
              {t('portfolioLabel')}{' '}
              <strong className="font-semibold text-gray-900 dark:text-gray-100">
                {portfolioName}
              </strong>{' '}
              • {t('fifoMethod')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              data-testid="download-tax-pdf-btn"
              disabled={downloading}
              onClick={handleDownloadPdf}
              className="inline-flex items-center justify-center gap-2.5 whitespace-nowrap rounded-xl bg-[#14342a] px-6 py-3.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1b4538] disabled:opacity-50"
            >
              {downloading ? (
                <>
                  <LoadingSpinner size="sm" className="border-white border-t-transparent" />
                  {t('downloading')}
                </>
              ) : (
                <>
                  <Download className="h-4 w-4" />
                  {t('download')}
                </>
              )}
            </button>
          </div>
        </div>

        {downloadSuccess && (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs font-semibold text-[#059669] dark:border-emerald-900/50 dark:bg-emerald-950/40 dark:text-emerald-300">
            <CheckCircle2 className="h-4 w-4 shrink-0" />
            {t('downloadSuccess')}
          </div>
        )}

        {pdfError && (
          <div className="mt-4">
            <ErrorMessage title={t('downloadErrorTitle')} message={pdfError} />
          </div>
        )}
      </div>

      {/* 4 Distinct Executive Tax Summary Cards with Large Tabular Numbers */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
            <span>{t('taxableIncome')}</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#14342a]/8 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <Scale className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-3 text-3xl font-bold tracking-tight text-[#14342a] tabular-nums dark:text-white">
            {formatTHB(taxableIncomeNum)}
          </p>
          <p className="mt-2 text-[11px] text-gray-500 tabular-nums dark:text-gray-400">
            {t('capitalGains')}: {formatTHB(totalCapGainsTHB)} • {t('dividends')}: {formatTHB(totalDivGrossTHB)}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
            <span>{t('withholdingCredit')}</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300">
              <Receipt className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-3 text-3xl font-bold tracking-tight text-gray-900 tabular-nums dark:text-gray-100">
            {formatTHB(taxWithheldNum)}
          </p>
          <p className="mt-2 text-[11px] text-gray-500 tabular-nums dark:text-gray-400">
            {t('withholdingFromDividends', { count: report.dividends.length })}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
            <span>
              {taxPayableNum < 0 ? t('overpaidCredit') : t('netTaxPayable')}
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400">
              <Landmark className="h-4 w-4" />
            </div>
          </div>
          <p
            className={cn(
              'mt-3 text-3xl font-bold tracking-tight tabular-nums',
              taxPayableNum > 0
                ? 'text-[#DC2626] dark:text-rose-400'
                : 'text-[#059669] dark:text-emerald-400'
            )}
          >
            {taxPayableNum < 0
              ? formatSignedTHB(Math.abs(taxPayableNum))
              : formatTHB(taxPayableNum)}
          </p>
          <p className="mt-2 text-[11px] text-gray-500 dark:text-gray-400">
            {taxPayableNum <= 0
              ? t('taxExemptNote')
              : t('progressiveTaxNote')}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
            <span>{t('taxItems')}</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300">
              <FileCheck2 className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-3 text-3xl font-bold tracking-tight text-gray-900 tabular-nums dark:text-gray-100">
            {t('itemCount', { count: report.capitalGains.length + report.dividends.length })}
          </p>
          <p className="mt-2 text-[11px] text-gray-500 tabular-nums dark:text-gray-400">
            {t('capitalGainCount', { count: report.capitalGains.length, dividends: report.dividends.length })}
          </p>
        </div>
      </div>

      {/* Detailed Tax Schedules via Minimalist Tabs */}
      <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <Tabs defaultValue="capital-gains">
          <TabsList className="w-full sm:w-auto flex-wrap">
            <TabsTrigger value="capital-gains">
              {t('capitalGainsTab', { count: report.capitalGains.length })}
            </TabsTrigger>
            <TabsTrigger value="dividends">
              {t('dividendsTab', { count: report.dividends.length })}
            </TabsTrigger>
            <TabsTrigger value="brackets">
              {t('bracketsTab')}
            </TabsTrigger>
          </TabsList>

          {/* Tab 1: Capital Gains */}
          <TabsContent value="capital-gains">
            {report.capitalGains.length === 0 ? (
              <div className="rounded-xl border border-gray-100 bg-gray-50/70 p-8 text-center text-xs text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                {t('noCapitalGains', { year: report.taxYear })}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-gray-100 bg-gray-50/70 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                    <tr>
                      <th className="px-4 py-2.5">{t('saleDate')}</th>
                      <th className="px-4 py-2.5">{t('security')}</th>
                      <th className="px-4 py-2.5 text-right">{t('fifoNetGain')}</th>
                      <th className="px-4 py-2.5 text-right">{t('taxableIncomeTHB')}</th>
                      <th className="px-4 py-2.5 text-right">{t('withholdingTax')}</th>
                      <th className="px-4 py-2.5 text-center">{t('revenueCode')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800/80">
                    {report.capitalGains.map((ev, idx) => {
                      const amountNum = Number(ev.amountTHB);
                      const taxableNum = Number(ev.taxableIncome);
                      const isTaxable = taxableNum > 0;
                      return (
                        <tr
                          key={`${ev.id}-${idx}`}
                          className="transition-colors hover:bg-[#14342a]/[0.03] dark:hover:bg-emerald-950/20"
                        >
                          <td className="whitespace-nowrap px-4 py-2.5 text-gray-600 tabular-nums dark:text-gray-300">
                            {formatDateShort(ev.date, numberLocale)}
                          </td>
                          <td className="px-4 py-2.5 font-bold text-gray-900 dark:text-gray-100">
                            {ev.symbol}
                          </td>
                          <td
                            className={cn(
                              'px-4 py-2.5 text-right font-bold tabular-nums',
                              amountNum > 0
                                ? 'text-[#059669] dark:text-emerald-400'
                                : amountNum < 0
                                  ? 'text-[#DC2626] dark:text-rose-400'
                                  : 'text-gray-600 dark:text-gray-300'
                            )}
                          >
                            {formatSignedTHB(amountNum)}
                          </td>
                          <td className="px-4 py-2.5 text-right font-bold text-gray-900 tabular-nums dark:text-gray-100">
                            {formatTHB(taxableNum)}
                          </td>
                          <td className="px-4 py-2.5 text-right text-gray-500 tabular-nums dark:text-gray-400">
                            {formatTHB(ev.taxWithheld)}
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <span
                              className={cn(
                                'inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold',
                                isTaxable
                                  ? 'bg-[#14342a]/10 text-[#14342a] dark:bg-[#4ade80]/15 dark:text-[#4ade80]'
                                  : 'bg-green-100 text-green-800 dark:bg-emerald-950/70 dark:text-emerald-300'
                              )}
                            >
                              {isTaxable ? t('taxableSection') : t('exemptOrLoss')}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>

          {/* Tab 2: Dividends */}
          <TabsContent value="dividends">
            {report.dividends.length === 0 ? (
              <div className="rounded-xl border border-gray-100 bg-gray-50/70 p-8 text-center text-xs text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                {t('noDividends', { year: report.taxYear })}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-gray-100 bg-gray-50/70 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                    <tr>
                      <th className="px-4 py-2.5">{t('dividendDate')}</th>
                      <th className="px-4 py-2.5">{t('security')}</th>
                      <th className="px-4 py-2.5 text-right">{t('grossDividends')}</th>
                      <th className="px-4 py-2.5 text-right">{t('withholdingTHB')}</th>
                      <th className="px-4 py-2.5 text-right">{t('taxableTHB')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800/80">
                    {report.dividends.map((ev, idx) => (
                      <tr
                        key={`${ev.id}-${idx}`}
                        className="transition-colors hover:bg-[#14342a]/[0.03] dark:hover:bg-emerald-950/20"
                      >
                        <td className="whitespace-nowrap px-4 py-2.5 text-gray-600 tabular-nums dark:text-gray-300">
                          {formatDateShort(ev.date, numberLocale)}
                        </td>
                        <td className="px-4 py-2.5 font-bold text-gray-900 dark:text-gray-100">
                          {ev.symbol}
                        </td>
                        <td className="px-4 py-2.5 text-right text-gray-900 tabular-nums dark:text-gray-100">
                          {formatTHB(ev.amountTHB)}
                        </td>
                        <td className="px-4 py-2.5 text-right text-amber-700 tabular-nums dark:text-amber-300">
                          {formatTHB(ev.taxWithheld)}
                        </td>
                        <td className="px-4 py-2.5 text-right font-bold text-[#059669] tabular-nums dark:text-emerald-400">
                          {formatTHB(ev.taxableIncome)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>

          {/* Tab 3: Thai PIT Brackets */}
          <TabsContent value="brackets">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-gray-100 bg-gray-50/70 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                  <tr>
                    <th className="px-4 py-2.5">{t('annualTaxableRange')}</th>
                    <th className="px-4 py-2.5">{t('taxRate')}</th>
                    <th className="px-4 py-2.5 text-right">{t('maxTaxInBracket')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800/80">
                  {THAI_PIT_BRACKETS.map((row) => (
                    <tr
                      key={row.key}
                      className="transition-colors hover:bg-[#14342a]/[0.03] dark:hover:bg-emerald-950/20"
                    >
                      <td className="px-4 py-2.5 font-medium text-gray-900 tabular-nums dark:text-gray-100">
                        {row.max === null ? t('aboveAmount', { amount: formatTaxNumber(row.min) }) : t('bracketRange', { min: formatTaxNumber(row.min), max: formatTaxNumber(row.max) })}
                      </td>
                      <td className="px-4 py-2.5 font-bold text-[#14342a] tabular-nums dark:text-[#4ade80]">
                        {row.rate}{row.key === 'exempt' ? ` (${t('exempt')})` : ''}
                      </td>
                      <td className="px-4 py-2.5 text-right text-gray-600 tabular-nums dark:text-gray-300">
                        {row.maxTax === null ? t('basedOnExcess') : formatTHB(row.maxTax)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default TaxReportViewer;
