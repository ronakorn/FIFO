'use client';

import React, { useState } from 'react';
import { useTranslations } from 'next-intl';
import { Calculator, CircleHelp, CalendarDays, ArrowUpRight } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api from '@/lib/api';
import { apiErrorMessage, formatCurrency, formatFixed, formatRatioAsPercent } from './format';
import type { DistributionScheduleResult, REITValuationResult } from './types';
import { Dialog, Field, MetricCard, SectionCard, StatusChip } from './ui';

const distributionHistory = [
  { quarter: 'Q3 ’25', amount: 0.165 },
  { quarter: 'Q4 ’25', amount: 0.172 },
  { quarter: 'Q1 ’26', amount: 0.178 },
  { quarter: 'Q2 ’26', amount: 0.180 },
  { quarter: 'Q3 ’26', amount: 0.184 },
  { quarter: 'Q4 ’26E', amount: 0.186 },
];

const sampleHoldings = [
  { symbol: 'WHART', name: 'WHA Premium Growth Freehold & Leasehold', type: 'LOGISTICS', structure: 'EQUITY REIT', units: '30,000', market: '10.50', nav: '11.60', yield: '6.18%', frequency: 'QUARTERLY', mark: 'W' },
  { symbol: 'CPNREIT', name: 'CPN Retail Growth Leasehold REIT', type: 'RETAIL', structure: 'EQUITY REIT', units: '14,000', market: '11.20', nav: '12.40', yield: '6.70%', frequency: 'QUARTERLY', mark: 'C' },
  { symbol: 'FTREIT', name: 'Frasers Property Thailand Industrial REIT', type: 'INDUSTRIAL', structure: 'EQUITY REIT', units: '22,000', market: '9.30', nav: '10.10', yield: '6.34%', frequency: 'QUARTERLY', mark: 'F' },
];

const valuationDefaults = { navPerUnit: '11.60', marketPrice: '10.50', annualDistributionPerUnit: '0.65', ffoPerUnit: '0.88', maintenanceCapexPerUnit: '0.08' };

export function REITsDashboard() {
  const t = useTranslations('advancedAssets.reits');
  const tCommon = useTranslations('advancedAssets.common');
  const [valuationOpen, setValuationOpen] = useState(false);
  const [valuationInputs, setValuationInputs] = useState(valuationDefaults);
  const [valuation, setValuation] = useState<REITValuationResult | null>(null);
  const [schedule, setSchedule] = useState<DistributionScheduleResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [scheduleLoading, setScheduleLoading] = useState(false);

  const updateValuationInput = (key: keyof typeof valuationDefaults, value: string) => setValuationInputs((current) => ({ ...current, [key]: value }));

  const runValuation = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const response = await api.post<{ result: REITValuationResult }>('/advanced-assets/reits/valuation', valuationInputs);
      setValuation(response.data.result);
    } catch (requestError) {
      setError(apiErrorMessage(requestError, tCommon('errorFallback')));
    } finally {
      setLoading(false);
    }
  };

  const buildSchedule = async () => {
    setScheduleLoading(true);
    setError(null);
    try {
      const response = await api.post<{ result: DistributionScheduleResult }>('/advanced-assets/reits/distribution-schedule', {
        annualDistributionPerUnit: '0.65', frequency: 'QUARTERLY', unitsHeld: '30000',
      });
      setSchedule(response.data.result);
    } catch (requestError) {
      setError(apiErrorMessage(requestError, tCommon('errorFallback')));
    } finally {
      setScheduleLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center gap-2"><h2 className="text-lg font-bold tracking-[-0.03em] text-[#1d3027]">{t('incomeTitle')}</h2><StatusChip tone="green">{t('summaryStatus')}</StatusChip></div>
          <p className="text-xs text-[#78847d]">{t('incomeSubtitle')}</p>
        </div>
        <button type="button" onClick={() => { setError(null); setValuationOpen(true); }} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"><Calculator className="h-3.5 w-3.5" />{t('valuationCalculator')}</button>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <MetricCard label={t('illustrativeValue')} value="฿676,400" footnote={t('sampleHoldings')} />
        <MetricCard label={t('weightedYield')} value="6.38%" footnote={t('annualizedScenario')} accent="gold" />
        <MetricCard label={t('priceVsNav')} value="−9.1%" footnote={t('weightedDiscount')} />
        <MetricCard label={t('nextQuarterlyCash')} value="฿4,875" footnote={t('estimate')} accent="blue" />
      </div>

      <SectionCard title={t('holdingsTitle')} eyebrow={t('realAssetIncome')} action={<StatusChip tone="gold">{tCommon('illustrativeData')}</StatusChip>}>
        <div className="mb-4 flex items-center gap-2 rounded-xl bg-[#f7f9f8] px-3 py-2.5 text-[10px] leading-4 text-[#69766f]"><CircleHelp className="h-3.5 w-3.5 shrink-0 text-[#71847a]" /> {t('navNotice')}</div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px] border-collapse text-left">
            <thead><tr className="border-b border-[#edf0ee] text-[9px] uppercase tracking-[0.12em] text-[#9aa49e]"><th className="pb-3 pr-4 font-semibold">{t('trustProperty')}</th><th className="pb-3 pr-4 font-semibold">{t('structure')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('units')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('priceNav')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('yield')}</th><th className="pb-3 text-right font-semibold">{t('cadence')}</th></tr></thead>
            <tbody>{sampleHoldings.map((holding) => (
              <tr key={holding.symbol} className="border-b border-[#f0f2f0] last:border-0">
                <td className="py-3.5 pr-4"><div className="flex items-center gap-2.5"><span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#eef4f0] text-[10px] font-bold text-[#315c42]">{holding.mark}</span><span><strong className="block text-xs font-bold text-[#293d32]">{holding.symbol}</strong><span className="mt-1 block max-w-[260px] truncate text-[9px] text-[#8e9992]">{holding.name}</span></span></div></td>
                <td className="py-3.5 pr-4"><span className="block text-[9px] font-semibold text-[#53665b]">{t('equityReit')}</span><span className="mt-1 block text-[8px] uppercase tracking-wide text-[#a0aaa4]">{t(holding.type.toLowerCase())}</span></td>
                <td className="py-3.5 pr-4 text-right text-xs font-medium text-[#425249]">{holding.units}</td>
                <td className="py-3.5 pr-4 text-right"><span className="block text-xs font-semibold text-[#34493d]">฿{holding.market}</span><span className="mt-1 block text-[9px] text-[#8b9790]">฿{holding.nav}</span></td>
                <td className="py-3.5 pr-4 text-right text-xs font-bold text-[#347454]">{holding.yield}</td>
                <td className="py-3.5 text-right"><span className="rounded-full bg-[#f2f6f3] px-2 py-1 text-[8px] font-bold text-[#527460]">{t(holding.frequency.toLowerCase())}</span></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </SectionCard>

      <div className="grid gap-5 xl:grid-cols-[1.25fr_0.85fr]">
        <SectionCard title={t('historyTitle')} eyebrow={t('historyEyebrow')} action={<span className="inline-flex items-center gap-1 text-[9px] font-semibold text-[#7d8982]"><ArrowUpRight className="h-3 w-3" />{t('indicative')}</span>}>
          <div className="mb-3 flex items-center justify-between text-[10px] text-[#7d8982]"><span>{t('sampleSchedule')}</span><StatusChip tone="blue">{t('lastSixQuarters')}</StatusChip></div>
          <div className="h-[226px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={distributionHistory} margin={{ top: 5, right: 7, bottom: 0, left: 0 }}>
                <CartesianGrid stroke="#edf1ee" vertical={false} />
                <XAxis dataKey="quarter" tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} tickFormatter={(value: number) => `฿${value.toFixed(2)}`} width={42} />
                <Tooltip formatter={(value) => [`฿${formatFixed(String(value), 3)}`, t('perUnit')]} contentStyle={{ borderRadius: 12, borderColor: '#e2e9e4', fontSize: 10 }} />
                <Bar dataKey="amount" fill="#62856e" radius={[5, 5, 0, 0]} maxBarSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-1 text-[9px] text-[#98a39c]">{t('estimateNotice')}</p>
        </SectionCard>

        <SectionCard title={t('scheduleTitle')} eyebrow={t('scheduleEyebrow')} action={<CalendarDays className="h-4 w-4 text-[#74907e]" />}>
          <div className="rounded-2xl border border-[#e6ece8] bg-[#f8faf8] p-4">
            <p className="text-[10px] text-[#75837a]">{t('perQuarter')}</p>
            <p className="mt-1.5 font-sans text-2xl font-bold tracking-[-0.04em] text-[#19372a]">{schedule ? formatCurrency(schedule.periodAmount, 'THB') : '฿4,875.00'}</p>
            <p className="mt-1 text-[9px] text-[#8d9992]">{t('annualizedEstimate', { value: schedule ? formatCurrency(schedule.annualTotal, 'THB') : '฿19,500.00' })}</p>
          </div>
          {error && !valuationOpen && <p role="alert" className="mt-3 rounded-xl border border-[#f0dcd8] bg-[#fcf1ef] px-3 py-2 text-[9px] leading-4 text-[#a24f43]">{error}</p>}
          <div className="mt-4 space-y-2.5">
            <div className="flex items-center justify-between text-[10px]"><span className="text-[#829087]">{t('frequency')}</span><span className="font-semibold text-[#34483d]">{t('quarterlyPeriods')}</span></div>
            <div className="flex items-center justify-between text-[10px]"><span className="text-[#829087]">{t('paymentDates')}</span><span className="font-semibold text-[#34483d]">{schedule?.paymentDates.length ? schedule.paymentDates.join(', ') : t('awaitingManagerNotice')}</span></div>
          </div>
          <button type="button" onClick={buildSchedule} disabled={scheduleLoading} className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-[#dfe6e1] bg-white px-3 py-2.5 text-[10px] font-semibold text-[#3b5045] transition hover:border-[#14342a] disabled:opacity-50"><CalendarDays className="h-3.5 w-3.5" />{scheduleLoading ? t('buildingSchedule') : t('recalculatePayout')}</button>
        </SectionCard>
      </div>

      {valuation && <SectionCard title={t('valuationTitle')} eyebrow={t('valuationEyebrow')} action={<StatusChip tone="green">{t('decimalJs')}</StatusChip>}>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <div><p className="text-[9px] text-[#87928b]">{t('premiumDiscount')}</p><p className={`mt-1.5 text-sm font-bold ${valuation.premiumDiscount.startsWith('-') ? 'text-[#347454]' : 'text-[#a75a50]'}`}>{formatRatioAsPercent(valuation.premiumDiscount)}</p></div>
          <div><p className="text-[9px] text-[#87928b]">{t('distributionYield')}</p><p className="mt-1.5 text-sm font-bold text-[#294b37]">{formatRatioAsPercent(valuation.distributionYield)}</p></div>
          <div><p className="text-[9px] text-[#87928b]">{t('ffoPerUnit')}</p><p className="mt-1.5 text-sm font-bold text-[#294b37]">฿{formatFixed(valuation.ffoPerUnit, 4)}</p></div>
          <div><p className="text-[9px] text-[#87928b]">{t('affoPerUnit')}</p><p className="mt-1.5 text-sm font-bold text-[#294b37]">฿{formatFixed(valuation.affoPerUnit, 4)}</p></div>
        </div>
        <p className="mt-4 border-t border-[#edf0ee] pt-3 text-[9px] leading-4 text-[#8b9790]">{t('distributionNavProxy', { value: formatRatioAsPercent(valuation.capRate) })}</p>
      </SectionCard>}

      {valuationOpen && <Dialog title={t('valuationDialogTitle')} description={t('valuationDialogDescription')} onClose={() => setValuationOpen(false)}>
        <form onSubmit={runValuation} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label={t('navPerUnit')} value={valuationInputs.navPerUnit} onChange={(value) => updateValuationInput('navPerUnit', value)} suffix="THB" />
            <Field label={t('marketPrice')} value={valuationInputs.marketPrice} onChange={(value) => updateValuationInput('marketPrice', value)} suffix="THB" />
            <Field label={t('annualDistribution')} value={valuationInputs.annualDistributionPerUnit} onChange={(value) => updateValuationInput('annualDistributionPerUnit', value)} suffix="THB" />
            <Field label={t('ffoPerUnit')} value={valuationInputs.ffoPerUnit} onChange={(value) => updateValuationInput('ffoPerUnit', value)} suffix="THB" />
            <Field label={t('maintenanceCapex')} value={valuationInputs.maintenanceCapexPerUnit} onChange={(value) => updateValuationInput('maintenanceCapexPerUnit', value)} suffix="THB" />
          </div>
          {error && valuationOpen && <p role="alert" className="rounded-xl border border-[#f0dcd8] bg-[#fcf1ef] px-3 py-2.5 text-[10px] leading-4 text-[#a24f43]">{error}</p>}
          {valuation && <div className="rounded-2xl border border-[#dfe9e2] bg-[#f4f8f5] p-4"><div className="grid grid-cols-2 gap-3"><div><p className="text-[9px] text-[#849088]">{t('premiumDiscount')}</p><p className="mt-1 text-sm font-bold text-[#19372a]">{formatRatioAsPercent(valuation.premiumDiscount)}</p></div><div><p className="text-[9px] text-[#849088]">{t('distributionYield')}</p><p className="mt-1 text-sm font-bold text-[#19372a]">{formatRatioAsPercent(valuation.distributionYield)}</p></div></div><p className="mt-3 text-[9px] leading-4 text-[#7c8981]">{t('affoPerUnit')}: ฿{formatFixed(valuation.affoPerUnit, 4)}</p><p className="mt-2 text-[9px] leading-4 text-[#7c8981]">{t('distributionNavProxy', { value: formatRatioAsPercent(valuation.capRate) })}</p></div>}
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end"><button type="button" onClick={() => setValuationOpen(false)} className="rounded-xl border border-[#dfe6e1] px-4 py-2.5 text-xs font-semibold text-[#53635a]">{tCommon('close')}</button><button disabled={loading} type="submit" className="rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white disabled:opacity-60">{loading ? tCommon('calculating') : t('calculateValuation')}</button></div>
        </form>
        <p className="mt-4 border-t border-[#edf0ee] pt-3 text-[9px] leading-4 text-[#98a39c]">{t('affoNote')}</p>
      </Dialog>}
    </div>
  );
}
