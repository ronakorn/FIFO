'use client';

import React, { useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import Decimal from 'decimal.js';
import { AlertTriangle, ArrowDownRight, ArrowUpRight, Gauge, RefreshCw, ShieldCheck, Waves } from 'lucide-react';
import api from '@/lib/api';
import { apiErrorMessage, formatCurrency, formatFixed, UiAssetDecimal } from './format';
import type { MarginHealthResult } from './types';
import { SectionCard, StatusChip } from './ui';

const FutUiDecimal = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

const demoPosition = {
  id: 'scenario-s50z26-long',
  symbol: 'S50Z26',
  side: 'LONG' as const,
  qty: '8',
  entryPrice: '870.00',
  markPrice: '886.00',
  contractSize: '200',
  multiplier: '1',
  initialMargin: '150000',
  maintenanceMargin: '120000',
};

const initialHealth: MarginHealthResult = {
  totalEquity: '1105600.00',
  totalInitialMargin: '1200000.00',
  totalMaintenanceMargin: '960000.00',
  availableMargin: '-94400.00',
  marginLevel: '115.17',
  status: 'DANGER',
};

export function FuturesRiskDashboard() {
  const t = useTranslations('advancedAssets.futures');
  const tCommon = useTranslations('advancedAssets.common');
  const [markPrice, setMarkPrice] = useState(demoPosition.markPrice);
  const [accountBalance, setAccountBalance] = useState('1080000');
  const [health, setHealth] = useState<MarginHealthResult>(initialHealth);
  const [unrealizedPnL, setUnrealizedPnL] = useState('25600.00');
  const [liquidationPrice, setLiquidationPrice] = useState('720.0000');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const gaugeProgress = useMemo(() => {
    const normalized = FutUiDecimal.max(0, FutUiDecimal.min(250, new FutUiDecimal(health.marginLevel))).dividedBy(250);
    return normalized.times(100).toNumber();
  }, [health.marginLevel]);
  const statusTone = health.status === 'HEALTHY' ? 'green' : health.status === 'WARNING' ? 'gold' : 'red';
  const statusLabel = health.status === 'HEALTHY' ? t('statusHealthy') : health.status === 'WARNING' ? t('statusWarning') : health.status === 'DANGER' ? t('statusDanger') : t('statusMarginCall');
  const gaugeColor = health.status === 'HEALTHY' ? '#4f8560' : health.status === 'WARNING' ? '#b18a3f' : '#b85a4b';
  const liquidationDistance = new UiAssetDecimal(demoPosition.entryPrice).minus(liquidationPrice).abs().toFixed(2);

  const recalculateRisk = async () => {
    setLoading(true);
    setError(null);
    const position = { ...demoPosition, markPrice };
    try {
      const [healthResponse, pnlResponse, liquidationResponse] = await Promise.all([
        api.post<{ result: MarginHealthResult }>('/advanced-assets/futures/margin-health', {
          positions: [position],
          accountBalance,
        }),
        api.post<{ result: { unrealizedPnL: string } }>('/advanced-assets/futures/mark-to-market', {
          side: position.side,
          qty: position.qty,
          entryPrice: position.entryPrice,
          markPrice: position.markPrice,
          contractSize: position.contractSize,
          multiplier: position.multiplier,
        }),
        api.post<{ result: { liquidationPrice: string } }>('/advanced-assets/futures/liquidation-price', {
          side: position.side,
          entryPrice: position.entryPrice,
          initialMarginPerContract: position.initialMargin,
          maintenanceMarginPerContract: position.maintenanceMargin,
          multiplier: position.multiplier,
          qty: position.qty,
          contractSize: position.contractSize,
        }),
      ]);
      setHealth(healthResponse.data.result);
      setUnrealizedPnL(pnlResponse.data.result.unrealizedPnL);
      setLiquidationPrice(liquidationResponse.data.result.liquidationPrice);
    } catch (requestError) {
      setError(apiErrorMessage(requestError, tCommon('errorFallback')));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center gap-2"><h2 className="text-lg font-bold tracking-[-0.03em] text-[#1d3027]">{t('title')}</h2><StatusChip tone="red">{t('linearScenario')}</StatusChip></div>
          <p className="text-xs text-[#78847d]">{t('subtitle')}</p>
        </div>
        <button type="button" onClick={recalculateRisk} disabled={loading} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-60"><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />{loading ? t('recomputing') : t('recalculate')}</button>
      </div>

      {health.status === 'MARGIN_CALL' || health.status === 'DANGER' ? <div className={`flex items-start gap-3 rounded-2xl border px-4 py-3.5 ${health.status === 'MARGIN_CALL' ? 'border-[#efd3cf] bg-[#fff3f1]' : 'border-[#efe1c7] bg-[#fcf8ef]'}`}>
        <AlertTriangle className={`mt-0.5 h-4 w-4 shrink-0 ${health.status === 'MARGIN_CALL' ? 'text-[#ad4d41]' : 'text-[#a27a2f]'}`} />
        <div><p className={`text-xs font-bold ${health.status === 'MARGIN_CALL' ? 'text-[#93473f]' : 'text-[#85692e]'}`}>{health.status === 'MARGIN_CALL' ? t('marginCallBreached') : t('lowBuffer')}</p><p className="mt-1 text-[10px] leading-4 text-[#817769]">{t('marginWarning', { level: formatFixed(health.marginLevel, 2) })}</p></div>
      </div> : null}

      {error && <p role="alert" className="rounded-xl border border-[#f0dcd8] bg-[#fcf1ef] px-3 py-2.5 text-[10px] leading-4 text-[#a24f43]">{error}</p>}

      <div className="grid gap-5 xl:grid-cols-[0.92fr_1.18fr]">
        <SectionCard title={t('marginGauge')} eyebrow={t('accountEquityMaintenance')} action={<Gauge className="h-4 w-4 text-[#78907f]" />}>
          <div className="relative mx-auto mt-1 flex h-[185px] w-full max-w-[330px] items-end justify-center">
            <svg className="absolute inset-x-0 top-0 mx-auto h-[165px] w-full max-w-[300px] overflow-visible" viewBox="0 0 200 120" aria-label={t('marginHealthAria', { level: health.marginLevel })} role="img">
              <path d="M20 100 A80 80 0 0 1 180 100" fill="none" stroke="#edf1ee" strokeWidth="13" strokeLinecap="round" />
              <path d="M20 100 A80 80 0 0 1 180 100" fill="none" stroke={gaugeColor} strokeWidth="13" strokeLinecap="round" strokeDasharray={`${(gaugeProgress / 100) * 251} 251`} />
              <text x="20" y="116" fontSize="7" fill="#929d96" textAnchor="middle">0%</text>
              <text x="180" y="116" fontSize="7" fill="#929d96" textAnchor="middle">250%</text>
            </svg>
            <div className="relative z-10 mb-2 text-center"><p className="font-sans text-4xl font-bold tracking-[-0.06em] text-[#20382b]">{formatFixed(health.marginLevel, 2)}<span className="ml-0.5 text-base">%</span></p><p className="mt-1 text-[9px] uppercase tracking-[0.14em] text-[#849088]">{t('marginLevel')}</p></div>
          </div>
          <div className="mt-1 flex justify-center"><StatusChip tone={statusTone}>{statusLabel}</StatusChip></div>
          <div className="mt-5 grid grid-cols-2 gap-3 border-t border-[#edf0ee] pt-4">
            <div><p className="text-[9px] text-[#89958e]">{t('totalEquity')}</p><p className="mt-1 text-sm font-bold text-[#2b4335]">{formatCurrency(health.totalEquity)}</p></div>
            <div><p className="text-[9px] text-[#89958e]">{t('maintenanceMargin')}</p><p className="mt-1 text-sm font-bold text-[#2b4335]">{formatCurrency(health.totalMaintenanceMargin)}</p></div>
          </div>
          <div className="mt-4 flex items-start gap-2 rounded-xl bg-[#f7f9f8] p-3 text-[9px] leading-4 text-[#7b8880]"><ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#688773]" />{t('riskThresholds')}</div>
        </SectionCard>

        <div className="space-y-5">
          <SectionCard title={t('openPosition')} eyebrow={t('set50Futures')} action={<StatusChip tone="gold">{t('illustrativePosition')}</StatusChip>}>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[590px] border-collapse text-left">
                <thead><tr className="border-b border-[#edf0ee] text-[9px] uppercase tracking-[0.12em] text-[#9aa49e]"><th className="pb-3 pr-4 font-semibold">{t('sideQty')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('entry')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('mark')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('unrealizedPnl')}</th><th className="pb-3 text-right font-semibold">{t('liquidationEstimate')}</th></tr></thead>
                <tbody><tr><td className="py-4 pr-4"><span className="inline-flex items-center gap-1.5 rounded-full bg-[#edf4f0] px-2.5 py-1 text-[9px] font-bold text-[#2f6947]"><ArrowUpRight className="h-3 w-3" />{t('long')}</span><span className="mt-1.5 block text-[8px] text-[#929d96]">{t('unitsPerContract')}</span></td><td className="py-4 pr-4 text-right text-xs font-semibold text-[#44554b]">870.00</td><td className="py-4 pr-4 text-right text-xs font-semibold text-[#44554b]">{markPrice}</td><td className={`py-4 pr-4 text-right text-xs font-bold ${new UiAssetDecimal(unrealizedPnL).isNegative() ? 'text-[#a75a50]' : 'text-[#347454]'}`}>{formatCurrency(unrealizedPnL)}</td><td className="py-4 text-right text-xs font-bold text-[#a75a50]">{formatFixed(liquidationPrice, 4)}</td></tr></tbody>
              </table>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 border-t border-[#edf0ee] pt-4 md:grid-cols-4">
              {[[t('initialMarginContract'), '฿150,000'], [t('maintenanceContract'), '฿120,000'], [t('totalInitialMargin'), formatCurrency(health.totalInitialMargin)], [t('availableMargin'), formatCurrency(health.availableMargin)]].map(([label, value]) => <div key={label}><p className="text-[9px] text-[#89958e]">{label}</p><p className={`mt-1 text-xs font-bold ${label === t('availableMargin') && new UiAssetDecimal(health.availableMargin).isNegative() ? 'text-[#a75a50]' : 'text-[#34483d]'}`}>{value}</p></div>)}
            </div>
          </SectionCard>

          <SectionCard title={t('scenarioInputs')} eyebrow={t('liveRecalculation')} action={<Waves className="h-4 w-4 text-[#78907f]" />}>
            <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
              <label className="block"><span className="mb-1.5 block text-[10px] font-semibold text-[#66736b]">{t('markPrice')}</span><span className="flex items-center rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3"><input type="number" step="0.25" value={markPrice} onChange={(event) => setMarkPrice(event.target.value)} className="h-10 min-w-0 flex-1 bg-transparent text-sm font-semibold text-[#20342a] outline-none" /><span className="ml-2 text-[10px] text-[#8a958e]">{t('indexPoints')}</span></span></label>
              <label className="block"><span className="mb-1.5 block text-[10px] font-semibold text-[#66736b]">{t('accountBalance')}</span><span className="flex items-center rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3"><input type="number" step="1000" value={accountBalance} onChange={(event) => setAccountBalance(event.target.value)} className="h-10 min-w-0 flex-1 bg-transparent text-sm font-semibold text-[#20342a] outline-none" /><span className="ml-2 text-[10px] text-[#8a958e]">THB</span></span></label>
              <button type="button" onClick={recalculateRisk} disabled={loading} className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-[#dfe6e1] bg-white px-3 text-[10px] font-semibold text-[#3b5045] transition hover:border-[#14342a] disabled:opacity-50"><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />{loading ? t('updating') : t('update') }</button>
            </div>
            <div className="mt-3 flex items-start gap-2 text-[9px] leading-4 text-[#929d96]"><ArrowDownRight className="mt-0.5 h-3 w-3 shrink-0" />{t('linearEstimate')}</div>
            <div className="mt-3 text-[9px] text-[#7c8981]">{t('liquidationDistance', { distance: formatFixed(liquidationDistance, 2) })}</div>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}
