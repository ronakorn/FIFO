'use client';

import React, { useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import { ArrowDownLeft, ArrowUpRight, Briefcase, CalendarRange, CircleHelp, RefreshCw, WalletCards } from 'lucide-react';
import { Area, AreaChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api from '@/lib/api';
import { apiErrorMessage, formatCurrency, formatFixed, formatMultiple, UiAssetDecimal } from './format';
import type { JCurvePoint, PECashFlow, PEMetricsResult } from './types';
import { MetricCard, SectionCard, StatusChip } from './ui';

const sampleCashFlows: PECashFlow[] = [
  { date: '2021-06-30', amount: '-1200000', type: 'CALL' },
  { date: '2022-06-30', amount: '-1400000', type: 'CALL' },
  { date: '2023-06-30', amount: '-1200000', type: 'CALL' },
  { date: '2024-06-30', amount: '200000', type: 'DISTRIBUTION' },
  { date: '2025-06-30', amount: '600000', type: 'DISTRIBUTION' },
  { date: '2026-06-30', amount: '5100000', type: 'DISTRIBUTION' },
];

const fallbackCurve = [
  { date: '2021', cumulativeCashFlow: '-1200000', irr: '0.000000' },
  { date: '2022', cumulativeCashFlow: '-2600000', irr: '0.000000' },
  { date: '2023', cumulativeCashFlow: '-3800000', irr: '0.000000' },
  { date: '2024', cumulativeCashFlow: '-3600000', irr: '-0.858594' },
  { date: '2025', cumulativeCashFlow: '-3000000', irr: '-0.448304' },
  { date: '2026', cumulativeCashFlow: '2100000', irr: '0.120834' },
];

const initialMetrics: PEMetricsResult = {
  tvpi: '1.5526', dpi: '0.3947', rvpi: '1.1579', moic: '1.5526', irr: '0.120834',
  paidInCapital: '3800000.00', totalDistributions: '1500000.00', residualValue: '4400000.00',
  committedCapital: '5000000.00', uncalledCapital: '900000.00',
};

export function PrivateEquityDashboard() {
  const t = useTranslations('advancedAssets.pe');
  const tCommon = useTranslations('advancedAssets.common');
  const [metrics, setMetrics] = useState<PEMetricsResult>(initialMetrics);
  const [curvePoints, setCurvePoints] = useState<Array<JCurvePoint | { date: string; cumulativeCashFlow: string; irr: string }>>(fallbackCurve);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const calledCapitalRatio = useMemo(
    () => new UiAssetDecimal('4100000').dividedBy('5000000').times(100).toNumber(),
    [],
  );

  const recalculate = async () => {
    setLoading(true);
    setError(null);
    try {
      const [metricsResponse, curveResponse] = await Promise.all([
        api.post<{ result: PEMetricsResult }>('/advanced-assets/private-equity/metrics', {
          committedCapital: '5000000',
          calledCapital: '4100000',
          investedCapital: '3800000',
          distributedCapital: '1500000',
          residualValue: '4400000',
          cashFlows: sampleCashFlows,
        }),
        api.post<{ result: { points: JCurvePoint[] } }>('/advanced-assets/private-equity/j-curve', { cashFlows: sampleCashFlows }),
      ]);
      setMetrics(metricsResponse.data.result);
      setCurvePoints(curveResponse.data.result.points);
    } catch (requestError) {
      setError(apiErrorMessage(requestError, tCommon('errorFallback')));
    } finally {
      setLoading(false);
    }
  };

  const chartData = useMemo(() => curvePoints.map((point) => ({
    ...point,
    year: point.date.slice(0, 4),
    // Chart scale is expressed in millions; the source cash flow remains exact Decimal text.
    cumulativeMillions: new UiAssetDecimal(point.cumulativeCashFlow).dividedBy('1000000').toNumber(),
  })), [curvePoints]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center gap-2"><h2 className="text-lg font-bold tracking-[-0.03em] text-[#1d3027]">{t('dashboardTitle')}</h2><StatusChip tone="blue">{t('fundPerformance')}</StatusChip></div>
          <p className="text-xs text-[#78847d]">{t('dashboardSubtitle')}</p>
        </div>
        <button type="button" onClick={recalculate} disabled={loading} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-60"><RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />{loading ? t('recalculating') : t('recalculate')}</button>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-5">
        <MetricCard label={t('tvpi')} value={formatMultiple(metrics.tvpi)} footnote={t('tvpiFootnote')} />
        <MetricCard label={t('dpi')} value={formatMultiple(metrics.dpi)} footnote={t('dpiFootnote')} />
        <MetricCard label={t('rvpi')} value={formatMultiple(metrics.rvpi)} footnote={t('rvpiFootnote')} />
        <MetricCard label={t('moic')} value={formatMultiple(metrics.moic)} footnote={t('moicFootnote')} accent="gold" />
        <MetricCard label={t('grossXirr')} value={`${formatFixed(metrics.irr ? new UiAssetDecimal(metrics.irr).times(100).toFixed(2) : '0', 2)}%`} footnote={t('xirrFootnote')} accent="blue" />
      </div>

      {error && <p role="alert" className="rounded-xl border border-[#f0dcd8] bg-[#fcf1ef] px-3 py-2.5 text-[10px] leading-4 text-[#a24f43]">{error}</p>}

      <div className="grid gap-5 xl:grid-cols-[1.45fr_0.85fr]">
        <SectionCard title={t('jcurveTitle')} eyebrow={t('northstarVintage')} action={<StatusChip tone="gold">{t('scenario')}</StatusChip>}>
          <div className="mb-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-[9px] text-[#7d8982]"><span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-[#3e7553]" />{t('cumulativeCashFlow')}</span><span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-[#bd9a56]" />{t('negativeCapital')}</span></div>
          <div className="h-[270px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 12, right: 14, bottom: 2, left: 0 }}>
                <defs><linearGradient id="peJCurveFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#467954" stopOpacity={0.25} /><stop offset="100%" stopColor="#467954" stopOpacity={0.02} /></linearGradient></defs>
                <CartesianGrid stroke="#edf1ee" vertical={false} />
                <XAxis dataKey="year" tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 10 }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} tickFormatter={(value: number) => `฿${value.toFixed(1)}m`} width={48} />
                <Tooltip formatter={(value) => [`฿${formatFixed(new UiAssetDecimal(String(value)).times('1000000').toFixed(0), 0)}`, t('cumulativeCashFlow')]} labelFormatter={(label) => t('vintageTimeline', { year: label })} contentStyle={{ borderRadius: 12, borderColor: '#e2e9e4', fontSize: 10 }} />
                <ReferenceLine y={0} stroke="#aeb8b1" strokeDasharray="4 4" />
                <Area type="monotone" dataKey="cumulativeMillions" stroke="#36704b" strokeWidth={2.5} fill="url(#peJCurveFill)" activeDot={{ r: 4, fill: '#14342a' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2 border-t border-[#edf0ee] pt-4 text-[9px] text-[#8a968e]"><span>{t('paidIn')} <strong className="ml-1 text-[#34483d]">{formatCurrency(metrics.paidInCapital)}</strong></span><span>{t('distributions')} <strong className="ml-1 text-[#34483d]">{formatCurrency(metrics.totalDistributions)}</strong></span><span>{t('residualValue')} <strong className="ml-1 text-[#34483d]">{formatCurrency(metrics.residualValue)}</strong></span></div>
        </SectionCard>

        <div className="space-y-5">
          <SectionCard title={t('fundTitle')} eyebrow={t('fundEyebrow')} action={<Briefcase className="h-4 w-4 text-[#78907f]" />}>
            <div className="mb-4 flex items-center justify-between"><span className="text-[10px] text-[#849088]">{t('fundStatus')}</span><StatusChip tone="green">{t('harvesting')}</StatusChip></div>
            <div className="mb-2 flex items-center justify-between text-[10px]"><span className="text-[#87928b]">{t('calledCapital')}</span><strong className="text-[#34483d]">฿4.10m <span className="font-normal text-[#9aa49e]">/ ฿5.00m</span></strong></div>
            <div className="h-2 overflow-hidden rounded-full bg-[#edf1ee]"><div className="h-full rounded-full bg-[#467954]" style={{ width: `${calledCapitalRatio}%` }} /></div>
            <div className="mt-4 grid grid-cols-2 gap-y-3 border-t border-[#edf0ee] pt-4">
              {[[t('invested'), '฿3.80m'], [t('uncalled'), '฿0.90m'], [t('distributions'), '฿1.50m'], [t('residualNav'), '฿4.40m']].map(([label, value]) => <div key={label}><p className="text-[9px] text-[#89958e]">{label}</p><p className="mt-1 text-xs font-bold text-[#34483d]">{value}</p></div>)}
            </div>
            <p className="mt-4 rounded-xl bg-[#f7f9f8] px-3 py-2.5 text-[9px] leading-4 text-[#7b8880]">{t('xirrCashflowNote')}</p>
          </SectionCard>

          <SectionCard title={t('snapshotsTitle')} eyebrow={t('snapshotEyebrow')} action={<WalletCards className="h-4 w-4 text-[#78907f]" />}>
            <div className="space-y-3">
              <div className="flex items-center justify-between rounded-xl border border-[#e9eeea] bg-[#fbfcfb] p-3"><div><p className="text-[10px] font-bold text-[#31483a]">Northstar Growth III</p><p className="mt-1 text-[8px] text-[#8b9790]">{t('ventureGrowthVintage')}</p></div><div className="text-right"><p className="text-sm font-bold text-[#27553a]">1.55×</p><p className="mt-1 text-[8px] text-[#8b9790]">TVPI</p></div></div>
              <div className="flex items-center justify-between rounded-xl border border-[#e9eeea] bg-[#fbfcfb] p-3"><div><p className="text-[10px] font-bold text-[#31483a]">Siam Ventures Select</p><p className="mt-1 text-[8px] text-[#8b9790]">{t('earlyStage')}</p></div><div className="text-right"><p className="text-sm font-bold text-[#92773a]">1.00×</p><p className="mt-1 text-[8px] text-[#8b9790]">TVPI</p></div></div>
            </div>
            <div className="mt-4 flex items-start gap-2 border-t border-[#edf0ee] pt-3 text-[9px] leading-4 text-[#8b9790]"><CircleHelp className="mt-0.5 h-3 w-3 shrink-0" />{t('multipleNote')}</div>
          </SectionCard>
        </div>
      </div>

      <SectionCard title={t('cashflowTimeline')} eyebrow={t('cashflowEyebrow')} action={<CalendarRange className="h-4 w-4 text-[#78907f]" />}>
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-6">
          {sampleCashFlows.map((cashFlow, index) => {
            const amount = new UiAssetDecimal(cashFlow.amount);
            const isContribution = amount.isNegative();
            return <div key={`${cashFlow.date}-${index}`} className="rounded-xl border border-[#e9eeea] bg-[#fbfcfb] p-3"><div className="flex items-center justify-between"><span className="text-[9px] font-semibold text-[#6f7d74]">{cashFlow.date.slice(0, 4)}</span>{isContribution ? <ArrowDownLeft className="h-3 w-3 text-[#a75a50]" /> : <ArrowUpRight className="h-3 w-3 text-[#347454]" />}</div><p className={`mt-3 text-xs font-bold ${isContribution ? 'text-[#a75a50]' : 'text-[#347454]'}`}>{isContribution ? '−' : '+'}{formatCurrency(amount.abs().toFixed(2))}</p><p className="mt-1 text-[8px] uppercase tracking-wide text-[#9aa49e]">{isContribution ? t('capitalCall') : index === sampleCashFlows.length - 1 ? t('distributionResidual') : t('distribution')}</p></div>;
          })}
        </div>
      </SectionCard>
    </div>
  );
}
