'use client';

import React, { useMemo, useState } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { Activity, CircleAlert, RefreshCw, Search, SlidersHorizontal } from 'lucide-react';
import { Area, AreaChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api from '@/lib/api';
import { apiErrorMessage, formatCurrency, formatFixed, formatRatioAsPercent, UiAssetDecimal } from './format';
import { getDemoOptionsChain } from './polishData';
import type { OptionChainSymbol, OptionsChainExpiry, OptionsChainQuote, OptionsChainResult } from './types';
import { Dialog, SectionCard, StatusChip } from './ui';

const SYMBOLS: readonly OptionChainSymbol[] = ['AAPL', 'SPY'];
const CONTRACT_SIZE = '100';

function toneForMoneyness(moneyness: OptionsChainQuote['callMoneyness']): string {
  if (moneyness === 'ITM') return 'bg-[#edf6f0] text-[#2d6747]';
  if (moneyness === 'ATM') return 'bg-[#fcf7e7] text-[#8d7132]';
  return 'bg-[#fcf1ef] text-[#a25349]';
}

function compactDate(date: string, locale: string): string {
  return new Date(`${date}T00:00:00.000Z`).toLocaleDateString(locale === 'th' ? 'th-TH' : 'en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  });
}

function getSelectedExpiry(chain: OptionsChainResult, selectedExpiryDate: string): OptionsChainExpiry | undefined {
  return chain.expiries.find((expiry) => expiry.expiryDate === selectedExpiryDate) ?? chain.expiries[0];
}

function buildPayoffData(
  quote: OptionsChainQuote,
  optionType: 'CALL' | 'PUT',
): Array<{ underlying: number; payoff: number }> {
  const strike = new UiAssetDecimal(quote.strike);
  const premium = new UiAssetDecimal(optionType === 'CALL' ? quote.callAsk : quote.putAsk);
  const step = strike.times('0.04');
  const start = UiAssetDecimal.max(strike.minus(step.times(6)), 0);

  return Array.from({ length: 13 }, (_unused, index) => {
    const underlying = start.plus(step.times(index));
    const intrinsic = optionType === 'CALL'
      ? UiAssetDecimal.max(underlying.minus(strike), 0)
      : UiAssetDecimal.max(strike.minus(underlying), 0);
    const payoff = intrinsic.minus(premium).times(CONTRACT_SIZE);
    // Recharts uses IEEE-754 for SVG positions; convert only at this presentation boundary.
    return { underlying: underlying.toNumber(), payoff: payoff.toNumber() };
  });
}

export function OptionsChain() {
  const t = useTranslations('advancedAssets.chain');
  const tCommon = useTranslations('advancedAssets.common');
  const locale = useLocale();
  const [symbol, setSymbol] = useState<OptionChainSymbol>('AAPL');
  const [chain, setChain] = useState<OptionsChainResult>(() => getDemoOptionsChain('AAPL'));
  const [selectedExpiryDate, setSelectedExpiryDate] = useState('2026-12-18');
  const [selectedStrike, setSelectedStrike] = useState('240.00');
  const [optionType, setOptionType] = useState<'CALL' | 'PUT'>('CALL');
  const [payoffOpen, setPayoffOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const expiry = getSelectedExpiry(chain, selectedExpiryDate);
  const selectedQuote = expiry?.quotes.find((quote) => quote.strike === selectedStrike) ?? expiry?.quotes[0];

  const payoffData = useMemo(
    () => selectedQuote ? buildPayoffData(selectedQuote, optionType) : [],
    [optionType, selectedQuote],
  );
  const selectedPremium = selectedQuote
    ? optionType === 'CALL' ? selectedQuote.callAsk : selectedQuote.putAsk
    : '0.00';

  const changeSymbol = (nextSymbol: OptionChainSymbol) => {
    const nextChain = getDemoOptionsChain(nextSymbol);
    const firstExpiry = nextChain.expiries[0];
    const atmStrike = nextSymbol === 'AAPL' ? '240.00' : '610.00';
    setSymbol(nextSymbol);
    setChain(nextChain);
    setSelectedExpiryDate(firstExpiry?.expiryDate ?? '');
    setSelectedStrike(atmStrike);
    setError(null);
  };

  const refreshChain = async () => {
    setRefreshing(true);
    setError(null);
    try {
      const response = await api.post<{ result: OptionsChainResult }>('/advanced-assets/options/chain', {
        symbol,
        asOfDate: new Date().toISOString().slice(0, 10),
      });
      setChain(response.data.result);
      setSelectedExpiryDate(response.data.result.expiries[0]?.expiryDate ?? '');
      setSelectedStrike(symbol === 'AAPL' ? '240.00' : '610.00');
    } catch (requestError) {
      setError(`${apiErrorMessage(requestError, tCommon('errorFallback'))} ${t('refreshFallback')}`);
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center gap-2">
            <h2 className="text-lg font-bold tracking-[-0.03em] text-[#1d3027]">{t('title')}</h2>
            <StatusChip tone="blue">{t('modelled')}</StatusChip>
          </div>
          <p className="text-xs text-[#78847d]">{t('subtitle')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <label className="flex h-10 items-center gap-2 rounded-xl border border-[#dfe6e1] bg-white px-3 text-xs font-semibold text-[#53635a]">
            <SlidersHorizontal className="h-3.5 w-3.5 text-[#738279]" />
            <span className="sr-only">{t('underlyingSymbol')}</span>
            <select aria-label={t('underlyingSymbol')} value={symbol} onChange={(event) => changeSymbol(event.target.value as OptionChainSymbol)} className="bg-transparent outline-none">
              {SYMBOLS.map((item) => <option key={item} value={item}>{item}</option>)}
            </select>
          </label>
          <button type="button" onClick={refreshChain} disabled={refreshing} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:cursor-wait disabled:opacity-60">
            <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? t('refreshing') : t('refresh')}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <div className="rounded-2xl border border-[#e7ebe8] bg-white p-4 shadow-[0_6px_22px_rgba(20,52,42,0.025)] sm:p-5">
          <p className="text-[10px] font-semibold text-[#7f8b84]">{t('underlying')}</p>
          <p className="mt-2.5 font-sans text-xl font-bold tracking-[-0.04em] text-[#1c3027]">{symbol} · {formatCurrency(chain.underlyingPrice, 'USD')}</p>
          <p className="mt-2 text-[9px] text-[#8d9992]">{t('scenarioSpot', { date: compactDate(chain.asOfDate, locale) })}</p>
        </div>
        <div className="rounded-2xl border border-[#e7ebe8] bg-white p-4 shadow-[0_6px_22px_rgba(20,52,42,0.025)] sm:p-5">
          <p className="text-[10px] font-semibold text-[#7f8b84]">{t('riskFreeRate')}</p>
          <p className="mt-2.5 font-sans text-xl font-bold tracking-[-0.04em] text-[#1c3027]">{formatRatioAsPercent(chain.riskFreeRate)}</p>
          <p className="mt-2 text-[9px] text-[#8d9992]">{t('annualizedInput')}</p>
        </div>
        <div className="rounded-2xl border border-[#e7ebe8] bg-white p-4 shadow-[0_6px_22px_rgba(20,52,42,0.025)] sm:p-5">
          <p className="text-[10px] font-semibold text-[#7f8b84]">{t('expiryCycles')}</p>
          <p className="mt-2.5 font-sans text-xl font-bold tracking-[-0.04em] text-[#1c3027]">{chain.expiries.length}</p>
          <p className="mt-2 text-[9px] text-[#8d9992]">{t('sampleDates')}</p>
        </div>
        <div className="rounded-2xl border border-[#e7ebe8] bg-white p-4 shadow-[0_6px_22px_rgba(20,52,42,0.025)] sm:p-5">
          <p className="text-[10px] font-semibold text-[#7f8b84]">{t('pricingSource')}</p>
          <p className="mt-2.5 flex items-center gap-2 font-sans text-sm font-bold text-[#1c3027]"><Activity className="h-4 w-4 text-[#437352]" />{tCommon('blackScholes')}</p>
          <p className="mt-2 text-[9px] text-[#8d9992]">{t('decimalEngine')}</p>
        </div>
      </div>

      <SectionCard title={t('chainTitle', { symbol })} eyebrow={t('chainEyebrow', { spot: formatCurrency(chain.underlyingPrice, 'USD'), date: compactDate(chain.asOfDate, locale) })} action={<StatusChip tone="gold">{t('snapshot')}</StatusChip>}>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label={t('expiryDates')}>
            {chain.expiries.map((item) => (
              <button
                key={item.expiryDate}
                type="button"
                role="tab"
                aria-selected={item.expiryDate === expiry?.expiryDate}
                onClick={() => setSelectedExpiryDate(item.expiryDate)}
                className={`rounded-xl px-3 py-2 text-[10px] font-semibold transition ${item.expiryDate === expiry?.expiryDate ? 'bg-[#14342a] text-white' : 'border border-[#e4eae6] bg-white text-[#66736b] hover:border-[#9caea2] hover:text-[#14342a]'}`}
              >
                {compactDate(item.expiryDate, locale)}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[9px] text-[#7b8780]" aria-label={t('moneynessLegend')}>
            <span className="rounded-full bg-[#edf6f0] px-2.5 py-1 font-semibold text-[#2d6747]">ITM</span>
            <span className="rounded-full bg-[#fcf7e7] px-2.5 py-1 font-semibold text-[#8d7132]">ATM</span>
            <span className="rounded-full bg-[#fcf1ef] px-2.5 py-1 font-semibold text-[#a25349]">OTM</span>
          </div>
        </div>

        {error && <p role="alert" className="mb-4 flex items-start gap-2 rounded-xl border border-[#eee2c8] bg-[#fbf8f0] px-3 py-2.5 text-[10px] leading-4 text-[#74694f]"><CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />{error}</p>}

        <div className="overflow-x-auto rounded-xl border border-[#edf0ee]">
          <table className="w-full min-w-[960px] border-collapse text-left" data-testid="options-chain-table">
            <thead>
              <tr className="bg-[#f8faf8] text-[9px] uppercase tracking-[0.12em] text-[#89958e]">
                <th rowSpan={2} className="sticky left-0 z-10 border-b border-[#e8ede9] bg-[#f8faf8] px-4 py-3 text-left font-semibold">{t('strike')}</th>
                <th colSpan={4} className="border-b border-[#e8ede9] px-3 py-2 text-center font-bold text-[#386b4b]">{t('call')}</th>
                <th colSpan={4} className="border-b border-[#e8ede9] px-3 py-2 text-center font-bold text-[#8a6e30]">{t('put')}</th>
              </tr>
              <tr className="bg-[#fbfcfb] text-[8px] uppercase tracking-[0.1em] text-[#9aa49e]">
                {(['bid', 'ask', 'iv', 'delta', 'bid', 'ask', 'iv', 'delta'] as const).map((heading, index) => <th key={`${heading}-${index}`} className="border-b border-[#edf0ee] px-3 py-2.5 text-right font-semibold">{t(heading)}</th>)}
              </tr>
            </thead>
            <tbody>
              {expiry?.quotes.map((quote) => (
                <tr key={`${expiry.expiryDate}-${quote.strike}`} className={`border-b border-[#f0f2f0] last:border-0 ${quote.strike === selectedStrike ? 'ring-1 ring-inset ring-[#9ab7a1]' : ''}`}>
                  <th scope="row" className={`sticky left-0 z-[1] min-w-[116px] px-4 py-3 text-left ${quote.strike === selectedStrike ? 'bg-[#f4f8f5]' : 'bg-white'}`}>
                    <button type="button" onClick={() => setSelectedStrike(quote.strike)} aria-label={t('selectStrike', { strike: quote.strike })} className="flex w-full items-center justify-between gap-2 text-xs font-bold text-[#263b30]">
                      {formatCurrency(quote.strike, 'USD', 0)}
                      {quote.callMoneyness === 'ATM' && <span className="rounded-full bg-[#fcf7e7] px-1.5 py-0.5 text-[7px] font-bold text-[#8d7132]">ATM</span>}
                    </button>
                  </th>
                  <td className={`px-3 py-3 text-right text-[10px] font-semibold ${toneForMoneyness(quote.callMoneyness)}`}>{formatCurrency(quote.callBid, 'USD')}</td>
                  <td className={`px-3 py-3 text-right text-[10px] font-semibold ${toneForMoneyness(quote.callMoneyness)}`}>{formatCurrency(quote.callAsk, 'USD')}</td>
                  <td className={`px-3 py-3 text-right text-[10px] ${toneForMoneyness(quote.callMoneyness)}`}>{formatRatioAsPercent(quote.callIV)}</td>
                  <td className={`px-3 py-3 text-right text-[10px] ${toneForMoneyness(quote.callMoneyness)}`}>
                    <span className="block">{formatFixed(quote.callDelta, 4)}</span>
                    <span aria-label={t('callMoneyness', { value: quote.callMoneyness })} className={`mt-1 inline-flex rounded-full px-1.5 py-0.5 text-[7px] font-bold ${toneForMoneyness(quote.callMoneyness)}`}>{quote.callMoneyness}</span>
                  </td>
                  <td className={`px-3 py-3 text-right text-[10px] font-semibold ${toneForMoneyness(quote.putMoneyness)}`}>{formatCurrency(quote.putBid, 'USD')}</td>
                  <td className={`px-3 py-3 text-right text-[10px] font-semibold ${toneForMoneyness(quote.putMoneyness)}`}>{formatCurrency(quote.putAsk, 'USD')}</td>
                  <td className={`px-3 py-3 text-right text-[10px] ${toneForMoneyness(quote.putMoneyness)}`}>{formatRatioAsPercent(quote.putIV)}</td>
                  <td className={`px-3 py-3 text-right text-[10px] ${toneForMoneyness(quote.putMoneyness)}`}>
                    <span className="block">{formatFixed(quote.putDelta, 4)}</span>
                    <span aria-label={t('putMoneyness', { value: quote.putMoneyness })} className={`mt-1 inline-flex rounded-full px-1.5 py-0.5 text-[7px] font-bold ${toneForMoneyness(quote.putMoneyness)}`}>{quote.putMoneyness}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex flex-col justify-between gap-3 rounded-2xl border border-[#e7ece8] bg-[#fbfcfb] p-4 sm:flex-row sm:items-center">
          <div>
            <p className="text-[10px] font-semibold text-[#425249]">{t('payoffSelection')}</p>
            <p className="mt-1 text-[9px] text-[#87928b]">{t('selectedStrike', { strike: selectedQuote?.strike ?? '—', type: t(optionType === 'CALL' ? 'call' : 'put'), multiplier: CONTRACT_SIZE })}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="sr-only" htmlFor="chain-option-type">{t('optionType')}</label>
            <select id="chain-option-type" value={optionType} onChange={(event) => setOptionType(event.target.value as 'CALL' | 'PUT')} className="h-9 rounded-xl border border-[#dfe6e1] bg-white px-3 text-[10px] font-semibold text-[#415349] outline-none focus:border-[#14342a]">
              <option value="CALL">{t('callPayoff')}</option><option value="PUT">{t('putPayoff')}</option>
            </select>
            <label className="sr-only" htmlFor="chain-selected-strike">{t('selectedStrikeAria')}</label>
            <select id="chain-selected-strike" aria-label={t('selectedStrikeAria')} value={selectedStrike} onChange={(event) => setSelectedStrike(event.target.value)} className="h-9 rounded-xl border border-[#dfe6e1] bg-white px-3 text-[10px] font-semibold text-[#415349] outline-none focus:border-[#14342a]">
              {expiry?.quotes.map((quote) => <option key={quote.strike} value={quote.strike}>{t('strikeOption', { value: formatCurrency(quote.strike, 'USD', 0) })}</option>)}
            </select>
            <button type="button" onClick={() => setPayoffOpen(true)} disabled={!selectedQuote} className="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-[#14342a] px-3.5 text-[10px] font-semibold text-white transition hover:bg-[#0f261e] disabled:opacity-50">
              <Search className="h-3.5 w-3.5" />{t('selectStrikeButton')}
            </button>
          </div>
        </div>
        <p className="mt-3 flex items-start gap-2 text-[9px] leading-4 text-[#929d96]"><CircleAlert className="mt-0.5 h-3 w-3 shrink-0" />{t('quoteCaveat')}</p>
      </SectionCard>

      {payoffOpen && selectedQuote && <Dialog title={t('payoffDialogTitle', { symbol, type: t(optionType === 'CALL' ? 'call' : 'put') })} description={t('payoffDialogDescription')} onClose={() => setPayoffOpen(false)}>
        <div className="mb-4 grid grid-cols-2 gap-3">
          <div className="rounded-xl bg-[#f6f8f6] p-3"><p className="text-[9px] text-[#849088]">{t('strike')}</p><p className="mt-1 text-sm font-bold text-[#263b30]">{formatCurrency(selectedQuote.strike, 'USD')}</p></div>
          <div className="rounded-xl bg-[#f6f8f6] p-3"><p className="text-[9px] text-[#849088]">{t('modelAskPerShare')}</p><p className="mt-1 text-sm font-bold text-[#263b30]">{formatCurrency(selectedPremium, 'USD')}</p></div>
        </div>
        <div className="h-[240px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={payoffData} margin={{ top: 10, right: 12, bottom: 2, left: 4 }}>
              <defs><linearGradient id="chainPayoffFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#467954" stopOpacity={0.22} /><stop offset="100%" stopColor="#467954" stopOpacity={0.015} /></linearGradient></defs>
              <CartesianGrid stroke="#edf1ee" vertical={false} />
              <XAxis dataKey="underlying" type="number" tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} tickFormatter={(value: number) => `$${formatFixed(String(value), 0)}`} />
              <YAxis tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} tickFormatter={(value: number) => formatCurrency(String(value), 'USD', 0)} width={60} />
              <Tooltip formatter={(value: unknown) => [formatCurrency(String(value), 'USD'), t('tooltipNetPayoff')]} labelFormatter={(label: unknown) => t('tooltipUnderlyingAtExpiry', { value: formatCurrency(String(label), 'USD') })} contentStyle={{ borderRadius: 12, borderColor: '#e2e9e4', fontSize: 10 }} />
              <ReferenceLine y={0} stroke="#aeb8b1" strokeDasharray="4 4" />
              <ReferenceLine x={new UiAssetDecimal(selectedQuote.strike).toNumber()} stroke="#b89958" strokeDasharray="4 4" />
              <Area type="monotone" dataKey="payoff" stroke="#36704b" strokeWidth={2.5} fill="url(#chainPayoffFill)" activeDot={{ r: 4, fill: '#14342a' }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-3 flex items-center justify-between border-t border-[#edf0ee] pt-3 text-[9px] text-[#8b9790]"><span>{t('decimalChartNote')}</span><span>{t('expiry', { label: expiry ? compactDate(expiry.expiryDate, locale) : '—' })}</span></div>
      </Dialog>}
    </div>
  );
}
