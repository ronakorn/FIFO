import Decimal from 'decimal.js';
import optionsChainDemo from './optionsChainDemo.json';
import type { OptionChainSymbol, OptionsChainResult } from './types';

export const PolishUiDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export function getDemoOptionsChain(symbol: OptionChainSymbol): OptionsChainResult {
  return optionsChainDemo[symbol] as OptionsChainResult;
}

export interface REITPeerView {
  symbol: string;
  name: string;
  propertyType: string;
  marketPrice: string;
  navPerUnit: string;
  annualDistributionPerUnit: string;
  distributionYield: string;
  priceToNAV: string;
  occupancyRate: string;
  marketCapTHB: string;
}

const reitPeerSeeds: readonly Omit<REITPeerView, 'distributionYield' | 'priceToNAV'>[] = [
  {
    symbol: 'WHART',
    name: 'WHA Premium Growth Freehold & Leasehold',
    propertyType: 'Logistics',
    marketPrice: '10.50',
    navPerUnit: '11.60',
    annualDistributionPerUnit: '0.65',
    occupancyRate: '0.92',
    marketCapTHB: '15000000000',
  },
  {
    symbol: 'CPNREIT',
    name: 'CPN Retail Growth Leasehold REIT',
    propertyType: 'Retail',
    marketPrice: '11.20',
    navPerUnit: '12.40',
    annualDistributionPerUnit: '0.78',
    occupancyRate: '0.91',
    marketCapTHB: '17000000000',
  },
  {
    symbol: 'FTREIT',
    name: 'Frasers Property Thailand Industrial REIT',
    propertyType: 'Industrial',
    marketPrice: '9.30',
    navPerUnit: '10.10',
    annualDistributionPerUnit: '0.59',
    occupancyRate: '0.94',
    marketCapTHB: '18000000000',
  },
  {
    symbol: 'SIRI',
    name: 'SIRI · illustrative residential peer',
    propertyType: 'Residential / mixed-use',
    marketPrice: '8.70',
    navPerUnit: '9.10',
    annualDistributionPerUnit: '0.64',
    occupancyRate: '0.88',
    marketCapTHB: '11000000000',
  },
  {
    symbol: 'LHHOTEL',
    name: 'LH Hotel Leasehold Real Estate Investment Trust',
    propertyType: 'Hospitality',
    marketPrice: '10.00',
    navPerUnit: '10.80',
    annualDistributionPerUnit: '0.85',
    occupancyRate: '0.76',
    marketCapTHB: '14000000000',
  },
];

export function getSampleREITPeers(): REITPeerView[] {
  return reitPeerSeeds.map((peer) => {
    const price = new PolishUiDecimal(peer.marketPrice);
    return {
      ...peer,
      distributionYield: new PolishUiDecimal(peer.annualDistributionPerUnit).dividedBy(price).toFixed(6),
      priceToNAV: price.dividedBy(peer.navPerUnit).toFixed(6),
    };
  });
}

export type PESampleStage = 'VENTURE' | 'GROWTH' | 'BUYOUT';
export type PESampleStatus = 'INVESTING' | 'VALUE_CREATION' | 'HARVESTING';
export type PESampleSort = 'IRR' | 'TVPI';
export type PESampleSortDirection = 'ASC' | 'DESC';

export interface PESampleCashFlow {
  date: string;
  amount: string;
  type: 'CALL' | 'DISTRIBUTION';
}

export interface PESampleFund {
  id: string;
  name: string;
  vintage: number;
  stage: PESampleStage;
  tvpi: string;
  dpi: string;
  irr: string;
  status: PESampleStatus;
  aumTHB: string;
  cashFlows: PESampleCashFlow[];
}

const peFunds: readonly PESampleFund[] = [
  {
    id: 'northstar-growth-iii', name: 'Northstar Growth III', vintage: 2021, stage: 'GROWTH',
    tvpi: '1.5526', dpi: '0.3947', irr: '0.120834', status: 'HARVESTING', aumTHB: '5000000000',
    cashFlows: [
      { date: '2021-06-30', amount: '-1200000000', type: 'CALL' },
      { date: '2022-06-30', amount: '-1400000000', type: 'CALL' },
      { date: '2023-06-30', amount: '-1200000000', type: 'CALL' },
      { date: '2024-06-30', amount: '200000000', type: 'DISTRIBUTION' },
      { date: '2025-06-30', amount: '600000000', type: 'DISTRIBUTION' },
      { date: '2026-06-30', amount: '5100000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'siam-ventures-select', name: 'Siam Ventures Select', vintage: 2023, stage: 'VENTURE',
    tvpi: '1.2500', dpi: '0.1000', irr: '0.079149', status: 'INVESTING', aumTHB: '2200000000',
    cashFlows: [
      { date: '2023-04-01', amount: '-700000000', type: 'CALL' },
      { date: '2024-04-01', amount: '-700000000', type: 'CALL' },
      { date: '2025-10-01', amount: '140000000', type: 'DISTRIBUTION' },
      { date: '2026-10-01', amount: '1610000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'ggv-capital-growth', name: 'GGV Capital Growth Fund', vintage: 2022, stage: 'BUYOUT',
    tvpi: '1.8000', dpi: '0.4000', irr: '0.176268', status: 'HARVESTING', aumTHB: '2500000000',
    cashFlows: [
      { date: '2022-03-31', amount: '-800000000', type: 'CALL' },
      { date: '2023-03-31', amount: '-1200000000', type: 'CALL' },
      { date: '2024-12-31', amount: '400000000', type: 'DISTRIBUTION' },
      { date: '2025-12-31', amount: '400000000', type: 'DISTRIBUTION' },
      { date: '2026-10-01', amount: '2800000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'east-ventures-fund', name: 'East Ventures', vintage: 2024, stage: 'VENTURE',
    tvpi: '1.1000', dpi: '0.0000', irr: '0.065185', status: 'INVESTING', aumTHB: '1200000000',
    cashFlows: [
      { date: '2024-02-01', amount: '-350000000', type: 'CALL' },
      { date: '2025-02-01', amount: '-350000000', type: 'CALL' },
      { date: '2026-02-01', amount: '770000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'openspace-ventures-iv', name: 'Openspace Ventures IV', vintage: 2022, stage: 'GROWTH',
    tvpi: '1.3200', dpi: '0.2000', irr: '0.077458', status: 'VALUE_CREATION', aumTHB: '1800000000',
    cashFlows: [
      { date: '2022-01-15', amount: '-700000000', type: 'CALL' },
      { date: '2023-01-15', amount: '-800000000', type: 'CALL' },
      { date: '2024-06-30', amount: '100000000', type: 'DISTRIBUTION' },
      { date: '2025-06-30', amount: '200000000', type: 'DISTRIBUTION' },
      { date: '2026-06-30', amount: '1680000000', type: 'DISTRIBUTION' },
    ],
  },
];

export function getSamplePEFunds(): PESampleFund[] {
  return peFunds.map((fund) => ({ ...fund, cashFlows: fund.cashFlows.map((cashFlow) => ({ ...cashFlow })) }));
}

export interface PESampleFilters {
  stage: PESampleStage | 'ALL';
  vintageFrom: number;
  vintageTo: number;
  minIRRPercent: string;
  maxIRRPercent: string;
  minTVPI: string;
  maxTVPI: string;
  sortBy: PESampleSort;
  sortDirection: PESampleSortDirection;
}

function optionalDecimal(value: string, label: string): Decimal | undefined {
  if (value.trim() === '') return undefined;
  const parsed = new PolishUiDecimal(value);
  if (!parsed.isFinite()) throw new Error(`${label} must be a finite decimal string.`);
  return parsed;
}

export function filterPESampleFunds(funds: readonly PESampleFund[], filters: PESampleFilters): PESampleFund[] {
  const minIrrPercent = optionalDecimal(filters.minIRRPercent, 'minIRRPercent');
  const maxIrrPercent = optionalDecimal(filters.maxIRRPercent, 'maxIRRPercent');
  const minTvpi = optionalDecimal(filters.minTVPI, 'minTVPI');
  const maxTvpi = optionalDecimal(filters.maxTVPI, 'maxTVPI');
  if (minIrrPercent?.isNegative() || maxIrrPercent?.isNegative()) throw new Error('IRR percentage bounds cannot be negative.');
  if (minTvpi?.isNegative() || maxTvpi?.isNegative()) throw new Error('TVPI bounds cannot be negative.');
  if (minIrrPercent && maxIrrPercent && minIrrPercent.gt(maxIrrPercent)) throw new Error('Minimum IRR cannot exceed maximum IRR.');
  if (minTvpi && maxTvpi && minTvpi.gt(maxTvpi)) throw new Error('Minimum TVPI cannot exceed maximum TVPI.');
  if (!Number.isInteger(filters.vintageFrom) || !Number.isInteger(filters.vintageTo) || filters.vintageFrom > filters.vintageTo) {
    throw new Error('Vintage year range must be a valid ascending integer range.');
  }

  const filtered = funds.filter((fund) => {
    if (filters.stage !== 'ALL' && fund.stage !== filters.stage) return false;
    if (fund.vintage < filters.vintageFrom || fund.vintage > filters.vintageTo) return false;
    const irr = new PolishUiDecimal(fund.irr);
    const tvpi = new PolishUiDecimal(fund.tvpi);
    if (minIrrPercent && irr.lt(minIrrPercent.dividedBy(100))) return false;
    if (maxIrrPercent && irr.gt(maxIrrPercent.dividedBy(100))) return false;
    if (minTvpi && tvpi.lt(minTvpi)) return false;
    if (maxTvpi && tvpi.gt(maxTvpi)) return false;
    return true;
  });

  const direction = filters.sortDirection === 'ASC' ? 1 : -1;
  return filtered.sort((left, right) => {
    const leftValue = new PolishUiDecimal(filters.sortBy === 'IRR' ? left.irr : left.tvpi);
    const rightValue = new PolishUiDecimal(filters.sortBy === 'IRR' ? right.irr : right.tvpi);
    return leftValue.comparedTo(rightValue) * direction || left.name.localeCompare(right.name);
  });
}

export function formatAumBillions(value: string): string {
  return new PolishUiDecimal(value).dividedBy('1000000000').toFixed(1);
}
