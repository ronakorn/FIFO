'use client';

import React, { useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import { Download, Plus, SlidersHorizontal, Trash2 } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { formatFixed, formatRatioAsPercent, UiAssetDecimal } from './format';
import { getSampleREITPeers } from './polishData';
import { SectionCard, StatusChip } from './ui';

const MAX_COMPARISON_PEERS = 5;
const INITIAL_SELECTED = ['WHART', 'CPNREIT', 'FTREIT'];
function csvCell(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

export function REITsComparison() {
  const t = useTranslations('advancedAssets.reits');
  const tCommon = useTranslations('advancedAssets.common');
  const propertyTypeLabels: Record<string, string> = {
    Logistics: t('logistics'),
    Retail: t('retail'),
    Industrial: t('industrial'),
    'Residential / mixed-use': t('residentialMixedUse'),
    Hospitality: t('hospitality'),
  };
  const peers = useMemo(() => getSampleREITPeers(), []);
  const [selectedSymbols, setSelectedSymbols] = useState<string[]>(INITIAL_SELECTED);
  const selectedPeers = useMemo(
    () => peers.filter((peer) => selectedSymbols.includes(peer.symbol)),
    [peers, selectedSymbols],
  );
  const chartData = useMemo(() => selectedPeers.map((peer) => ({
    symbol: peer.symbol,
    yieldPercent: new UiAssetDecimal(peer.distributionYield).times(100).toNumber(),
  })), [selectedPeers]);
  const canAddMore = selectedSymbols.length < MAX_COMPARISON_PEERS;

  const togglePeer = (symbol: string) => {
    setSelectedSymbols((current) => current.includes(symbol)
      ? current.filter((selected) => selected !== symbol)
      : current.length < MAX_COMPARISON_PEERS ? [...current, symbol] : current);
  };

  const exportComparison = () => {
    const headers = [t('peerCsvHeaderName'), t('peerCsvHeaderType'), t('peerCsvHeaderYield'), t('peerCsvHeaderPriceNav'), t('peerCsvHeaderOccupancy'), t('peerCsvHeaderMarketCap')];
    const rows = selectedPeers.map((peer) => [
      `${peer.symbol} — ${peer.symbol === 'SIRI' ? t('siriPeerName') : peer.name}`,
      propertyTypeLabels[peer.propertyType] ?? peer.propertyType,
      formatRatioAsPercent(peer.distributionYield),
      `${formatFixed(peer.priceToNAV, 4)}x`,
      formatRatioAsPercent(peer.occupancyRate),
      peer.marketCapTHB,
    ]);
    const csv = [headers, ...rows].map((row) => row.map(csvCell).join(',')).join('\r\n');
    const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'reit-peer-comparison.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center gap-2"><h2 className="text-lg font-bold tracking-[-0.03em] text-[#1d3027]">{t('comparisonTitle')}</h2><StatusChip tone="blue">{t('peerSet')}</StatusChip></div>
          <p className="text-xs text-[#78847d]">{t('comparisonSubtitle')}</p>
        </div>
        <button type="button" onClick={exportComparison} disabled={selectedPeers.length === 0} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:cursor-not-allowed disabled:opacity-50">
          <Download className="h-3.5 w-3.5" />{t('exportComparison')}
        </button>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#e4ebe6] bg-[#f7faf8] px-4 py-3 text-[10px] text-[#647269]">
        <span className="inline-flex items-center gap-2"><SlidersHorizontal className="h-3.5 w-3.5 text-[#66806f]" />{t('selectedForChart', { selected: selectedPeers.length, maximum: MAX_COMPARISON_PEERS })}</span>
        <span className="text-[9px] text-[#8b9790]">{t('peerAssumptions')}</span>
      </div>

      <div className="grid gap-5 xl:grid-cols-[0.95fr_1.35fr]">
        <SectionCard title={t('distributionYieldTitle')} eyebrow={t('annualDistributionPrice')} action={<StatusChip tone="green">{t('thbUnit')}</StatusChip>}>
          <div className="mb-2 flex flex-wrap gap-2">
            {selectedPeers.map((peer) => <span key={peer.symbol} className="rounded-full border border-[#e0e8e2] bg-[#f8faf8] px-2.5 py-1 text-[8px] font-semibold text-[#5c7062]">{peer.symbol}</span>)}
            {selectedPeers.length === 0 && <span className="text-[9px] text-[#89958e]">{t('addPeer')}</span>}
          </div>
          <div className="h-[270px] w-full" data-testid="reit-yield-chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
                <CartesianGrid stroke="#edf1ee" vertical={false} />
                <XAxis dataKey="symbol" tickLine={false} axisLine={false} tick={{ fill: '#7d8982', fontSize: 9 }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} tickFormatter={(value: number) => `${value.toFixed(0)}%`} width={36} />
                <Tooltip formatter={(value: unknown) => [`${formatFixed(String(value), 2)}%`, t('peerChartYield')]} contentStyle={{ borderRadius: 12, borderColor: '#e2e9e4', fontSize: 10 }} />
                <Bar dataKey="yieldPercent" fill="#4e7b5c" radius={[6, 6, 0, 0]} maxBarSize={42} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 text-[9px] leading-4 text-[#98a39c]">{t('chartNumberNote')}</p>
        </SectionCard>

        <SectionCard title={t('peerSetTitle')} eyebrow={t('peerTableEyebrow')} action={<span className="text-[9px] font-semibold text-[#819087]">{t('sortCsv')}</span>}>
          <div className="overflow-x-auto rounded-xl border border-[#edf0ee]">
            <table className="w-full min-w-[850px] border-collapse text-left" data-testid="reit-comparison-table">
              <thead><tr className="bg-[#f8faf8] text-[8px] uppercase tracking-[0.1em] text-[#8b9790]">
                <th className="px-3 py-3 font-semibold">{t('peerCsvHeaderName')}</th><th className="px-3 py-3 font-semibold">{t('peerCsvHeaderType')}</th><th className="px-3 py-3 text-right font-semibold">{t('peerCsvHeaderYield')}</th><th className="px-3 py-3 text-right font-semibold">{t('peerCsvHeaderPriceNav')}</th><th className="px-3 py-3 text-right font-semibold">{t('peerCsvHeaderOccupancy')}</th><th className="px-3 py-3 text-right font-semibold">{t('peerCsvHeaderMarketCap')}</th><th className="px-3 py-3 text-right font-semibold">{t('compare')}</th>
              </tr></thead>
              <tbody>{peers.map((peer) => {
                const selected = selectedSymbols.includes(peer.symbol);
                return (
                  <tr key={peer.symbol} className="border-t border-[#edf0ee] hover:bg-[#fbfcfb]">
                    <td className="px-3 py-3"><strong className="block text-[10px] font-bold text-[#2b4034]">{peer.symbol}</strong><span className="mt-1 block max-w-[190px] truncate text-[8px] text-[#929d96]">{peer.symbol === 'SIRI' ? t('siriPeerName') : peer.name}</span></td>
                    <td className="px-3 py-3 text-[9px] text-[#647269]">{propertyTypeLabels[peer.propertyType] ?? peer.propertyType}</td>
                    <td className="px-3 py-3 text-right text-[10px] font-bold text-[#347454]">{formatRatioAsPercent(peer.distributionYield)}</td>
                    <td className="px-3 py-3 text-right text-[10px] font-semibold text-[#475b4e]">{formatFixed(peer.priceToNAV, 2)}×</td>
                    <td className="px-3 py-3 text-right text-[10px] text-[#647269]">{formatRatioAsPercent(peer.occupancyRate)}</td>
                    <td className="px-3 py-3 text-right text-[10px] font-semibold text-[#475b4e]">฿{new UiAssetDecimal(peer.marketCapTHB).dividedBy('1000000000').toFixed(1)} {tCommon('billionUnit')}</td>
                    <td className="px-3 py-3 text-right">
                      <button type="button" aria-label={selected ? t('removePeer', { symbol: peer.symbol }) : t('addPeerAria', { symbol: peer.symbol })} onClick={() => togglePeer(peer.symbol)} disabled={!selected && !canAddMore} className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-2 text-[8px] font-semibold transition disabled:cursor-not-allowed disabled:opacity-40 ${selected ? 'border border-[#e8e2d8] bg-[#fbf8f0] text-[#806d42] hover:bg-[#f8f2e5]' : 'border border-[#dce7df] bg-[#f2f7f3] text-[#346248] hover:bg-[#e9f2eb]'}`}>
                        {selected ? <Trash2 className="h-3 w-3" /> : <Plus className="h-3 w-3" />}{selected ? t('remove') : t('add')}
                      </button>
                    </td>
                  </tr>
                );
              })}</tbody>
            </table>
          </div>
        </SectionCard>
      </div>

      <p className="rounded-2xl border border-[#eee5cf] bg-[#fbf8f0] px-4 py-3 text-[9px] leading-4 text-[#74694f]">{t('comparisonDisclaimer')}</p>
    </div>
  );
}
