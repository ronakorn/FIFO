import Decimal from 'decimal.js';

export const UiAssetDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

function groupIntegerPart(value: string): string {
  return value.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export function formatFixed(value: string, places = 2): string {
  try {
    const decimal = new UiAssetDecimal(value);
    if (!decimal.isFinite()) return '—';
    const fixed = decimal.toDecimalPlaces(places, UiAssetDecimal.ROUND_HALF_UP).toFixed(places);
    const parts = fixed.split('.');
    const integerPart = parts[0] ?? '0';
    const fractionalPart = parts[1];
    const grouped = groupIntegerPart(integerPart.replace('-', ''));
    return `${integerPart.startsWith('-') ? '-' : ''}${grouped}${fractionalPart === undefined ? '' : `.${fractionalPart}`}`;
  } catch {
    return '—';
  }
}

export function formatCurrency(value: string, currency = 'THB', places = 2): string {
  const symbol = currency === 'USD' ? '$' : currency === 'THB' ? '฿' : `${currency} `;
  const formatted = formatFixed(value, places);
  return currency === 'USD' ? `${symbol}${formatted}` : `${symbol}${formatted}`;
}

export function formatRatioAsPercent(value: string, places = 2): string {
  try {
    return `${new UiAssetDecimal(value).times(100).toDecimalPlaces(places, UiAssetDecimal.ROUND_HALF_UP).toFixed(places)}%`;
  } catch {
    return '—';
  }
}

export function formatMultiple(value: string): string {
  return `${formatFixed(value, 2)}×`;
}

export function apiErrorMessage(error: unknown, fallback = 'The calculation could not be completed. Please review the inputs and try again.'): string {
  if (typeof error === 'object' && error !== null && 'response' in error) {
    const response = (error as { response?: { data?: { error?: { message?: string } } } }).response;
    if (response?.data?.error?.message) return response.data.error.message;
  }
  if (error instanceof Error) return error.message;
  return fallback;
}
