'use client';

import React, { useCallback, useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import { ArrowDownWideNarrow, ArrowUpWideNarrow, BriefcaseBusiness, Eye, Search } from 'lucide-react';
import { Area, AreaChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { formatAumBillions, filterPESampleFunds, getSamplePEFunds, type PESampleFund, type PESampleSort, type PESampleSortDirection, type PESampleStage } from './polishData';
import { formatCurrency, formatFixed, formatMultiple, formatRatioAsPercent, UiAssetDecimal } from './format';
import { Dialog, SectionCard, StatusChip } from './ui';

const VINTAGE_YEARS = [2020, 2021, 2022, 2023, 2024, 2025, 2026] as const;

function statusTone(status: PESampleFund['status']): 'green' | 'gold' | 'blue' {
  if (status === 'HARVESTING') return 'green';
  if (status === 'VALUE_CREATION') return 'gold';
  return 'blue';
}

function buildJCurveChartData(fund: PESampleFund): Array<{ year: string; cumulativeBillions: number }> {
  let cumulative = new UiAssetDecimal(0);
  return fund.cashFlows.map((cashFlow) => {
    cumulative = cumulative.plus(cashFlow.amount);
    return {
      year: cashFlow.date.slice(0, 4),
      // Chart conversion is for SVG geometry only; the cash-flow sum stays Decimal until this point.
      cumulativeBillions: cumulative.dividedBy('1000000000').toNumber(),
    };
  });
}

export function PEScreener() {
  const t = useTranslations('advancedAssets.pe');
  const tCommon = useTranslations('advancedAssets.common');
  const stageLabels: Record<PESampleStage, string> = { VENTURE: t('stageVenture'), GROWTH: t('stageGrowth'), BUYOUT: t('stageBuyout') };
  const statusLabels: Record<PESampleFund['status'], string> = { INVESTING: t('statusInvesting'), VALUE_CREATION: t('statusValueCreation'), HARVESTING: t('statusHarvesting') };
  const translateFilterError = useCallback((message: string): string => {
    if (message.includes('IRR percentage bounds')) return t('filterErrorIrrNegative');
    if (message.includes('TVPI bounds')) return t('filterErrorTvpiNegative');
    if (message.includes('Minimum IRR')) return t('filterErrorIrrRange');
    if (message.includes('Minimum TVPI')) return t('filterErrorTvpiRange');
    if (message.includes('Vintage year')) return t('filterErrorVintage');
    if (message.includes('finite decimal')) return t('filterErrorFinite');
    return t('filterErrorFallback');
  }, [t]);
  const funds = useMemo(() => getSamplePEFunds(), []);
  const [stage, setStage] = useState<PESampleStage | 'ALL'>('ALL');
  const [vintageFrom, setVintageFrom] = useState('2020');
  const [vintageTo, setVintageTo] = useState('2026');
  const [minIRRPercent, setMinIRRPercent] = useState('0');
  const [maxIRRPercent, setMaxIRRPercent] = useState('100');
  const [minTVPI, setMinTVPI] = useState('0');
  const [maxTVPI, setMaxTVPI] = useState('5');
  const [sortBy, setSortBy] = useState<PESampleSort>('IRR');
  const [sortDirection, setSortDirection] = useState<PESampleSortDirection>('DESC');
  const [selectedFund, setSelectedFund] = useState<PESampleFund | null>(null);

  const filterState = useMemo(() => {
    try {
      return {
        result: filterPESampleFunds(funds, {
          stage,
          vintageFrom: Number(vintageFrom),
          vintageTo: Number(vintageTo),
          minIRRPercent,
          maxIRRPercent,
          minTVPI,
          maxTVPI,
          sortBy,
          sortDirection,
        }),
        error: null,
      };
    } catch (filterError) {
      return {
        result: [] as PESampleFund[],
        error: filterError instanceof Error ? translateFilterError(filterError.message) : t('filterErrorFallback'),
      };
    }
  }, [funds, maxIRRPercent, maxTVPI, minIRRPercent, minTVPI, sortBy, sortDirection, stage, t, translateFilterError, vintageFrom, vintageTo]);

  const detailChart = useMemo(
    () => selectedFund ? buildJCurveChartData(selectedFund) : [],
    [selectedFund],
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center gap-2"><h2 className="text-lg font-bold tracking-[-0.03em] text-[#1d3027]">{t('screenerTitle')}</h2><StatusChip tone="blue">{t('scenarioDataset')}</StatusChip></div>
          <p className="text-xs text-[#78847d]">{t('screenerSubtitle')}</p>
        </div>
        <div className="inline-flex items-center gap-2 rounded-2xl border border-[#e5e9e6] bg-white px-3.5 py-2.5 text-[10px] text-[#65716b]"><BriefcaseBusiness className="h-4 w-4 text-[#54725f]" /><strong className="text-[#263b30]">{filterState.result.length}</strong> / {funds.length} {t('sampleFunds')}</div>
      </div>

      <SectionCard title={t('criteriaTitle')} eyebrow={t('filterEyebrow')} action={<Search className="h-4 w-4 text-[#78907f]" />}>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('stage')}</span><select aria-label={t('stage')} value={stage} onChange={(event) => setStage(event.target.value as PESampleStage | 'ALL')} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]"><option value="ALL">{t('allStages')}</option><option value="VENTURE">{t('venture')}</option><option value="GROWTH">{t('growth')}</option><option value="BUYOUT">{t('buyout')}</option></select></label>
          <label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('vintageFrom')}</span><select aria-label={t('vintageFrom')} value={vintageFrom} onChange={(event) => setVintageFrom(event.target.value)} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]">{VINTAGE_YEARS.map((year) => <option key={year} value={year}>{year}</option>)}</select></label>
          <label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('vintageTo')}</span><select aria-label={t('vintageTo')} value={vintageTo} onChange={(event) => setVintageTo(event.target.value)} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]">{VINTAGE_YEARS.map((year) => <option key={year} value={year}>{year}</option>)}</select></label>
          <div className="grid grid-cols-2 gap-2"><label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('minIrr')}</span><input aria-label={t('minIrr')} type="number" min="0" max="100" step="0.5" value={minIRRPercent} onChange={(event) => setMinIRRPercent(event.target.value)} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]" /></label><label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('maxIrr')}</span><input aria-label={t('maxIrr')} type="number" min="0" max="100" step="0.5" value={maxIRRPercent} onChange={(event) => setMaxIRRPercent(event.target.value)} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]" /></label></div>
          <div className="grid grid-cols-2 gap-2"><label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('minTvpi')}</span><input aria-label={t('minTvpi')} type="number" min="0" step="0.05" value={minTVPI} onChange={(event) => setMinTVPI(event.target.value)} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]" /></label><label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('maxTvpi')}</span><input aria-label={t('maxTvpi')} type="number" min="0" step="0.05" value={maxTVPI} onChange={(event) => setMaxTVPI(event.target.value)} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]" /></label></div>
          <label className="block"><span className="mb-1.5 block text-[9px] font-semibold text-[#68766d]">{t('sortBy')}</span><select aria-label={t('sortBy')} value={sortBy} onChange={(event) => setSortBy(event.target.value as PESampleSort)} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-xs font-semibold text-[#263b30] outline-none focus:border-[#14342a]"><option value="IRR">IRR</option><option value="TVPI">TVPI</option></select></label>
          <button type="button" onClick={() => setSortDirection((current) => current === 'DESC' ? 'ASC' : 'DESC')} className="mt-5 inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-[#dfe6e1] bg-white px-3 text-[10px] font-semibold text-[#53635a] transition hover:border-[#14342a]" aria-label={t('sortAria', { direction: t(sortDirection === 'DESC' ? 'ascending' : 'descending') })}>
            {sortDirection === 'DESC' ? <ArrowDownWideNarrow className="h-3.5 w-3.5" /> : <ArrowUpWideNarrow className="h-3.5 w-3.5" />}{t(sortDirection === 'DESC' ? 'highestFirst' : 'lowestFirst')}
          </button>
        </div>
        {filterState.error && <p role="alert" className="mt-3 rounded-xl border border-[#f0dcd8] bg-[#fcf1ef] px-3 py-2 text-[9px] text-[#a24f43]">{filterState.error}</p>}
      </SectionCard>

      <SectionCard title={t('universeTitle')} eyebrow={t('universeEyebrow')} action={<span className="text-[9px] font-semibold text-[#87928b]">{t('sortLabel', { metric: sortBy, direction: t(sortDirection === 'DESC' ? 'descending' : 'ascending') })}</span>}>
        <div className="overflow-x-auto rounded-xl border border-[#edf0ee]">
          <table className="w-full min-w-[920px] border-collapse text-left" data-testid="pe-screener-table">
            <thead><tr className="bg-[#f8faf8] text-[8px] uppercase tracking-[0.1em] text-[#8b9790]"><th className="px-3 py-3 font-semibold">{t('fundName')}</th><th className="px-3 py-3 text-right font-semibold">{t('vintage')}</th><th className="px-3 py-3 font-semibold">{t('stage')}</th><th className="px-3 py-3 text-right font-semibold">{t('tvpi')}</th><th className="px-3 py-3 text-right font-semibold">{t('dpi')}</th><th className="px-3 py-3 text-right font-semibold">{t('irr')}</th><th className="px-3 py-3 font-semibold">{t('status')}</th><th className="px-3 py-3 text-right font-semibold">{t('aum')}</th><th className="px-3 py-3 text-right font-semibold">{t('details')}</th></tr></thead>
            <tbody>
              {filterState.result.map((fund) => (
                <tr key={fund.id} className="border-t border-[#edf0ee] hover:bg-[#fbfcfb]">
                  <td className="px-3 py-3 text-[10px] font-bold text-[#2b4034]">{fund.name}</td>
                  <td className="px-3 py-3 text-right text-[10px] text-[#66736b]">{fund.vintage}</td>
                  <td className="px-3 py-3 text-[9px] text-[#66736b]">{stageLabels[fund.stage]}</td>
                  <td className="px-3 py-3 text-right text-[10px] font-bold text-[#304b3b]">{formatMultiple(fund.tvpi)}</td>
                  <td className="px-3 py-3 text-right text-[10px] text-[#66736b]">{formatMultiple(fund.dpi)}</td>
                  <td className="px-3 py-3 text-right text-[10px] font-bold text-[#347454]">{formatRatioAsPercent(fund.irr)}</td>
                  <td className="px-3 py-3"><StatusChip tone={statusTone(fund.status)}>{statusLabels[fund.status]}</StatusChip></td>
                  <td className="px-3 py-3 text-right text-[10px] font-semibold text-[#475b4e]">฿{formatAumBillions(fund.aumTHB)} {tCommon('billionUnit')}</td>
                  <td className="px-3 py-3 text-right"><button type="button" aria-label={t('viewDetails', { name: fund.name })} onClick={() => setSelectedFund(fund)} className="inline-flex items-center gap-1 rounded-lg border border-[#dce7df] bg-[#f2f7f3] px-2.5 py-2 text-[8px] font-semibold text-[#346248] transition hover:bg-[#e9f2eb]"><Eye className="h-3 w-3" />{t('viewDetailsButton')}</button></td>
                </tr>
              ))}
              {filterState.result.length === 0 && <tr><td colSpan={9} className="px-4 py-10 text-center text-[10px] text-[#8b9790]">{t('noFundsMatch')}</td></tr>}
            </tbody>
          </table>
        </div>
      </SectionCard>

      <p className="rounded-2xl border border-[#eee5cf] bg-[#fbf8f0] px-4 py-3 text-[9px] leading-4 text-[#74694f]">{t('fundDisclaimer')}</p>

      {selectedFund && <Dialog title={selectedFund.name} description={t('fundDetailDescription', { vintage: selectedFund.vintage, stage: stageLabels[selectedFund.stage] })} onClose={() => setSelectedFund(null)}>
        <div className="mb-4 grid grid-cols-3 gap-2">
          <div className="rounded-xl bg-[#f6f8f6] p-3"><p className="text-[8px] text-[#849088]">TVPI</p><p className="mt-1 text-sm font-bold text-[#263b30]">{formatMultiple(selectedFund.tvpi)}</p></div>
          <div className="rounded-xl bg-[#f6f8f6] p-3"><p className="text-[8px] text-[#849088]">DPI</p><p className="mt-1 text-sm font-bold text-[#263b30]">{formatMultiple(selectedFund.dpi)}</p></div>
          <div className="rounded-xl bg-[#f6f8f6] p-3"><p className="text-[8px] text-[#849088]">{t('grossXirr')}</p><p className="mt-1 text-sm font-bold text-[#263b30]">{formatRatioAsPercent(selectedFund.irr)}</p></div>
        </div>
        <SectionCard title={t('jcurve')} eyebrow={t('cumulativeDatedCashflow')} action={<StatusChip tone="gold">{t('illustrative')}</StatusChip>}>
          <div className="h-[220px] w-full" data-testid="pe-jcurve-chart">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={detailChart} margin={{ top: 10, right: 10, bottom: 0, left: 0 }}>
                <defs><linearGradient id="peScreenerCurve" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#467954" stopOpacity={0.23} /><stop offset="100%" stopColor="#467954" stopOpacity={0.02} /></linearGradient></defs>
                <CartesianGrid stroke="#edf1ee" vertical={false} />
                <XAxis dataKey="year" tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 9 }} tickFormatter={(value: number) => `฿${value.toFixed(1)} ${tCommon('billionUnit')}`} width={76} />
                <Tooltip formatter={(value: unknown) => [`฿${formatFixed(new UiAssetDecimal(String(value)).times('1000000000').toFixed(2), 0)}`, t('cumulativeCashFlow')]} labelFormatter={(label: unknown) => t('vintageTimeline', { year: String(label) })} contentStyle={{ borderRadius: 12, borderColor: '#e2e9e4', fontSize: 10 }} />
                <ReferenceLine y={0} stroke="#aeb8b1" strokeDasharray="4 4" />
                <Area type="monotone" dataKey="cumulativeBillions" stroke="#36704b" strokeWidth={2.5} fill="url(#peScreenerCurve)" activeDot={{ r: 4, fill: '#14342a' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
        <div className="mt-4">
          <p className="mb-2 text-[9px] font-bold uppercase tracking-[0.14em] text-[#829087]">{t('cashflowTimelineThb')}</p>
          <div className="max-h-48 space-y-2 overflow-y-auto pr-1" data-testid="pe-cashflow-timeline">
            {selectedFund.cashFlows.map((cashFlow, index) => {
              const amount = new UiAssetDecimal(cashFlow.amount);
              const call = amount.isNegative();
              return <div key={`${cashFlow.date}-${index}`} className="flex items-center justify-between rounded-xl border border-[#e9eeea] bg-[#fbfcfb] px-3 py-2.5"><div><p className="text-[9px] font-semibold text-[#35493d]">{cashFlow.date}</p><p className="mt-0.5 text-[8px] uppercase tracking-wide text-[#98a39c]">{call ? t('capitalCall') : t('distribution')}</p></div><strong className={`text-[10px] ${call ? 'text-[#a75a50]' : 'text-[#347454]'}`}>{call ? '−' : '+'}{formatCurrency(amount.abs().toFixed(2), 'THB', 0)}</strong></div>;
            })}
          </div>
        </div>
      </Dialog>}
    </div>
  );
}
