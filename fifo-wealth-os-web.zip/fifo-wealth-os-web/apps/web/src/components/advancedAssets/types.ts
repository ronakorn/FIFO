export interface GreeksResult {
  theoreticalPrice: string;
  delta: string;
  gamma: string;
  theta: string;
  vega: string;
  rho: string;
  impliedVolatility?: string;
}

export interface REITValuationResult {
  navPerUnit: string;
  marketPrice: string;
  premiumDiscount: string;
  distributionYield: string;
  capRate: string;
  ffoPerUnit: string;
  affoPerUnit: string;
  capRateIsProxy: true;
  affoMaintenanceCapexPerUnit: string;
  notes: string[];
}

export interface DistributionScheduleResult {
  periodAmount: string;
  annualTotal: string;
  periodsPerYear: number;
  paymentDates: string[];
}

export interface PECashFlow {
  date: string;
  amount: string;
  type: 'CALL' | 'DISTRIBUTION' | 'FEE' | 'WRITE_OFF';
}

export interface PEMetricsResult {
  tvpi: string;
  dpi: string;
  rvpi: string;
  moic: string;
  irr: string;
  paidInCapital: string;
  totalDistributions: string;
  residualValue: string;
  committedCapital: string;
  uncalledCapital: string;
}

export interface JCurvePoint {
  date: string;
  cashFlow: string;
  cumulativeCashFlow: string;
  irr: string;
}

export interface MarginHealthResult {
  totalEquity: string;
  totalInitialMargin: string;
  totalMaintenanceMargin: string;
  availableMargin: string;
  marginLevel: string;
  status: 'HEALTHY' | 'WARNING' | 'DANGER' | 'MARGIN_CALL';
}

export type OptionChainSymbol = 'AAPL' | 'SPY';
export type OptionMoneyness = 'ITM' | 'ATM' | 'OTM';

export interface OptionsChainQuote {
  strike: string;
  callBid: string;
  callAsk: string;
  callIV: string;
  callDelta: string;
  callMoneyness: OptionMoneyness;
  putBid: string;
  putAsk: string;
  putIV: string;
  putDelta: string;
  putMoneyness: OptionMoneyness;
}

export interface OptionsChainExpiry {
  expiryDate: string;
  label: string;
  daysToExpiry: number;
  timeToExpiry: string;
  quotes: OptionsChainQuote[];
}

export interface OptionsChainResult {
  symbol: OptionChainSymbol;
  underlyingPrice: string;
  currency: 'USD';
  asOfDate: string;
  riskFreeRate: string;
  source: 'ILLUSTRATIVE_MODEL';
  expiries: OptionsChainExpiry[];
}
