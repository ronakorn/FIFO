'use client';

import React from 'react';
import { useTranslations } from 'next-intl';

export function SectionCard({
  title,
  eyebrow,
  action,
  children,
  className = '',
}: {
  title: string;
  eyebrow?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`rounded-2xl border border-[#e6ebe7] bg-white p-5 shadow-[0_8px_30px_rgba(20,52,42,0.035)] sm:p-6 ${className}`}>
      <div className="mb-5 flex items-start justify-between gap-3">
        <div>
          {eyebrow && <p className="mb-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-[#8d9a92]">{eyebrow}</p>}
          <h2 className="text-sm font-bold tracking-[-0.01em] text-[#1d2d25] sm:text-base">{title}</h2>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

export function MetricCard({
  label,
  value,
  footnote,
  accent = 'green',
}: {
  label: string;
  value: string;
  footnote?: string;
  accent?: 'green' | 'gold' | 'red' | 'blue';
}) {
  const accentClass = {
    green: 'bg-[#edf4f0] text-[#14342a]',
    gold: 'bg-[#f8f3e8] text-[#9a7b36]',
    red: 'bg-[#fbefed] text-[#a24f43]',
    blue: 'bg-[#eef3f8] text-[#526f8e]',
  }[accent];
  return (
    <div className="rounded-2xl border border-[#e7ebe8] bg-white p-4 shadow-[0_6px_22px_rgba(20,52,42,0.025)] sm:p-5">
      <p className="text-[10px] font-semibold text-[#7f8b84]">{label}</p>
      <p className={`mt-2.5 font-sans text-xl font-bold tracking-[-0.04em] sm:text-2xl ${accent === 'red' ? 'text-[#9a4e44]' : 'text-[#1c3027]'}`}>{value}</p>
      {footnote && <p className={`mt-2 inline-flex rounded-full px-2 py-1 text-[9px] font-semibold ${accentClass}`}>{footnote}</p>}
    </div>
  );
}

export function StatusChip({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: 'neutral' | 'green' | 'gold' | 'red' | 'blue' }) {
  const toneClass = {
    neutral: 'border-[#e6ebe7] bg-[#f7f9f8] text-[#65716b]',
    green: 'border-[#dce8e1] bg-[#eff6f1] text-[#276143]',
    gold: 'border-[#eee5cf] bg-[#fbf7ee] text-[#8a7138]',
    red: 'border-[#f0dcd8] bg-[#fcf1ef] text-[#a24f43]',
    blue: 'border-[#dce6ef] bg-[#f1f6fa] text-[#587590]',
  }[tone];
  return <span className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[9px] font-bold uppercase tracking-[0.1em] ${toneClass}`}>{children}</span>;
}

export function Dialog({
  title,
  description,
  onClose,
  children,
}: {
  title: string;
  description?: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  const t = useTranslations('common');
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center overflow-y-auto bg-[#0e211b]/55 p-4 backdrop-blur-sm" onMouseDown={(event) => { if (event.currentTarget === event.target) onClose(); }}>
      <div role="dialog" aria-modal="true" aria-labelledby="advanced-dialog-title" className="my-auto w-full max-w-xl rounded-2xl border border-white/50 bg-white p-5 shadow-[0_24px_80px_rgba(7,23,16,0.24)] sm:p-7">
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <h2 id="advanced-dialog-title" className="text-lg font-bold tracking-[-0.03em] text-[#193127]">{title}</h2>
            {description && <p className="mt-1.5 text-xs leading-5 text-[#748078]">{description}</p>}
          </div>
          <button type="button" aria-label={t('close')} onClick={onClose} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-xl leading-none text-[#758079] transition hover:bg-[#f1f4f2] hover:text-[#14342a]">×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({
  label,
  value,
  onChange,
  suffix,
  step = '0.01',
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  suffix?: string;
  step?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[10px] font-semibold text-[#66736b]">{label}</span>
      <span className="flex items-center rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 transition focus-within:border-[#14342a] focus-within:ring-2 focus-within:ring-[#14342a]/10">
        <input type="number" inputMode="decimal" step={step} value={value} onChange={(event) => onChange(event.target.value)} className="h-10 min-w-0 flex-1 bg-transparent text-sm font-semibold text-[#20342a] outline-none" />
        {suffix && <span className="ml-2 text-[10px] font-medium text-[#8a958e]">{suffix}</span>}
      </span>
    </label>
  );
}
