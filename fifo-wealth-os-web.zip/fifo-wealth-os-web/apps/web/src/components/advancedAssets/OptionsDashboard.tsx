'use client';

import React, { useMemo, useState } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import Decimal from 'decimal.js';
import { Calculator, CircleHelp, Sparkles } from 'lucide-react';
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api from '@/lib/api';
import { apiErrorMessage, formatCurrency, formatRatioAsPercent, UiAssetDecimal } from './format';
import type { GreeksResult } from './types';
import { Dialog, Field, MetricCard, SectionCard, StatusChip } from './ui';

const ChartDecimal = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });
const demoPositions = [
  { symbol: 'AAPL', expiry: '2026-12-18', type: 'CALL', strike: '220.00', quantity: '12', premium: '13.40', delta: '0.6840', gamma: '0.0142', theta: '-0.0820', vega: '0.2610', tone: 'green' as const },
  { symbol: 'SPY', expiry: '2026-09-18', type: 'PUT', strike: '610.00', quantity: '8', premium: '16.20', delta: '-0.4210', gamma: '0.0098', theta: '-0.0950', vega: '0.3170', tone: 'gold' as const },
];

function createPayoffCurve() {
  const strike = new ChartDecimal('220');
  const premium = new ChartDecimal('13.4');
  const contractSize = new ChartDecimal('100');
  const step = new ChartDecimal('5');
  return Array.from({ length: 23 }, (_unused, index) => {
    const underlying = new ChartDecimal('170').plus(step.times(index));
    const intrinsic = ChartDecimal.max(underlying.minus(strike), 0);
    const payoff = intrinsic.minus(premium).times(contractSize);
    // Recharts requires JS numbers for SVG geometry; values are converted only after Decimal calculations are complete.
    return { underlying: underlying.toNumber(), payoff: payoff.toNumber() };
  });
}

const payoffCurve = createPayoffCurve();

const defaultInputs = {
  underlyingPrice: '238.00',
  strikePrice: '220.00',
  timeToExpiry: '0.48',
  riskFreeRate: '0.04',
  volatility: '0.31',
  marketPrice: '32.4666',
};

type CalculatorMode = 'pricing' | 'iv';

export function OptionsDashboard() {
  const locale = useLocale();
  const t = useTranslations('advancedAssets.options');
  const tCommon = useTranslations('advancedAssets.common');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [mode, setMode] = useState<CalculatorMode>('pricing');
  const [optionType, setOptionType] = useState<'CALL' | 'PUT'>('CALL');
  const [inputs, setInputs] = useState(defaultInputs);
  const [result, setResult] = useState<GreeksResult | null>(null);
  const [impliedVolatility, setImpliedVolatility] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const breakeven = useMemo(() => new UiAssetDecimal('220').plus('13.4').toFixed(2), []);
  const payoffAtCurrent = useMemo(() => {
    const current = new UiAssetDecimal('238');
    return current.minus('220').minus('13.4').times(100).toFixed(2);
  }, []);

  const updateInput = (key: keyof typeof defaultInputs, value: string) => setInputs((current) => ({ ...current, [key]: value }));
  const openCalculator = (nextMode: CalculatorMode) => {
    setMode(nextMode);
    setResult(null);
    setImpliedVolatility(null);
    setError(null);
    setDialogOpen(true);
  };

  const calculate = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);
    setImpliedVolatility(null);
    try {
      if (mode === 'pricing') {
        const response = await api.post<{ result: GreeksResult }>('/advanced-assets/options/pricing', {
          underlyingPrice: inputs.underlyingPrice,
          strikePrice: inputs.strikePrice,
          timeToExpiry: inputs.timeToExpiry,
          riskFreeRate: inputs.riskFreeRate,
          volatility: inputs.volatility,
          optionType,
        });
        setResult(response.data.result);
      } else {
        const response = await api.post<{ result: { impliedVolatility: string } }>('/advanced-assets/options/implied-volatility', {
          marketPrice: inputs.marketPrice,
          underlyingPrice: inputs.underlyingPrice,
          strikePrice: inputs.strikePrice,
          timeToExpiry: inputs.timeToExpiry,
          riskFreeRate: inputs.riskFreeRate,
          optionType,
        });
        setImpliedVolatility(response.data.result.impliedVolatility);
      }
    } catch (requestError) {
      setError(apiErrorMessage(requestError, tCommon('errorFallback')));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
        <div>
          <div className="mb-1.5 flex items-center gap-2"><h2 className="text-lg font-bold tracking-[-0.03em] text-[#1d3027]">{t('deskTitle')}</h2><StatusChip tone="green">{tCommon('blackScholes')}</StatusChip></div>
          <p className="text-xs text-[#78847d]">{t('deskSubtitle')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => openCalculator('iv')} className="inline-flex items-center gap-2 rounded-xl border border-[#dfe6e1] bg-white px-3.5 py-2.5 text-xs font-semibold text-[#3b5045] transition hover:border-[#14342a] hover:bg-[#f8faf8]"><Sparkles className="h-3.5 w-3.5" />{t('impliedVolatility')}</button>
          <button type="button" onClick={() => openCalculator('pricing')} className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"><Calculator className="h-3.5 w-3.5" />{t('priceOption')}</button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <MetricCard label={t('openContracts')} value="20" footnote={t('samplePositions')} />
        <MetricCard label={t('netDelta')} value="+68.4" footnote={t('underlyingEquivalent')} />
        <MetricCard label={t('annualTheta')} value="−$1,744" footnote={t('annualizedDecay')} accent="gold" />
        <MetricCard label={t('aggregateVega')} value="+$567" footnote={t('vegaScenario')} accent="blue" />
      </div>

      <SectionCard title={t('holdingsTitle')} eyebrow={t('greeksMonitor')} action={<StatusChip tone="gold">{tCommon('illustrativeData')}</StatusChip>}>
        <div className="mb-4 flex items-center gap-2 rounded-xl bg-[#f7f9f8] px-3 py-2.5 text-[10px] leading-4 text-[#69766f]"><CircleHelp className="h-3.5 w-3.5 shrink-0 text-[#71847a]" /> {t('sampleRowsNotice')}</div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[830px] border-collapse text-left">
            <thead><tr className="border-b border-[#edf0ee] text-[9px] uppercase tracking-[0.12em] text-[#9aa49e]">
              <th className="pb-3 pr-4 font-semibold">{t('underlyingExpiry')}</th><th className="pb-3 pr-4 font-semibold">{t('contract')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('quantity')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('premium')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('delta')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('gamma')}</th><th className="pb-3 pr-4 text-right font-semibold">{t('thetaYear')}</th><th className="pb-3 text-right font-semibold">{t('vega')}</th>
            </tr></thead>
            <tbody>{demoPositions.map((position) => (
              <tr key={`${position.symbol}-${position.type}`} className="border-b border-[#f0f2f0] last:border-0">
                <td className="py-3.5 pr-4"><div className="font-semibold text-[#23382d]">{position.symbol}</div><div className="mt-1 text-[9px] text-[#939f97]">{new Date(`${position.expiry}T00:00:00.000Z`).toLocaleDateString(locale === 'th' ? 'th-TH' : 'en-US', { day: '2-digit', month: 'short', year: 'numeric' })}</div></td>
                <td className="py-3.5 pr-4"><span className={`mr-2 rounded-md px-1.5 py-1 text-[8px] font-bold ${position.tone === 'green' ? 'bg-[#edf4f0] text-[#256143]' : 'bg-[#f8f3e8] text-[#92773a]'}`}>{t(position.type === 'CALL' ? 'call' : 'put')}</span><span className="text-xs font-semibold text-[#31443a]">{position.strike}</span></td>
                <td className="py-3.5 pr-4 text-right text-xs font-medium text-[#425249]">{position.quantity}</td>
                <td className="py-3.5 pr-4 text-right text-xs font-medium text-[#425249]">${position.premium}</td>
                <td className={`py-3.5 pr-4 text-right text-xs font-semibold ${position.delta.startsWith('-') ? 'text-[#a75a50]' : 'text-[#347454]'}`}>{position.delta}</td>
                <td className="py-3.5 pr-4 text-right text-xs text-[#53635a]">{position.gamma}</td>
                <td className="py-3.5 pr-4 text-right text-xs text-[#a75a50]">{position.theta}</td>
                <td className="py-3.5 text-right text-xs text-[#53635a]">{position.vega}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        <div className="mt-4 flex items-center gap-1.5 text-[9px] text-[#9aa49e]"><CircleHelp className="h-3 w-3" /> {t('unitsNotice')}</div>
      </SectionCard>

      <div className="grid gap-5 xl:grid-cols-[1.65fr_0.9fr]">
        <SectionCard title={t('payoffTitle')} eyebrow={t('payoffEyebrow')} action={<StatusChip tone="blue">{t('premiumTag')}</StatusChip>}>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-[10px] text-[#7d8982]">
            <span>{t('netPayoff')}</span>
            <span className="inline-flex items-center gap-1.5 text-[#4a745c]"><span className="h-2 w-2 rounded-full bg-[#3b7756]" />{t('longCall')}</span>
          </div>
          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={payoffCurve} margin={{ top: 12, right: 12, bottom: 2, left: 2 }}>
                <CartesianGrid stroke="#edf1ee" vertical={false} />
                <XAxis dataKey="underlying" type="number" domain={[170, 280]} tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 10 }} tickFormatter={(value: number) => `$${value}`} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: '#8b9790', fontSize: 10 }} tickFormatter={(value: number) => value < 0 ? `−$${Math.abs(value) / 1000}k` : `$${value / 1000}k`} width={45} />
                <Tooltip formatter={(value) => [formatCurrency(String(value), 'USD', 0), t('tooltipNetPayoff')]} labelFormatter={(label) => t('tooltipUnderlyingAtExpiry', { value: `$${label}` })} contentStyle={{ borderRadius: 12, borderColor: '#e2e9e4', fontSize: 11 }} />
                <ReferenceLine y={0} stroke="#9da9a2" strokeDasharray="3 4" />
                <ReferenceLine x={Number(breakeven)} stroke="#b89958" strokeDasharray="4 4" label={{ value: t('breakEven'), position: 'insideTopRight', fill: '#917d4e', fontSize: 9 }} />
                <Line type="monotone" dataKey="payoff" stroke="#2e6848" strokeWidth={2.5} dot={false} activeDot={{ r: 4, fill: '#14342a' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2 border-t border-[#edf0ee] pt-4 text-[10px]">
            <span className="text-[#7d8982]">{t('breakEven')} <strong className="ml-1 text-[#273a30]">${breakeven}</strong></span>
            <span className="text-[#7d8982]">{t('maxLoss')} <strong className="ml-1 text-[#a75a50]">−$1,340</strong></span>
            <span className="text-[#7d8982]">{t('spotPrice')} <strong className="ml-1 text-[#347454]">{formatCurrency(payoffAtCurrent, 'USD')}</strong></span>
          </div>
        </SectionCard>

        <SectionCard title={t('assumptionsTitle')} eyebrow={t('referenceSnapshot')}>
          <div className="space-y-3.5">
            {[
              [t('pricingModel'), t('europeanBlackScholes')],
              [t('underlyingPrice'), '$238.00'],
              [t('strikeMaturity'), t('strikeMaturityValue', { strike: '$220', years: '0.48' })],
              [t('riskFreeRate'), t('annualizedValue', { value: '4.00%' })],
              [t('volatility'), t('annualizedValue', { value: '31.00%' })],
              [t('callMoneyness'), t('inTheMoney')],
            ].map(([label, value]) => <div key={label} className="flex items-center justify-between gap-3 border-b border-[#f0f2f0] pb-3 last:border-0 last:pb-0"><span className="text-[10px] text-[#87928b]">{label}</span><span className="text-right text-[10px] font-semibold text-[#34483d]">{value}</span></div>)}
          </div>
          <button type="button" onClick={() => openCalculator('pricing')} className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-[#dfe6e1] bg-[#f9fbfa] px-3 py-2.5 text-[10px] font-semibold text-[#3b5045] transition hover:border-[#14342a] hover:bg-white"><Calculator className="h-3.5 w-3.5" />{t('customScenario')}</button>
          <p className="mt-3 text-[9px] leading-4 text-[#9aa49e]">{t('modelCaveat')}</p>
        </SectionCard>
      </div>

      {dialogOpen && <Dialog title={mode === 'pricing' ? t('pricingDialogTitle') : t('ivDialogTitle')} description={t('dialogDescription')} onClose={() => setDialogOpen(false)}>
        <form onSubmit={calculate} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Field label={t('underlyingPrice')} value={inputs.underlyingPrice} onChange={(value) => updateInput('underlyingPrice', value)} suffix="USD" />
            <Field label={t('strikePrice')} value={inputs.strikePrice} onChange={(value) => updateInput('strikePrice', value)} suffix="USD" />
            <Field label={t('timeToExpiry')} value={inputs.timeToExpiry} onChange={(value) => updateInput('timeToExpiry', value)} suffix={t('unitYears')} step="0.001" />
            <Field label={t('riskFreeRate')} value={inputs.riskFreeRate} onChange={(value) => updateInput('riskFreeRate', value)} suffix={t('unitDecimal')} step="0.001" />
            {mode === 'pricing' ? <Field label={t('volatility')} value={inputs.volatility} onChange={(value) => updateInput('volatility', value)} suffix={t('unitDecimal')} step="0.001" /> : <Field label={t('observedMarketPrice')} value={inputs.marketPrice} onChange={(value) => updateInput('marketPrice', value)} suffix="USD" />}
            <label className="block"><span className="mb-1.5 block text-[10px] font-semibold text-[#66736b]">{t('optionType')}</span><select value={optionType} onChange={(event) => setOptionType(event.target.value as 'CALL' | 'PUT')} className="h-10 w-full rounded-xl border border-[#dfe6e1] bg-[#fbfcfb] px-3 text-sm font-semibold text-[#20342a] outline-none focus:border-[#14342a]"><option value="CALL">{t('call')}</option><option value="PUT">{t('put')}</option></select></label>
          </div>
          {error && <p role="alert" className="rounded-xl border border-[#f0dcd8] bg-[#fcf1ef] px-3 py-2.5 text-[10px] leading-4 text-[#a24f43]">{error}</p>}
          {(result || impliedVolatility) && <div className="rounded-2xl border border-[#dfe9e2] bg-[#f4f8f5] p-4">
            {result && <><div className="flex items-end justify-between border-b border-[#e1eae4] pb-3"><span className="text-[10px] text-[#718078]">{t('theoreticalPrice')}</span><strong className="text-xl font-bold tracking-tight text-[#14342a]">{formatCurrency(result.theoreticalPrice, 'USD')}</strong></div><div className="mt-3 grid grid-cols-3 gap-3">{[[t('delta'), result.delta], [t('gamma'), result.gamma], [t('thetaYear'), result.theta], [t('vega'), result.vega], [t('rho'), result.rho]].map(([label, value]) => <div key={label}><p className="text-[9px] text-[#849088]">{label}</p><p className="mt-1 text-xs font-bold text-[#30463a]">{value}</p></div>)}</div></>}
            {impliedVolatility && <div className="flex items-center justify-between"><span className="text-[10px] text-[#718078]">{t('ivResult')}</span><strong className="text-xl font-bold tracking-tight text-[#14342a]">{formatRatioAsPercent(impliedVolatility)}</strong></div>}
          </div>}
          <div className="flex flex-col-reverse gap-2 pt-1 sm:flex-row sm:justify-end"><button type="button" onClick={() => setDialogOpen(false)} className="rounded-xl border border-[#dfe6e1] px-4 py-2.5 text-xs font-semibold text-[#53635a]">{tCommon('close')}</button><button disabled={loading} type="submit" className="rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-[#0f261e] disabled:cursor-wait disabled:opacity-60">{loading ? tCommon('calculating') : mode === 'pricing' ? t('calculatePriceGreeks') : t('solveIv')}</button></div>
        </form>
        <div className="mt-4 flex items-center justify-between border-t border-[#edf0ee] pt-3 text-[9px] text-[#9aa49e]"><span>{t('modelFooter')}</span><button type="button" onClick={() => setMode(mode === 'pricing' ? 'iv' : 'pricing')} className="font-semibold text-[#37694b]">{t(mode === 'pricing' ? 'switchToIv' : 'switchToPricing')}</button></div>
      </Dialog>}
    </div>
  );
}
