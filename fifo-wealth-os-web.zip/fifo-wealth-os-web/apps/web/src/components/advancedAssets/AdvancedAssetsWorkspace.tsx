'use client';

import React, { useState } from 'react';
import { useTranslations } from 'next-intl';
import { Activity, ArrowUpRight, BriefcaseBusiness, Building2, ChartNoAxesCombined, CircleAlert, Layers3 } from 'lucide-react';
import { FuturesRiskDashboard } from './FuturesRiskDashboard';
import { OptionsChain } from './OptionsChain';
import { OptionsDashboard } from './OptionsDashboard';
import { PEScreener } from './PEScreener';
import { PrivateEquityDashboard } from './PrivateEquityDashboard';
import { REITsComparison } from './REITsComparison';
import { REITsDashboard } from './REITsDashboard';

type AssetTab = 'options' | 'reits' | 'private-equity' | 'futures';
type AssetView = 'desk' | 'chain' | 'income' | 'comparison' | 'dashboard' | 'screener';

const tabs: Array<{ id: AssetTab; labelKey: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'options', labelKey: 'tabs.options', icon: ChartNoAxesCombined },
  { id: 'reits', labelKey: 'tabs.reits', icon: Building2 },
  { id: 'private-equity', labelKey: 'tabs.privateEquity', icon: BriefcaseBusiness },
  { id: 'futures', labelKey: 'tabs.futures', icon: Layers3 },
];

const defaultView: Record<AssetTab, AssetView> = {
  options: 'desk',
  reits: 'income',
  'private-equity': 'dashboard',
  futures: 'dashboard',
};

const subTabs: Partial<Record<AssetTab, Array<{ id: AssetView; labelKey: string }>>> = {
  options: [
    { id: 'desk', labelKey: 'subtabs.optionsDesk' },
    { id: 'chain', labelKey: 'subtabs.optionsChain' },
  ],
  reits: [
    { id: 'income', labelKey: 'subtabs.incomeMonitor' },
    { id: 'comparison', labelKey: 'subtabs.peerComparison' },
  ],
  'private-equity': [
    { id: 'dashboard', labelKey: 'subtabs.peDashboard' },
    { id: 'screener', labelKey: 'subtabs.fundScreener' },
  ],
};

export function AdvancedAssetsWorkspace() {
  const t = useTranslations('advancedAssets');
  const [activeTab, setActiveTab] = useState<AssetTab>('options');
  const [activeView, setActiveView] = useState<AssetView>('desk');
  const selectedTab = tabs.find((tab) => tab.id === activeTab);
  const visibleSubTabs = subTabs[activeTab];

  const selectTab = (tab: AssetTab) => {
    setActiveTab(tab);
    setActiveView(defaultView[tab]);
  };

  return (
    <main className="mx-auto w-full max-w-7xl px-4 pb-12 pt-7 sm:px-6 lg:px-8 lg:pt-9">
      <div className="mb-7 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div className="max-w-3xl">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[#d7e2dc] bg-[#eef4f0] px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-[#14342a]">
            <Activity className="h-3.5 w-3.5" />
            {t('page.eyebrow')}
            <span className="rounded-full bg-[#14342a] px-2 py-0.5 text-[9px] tracking-[0.12em] text-white">{t('page.beta')}</span>
          </div>
          <h1 className="font-sans text-3xl font-bold tracking-[-0.04em] text-[#18221d] sm:text-4xl">{t('page.title')}</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-[#65716b]">
            {t('page.description')}
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-2xl border border-[#e5e9e6] bg-white px-3.5 py-2.5 text-xs text-[#59645e] shadow-[0_8px_28px_rgba(20,52,42,0.04)]">
          <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-[#f2f5f3] text-[#14342a]"><ArrowUpRight className="h-4 w-4" /></span>
          <span><strong className="block font-semibold text-[#24362e]">{t('page.quantTools')}</strong><span className="text-[11px]">{t('page.precision')}</span></span>
        </div>
      </div>

      <div className="mb-3 flex gap-1 overflow-x-auto rounded-2xl border border-[#e7ebe8] bg-white p-1.5 shadow-[0_6px_24px_rgba(20,52,42,0.035)]" role="tablist" aria-label={t('page.categoriesAriaLabel')}>
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const selected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`advanced-tab-${tab.id}`}
              type="button"
              role="tab"
              aria-selected={selected}
              aria-controls="advanced-assets-panel"
              onClick={() => selectTab(tab.id)}
              className={`inline-flex min-w-max flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-xs font-semibold transition ${selected ? 'bg-[#14342a] text-white shadow-sm' : 'text-[#67736d] hover:bg-[#f4f6f5] hover:text-[#14342a]'}`}
            >
              <Icon className="h-4 w-4" />
              <span>{t(tab.labelKey)}</span>
            </button>
          );
        })}
      </div>

      {visibleSubTabs && (
        <div className="mb-5 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label={t('page.toolsAriaLabel', { category: t(selectedTab?.labelKey ?? 'tabs.options') })}>
          {visibleSubTabs.map((view) => (
            <button
              key={view.id}
              id={`advanced-subtab-${view.id}`}
              type="button"
              role="tab"
              aria-selected={activeView === view.id}
              aria-controls="advanced-assets-panel"
              onClick={() => setActiveView(view.id)}
              className={`min-w-max rounded-xl border px-3.5 py-2 text-[10px] font-semibold transition ${activeView === view.id ? 'border-[#b8cbbd] bg-[#edf4f0] text-[#14342a]' : 'border-transparent bg-white/60 text-[#718078] hover:border-[#e2e9e4] hover:bg-white'}`}
            >
              {t(view.labelKey)}
            </button>
          ))}
        </div>
      )}

      <div className="mb-5 flex items-start gap-3 rounded-2xl border border-[#e8e3d6] bg-[#fbf8f0] px-4 py-3.5 text-[11px] leading-5 text-[#74694f] sm:items-center">
        <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-[#9a7e3d] sm:mt-0" />
        <p><strong className="font-semibold text-[#605639]">{t('page.warningTitle')}</strong> {t('page.warning')}</p>
      </div>

      <section id="advanced-assets-panel" role="tabpanel" aria-labelledby={visibleSubTabs ? `advanced-subtab-${activeView}` : `advanced-tab-${activeTab}`} aria-label={t('page.panelAriaLabel', { category: t(selectedTab?.labelKey ?? 'tabs.options') })}>
        {activeTab === 'options' && activeView === 'desk' && <OptionsDashboard />}
        {activeTab === 'options' && activeView === 'chain' && <OptionsChain />}
        {activeTab === 'reits' && activeView === 'income' && <REITsDashboard />}
        {activeTab === 'reits' && activeView === 'comparison' && <REITsComparison />}
        {activeTab === 'private-equity' && activeView === 'dashboard' && <PrivateEquityDashboard />}
        {activeTab === 'private-equity' && activeView === 'screener' && <PEScreener />}
        {activeTab === 'futures' && <FuturesRiskDashboard />}
      </section>
      <p className="mt-8 flex items-center justify-center gap-2 text-[10px] tracking-wide text-[#9aa49e]"><Layers3 className="h-3 w-3" /> {t('page.footer')}</p>
    </main>
  );
}
