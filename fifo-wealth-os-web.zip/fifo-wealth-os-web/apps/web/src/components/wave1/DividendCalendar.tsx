'use client';

import React, { useEffect, useState } from 'react';
import {
  Banknote,
  Calendar as CalendarIcon,
  Clock,
  TrendingUp,
} from 'lucide-react';
import { useLocale, useTranslations } from 'next-intl';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import { DividendCalendarReport } from '@/types/wave1';

const FALLBACK_DIVIDEND_REPORT: DividendCalendarReport = {
  year: 2026,
  events: [],
  yearlyDividendTHB: '31245.50',
  averageMonthlyTHB: '2603.79',
  upcomingDividends: [
    {
      id: 'up-1',
      symbol: 'AAPL',
      exDate: '2026-11-08',
      payDate: '2026-11-14',
      amountPerShare: '0.2600',
      currency: 'USD',
      estimatedTHB: '46.15',
      isForecast: true,
    },
    {
      id: 'up-2',
      symbol: 'ADVANC',
      exDate: '2026-11-18',
      payDate: '2026-11-26',
      amountPerShare: '5.0000',
      currency: 'THB',
      estimatedTHB: '3000.00',
      isForecast: true,
    },
  ],
  monthlyIncome: [
    {
      month: 1,
      monthKey: 'Jan',
      monthNameTH: 'ม.ค.',
      actualTHB: '0.00',
      forecastTHB: '2896.80',
      totalTHB: '2896.80',
      eventCount: 1,
      events: [
        {
          symbol: 'SCHD',
          exDate: '2026-01-12',
          payDate: '2026-01-22',
          amountPerShare: '0.6800',
          currency: 'USD',
          estimatedTHB: '2896.80',
          isForecast: true,
        },
      ],
    },
    {
      month: 2,
      monthKey: 'Feb',
      monthNameTH: 'ก.พ.',
      actualTHB: '0.00',
      forecastTHB: '2804.38',
      totalTHB: '2804.38',
      eventCount: 2,
      events: [
        {
          symbol: 'ADVANC',
          exDate: '2026-02-20',
          payDate: '2026-02-27',
          amountPerShare: '4.6000',
          currency: 'THB',
          estimatedTHB: '2760.00',
          isForecast: true,
        },
      ],
    },
    {
      month: 3,
      monthKey: 'Mar',
      monthNameTH: 'มี.ค.',
      actualTHB: '0.00',
      forecastTHB: '2635.88',
      totalTHB: '2635.88',
      eventCount: 1,
      events: [
        {
          symbol: 'VOO',
          exDate: '2026-03-20',
          payDate: '2026-03-28',
          amountPerShare: '1.6500',
          currency: 'USD',
          estimatedTHB: '2635.88',
          isForecast: true,
        },
      ],
    },
    {
      month: 4,
      monthKey: 'Apr',
      monthNameTH: 'เม.ย.',
      actualTHB: '0.00',
      forecastTHB: '4200.00',
      totalTHB: '4200.00',
      eventCount: 1,
      events: [
        {
          symbol: 'PTT',
          exDate: '2026-04-10',
          payDate: '2026-04-28',
          amountPerShare: '1.2000',
          currency: 'THB',
          estimatedTHB: '4200.00',
          isForecast: true,
        },
      ],
    },
    {
      month: 5,
      monthKey: 'May',
      monthNameTH: 'พ.ค.',
      actualTHB: '0.00',
      forecastTHB: '3294.38',
      totalTHB: '3294.38',
      eventCount: 2,
      events: [
        {
          symbol: 'SCB',
          exDate: '2026-05-05',
          payDate: '2026-05-22',
          amountPerShare: '6.5000',
          currency: 'THB',
          estimatedTHB: '3250.00',
          isForecast: true,
        },
      ],
    },
    {
      month: 6,
      monthKey: 'Jun',
      monthNameTH: 'มิ.ย.',
      actualTHB: '0.00',
      forecastTHB: '2772.55',
      totalTHB: '2772.55',
      eventCount: 2,
      events: [
        {
          symbol: 'VOO',
          exDate: '2026-06-22',
          payDate: '2026-06-30',
          amountPerShare: '1.7200',
          currency: 'USD',
          estimatedTHB: '2747.70',
          isForecast: true,
        },
      ],
    },
    {
      month: 7,
      monthKey: 'Jul',
      monthNameTH: 'ก.ค.',
      actualTHB: '0.00',
      forecastTHB: '3152.40',
      totalTHB: '3152.40',
      eventCount: 1,
      events: [
        {
          symbol: 'SCHD',
          exDate: '2026-07-10',
          payDate: '2026-07-24',
          amountPerShare: '0.7400',
          currency: 'USD',
          estimatedTHB: '3152.40',
          isForecast: true,
        },
      ],
    },
    {
      month: 8,
      monthKey: 'Aug',
      monthNameTH: 'ส.ค.',
      actualTHB: '0.00',
      forecastTHB: '44.38',
      totalTHB: '44.38',
      eventCount: 1,
      events: [],
    },
    {
      month: 9,
      monthKey: 'Sep',
      monthNameTH: 'ก.ย.',
      actualTHB: '0.00',
      forecastTHB: '2910.00',
      totalTHB: '2910.00',
      eventCount: 1,
      events: [
        {
          symbol: 'ADVANC',
          exDate: '2026-08-19',
          payDate: '2026-09-04',
          amountPerShare: '4.8500',
          currency: 'THB',
          estimatedTHB: '2910.00',
          isForecast: true,
        },
      ],
    },
    {
      month: 10,
      monthKey: 'Oct',
      monthNameTH: 'ต.ค.',
      actualTHB: '0.00',
      forecastTHB: '2800.00',
      totalTHB: '2800.00',
      eventCount: 1,
      events: [
        {
          symbol: 'PTT',
          exDate: '2026-09-25',
          payDate: '2026-10-16',
          amountPerShare: '0.8000',
          currency: 'THB',
          estimatedTHB: '2800.00',
          isForecast: true,
        },
      ],
    },
    {
      month: 11,
      monthKey: 'Nov',
      monthNameTH: 'พ.ย.',
      actualTHB: '0.00',
      forecastTHB: '3046.15',
      totalTHB: '3046.15',
      eventCount: 2,
      events: [
        {
          symbol: 'ADVANC',
          exDate: '2026-11-18',
          payDate: '2026-11-26',
          amountPerShare: '5.0000',
          currency: 'THB',
          estimatedTHB: '3000.00',
          isForecast: true,
        },
      ],
    },
    {
      month: 12,
      monthKey: 'Dec',
      monthNameTH: 'ธ.ค.',
      actualTHB: '0.00',
      forecastTHB: '2955.38',
      totalTHB: '2955.38',
      eventCount: 1,
      events: [
        {
          symbol: 'VOO',
          exDate: '2026-12-18',
          payDate: '2026-12-26',
          amountPerShare: '1.8500',
          currency: 'USD',
          estimatedTHB: '2955.38',
          isForecast: true,
        },
      ],
    },
  ],
};

function formatTHB(value: string | number): string {
  const num = typeof value === 'string' ? Number(value) : value;
  if (Number.isNaN(num)) return '฿0.00';
  return `฿${num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

interface DividendCalendarProps {
  portfolioId?: string | null;
  year?: number;
}

export function DividendCalendar({
  portfolioId,
  year = 2026,
}: DividendCalendarProps) {
  const t = useTranslations('wave1');
  const locale = useLocale();
  const token = useAuthStore((s) => s.token);

  const [report, setReport] = useState<DividendCalendarReport>(
    FALLBACK_DIVIDEND_REPORT
  );
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    let active = true;
    async function loadCalendar() {
      setLoading(true);
      try {
        if (!token) {
          if (active) setReport(FALLBACK_DIVIDEND_REPORT);
          return;
        }
        const params: Record<string, string | number> = { year };
        if (portfolioId && !portfolioId.startsWith('mock-')) {
          params.portfolioId = portfolioId;
        }
        const res = await api.get<DividendCalendarReport>(
          '/dividend-calendar',
          { params }
        );
        if (active) setReport(res.data);
      } catch {
        if (active) setReport(FALLBACK_DIVIDEND_REPORT);
      } finally {
        if (active) setLoading(false);
      }
    }
    loadCalendar();
    return () => {
      active = false;
    };
  }, [token, portfolioId, year]);

  const chartData = report.monthlyIncome.map((m) => ({
    label: locale === 'th' ? m.monthNameTH : m.monthKey,
    total: Number(m.totalTHB),
    actual: Number(m.actualTHB),
    forecast: Number(m.forecastTHB),
  }));

  const upcomingSum = report.upcomingDividends.reduce(
    (acc, ev) => acc + Number(ev.estimatedTHB || 0),
    0
  );

  return (
    <section
      data-testid="dividend-calendar-section"
      className="space-y-6 pb-safe"
    >
      {/* Top 3 KPI Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
              {t('divYearlyLabel')}
            </span>
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#14342a]/10 text-[#14342a] dark:bg-[#4ade80]/15 dark:text-[#4ade80]">
              <Banknote className="h-4 w-4" />
            </span>
          </div>
          <p
            data-testid="yearly-dividend-total"
            className="mt-2 text-2xl font-extrabold tracking-tight text-[#14342a] dark:text-[#4ade80] tabular-nums"
          >
            {formatTHB(report.yearlyDividendTHB)}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
              {t('divMonthlyAvgLabel')}
            </span>
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-50 text-[#059669] dark:bg-emerald-950/50 dark:text-emerald-300">
              <TrendingUp className="h-4 w-4" />
            </span>
          </div>
          <p
            data-testid="monthly-average-dividend"
            className="mt-2 text-2xl font-extrabold tracking-tight text-[#059669] tabular-nums"
          >
            {formatTHB(report.averageMonthlyTHB)}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
              {t('divUpcomingLabel')}
            </span>
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300">
              <Clock className="h-4 w-4" />
            </span>
          </div>
          <p className="mt-2 text-2xl font-extrabold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5] tabular-nums">
            {formatTHB(upcomingSum)}
            <span className="ml-2 text-xs font-medium text-gray-400">
              ({t('payoutsCount', { count: report.upcomingDividends.length })})
            </span>
          </p>
        </div>
      </div>

      {/* Monthly Passive Income Bar Chart */}
      <div className="rounded-2xl border border-gray-200/80 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
              {t('divChartTitle')}
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {t('divSubtitle')}
            </p>
          </div>
        </div>

        <div
          data-testid="dividend-monthly-barchart"
          className="h-64 w-full"
        >
          {loading ? (
            <div className="h-full w-full animate-pulse rounded-xl bg-gray-100 dark:bg-gray-800" />
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 10, right: 12, left: 0, bottom: 4 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#E5E7EB"
                />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11, fill: '#6B7280' }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#6B7280' }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(val) =>
                    `฿${Number(val).toLocaleString('en-US')}`
                  }
                />
                <Tooltip
                  formatter={(val: unknown) => [
                    formatTHB(Number(val ?? 0)),
                    'Passive Income',
                  ]}
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid #E5E7EB',
                    fontSize: '12px',
                  }}
                />
                <Bar
                  dataKey="total"
                  fill="#059669"
                  radius={[8, 8, 0, 0]}
                  isAnimationActive={false}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* 12-Month Calendar Grid (Jan - Dec) */}
      <div className="rounded-2xl border border-gray-200/80 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <div className="mb-4 flex items-center gap-2">
          <CalendarIcon className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
          <h3 className="text-base font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
            {t('divCalendarGridTitle', { year: report.year })}
          </h3>
        </div>

        <div
          data-testid="dividend-12month-grid"
          className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
        >
          {report.monthlyIncome.map((bucket) => {
            const hasPayout = Number(bucket.totalTHB) > 0;
            return (
              <div
                key={bucket.month}
                data-testid={`dividend-month-${bucket.month}`}
                className="flex flex-col justify-between rounded-2xl border border-gray-100 bg-gray-50/70 p-4 transition hover:border-[#14342a]/30 dark:border-gray-800 dark:bg-[#121212]"
              >
                <div>
                  <div className="flex items-center justify-between border-b border-gray-200/60 pb-2.5 dark:border-gray-800">
                    <span className="text-xs font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                      {locale === 'th' ? bucket.monthNameTH : bucket.monthKey}{' '}
                      {report.year}
                    </span>
                    <span
                      className={`text-xs font-extrabold tabular-nums ${
                        hasPayout
                          ? 'text-[#059669]'
                          : 'text-gray-400 dark:text-gray-500'
                      }`}
                    >
                      {formatTHB(bucket.totalTHB)}
                    </span>
                  </div>

                  <div className="mt-3 space-y-2">
                    {bucket.events.length === 0 ? (
                      <p className="py-2 text-[11px] text-gray-400">
                        {t('noDividendsMonth')}
                      </p>
                    ) : (
                      bucket.events.map((ev, idx) => (
                        <div
                          key={`${ev.symbol}-${ev.payDate}-${idx}`}
                          className="flex items-center justify-between rounded-xl bg-white px-2.5 py-2 text-xs shadow-2xs dark:bg-[#1E1E1E]"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-[#14342a] dark:text-[#4ade80]">
                                {ev.symbol}
                              </span>
                              <span
                                className={`rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${
                                  ev.isForecast
                                    ? 'bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-300'
                                    : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'
                                }`}
                              >
                                {ev.isForecast
                                  ? t('badgeForecast')
                                  : t('badgeActual')}
                              </span>
                            </div>
                            <p className="text-[10px] text-gray-400 tabular-nums">
                              {t('payDateLabel')} {ev.payDate}
                            </p>
                          </div>
                          <span className="font-bold text-[#1A1A1A] dark:text-[#F5F5F5] tabular-nums">
                            {formatTHB(ev.estimatedTHB)}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default DividendCalendar;
