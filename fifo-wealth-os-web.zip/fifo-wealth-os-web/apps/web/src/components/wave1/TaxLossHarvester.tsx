'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import {
  AlertTriangle,
  Calculator,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
  TrendingDown,
  X,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import { cn } from '@/lib/utils';
import {
  HarvestingSimulationResult,
  TaxLossHarvestingOpportunity,
} from '@/types/wave1';

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

const FALLBACK_OPPORTUNITIES: TaxLossHarvestingOpportunity[] = [
  {
    lotId: 'demo-eth-lot',
    symbol: 'ETH',
    qtyRemain: '1',
    avgCost: '82205.00',
    currentPrice: '71200.00',
    unrealizedLoss: '11005.00',
    daysHeld: 753,
    taxSavingPotential: '2201.00',
    marginalTaxRate: '0.20',
    washSaleRisk: false,
    status: 'AVAILABLE',
    washSaleNote: null,
  },
  {
    lotId: 'demo-aapl-lot',
    symbol: 'AAPL',
    qtyRemain: '5',
    avgCost: '5525.18',
    currentPrice: '4820.00',
    unrealizedLoss: '3525.90',
    daysHeld: 755,
    taxSavingPotential: '705.18',
    marginalTaxRate: '0.20',
    washSaleRisk: false,
    status: 'AVAILABLE',
    washSaleNote:
      'US Equity: หลังขายทำ Tax-Loss Harvesting ห้ามซื้อหุ้นเดิมกลับภายใน 30 วัน (Wash Sale Rule)',
  },
];

function formatTHB(value: string | number | undefined): string {
  if (value === undefined) return '฿0.00';
  try {
    const decimalValue = new Dec(String(value));
    if (!decimalValue.isFinite()) return '฿0.00';
    const fixed = decimalValue.toDecimalPlaces(2).toFixed(2);
    const [wholePart = '0', fraction = '00'] = fixed.split('.');
    return `฿${wholePart.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}.${fraction}`;
  } catch {
    return '฿0.00';
  }
}

interface TaxLossHarvesterProps {
  portfolioId?: string | null;
  refreshTrigger?: number;
  /** THB-denominated market quotes supplied by the Dashboard ticker. */
  currentPrices?: Record<string, string>;
}

export function TaxLossHarvester({
  portfolioId,
  refreshTrigger = 0,
  currentPrices,
}: TaxLossHarvesterProps) {
  const t = useTranslations('wave1');
  const token = useAuthStore((s) => s.token);

  const [marginalRate, setMarginalRate] = useState<string>('0.20');
  const [currentTaxLiability, setCurrentTaxLiability] =
    useState<string>('25000.00');
  const [opportunities, setOpportunities] = useState<
    TaxLossHarvestingOpportunity[]
  >([]);
  const [selectedSymbols, setSelectedSymbols] = useState<Set<string>>(
    new Set()
  );
  const [loading, setLoading] = useState<boolean>(true);
  const [simResult, setSimResult] =
    useState<HarvestingSimulationResult | null>(null);
  const [simulating, setSimulating] = useState<boolean>(false);

  useEffect(() => {
    let active = true;
    async function loadOpportunities() {
      setLoading(true);
      try {
        if (!token) {
          if (active) {
            setOpportunities(FALLBACK_OPPORTUNITIES);
            setSelectedSymbols(
              new Set(FALLBACK_OPPORTUNITIES.map((o) => o.symbol))
            );
          }
          return;
        }

        const params: Record<string, string> = {
          marginalTaxRate: marginalRate,
        };
        if (portfolioId && !portfolioId.startsWith('mock-')) {
          params.portfolioId = portfolioId;
        }

        const res = await api.get<{
          opportunities: TaxLossHarvestingOpportunity[];
        }>('/tax-loss-harvesting/opportunities', { params });

        const list =
          res.data.opportunities.length > 0
            ? res.data.opportunities
            : FALLBACK_OPPORTUNITIES;

        if (active) {
          setOpportunities(list);
          setSelectedSymbols(new Set(list.map((o) => o.symbol)));
        }
      } catch {
        if (active) {
          setOpportunities(FALLBACK_OPPORTUNITIES);
          setSelectedSymbols(
            new Set(FALLBACK_OPPORTUNITIES.map((o) => o.symbol))
          );
        }
      } finally {
        if (active) setLoading(false);
      }
    }
    loadOpportunities();
    return () => {
      active = false;
    };
  }, [token, portfolioId, marginalRate, refreshTrigger]);

  const displayOpportunities = useMemo(
    () =>
      opportunities.map((opportunity) => {
        const livePrice = currentPrices?.[opportunity.symbol];
        if (livePrice === undefined) return opportunity;

        const quantity = new Dec(opportunity.qtyRemain || '1');
        const averageCost = new Dec(opportunity.avgCost || '0');
        const marketPrice = new Dec(livePrice);
        const perUnitLoss = averageCost.gt(marketPrice)
          ? averageCost.minus(marketPrice)
          : new Dec(0);
        const unrealizedLoss = perUnitLoss
          .times(quantity)
          .toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
        const taxSaving = unrealizedLoss
          .times(new Dec(marginalRate))
          .toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

        return {
          ...opportunity,
          currentPrice: marketPrice.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
          unrealizedLoss: unrealizedLoss.toFixed(2),
          taxSavingPotential: taxSaving.toFixed(2),
          marginalTaxRate: marginalRate,
        };
      }),
    [opportunities, currentPrices, marginalRate]
  );

  const selectedOpportunities = useMemo(
    () => displayOpportunities.filter((o) => selectedSymbols.has(o.symbol)),
    [displayOpportunities, selectedSymbols]
  );

  const totalPotentialSaving = useMemo(
    () =>
      selectedOpportunities
        .filter((o) => o.status !== 'WASH_SALE_RISK')
        .reduce((acc, o) => acc.plus(new Dec(o.taxSavingPotential || '0')), new Dec(0))
        .toFixed(2),
    [selectedOpportunities]
  );

  const toggleSymbol = (symbol: string) => {
    setSelectedSymbols((prev) => {
      const next = new Set(prev);
      if (next.has(symbol)) {
        next.delete(symbol);
      } else {
        next.add(symbol);
      }
      return next;
    });
  };

  const handleSimulate = async () => {
    setSimulating(true);
    try {
      if (token) {
        const res = await api.post<
          HarvestingSimulationResult & {
            simulation?: HarvestingSimulationResult;
          }
        >('/tax-loss-harvesting/simulate', {
          opportunities: selectedOpportunities,
          currentTaxLiability: currentTaxLiability || '25000.00',
        });
        setSimResult(res.data.simulation ?? res.data);
      } else {
        const available = selectedOpportunities.filter(
          (o) => o.status === 'AVAILABLE'
        );
        const risky = selectedOpportunities.filter(
          (o) => o.status === 'WASH_SALE_RISK'
        );
        const sumLoss = available.reduce(
          (acc, opportunity) => acc.plus(new Dec(opportunity.unrealizedLoss || '0')),
          new Dec(0)
        );
        const sumSave = available.reduce(
          (acc, opportunity) => acc.plus(new Dec(opportunity.taxSavingPotential || '0')),
          new Dec(0)
        );
        const initLiab = new Dec(currentTaxLiability || '25000');
        const newLiability = initLiab.minus(sumSave).gt(0)
          ? initLiab.minus(sumSave)
          : new Dec(0);
        setSimResult({
          totalHarvestedLoss: sumLoss.toFixed(2),
          totalTaxSaving: sumSave.toFixed(2),
          currentTaxLiability: initLiab.toFixed(2),
          newTaxLiability: newLiability.toFixed(2),
          harvestedLots: available.map((o) => o.lotId),
          washSaleWarnings: risky.map(
            (o) => `${o.symbol}: ถือครองไม่ถึง 30 วัน เสี่ยง Wash Sale Rule`
          ),
          selectedCount: selectedOpportunities.length,
        });
      }
    } finally {
      setSimulating(false);
    }
  };

  return (
    <section
      data-testid="tax-loss-harvester-card"
      className="rounded-2xl border border-gray-200/80 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      {/* Header & Controls */}
      <div className="flex flex-col justify-between gap-4 border-b border-gray-100 pb-5 dark:border-gray-800 lg:flex-row lg:items-center">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-[#FEE2E2] text-[#DC2626]">
              <TrendingDown className="h-4 w-4" />
            </span>
            <h2 className="text-lg font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
              {t('tlhTitle')}
            </h2>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {t('tlhSubtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-gray-500 dark:text-gray-400">
              {t('tlhTaxRateLabel')}
            </label>
            <select
              aria-label={t('tlhTaxRateLabel')}
              value={marginalRate}
              onChange={(e) => setMarginalRate(e.target.value)}
              className="mt-1 rounded-xl border border-gray-200 bg-gray-50 px-3 py-2 text-xs font-semibold text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5] tabular-nums"
            >
              <option value="0.15">15%</option>
              <option value="0.20">20%</option>
              <option value="0.25">25%</option>
              <option value="0.30">30%</option>
              <option value="0.35">35%</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-gray-500 dark:text-gray-400">
              {t('tlhCurrentTaxLabel')}
            </label>
            <input
              type="number"
              min="0"
              step="1000"
              value={currentTaxLiability}
              onChange={(e) => setCurrentTaxLiability(e.target.value)}
              className="mt-1 w-36 rounded-xl border border-gray-200 bg-gray-50 px-3 py-2 text-xs font-semibold text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5] tabular-nums"
            />
          </div>

          <button
            type="button"
            disabled={selectedOpportunities.length === 0 || simulating}
            data-testid="simulate-harvesting-btn"
            onClick={handleSimulate}
            className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-50"
          >
            <Calculator className="h-4 w-4" />
            <span>{t('tlhSimulateBtn')}</span>
            <span
              data-testid="tlh-total-potential-saving"
              className="rounded-md bg-white/15 px-1.5 py-0.5 text-[11px] font-bold tabular-nums"
            >
              {formatTHB(totalPotentialSaving)}
            </span>
          </button>
        </div>
      </div>

      {/* Losing Positions Table */}
      <div className="mt-5 overflow-x-auto">
        {loading ? (
          <div className="space-y-2 py-6">
            <div className="h-10 animate-pulse rounded-xl bg-gray-100 dark:bg-gray-800" />
            <div className="h-10 animate-pulse rounded-xl bg-gray-100 dark:bg-gray-800" />
          </div>
        ) : (
          <table
            data-testid="tax-loss-opportunities-table"
            className="w-full min-w-[680px] border-collapse text-left text-sm"
          >
            <thead>
              <tr className="border-b border-gray-100 text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:border-gray-800">
                <th className="py-3 pr-3">{t('colSelect')}</th>
                <th className="py-3 pr-4">{t('colSymbol')}</th>
                <th className="py-3 pr-4 text-right">{t('colAvgCost')}</th>
                <th className="py-3 pr-4 text-right">{t('colCurrentPrice')}</th>
                <th className="py-3 pr-4 text-right">
                  {t('colUnrealizedLoss')}
                </th>
                <th className="py-3 pr-4 text-right">{t('colDaysHeld')}</th>
                <th className="py-3 text-right">{t('colTaxSaving')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {displayOpportunities.map((opp) => {
                const checked = selectedSymbols.has(opp.symbol);
                const currentLoss = new Dec(opp.unrealizedLoss || '0');
                const isCurrentlyLosing = currentLoss.gt(0);
                return (
                  <tr
                    key={opp.symbol}
                    data-testid={`tlh-row-${opp.symbol}`}
                    className="transition hover:bg-gray-50/70 dark:hover:bg-white/5"
                  >
                    <td className="py-4 pr-3">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleSymbol(opp.symbol)}
                        aria-label={t('selectOpportunity', { symbol: opp.symbol })}
                        className="h-4 w-4 rounded border-gray-300 accent-[#14342a]"
                      />
                    </td>
                    <td className="py-4 pr-4">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#14342a]/10 text-xs font-extrabold text-[#14342a] dark:bg-[#4ade80]/15 dark:text-[#4ade80]">
                          {opp.symbol.slice(0, 4)}
                        </div>
                        <div>
                          <p className="font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                            {opp.symbol}
                            {opp.qtyRemain && (
                              <span className="ml-1.5 text-xs font-normal text-gray-400 tabular-nums">
                                ({opp.qtyRemain} {t('unitsLabel')})
                              </span>
                            )}
                          </p>
                          {opp.washSaleRisk ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-600 dark:text-amber-400">
                              <AlertTriangle className="h-3 w-3" />
                              {t('washSaleWarn')}
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] text-gray-400">
                              <ShieldCheck className="h-3 w-3 text-[#059669]" />
                              {t('washSaleSafe')}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-4 pr-4 text-right font-medium text-gray-700 dark:text-gray-300 tabular-nums">
                      {formatTHB(opp.avgCost)}
                    </td>
                    <td
                      data-testid={`tlh-price-${opp.symbol}`}
                      className="py-4 pr-4 text-right font-medium text-gray-700 dark:text-gray-300 tabular-nums"
                    >
                      {formatTHB(opp.currentPrice)}
                    </td>
                    <td
                      data-testid={`tlh-loss-${opp.symbol}`}
                      className="py-4 pr-4 text-right tabular-nums"
                    >
                      <span
                        className={cn(
                          'inline-flex items-center rounded-lg px-2.5 py-1 text-xs font-bold',
                          isCurrentlyLosing
                            ? 'bg-[#FEE2E2] text-[#DC2626]'
                            : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                        )}
                      >
                        {isCurrentlyLosing ? '-' : ''}{formatTHB(opp.unrealizedLoss)}
                      </span>
                    </td>
                    <td className="py-4 pr-4 text-right font-medium text-gray-600 dark:text-gray-400 tabular-nums">
                      {t('daysUnit', { days: opp.daysHeld })}
                    </td>
                    <td className="py-4 text-right tabular-nums">
                      <span
                        data-testid={`tlh-saving-${opp.symbol}`}
                        className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-bold text-[#059669] dark:bg-emerald-950/50 dark:text-emerald-300"
                      >
                        <Sparkles className="h-3 w-3" />+
                        {formatTHB(opp.taxSavingPotential)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Simulation Summary Modal */}
      {simResult && (
        <div
          role="dialog"
          aria-modal="true"
          data-testid="harvesting-simulation-modal"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-lg rounded-2xl border border-gray-200 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-300">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {t('precisionSimulationLabel')}
                </span>
                <h3 className="mt-2 text-lg font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                  {t('simModalTitle')}
                </h3>
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  {t('simModalSubtitle')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSimResult(null)}
                className="rounded-lg p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-2xl bg-[#FEE2E2]/70 p-4 dark:bg-red-950/30">
                <p className="text-[11px] font-semibold text-[#DC2626]">
                  {t('simTotalLoss')}
                </p>
                <p className="mt-1 text-xl font-extrabold text-[#DC2626] tabular-nums">
                  -{formatTHB(simResult.totalHarvestedLoss)}
                </p>
              </div>

              <div className="rounded-2xl bg-emerald-50 p-4 dark:bg-emerald-950/40">
                <p className="text-[11px] font-semibold text-[#059669]">
                  {t('simTotalSaving')}
                </p>
                <p
                  data-testid="modal-total-tax-saving"
                  className="mt-1 text-xl font-extrabold text-[#059669] tabular-nums"
                >
                  +{formatTHB(simResult.totalTaxSaving)}
                </p>
              </div>

              <div className="rounded-2xl border border-gray-100 bg-gray-50 p-4 dark:border-gray-800 dark:bg-[#121212]">
                <p className="text-[11px] font-semibold text-gray-500">
                  {t('simOldLiability')}
                </p>
                <p className="mt-1 text-base font-bold text-gray-700 dark:text-gray-300 tabular-nums">
                  {formatTHB(simResult.currentTaxLiability)}
                </p>
              </div>

              <div className="rounded-2xl border border-[#14342a]/20 bg-[#14342a]/5 p-4 dark:border-[#4ade80]/20 dark:bg-[#14342a]/30">
                <p className="text-[11px] font-semibold text-[#14342a] dark:text-[#4ade80]">
                  {t('simNewLiability')}
                </p>
                <p
                  data-testid="modal-new-tax-liability"
                  className="mt-1 text-base font-extrabold text-[#14342a] dark:text-[#4ade80] tabular-nums"
                >
                  {formatTHB(simResult.newTaxLiability)}
                </p>
              </div>
            </div>

            {simResult.washSaleWarnings &&
              simResult.washSaleWarnings.length > 0 && (
                <div className="mt-4 space-y-1 rounded-xl border border-red-200 bg-[#FEE2E2]/80 p-3 text-xs font-medium text-[#DC2626] dark:border-red-900/60 dark:bg-red-950/40 dark:text-rose-300">
                  {simResult.washSaleWarnings.map((warn, i) => (
                    <p key={i}>⚠ {warn}</p>
                  ))}
                </div>
              )}

            <div className="mt-4 rounded-xl border border-amber-200/70 bg-amber-50/70 p-3 text-xs leading-relaxed text-amber-900 dark:border-amber-800/50 dark:bg-amber-950/30 dark:text-amber-200">
              {t('simWashSaleReminder')}
            </div>

            <div className="mt-5 flex justify-end">
              <button
                type="button"
                data-testid="close-simulation-modal-btn"
                onClick={() => setSimResult(null)}
                className="rounded-xl bg-[#14342a] px-5 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-[#0f261e]"
              >
                {t('simCloseBtn')}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

export default TaxLossHarvester;
