'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import Decimal from 'decimal.js';
import {
  AlertCircle,
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  GitBranch,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import { Lot } from '@/types/shared';
import {
  ApplyCorporateActionResult,
  CorporateAction,
  LotBeforeAfterPreview,
  SplitAdjustmentPreview,
} from '@/types/wave1';

const UiDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

const FALLBACK_CORPORATE_ACTIONS: CorporateAction[] = [
  {
    id: 'ca-nvda-split-2026',
    symbol: 'NVDA',
    type: 'STOCK_SPLIT',
    ratio: 2,
    effectiveDate: '2026-10-15',
    adjustmentFactor: '0.5000',
    applied: false,
  },
  {
    id: 'ca-aapl-split-2026',
    symbol: 'AAPL',
    type: 'STOCK_SPLIT',
    ratio: 4,
    effectiveDate: '2026-10-20',
    adjustmentFactor: '0.2500',
    applied: false,
  },
];

function computeDaysHeld(lotDate: string, refDate = '2026-10-26'): number {
  const lotMs = Date.parse(`${lotDate.slice(0, 10)}T00:00:00.000Z`);
  const refMs = Date.parse(`${refDate.slice(0, 10)}T00:00:00.000Z`);
  if (Number.isNaN(lotMs) || Number.isNaN(refMs)) return 0;
  return Math.max(0, Math.floor((refMs - lotMs) / 86_400_000));
}

function buildClientFallbackPreview(
  action: CorporateAction,
  portfolioLots?: Lot[]
): SplitAdjustmentPreview {
  if (action.preview && action.preview.lotPreviews.length > 0) {
    return action.preview;
  }

  const ratioDec = new UiDecimal(action.ratio);
  const multiplier =
    action.type === 'REVERSE_SPLIT'
      ? ratioDec.gt(1)
        ? new UiDecimal(1).dividedBy(ratioDec)
        : ratioDec
      : ratioDec;

  const matchingLots = (portfolioLots ?? []).filter(
    (l) => l.symbol.toUpperCase() === action.symbol.toUpperCase()
  );

  // If demo/planning view has no matching lots loaded locally, generate illustrative lot preview
  const sourceLots: Lot[] =
    matchingLots.length > 0
      ? matchingLots
      : [
          {
            id: `sample-${action.symbol.toLowerCase()}-1`,
            symbol: action.symbol,
            date: '2026-09-15',
            buyQty: 100,
            qtySold: 0,
            qtyRemain: 100,
            costPerUnit: 1250,
            realizedGL: 0,
            unrealizedGL: 0,
            status: 'Hold',
          },
        ];

  let sumBefore = new UiDecimal(0);
  let sumAfter = new UiDecimal(0);
  let affectedLotCount = 0;

  const lotPreviews: LotBeforeAfterPreview[] = sourceLots.map((lot) => {
    const affected = lot.date.slice(0, 10) <= action.effectiveDate.slice(0, 10);
    if (affected) affectedLotCount += 1;

    const qtyBeforeDec = new UiDecimal(
      lot.qtyRemain > 0 ? lot.qtyRemain : lot.buyQty
    );
    const unitBeforeDec = new UiDecimal(lot.costPerUnit);
    const totalBeforeDec = qtyBeforeDec.times(unitBeforeDec);

    const qtyAfterDec = affected
      ? qtyBeforeDec.times(multiplier)
      : qtyBeforeDec;
    const unitAfterDec =
      affected && qtyAfterDec.gt(0)
        ? totalBeforeDec.dividedBy(qtyAfterDec)
        : unitBeforeDec;
    const totalAfterDec = qtyAfterDec.times(unitAfterDec);

    sumBefore = sumBefore.plus(totalBeforeDec);
    sumAfter = sumAfter.plus(totalAfterDec);

    const daysHeld = computeDaysHeld(lot.date);

    return {
      lotId: lot.id,
      symbol: lot.symbol,
      date: lot.date.slice(0, 10),
      daysHeldBefore: daysHeld,
      daysHeldAfter: daysHeld,
      qtyBefore: qtyBeforeDec.toDecimalPlaces(4).toString(),
      qtyAfter: qtyAfterDec.toDecimalPlaces(4).toString(),
      costPerUnitBefore: unitBeforeDec.toFixed(2),
      costPerUnitAfter: unitAfterDec.toFixed(2),
      totalCostBasisBefore: totalBeforeDec.toFixed(2),
      totalCostBasisAfter: totalAfterDec.toFixed(2),
      affected,
    };
  });

  return {
    actionId: action.id,
    symbol: action.symbol,
    type: action.type,
    ratio: action.ratio,
    effectiveDate: action.effectiveDate,
    affectedLotCount,
    totalCostBeforeTHB: sumBefore.toFixed(2),
    totalCostAfterTHB: sumAfter.toFixed(2),
    isCostBasisPreserved: sumBefore.toFixed(2) === sumAfter.toFixed(2),
    isDaysHeldPreserved: true,
    lotPreviews,
  };
}

function formatMoneyTHB(val: string | number): string {
  const num = Number(val);
  if (!Number.isFinite(num)) return '฿0.00';
  return `฿${num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

interface CorporateActionAlertProps {
  portfolioId?: string | null;
  portfolioLots?: Lot[];
  onlyUnapplied?: boolean;
  onAdjustmentApplied?: () => void;
}

export function CorporateActionAlert({
  portfolioId,
  portfolioLots,
  onlyUnapplied = false,
  onAdjustmentApplied,
}: CorporateActionAlertProps) {
  const t = useTranslations('wave1');
  const queryClient = useQueryClient();
  const token = useAuthStore((s) => s.token);

  const [actions, setActions] = useState<CorporateAction[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAction, setSelectedAction] = useState<CorporateAction | null>(
    null
  );
  const [submitting, setSubmitting] = useState(false);
  const [lastResult, setLastResult] =
    useState<ApplyCorporateActionResult | null>(null);

  const isMockPortfolio = Boolean(portfolioId && portfolioId.startsWith('mock-'));

  useEffect(() => {
    let active = true;
    async function fetchActions() {
      setLoading(true);
      try {
        if (!token || isMockPortfolio) {
          if (!active) return;
          if (portfolioLots && portfolioLots.length > 0) {
            const heldSet = new Set(
              portfolioLots.map((l) => l.symbol.toUpperCase())
            );
            const matched = FALLBACK_CORPORATE_ACTIONS.filter((ca) =>
              heldSet.has(ca.symbol.toUpperCase())
            );
            setActions(matched);
          } else {
            setActions(FALLBACK_CORPORATE_ACTIONS);
          }
          return;
        }

        const params: Record<string, string> = {
          symbol: 'ALL',
          dateRange: '2024-01-01,2026-12-31',
        };
        if (portfolioId) {
          params.portfolioId = portfolioId;
        }
        const res = await api.get<
          CorporateAction[] | { actions: CorporateAction[] }
        >('/corporate-actions', {
          params,
        });
        const list = Array.isArray(res.data) ? res.data : res.data.actions;
        if (active) {
          if (portfolioId) {
            setActions(list);
          } else {
            setActions(list.length > 0 ? list : FALLBACK_CORPORATE_ACTIONS);
          }
        }
      } catch {
        if (active && !portfolioId) {
          setActions(FALLBACK_CORPORATE_ACTIONS);
        }
      } finally {
        if (active) setLoading(false);
      }
    }
    fetchActions();
    return () => {
      active = false;
    };
  }, [token, portfolioId, isMockPortfolio, portfolioLots]);

  const activePreview = useMemo(() => {
    if (!selectedAction) return null;
    return buildClientFallbackPreview(selectedAction, portfolioLots);
  }, [selectedAction, portfolioLots]);

  const visibleActions = useMemo(() => {
    return onlyUnapplied ? actions.filter((a) => !a.applied) : actions;
  }, [actions, onlyUnapplied]);

  const handleConfirmApply = async () => {
    if (!selectedAction) return;
    setSubmitting(true);
    try {
      if (token && !isMockPortfolio) {
        const payload: { actionId: string; portfolioId?: string } = {
          actionId: selectedAction.id,
        };
        if (portfolioId) {
          payload.portfolioId = portfolioId;
        }
        const res = await api.post<ApplyCorporateActionResult>(
          '/corporate-actions/apply',
          payload
        );
        setLastResult(res.data);

        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ['portfolio'] }),
          queryClient.invalidateQueries({ queryKey: ['portfolios'] }),
          queryClient.invalidateQueries({ queryKey: ['transactions'] }),
          queryClient.invalidateQueries({ queryKey: ['dashboardAnalytics'] }),
        ]);
      } else if (activePreview) {
        setLastResult({
          action: { ...selectedAction, applied: true },
          preview: activePreview,
          beforeLots: [],
          adjustedLots: [],
          totalCostBeforeTHB: activePreview.totalCostBeforeTHB,
          totalCostAfterTHB: activePreview.totalCostAfterTHB,
        });
      }

      setActions((prev) =>
        prev.map((a) =>
          a.id === selectedAction.id ? { ...a, applied: true } : a
        )
      );
      setSelectedAction(null);
      onAdjustmentApplied?.();
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || (visibleActions.length === 0 && !lastResult)) {
    return null;
  }

  return (
    <section
      data-testid="corporate-action-alert-section"
      className="space-y-3"
    >
      {visibleActions.map((action) => {
        const isSplit = action.type === 'STOCK_SPLIT';
        return (
          <div
            key={action.id}
            data-testid={`corporate-action-card-${action.symbol}`}
            className="flex flex-col justify-between gap-4 rounded-2xl border border-amber-200/90 bg-gradient-to-r from-amber-50/90 via-white to-emerald-50/40 p-5 shadow-sm dark:border-amber-800/50 dark:from-amber-950/30 dark:via-[#1E1E1E] dark:to-emerald-950/20 sm:flex-row sm:items-center"
          >
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-900 dark:bg-amber-900/50 dark:text-amber-200">
                  <AlertCircle className="h-3.5 w-3.5" />
                  {t('caBannerBadge')}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-[#14342a] px-2.5 py-0.5 text-xs font-bold text-white">
                  <GitBranch className="h-3 w-3" />
                  {action.symbol} •{' '}
                  {isSplit
                    ? t('caSplitLabel', { ratio: action.ratio })
                    : t('caReverseLabel', { ratio: action.ratio })}
                </span>
                {action.source === 'IBKR_FLEX' && (
                  <span className="inline-flex items-center rounded-full border border-[#14342a]/20 bg-[#14342a]/5 px-2.5 py-0.5 text-[11px] font-bold text-[#14342a] dark:border-[#4ade80]/30 dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                    {t('sourceIbkrFlexXml')}
                  </span>
                )}
                <span className="text-xs font-medium text-gray-500 dark:text-gray-400 tabular-nums">
                  {t('caEffectiveDate', { date: action.effectiveDate })}
                </span>
              </div>

              <p className="text-sm font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                {action.title ??
                  action.description ??
                  `${action.symbol} Corporate Action (${action.ratio}:1)`}
              </p>

              <p className="flex items-center gap-1.5 text-xs text-gray-600 dark:text-gray-400">
                <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-[#059669]" />
                <span>{t('caInvariantHint')}</span>
              </p>
            </div>

            <div className="flex shrink-0 items-center gap-3">
              {action.applied ? (
                <span
                  data-testid={`corporate-action-applied-${action.symbol}`}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2 text-xs font-bold text-[#059669] dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-300"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  {t('caAppliedBadge')}
                </span>
              ) : (
                <button
                  type="button"
                  data-testid={`corporate-action-apply-btn-${action.symbol}`}
                  onClick={() => setSelectedAction(action)}
                  className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
                >
                  <span>{t('caApplyBtn')}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        );
      })}

      {lastResult && (
        <div
          data-testid="corporate-action-result-toast"
          className="flex items-center justify-between rounded-2xl border border-emerald-200 bg-emerald-50/80 px-4 py-3 text-xs text-emerald-900 dark:border-emerald-800/50 dark:bg-emerald-950/30 dark:text-emerald-200"
        >
          <span className="font-medium tabular-nums">
            ✓ {t('caResultToast', { symbol: lastResult.action.symbol, before: formatMoneyTHB(lastResult.totalCostBeforeTHB), after: formatMoneyTHB(lastResult.totalCostAfterTHB) })}
          </span>
          <button
            type="button"
            onClick={() => setLastResult(null)}
            className="text-emerald-700 hover:text-emerald-950 dark:text-emerald-300"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Before / After Adjustment Preview Modal */}
      {selectedAction && activePreview && (
        <div
          role="dialog"
          aria-modal="true"
          data-testid="corporate-action-confirm-modal"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-xs"
        >
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-gray-200 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold text-[#14342a] dark:bg-emerald-950/50 dark:text-[#4ade80]">
                    <GitBranch className="h-3.5 w-3.5" />
                    {selectedAction.symbol} •{' '}
                    {selectedAction.type === 'STOCK_SPLIT'
                      ? t('caSplitLabel', { ratio: selectedAction.ratio })
                      : t('caReverseLabel', { ratio: selectedAction.ratio })}
                  </span>
                  <span className="rounded-full bg-gray-100 px-2.5 py-1 text-[11px] font-semibold text-gray-600 dark:bg-gray-800 dark:text-gray-300 tabular-nums">
                    {t('caEffectiveDate', { date: selectedAction.effectiveDate })}
                  </span>
                </div>
                <h3 className="mt-2.5 text-lg font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                  {t('caPreviewTitle')}: {t('caModalTitle')}
                </h3>
                <p className="mt-1 text-xs leading-relaxed text-gray-500 dark:text-gray-400">
                  {t('caModalSubtitle')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedAction(null)}
                aria-label={t('close')}
                className="rounded-lg p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Accounting Invariants Summary Cards */}
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-emerald-200/70 bg-emerald-50/50 p-4 dark:border-emerald-800/50 dark:bg-emerald-950/20">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                    {t('caTotalCostLabel')}
                  </span>
                  <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-[#059669] dark:bg-emerald-900/60 dark:text-emerald-300">
                    {t('caUnchangedBadge')}
                  </span>
                </div>
                <p
                  data-testid="preview-total-cost-invariant"
                  className="mt-1.5 text-sm font-bold text-[#14342a] dark:text-[#4ade80] tabular-nums"
                >
                  {formatMoneyTHB(activePreview.totalCostBeforeTHB)} →{' '}
                  {formatMoneyTHB(activePreview.totalCostAfterTHB)}
                </p>
                <p className="mt-0.5 text-[11px] text-gray-500 dark:text-gray-400">
                  {t('caPrecisionHint')}
                </p>
              </div>

              <div className="rounded-2xl border border-gray-200 bg-gray-50/80 p-4 dark:border-gray-800 dark:bg-[#141414]">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                    {t('caHoldingPeriodLabel')}
                  </span>
                  <CalendarClock className="h-3.5 w-3.5 text-[#14342a] dark:text-[#4ade80]" />
                </div>
                <p
                  data-testid="preview-days-held-invariant"
                  className="mt-1.5 text-sm font-bold text-gray-900 dark:text-gray-100"
                >
                  {t('caHoldingPeriodPreserved')}
                </p>
                <p className="mt-0.5 text-[11px] text-gray-500 dark:text-gray-400">
                  {t('caEffectiveDateHint', { date: selectedAction.effectiveDate })}
                </p>
              </div>
            </div>

            {/* Per-Lot Before / After Comparison Table */}
            <div className="mt-4 overflow-hidden rounded-2xl border border-gray-200 dark:border-gray-800">
              <div className="bg-gray-50/90 px-4 py-2.5 text-xs font-bold text-gray-700 dark:bg-[#16191D] dark:text-gray-200">
                {t('caLotComparisonTitle')}
              </div>
              <div className="overflow-x-auto">
                <table
                  data-testid="corporate-action-preview-table"
                  className="min-w-full divide-y divide-gray-200 text-xs dark:divide-gray-800"
                >
                  <thead className="bg-white dark:bg-[#1E1E1E]">
                    <tr>
                      <th className="px-3.5 py-2.5 text-left font-semibold text-gray-500 dark:text-gray-400">
                        {t('caColumnPurchaseDate')}
                      </th>
                      <th className="px-3.5 py-2.5 text-right font-semibold text-gray-500 dark:text-gray-400">
                        {t('caColumnQuantity')}
                      </th>
                      <th className="px-3.5 py-2.5 text-right font-semibold text-gray-500 dark:text-gray-400">
                        {t('caColumnUnitCost')}
                      </th>
                      <th className="px-3.5 py-2.5 text-right font-semibold text-gray-500 dark:text-gray-400">
                        {t('caColumnTotalCost')}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 bg-white dark:divide-gray-800/70 dark:bg-[#1E1E1E]">
                    {activePreview.lotPreviews.map((lp) => (
                      <tr key={lp.lotId}>
                        <td className="px-3.5 py-3 text-gray-800 dark:text-gray-200 tabular-nums">
                          <div className="font-semibold">{lp.date}</div>
                          <div className="text-[11px] text-[#059669] dark:text-[#4ade80]">
                            {t('caHoldingDays', { before: lp.daysHeldBefore, after: lp.daysHeldAfter })}
                          </div>
                        </td>
                        <td className="px-3.5 py-3 text-right font-semibold text-gray-900 dark:text-gray-100 tabular-nums">
                          {lp.affected ? (
                            <span>
                              <span className="text-gray-400 line-through mr-1.5">
                                {lp.qtyBefore}
                              </span>
                              <span className="text-[#14342a] dark:text-[#4ade80] font-bold">
                                → {lp.qtyAfter}
                              </span>
                            </span>
                          ) : (
                            <span>{lp.qtyAfter} ({t('caNotAffected')})</span>
                          )}
                        </td>
                        <td className="px-3.5 py-3 text-right font-semibold text-gray-900 dark:text-gray-100 tabular-nums">
                          {lp.affected ? (
                            <span>
                              <span className="text-gray-400 line-through mr-1.5">
                                {formatMoneyTHB(lp.costPerUnitBefore)}
                              </span>
                              <span className="text-[#059669] dark:text-[#4ade80] font-bold">
                                → {formatMoneyTHB(lp.costPerUnitAfter)}
                              </span>
                            </span>
                          ) : (
                            <span>{formatMoneyTHB(lp.costPerUnitAfter)}</span>
                          )}
                        </td>
                        <td className="px-3.5 py-3 text-right font-bold text-gray-900 dark:text-gray-100 tabular-nums">
                          {formatMoneyTHB(lp.totalCostBasisAfter)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setSelectedAction(null)}
                className="rounded-xl border border-gray-200 px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
              >
                {t('caCancelBtn')}
              </button>
              <button
                type="button"
                disabled={submitting}
                data-testid="confirm-apply-corporate-action-btn"
                onClick={handleConfirmApply}
                className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-60"
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>{submitting ? t('caSaving') : t('caConfirmBtn')}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

export default CorporateActionAlert;
