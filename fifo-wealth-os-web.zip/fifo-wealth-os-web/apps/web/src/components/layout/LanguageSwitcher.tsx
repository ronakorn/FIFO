'use client';

import React, { useTransition } from 'react';
import { Globe } from 'lucide-react';
import { motion } from 'framer-motion';
import { useLocale, useTranslations } from 'next-intl';
import { usePathname, useRouter } from '@/navigation';
import { AppLocale } from '@/i18n';
import { cn } from '@/lib/utils';

export function LanguageSwitcher({ className }: { className?: string }) {
  const locale = useLocale() as AppLocale;
  const t = useTranslations('header');
  const router = useRouter();
  const pathname = usePathname();
  const [isPending, startTransition] = useTransition();

  const handleSelectLocale = (nextLocale: AppLocale) => {
    if (nextLocale === locale) return;
    startTransition(() => {
      router.replace(pathname, { locale: nextLocale });
    });
  };

  return (
    <div
      data-testid="language-switcher"
      aria-label={t('languageSwitcherLabel')}
      className={cn(
        'inline-flex items-center gap-1 rounded-xl border border-gray-200/80 bg-white p-1 shadow-sm dark:border-gray-700 dark:bg-[#1E1E1E]',
        isPending && 'opacity-70',
        className
      )}
    >
      <Globe className="ml-1.5 h-3.5 w-3.5 text-gray-400 dark:text-gray-500" />
      {(['th', 'en'] as const).map((lang) => {
        const isActive = locale === lang;
        return (
          <motion.button
            key={lang}
            type="button"
            whileTap={{ scale: 0.95 }}
            data-testid={`lang-btn-${lang}`}
            aria-pressed={isActive}
            onClick={() => handleSelectLocale(lang)}
            className={cn(
              'rounded-lg px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide transition-colors',
              isActive
                ? 'bg-[#14342a] text-white shadow-sm dark:text-[#4ade80]'
                : 'text-gray-500 hover:bg-gray-100 hover:text-[#1A1A1A] dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white'
            )}
          >
            {lang.toUpperCase()}
          </motion.button>
        );
      })}
    </div>
  );
}

export default LanguageSwitcher;
