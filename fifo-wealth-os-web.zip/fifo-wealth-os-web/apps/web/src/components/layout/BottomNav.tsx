'use client';

import React from 'react';
import {
  BookOpen,
  LayoutDashboard,
  PieChart,
  Target,
  User,
  Users,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Link, usePathname } from '@/navigation';
import { cn } from '@/lib/utils';

export function BottomNav() {
  const t = useTranslations('nav');
  const pathname = usePathname();

  if (pathname === '/login' || pathname === '/register') {
    return null;
  }

  const tabs = [
    {
      key: 'home',
      label: t('mobileHome'),
      href: '/',
      icon: LayoutDashboard,
      isActive: pathname === '/',
    },
    {
      key: 'portfolios',
      label: t('mobilePortfolios'),
      href: '/portfolios',
      icon: PieChart,
      isActive: pathname.startsWith('/portfolios'),
    },
    {
      key: 'fire',
      label: t('mobileFire'),
      href: '/fire',
      icon: Target,
      isActive: pathname.startsWith('/fire'),
    },
    {
      key: 'journal',
      label: t('mobileJournal'),
      href: '/journal',
      icon: BookOpen,
      isActive: pathname.startsWith('/journal'),
    },
    {
      key: 'family',
      label: t('mobileFamily'),
      href: '/family',
      icon: Users,
      isActive: pathname.startsWith('/family'),
    },
    {
      key: 'profile',
      label: t('mobileProfile'),
      href: '/profile',
      icon: User,
      isActive: pathname.startsWith('/profile'),
    },
  ];

  return (
    <nav
      aria-label={t('mobileNavigation')}
      data-testid="mobile-bottom-nav"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-gray-200/80 bg-white/85 backdrop-blur-md pb-safe dark:border-gray-800/80 dark:bg-[#1E1E1E]/90 md:hidden"
    >
      <div className="mx-auto grid h-16 max-w-md grid-cols-6 items-center px-1.5">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <Link
              key={tab.key}
              href={tab.href}
              aria-current={tab.isActive ? 'page' : undefined}
              className={cn(
                'group flex flex-col items-center justify-center gap-1 py-1.5 transition-colors',
                tab.isActive
                  ? 'text-[#14342a] dark:text-[#4ade80]'
                  : 'text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300'
              )}
            >
              <span
                className={cn(
                  'flex h-7 w-10 items-center justify-center rounded-xl transition-all',
                  tab.isActive
                    ? 'bg-[#14342a]/10 dark:bg-[#4ade80]/15'
                    : 'bg-transparent'
                )}
              >
                <Icon
                  className={cn(
                    'h-[18px] w-[18px] transition-transform',
                    tab.isActive
                      ? 'fill-current/20 stroke-[2.4] scale-105'
                      : 'stroke-[1.8]'
                  )}
                />
              </span>
              <span
                className={cn(
                  'truncate max-w-[54px] text-[10px] leading-none tracking-tight',
                  tab.isActive ? 'font-bold' : 'font-medium'
                )}
              >
                {tab.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export default BottomNav;
