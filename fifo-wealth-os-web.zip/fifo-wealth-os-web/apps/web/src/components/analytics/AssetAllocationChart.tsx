'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import { useTheme } from 'next-themes';
import { useTranslations } from 'next-intl';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { formatTHB } from '@/lib/utils';
import { ChartTooltip } from '@/components/common/ChartTooltip';
import { AssetClassAllocation, AssetClassCategory } from '@/types/analytics';

const Dec = Decimal.clone({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

const CLEAN_LIGHT_COLORS: Record<AssetClassCategory, string> = {
  THAI_EQUITY: '#14342a',
  FOREIGN_EQUITY: '#059669',
  CRYPTO: '#0d9488',
  GOLD: '#d97706',
  CASH: '#64748b',
};

const CLEAN_DARK_COLORS: Record<AssetClassCategory, string> = {
  THAI_EQUITY: '#4ade80',
  FOREIGN_EQUITY: '#10b981',
  CRYPTO: '#2dd4bf',
  GOLD: '#fbbf24',
  CASH: '#94a3b8',
};

export function AssetAllocationSkeleton() {
  return (
    <div
      data-testid="asset-allocation-skeleton"
      aria-busy="true"
      className="animate-pulse rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      <div className="space-y-2">
        <div className="h-4 w-48 rounded bg-gray-200 dark:bg-gray-700" />
        <div className="h-3 w-36 rounded bg-gray-100 dark:bg-gray-800" />
      </div>
      <div className="mt-6 grid grid-cols-1 items-center gap-4 sm:grid-cols-2">
        <div className="mx-auto h-44 w-44 rounded-full border-[18px] border-gray-100 dark:border-gray-800" />
        <div className="space-y-2.5">
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="h-9 rounded-xl bg-gray-50 dark:bg-[#121212]" />
          ))}
        </div>
      </div>
    </div>
  );
}

export function AssetAllocationChart({
  allocations,
  isLoading = false,
}: {
  allocations: AssetClassAllocation[];
  isLoading?: boolean;
}) {
  const [mounted, setMounted] = useState(false);
  const { resolvedTheme } = useTheme();
  const t = useTranslations('dashboard');

  useEffect(() => {
    setMounted(true);
  }, []);

  const isDark = resolvedTheme === 'dark';
  const palette = isDark ? CLEAN_DARK_COLORS : CLEAN_LIGHT_COLORS;
  const { totalTHBStr, chartSlices } = useMemo(() => {
    const classLabels: Record<AssetClassCategory, string> = {
      THAI_EQUITY: t('chartAssetThaiEquity'),
      FOREIGN_EQUITY: t('chartAssetForeignEquity'),
      CRYPTO: t('chartAssetCrypto'),
      GOLD: t('chartAssetGold'),
      CASH: t('chartAssetCash'),
    };
    let sum = new Dec(0);
    for (const item of allocations) {
      sum = sum.plus(new Dec(item.valueTHB || '0'));
    }

    const nonZero = allocations
      .filter((item) => new Dec(item.valueTHB || '0').gt(0))
      .map((item) => ({
        name: classLabels[item.category],
        value: new Dec(item.valueTHB).toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toNumber(),
        color: palette[item.category] ?? item.color,
      }));

    return {
      totalTHBStr: sum.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
      chartSlices:
        nonZero.length > 0
          ? nonZero
          : [{ name: t('chartNoAssets'), value: 1, color: isDark ? '#374151' : '#E5E7EB' }],
    };
  }, [allocations, isDark, palette, t]);

  if (isLoading || !mounted) {
    return <AssetAllocationSkeleton />;
  }

  return (
    <div className="flex h-full flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
      <div>
        <h3 className="text-base font-bold tracking-tight text-gray-900 dark:text-gray-100">
          {t('chartAllocationTitle')}
        </h3>
        <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
          {t('chartAllocationSubtitle')}
        </p>
      </div>

      <div className="mt-4 grid grid-cols-1 items-center gap-4 sm:grid-cols-12">
        {/* Donut Chart */}
        <div className="relative h-52 sm:col-span-5">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartSlices}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={54}
                outerRadius={76}
                paddingAngle={2.5}
                stroke={isDark ? '#1E1E1E' : '#FFFFFF'}
                strokeWidth={2}
                isAnimationActive={false}
              >
                {chartSlices.map((entry) => (
                  <Cell key={entry.name} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                content={(
                  <ChartTooltip
                    formatter={(value) => {
                      const amount = Array.isArray(value) ? value[0] ?? 0 : value ?? 0;
                      return { label: '', value: formatTHB(amount) };
                    }}
                  />
                )}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-[10px] font-medium uppercase tracking-wider text-gray-400">
              {t('chartTotal')}
            </span>
            <span className="text-xs font-bold text-gray-900 tabular-nums dark:text-gray-100">
              {formatTHB(totalTHBStr)}
            </span>
          </div>
        </div>

        {/* 5 Asset Classes List */}
        <div className="space-y-2 sm:col-span-7">
          {allocations.map((item) => {
            const hasValue = new Dec(item.valueTHB || '0').gt(0);
            const swatch = palette[item.category] ?? item.color;
            return (
              <div
                key={item.category}
                className="flex items-center justify-between rounded-xl border border-gray-100 bg-gray-50/70 px-3 py-2 text-xs dark:border-gray-800 dark:bg-[#121212]/70"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: swatch }}
                  />
                  <span className="truncate font-semibold text-gray-800 dark:text-gray-200">
                    {item.label}
                  </span>
                </div>

                <div className="ml-2 flex items-center gap-3 tabular-nums">
                  <span
                    className={
                      hasValue
                        ? 'text-gray-600 dark:text-gray-300'
                        : 'text-gray-400 dark:text-gray-600'
                    }
                  >
                    {formatTHB(item.valueTHB)}
                  </span>
                  <span className="w-12 text-right font-bold text-gray-900 dark:text-gray-100">
                    {item.weightPct}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default AssetAllocationChart;
