'use client';

import React, { useState } from 'react';
import { useTranslations } from 'next-intl';
import Decimal from 'decimal.js';
import {
  Activity,
  Gauge,
  HelpCircle,
  ShieldAlert,
  TrendingUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { PortfolioMetrics } from '@/types/analytics';

const Dec = Decimal.clone({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

function formatDecimalRateAsSignedPercent(rateStr: string): {
  text: string;
  isPositive: boolean;
  isNegative: boolean;
} {
  const pct = new Dec(rateStr || '0').times(new Dec(100));
  const fixed = pct.abs().toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
  if (pct.gt(0)) {
    return { text: `+${fixed}%`, isPositive: true, isNegative: false };
  }
  if (pct.lt(0)) {
    return { text: `-${fixed}%`, isPositive: false, isNegative: true };
  }
  return { text: `0.00%`, isPositive: false, isNegative: false };
}

function formatDrawdownPercent(ddStr: string): string {
  const pct = new Dec(ddStr || '0').abs().times(new Dec(100));
  if (pct.isZero()) return '0.00%';
  return `-${pct.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2)}%`;
}

function formatRatioValue(ratioStr: string): {
  text: string;
  qualityKey: 'ratioExcellent' | 'ratioGood' | 'ratioModerate';
  tone: 'emerald' | 'neutral' | 'amber';
} {
  const val = new Dec(ratioStr || '0');
  const text = val.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
  if (val.gte(new Dec('1.5'))) {
    return { text, qualityKey: 'ratioExcellent', tone: 'emerald' };
  }
  if (val.gte(new Dec('1.0'))) {
    return { text, qualityKey: 'ratioGood', tone: 'neutral' };
  }
  return { text, qualityKey: 'ratioModerate', tone: 'amber' };
}

export function MetricsGridSkeleton() {
  const t = useTranslations('dashboard.metrics');
  return (
    <div
      data-testid="metrics-grid-skeleton"
      aria-busy="true"
      aria-label={t('loadingAria')}
      className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4"
    >
      {[0, 1, 2, 3].map((idx) => (
        <div
          key={idx}
          className="animate-pulse rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
        >
          <div className="flex items-center justify-between">
            <div className="h-3.5 w-28 rounded bg-gray-200 dark:bg-gray-700" />
            <div className="h-8 w-8 rounded-xl bg-gray-100 dark:bg-gray-800" />
          </div>
          <div className="mt-4 h-8 w-28 rounded-lg bg-gray-200 dark:bg-gray-700" />
          <div className="mt-3 h-3 w-40 rounded bg-gray-100 dark:bg-gray-800" />
        </div>
      ))}
    </div>
  );
}

interface MetricCardInfo {
  id: string;
  title: string;
  subtitle: string;
  value: string;
  badgeText: string;
  valueClass: string;
  icon: React.ComponentType<{ className?: string }>;
  tooltipTitle: string;
  tooltipBody: string;
  tooltipFormula: string;
}

export function MetricsGrid({
  metrics,
  isLoading = false,
}: {
  metrics?: PortfolioMetrics;
  isLoading?: boolean;
}) {
  const t = useTranslations('dashboard.metrics');
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [pinnedId, setPinnedId] = useState<string | null>(null);

  if (isLoading || !metrics) {
    return <MetricsGridSkeleton />;
  }

  const xirrFmt = formatDecimalRateAsSignedPercent(metrics.xirr);
  const twrFmt = formatDecimalRateAsSignedPercent(metrics.twr);
  const totalRetFmt = formatDecimalRateAsSignedPercent(metrics.totalReturn);
  const sharpeFmt = formatRatioValue(metrics.sharpeRatio);
  const sortinoFmt = formatRatioValue(metrics.sortinoRatio);
  const mddText = formatDrawdownPercent(metrics.maxDrawdown);

  const cards: MetricCardInfo[] = [
    {
      id: 'xirr',
      title: t('xirrTitle'),
      subtitle: t('xirrSubtitle'),
      value: xirrFmt.text,
      badgeText: t('totalReturnBadge', { value: totalRetFmt.text }),
      valueClass: xirrFmt.isNegative
        ? 'text-[#DC2626] dark:text-rose-400'
        : 'text-[#059669] dark:text-emerald-400',
      icon: TrendingUp,
      tooltipTitle: t('xirrTooltipTitle'),
      tooltipBody:
        t('xirrTooltipBody'),
      tooltipFormula: 'Newton-Raphson NPV(CF_i, t_i) = 0',
    },
    {
      id: 'twr',
      title: t('twrTitle'),
      subtitle: t('twrSubtitle'),
      value: twrFmt.text,
      badgeText: t('gipsBadge'),
      valueClass: twrFmt.isNegative
        ? 'text-[#DC2626] dark:text-rose-400'
        : 'text-[#14342a] dark:text-[#4ade80]',
      icon: Activity,
      tooltipTitle: t('twrTooltipTitle'),
      tooltipBody:
        t('twrTooltipBody'),
      tooltipFormula: '(1 + r₁)(1 + r₂)...(1 + rₙ) - 1',
    },
    {
      id: 'sharpe',
      title: t('sharpeTitle'),
      subtitle: t('sharpeSubtitle'),
      value: sharpeFmt.text,
      badgeText: t('sortinoBadge', { value: sortinoFmt.text, quality: t(sharpeFmt.qualityKey) }),
      valueClass: 'text-gray-900 dark:text-gray-100',
      icon: Gauge,
      tooltipTitle: t('sharpeTooltipTitle'),
      tooltipBody:
        t('sharpeTooltipBody'),
      tooltipFormula: '(Mean Return - R_f) / σ_portfolio',
    },
    {
      id: 'mdd',
      title: t('drawdownTitle'),
      subtitle: t('drawdownSubtitle'),
      value: mddText,
      badgeText: t('drawdownBadge'),
      valueClass:
        mddText === '0.00%'
          ? 'text-[#059669] dark:text-emerald-400'
          : 'text-[#DC2626] dark:text-rose-400',
      icon: ShieldAlert,
      tooltipTitle: t('drawdownTooltipTitle'),
      tooltipBody:
        t('drawdownTooltipBody'),
      tooltipFormula: 'max((Peak_t - Value_t) / Peak_t)',
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => {
        const Icon = card.icon;
        const isOpen = pinnedId === card.id || hoveredId === card.id;

        return (
          <div
            key={card.id}
            onMouseEnter={() => setHoveredId(card.id)}
            onMouseLeave={() => setHoveredId((prev) => (prev === card.id ? null : prev))}
            className="relative rounded-2xl border border-gray-100 bg-white p-5 shadow-sm transition hover:border-gray-200 dark:border-gray-800 dark:bg-[#1E1E1E] dark:hover:border-gray-700"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-gray-600 dark:text-gray-300">
                  {card.title}
                </span>
                <button
                  type="button"
                  aria-label={t('tooltipAria', { title: card.title })}
                  onClick={() =>
                    setPinnedId((prev) => (prev === card.id ? null : card.id))
                  }
                  onFocus={() => setHoveredId(card.id)}
                  onBlur={() => setHoveredId((prev) => (prev === card.id ? null : prev))}
                  className="rounded-full p-0.5 text-gray-400 transition hover:text-[#14342a] focus:outline-none dark:hover:text-[#4ade80]"
                >
                  <HelpCircle className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#14342a]/8 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                <Icon className="h-4 w-4" />
              </div>
            </div>

            <p
              className={cn(
                'mt-3 text-2xl sm:text-3xl font-bold tracking-tight tabular-nums',
                card.valueClass
              )}
            >
              {card.value}
            </p>

            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{card.subtitle}</p>

            <div className="mt-3 inline-flex items-center rounded-lg bg-gray-50 px-2.5 py-1 text-[11px] font-medium text-gray-600 tabular-nums dark:bg-[#121212] dark:text-gray-300">
              {card.badgeText}
            </div>

            {/* Clean Minimalist Tooltip */}
            {isOpen && (
              <div
                role="tooltip"
                className="absolute left-3 right-3 top-12 z-30 rounded-2xl border border-gray-200 bg-white p-4 text-left shadow-xl dark:border-gray-700 dark:bg-[#121212]"
              >
                <p className="text-xs font-bold text-[#14342a] dark:text-[#4ade80]">
                  {card.tooltipTitle}
                </p>
                <p className="mt-1 text-xs leading-relaxed text-gray-600 dark:text-gray-300">
                  {card.tooltipBody}
                </p>
                <p className="mt-2 rounded-lg bg-gray-50 px-2.5 py-1 text-[10px] font-medium text-[#14342a] tabular-nums dark:bg-[#1E1E1E] dark:text-[#4ade80]">
                  {t('formulaLabel')}: {card.tooltipFormula}
                </p>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default MetricsGrid;
