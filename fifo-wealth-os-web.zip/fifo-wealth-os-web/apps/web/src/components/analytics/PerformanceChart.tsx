'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import { useTheme } from 'next-themes';
import { useLocale, useTranslations } from 'next-intl';
import {
  Area,
  ComposedChart,
  CartesianGrid,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { cn, formatTHB } from '@/lib/utils';
import { ChartTooltip } from '@/components/common/ChartTooltip';
import { BenchmarkData, BenchmarkSymbol } from '@/types/analytics';

const Dec = Decimal.clone({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

export function PerformanceChartSkeleton() {
  return (
    <div
      data-testid="performance-chart-skeleton"
      aria-busy="true"
      className="animate-pulse rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <div className="h-4 w-52 rounded bg-gray-200 dark:bg-gray-700" />
          <div className="h-3 w-36 rounded bg-gray-100 dark:bg-gray-800" />
        </div>
        <div className="h-8 w-32 rounded-xl bg-gray-100 dark:bg-gray-800" />
      </div>
      <div className="mt-6 h-64 w-full rounded-xl bg-gray-50 dark:bg-[#121212]" />
    </div>
  );
}

interface PerformanceChartProps {
  data: BenchmarkData[];
  benchmark: BenchmarkSymbol;
  onBenchmarkChange?: (next: BenchmarkSymbol) => void;
  isLoading?: boolean;
}

function formatChartDateLabel(isoDate: string, locale: string): string {
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return isoDate;
  return new Intl.DateTimeFormat(locale === 'th' ? 'th-TH' : 'en-GB', {
    month: 'short',
    year: '2-digit',
  }).format(parsed);
}

export function PerformanceChart({
  data,
  benchmark,
  onBenchmarkChange,
  isLoading = false,
}: PerformanceChartProps) {
  const [mounted, setMounted] = useState(false);
  const { resolvedTheme } = useTheme();
  const locale = useLocale();
  const t = useTranslations('dashboard');

  useEffect(() => {
    setMounted(true);
  }, []);

  const alphaStats = useMemo(() => {
    const first = data[0];
    const last = data[data.length - 1];
    if (!first || !last || first.portfolioValue <= 0 || first.benchmarkValue <= 0) {
      return { alphaText: '+0.00%', isOutperforming: true };
    }

    const p0 = new Dec(first.portfolioValue.toString());
    const p1 = new Dec(last.portfolioValue.toString());
    const b0 = new Dec(first.benchmarkValue.toString());
    const b1 = new Dec(last.benchmarkValue.toString());

    const portRetPct = p1.minus(p0).dividedBy(p0).times(100);
    const benchRetPct = b1.minus(b0).dividedBy(b0).times(100);
    const alpha = portRetPct.minus(benchRetPct);

    const sign = alpha.gte(0) ? '+' : '-';
    return {
      alphaText: `${sign}${alpha.abs().toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2)}%`,
      isOutperforming: alpha.gte(0),
    };
  }, [data]);

  if (isLoading || !mounted) {
    return <PerformanceChartSkeleton />;
  }

  const isDark = resolvedTheme === 'dark';
  const primaryStroke = isDark ? '#4ade80' : '#14342a';
  const benchmarkStroke = isDark ? '#9CA3AF' : '#94A3B8';
  const gridStroke = isDark ? '#262626' : '#F3F4F6';
  const axisStroke = isDark ? '#9CA3AF' : '#6B7280';

  const chartRows = data.map((row) => ({
    ...row,
    label: formatChartDateLabel(row.date, locale),
  }));

  const benchmarkLabel =
    benchmark === 'SP500' ? t('chartBenchmarkSP500') : t('chartBenchmarkSET50');

  return (
    <div className="flex h-full flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
      {/* Header & Benchmark Switcher */}
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-base font-bold tracking-tight text-gray-900 dark:text-gray-100">
              {t('chartPerformanceTitle')}
            </h3>
            <span
              className={cn(
                'rounded-full px-2.5 py-0.5 text-[11px] font-bold tabular-nums',
                alphaStats.isOutperforming
                  ? 'bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400'
                  : 'bg-red-50 text-[#DC2626] dark:bg-red-950/60 dark:text-rose-400'
              )}
            >
              {t('chartAlpha')} {alphaStats.alphaText}
            </span>
          </div>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
            {t('chartPerformanceSubtitle', { benchmark })}
          </p>
        </div>

        {onBenchmarkChange && (
          <div className="inline-flex self-start rounded-xl bg-gray-100 p-1 dark:bg-[#121212]">
            {(['SP500', 'SET50'] as const).map((sym) => (
              <button
                key={sym}
                type="button"
                onClick={() => onBenchmarkChange(sym)}
                className={cn(
                  'rounded-lg px-3 py-1 text-xs font-semibold transition',
                  benchmark === sym
                    ? 'bg-[#14342a] text-white shadow-sm dark:text-[#4ade80]'
                    : 'text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200'
                )}
              >
                {sym === 'SP500' ? 'S&P 500' : 'SET50'}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Minimalist Legend */}
      <div className="mb-3 flex flex-wrap items-center gap-5 text-xs">
        <span className="flex items-center gap-2 font-semibold text-gray-900 dark:text-gray-100">
          <span
            className="h-2.5 w-2.5 rounded-full"
            style={{ backgroundColor: primaryStroke }}
          />
          {t('chartPortfolioLegend')}
        </span>
        <span className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
          <span
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: benchmarkStroke }}
          />
          {benchmarkLabel}
        </span>
      </div>

      {/* Recharts Composed Area + Line with Soft Primary Gradient & Faint Grid */}
      <div className="h-64 w-full">
        {chartRows.length === 0 ? (
          <div className="flex h-full items-center justify-center text-xs text-gray-400">
            {t('chartNoPerformance')}
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartRows} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="forestPrimaryGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={primaryStroke} stopOpacity={0.18} />
                  <stop offset="100%" stopColor={primaryStroke} stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={gridStroke} strokeDasharray="3 3" vertical={false} />
              <XAxis
                dataKey="label"
                stroke={axisStroke}
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke={axisStroke}
                fontSize={11}
                tickLine={false}
                axisLine={false}
                width={64}
                domain={['auto', 'auto']}
                tickFormatter={(val: number) =>
                  val >= 1000 ? `฿${Math.round(val / 1000)}k` : `฿${val}`
                }
              />
              <Tooltip
                content={(
                  <ChartTooltip
                    formatter={(value, name) => {
                      const amount = Array.isArray(value) ? value[0] ?? 0 : value ?? 0;
                      return {
                        label: name === 'portfolioValue' ? t('chartPortfolioValue') : t('chartBenchmarkValue'),
                        value: formatTHB(amount),
                      };
                    }}
                  />
                )}
              />
              <Line
                type="monotone"
                dataKey="benchmarkValue"
                stroke={benchmarkStroke}
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={false}
                isAnimationActive={false}
              />
              <Area
                type="monotone"
                dataKey="portfolioValue"
                stroke={primaryStroke}
                strokeWidth={2.5}
                fill="url(#forestPrimaryGradient)"
                dot={{ r: 3, fill: primaryStroke, strokeWidth: 0 }}
                activeDot={{ r: 5 }}
                isAnimationActive={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}

export default PerformanceChart;
