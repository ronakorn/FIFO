'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { useTranslations } from 'next-intl';
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  Pencil,
  Target,
  Trash2,
} from 'lucide-react';
import { FIREGoal, GoalProgress } from '@/types/fire';
import { cn, formatTHB } from '@/lib/utils';

interface GoalCardProps {
  goal: FIREGoal;
  progress: GoalProgress;
  onEdit?: (goal: FIREGoal) => void;
  onDelete?: (goalId: string) => void;
}

export function GoalCard({ goal, progress, onEdit, onDelete }: GoalCardProps) {
  const t = useTranslations('fire');
  const pctNum = Math.min(100, Math.max(0, Number(progress.progressPct) || 0));
  const isMock = goal.id.startsWith('mock-');
  const expectedReturnPctDisplay = (Number(goal.expectedReturn) * 100).toFixed(1);

  return (
    <div
      data-testid="fire-goal-card"
      className="group relative flex flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm transition hover:border-[#14342a]/25 hover:shadow-md dark:border-gray-800 dark:bg-[#1E1E1E] dark:hover:border-[#4ade80]/30"
    >
      <div>
        {/* Top Row: Icon + Title + Top-Right Edit/Delete Icon Buttons */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#14342a]/5 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <Target className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <h3 className="truncate text-base font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                {goal.name}
              </h3>
              <p className="mt-0.5 text-xs text-gray-500 tabular-nums dark:text-gray-400">
                {t('goalRetirementSummary', { retirementAge: goal.retirementAge, currentAge: goal.currentAge, expectedReturn: expectedReturnPctDisplay })}
              </p>
            </div>
          </div>

          {/* Small subtle Edit / Delete Icon Buttons at top-right */}
          {!isMock && (
            <div className="flex shrink-0 items-center gap-1">
              {onEdit && (
                <button
                  type="button"
                  aria-label={t('editGoalAria', { name: goal.name })}
                  onClick={() => onEdit(goal)}
                  className="rounded-lg p-1.5 text-gray-400 transition hover:bg-gray-100 hover:text-[#14342a] dark:hover:bg-gray-800 dark:hover:text-[#4ade80]"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </button>
              )}
              {onDelete && (
                <button
                  type="button"
                  aria-label={t('deleteGoalAria', { name: goal.name })}
                  onClick={() => onDelete(goal.id)}
                  className="rounded-lg p-1.5 text-gray-400 transition hover:bg-red-50 hover:text-[#DC2626] dark:hover:bg-red-950/40 dark:hover:text-rose-400"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Amounts & Percentage Callout */}
        <div className="mt-5 flex items-baseline justify-between gap-2">
          <div>
            <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">
              {t('currentWealthProgress')}
            </p>
            <p className="mt-0.5 text-lg font-bold tracking-tight text-[#1A1A1A] tabular-nums dark:text-[#F5F5F5]">
              {formatTHB(progress.currentAmount)}{' '}
              <span className="text-xs font-normal text-gray-400">
                / {formatTHB(progress.targetAmount)}
              </span>
            </p>
          </div>

          <span className="rounded-lg bg-[#14342a]/5 px-2.5 py-1 text-sm font-bold text-[#14342a] tabular-nums dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
            {progress.progressPct}%
          </span>
        </div>

        {/* Gradient Progress Bar (#DC2626 -> #F59E0B -> #059669) */}
        <div className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.max(4, pctNum)}%` }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="h-full rounded-full"
            style={{
              backgroundImage:
                'linear-gradient(90deg, #DC2626 0%, #F59E0B 50%, #059669 100%)',
            }}
          />
        </div>
      </div>

      {/* Footer: Years Remaining + On-Track Status Badge */}
      <div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-gray-100 pt-3.5 text-xs dark:border-gray-800">
        <div className="flex items-center gap-1.5 font-medium text-gray-600 tabular-nums dark:text-gray-300">
          <CalendarClock className="h-4 w-4 text-gray-400" />
          <span>
            {t('yearsRemainingSummary', { years: progress.yearsRemaining, year: goal.targetYear })}
          </span>
        </div>

        <span
          className={cn(
            'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold',
            progress.onTrack
              ? 'bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400'
              : 'bg-red-50 text-[#DC2626] dark:bg-red-950/60 dark:text-rose-400'
          )}
        >
          {progress.onTrack ? (
            <>
              <CheckCircle2 className="h-3.5 w-3.5" />
              {t('onTrackStatus')}
            </>
          ) : (
            <>
              <AlertTriangle className="h-3.5 w-3.5" />
              {t('offTrackStatus')}
            </>
          )}
        </span>
      </div>
    </div>
  );
}

export default GoalCard;
