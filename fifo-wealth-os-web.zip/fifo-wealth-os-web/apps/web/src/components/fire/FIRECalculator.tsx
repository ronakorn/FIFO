'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import Decimal from 'decimal.js';
import { animate, motion, useMotionValue } from 'framer-motion';
import { Calculator, Play, PlusCircle, Sparkles, Clock } from 'lucide-react';
import {
  calculateFIRENumberClient,
  calculateYearsToFIREClient,
} from '@/lib/fireClientMath';
import { useFirePlannerStore } from '@/lib/stores';
import { cn, formatTHB } from '@/lib/utils';

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

interface FIRECalculatorProps {
  livePortfolioValueTHB: string;
  isSimulating?: boolean;
  onRunSimulation: (params: {
    currentAmount: string;
    monthlyContribution: string;
    expectedReturn: string;
    volatility: string;
    years: number;
    targetAmount: string;
  }) => void;
  onSaveAsGoal?: (params: {
    targetAmount: string;
    currentAmount: string;
    monthlyContribution: string;
    expectedReturn: string;
    inflationRate: string;
    yearsToFIRE: number;
  }) => void;
}

function AnimatedCurrencyDisplay({ valueStr }: { valueStr: string }) {
  const targetVal = useMemo(() => {
    try {
      return new Dec(valueStr || '0').toNumber();
    } catch {
      return 0;
    }
  }, [valueStr]);

  const motionVal = useMotionValue(targetVal);
  const [renderedText, setRenderedText] = useState(() => formatTHB(valueStr));

  useEffect(() => {
    const controls = animate(motionVal, targetVal, {
      duration: 0.45,
      ease: 'easeOut',
      onUpdate: (latest) => {
        setRenderedText(formatTHB(latest));
      },
      onComplete: () => {
        setRenderedText(formatTHB(valueStr));
      },
    });
    return () => controls.stop();
  }, [targetVal, valueStr, motionVal]);

  return (
    <motion.p
      key="fire-number-animated"
      initial={{ opacity: 0.85, y: 3 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      data-testid="calculated-fire-number"
      className="mt-1.5 text-3xl sm:text-4xl font-bold tracking-tight text-[#14342a] tabular-nums dark:text-[#4ade80]"
    >
      {renderedText}
    </motion.p>
  );
}

export function FIRECalculator({
  livePortfolioValueTHB,
  isSimulating = false,
  onRunSimulation,
  onSaveAsGoal,
}: FIRECalculatorProps) {
  const t = useTranslations('fire');
  const {
    monthlyExpenses,
    withdrawalRatePct,
    currentSavings,
    monthlyContribution,
    expectedReturnPct,
    inflationRatePct,
    volatilityPct,
    horizonYears,
    setField,
  } = useFirePlannerStore();

  const totalStartingWealthStr = useMemo(() => {
    try {
      return new Dec(livePortfolioValueTHB || '0')
        .plus(new Dec(currentSavings || '0'))
        .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
        .toFixed(2);
    } catch {
      return livePortfolioValueTHB || '0.00';
    }
  }, [livePortfolioValueTHB, currentSavings]);

  const fireNumberStr = useMemo(
    () => calculateFIRENumberClient(monthlyExpenses, withdrawalRatePct),
    [monthlyExpenses, withdrawalRatePct]
  );

  const yearsToFIREStr = useMemo(
    () =>
      calculateYearsToFIREClient(
        totalStartingWealthStr,
        monthlyContribution,
        fireNumberStr,
        expectedReturnPct,
        inflationRatePct
      ),
    [
      totalStartingWealthStr,
      monthlyContribution,
      fireNumberStr,
      expectedReturnPct,
      inflationRatePct,
    ]
  );

  const handleSimulateClick = (e: React.FormEvent) => {
    e.preventDefault();
    const expReturnDec = new Dec(expectedReturnPct || '8')
      .dividedBy(100)
      .toFixed(4);
    const volDec = new Dec(volatilityPct || '15').dividedBy(100).toFixed(4);

    onRunSimulation({
      currentAmount: totalStartingWealthStr,
      monthlyContribution: new Dec(monthlyContribution || '0').toFixed(2),
      expectedReturn: expReturnDec,
      volatility: volDec,
      years: horizonYears,
      targetAmount: fireNumberStr,
    });
  };

  const handleSaveGoalClick = () => {
    if (!onSaveAsGoal) return;
    const expReturnDec = new Dec(expectedReturnPct || '8')
      .dividedBy(100)
      .toFixed(4);
    const infDec = new Dec(inflationRatePct || '3').dividedBy(100).toFixed(4);
    const estYears = Math.max(
      1,
      Math.min(50, Math.round(Number(yearsToFIREStr) || horizonYears))
    );

    onSaveAsGoal({
      targetAmount: fireNumberStr,
      currentAmount: new Dec(currentSavings || '0').toFixed(2),
      monthlyContribution: new Dec(monthlyContribution || '0').toFixed(2),
      expectedReturn: expReturnDec,
      inflationRate: infDec,
      yearsToFIRE: estYears,
    });
  };

  return (
    <div className="flex h-full flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
      <div>
        {/* Card Header */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 rounded-full bg-[#14342a]/5 px-2.5 py-1 text-[11px] font-semibold text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <Calculator className="h-3.5 w-3.5" />
              {t('calculatorEngine')}
            </div>
            <h2 className="mt-2 text-lg font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
              {t('calculatorTitle')}
            </h2>
            <p className="mt-0.5 text-xs leading-relaxed text-gray-500 dark:text-gray-400">
              {t('calculatorDescription')}
            </p>
          </div>
        </div>

        {/* Real-Time Animated FIRE Number Callout */}
        <div className="mt-5 rounded-2xl border border-[#14342a]/10 bg-[#14342a]/5 p-5 dark:border-[#4ade80]/20 dark:bg-[#4ade80]/10">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-600 dark:text-gray-300">
            <span>{t('fireNumber')}</span>
            <Sparkles className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
          </div>

          <AnimatedCurrencyDisplay valueStr={fireNumberStr} />

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#14342a]/10 pt-3 text-xs dark:border-[#4ade80]/15">
            <span className="inline-flex items-center gap-1.5 font-semibold text-[#059669] tabular-nums dark:text-emerald-400">
              <Clock className="h-3.5 w-3.5" />
              {t('yearsToTarget', { years: yearsToFIREStr })}
            </span>
            <span className="text-[11px] text-gray-500 tabular-nums dark:text-gray-400">
              {t('linkedLivePortfolio', { amount: formatTHB(livePortfolioValueTHB) })}
            </span>
          </div>
        </div>

        {/* Clean Minimalist Input Form */}
        <form onSubmit={handleSimulateClick} className="mt-5 space-y-4">
          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
            <div>
              <div className="mb-1.5 flex min-h-[18px] items-center">
                <label
                  htmlFor="fire-monthly-expenses"
                  className="block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]"
                >
                  {t('monthlyExpenses')}
                </label>
              </div>
              <input
                id="fire-monthly-expenses"
                type="number"
                min="1000"
                step="1000"
                value={monthlyExpenses}
                onChange={(e) => setField('monthlyExpenses', e.target.value)}
                className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3.5 text-sm font-medium text-[#1A1A1A] tabular-nums focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>

            <div>
              <div className="mb-1.5 flex min-h-[18px] items-center justify-between gap-1">
                <label
                  htmlFor="fire-swr"
                  className="whitespace-nowrap text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]"
                >
                  {t('withdrawalRate')}
                </label>
                <div className="flex shrink-0 gap-1">
                  {['3.5', '4.0', '4.5'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setField('withdrawalRatePct', preset)}
                      className={cn(
                        'rounded-md px-1.5 py-0.5 text-[10px] font-bold tabular-nums transition',
                        withdrawalRatePct === preset
                          ? 'bg-[#14342a] text-white dark:text-[#4ade80]'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300'
                      )}
                    >
                      {preset}%
                    </button>
                  ))}
                </div>
              </div>
              <input
                id="fire-swr"
                type="number"
                min="1"
                max="15"
                step="0.1"
                value={withdrawalRatePct}
                onChange={(e) => setField('withdrawalRatePct', e.target.value)}
                className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3.5 text-sm font-medium text-[#1A1A1A] tabular-nums focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
            <div>
              <label
                htmlFor="fire-current-savings"
                className="mb-1.5 block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]"
              >
                {t('otherSavings')}
              </label>
              <input
                id="fire-current-savings"
                type="number"
                min="0"
                step="50000"
                value={currentSavings}
                onChange={(e) => setField('currentSavings', e.target.value)}
                className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3.5 text-sm font-medium text-[#1A1A1A] tabular-nums focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>

            <div>
              <label
                htmlFor="fire-monthly-contrib"
                className="mb-1.5 block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]"
              >
                {t('monthlyContribution')}
              </label>
              <input
                id="fire-monthly-contrib"
                type="number"
                min="0"
                step="1000"
                value={monthlyContribution}
                onChange={(e) => setField('monthlyContribution', e.target.value)}
                className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3.5 text-sm font-medium text-[#1A1A1A] tabular-nums focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            <div>
              <label
                htmlFor="fire-exp-return"
                className="mb-1.5 block text-[11px] font-semibold text-gray-600 dark:text-gray-300"
              >
                {t('expectedReturn')}
              </label>
              <input
                id="fire-exp-return"
                type="number"
                step="0.5"
                value={expectedReturnPct}
                onChange={(e) => setField('expectedReturnPct', e.target.value)}
                className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3 text-sm font-medium text-[#1A1A1A] tabular-nums focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>

            <div>
              <label
                htmlFor="fire-inflation"
                className="mb-1.5 block text-[11px] font-semibold text-gray-600 dark:text-gray-300"
              >
                {t('inflation')}
              </label>
              <input
                id="fire-inflation"
                type="number"
                step="0.5"
                value={inflationRatePct}
                onChange={(e) => setField('inflationRatePct', e.target.value)}
                className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3 text-sm font-medium text-[#1A1A1A] tabular-nums focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>

            <div>
              <label
                htmlFor="fire-horizon"
                className="mb-1.5 block text-[11px] font-semibold text-gray-600 dark:text-gray-300"
              >
                {t('simulationHorizon')}
              </label>
              <input
                id="fire-horizon"
                type="number"
                min="5"
                max="50"
                value={horizonYears}
                onChange={(e) =>
                  setField('horizonYears', Math.max(5, Math.min(50, Number(e.target.value) || 20)))
                }
                className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3 text-sm font-medium text-[#1A1A1A] tabular-nums focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2.5 pt-2 sm:flex-row">
            <button
              type="submit"
              disabled={isSimulating}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-60"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              {isSimulating
                ? t('simulateLoading')
                : t('simulateMonteCarlo')}
            </button>

            {onSaveAsGoal && (
              <button
                type="button"
                onClick={handleSaveGoalClick}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-gray-100 px-4 py-2.5 text-xs font-semibold text-gray-900 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-100 dark:hover:bg-gray-700"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                {t('saveGoal')}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

export default FIRECalculator;
