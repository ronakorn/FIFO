'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import {
  Compass,
  LogIn,
  Plus,
  Sparkles,
  Target,
  TrendingUp,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ErrorMessage } from '@/components/ErrorMessage';
import { FIRECalculator } from './FIRECalculator';
import { GoalCard } from './GoalCard';
import { MonteCarloChart } from './MonteCarloChart';
import {
  UpsertFireGoalPayload,
  useCreateFireGoal,
  useDeleteFireGoal,
  useFireSummary,
  useRunMonteCarloMutation,
  useUpdateFireGoal,
} from '@/lib/queries';
import { useAuthStore } from '@/lib/stores';
import { extractApiErrorMessage, formatTHB } from '@/lib/utils';
import { mockFireSummary } from '@/mocks/mockFire';
import { FIREGoal, MonteCarloResult } from '@/types/fire';

export function FIRESummarySkeleton() {
  return (
    <div
      data-testid="fire-summary-skeleton"
      aria-busy="true"
      className="space-y-6 animate-pulse"
    >
      <div className="space-y-2">
        <div className="h-4 w-44 rounded bg-gray-200 dark:bg-gray-800" />
        <div className="h-8 w-96 max-w-full rounded-lg bg-gray-200 dark:bg-gray-800" />
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="h-28 rounded-2xl border border-gray-100 bg-white p-5 dark:border-gray-800 dark:bg-[#1E1E1E]"
          />
        ))}
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="h-[520px] rounded-2xl border border-gray-100 bg-white lg:col-span-5 dark:border-gray-800 dark:bg-[#1E1E1E]" />
        <div className="h-[520px] rounded-2xl border border-gray-100 bg-white lg:col-span-7 dark:border-gray-800 dark:bg-[#1E1E1E]" />
      </div>
    </div>
  );
}

export function FIRESummaryDashboard() {
  const t = useTranslations('fire');
  const token = useAuthStore((s) => s.token);
  const isHydrated = useAuthStore((s) => s.isHydrated);

  const summaryQuery = useFireSummary();
  const createGoalMutation = useCreateFireGoal();
  const updateGoalMutation = useUpdateFireGoal();
  const deleteGoalMutation = useDeleteFireGoal();
  const monteCarloMutation = useRunMonteCarloMutation();

  const [customMcResult, setCustomMcResult] = useState<MonteCarloResult | null>(null);
  const [customTargetTHB, setCustomTargetTHB] = useState<string | undefined>(undefined);

  // Modal state for Create / Edit FIRE Goal
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<FIREGoal | null>(null);
  const [goalName, setGoalName] = useState('');
  const [goalTarget, setGoalTarget] = useState('12000000');
  const [goalCurrent, setGoalCurrent] = useState('500000');
  const [goalMonthly, setGoalMonthly] = useState('30000');
  const [goalReturnPct, setGoalReturnPct] = useState('8.0');
  const [goalCurrentAge, setGoalCurrentAge] = useState(32);
  const [goalRetireAge, setGoalRetireAge] = useState(50);
  const [goalError, setGoalError] = useState<string | null>(null);

  if (!isHydrated || (token && summaryQuery.isLoading)) {
    return <FIRESummarySkeleton />;
  }

  if (token && summaryQuery.isError) {
    return (
      <ErrorMessage
        title={t('pageError')}
        message={extractApiErrorMessage(summaryQuery.error, t('pageError'))}
        onRetry={() => summaryQuery.refetch()}
      />
    );
  }

  const activeSummary = token
    ? (summaryQuery.data ?? mockFireSummary)
    : mockFireSummary;

  const displayedMc = customMcResult ?? activeSummary.monteCarlo;

  const openCreateModal = (prefill?: {
    targetAmount: string;
    currentAmount: string;
    monthlyContribution: string;
    expectedReturn: string;
    yearsToFIRE: number;
  }) => {
    setEditingGoal(null);
    setGoalError(null);
    setGoalName('แผนอิสรภาพทางการเงินใหม่ (FIRE Goal)');
    setGoalTarget(prefill?.targetAmount ?? '12000000');
    setGoalCurrent(prefill?.currentAmount ?? '500000');
    setGoalMonthly(prefill?.monthlyContribution ?? '30000');
    setGoalReturnPct(
      prefill
        ? (Number(prefill.expectedReturn) * 100).toFixed(1)
        : '8.0'
    );
    setGoalCurrentAge(32);
    setGoalRetireAge(32 + (prefill?.yearsToFIRE ?? 18));
    setDialogOpen(true);
  };

  const openEditModal = (goal: FIREGoal) => {
    setEditingGoal(goal);
    setGoalError(null);
    setGoalName(goal.name);
    setGoalTarget(goal.targetAmount);
    setGoalCurrent(goal.currentAmount);
    setGoalMonthly(goal.monthlyContribution);
    setGoalReturnPct((Number(goal.expectedReturn) * 100).toFixed(1));
    setGoalCurrentAge(goal.currentAge);
    setGoalRetireAge(goal.retirementAge);
    setDialogOpen(true);
  };

  const handleGoalFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGoalError(null);

    if (!token) {
      setGoalError('กรุณาเข้าสู่ระบบเพื่อบันทึกเป้าหมายลงฐานข้อมูลจริง');
      return;
    }

    const yearsSpan = Math.max(1, goalRetireAge - goalCurrentAge);
    const targetYear = new Date().getFullYear() + yearsSpan;
    const payload: UpsertFireGoalPayload = {
      name: goalName.trim() || 'เป้าหมาย FIRE',
      targetAmount: goalTarget,
      currentAmount: goalCurrent || '0',
      monthlyContribution: goalMonthly || '0',
      expectedReturn: (Number(goalReturnPct || '8') / 100).toFixed(4),
      inflationRate: '0.03',
      targetYear,
      currentAge: goalCurrentAge,
      retirementAge: goalRetireAge,
    };

    try {
      if (editingGoal) {
        await updateGoalMutation.mutateAsync({ id: editingGoal.id, payload });
      } else {
        await createGoalMutation.mutateAsync(payload);
      }
      setDialogOpen(false);
    } catch (err) {
      setGoalError(extractApiErrorMessage(err, t('goalErrorFallback')));
    }
  };

  const handleRunSimulation = async (params: {
    currentAmount: string;
    monthlyContribution: string;
    expectedReturn: string;
    volatility: string;
    years: number;
    targetAmount: string;
  }) => {
    setCustomTargetTHB(params.targetAmount);
    if (!token) return;

    try {
      const mc = await monteCarloMutation.mutateAsync({
        currentAmount: params.currentAmount,
        monthlyContribution: params.monthlyContribution,
        expectedReturn: params.expectedReturn,
        volatility: params.volatility,
        years: params.years,
        numSimulations: 150,
        seed: `wealthos-${params.targetAmount}-${params.monthlyContribution}-${params.years}`,
        targetAmount: params.targetAmount,
      });
      setCustomMcResult(mc);
    } catch {
      // Errors handled gracefully by mutation state
    }
  };

  return (
    <div className="space-y-8">
      {/* Preview Mode Banner if not logged in */}
      {!token && (
        <div className="flex flex-col justify-between gap-3 rounded-2xl border border-emerald-200/70 bg-emerald-50/70 px-5 py-3.5 sm:flex-row sm:items-center dark:border-emerald-900/50 dark:bg-emerald-950/30">
          <div className="flex items-center gap-2.5 text-xs text-[#14342a] dark:text-emerald-200">
            <Sparkles className="h-4 w-4 shrink-0 text-[#059669] dark:text-[#4ade80]" />
            <span>
              <strong>{t('previewTitle')}</strong> {t('previewDescription')}
            </span>
          </div>
          <Link
            href="/login"
            className="inline-flex items-center justify-center gap-1.5 self-start rounded-xl bg-[#14342a] px-3.5 py-2 text-xs font-semibold text-white transition hover:bg-[#0f261e] sm:self-auto"
          >
            <LogIn className="h-3.5 w-3.5" />
            {t('loginDemo')}
          </Link>
        </div>
      )}

      {/* Inspirational Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
            {t('eyebrow')}
          </p>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
            {t('title')}
          </h1>
          <p className="mt-1 text-xs sm:text-sm leading-relaxed text-gray-500 dark:text-gray-400">
            {t('subtitle')}
          </p>
        </div>

        <motion.button
          type="button"
          whileTap={{ scale: 0.95 }}
          onClick={() => openCreateModal()}
          className="inline-flex items-center justify-center gap-2 self-start rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          {t('newGoalBtn')}
        </motion.button>
      </div>

      {/* Top 3 Minimalist KPI Summary Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
            <span>{t('kpiFireNumber')}</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#14342a]/5 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <Target className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-2.5 text-2xl sm:text-3xl font-bold tracking-tight text-[#14342a] tabular-nums dark:text-[#F5F5F5]">
            {formatTHB(activeSummary.fireNumber)}
          </p>
          <p className="mt-1 text-[11px] text-gray-500 tabular-nums dark:text-gray-400">
            {t('linkedPortfolio', { amount: formatTHB(activeSummary.currentPortfolioValueTHB) })}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
            <span>{t('yearsToFire')}</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#14342a]/5 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <Compass className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-2.5 text-2xl sm:text-3xl font-bold tracking-tight text-[#1A1A1A] tabular-nums dark:text-[#F5F5F5]">
            {t('yearsToFireValue', { count: activeSummary.yearsToFIRE })}
          </p>
          <p className="mt-1 text-[11px] text-gray-500 tabular-nums dark:text-gray-400">
            {t('monthlyContributionValue', { amount: formatTHB(activeSummary.monthlyContributionTHB) })}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
            <span>{t('onTrack')}</span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400">
              <TrendingUp className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-2.5 text-2xl sm:text-3xl font-bold tracking-tight text-[#059669] tabular-nums dark:text-emerald-400">
            {t('goalsCountValue', { onTrack: activeSummary.onTrackCount, total: activeSummary.goalsCount })}
          </p>
          <p className="mt-1 text-[11px] text-gray-500 tabular-nums dark:text-gray-400">
            {t('mcConfidenceValue', { percent: Math.round(displayedMc.successRate) })}
          </p>
        </div>
      </div>

      {/* Main 2-Column Grid (Desktop 2 Columns: Calculator + Monte Carlo Chart, Mobile 1 Column) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <FIRECalculator
            livePortfolioValueTHB={activeSummary.currentPortfolioValueTHB}
            isSimulating={monteCarloMutation.isPending}
            onRunSimulation={handleRunSimulation}
            onSaveAsGoal={(params) => openCreateModal(params)}
          />
        </div>

        <div className="lg:col-span-7">
          <MonteCarloChart
            result={displayedMc}
            targetAmountTHB={customTargetTHB ?? activeSummary.fireNumber}
            isLoading={monteCarloMutation.isPending}
          />
        </div>
      </div>

      {/* Financial Goals List Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
              {t('goalsTitle', { count: activeSummary.goals.length })}
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {t('goalSectionDescription')}
            </p>
          </div>

          <button
            type="button"
            onClick={() => openCreateModal()}
            className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl bg-gray-100 px-3.5 py-2 text-xs font-semibold text-gray-900 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-100 dark:hover:bg-gray-700"
          >
            <Plus className="h-3.5 w-3.5" />
            {t('addGoal')}
          </button>
        </div>

        {activeSummary.goals.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-200 bg-white p-10 text-center shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <Target className="mx-auto mb-3 h-10 w-10 text-[#14342a] dark:text-[#4ade80]" />
            <h3 className="text-base font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
              {t('emptyGoalsTitle')}
            </h3>
            <p className="mx-auto mt-1 max-w-md text-xs text-gray-500 dark:text-gray-400">
              {t('emptyGoalsDescription')}
            </p>
            <button
              type="button"
              onClick={() => openCreateModal()}
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-[#0f261e]"
            >
              <Plus className="h-4 w-4" />
              {t('createFirstGoal')}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {activeSummary.goals.map(({ goal, progress }) => (
              <GoalCard
                key={goal.id}
                goal={goal}
                progress={progress}
                onEdit={openEditModal}
                onDelete={(id) => deleteGoalMutation.mutate(id)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Create / Edit Goal Modal */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingGoal ? t('editGoalTitle') : t('newGoalTitle')}
            </DialogTitle>
            <DialogDescription>
              {t('goalAutoLinkDescription', { amount: formatTHB(activeSummary.currentPortfolioValueTHB) })}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleGoalFormSubmit} className="mt-2 space-y-4">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                {t('goalName')}
              </label>
              <input
                type="text"
                required
                value={goalName}
                onChange={(e) => setGoalName(e.target.value)}
                placeholder={t('goalNamePlaceholder')}
                className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-sm text-[#1A1A1A] focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('targetAmount')}
                </label>
                <input
                  type="number"
                  required
                  min="10000"
                  value={goalTarget}
                  onChange={(e) => setGoalTarget(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-sm tabular-nums text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('startingSavings')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={goalCurrent}
                  onChange={(e) => setGoalCurrent(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-sm tabular-nums text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('monthlyInvestmentInput')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={goalMonthly}
                  onChange={(e) => setGoalMonthly(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-sm tabular-nums text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('expectedReturnInput')}
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={goalReturnPct}
                  onChange={(e) => setGoalReturnPct(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-sm tabular-nums text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('currentAge')}
                </label>
                <input
                  type="number"
                  min="18"
                  max="95"
                  value={goalCurrentAge}
                  onChange={(e) => setGoalCurrentAge(Number(e.target.value) || 30)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-sm tabular-nums text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('retirementAge')}
                </label>
                <input
                  type="number"
                  min="20"
                  max="100"
                  value={goalRetireAge}
                  onChange={(e) => setGoalRetireAge(Number(e.target.value) || 50)}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-sm tabular-nums text-[#1A1A1A] focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                />
              </div>
            </div>

            {goalError && <p className="text-xs text-[#DC2626]">{goalError}</p>}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDialogOpen(false)}
                className="rounded-xl bg-gray-100 px-4 py-2 text-xs font-semibold text-gray-900 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-100"
              >
                {t('cancel')}
              </button>
              <button
                type="submit"
                disabled={createGoalMutation.isPending || updateGoalMutation.isPending}
                className="rounded-xl bg-[#14342a] px-5 py-2 text-xs font-semibold text-white hover:bg-[#0f261e] disabled:opacity-50"
              >
                {editingGoal ? t('saveChanges') : t('createGoal')}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default FIRESummaryDashboard;
