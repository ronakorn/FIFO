'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import { useTheme } from 'next-themes';
import { useTranslations } from 'next-intl';
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { CheckCircle2, AlertTriangle, Sparkles } from 'lucide-react';
import { MonteCarloResult } from '@/types/fire';
import { cn, formatTHB } from '@/lib/utils';

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

interface MonteCarloChartProps {
  result: MonteCarloResult;
  targetAmountTHB?: string;
  isLoading?: boolean;
}

export function MonteCarloChart({
  result,
  targetAmountTHB,
  isLoading = false,
}: MonteCarloChartProps) {
  const t = useTranslations('fire');
  const [mounted, setMounted] = useState(false);
  const { resolvedTheme } = useTheme();

  useEffect(() => {
    setMounted(true);
  }, []);

  const isDark = resolvedTheme === 'dark';

  // Cap rendered background paths at 120 so 100+ individual trajectories render smoothly
  const sampleSimulations = useMemo(
    () => result.simulations.slice(0, 120),
    [result.simulations]
  );

  const chartData = useMemo(() => {
    const firstSim = sampleSimulations[0];
    if (!firstSim || firstSim.length === 0) return [];

    return firstSim.map((pt, stepIdx) => {
      const row: Record<string, number> = {
        year: pt.year,
      };

      // Populate 100+ simulation trajectories from exact Decimal strings
      sampleSimulations.forEach((simPath, simIdx) => {
        const valStr = simPath[stepIdx]?.value ?? '0';
        row[`s${simIdx}`] = new Dec(valStr).toNumber();
      });

      // Populate P10, Median, and P90 curves
      const pctPoint = result.percentileSeries?.[stepIdx];
      if (pctPoint) {
        row['p10'] = new Dec(pctPoint.p10).toNumber();
        row['median'] = new Dec(pctPoint.median).toNumber();
        row['p90'] = new Dec(pctPoint.p90).toNumber();
      } else {
        const sorted = sampleSimulations
          .map((s) => new Dec(s[stepIdx]?.value ?? '0'))
          .sort((a, b) => a.comparedTo(b));
        row['p10'] = (sorted[Math.floor(sorted.length * 0.1)] ?? new Dec(0)).toNumber();
        row['median'] = (
          sorted[Math.floor(sorted.length * 0.5)] ?? new Dec(0)
        ).toNumber();
        row['p90'] = (sorted[Math.floor(sorted.length * 0.9)] ?? new Dec(0)).toNumber();
      }

      return row;
    });
  }, [sampleSimulations, result.percentileSeries]);

  const effectiveTarget = targetAmountTHB ?? result.targetAmount;
  const targetNum = effectiveTarget ? new Dec(effectiveTarget).toNumber() : null;

  const successRateRounded = Math.round(result.successRate);
  const isStrongSuccess = result.successRate >= 75;
  const isModerateSuccess = result.successRate >= 50 && result.successRate < 75;

  const medianColor = isDark ? '#4ade80' : '#14342a';
  const simPathColor = isDark ? '#4ade80' : '#14342a';
  const gridColor = isDark ? 'rgba(55, 65, 81, 0.35)' : 'rgba(229, 231, 235, 0.5)';

  if (isLoading || !mounted) {
    return (
      <div className="flex h-full min-h-[440px] animate-pulse flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <div className="h-5 w-56 rounded bg-gray-200 dark:bg-gray-700" />
            <div className="h-3.5 w-40 rounded bg-gray-100 dark:bg-gray-800" />
          </div>
          <div className="h-11 w-36 rounded-2xl bg-gray-100 dark:bg-gray-800" />
        </div>
        <div className="mt-6 h-80 w-full rounded-xl bg-gray-50 dark:bg-[#121212]" />
      </div>
    );
  }

  return (
    <div
      data-testid="monte-carlo-card"
      className="flex h-full flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      {/* Top Header + Large Prominent Success Rate Badge */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="inline-flex items-center gap-1.5 rounded-full bg-[#14342a]/5 px-2.5 py-1 text-[11px] font-semibold text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
            <Sparkles className="h-3.5 w-3.5" />
            {t('monteCarloEngine', { count: result.simulations.length })}
          </div>
          <h2 className="mt-2 text-lg font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
            {t('monteCarloTitle')}
          </h2>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
            {t('monteCarloSubtitle')}
          </p>
        </div>

        {/* Large Success Rate Badge (Close-up target for 16-fire-success-badge.png) */}
        <div
          id="fire-success-badge"
          data-testid="fire-success-badge"
          className={cn(
            'inline-flex items-center gap-3 self-start rounded-2xl border px-4 py-3 shadow-sm',
            isStrongSuccess
              ? 'border-[#059669]/25 bg-[#059669]/10 text-[#059669] dark:border-emerald-500/30 dark:bg-emerald-950/60 dark:text-emerald-400'
              : isModerateSuccess
                ? 'border-amber-500/30 bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300'
                : 'border-[#DC2626]/25 bg-red-50 text-[#DC2626] dark:bg-red-950/50 dark:text-rose-400'
          )}
        >
          {isStrongSuccess ? (
            <CheckCircle2 className="h-6 w-6 shrink-0" />
          ) : (
            <AlertTriangle className="h-6 w-6 shrink-0" />
          )}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wider opacity-80">
              {t('fireSuccessChance')}
            </p>
            <p className="text-xl font-bold leading-tight tracking-tight tabular-nums">
              {t('successPercent', { percent: successRateRounded })}
            </p>
          </div>
        </div>
      </div>

      {/* Percentile Crossing Year Milestones */}
      <div className="mt-4 grid grid-cols-3 gap-2.5">
        <div className="rounded-xl border border-emerald-100 bg-emerald-50/50 px-3 py-2 dark:border-emerald-900/40 dark:bg-emerald-950/20">
          <p className="text-[10px] font-semibold text-[#059669] dark:text-emerald-400">
            {t('bullMarketP90')}
          </p>
          <p className="mt-0.5 text-sm font-bold text-[#1A1A1A] tabular-nums dark:text-[#F5F5F5]">
            {t('yearLabel', { year: result.p90Year })}
          </p>
        </div>

        <div className="rounded-xl border border-[#14342a]/15 bg-[#14342a]/5 px-3 py-2 dark:border-[#4ade80]/20 dark:bg-[#4ade80]/10">
          <p className="text-[10px] font-semibold text-[#14342a] dark:text-[#4ade80]">
            {t('medianLabel')}
          </p>
          <p className="mt-0.5 text-sm font-bold text-[#14342a] tabular-nums dark:text-[#4ade80]">
            {t('yearLabel', { year: result.medianYear })}
          </p>
        </div>

        <div className="rounded-xl border border-red-100 bg-red-50/50 px-3 py-2 dark:border-red-900/40 dark:bg-red-950/20">
          <p className="text-[10px] font-semibold text-[#DC2626] dark:text-rose-400">
            {t('volatileMarketP10')}
          </p>
          <p className="mt-0.5 text-sm font-bold text-[#1A1A1A] tabular-nums dark:text-[#F5F5F5]">
            {t('yearLabel', { year: result.p10Year })}
          </p>
        </div>
      </div>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap items-center gap-4 text-[11px]">
        <span className="inline-flex items-center gap-1.5 font-bold text-[#14342a] dark:text-[#4ade80]">
          <span
            className="h-1 w-5 rounded-full"
            style={{ backgroundColor: medianColor }}
          />
          {t('medianLabel')}
        </span>
        <span className="inline-flex items-center gap-1.5 font-medium text-[#059669] dark:text-emerald-400">
          <span className="w-4 border-t-2 border-dashed border-[#059669]" />
          {t('optimisticP90')}
        </span>
        <span className="inline-flex items-center gap-1.5 font-medium text-[#DC2626] dark:text-rose-400">
          <span className="w-4 border-t-2 border-dashed border-[#DC2626]" />
          {t('conservativeP10')}
        </span>
        <span className="inline-flex items-center gap-1.5 text-gray-400">
          <span
            className="h-0.5 w-4 rounded-full opacity-35"
            style={{ backgroundColor: simPathColor }}
          />
          {t('simulationPaths', { count: sampleSimulations.length })}
        </span>
      </div>

      {/* Recharts Multi-Line Chart (100+ Paths + Median 3px + P10/P90 Dashed 1px) */}
      <div className="mt-3 h-72 sm:h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 14, left: 4, bottom: 0 }}>
            <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
            <XAxis
              dataKey="year"
              stroke={isDark ? '#9CA3AF' : '#6B7280'}
              fontSize={11}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              stroke={isDark ? '#9CA3AF' : '#6B7280'}
              fontSize={11}
              tickLine={false}
              axisLine={false}
              width={66}
              tickFormatter={(val: number) => {
                if (val >= 1_000_000) return `฿${(val / 1_000_000).toFixed(1)}M`;
                if (val >= 1_000) return `฿${Math.round(val / 1_000)}k`;
                return `฿${val}`;
              }}
            />
            <Tooltip
              content={({ active, payload, label }) => {
                if (!active || !payload || payload.length === 0) return null;
                const row = payload[0]?.payload as Record<string, number> | undefined;
                if (!row) return null;
                return (
                  <div className="rounded-xl border border-gray-200 bg-white p-3 text-xs shadow-lg dark:border-gray-700 dark:bg-[#121212]">
                    <p className="font-bold text-[#1A1A1A] tabular-nums dark:text-[#F5F5F5]">
                      ปี ค.ศ. {label} (พ.ศ. {Number(label) + 543})
                    </p>
                    <div className="mt-2 space-y-1 tabular-nums">
                      <p className="flex items-center justify-between gap-4 font-semibold text-[#059669] dark:text-emerald-400">
                        <span>P90 (ตลาดดี):</span>
                        <span>{formatTHB(row['p90'] ?? 0)}</span>
                      </p>
                      <p className="flex items-center justify-between gap-4 font-bold text-[#14342a] dark:text-[#4ade80]">
                        <span>Median (P50):</span>
                        <span>{formatTHB(row['median'] ?? 0)}</span>
                      </p>
                      <p className="flex items-center justify-between gap-4 font-semibold text-[#DC2626] dark:text-rose-400">
                        <span>P10 (ตลาดแย่):</span>
                        <span>{formatTHB(row['p10'] ?? 0)}</span>
                      </p>
                    </div>
                  </div>
                );
              }}
            />

            {/* 100+ Background GBM Simulation Trajectories */}
            {sampleSimulations.map((_sim, idx) => (
              <Line
                key={`sim-path-${idx}`}
                type="monotone"
                dataKey={`s${idx}`}
                stroke={simPathColor}
                strokeWidth={1}
                strokeOpacity={isDark ? 0.09 : 0.06}
                dot={false}
                activeDot={false}
                isAnimationActive={false}
              />
            ))}

            {/* Optional FIRE Target Horizontal Reference Line */}
            {targetNum && targetNum > 0 && (
              <ReferenceLine
                y={targetNum}
                stroke={isDark ? '#9CA3AF' : '#64748B'}
                strokeDasharray="3 3"
                strokeWidth={1}
              />
            )}

            {/* P90 Optimistic Dashed Curve (#059669, 1px dashed) */}
            <Line
              type="monotone"
              dataKey="p90"
              stroke="#059669"
              strokeWidth={1.25}
              strokeDasharray="4 4"
              dot={false}
              isAnimationActive={false}
            />

            {/* P10 Conservative Dashed Curve (#DC2626, 1px dashed) */}
            <Line
              type="monotone"
              dataKey="p10"
              stroke="#DC2626"
              strokeWidth={1.25}
              strokeDasharray="4 4"
              dot={false}
              isAnimationActive={false}
            />

            {/* Median Curve (#14342a Light / #4ade80 Dark, 3px bold) */}
            <Line
              type="monotone"
              dataKey="median"
              stroke={medianColor}
              strokeWidth={3}
              dot={false}
              activeDot={{ r: 5 }}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default MonteCarloChart;
