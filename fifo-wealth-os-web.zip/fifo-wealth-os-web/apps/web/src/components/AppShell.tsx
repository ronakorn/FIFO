'use client';

import React from 'react';
import { motion } from 'framer-motion';
import {
  Activity,
  BookOpen,
  Bot,
  Calculator,
  CircleDollarSign,
  CalendarRange,
  Coins,
  Compass,
  LayoutDashboard,
  Layers,
  LogIn,
  LogOut,
  Gauge,
  PieChart,
  ShieldAlert,
  Target,
  UploadCloud,
  User as UserIcon,
  Users,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Link, usePathname, useRouter } from '@/navigation';
import { AIChatDrawer } from '@/components/ai/AIChatDrawer';
import { LanguageSwitcher } from '@/components/layout/LanguageSwitcher';
import { ThemeToggle } from '@/components/layout/ThemeToggle';
import { OnboardingWalkthrough } from '@/components/ux/OnboardingWalkthrough';
import { usePortfolios } from '@/lib/queries';
import { useAssistantStore, useAuthStore, usePortfolioStore } from '@/lib/stores';
import { cn } from '@/lib/utils';

export function AppShell({ children }: { children: React.ReactNode }) {
  const tNav = useTranslations('nav');
  const tHeader = useTranslations('header');
  const tFooter = useTranslations('footer');

  const pathname = usePathname();
  const router = useRouter();

  const user = useAuthStore((s) => s.user);
  const token = useAuthStore((s) => s.token);
  const logout = useAuthStore((s) => s.logout);

  const openChat = useAssistantStore((s) => s.openChat);
  const openOnboarding = useAssistantStore((s) => s.openOnboarding);

  const selectedPortfolioId = usePortfolioStore((s) => s.selectedPortfolioId);
  const selectedTaxYear = usePortfolioStore((s) => s.selectedTaxYear);
  const { data: portfolios } = usePortfolios();

  const activePortfolioId =
    selectedPortfolioId ?? portfolios?.[0]?.id ?? 'mock-portfolio-ibkr';
  const taxHref = `/tax/${activePortfolioId}/${selectedTaxYear}`;

  const sidebarItems = [
    { href: '/', label: tNav('overview'), icon: LayoutDashboard, matchPrefix: '/' },
    { href: '/portfolios', label: tNav('portfolios'), icon: PieChart, matchPrefix: '/portfolios' },
    { href: '/multi-assets', label: tNav('multiAsset'), icon: Layers, matchPrefix: '/multi-assets' },
    { href: '/advanced-assets', label: tNav('advancedAssets'), icon: Gauge, matchPrefix: '/advanced-assets' },
    { href: '/gold', label: tNav('gold'), icon: Coins, matchPrefix: '/gold' },
    { href: '/fire', label: tNav('fire'), icon: Target, matchPrefix: '/fire' },
    { href: '/journal', label: tNav('journal'), icon: BookOpen, matchPrefix: '/journal' },
    { href: '/family', label: tNav('family'), icon: Users, matchPrefix: '/family' },
    { href: '/planning', label: tNav('planning'), icon: CalendarRange, matchPrefix: '/planning' },
    { href: '/upload', label: tNav('upload'), icon: UploadCloud, matchPrefix: '/upload' },
    { href: taxHref, label: tNav('tax'), icon: Calculator, matchPrefix: '/tax' },
    { href: '/admin/audit-logs', label: tNav('auditLogs'), icon: ShieldAlert, matchPrefix: '/admin/audit-logs' },
    { href: '/pricing', label: tNav('pricing'), icon: CircleDollarSign, matchPrefix: '/pricing' },
    { href: '/profile', label: tNav('profile'), icon: UserIcon, matchPrefix: '/profile' },
  ];

  const isAuthPage = pathname === '/login' || pathname === '/register';

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  if (isAuthPage) {
    return (
      <div className="min-h-screen bg-[#FAFAFA] text-[#1A1A1A] dark:bg-[#121212] dark:text-[#F5F5F5]">
        <div className="fixed right-4 top-4 z-40 flex items-center gap-2">
          <LanguageSwitcher />
          <ThemeToggle />
        </div>
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-[#1A1A1A] transition-colors dark:bg-[#121212] dark:text-[#F5F5F5]">
      {/* Desktop Clean Minimalist Sidebar (hidden on mobile < md) */}
      <aside
        aria-label={tNav('desktopSidebar')}
        data-testid="desktop-sidebar"
        className="hidden md:fixed md:inset-y-0 md:left-0 md:z-40 md:flex md:w-64 md:flex-col md:justify-between md:border-r md:border-gray-200/80 md:bg-white md:px-4 md:py-6 dark:md:border-gray-800 dark:md:bg-[#1E1E1E]"
      >
        <div className="space-y-6">
          {/* Brand Logo */}
          <Link href="/" className="group flex items-center gap-3 px-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#14342a] text-white shadow-sm transition group-hover:scale-105">
              <Activity className="h-5 w-5 stroke-[2.5]" />
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                FIFO Wealth OS
              </span>
              <p className="text-[11px] text-gray-500 dark:text-gray-400">
                {tNav('brandSubtitle')}
              </p>
            </div>
          </Link>

          {/* Navigation Menu */}
          <nav aria-label={tNav('primaryNavigation')} className="space-y-1">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const isActive =
                item.matchPrefix === '/'
                  ? pathname === '/'
                  : pathname.startsWith(item.matchPrefix);

              return (
                <Link
                  key={item.matchPrefix}
                  href={item.href}
                  aria-current={isActive ? 'page' : undefined}
                  className={cn(
                    'flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-xs font-semibold transition-all',
                    isActive
                      ? 'bg-[#14342a] text-white shadow-sm dark:bg-[#14342a] dark:text-[#4ade80] dark:ring-1 dark:ring-emerald-700/60'
                      : 'text-gray-600 hover:bg-gray-100/80 hover:text-[#1A1A1A] dark:text-gray-400 dark:hover:bg-[#121212] dark:hover:text-[#F5F5F5]'
                  )}
                >
                  <Icon
                    className={cn(
                      'h-4 w-4 shrink-0',
                      isActive ? 'stroke-[2.4]' : 'stroke-[1.9]'
                    )}
                  />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Bottom Sidebar Controls: Live Status + Theme Toggle + User Card */}
        <div className="space-y-3 border-t border-gray-100 pt-4 dark:border-gray-800">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-1.5 rounded-full border border-gray-200 bg-gray-50 px-2.5 py-1 text-[11px] font-medium text-gray-600 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-300">
              <span
                className={cn(
                  'h-1.5 w-1.5 rounded-full',
                  token ? 'bg-[#059669]' : 'bg-amber-500'
                )}
              />
              <span>{token ? tNav('connected') : tNav('preview')}</span>
            </div>
            <ThemeToggle />
          </div>

          {token && user ? (
            <div className="rounded-xl border border-gray-100 bg-gray-50/80 p-3 dark:border-gray-800 dark:bg-[#121212]">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#14342a] text-xs font-bold text-white dark:text-[#4ade80]">
                  {user.name.slice(0, 1).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                    {user.name}
                  </p>
                  <p className="truncate text-[11px] text-gray-500 dark:text-gray-400">
                    {user.email}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleLogout}
                  title={tNav('logout')}
                  className="rounded-lg p-1.5 text-gray-400 transition hover:bg-red-50 hover:text-[#DC2626] dark:hover:bg-red-950/40 dark:hover:text-rose-400"
                >
                  <LogOut className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <Link
              href="/login"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2.5 text-xs font-semibold text-white transition hover:bg-[#0f261e]"
            >
              <LogIn className="h-3.5 w-3.5" />
              {tNav('loginDemo')}
            </Link>
          )}
        </div>
      </aside>

      {/* Main Content Container (offset by md:pl-64 on Desktop, pb-28 on Mobile for BottomNav) */}
      <div className="md:pl-64">
        {/* Clean Minimalist Top Bar (Mobile Brand + Top-Right Language Switcher, Tour & AI Assistant) */}
        <header className="sticky top-0 z-30 border-b border-gray-200/70 bg-white/85 backdrop-blur-md dark:border-gray-800/80 dark:bg-[#121212]/85">
          <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-2 px-4 sm:px-6 lg:px-8">
            {/* Mobile Brand (hidden on Desktop where Sidebar shows Brand) */}
            <Link href="/" className="flex shrink-0 items-center gap-2 md:hidden">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[#14342a] text-white shadow-sm">
                <Activity className="h-4 w-4 stroke-[2.5]" />
              </div>
              <span className="whitespace-nowrap text-xs font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5] sm:text-sm">
                Wealth OS
              </span>
            </Link>

            <div className="hidden md:block" />

            {/* Top-Right Utility Controls: Quick Tour, AI Assistant, LanguageSwitcher, Mobile ThemeToggle */}
            <div className="flex items-center gap-2">
              <motion.button
                type="button"
                whileTap={{ scale: 0.95 }}
                data-testid="open-onboarding-btn"
                onClick={openOnboarding}
                className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-2.5 py-1.5 text-[11px] font-semibold text-gray-700 shadow-sm transition hover:bg-gray-50 dark:border-gray-700 dark:bg-[#1E1E1E] dark:text-gray-200"
              >
                <Compass className="h-3.5 w-3.5 text-[#14342a] dark:text-[#4ade80]" />
                <span className="hidden sm:inline">{tHeader('tourButton')}</span>
              </motion.button>

              <motion.button
                type="button"
                whileTap={{ scale: 0.95 }}
                data-testid="open-ai-drawer-btn"
                onClick={openChat}
                className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl bg-[#14342a] px-3 py-1.5 text-[11px] font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
              >
                <Bot className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">{tHeader('aiButton')}</span>
                <span className="sm:hidden">AI</span>
              </motion.button>

              <LanguageSwitcher />

              <div className="md:hidden">
                <ThemeToggle />
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-6 md:pb-12 md:pt-8 lg:px-8">
          {children}
        </main>

        <footer className="hidden border-t border-gray-200/60 py-6 text-xs text-gray-400 dark:border-gray-800/80 dark:text-gray-500 md:block">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
            <span>{tFooter('productLine')}</span>
            <span>{tFooter('integrations')}</span>
          </div>
        </footer>
      </div>

      {/* Global Slide-in AI Wealth Assistant & 3-Step Onboarding Walkthrough */}
      <AIChatDrawer />
      <OnboardingWalkthrough />
    </div>
  );
}

export default AppShell;
