'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import { ShieldCheck } from 'lucide-react';

export function LegalDisclaimer({ className = '' }: { className?: string }) {
  const t = useTranslations('legal');
  return (
    <aside
      aria-label={t('ariaLabel')}
      className={`rounded-2xl border border-gray-200/80 bg-gray-50/80 px-4 py-3 text-[11px] leading-relaxed text-gray-500 dark:border-gray-800 dark:bg-[#16191D] dark:text-gray-400 ${className}`}
    >
      <div className="flex items-start gap-2.5">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-gray-400 dark:text-gray-500" aria-hidden="true" />
        <div>
          <p className="font-semibold text-gray-600 dark:text-gray-300">{t('title')}</p>
          <p className="mt-0.5">
            {t('paragraph1')}
          </p>
          <p className="mt-1">
            {t('paragraph2')}
          </p>
        </div>
      </div>
    </aside>
  );
}

export default LegalDisclaimer;
