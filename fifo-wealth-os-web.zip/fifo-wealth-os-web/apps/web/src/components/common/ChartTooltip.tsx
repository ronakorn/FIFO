'use client';

import React from 'react';
import { useTheme } from 'next-themes';
import type {
  NameType,
  Payload,
  ValueType,
} from 'recharts/types/component/DefaultTooltipContent';

export interface ChartTooltipRow {
  label: React.ReactNode;
  value: React.ReactNode;
  detail?: React.ReactNode;
}

export type ChartTooltipFormatter = (
  value: ValueType | undefined,
  name: NameType | undefined,
) => ChartTooltipRow;

interface ChartTooltipProps {
  active?: boolean;
  label?: React.ReactNode;
  payload?: ReadonlyArray<Payload<ValueType, NameType>>;
  formatter?: ChartTooltipFormatter;
  labelFormatter?: (label: React.ReactNode) => React.ReactNode;
}

function formatValue(value: ValueType | undefined): string {
  if (value === undefined) return '—';
  return Array.isArray(value) ? value.map(String).join(', ') : String(value);
}

export function ChartTooltip({
  active,
  label,
  payload,
  formatter,
  labelFormatter,
}: ChartTooltipProps) {
  const { resolvedTheme } = useTheme();
  const visibleItems = payload?.filter((item) => item.value !== undefined && !item.hide) ?? [];

  if (!active || visibleItems.length === 0) return null;

  const isDark = resolvedTheme === 'dark';
  const surfaceStyle: React.CSSProperties = {
    minWidth: 148,
    maxWidth: 280,
    border: `1px solid ${isDark ? '#365447' : '#dce6df'}`,
    borderRadius: 14,
    backgroundColor: isDark ? '#111b17' : '#ffffff',
    color: isDark ? '#f3f7f4' : '#1b2e24',
    boxShadow: isDark
      ? '0 12px 30px rgba(0, 0, 0, 0.42)'
      : '0 12px 30px rgba(20, 52, 42, 0.14)',
    padding: '10px 12px',
    fontSize: 12,
    lineHeight: 1.45,
    pointerEvents: 'none',
  };

  return (
    <div role="status" aria-live="polite" style={surfaceStyle}>
      {label !== undefined && label !== null && (
        <p
          style={{
            margin: '0 0 7px',
            paddingBottom: 6,
            borderBottom: `1px solid ${isDark ? '#293b32' : '#edf1ee'}`,
            color: isDark ? '#c7d8ce' : '#52655a',
            fontWeight: 700,
          }}
        >
          {labelFormatter ? labelFormatter(label) : label}
        </p>
      )}
      <div style={{ display: 'grid', gap: 6 }}>
        {visibleItems.map((item, index) => {
          const row = formatter
            ? formatter(item.value, item.name)
            : {
                label: item.name ?? item.dataKey?.toString() ?? '',
                value: formatValue(item.value),
              };
          const markerColor = item.color ?? item.stroke ?? (isDark ? '#4ade80' : '#14342a');
          const rowKey = String(item.dataKey ?? item.name ?? 'value');

          return (
            <div
              key={`${rowKey}-${index}`}
              style={{
                display: 'grid',
                gridTemplateColumns: 'minmax(0, 1fr) auto',
                columnGap: 12,
                alignItems: 'start',
              }}
            >
              <span style={{ display: 'inline-flex', minWidth: 0, alignItems: 'center', gap: 7 }}>
                <span
                  aria-hidden="true"
                  style={{
                    width: 7,
                    height: 7,
                    flex: '0 0 auto',
                    borderRadius: '50%',
                    backgroundColor: markerColor,
                  }}
                />
                <span style={{ overflowWrap: 'anywhere', color: isDark ? '#d8e4dc' : '#465a4e' }}>
                  {row.label}
                </span>
              </span>
              <strong style={{ color: isDark ? '#f3f7f4' : '#173528', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>
                {row.value}
              </strong>
              {row.detail !== undefined && (
                <span
                  style={{
                    gridColumn: '1 / -1',
                    marginLeft: 14,
                    color: isDark ? '#9db2a4' : '#77867d',
                    fontSize: 11,
                  }}
                >
                  {row.detail}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default ChartTooltip;
