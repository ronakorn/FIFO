'use client';

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Pause,
  Play,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import {
  fetchLatestMarketPrices,
  INITIAL_MOCK_TICKERS,
  TickerDecimal,
  TickerItem,
  TickerCategory,
} from '@/data/mockTickerData';
import { useLocale, useTranslations } from 'next-intl';
import { cn } from '@/lib/utils';

type TickerTranslationKey =
  | 'allAssets'
  | 'thaiEquities'
  | 'usStocks'
  | 'gold'
  | 'crypto'
  | 'categoryThaiStock'
  | 'categoryUsStock'
  | 'categoryGold'
  | 'categoryCrypto';

const CATEGORY_FILTERS: Array<{
  id: 'ALL' | TickerCategory;
  labelKey: TickerTranslationKey;
}> = [
  { id: 'ALL', labelKey: 'allAssets' },
  { id: 'TH_STOCK', labelKey: 'thaiEquities' },
  { id: 'US_STOCK', labelKey: 'usStocks' },
  { id: 'GOLD', labelKey: 'gold' },
  { id: 'CRYPTO', labelKey: 'crypto' },
];

const CATEGORY_LABEL_KEYS: Record<TickerCategory, TickerTranslationKey> = {
  TH_STOCK: 'categoryThaiStock',
  US_STOCK: 'categoryUsStock',
  GOLD: 'categoryGold',
  CRYPTO: 'categoryCrypto',
};

const CURRENCY_SYMBOL: Record<TickerItem['currency'], string> = {
  THB: '฿',
  USD: '$',
};

const MIN_REFRESH_INDICATOR_MS = 850;
const AUTO_SCROLL_PIXELS_PER_SECOND = 24;

export interface MultiAssetTickerBarProps {
  items?: TickerItem[];
  onPriceUpdate?: (updatedTickers: TickerItem[]) => void;
  /** Injectable fetcher keeps the bar easy to test and lets the Dashboard own the feed. */
  fetchPrices?: typeof fetchLatestMarketPrices;
}

function formatPrice(item: TickerItem): string {
  const formatted = new TickerDecimal(item.price).toFixed(item.displayDecimals);
  const [wholePart = '0', fraction = ''] = formatted.split('.');
  const groupedWhole = wholePart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${CURRENCY_SYMBOL[item.currency]}${
    item.displayDecimals > 0 ? `${groupedWhole}.${fraction}` : groupedWhole
  }`;
}

function formatChange(changePct: string): string {
  const value = new TickerDecimal(changePct).toDecimalPlaces(2);
  return `${value.gte(0) ? '+' : ''}${value.toFixed(2)}%`;
}

function AssetMark({ category }: { category: TickerCategory }) {
  const mark =
    category === 'TH_STOCK'
      ? 'TH'
      : category === 'US_STOCK'
        ? 'US'
        : category === 'GOLD'
          ? 'Au'
          : '₿';

  return (
    <span
      className={cn(
        'flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-[11px] font-extrabold',
        category === 'TH_STOCK' && 'bg-[#14342a]/[0.07] text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]',
        category === 'US_STOCK' && 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300',
        category === 'GOLD' && 'bg-amber-50 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300',
        category === 'CRYPTO' && 'bg-violet-50 text-violet-700 dark:bg-violet-950/50 dark:text-violet-300'
      )}
      aria-hidden="true"
    >
      {mark}
    </span>
  );
}

export function MultiAssetTickerBar({
  items = INITIAL_MOCK_TICKERS,
  onPriceUpdate,
  fetchPrices = fetchLatestMarketPrices,
}: MultiAssetTickerBarProps) {
  const t = useTranslations('multiAsset.ticker');
  const locale = useLocale() as 'th' | 'en';
  const [uncontrolledItems, setUncontrolledItems] = useState<TickerItem[]>(items);
  const [activeCategory, setActiveCategory] = useState<'ALL' | TickerCategory>('ALL');
  const [isAutoScrolling, setIsAutoScrolling] = useState(true);
  const [isHovering, setIsHovering] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdatedAt, setLastUpdatedAt] = useState<Date | null>(null);
  const [refreshError, setRefreshError] = useState<string | null>(null);
  const scrollTrackRef = useRef<HTMLDivElement | null>(null);

  // The parent owns the feed when a price callback is supplied; otherwise the bar is self-contained.
  const sourceItems = onPriceUpdate ? items : uncontrolledItems;

  useEffect(() => {
    if (!onPriceUpdate) setUncontrolledItems(items);
  }, [items, onPriceUpdate]);

  const filteredItems = useMemo(
    () =>
      activeCategory === 'ALL'
        ? sourceItems
        : sourceItems.filter((item) => item.category === activeCategory),
    [activeCategory, sourceItems]
  );

  const handleRefresh = useCallback(async () => {
    if (isRefreshing) return;
    const startedAt = Date.now();
    setIsRefreshing(true);
    setRefreshError(null);

    try {
      const updatedData = await fetchPrices(sourceItems);
      if (onPriceUpdate) {
        onPriceUpdate(updatedData);
      } else {
        setUncontrolledItems(updatedData);
      }
      setLastUpdatedAt(new Date());
    } catch {
      setRefreshError(t('priceFetchError'));
    } finally {
      // Keep the spinner visible long enough for the parent Tax-Loss panel to finish propagating state.
      const remaining = MIN_REFRESH_INDICATOR_MS - (Date.now() - startedAt);
      if (remaining > 0) {
        await new Promise<void>((resolve) => setTimeout(resolve, remaining));
      }
      setIsRefreshing(false);
    }
  }, [fetchPrices, isRefreshing, onPriceUpdate, sourceItems, t]);

  // Smooth 60fps ticker motion. Hover pauses the animation; no interval or CSS-only scrolling.
  useEffect(() => {
    let animationFrame = 0;
    let previousFrameAt = 0;
    let scrollRemainder = 0;

    const animate = (timestamp: number) => {
      if (!previousFrameAt) previousFrameAt = timestamp;
      const elapsedMs = Math.min(timestamp - previousFrameAt, 64);
      previousFrameAt = timestamp;

      const track = scrollTrackRef.current;
      if (
        track &&
        isAutoScrolling &&
        !isHovering &&
        track.scrollWidth > track.clientWidth + 2
      ) {
        const maxScroll = track.scrollWidth - track.clientWidth;
        scrollRemainder += (AUTO_SCROLL_PIXELS_PER_SECOND * elapsedMs) / 1000;
        const wholePixelStep = Math.floor(scrollRemainder);
        if (wholePixelStep > 0) {
          track.scrollLeft += wholePixelStep;
          scrollRemainder -= wholePixelStep;
        }
        if (track.scrollLeft >= maxScroll - 1) {
          track.scrollLeft = 0;
          scrollRemainder = 0;
        }
      }

      animationFrame = window.requestAnimationFrame(animate);
    };

    animationFrame = window.requestAnimationFrame(animate);
    return () => window.cancelAnimationFrame(animationFrame);
  }, [activeCategory, filteredItems.length, isAutoScrolling, isHovering]);

  useEffect(() => {
    if (scrollTrackRef.current) scrollTrackRef.current.scrollLeft = 0;
  }, [activeCategory]);

  const handleMouseEnter = () => {
    setIsHovering(true);
  };
  const handleMouseLeave = () => {
    setIsHovering(false);
  };

  return (
    <section
      data-testid="multi-asset-ticker-bar"
      data-autoscrolling={isAutoScrolling}
      data-hovering={isHovering}
      aria-label={t('sectionAria')}
      className="overflow-hidden rounded-2xl border border-gray-200/90 bg-white shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      <div className="flex flex-col gap-3 border-b border-gray-100 px-4 py-4 dark:border-gray-800 sm:px-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#14342a] text-white shadow-sm">
            <Activity className="h-5 w-5" />
          </span>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-sm font-bold tracking-tight text-gray-900 dark:text-gray-100 sm:text-base">
                {t('title')}
              </h2>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-[#059669] dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-300">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#059669]" />
                {t('simulatedFeed')}
              </span>
            </div>
            <p className="mt-0.5 text-[11px] text-gray-500 dark:text-gray-400">
              {t('description')}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="mr-1 text-[10px] text-gray-400 tabular-nums">
            {lastUpdatedAt
              ? t('updatedAt', { time: lastUpdatedAt.toLocaleTimeString(locale === 'th' ? 'th-TH' : 'en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) })
              : t('demoPrices')}
          </span>
          <button
            type="button"
            data-testid="ticker-autoscroll-toggle"
            aria-label={isAutoScrolling ? 'หยุด Auto-Scroll' : 'เริ่ม Auto-Scroll'}
            aria-pressed={isAutoScrolling}
            onClick={() => setIsAutoScrolling((current) => !current)}
            className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-3 py-2 text-[11px] font-semibold text-gray-700 shadow-sm transition hover:border-[#14342a]/30 hover:text-[#14342a] dark:border-gray-700 dark:bg-[#151719] dark:text-gray-200 dark:hover:text-[#4ade80]"
          >
            {isAutoScrolling ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
            {isAutoScrolling ? t('autoScrollOn') : t('autoScrollOff')}
          </button>
          <button
            type="button"
            data-testid="ticker-refresh-btn"
            aria-label={isRefreshing ? t('refreshing') : t('refreshPrices')}
            disabled={isRefreshing}
            onClick={handleRefresh}
            className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-3.5 py-2 text-[11px] font-bold text-white shadow-sm transition hover:bg-[#0f261e] disabled:cursor-wait disabled:opacity-70"
          >
            <RefreshCw className={cn('h-3.5 w-3.5', isRefreshing && 'animate-spin')} />
            {isRefreshing ? t('refreshing') : t('refreshPrices')}
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-3 px-4 pt-3 sm:flex-row sm:items-center sm:justify-between sm:px-5">
        <div
          role="group"
          aria-label={t('categoryFilterAria')}
          data-testid="ticker-category-filter"
          className="flex max-w-full items-center gap-1.5 overflow-x-auto pb-1"
        >
          {CATEGORY_FILTERS.map((filter) => (
            <button
              key={filter.id}
              type="button"
              data-testid={`ticker-filter-${filter.id}`}
              aria-pressed={activeCategory === filter.id}
              onClick={() => setActiveCategory(filter.id)}
              className={cn(
                'shrink-0 rounded-lg px-3 py-1.5 text-[10px] font-semibold transition',
                activeCategory === filter.id
                  ? 'bg-[#14342a] text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'
              )}
            >
              {t(filter.labelKey)}
            </button>
          ))}
        </div>
        <span className="shrink-0 text-[10px] font-medium text-gray-400">
          {t('instrumentCount', { count: filteredItems.length })}
        </span>
      </div>

      <div
        ref={scrollTrackRef}
        data-testid="ticker-scroll-track"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onTouchStart={handleMouseEnter}
        onTouchEnd={handleMouseLeave}
        className="ticker-scrollbar mt-2 flex gap-3 overflow-x-auto px-4 pb-4 pt-1 sm:px-5"
      >
        {filteredItems.map((item) => {
          const change = new TickerDecimal(item.changePct);
          const positive = change.gte(0);
          return (
            <article
              key={item.symbol}
              data-testid={`ticker-item-${item.symbol}`}
              data-price={item.price}
              data-change-pct={item.changePct}
              data-category={item.category}
              data-currency={item.currency}
              className="w-[184px] shrink-0 rounded-2xl border border-gray-100 bg-gray-50/80 p-3.5 transition-colors hover:border-[#14342a]/20 hover:bg-white dark:border-gray-800 dark:bg-[#17191B] dark:hover:border-[#4ade80]/30 dark:hover:bg-[#1A1D1F]"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2.5">
                  <AssetMark category={item.category} />
                  <div className="min-w-0">
                    <p className="truncate text-xs font-extrabold tracking-tight text-gray-900 dark:text-gray-100">
                      {item.symbol}
                    </p>
                    <p className="truncate text-[9px] font-semibold uppercase tracking-wider text-gray-400">
                      {t(CATEGORY_LABEL_KEYS[item.category])}
                    </p>
                  </div>
                </div>
                <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-gray-300 dark:text-gray-600" />
              </div>

              <div className="mt-3 flex items-end justify-between gap-2">
                <p
                  data-testid={`ticker-price-${item.symbol}`}
                  className="text-[15px] font-bold tracking-tight text-[#14342a] tabular-nums dark:text-gray-100"
                >
                  {formatPrice(item)}
                </p>
                <span
                  data-testid={`ticker-change-${item.symbol}`}
                  className={cn(
                    'inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[10px] font-bold tabular-nums',
                    positive
                      ? 'bg-emerald-50 text-[#059669] dark:bg-emerald-950/50 dark:text-emerald-300'
                      : 'bg-red-50 text-[#DC2626] dark:bg-red-950/50 dark:text-rose-300'
                  )}
                >
                  {positive ? (
                    <ArrowUpRight className="h-3 w-3" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3" />
                  )}
                  {formatChange(item.changePct)}
                </span>
              </div>
              {item.currency === 'USD' && (
                <p className="mt-1 text-[9px] text-gray-400 tabular-nums">
                  ≈ ฿{new TickerDecimal(item.price)
                    .times(new TickerDecimal(item.fxToTHB))
                    .toDecimalPlaces(2)
                    .toFixed(2)} · {t('fxToThb')}
                </p>
              )}
            </article>
          );
        })}
      </div>

      {isRefreshing && (
        <p
          data-testid="ticker-refresh-status"
          role="status"
          className="border-t border-emerald-100 bg-emerald-50/70 px-5 py-2 text-[11px] font-medium text-[#14342a] dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-200"
        >
          {t('refreshStatus')}
        </p>
      )}
      {refreshError && (
        <p role="alert" className="border-t border-red-100 px-5 py-2 text-[11px] text-red-600 dark:border-red-900/50 dark:text-red-300">
          {refreshError}
        </p>
      )}
    </section>
  );
}

export default MultiAssetTickerBar;
