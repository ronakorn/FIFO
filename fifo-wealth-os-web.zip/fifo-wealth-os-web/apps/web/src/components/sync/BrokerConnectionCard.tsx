'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useLocale, useTranslations } from 'next-intl';
import {
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  Fingerprint,
  KeyRound,
  Lock,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import { Link } from '@/navigation';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import { cn, extractApiErrorMessage } from '@/lib/utils';
import type {
  BrokerConnectionPublic,
  BrokerSyncStatus,
  ManualSyncResult,
} from '@/types/sync';

interface BrokerConnectionCardProps {
  selectedPortfolioId?: string;
  onSyncCompleted?: (result: ManualSyncResult) => void;
}

const DEFAULT_DISCONNECTED_STATE: BrokerConnectionPublic = {
  id: null,
  brokerName: 'IBKR',
  flexQueryId: null,
  portfolioId: null,
  status: 'DISCONNECTED',
  connected: false,
  lastSyncedAt: null,
  createdAt: null,
  readOnly: true,
  encryption: 'AES-256-GCM',
};

export function BrokerConnectionCard({
  selectedPortfolioId,
  onSyncCompleted,
}: BrokerConnectionCardProps) {
  const t = useTranslations('IbkrSync');
  const locale = useLocale();
  const queryClient = useQueryClient();
  const token = useAuthStore((s) => s.token);

  const [connection, setConnection] = useState<BrokerConnectionPublic>(
    DEFAULT_DISCONNECTED_STATE
  );

  // Connect Modal state
  const [connectModalOpen, setConnectModalOpen] = useState(false);
  const [flexQueryToken, setFlexQueryToken] = useState('');
  const [flexQueryId, setFlexQueryId] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [submittingConnect, setSubmittingConnect] = useState(false);

  // Sync & Disconnect states
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncResult, setLastSyncResult] = useState<ManualSyncResult | null>(
    null
  );
  const [disconnectModalOpen, setDisconnectModalOpen] = useState(false);
  const [submittingDisconnect, setSubmittingDisconnect] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchStatus = useCallback(async () => {
    if (!token) {
      setConnection(DEFAULT_DISCONNECTED_STATE);
      return;
    }
    try {
      const { data } = await api.get<BrokerConnectionPublic>('/sync/status');
      setConnection(data);
    } catch {
      // Keep clean default state if endpoint not yet queried
    }
  }, [token]);

  useEffect(() => {
    void fetchStatus();
  }, [fetchStatus]);

  const effectiveStatus: BrokerSyncStatus = isSyncing
    ? 'SYNCING'
    : connection.status;

  const handleConnectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!flexQueryToken.trim() || flexQueryToken.trim().length < 6) {
      setErrorMsg(t('tokenLengthError'));
      return;
    }
    if (!flexQueryId.trim() || flexQueryId.trim().length < 3) {
      setErrorMsg(t('queryIdLengthError'));
      return;
    }

    setSubmittingConnect(true);
    try {
      if (token) {
        const { data } = await api.post<{ connection: BrokerConnectionPublic }>(
          '/sync/ibkr/connect',
          {
            flexQueryToken: flexQueryToken.trim(),
            flexQueryId: flexQueryId.trim(),
            portfolioId: selectedPortfolioId || undefined,
          }
        );
        setConnection(data.connection);
      } else {
        // Demo preview fallback when unauthenticated
        setConnection({
          id: 'demo-ibkr-conn',
          brokerName: 'IBKR',
          flexQueryId: flexQueryId.trim(),
          portfolioId: selectedPortfolioId ?? null,
          status: 'CONNECTED',
          connected: true,
          lastSyncedAt: null,
          createdAt: new Date().toISOString(),
          readOnly: true,
          encryption: 'AES-256-GCM',
        });
      }

      // Immediately clear plaintext token from React state memory
      setFlexQueryToken('');
      setShowToken(false);
      setConnectModalOpen(false);
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setSubmittingConnect(false);
    }
  };

  const handleTriggerSync = async () => {
    setErrorMsg(null);
    setIsSyncing(true);
    setLastSyncResult(null);

    try {
      if (token) {
        const { data } = await api.post<ManualSyncResult>(
          '/sync/ibkr/trigger',
          {
            portfolioId:
              selectedPortfolioId || connection.portfolioId || undefined,
            delayMs: 1100,
          }
        );
        setLastSyncResult(data);
        setConnection((prev) => ({
          ...prev,
          status: 'CONNECTED',
          connected: true,
          portfolioId: data.portfolioId,
          lastSyncedAt: data.lastSyncedAt,
        }));

        // Refresh all FIFO portfolio & tax queries across the app
        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ['portfolios'] }),
          queryClient.invalidateQueries({ queryKey: ['portfolio'] }),
          queryClient.invalidateQueries({ queryKey: ['transactions'] }),
          queryClient.invalidateQueries({ queryKey: ['tax-summary'] }),
          queryClient.invalidateQueries({ queryKey: ['analytics'] }),
        ]);

        onSyncCompleted?.(data);
      } else {
        await new Promise((r) => setTimeout(r, 1100));
        const demoResult: ManualSyncResult = {
          addedTransactions: 3,
          addedDividends: 1,
          skippedTransactions: 0,
          skippedDividends: 0,
          portfolioId: selectedPortfolioId ?? 'demo-global',
          status: 'CONNECTED',
          lastSyncedAt: new Date().toISOString(),
        };
        setLastSyncResult(demoResult);
        setConnection((prev) => ({
          ...prev,
          status: 'CONNECTED',
          lastSyncedAt: demoResult.lastSyncedAt,
        }));
      }
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
      setConnection((prev) => ({ ...prev, status: 'ERROR' }));
    } finally {
      setIsSyncing(false);
    }
  };

  const handleConfirmDisconnect = async () => {
    setErrorMsg(null);
    setSubmittingDisconnect(true);
    try {
      if (token) {
        await api.delete('/sync/ibkr/disconnect');
      }
      setConnection(DEFAULT_DISCONNECTED_STATE);
      setLastSyncResult(null);
      setDisconnectModalOpen(false);
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setSubmittingDisconnect(false);
    }
  };

  const formattedLastSynced = connection.lastSyncedAt
    ? new Date(connection.lastSyncedAt).toLocaleString(locale === 'th' ? 'th-TH' : 'en-GB', {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
    : null;

  return (
    <>
      <section
        data-testid="ibkr-connection-card"
        className="rounded-2xl border border-gray-200 bg-white p-5 sm:p-6 shadow-sm transition dark:border-gray-800 dark:bg-[#1E1E1E]"
      >
        {/* Top Row: IBKR Brand Logo + Security & Connection Status Badges */}
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-4">
            {/* IBKR Geometric Vector Logo */}
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-red-200/80 bg-red-50/80 shadow-xs dark:border-red-900/50 dark:bg-red-950/30">
              <svg
                viewBox="0 0 36 36"
                className="h-7 w-7"
                aria-hidden="true"
              >
                <polygon points="8,30 18,6 18,30" fill="#D81B2A" />
                <circle cx="23.5" cy="13.5" r="4.5" fill="#D81B2A" />
                <rect
                  x="20"
                  y="20"
                  width="7"
                  height="10"
                  rx="1.5"
                  fill="#14342a"
                  className="dark:fill-white"
                />
              </svg>
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
                  {t('sectionEyebrow')}
                </span>
                <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50/90 px-2.5 py-0.5 text-[11px] font-semibold text-[#14342a] dark:border-emerald-800/60 dark:bg-emerald-950/50 dark:text-[#4ade80]">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  {t('securityBadge')}
                </span>
              </div>

              <h2 className="mt-1 text-lg sm:text-xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
                {t('cardTitle')}
              </h2>
              <p className="mt-1 max-w-2xl text-xs sm:text-sm leading-relaxed text-gray-600 dark:text-gray-400">
                {t('cardSubtitle')}
              </p>
            </div>
          </div>

          {/* Live Status Pill */}
          <div className="flex flex-wrap items-center gap-2 self-start">
            <span
              data-testid="ibkr-status-badge"
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold border',
                effectiveStatus === 'CONNECTED' &&
                  'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-800/60 dark:bg-emerald-950/50 dark:text-emerald-300',
                effectiveStatus === 'SYNCING' &&
                  'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-800/60 dark:bg-amber-950/50 dark:text-amber-300',
                effectiveStatus === 'ERROR' &&
                  'border-red-200 bg-red-50 text-red-700 dark:border-red-800/60 dark:bg-red-950/50 dark:text-red-300',
                effectiveStatus === 'DISCONNECTED' &&
                  'border-gray-200 bg-gray-50 text-gray-600 dark:border-gray-700 dark:bg-gray-800/80 dark:text-gray-300'
              )}
            >
              {effectiveStatus === 'SYNCING' ? (
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <span
                  className={cn(
                    'h-2 w-2 rounded-full',
                    effectiveStatus === 'CONNECTED' && 'bg-emerald-500',
                    effectiveStatus === 'ERROR' && 'bg-red-500',
                    effectiveStatus === 'DISCONNECTED' && 'bg-gray-400'
                  )}
                />
              )}
              {effectiveStatus === 'CONNECTED' && t('statusConnected')}
              {effectiveStatus === 'SYNCING' && t('statusSyncing')}
              {effectiveStatus === 'ERROR' && t('statusError')}
              {effectiveStatus === 'DISCONNECTED' && t('statusDisconnected')}
            </span>
          </div>
        </div>

        {/* Error Callout */}
        {errorMsg && (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-red-200 bg-red-50/90 px-4 py-3 text-xs font-medium text-red-700 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
            <ShieldAlert className="h-4 w-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Active Syncing Progress State */}
        {isSyncing && (
          <div
            data-testid="ibkr-syncing-banner"
            className="mt-5 rounded-2xl border border-[#14342a]/20 bg-[#14342a]/[0.04] p-4 sm:p-5 dark:border-[#4ade80]/25 dark:bg-[#14342a]/30"
          >
            <div className="flex items-start gap-3.5">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#14342a] text-white dark:bg-[#4ade80] dark:text-[#0d221b]">
                <RefreshCw className="h-5 w-5 animate-spin" />
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-bold text-[#14342a] dark:text-[#4ade80]">
                    {t('syncProgressTitle')}
                  </p>
                  <span className="font-mono text-xs font-semibold text-[#14342a] dark:text-[#4ade80]">
                    AES-256-GCM • XML • THB FX
                  </span>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-300">
                  {t('syncProgressDesc')}
                </p>
                <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200 dark:bg-gray-800">
                  <div className="h-full w-2/3 animate-pulse rounded-full bg-[#14342a] dark:bg-[#4ade80]" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Sync Completed Result Banner */}
        {lastSyncResult && !isSyncing && (
          <div
            data-testid="ibkr-sync-success-banner"
            className="mt-5 flex flex-col gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/75 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-emerald-800/60 dark:bg-emerald-950/30"
          >
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
              <p className="text-xs sm:text-sm font-semibold text-emerald-900 dark:text-emerald-200">
                {t('syncSuccessBanner', {
                  txCount: lastSyncResult.addedTransactions,
                  divCount: lastSyncResult.addedDividends,
                  skippedCount:
                    lastSyncResult.skippedTransactions +
                    lastSyncResult.skippedDividends,
                })}
              </p>
            </div>

            <Link
              href={`/portfolios/${lastSyncResult.portfolioId}`}
              data-testid="ibkr-view-portfolio-link"
              className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#14342a] px-4 py-2 text-xs font-semibold text-white shadow-xs transition hover:bg-[#1c4739] dark:bg-[#4ade80] dark:text-[#0d221b]"
            >
              {t('viewUpdatedPortfolioBtn')}
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        )}

        {/* Action Footer: Disconnected vs Connected */}
        <div className="mt-5 flex flex-col gap-3 border-t border-gray-100 pt-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800">
          {!connection.connected && effectiveStatus === 'DISCONNECTED' ? (
            <>
              <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                <Lock className="h-3.5 w-3.5 text-[#14342a] dark:text-[#4ade80]" />
                <span>{t('readOnlyPermissions')}</span>
              </div>

              <button
                type="button"
                data-testid="ibkr-open-connect-modal"
                onClick={() => {
                  setErrorMsg(null);
                  setConnectModalOpen(true);
                }}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm transition hover:bg-[#1c4739] dark:bg-[#4ade80] dark:text-[#0d221b] dark:hover:bg-[#22c55e]"
              >
                <KeyRound className="h-4 w-4" />
                {t('openConnectModalBtn')}
              </button>
            </>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-600 dark:text-gray-400">
                <span className="font-mono font-semibold text-gray-900 dark:text-gray-200">
                  {t('queryIdDisplay', { id: connection.flexQueryId ?? '' })}
                </span>
                <span>•</span>
                <span data-testid="ibkr-last-synced">
                  {formattedLastSynced
                    ? t('lastSyncedLabel', { time: formattedLastSynced })
                    : t('neverSynced')}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  disabled={isSyncing}
                  data-testid="ibkr-sync-now-btn"
                  onClick={() => void handleTriggerSync()}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm transition hover:bg-[#1c4739] disabled:opacity-65 dark:bg-[#4ade80] dark:text-[#0d221b]"
                >
                  {isSyncing ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      {t('syncingBtn')}
                    </>
                  ) : (
                    <span>{t('syncNowBtn')}</span>
                  )}
                </button>

                <button
                  type="button"
                  disabled={isSyncing}
                  data-testid="ibkr-disconnect-btn"
                  onClick={() => setDisconnectModalOpen(true)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-red-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-red-600 transition hover:bg-red-50 disabled:opacity-50 dark:border-red-900/60 dark:bg-transparent dark:text-red-400 dark:hover:bg-red-950/40"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  {t('disconnectBtn')}
                </button>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Modal 1: Configure IBKR Read-Only Flex Query Connection */}
      <Dialog open={connectModalOpen} onOpenChange={setConnectModalOpen}>
        <DialogContent
          data-testid="ibkr-connect-modal"
          className="max-w-xl rounded-2xl p-6 sm:p-7"
        >
          <DialogHeader>
            <div className="mb-2 inline-flex w-fit items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[11px] font-semibold text-[#14342a] dark:border-emerald-800/60 dark:bg-emerald-950/60 dark:text-[#4ade80]">
              <ShieldCheck className="h-3.5 w-3.5" />
              {t('securityBadge')}
            </div>
            <DialogTitle className="text-xl font-bold">
              {t('modalTitle')}
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm leading-relaxed">
              {t('modalSubtitle')}
            </DialogDescription>
          </DialogHeader>

          {/* 3 Security Architecture Guarantees */}
          <div className="grid grid-cols-1 gap-2.5 rounded-2xl border border-gray-100 bg-[#F8FAFC] p-4 dark:border-gray-800 dark:bg-gray-900/60">
            <div className="flex items-start gap-3">
              <Lock className="mt-0.5 h-4 w-4 shrink-0 text-[#14342a] dark:text-[#4ade80]" />
              <div>
                <p className="text-xs font-bold text-gray-900 dark:text-gray-100">
                  {t('secPoint1Title')}
                </p>
                <p className="text-[11px] leading-relaxed text-gray-600 dark:text-gray-400">
                  {t('secPoint1Desc')}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#14342a] dark:text-[#4ade80]" />
              <div>
                <p className="text-xs font-bold text-gray-900 dark:text-gray-100">
                  {t('secPoint2Title')}
                </p>
                <p className="text-[11px] leading-relaxed text-gray-600 dark:text-gray-400">
                  {t('secPoint2Desc')}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Fingerprint className="mt-0.5 h-4 w-4 shrink-0 text-[#14342a] dark:text-[#4ade80]" />
              <div>
                <p className="text-xs font-bold text-gray-900 dark:text-gray-100">
                  {t('secPoint3Title')}
                </p>
                <p className="text-[11px] leading-relaxed text-gray-600 dark:text-gray-400">
                  {t('secPoint3Desc')}
                </p>
              </div>
            </div>
          </div>

          <form onSubmit={handleConnectSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="ibkr-flex-token"
                className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-300"
              >
                {t('tokenLabel')}
              </label>
              <div className="relative">
                <input
                  id="ibkr-flex-token"
                  data-testid="ibkr-token-input"
                  type={showToken ? 'text' : 'password'}
                  autoComplete="off"
                  value={flexQueryToken}
                  onChange={(e) => setFlexQueryToken(e.target.value)}
                  placeholder={t('tokenPlaceholder')}
                  className="w-full rounded-xl border border-gray-300 bg-white px-3.5 py-2.5 pr-10 font-mono text-sm text-gray-900 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/20 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-100"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowToken((v) => !v)}
                  aria-label={t('toggleTokenVisibility')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                >
                  {showToken ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            <div>
              <label
                htmlFor="ibkr-flex-query-id"
                className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-300"
              >
                {t('queryIdLabel')}
              </label>
              <input
                id="ibkr-flex-query-id"
                data-testid="ibkr-query-id-input"
                type="text"
                autoComplete="off"
                value={flexQueryId}
                onChange={(e) => setFlexQueryId(e.target.value)}
                placeholder={t('queryIdPlaceholder')}
                className="w-full rounded-xl border border-gray-300 bg-white px-3.5 py-2.5 font-mono text-sm text-gray-900 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/20 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-100"
                required
              />
            </div>

            {errorMsg && (
              <p className="text-xs font-medium text-red-600 dark:text-red-400">
                {errorMsg}
              </p>
            )}

            <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setConnectModalOpen(false)}
                className="rounded-xl border border-gray-200 px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
              >
                {t('cancelBtn')}
              </button>
              <button
                type="submit"
                disabled={submittingConnect}
                data-testid="ibkr-connect-submit"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm transition hover:bg-[#1c4739] disabled:opacity-60 dark:bg-[#4ade80] dark:text-[#0d221b]"
              >
                <ShieldCheck className="h-4 w-4" />
                {t('connectReadOnlyBtn')}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Modal 2: Right to be Forgotten Disconnect Confirmation */}
      <Dialog open={disconnectModalOpen} onOpenChange={setDisconnectModalOpen}>
        <DialogContent className="max-w-md rounded-2xl p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg font-bold text-red-600 dark:text-red-400">
              {t('disconnectModalTitle')}
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm leading-relaxed">
              {t('disconnectModalDesc')}
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col-reverse gap-2 pt-3 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={() => setDisconnectModalOpen(false)}
              className="rounded-xl border border-gray-200 px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300"
            >
              {t('cancelBtn')}
            </button>
            <button
              type="button"
              disabled={submittingDisconnect}
              data-testid="ibkr-confirm-disconnect-btn"
              onClick={() => void handleConfirmDisconnect()}
              className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-red-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-red-700 disabled:opacity-60"
            >
              <Trash2 className="h-3.5 w-3.5" />
              {t('confirmDisconnectBtn')}
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
