'use client';

import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  BookOpen,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  FolderKanban,
  Minus,
  Plus,
  Sparkles,
  Trash2,
  TrendingDown,
  TrendingUp,
  X,
} from 'lucide-react';
import { useLocale, useTranslations } from 'next-intl';
import {
  useCreateJournalEntry,
  useDeleteJournalEntry,
  useJournalEntries,
  usePortfolios,
} from '@/lib/queries';
import { useAssistantStore, useAuthStore } from '@/lib/stores';
import { mockJournalEntries } from '@/mocks/mockJournalFamily';
import { JournalEntryItem, JournalMood } from '@/types/journalAi';
import { EmptyState } from '@/components/ux/EmptyState';
import { cn } from '@/lib/utils';

export function WealthJournal() {
  const t = useTranslations('journal');
  const locale = useLocale() as 'th' | 'en';
  const token = useAuthStore((s) => s.token);
  const openChat = useAssistantStore((s) => s.openChat);

  // Default to October 2026 (current system date 2026-10-26)
  const [viewYear, setViewYear] = useState<number>(2026);
  const [viewMonth, setViewMonth] = useState<number>(10); // 1-12
  const [selectedDayFilter, setSelectedDayFilter] = useState<string | null>(null);

  const monthKey = `${viewYear}-${String(viewMonth).padStart(2, '0')}`;
  const journalQuery = useJournalEntries(monthKey);
  const portfoliosQuery = usePortfolios();
  const createMutation = useCreateJournalEntry();
  const deleteMutation = useDeleteJournalEntry();

  // Preview mode local state
  const [previewEntries, setPreviewEntries] =
    useState<JournalEntryItem[]>(mockJournalEntries);

  const entries: JournalEntryItem[] = useMemo(() => {
    if (token) return journalQuery.data ?? [];
    return previewEntries.filter((e) => e.date.startsWith(`${monthKey}-`));
  }, [token, journalQuery.data, previewEntries, monthKey]);

  const entriesByDate = useMemo(() => {
    const map = new Map<string, JournalEntryItem[]>();
    for (const entry of entries) {
      const list = map.get(entry.date) ?? [];
      list.push(entry);
      map.set(entry.date, list);
    }
    return map;
  }, [entries]);

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [formDate, setFormDate] = useState<string>('2026-10-26');
  const [formPortfolioId, setFormPortfolioId] = useState<string>('');
  const [formTitle, setFormTitle] = useState<string>('');
  const [formContent, setFormContent] = useState<string>('');
  const [formMood, setFormMood] = useState<JournalMood>('BULLISH');

  const openModalForDate = (isoDate: string) => {
    setFormDate(isoDate);
    setFormTitle('');
    setFormContent('');
    setFormMood('BULLISH');
    setIsModalOpen(true);
  };

  const handlePrevMonth = () => {
    setSelectedDayFilter(null);
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    setSelectedDayFilter(null);
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const calendarDays = useMemo(() => {
    const firstDayOfWeek = new Date(viewYear, viewMonth - 1, 1).getDay();
    const daysInMonth = new Date(viewYear, viewMonth, 0).getDate();
    const cells: { day: number | null; isoDate: string | null }[] = [];

    for (let i = 0; i < firstDayOfWeek; i++) {
      cells.push({ day: null, isoDate: null });
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const iso = `${viewYear}-${String(viewMonth).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      cells.push({ day: d, isoDate: iso });
    }
    return cells;
  }, [viewYear, viewMonth]);

  const displayedEntries = useMemo(() => {
    if (!selectedDayFilter) return entries;
    return entries.filter((e) => e.date === selectedDayFilter);
  }, [entries, selectedDayFilter]);

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) return;

    if (!token) {
      const newMock: JournalEntryItem = {
        id: `preview-journal-${Date.now()}`,
        userId: 'preview-user',
        portfolioId: formPortfolioId || null,
        portfolioName: null,
        date: formDate,
        title: formTitle.trim(),
        content: formContent.trim(),
        mood: formMood,
        createdAt: new Date().toISOString(),
      };
      setPreviewEntries((prev) => [newMock, ...prev]);
      setIsModalOpen(false);
      return;
    }

    await createMutation.mutateAsync({
      date: formDate,
      title: formTitle.trim(),
      content: formContent.trim(),
      mood: formMood,
      portfolioId: formPortfolioId || null,
    });
    setIsModalOpen(false);
  };

  const handleDeleteEntry = async (id: string) => {
    if (!token) {
      setPreviewEntries((prev) => prev.filter((item) => item.id !== id));
      return;
    }
    await deleteMutation.mutateAsync(id);
  };

  const renderMoodBadge = (mood: JournalMood) => {
    if (mood === 'BULLISH') {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-semibold text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400">
          <TrendingUp className="h-3 w-3" />
          {t('moodBullish')}
        </span>
      );
    }
    if (mood === 'BEARISH') {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-red-50 px-2.5 py-0.5 text-[11px] font-semibold text-[#DC2626] dark:bg-red-950/60 dark:text-rose-400">
          <TrendingDown className="h-3 w-3" />
          {t('moodBearish')}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-[#14342a]/10 px-2.5 py-0.5 text-[11px] font-semibold text-[#14342a] dark:bg-[#4ade80]/15 dark:text-[#4ade80]">
        <Minus className="h-3 w-3" />
        {t('moodNeutral')}
      </span>
    );
  };

  const monthTitle = `${new Intl.DateTimeFormat(locale, { month: 'long' }).format(new Date(viewYear, viewMonth - 1, 1))} ${viewYear}`;
  const weekdayFormatter = new Intl.DateTimeFormat(locale, { weekday: 'short' });
  const weekdays = Array.from({ length: 7 }, (_, day) =>
    weekdayFormatter.format(new Date(2024, 0, 7 + day))
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-8"
    >
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
            {t('eyebrow')}
          </p>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
            {t('title')}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t('subtitle')}
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start sm:self-auto">
          <motion.button
            type="button"
            whileTap={{ scale: 0.95 }}
            onClick={openChat}
            className="inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-[#14342a] shadow-sm transition hover:bg-gray-50 dark:border-gray-700 dark:bg-[#1E1E1E] dark:text-[#4ade80]"
          >
            <Sparkles className="h-4 w-4" />
            <span>{t('aiAssistant')}</span>
          </motion.button>

          <motion.button
            type="button"
            whileTap={{ scale: 0.95 }}
            data-testid="journal-new-memo-btn"
            onClick={() => openModalForDate('2026-10-26')}
            className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
          >
            <Plus className="h-4 w-4" />
            <span>{t('newMemoBtn')}</span>
          </motion.button>
        </div>
      </div>

      {/* Main 2-Column Layout: Minimalist Calendar + Monthly Memo Feed */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Minimalist Calendar Card */}
        <div
          data-testid="wealth-journal-calendar"
          className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] lg:col-span-5"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#14342a]/5 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                <CalendarIcon className="h-4 w-4" />
              </div>
              <h2 className="text-base font-bold tracking-tight text-[#1A1A1A] tabular-nums dark:text-[#F5F5F5]">
                {monthTitle}
              </h2>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handlePrevMonth}
                aria-label={t('previousMonth')}
                className="rounded-xl p-1.5 text-gray-500 transition hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={handleNextMonth}
                aria-label={t('nextMonth')}
                className="rounded-xl p-1.5 text-gray-500 transition hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <p className="mt-2 text-[11px] text-gray-500 dark:text-gray-400">
            {t('clickDayHint')}
          </p>

          {/* Weekday Headers */}
          <div className="mt-5 grid grid-cols-7 text-center text-[11px] font-semibold text-gray-400 dark:text-gray-500">
            {weekdays.map((wd) => (
              <div key={wd} className="py-1.5">
                {wd}
              </div>
            ))}
          </div>

          {/* Calendar Days */}
          <div className="mt-1 grid grid-cols-7 gap-1.5">
            {calendarDays.map((cell, idx) => {
              if (!cell.day || !cell.isoDate) {
                return <div key={`empty-${idx}`} className="h-11" />;
              }

              const dayEntries = entriesByDate.get(cell.isoDate) ?? [];
              const hasEntries = dayEntries.length > 0;
              const isToday = cell.isoDate === '2026-10-26';
              const isSelected = selectedDayFilter === cell.isoDate;

              return (
                <motion.button
                  key={cell.isoDate}
                  type="button"
                  whileTap={{ scale: 0.94 }}
                  data-testid={`calendar-day-${cell.isoDate}`}
                  onClick={() => openModalForDate(cell.isoDate!)}
                  className={cn(
                    'relative flex h-11 flex-col items-center justify-center rounded-xl text-xs font-semibold tabular-nums transition',
                    isSelected || isToday
                      ? 'border border-[#14342a]/40 bg-[#14342a]/5 text-[#14342a] dark:border-[#4ade80]/50 dark:bg-[#4ade80]/10 dark:text-[#4ade80]'
                      : 'text-[#1A1A1A] hover:bg-gray-100 dark:text-[#F5F5F5] dark:hover:bg-gray-800'
                  )}
                >
                  <span>{cell.day}</span>
                  {/* #14342a Dot Indicator when Journal Entry Exists */}
                  {hasEntries && (
                    <span
                      data-testid="journal-dot-indicator"
                      className="mt-0.5 h-1.5 w-1.5 rounded-full bg-[#14342a] dark:bg-[#4ade80]"
                    />
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Right: Monthly Journal Entries Feed */}
        <div className="space-y-4 lg:col-span-7">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
              <h2 className="text-base font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                {t('entriesTitle')} ({displayedEntries.length})
              </h2>
            </div>

            {selectedDayFilter && (
              <button
                type="button"
                onClick={() => setSelectedDayFilter(null)}
                className="text-xs font-semibold text-[#14342a] underline dark:text-[#4ade80]"
              >
                {selectedDayFilter} ×
              </button>
            )}
          </div>

          {displayedEntries.length === 0 ? (
            <EmptyState
              title={t('emptyTitle')}
              description={t('emptyDescription')}
              actionLabel={t('emptyAction')}
              onActionClick={() => openModalForDate(`${monthKey}-01`)}
            />
          ) : (
            <div className="space-y-3.5">
              {displayedEntries.map((entry) => (
                <motion.article
                  key={entry.id}
                  data-testid="journal-entry-card"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm transition hover:border-gray-200 dark:border-gray-800 dark:bg-[#1E1E1E]"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="rounded-lg bg-gray-100 px-2 py-0.5 text-[11px] font-bold text-gray-700 tabular-nums dark:bg-gray-800 dark:text-gray-300">
                          {entry.date}
                        </span>
                        {renderMoodBadge(entry.mood)}
                        {entry.portfolioName && (
                          <span className="inline-flex items-center gap-1 rounded-lg bg-[#14342a]/5 px-2 py-0.5 text-[11px] font-medium text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                            <FolderKanban className="h-3 w-3" />
                            {entry.portfolioName}
                          </span>
                        )}
                      </div>
                      <h3 className="pt-1 text-sm font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                        {entry.title}
                      </h3>
                    </div>

                    <button
                      type="button"
                      onClick={() => void handleDeleteEntry(entry.id)}
                      aria-label={t('deleteMemo')}
                      className="rounded-lg p-1.5 text-gray-400 transition hover:bg-red-50 hover:text-[#DC2626] dark:hover:bg-red-950/40 dark:hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <p className="mt-2 text-xs leading-relaxed text-gray-600 dark:text-gray-300">
                    {entry.content}
                  </p>
                </motion.article>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Create Journal Memo Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div
            data-testid="journal-modal"
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 10 }}
              className="w-full max-w-lg rounded-2xl border border-gray-100 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                  {t('modalTitle')}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-xl p-1.5 text-gray-400 transition hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <form onSubmit={handleCreateSubmit} className="mt-4 space-y-4">
                <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]">
                      {t('dateLabel')}
                    </label>
                    <input
                      type="date"
                      required
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3 text-xs font-medium tabular-nums focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                    />
                  </div>

                  <div>
                    <label className="mb-1.5 block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]">
                      {t('portfolioLabel')}
                    </label>
                    <select
                      value={formPortfolioId}
                      onChange={(e) => setFormPortfolioId(e.target.value)}
                      className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3 text-xs font-medium focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                    >
                      <option value="">{t('allPortfoliosOption')}</option>
                      {(portfoliosQuery.data ?? []).map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Mood Selector */}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]">
                    {t('moodLabel')}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['BULLISH', 'NEUTRAL', 'BEARISH'] as const).map((m) => {
                      const active = formMood === m;
                      return (
                        <button
                          key={m}
                          type="button"
                          data-testid={`mood-btn-${m}`}
                          onClick={() => setFormMood(m)}
                          className={cn(
                            'rounded-xl border px-3 py-2 text-xs font-semibold transition',
                            active
                              ? 'border-[#14342a] bg-[#14342a] text-white dark:border-[#4ade80] dark:text-[#4ade80]'
                              : 'border-gray-200 bg-gray-50 text-gray-600 hover:bg-gray-100 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-300'
                          )}
                        >
                          {m === 'BULLISH'
                            ? t('moodBullish')
                            : m === 'BEARISH'
                              ? t('moodBearish')
                              : t('moodNeutral')}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]">
                    {t('memoTitleLabel')}
                  </label>
                  <input
                    data-testid="journal-title-input"
                    type="text"
                    required
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    placeholder={t('memoTitlePlaceholder')}
                    className="h-10 w-full rounded-xl border border-gray-200 bg-white px-3.5 text-xs focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                  />
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#1A1A1A] dark:text-[#F5F5F5]">
                    {t('memoContentLabel')}
                  </label>
                  <textarea
                    data-testid="journal-content-input"
                    rows={3}
                    required
                    value={formContent}
                    onChange={(e) => setFormContent(e.target.value)}
                    placeholder={t('memoContentPlaceholder')}
                    className="w-full rounded-xl border border-gray-200 bg-white p-3.5 text-xs leading-relaxed focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="rounded-xl bg-gray-100 px-4 py-2.5 text-xs font-semibold text-gray-800 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200"
                  >
                    {t('cancelBtn')}
                  </button>
                  <motion.button
                    type="submit"
                    whileTap={{ scale: 0.95 }}
                    data-testid="journal-save-btn"
                    disabled={createMutation.isPending}
                    className="rounded-xl bg-[#14342a] px-5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
                  >
                    {t('saveBtn')}
                  </motion.button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default WealthJournal;
