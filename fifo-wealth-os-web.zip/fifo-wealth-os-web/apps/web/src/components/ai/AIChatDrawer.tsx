'use client';

import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Bot, Loader2, Send, Sparkles, User, X } from 'lucide-react';
import { useLocale, useTranslations } from 'next-intl';
import { useAIChatMutation } from '@/lib/queries';
import { useAssistantStore, useAuthStore } from '@/lib/stores';
import { ChatMessage } from '@/types/journalAi';
import { cn } from '@/lib/utils';

function TypingAssistantBubble({
  text,
  animateTyping,
}: {
  text: string;
  animateTyping: boolean;
}) {
  const [displayed, setDisplayed] = useState<string>(animateTyping ? '' : text);

  useEffect(() => {
    if (!animateTyping) {
      setDisplayed(text);
      return;
    }

    let idx = 0;
    setDisplayed('');
    const stepSize = Math.max(2, Math.ceil(text.length / 65));
    const timer = window.setInterval(() => {
      idx += stepSize;
      if (idx >= text.length) {
        setDisplayed(text);
        window.clearInterval(timer);
      } else {
        setDisplayed(text.slice(0, idx));
      }
    }, 18);

    return () => window.clearInterval(timer);
  }, [text, animateTyping]);

  // Render simple **bold** highlights cleanly
  const segments = displayed.split(/(\*\*[^*]+\*\*)/g);

  return (
    <div className="whitespace-pre-line text-xs leading-relaxed text-[#1A1A1A] dark:text-[#F5F5F5]">
      {segments.map((seg, i) =>
        seg.startsWith('**') && seg.endsWith('**') ? (
          <strong
            key={i}
            className="font-bold text-[#14342a] tabular-nums dark:text-[#4ade80]"
          >
            {seg.slice(2, -2)}
          </strong>
        ) : (
          <span key={i}>{seg}</span>
        )
      )}
    </div>
  );
}

export function AIChatDrawer() {
  const t = useTranslations('ai');
  const locale = useLocale() as 'th' | 'en';

  const isOpen = useAssistantStore((s) => s.isChatOpen);
  const closeChat = useAssistantStore((s) => s.closeChat);
  const sessionId = useAssistantStore((s) => s.chatSessionId);
  const setSessionId = useAssistantStore((s) => s.setChatSessionId);
  const token = useAuthStore((s) => s.token);

  const chatMutation = useAIChatMutation();
  const [input, setInput] = useState<string>('');
  const [messages, setMessages] = useState<
    (ChatMessage & { isFresh?: boolean })[]
  >([]);
  const scrollEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, chatMutation.isPending]);

  const sendQuestion = async (rawPrompt: string) => {
    const trimmed = rawPrompt.trim();
    if (!trimmed || chatMutation.isPending) return;

    const userMsg: ChatMessage = {
      id: `local-user-${Date.now()}`,
      role: 'user',
      content: trimmed,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [
      ...prev.map((m) => ({ ...m, isFresh: false })),
      userMsg,
    ]);
    setInput('');

    if (!token) {
      // Preview Mode smart fallback
      const fallbackReply = t('previewFallback');

      window.setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            id: `local-ai-${Date.now()}`,
            role: 'assistant',
            content: fallbackReply,
            timestamp: new Date().toISOString(),
            isFresh: true,
          },
        ]);
      }, 280);
      return;
    }

    try {
      const res = await chatMutation.mutateAsync({
        message: trimmed,
        sessionId: sessionId ?? undefined,
        locale,
      });
      setSessionId(res.sessionId);
      setMessages(
        res.messages.map((m, idx) => ({
          ...m,
          isFresh: idx === res.messages.length - 1 && m.role === 'assistant',
        }))
      );
    } catch {
      const errText = t('errorFallback');
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: errText,
          timestamp: new Date().toISOString(),
          isFresh: true,
        },
      ]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendQuestion(input);
  };

  const quickPrompts = [
    t('promptBestMonth'),
    t('promptSummary'),
    t('promptFire'),
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          data-testid="ai-chat-drawer"
          className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-[2px]"
        >
          {/* Keyboard-accessible backdrop dismissal */}
          <button
            type="button"
            data-testid="ai-chat-backdrop-close"
            aria-label={t('closeAssistant')}
            onClick={closeChat}
            className="flex-1 cursor-default border-0 bg-transparent p-0 focus:outline-none"
          />

          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 320, damping: 32 }}
            className="flex h-full w-full max-w-md flex-col border-l border-gray-200 bg-white shadow-2xl dark:border-gray-800 dark:bg-[#1E1E1E]"
          >
            {/* Drawer Header with AI Avatar */}
            <div className="flex items-center justify-between border-b border-gray-100 px-5 py-4 dark:border-gray-800">
              <div className="flex items-center gap-3">
                <div className="relative flex h-10 w-10 items-center justify-center rounded-2xl bg-[#14342a] text-white shadow-sm">
                  <Bot className="h-5 w-5" />
                  <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-white bg-[#059669] dark:border-[#1E1E1E]" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h2 className="text-sm font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                      {t('title')}
                    </h2>
                    <Sparkles className="h-3.5 w-3.5 text-[#059669]" />
                  </div>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">
                    {t('subtitle')}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={closeChat}
                aria-label={t('closeAssistant')}
                className="rounded-xl p-2 text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-gray-200"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Chat Messages Scroll Container */}
            <div className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
              {/* Welcome Card */}
              <div className="rounded-2xl border border-gray-100 bg-[#FAFAFA] p-4 dark:border-gray-800 dark:bg-[#121212]">
                <p className="text-xs leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('welcome')}
                </p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {quickPrompts.map((prompt) => (
                    <motion.button
                      key={prompt}
                      type="button"
                      whileTap={{ scale: 0.95 }}
                      onClick={() => void sendQuestion(prompt)}
                      className="rounded-xl border border-gray-200 bg-white px-2.5 py-1.5 text-[11px] font-semibold text-[#14342a] transition hover:border-[#14342a] hover:bg-[#14342a]/5 dark:border-gray-700 dark:bg-[#1E1E1E] dark:text-[#4ade80]"
                    >
                      {prompt}
                    </motion.button>
                  ))}
                </div>
              </div>

              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    'flex items-start gap-2.5',
                    msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                  )}
                >
                  <div
                    className={cn(
                      'flex h-7 w-7 shrink-0 items-center justify-center rounded-xl text-xs',
                      msg.role === 'assistant'
                        ? 'bg-[#14342a] text-white dark:text-[#4ade80]'
                        : 'bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-200'
                    )}
                  >
                    {msg.role === 'assistant' ? (
                      <Bot className="h-3.5 w-3.5" />
                    ) : (
                      <User className="h-3.5 w-3.5" />
                    )}
                  </div>

                  <div
                    data-testid={
                      msg.role === 'assistant'
                        ? 'ai-assistant-message'
                        : 'ai-user-message'
                    }
                    className={cn(
                      'max-w-[82%] rounded-2xl px-4 py-3 shadow-sm',
                      msg.role === 'assistant'
                        ? 'border border-gray-100 bg-[#FAFAFA] dark:border-gray-800 dark:bg-[#121212]'
                        : 'bg-[#14342a] text-xs leading-relaxed text-white'
                    )}
                  >
                    {msg.role === 'assistant' ? (
                      <TypingAssistantBubble
                        text={msg.content}
                        animateTyping={Boolean(msg.isFresh)}
                      />
                    ) : (
                      <span>{msg.content}</span>
                    )}
                  </div>
                </div>
              ))}

              {chatMutation.isPending && (
                <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-[#14342a] dark:text-[#4ade80]" />
                  <span>{t('thinking')}</span>
                </div>
              )}

              <div ref={scrollEndRef} />
            </div>

            {/* Input Form */}
            <form
              onSubmit={handleSubmit}
              className="border-t border-gray-100 bg-white p-4 pb-safe dark:border-gray-800 dark:bg-[#1E1E1E]"
            >
              <div className="flex items-center gap-2">
                <input
                  data-testid="ai-chat-input"
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={t('placeholder')}
                  className="h-10 flex-1 rounded-xl border border-gray-200 bg-[#FAFAFA] px-3.5 text-xs text-[#1A1A1A] outline-none transition focus:border-[#14342a] focus:bg-white focus:ring-2 focus:ring-[#14342a]/30 dark:border-gray-700 dark:bg-[#121212] dark:text-[#F5F5F5]"
                />
                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.95 }}
                  data-testid="ai-chat-send"
                  disabled={!input.trim() || chatMutation.isPending}
                  className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-[#14342a] px-4 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-50"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">{t('sendBtn')}</span>
                </motion.button>
              </div>
            </form>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}

export default AIChatDrawer;
