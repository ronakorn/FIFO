'use client';

import React, { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';
import { useTranslations } from 'next-intl';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { formatTHB } from '@/lib/utils';

export interface PerformancePoint {
  month: string;
  netWorthTHB: number;
  costBasisTHB: number;
}

export interface AllocationSlice {
  name: string;
  value: number;
  color?: string;
}

const LIGHT_SLICES = ['#14342a', '#059669', '#0d9488', '#d97706', '#64748b'];
const DARK_SLICES = ['#4ade80', '#10b981', '#2dd4bf', '#fbbf24', '#94a3b8'];

export function PortfolioPerformanceLineChart({
  data,
  title,
  subtitle,
}: {
  data: PerformancePoint[];
  title?: string;
  subtitle?: string;
}) {
  const t = useTranslations('portfolioDetail');
  const resolvedTitle = title ?? t('performanceChartTitle');
  const resolvedSubtitle = subtitle ?? t('performanceChartSubtitle');
  const [mounted, setMounted] = useState(false);
  const { resolvedTheme } = useTheme();

  useEffect(() => {
    setMounted(true);
  }, []);

  const isDark = resolvedTheme === 'dark';
  const primaryColor = isDark ? '#4ade80' : '#14342a';
  const gridColor = isDark ? '#262626' : '#F3F4F6';

  return (
    <div className="flex flex-col rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-base font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {resolvedTitle}
          </h3>
          <p className="text-xs text-gray-500 dark:text-gray-400">{resolvedSubtitle}</p>
        </div>
      </div>

      <div className="h-60 w-full">
        {!mounted ? (
          <div className="flex h-full items-center justify-center text-xs text-gray-400">
            {t('chartLoading')}
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="cleanNetWorthGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={primaryColor} stopOpacity={0.18} />
                  <stop offset="100%" stopColor={primaryColor} stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={gridColor} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" stroke="#9CA3AF" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis
                stroke="#9CA3AF"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                width={64}
                tickFormatter={(val: number) =>
                  val >= 1000 ? `฿${(val / 1000).toFixed(0)}k` : `฿${val}`
                }
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: isDark ? '#121212' : '#FFFFFF',
                  borderColor: isDark ? '#374151' : '#E5E7EB',
                  borderRadius: '12px',
                  fontSize: '12px',
                }}
                formatter={(value: number) => formatTHB(value)}
              />
              <Area
                type="monotone"
                dataKey="netWorthTHB"
                stroke={primaryColor}
                strokeWidth={2.5}
                fill="url(#cleanNetWorthGrad)"
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}

export function AssetAllocationPieChart({
  data,
  title,
  subtitle,
}: {
  data: AllocationSlice[];
  title?: string;
  subtitle?: string;
}) {
  const t = useTranslations('portfolioDetail');
  const resolvedTitle = title ?? t('allocationTitle');
  const resolvedSubtitle = subtitle ?? t('allocationSubtitle');
  const [mounted, setMounted] = useState(false);
  const { resolvedTheme } = useTheme();

  useEffect(() => {
    setMounted(true);
  }, []);

  const isDark = resolvedTheme === 'dark';
  const palette = isDark ? DARK_SLICES : LIGHT_SLICES;
  const total = data.reduce((acc, item) => acc + item.value, 0);

  return (
    <div className="flex flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
      <div className="mb-2">
        <h3 className="text-base font-bold tracking-tight text-gray-900 dark:text-gray-100">
          {resolvedTitle}
        </h3>
        <p className="text-xs text-gray-500 dark:text-gray-400">{resolvedSubtitle}</p>
      </div>

      {!mounted ? (
        <div className="flex h-52 items-center justify-center text-xs text-gray-400">
          {t('allocationLoading')}
        </div>
      ) : total <= 0 ? (
        <div className="flex h-52 items-center justify-center text-center text-xs text-gray-400">
          {t('allocationEmpty')}
        </div>
      ) : (
        <div className="grid grid-cols-1 items-center gap-4 sm:grid-cols-2">
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={48}
                  outerRadius={72}
                  paddingAngle={2.5}
                  stroke={isDark ? '#1E1E1E' : '#FFFFFF'}
                  strokeWidth={2}
                  isAnimationActive={false}
                >
                  {data.map((entry, idx) => (
                    <Cell
                      key={entry.name}
                      fill={entry.color ?? palette[idx % palette.length] ?? '#14342a'}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: isDark ? '#121212' : '#FFFFFF',
                    borderColor: isDark ? '#374151' : '#E5E7EB',
                    borderRadius: '12px',
                    fontSize: '12px',
                  }}
                  formatter={(val: number) => formatTHB(val)}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2">
            {data.map((slice, idx) => {
              const pct = total > 0 ? (slice.value / total) * 100 : 0;
              const swatch = slice.color ?? palette[idx % palette.length] ?? '#14342a';
              return (
                <div
                  key={slice.name}
                  className="flex items-center justify-between rounded-xl border border-gray-100 bg-gray-50/70 px-3 py-2 text-xs dark:border-gray-800 dark:bg-[#121212]"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="h-2.5 w-2.5 shrink-0 rounded-full"
                      style={{ backgroundColor: swatch }}
                    />
                    <span className="truncate font-semibold text-gray-800 dark:text-gray-200">
                      {slice.name}
                    </span>
                  </div>
                  <div className="ml-2 text-right tabular-nums">
                    <p className="font-bold text-gray-900 dark:text-gray-100">{pct.toFixed(1)}%</p>
                    <p className="text-[11px] text-gray-500 dark:text-gray-400">
                      {formatTHB(slice.value)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
