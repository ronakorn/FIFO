'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import { ErrorMessage } from './ErrorMessage';

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallbackTitle?: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

function ErrorBoundaryFallback({
  title,
  onRetry,
}: {
  title?: string;
  onRetry: () => void;
}) {
  const t = useTranslations('common');
  return (
    <div className="py-6">
      <ErrorMessage
        title={title ?? t('errorTitle')}
        message={t('errorBody')}
        onRetry={onRetry}
      />
    </div>
  );
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error.message || 'Unexpected rendering error occurred.',
    };
  }

  handleReset = (): void => {
    this.setState({ hasError: false, errorMessage: '' });
  };

  override render(): React.ReactNode {
    if (this.state.hasError) {
      return (
        <ErrorBoundaryFallback
          title={this.props.fallbackTitle}
          onRetry={this.handleReset}
        />
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
