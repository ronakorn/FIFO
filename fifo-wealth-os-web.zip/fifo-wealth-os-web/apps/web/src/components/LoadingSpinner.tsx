'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import { cn } from '@/lib/utils';

interface LoadingSpinnerProps {
  label?: string;
  sublabel?: string;
  size?: 'sm' | 'md' | 'lg';
  fullScreen?: boolean;
  className?: string;
}

export function LoadingSpinner({
  label,
  sublabel,
  size = 'md',
  fullScreen = false,
  className,
}: LoadingSpinnerProps) {
  const t = useTranslations('common');
  const resolvedLabel = label ?? t('loadingPortfolio');
  const resolvedSublabel = sublabel ?? t('loadingEngine');
  const dimensions =
    size === 'sm' ? 'h-4 w-4 border-2' : size === 'lg' ? 'h-11 w-11 border-[3px]' : 'h-8 w-8 border-2';

  if (size === 'sm') {
    return (
      <span
        role="status"
        aria-label={resolvedLabel}
        className={cn(
          'inline-block animate-spin rounded-full border-[#14342a] border-t-transparent dark:border-[#4ade80] dark:border-t-transparent',
          dimensions,
          className
        )}
      />
    );
  }

  return (
    <div
      role="status"
      className={cn(
        'flex flex-col items-center justify-center gap-3 rounded-2xl border border-gray-100 bg-white p-8 text-center shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]',
        fullScreen && 'min-h-[55vh]',
        className
      )}
    >
      <div
        className={cn(
          'animate-spin rounded-full border-[#14342a] border-t-[#059669] border-r-transparent dark:border-[#4ade80] dark:border-r-transparent',
          dimensions
        )}
      />
      <div className="space-y-1">
        <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{resolvedLabel}</p>
        {resolvedSublabel && <p className="text-xs text-gray-500 dark:text-gray-400">{resolvedSublabel}</p>}
      </div>
    </div>
  );
}

export default LoadingSpinner;
