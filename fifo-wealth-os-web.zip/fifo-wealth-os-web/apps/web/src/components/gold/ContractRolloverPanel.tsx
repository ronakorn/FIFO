'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  AlertTriangle,
  ArrowRight,
  BellRing,
  CalendarClock,
  CheckCircle2,
  GitCompareArrows,
  Repeat,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import {
  cn,
  extractApiErrorMessage,
  formatSignedTHB,
  formatTHB,
} from '@/lib/utils';
import { mockRolloverOverview } from '@/mocks/mockRollover';
import type {
  ContractRolloverOverview,
  ExpiringContractAlert,
  RolloverSpreadAnalytics,
} from '@/types/rollover';

/**
 * Pure Web Audio API two-tone alert chime (880Hz -> 1174.66Hz).
 * Works 100% offline with zero network calls or external MP3 dependencies.
 */
export function playProactiveExpiryChime() {
  if (typeof window === 'undefined') return;
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx) return;

    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const playNote = (freq: number, startOffset: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + startOffset);
      gain.gain.setValueAtTime(0.001, now + startOffset);
      gain.gain.exponentialRampToValueAtTime(0.12, now + startOffset + 0.02);
      gain.gain.exponentialRampToValueAtTime(
        0.0001,
        now + startOffset + duration
      );
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + startOffset);
      osc.stop(now + startOffset + duration + 0.02);
    };

    playNote(880, 0, 0.16);
    playNote(1174.66, 0.18, 0.24);
  } catch {
    // Gracefully ignore browser autoplay blocks until user interaction
  }
}

interface ContractRolloverPanelProps {
  portfolioId: string;
  onRolloverCompleted?: () => void;
}

export function ContractRolloverPanel({
  portfolioId,
  onRolloverCompleted,
}: ContractRolloverPanelProps) {
  const t = useTranslations('RolloverManager');
  const token = useAuthStore((s) => s.token);

  const [data, setData] =
    useState<ContractRolloverOverview>(mockRolloverOverview);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [wizardOpen, setWizardOpen] = useState(false);
  const [selectedAlert, setSelectedAlert] =
    useState<ExpiringContractAlert | null>(null);

  // Wizard Editable Inputs
  const [frontSymbol, setFrontSymbol] = useState('GOV26');
  const [frontMonth, setFrontMonth] = useState('V26');
  const [frontExpDate, setFrontExpDate] = useState('2026-10-29');
  const [frontClosePriceUSD, setFrontClosePriceUSD] = useState('2742.00');
  const [closeCommUSD, setCloseCommUSD] = useState('4.00');

  const [backSymbol, setBackSymbol] = useState('GOZ26');
  const [backMonth, setBackMonth] = useState('Z26');
  const [backExpDate, setBackExpDate] = useState('2026-12-29');
  const [backOpenPriceUSD, setBackOpenPriceUSD] = useState('2758.50');
  const [openCommUSD, setOpenCommUSD] = useState('4.00');

  const [rollWeight, setRollWeight] = useState('3.0000');
  const [fxRateUSDTHB, setFxRateUSDTHB] = useState('35.6000');

  const [previewAnalytics, setPreviewAnalytics] =
    useState<RolloverSpreadAnalytics | null>(null);
  const [executing, setExecuting] = useState(false);
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchRolloverData = useCallback(async () => {
    if (!token || !portfolioId || portfolioId.startsWith('mock-')) {
      setData(mockRolloverOverview);
      return;
    }
    try {
      const res = await api.get<ContractRolloverOverview>(
        '/gold/rollover/overview',
        {
          params: { portfolioId },
        }
      );
      setData(res.data);
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
    }
  }, [token, portfolioId, t]);

  useEffect(() => {
    void fetchRolloverData();
  }, [fetchRolloverData]);

  // Trigger audio alert once when urgent contracts (<= 7d) exist and audio is enabled
  useEffect(() => {
    const hasAudioAlert = data.activeAlerts.some((a) => a.shouldPlayAudioAlert);
    if (hasAudioAlert && audioEnabled) {
      playProactiveExpiryChime();
    }
  }, [data.activeAlerts, audioEnabled]);

  const openWizardForAlert = (alert: ExpiringContractAlert) => {
    setErrorMsg(null);
    setSelectedAlert(alert);
    setFrontSymbol(alert.symbol);
    setFrontMonth(alert.contractMonth);
    setFrontExpDate(alert.expirationDate);
    setFrontClosePriceUSD(alert.currentFrontPriceUSD);
    setCloseCommUSD('4.00');

    setBackSymbol(alert.suggestedBackSymbol);
    setBackMonth(alert.suggestedBackMonth);
    setBackExpDate(alert.suggestedBackExpirationDate);
    setBackOpenPriceUSD(alert.suggestedBackPriceUSD);
    setOpenCommUSD('4.00');

    setRollWeight(alert.openWeight);
    setFxRateUSDTHB(data.usdThbRate);
    setWizardOpen(true);
  };

  // Instant Client-Side + Server Preview Calculation
  const computedLivePreview = useMemo(() => {
    const w = Math.max(0, Number(rollWeight) || 0);
    const fPrice = Math.max(0, Number(frontClosePriceUSD) || 0);
    const bPrice = Math.max(0, Number(backOpenPriceUSD) || 0);
    const cComm = Math.max(0, Number(closeCommUSD) || 0);
    const oComm = Math.max(0, Number(openCommUSD) || 0);
    const fx = Math.max(1, Number(fxRateUSDTHB) || 35.6);

    const spreadUSD = bPrice - fPrice;
    const regime =
      spreadUSD > 0 ? 'CONTANGO' : spreadUSD < 0 ? 'BACKWARDATION' : 'FLAT';
    const spreadCostTHB = spreadUSD * w * fx;
    const totalCommTHB = (cComm + oComm) * fx;

    const entryCostUnitTHB = selectedAlert
      ? Number(selectedAlert.entryCostPerUnitTHB)
      : fPrice * 34.8;
    const closeProceedsTHB = (fPrice * w - cComm) * fx;
    const estRealizedTHB = closeProceedsTHB - entryCostUnitTHB * w;
    const newBasisTHB = (bPrice * w + oComm) * fx;

    return {
      spreadUSD: spreadUSD.toFixed(2),
      regime,
      spreadCostTHB: spreadCostTHB.toFixed(2),
      totalCommTHB: totalCommTHB.toFixed(2),
      estRealizedTHB: previewAnalytics
        ? previewAnalytics.estimatedCloseRealizedGLTHB
        : estRealizedTHB.toFixed(2),
      newBasisTHB: previewAnalytics
        ? previewAnalytics.newBackContractCostBasisTHB
        : newBasisTHB.toFixed(2),
    };
  }, [
    rollWeight,
    frontClosePriceUSD,
    backOpenPriceUSD,
    closeCommUSD,
    openCommUSD,
    fxRateUSDTHB,
    selectedAlert,
    previewAnalytics,
  ]);

  // Fetch exact Decimal server preview when wizard opens or prices change
  useEffect(() => {
    if (!wizardOpen || !token || !portfolioId || portfolioId.startsWith('mock-')) {
      setPreviewAnalytics(null);
      return;
    }

    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const res = await api.post<RolloverSpreadAnalytics>(
          '/gold/rollover/preview',
          {
            portfolioId,
            date: data.asOfDate,
            frontSymbol,
            frontContractMonth: frontMonth,
            frontExpirationDate: frontExpDate,
            frontClosePriceUSD,
            closeCommissionUSD: closeCommUSD,
            backSymbol,
            backContractMonth: backMonth,
            backExpirationDate: backExpDate,
            backOpenPriceUSD,
            openCommissionUSD: openCommUSD,
            weight: rollWeight,
            weightUnit: 'TROY_OUNCE',
            purity: '99.5',
            fxRateUSDTHB,
            allowAutoSeedWhenEmpty: true,
          }
        );
        if (!cancelled) {
          setPreviewAnalytics(res.data);
        }
      } catch {
        // Keep client fallback preview while editing
      }
    }, 180);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [
    wizardOpen,
    token,
    portfolioId,
    data.asOfDate,
    frontSymbol,
    frontMonth,
    frontExpDate,
    frontClosePriceUSD,
    closeCommUSD,
    backSymbol,
    backMonth,
    backExpDate,
    backOpenPriceUSD,
    openCommUSD,
    rollWeight,
    fxRateUSDTHB,
  ]);

  const handleConfirmExecuteRollover = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setExecuting(true);

    try {
      if (token && portfolioId && !portfolioId.startsWith('mock-')) {
        const res = await api.post<{
          rolloverGroupId: string;
          analytics: RolloverSpreadAnalytics;
        }>('/gold/rollover/execute', {
          portfolioId,
          date: data.asOfDate,
          frontSymbol,
          frontContractMonth: frontMonth,
          frontExpirationDate: frontExpDate,
          frontClosePriceUSD,
          closeCommissionUSD: closeCommUSD,
          backSymbol,
          backContractMonth: backMonth,
          backExpirationDate: backExpDate,
          backOpenPriceUSD,
          openCommissionUSD: openCommUSD,
          weight: rollWeight,
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          fxRateUSDTHB,
          allowAutoSeedWhenEmpty: true,
        });

        setSuccessBanner(
          t('rolloverSuccessDetailed', { front: frontSymbol, back: backSymbol, groupId: res.data.rolloverGroupId.slice(0, 8), realized: formatSignedTHB(res.data.analytics.estimatedCloseRealizedGLTHB), basis: formatTHB(res.data.analytics.newBackContractCostBasisTHB) })
        );
        await fetchRolloverData();
        onRolloverCompleted?.();
      } else {
        // Demo preview update
        const newGroupId = 'demo-roll-v26-to-z26';
        setData((prev) => ({
          ...prev,
          activeAlerts: prev.activeAlerts.map((a) =>
            a.symbol === frontSymbol
              ? {
                  ...a,
                  symbol: backSymbol,
                  contractMonth: backMonth,
                  expirationDate: backExpDate,
                  daysToExpiry: 64,
                  severity: 'SAFE',
                  shouldPlayAudioAlert: false,
                  currentFrontPriceUSD: backOpenPriceUSD,
                  suggestedBackSymbol: 'GOH27',
                  suggestedBackMonth: 'H27',
                }
              : a
          ),
          rolloverHistory: [
            {
              rolloverGroupId: newGroupId,
              executedDate: prev.asOfDate,
              frontSymbol,
              frontContractMonth: frontMonth,
              backSymbol,
              backContractMonth: backMonth,
              rolledWeight: rollWeight,
              weightUnit: 'TROY_OUNCE',
              frontClosePriceUSD,
              backOpenPriceUSD,
              rolloverSpreadUSD: computedLivePreview.spreadUSD,
              regime: computedLivePreview.regime as 'CONTANGO' | 'BACKWARDATION' | 'FLAT',
              spreadCostTHB: computedLivePreview.spreadCostTHB,
              realizedGLClosedLegTHB: computedLivePreview.estRealizedTHB,
              newOpenCostBasisTHB: computedLivePreview.newBasisTHB,
            },
            ...prev.rolloverHistory,
          ],
          summary: {
            ...prev.summary,
            urgentExpiringCount: Math.max(0, prev.summary.urgentExpiringCount - 1),
            totalRolloversExecuted: prev.summary.totalRolloversExecuted + 1,
          },
        }));
        setSuccessBanner(
          t('rolloverSuccessPreview', { front: frontSymbol, back: backSymbol, realized: formatSignedTHB(computedLivePreview.estRealizedTHB) })
        );
      }

      setWizardOpen(false);
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setExecuting(false);
    }
  };

  const termCurveData = useMemo(
    () =>
      data.contractCatalog
        .filter((c) => c.exchange === 'TFEX')
        .map((c) => ({
          symbol: c.symbol,
          priceUSD: Number(c.currentMarketPriceUSD),
          expDate: c.expirationDate,
        })),
    [data.contractCatalog]
  );

  return (
    <div className="space-y-6">
      {/* Proactive Urgent Expiry Alert Banner with Web Audio Toggle */}
      {data.summary.urgentExpiringCount > 0 && (
        <div
          data-testid="rollover-urgent-alert-banner"
          className="rounded-2xl border border-amber-300/90 bg-amber-50/90 p-4 sm:p-5 shadow-xs dark:border-amber-700/60 dark:bg-amber-950/35"
        >
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-start gap-3.5">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-600 text-white">
                <BellRing className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-amber-950 dark:text-amber-200">
                  {t('urgentBannerTitle', {
                    count: data.summary.urgentExpiringCount,
                  })}
                </h3>
                <p className="mt-0.5 text-xs text-amber-800 dark:text-amber-300/90">
                  {t('urgentBannerDesc')}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                data-testid="rollover-audio-toggle-btn"
                onClick={() => {
                  const next = !audioEnabled;
                  setAudioEnabled(next);
                  if (next) playProactiveExpiryChime();
                }}
                className="inline-flex items-center gap-1.5 rounded-xl border border-amber-300 bg-white px-3.5 py-2 text-xs font-semibold text-amber-900 shadow-2xs transition hover:bg-amber-100/60 dark:border-amber-700 dark:bg-gray-900 dark:text-amber-200"
              >
                {audioEnabled ? (
                  <>
                    <Volume2 className="h-3.5 w-3.5 text-amber-600" />
                    {t('audioBtnActive')}
                  </>
                ) : (
                  <>
                    <VolumeX className="h-3.5 w-3.5 text-gray-400" />
                    {t('audioBtnMuted')}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {successBanner && (
        <div
          data-testid="rollover-success-banner"
          className="flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/90 px-4 py-3.5 text-xs sm:text-sm font-semibold text-emerald-900 dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-200"
        >
          <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
          <span>{successBanner}</span>
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-semibold text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300">
          {errorMsg}
        </div>
      )}

      {/* 4 Rollover Summary KPIs */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiActiveContracts')}
            </span>
            <CalendarClock className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-gray-900 dark:text-gray-100">
            {t('seriesCount', { count: data.summary.activeFuturesContractsCount })}
          </p>
          <p className="mt-1 text-[11px] font-semibold text-amber-700 dark:text-amber-400">
            {t('kpiUrgentSub', { urgent: data.summary.urgentExpiringCount })}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiRealizedRollover')}
            </span>
            <Repeat className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            {formatSignedTHB(data.summary.cumulativeRealizedOnRolloversTHB)}
          </p>
          <p className="mt-1 text-[11px] text-gray-500 dark:text-gray-400">
            {t('kpiExecutedCountSub', {
              count: data.summary.totalRolloversExecuted,
            })}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiSpreadCost')}
            </span>
            <GitCompareArrows className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-gray-900 dark:text-gray-100">
            {formatTHB(data.summary.cumulativeSpreadCostTHB)}
          </p>
          <p className="mt-1 text-[11px] text-gray-500 dark:text-gray-400">
            {t('kpiSpreadSub')}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiNetImpact')}
            </span>
            <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-gray-900 dark:text-gray-100">
            {(Number(data.summary.netRolloverImpactPct) * 100).toFixed(2)}%
          </p>
          <p className="mt-1 text-[11px] text-gray-500 dark:text-gray-400">
            {t('kpiNetImpactSub')}
          </p>
        </div>
      </div>

      {/* Expiry Alert Queue + Futures Term Structure Curve */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm lg:col-span-7 dark:border-gray-800 dark:bg-[#1E1E1E]">
          <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
            {t('queueTitle')}
          </h2>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
            {t('queueSubtitle')}
          </p>

          <div className="mt-4 space-y-3">
            {data.activeAlerts.map((alert) => {
              const isUrgent = alert.daysToExpiry <= 7;
              return (
                <div
                  key={alert.lotId}
                  data-testid={`expiry-card-${alert.symbol}`}
                  className={cn(
                    'flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row sm:items-center sm:justify-between',
                    alert.daysToExpiry <= 3
                      ? 'border-red-200 bg-red-50/50 dark:border-red-900/50 dark:bg-red-950/20'
                      : isUrgent
                        ? 'border-amber-200 bg-amber-50/50 dark:border-amber-900/50 dark:bg-amber-950/20'
                        : 'border-gray-100 bg-[#F8FAFC] dark:border-gray-800 dark:bg-gray-900/50'
                  )}
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-sm font-bold text-gray-900 dark:text-white">
                        {alert.symbol}
                      </span>
                      <ArrowRight className="h-3.5 w-3.5 text-gray-400" />
                      <span className="font-mono text-sm font-bold text-[#14342a] dark:text-[#4ade80]">
                        {alert.suggestedBackSymbol}
                      </span>

                      <span
                        className={cn(
                          'rounded-full px-2.5 py-0.5 font-mono text-[11px] font-bold',
                          alert.daysToExpiry <= 3
                            ? 'bg-red-600 text-white'
                            : isUrgent
                              ? 'bg-amber-500 text-white'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        )}
                      >
                        {alert.daysToExpiry < 0
                          ? t('expiredBadge')
                          : t('daysLeftBadge', { days: alert.daysToExpiry })}
                      </span>

                      <span className="rounded-lg border border-gray-200 bg-white px-2 py-0.5 font-mono text-[10px] font-semibold text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">
                        {alert.regime} ({Number(alert.estimatedSpreadPerUnitUSD) >= 0 ? '+' : ''}$
                        {alert.estimatedSpreadPerUnitUSD}/{t('unitOunce')})
                      </span>
                    </div>

                    <p className="text-xs text-gray-600 dark:text-gray-300">
                      {t('openWeightLine', { weight: Number(alert.openWeight).toFixed(2) })} • {t('lastTradingDayLine', { date: alert.expirationDate })} • {t('frontBackPriceLine', { front: alert.currentFrontPriceUSD, back: alert.suggestedBackPriceUSD })}
                    </p>
                  </div>

                  <button
                    type="button"
                    data-testid={`execute-rollover-btn-${alert.symbol}`}
                    onClick={() => openWizardForAlert(alert)}
                    className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-xs transition hover:bg-[#1c4739] dark:bg-[#4ade80] dark:text-[#0d221b]"
                  >
                    <Repeat className="h-3.5 w-3.5" />
                    {t('executeRolloverBtn')}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* TFEX Gold Futures Term Structure Curve */}
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm lg:col-span-5 dark:border-gray-800 dark:bg-[#1E1E1E]">
          <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
            {t('termChartTitle')}
          </h2>
          <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
            {t('termChartSubtitle')}
          </p>

          <div className="mt-4 h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={termCurveData}
                margin={{ top: 10, right: 14, left: 0, bottom: 0 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#E5E7EB"
                />
                <XAxis
                  dataKey="symbol"
                  tick={{ fontSize: 11, fontWeight: 600 }}
                />
                <YAxis
                  domain={['dataMin - 15', 'dataMax + 15']}
                  tickFormatter={(v: number) => `$${v}`}
                  tick={{ fontSize: 11 }}
                />
                <Tooltip
                  formatter={(v: number) => [t('pricePerOunce', { value: v.toFixed(2) }), t('futuresQuoteLabel')]}
                  contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                />
                <Area
                  type="monotone"
                  dataKey="priceUSD"
                  stroke="#14342a"
                  strokeWidth={2.5}
                  fill="#14342a"
                  fillOpacity={0.12}
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Atomic Rollover History Table */}
      <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
          {t('historyTitle')}
        </h2>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-gray-100 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:text-gray-400">
                <th className="pb-3 pr-4">{t('colGroup')}</th>
                <th className="pb-3 pr-4">{t('colDate')}</th>
                <th className="pb-3 pr-4">{t('colPair')}</th>
                <th className="pb-3 pr-4">{t('colWeight')}</th>
                <th className="pb-3 pr-4">{t('colSpread')}</th>
                <th className="pb-3 pr-4 text-right">{t('colSpreadTHB')}</th>
                <th className="pb-3 pr-4 text-right">{t('colRealizedTHB')}</th>
                <th className="pb-3 text-right">{t('colNewBasisTHB')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {data.rolloverHistory.map((row) => (
                <tr key={row.rolloverGroupId}>
                  <td className="py-3.5 pr-4 font-mono text-xs text-gray-500">
                    #{row.rolloverGroupId.slice(0, 10)}
                  </td>
                  <td className="py-3.5 pr-4 font-mono text-xs text-gray-700 dark:text-gray-300">
                    {row.executedDate}
                  </td>
                  <td className="py-3.5 pr-4 font-mono font-bold text-gray-900 dark:text-white">
                    {row.frontSymbol} →{' '}
                    <span className="text-[#14342a] dark:text-[#4ade80]">
                      {row.backSymbol}
                    </span>
                  </td>
                  <td className="py-3.5 pr-4 font-mono text-xs">
                    {Number(row.rolledWeight).toFixed(2)} {t('unitOunce')}
                  </td>
                  <td className="py-3.5 pr-4 font-mono text-xs">
                    <span className="rounded-md bg-amber-50 px-2 py-0.5 font-semibold text-amber-800 dark:bg-amber-950/50 dark:text-amber-300">
                      {row.regime} (${row.rolloverSpreadUSD})
                    </span>
                  </td>
                  <td className="py-3.5 pr-4 text-right font-mono text-gray-800 dark:text-gray-200">
                    {formatTHB(row.spreadCostTHB)}
                  </td>
                  <td className="py-3.5 pr-4 text-right font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                    {formatSignedTHB(row.realizedGLClosedLegTHB)}
                  </td>
                  <td className="py-3.5 text-right font-mono font-semibold text-gray-900 dark:text-gray-100">
                    {formatTHB(row.newOpenCostBasisTHB)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Atomic Rollover Execution Wizard Modal */}
      <Dialog open={wizardOpen} onOpenChange={setWizardOpen}>
        <DialogContent
          data-testid="rollover-wizard-modal"
          className="max-w-2xl rounded-2xl p-6 sm:p-7"
        >
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl font-bold">
              {t('wizardTitle')}
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm leading-relaxed">
              {t('wizardSubtitle')}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleConfirmExecuteRollover} className="space-y-4">
            {/* Dual Leg Cards: Close Leg vs Open Leg */}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-red-200/80 bg-red-50/40 p-4 space-y-2.5 dark:border-red-900/50 dark:bg-red-950/20">
                <p className="text-xs font-bold text-red-800 dark:text-red-300">
                  {t('closeLegTitle')}
                </p>
                <div className="flex items-center justify-between font-mono text-xs">
                  <span className="font-bold text-gray-900 dark:text-white">
                    {frontSymbol} ({frontMonth})
                  </span>
                  <span className="text-gray-500">{t('expiryLabel', { date: frontExpDate })}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-gray-600 dark:text-gray-300">
                      {t('fieldFrontPrice')}
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={frontClosePriceUSD}
                      onChange={(e) => setFrontClosePriceUSD(e.target.value)}
                      className="h-9 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                      required
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-gray-600 dark:text-gray-300">
                      {t('fieldCommUSD')}
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={closeCommUSD}
                      onChange={(e) => setCloseCommUSD(e.target.value)}
                      className="h-9 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs dark:border-gray-700 dark:bg-gray-900"
                    />
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-emerald-200/80 bg-emerald-50/40 p-4 space-y-2.5 dark:border-emerald-900/50 dark:bg-emerald-950/20">
                <p className="text-xs font-bold text-[#14342a] dark:text-[#4ade80]">
                  {t('openLegTitle')}
                </p>
                <div className="flex items-center justify-between font-mono text-xs">
                  <span className="font-bold text-gray-900 dark:text-white">
                    {backSymbol} ({backMonth})
                  </span>
                  <span className="text-gray-500">{t('expiryLabel', { date: backExpDate })}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-gray-600 dark:text-gray-300">
                      {t('fieldBackPrice')}
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={backOpenPriceUSD}
                      onChange={(e) => setBackOpenPriceUSD(e.target.value)}
                      className="h-9 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                      required
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-[11px] font-semibold text-gray-600 dark:text-gray-300">
                      {t('fieldCommUSD')}
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={openCommUSD}
                      onChange={(e) => setOpenCommUSD(e.target.value)}
                      className="h-9 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs dark:border-gray-700 dark:bg-gray-900"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldRollWeight')}
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={rollWeight}
                  onChange={(e) => setRollWeight(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldFxRate')}
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={fxRateUSDTHB}
                  onChange={(e) => setFxRateUSDTHB(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>
            </div>

            {/* Pre-Trade Analytics Box */}
            <div className="rounded-2xl border border-gray-200 bg-[#F8FAFC] p-4 space-y-2 dark:border-gray-800 dark:bg-gray-900/70">
              <p className="text-xs font-bold text-gray-900 dark:text-gray-100">
                {t('previewTitle')}
              </p>
              <div className="grid grid-cols-1 gap-2.5 text-xs sm:grid-cols-2">
                <div className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2.5 dark:bg-gray-800">
                  <span className="text-gray-500">{t('previewSpreadLabel')}</span>
                  <span className="shrink-0 whitespace-nowrap font-mono font-bold text-amber-700 dark:text-amber-400">
                    ${computedLivePreview.spreadUSD} ({computedLivePreview.regime})
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2.5 dark:bg-gray-800">
                  <span className="text-gray-500">{t('previewSpreadTHBLabel')}</span>
                  <span className="shrink-0 whitespace-nowrap font-mono font-bold text-gray-900 dark:text-white">
                    {formatTHB(computedLivePreview.spreadCostTHB)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2.5 dark:bg-gray-800">
                  <span className="text-gray-500">{t('previewRealizedLabel')}</span>
                  <span className="shrink-0 whitespace-nowrap font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {formatSignedTHB(computedLivePreview.estRealizedTHB)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 rounded-xl bg-white px-3 py-2.5 dark:bg-gray-800">
                  <span className="text-gray-500">{t('previewNewBasisLabel')}</span>
                  <span className="shrink-0 whitespace-nowrap font-mono font-bold text-[#14342a] dark:text-[#4ade80]">
                    {formatTHB(computedLivePreview.newBasisTHB)}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-col-reverse gap-2 pt-1 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setWizardOpen(false)}
                className="rounded-xl border border-gray-200 px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300"
              >
                {t('cancelBtn')}
              </button>
              <button
                type="submit"
                disabled={executing}
                data-testid="rollover-confirm-execute-btn"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm transition hover:bg-[#1c4739] disabled:opacity-60 dark:bg-[#4ade80] dark:text-[#0d221b]"
              >
                <Repeat className="h-4 w-4" />
                {t('confirmExecuteBtn')}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
