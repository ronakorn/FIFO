'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import { useTranslations } from 'next-intl';
import {
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import {
  Coins,
  FileSearch,
  Landmark,
  Layers,
  Pause,
  Play,
  Plus,
  Radio,
  RefreshCcw,
  Repeat,
  Scale,
  ShieldCheck,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { Link } from '@/navigation';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLiveGoldPrices } from '@/hooks/useLiveGoldPrices';
import api from '@/lib/api';
import { usePortfolios } from '@/lib/queries';
import { useAuthStore } from '@/lib/stores';
import {
  cn,
  extractApiErrorMessage,
  formatSignedTHB,
  formatTHB,
} from '@/lib/utils';
import { mockGoldOverview } from '@/mocks/mockGold';
import { ContractRolloverPanel } from './ContractRolloverPanel';
import { GoldAttributionChart } from './GoldAttributionChart';
import type {
  GoldAssetSubclass,
  GoldLot,
  GoldOverviewSummary,
  GoldPurity,
  GoldSensitivityMatrixCell,
  GoldWeightUnit,
} from '@/types/gold';

const FrontendGoldDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

const DEC_GRAMS_PER_THAI_BAHT = new FrontendGoldDecimal('15.244');
const DEC_GRAMS_PER_TROY_OUNCE = new FrontendGoldDecimal('31.1034768');
const DEC_STANDARD_THAI_PURITY = new FrontendGoldDecimal('0.965');

const GOLD_SHOCK_ROWS = ['-0.1000', '-0.0500', '0.0000', '0.0500', '0.1000'];
const FX_SHOCK_COLS = ['-0.0500', '-0.0250', '0.0000', '0.0250', '0.0500'];

function formatUnitTranslationKey(unit: GoldWeightUnit): 'unitThaiBahtWeight' | 'unitGram' | 'unitTroyOunce' {
  switch (unit) {
    case 'THAI_BAHT':
      return 'unitThaiBahtWeight';
    case 'GRAM':
      return 'unitGram';
    case 'TROY_OUNCE':
      return 'unitTroyOunce';
  }
}

function formatSubclassTranslationKey(subclass: GoldAssetSubclass): 'subclassPhysicalGold' | 'subclassTfexGoldOnline' | 'subclassXauSpot' {
  switch (subclass) {
    case 'PHYSICAL_GOLD':
      return 'subclassPhysicalGold';
    case 'GOLD_ONLINE_FUTURES':
      return 'subclassTfexGoldOnline';
    case 'XAU_SPOT':
      return 'subclassXauSpot';
  }
}

export function GoldSensitivityWorkspace() {
  const t = useTranslations('GoldEngine');
  const tRollover = useTranslations('RolloverManager');
  const token = useAuthStore((s) => s.token);
  const { data: portfolios } = usePortfolios();

  const [mounted, setMounted] = useState(false);
  const [selectedPortfolioId, setSelectedPortfolioId] = useState<string>('');
  const [activeTab, setActiveTab] = useState<
    'overview' | 'sensitivity' | 'rollover'
  >('overview');

  const [overview, setOverview] =
    useState<GoldOverviewSummary>(mockGoldOverview);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Interactive Stress Simulator Sliders (% integer / half-step)
  const [goldShockPctInput, setGoldShockPctInput] = useState<number>(0);
  const [fxShockPctInput, setFxShockPctInput] = useState<number>(0);

  // Step 4: Real-Time Simulated WebSocket / 10-second Polling Hook (Decimal precision: 40)
  const liveFeed = useLiveGoldPrices({
    initialXauUsd: mockGoldOverview.market.xauUsdSpot,
    initialUsdThb: mockGoldOverview.market.usdThbRate,
    intervalMs: 10_000,
    autoStart: true,
  });

  // Add Gold Trade Modal State
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [txType, setTxType] = useState<'BUY' | 'SELL'>('BUY');
  const [assetSubclass, setAssetSubclass] =
    useState<GoldAssetSubclass>('PHYSICAL_GOLD');
  const [symbol, setSymbol] = useState('GOLD965');
  const [date, setDate] = useState('2026-10-26');
  const [weight, setWeight] = useState('5.00');
  const [weightUnit, setWeightUnit] = useState<GoldWeightUnit>('THAI_BAHT');
  const [purity, setPurity] = useState<GoldPurity>('96.5');
  const [spotPricePerUnit, setSpotPricePerUnit] = useState('46200.00');
  const [premiumPerUnit, setPremiumPerUnit] = useState('250.00');
  const [commission, setCommission] = useState('0.00');
  const [fxRateAtPurchase, setFxRateAtPurchase] = useState('35.60');
  const [botFxAutoMeta, setBotFxAutoMeta] = useState<{
    date: string;
    rate: string;
  }>({ date: '2026-10-26', rate: '35.60' });
  const [submittingTx, setSubmittingTx] = useState(false);

  // Step 2 & 4: Roll Position Modal State (Gold Futures Rollover Manager)
  const [rollModalOpen, setRollModalOpen] = useState(false);
  const [rollTargetLot, setRollTargetLot] = useState<GoldLot | null>(null);
  const [rollNewSymbol, setRollNewSymbol] = useState('GOH27');
  const [rollNewQty, setRollNewQty] = useState('3.0000');
  const [rollNewPrice, setRollNewPrice] = useState('2781.00');
  const [rollClosePrice, setRollClosePrice] = useState('2758.50');
  const [rollFee, setRollFee] = useState('12.50');
  const [rollDate, setRollDate] = useState('2026-10-26');
  const [rollSubmitting, setRollSubmitting] = useState(false);
  const [rollSuccessBanner, setRollSuccessBanner] = useState<string | null>(
    null
  );

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!selectedPortfolioId && portfolios && portfolios.length > 0) {
      const first = portfolios[0];
      if (first && !first.id.startsWith('mock-')) {
        setSelectedPortfolioId(first.id);
      }
    }
  }, [portfolios, selectedPortfolioId]);

  const fetchGoldOverview = useCallback(
    async (gShock = goldShockPctInput, fShock = fxShockPctInput) => {
      if (!token) {
        // Client-side multiplicative scaling on mock overview when in unauthenticated preview
        const mult = (1 + gShock / 100) * (1 + fShock / 100);
        const baseMkt = Number(mockGoldOverview.totalMarketValueTHB);
        const baseCost = Number(mockGoldOverview.totalCostBasisTHB);
        const projMkt = baseMkt * mult;
        const projUnreal = projMkt - baseCost;
        setOverview({
          ...mockGoldOverview,
          market: {
            ...mockGoldOverview.market,
            xauUsdSpot: (2740 * (1 + gShock / 100)).toFixed(2),
            usdThbRate: (35.6 * (1 + fShock / 100)).toFixed(4),
            gtaGold965SellTHB: (46450 * mult).toFixed(2),
          },
          totalMarketValueTHB: projMkt.toFixed(2),
          totalUnrealizedGLTHB: projUnreal.toFixed(2),
        });
        return;
      }

      setLoading(true);
      setErrorMsg(null);
      try {
        const { data } = await api.get<GoldOverviewSummary>('/gold/overview', {
          params: {
            portfolioId: selectedPortfolioId || undefined,
            goldShockPct: (gShock / 100).toFixed(4),
            fxShockPct: (fShock / 100).toFixed(4),
          },
        });
        setOverview(data);
        if (!selectedPortfolioId && data.portfolioId) {
          setSelectedPortfolioId(data.portfolioId);
        }
      } catch (err) {
        setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
      } finally {
        setLoading(false);
      }
    },
    [token, selectedPortfolioId, goldShockPctInput, fxShockPctInput, t]
  );

  useEffect(() => {
    if (mounted) {
      void fetchGoldOverview(goldShockPctInput, fxShockPctInput);
    }
  }, [mounted, fetchGoldOverview, goldShockPctInput, fxShockPctInput]);

  // Step 1: Automated BOT Historical FX Rate Auto-Fetch whenever Transaction Date changes in Add Modal
  useEffect(() => {
    if (!addModalOpen || !date || date.length < 10) return;
    let cancelled = false;
    const isoDate = date.slice(0, 10);

    const fallbackRates: Record<string, string> = {
      '2024-10-01': '36.75',
      '2024-10-04': '36.90',
      '2025-01-15': '34.65',
      '2026-03-15': '34.20',
      '2026-07-20': '35.10',
      '2026-10-26': '35.60',
    };

    const runBotFetch = async () => {
      if (!token) {
        const localRate = fallbackRates[isoDate] ?? '35.60';
        if (!cancelled) {
          setFxRateAtPurchase(localRate);
          setBotFxAutoMeta({ date: isoDate, rate: localRate });
        }
        return;
      }

      try {
        const res = await api.get<{ rate: string; date: string }>(
          '/gold/fx-rate',
          {
            params: { currency: 'USD', date: isoDate },
          }
        );
        if (!cancelled && res.data.rate) {
          setFxRateAtPurchase(res.data.rate);
          setBotFxAutoMeta({ date: isoDate, rate: res.data.rate });
        }
      } catch {
        const localRate = fallbackRates[isoDate] ?? '35.60';
        if (!cancelled) {
          setFxRateAtPurchase(localRate);
          setBotFxAutoMeta({ date: isoDate, rate: localRate });
        }
      }
    };

    void runBotFetch();
    return () => {
      cancelled = true;
    };
  }, [addModalOpen, date, token]);

  const openRollPositionModal = (lot: GoldLot) => {
    setErrorMsg(null);
    setRollTargetLot(lot);
    const nextSeriesMap: Record<string, { sym: string; close: string; open: string }> = {
      GOV26: { sym: 'GOZ26', close: '2742.00', open: '2758.50' },
      GOZ26: { sym: 'GOH27', close: '2758.50', open: '2781.00' },
      GOH27: { sym: 'GOM27', close: '2781.00', open: '2802.00' },
      GCX26: { sym: 'GCZ26', close: '2746.50', open: '2761.00' },
    };
    const preset = nextSeriesMap[lot.symbol.toUpperCase()] ?? {
      sym: `${lot.symbol.slice(0, 2)}H27`,
      close: '2758.50',
      open: '2781.00',
    };
    setRollNewSymbol(preset.sym);
    setRollNewQty(lot.weightRemain);
    setRollClosePrice(preset.close);
    setRollNewPrice(preset.open);
    setRollFee('12.50');
    setRollDate('2026-10-26');
    setRollModalOpen(true);
  };

  const liveRollPreview = useMemo(() => {
    const qtyDec = FrontendGoldDecimal.max(
      0,
      new FrontendGoldDecimal(rollNewQty || '0')
    );
    const openDec = FrontendGoldDecimal.max(
      0,
      new FrontendGoldDecimal(rollNewPrice || '0')
    );
    const closeDec = FrontendGoldDecimal.max(
      0,
      new FrontendGoldDecimal(rollClosePrice || '0')
    );
    const feeDec = FrontendGoldDecimal.max(
      0,
      new FrontendGoldDecimal(rollFee || '0')
    );
    const fxDec = FrontendGoldDecimal.max(
      1,
      new FrontendGoldDecimal(liveFeed.usdThb || '35.6000')
    );

    const spreadUSD = openDec.minus(closeDec);
    const newBasisUSD = openDec.times(qtyDec).plus(feeDec);
    const newBasisTHB = newBasisUSD.times(fxDec);
    const feeTHB = feeDec.times(fxDec);

    return {
      spreadUSD: spreadUSD.toFixed(2),
      feeUSD: feeDec.toFixed(2),
      feeTHB: feeTHB.toFixed(2),
      newBasisUSD: newBasisUSD.toFixed(2),
      newBasisTHB: newBasisTHB.toFixed(2),
      fxRate: fxDec.toFixed(4),
    };
  }, [rollNewQty, rollNewPrice, rollClosePrice, rollFee, liveFeed.usdThb]);

  const handleConfirmRollPosition = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rollTargetLot) return;
    setErrorMsg(null);
    setRollSubmitting(true);

    try {
      const targetPortId = selectedPortfolioId || overview.portfolioId;
      if (token && targetPortId && !targetPortId.startsWith('mock-')) {
        const res = await api.post<{
          rolloverGroupId: string;
          rolloverFee: string;
          rolloverFeeTHB: string;
          newInitialCostBasisTHB: string;
        }>(`/gold/transactions/${rollTargetLot.transactionId}/rollover`, {
          portfolioId: targetPortId,
          newContractSymbol: rollNewSymbol.trim().toUpperCase(),
          newQty: rollNewQty,
          newPrice: rollNewPrice,
          rolloverFee: rollFee,
          closePrice: rollClosePrice,
          executionDate: rollDate,
        });

        setRollSuccessBanner(
          t('rollSuccessWithAudit', { symbol: rollTargetLot.symbol, newSymbol: rollNewSymbol.toUpperCase(), groupId: res.data.rolloverGroupId.slice(0, 8), feeUSD: res.data.rolloverFee, feeTHB: formatTHB(res.data.rolloverFeeTHB), costBasis: formatTHB(res.data.newInitialCostBasisTHB) })
        );
        await fetchGoldOverview(goldShockPctInput, fxShockPctInput);
      } else {
        setRollSuccessBanner(
          t('rollSuccessPreview', { symbol: rollTargetLot.symbol, newSymbol: rollNewSymbol.toUpperCase(), feeUSD: liveRollPreview.feeUSD, feeTHB: formatTHB(liveRollPreview.feeTHB) })
        );
      }
      setRollModalOpen(false);
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setRollSubmitting(false);
    }
  };

  // Preset Subclass Defaults when user switches assetSubclass in Modal
  const handleSubclassChange = (nextSubclass: GoldAssetSubclass) => {
    setAssetSubclass(nextSubclass);
    if (nextSubclass === 'PHYSICAL_GOLD') {
      setSymbol('GOLD965');
      setWeightUnit('THAI_BAHT');
      setPurity('96.5');
      setSpotPricePerUnit('46200.00');
      setPremiumPerUnit('250.00');
      setCommission('0.00');
    } else if (nextSubclass === 'XAU_SPOT') {
      setSymbol('XAUUSD');
      setWeightUnit('TROY_OUNCE');
      setPurity('99.99');
      setSpotPricePerUnit('2740.00');
      setPremiumPerUnit('1.20');
      setCommission('5.00');
    } else {
      setSymbol('GOZ26');
      setWeightUnit('TROY_OUNCE');
      setPurity('99.5');
      setSpotPricePerUnit('2752.00');
      setPremiumPerUnit('1.50');
      setCommission('6.00');
    }
  };

  // Step 3: UX Guard — Check remaining FIFO Holdings for selected Purity when Type === 'SELL'
  const selectedPurityRemainingWeight = useMemo(() => {
    return overview.lots
      .filter((lot) => lot.purity === purity)
      .reduce(
        (acc, lot) =>
          acc.plus(new FrontendGoldDecimal(lot.weightRemain || '0')),
        new FrontendGoldDecimal(0)
      );
  }, [overview.lots, purity]);

  const showPurityMismatchWarning =
    txType === 'SELL' && selectedPurityRemainingWeight.lte(0);

  // Live Weight & Total Settlement Preview in Modal (Decimal.js precision: 40)
  const liveModalPreview = useMemo(() => {
    const w = FrontendGoldDecimal.max(0, new FrontendGoldDecimal(weight || '0'));
    const spot = FrontendGoldDecimal.max(
      0,
      new FrontendGoldDecimal(spotPricePerUnit || '0')
    );
    const prem = FrontendGoldDecimal.max(
      0,
      new FrontendGoldDecimal(premiumPerUnit || '0')
    );
    const comm = FrontendGoldDecimal.max(
      0,
      new FrontendGoldDecimal(commission || '0')
    );
    const fx = FrontendGoldDecimal.max(
      1,
      new FrontendGoldDecimal(fxRateAtPurchase || '35.6000')
    );

    const grams =
      weightUnit === 'GRAM'
        ? w
        : weightUnit === 'THAI_BAHT'
          ? w.times(DEC_GRAMS_PER_THAI_BAHT)
          : w.times(DEC_GRAMS_PER_TROY_OUNCE);
    const baht = grams.dividedBy(DEC_GRAMS_PER_THAI_BAHT);
    const oz = grams.dividedBy(DEC_GRAMS_PER_TROY_OUNCE);

    const gross = spot.plus(prem).times(w);
    const nativeTotal =
      txType === 'BUY' ? gross.plus(comm) : gross.minus(comm);
    const isUsd =
      assetSubclass === 'XAU_SPOT' || assetSubclass === 'GOLD_ONLINE_FUTURES';
    const thbTotal = isUsd ? nativeTotal.times(fx) : nativeTotal;

    return {
      grams: grams.toFixed(2),
      baht: baht.toFixed(4),
      oz: oz.toFixed(4),
      nativeCurrency: isUsd ? 'USD' : 'THB',
      nativeTotal: nativeTotal.toFixed(2),
      thbTotal: thbTotal.toFixed(2),
    };
  }, [
    weight,
    weightUnit,
    spotPricePerUnit,
    premiumPerUnit,
    commission,
    fxRateAtPurchase,
    txType,
    assetSubclass,
  ]);

  const handleCreateGoldTrade = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmittingTx(true);

    try {
      const targetPortId = selectedPortfolioId || overview.portfolioId;
      if (token && targetPortId && !targetPortId.startsWith('mock-')) {
        await api.post('/gold/transactions', {
          portfolioId: targetPortId,
          date,
          symbol: symbol.trim().toUpperCase(),
          assetSubclass,
          weight,
          weightUnit,
          purity,
          spotPricePerUnit,
          premiumPerUnit,
          commission,
          fxRateAtPurchase,
          type: txType,
        });
        await fetchGoldOverview(goldShockPctInput, fxShockPctInput);
      }
      setAddModalOpen(false);
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setSubmittingTx(false);
    }
  };

  // Recharts Data
  const pieData = useMemo(
    () => [
      {
        name: t('physicalLabel'),
        value: Number(overview.breakdown.physicalGold.totalValueTHB),
        color: '#14342a',
      },
      {
        name: t('paperLabel'),
        value: Number(overview.breakdown.paperGold.totalValueTHB),
        color: '#D97706',
      },
    ],
    [overview.breakdown, t]
  );

  // Step 1: Scalar primitives for strict 5×5 Sensitivity Matrix memoization
  const currentWeight = overview.totalEquivalentBaht965;

  const avgCost = useMemo<string>(() => {
    const weightDec = new FrontendGoldDecimal(currentWeight || '0');
    const costBasisDec = new FrontendGoldDecimal(
      overview.totalCostBasisTHB || '0'
    );
    if (weightDec.lte(0)) return '0';
    return costBasisDec.dividedBy(weightDec).toString();
  }, [overview.totalCostBasisTHB, currentWeight]);

  const currentXauUsd = useMemo<string>(() => {
    const baseXau = new FrontendGoldDecimal(liveFeed.xauUsd);
    const gShock = new FrontendGoldDecimal(goldShockPctInput).dividedBy(100);
    return baseXau.times(new FrontendGoldDecimal(1).plus(gShock)).toFixed(2);
  }, [liveFeed.xauUsd, goldShockPctInput]);

  const currentUsdThb = useMemo<string>(() => {
    const baseFx = new FrontendGoldDecimal(liveFeed.usdThb);
    const fShock = new FrontendGoldDecimal(fxShockPctInput).dividedBy(100);
    return baseFx.times(new FrontendGoldDecimal(1).plus(fShock)).toFixed(4);
  }, [liveFeed.usdThb, fxShockPctInput]);

  /**
   * Step 1: Performance Optimization (5×5 Sensitivity Matrix)
   * Strictly memoized with `useMemo` and `Decimal.js` (precision: 40) so it ONLY
   * recalculates when `currentWeight`, `avgCost`, `currentXauUsd`, or `currentUsdThb` changes.
   */
  const matrixLookup = useMemo<Map<string, GoldSensitivityMatrixCell>>(() => {
    const map = new Map<string, GoldSensitivityMatrixCell>();
    const weightDec = new FrontendGoldDecimal(currentWeight || '0');
    const avgCostDec = new FrontendGoldDecimal(avgCost || '0');
    const spotXauDec = new FrontendGoldDecimal(currentXauUsd || '2740.00');
    const spotFxDec = new FrontendGoldDecimal(currentUsdThb || '35.6000');
    const one = new FrontendGoldDecimal(1);

    const totalCostBasisTHB = weightDec.times(avgCostDec);

    for (const gRow of GOLD_SHOCK_ROWS) {
      const gShock = new FrontendGoldDecimal(gRow);
      const projectedXau = spotXauDec.times(one.plus(gShock));

      for (const fxCol of FX_SHOCK_COLS) {
        const fShock = new FrontendGoldDecimal(fxCol);
        const projectedFx = spotFxDec.times(one.plus(fShock));

        // GTA Theoretical 96.5% Baht Parity: XAUUSD × (15.244 / 31.1034768) × 0.965 × USDTHB
        const projectedGold965THB = projectedXau
          .times(DEC_GRAMS_PER_THAI_BAHT)
          .dividedBy(DEC_GRAMS_PER_TROY_OUNCE)
          .times(DEC_STANDARD_THAI_PURITY)
          .times(projectedFx);

        const projectedPortfolioValueTHB =
          weightDec.times(projectedGold965THB);
        const projectedNetGLTHB =
          projectedPortfolioValueTHB.minus(totalCostBasisTHB);
        const projectedReturnPct = totalCostBasisTHB.gt(0)
          ? projectedNetGLTHB.dividedBy(totalCostBasisTHB)
          : new FrontendGoldDecimal(0);

        map.set(`${gRow}|${fxCol}`, {
          goldShockPct: gShock.toFixed(4),
          fxShockPct: fShock.toFixed(4),
          projectedXauUsd: projectedXau.toFixed(2),
          projectedUsdThb: projectedFx.toFixed(4),
          projectedGold965THB: projectedGold965THB.toFixed(2),
          projectedPortfolioValueTHB: projectedPortfolioValueTHB.toFixed(2),
          projectedNetGLTHB: projectedNetGLTHB.toFixed(2),
          projectedReturnPct: projectedReturnPct.toFixed(4),
        });
      }
    }
    return map;
  }, [currentWeight, avgCost, currentXauUsd, currentUsdThb]);

  // Live Dashboard KPI Valuation synchronized with `useLiveGoldPrices` (Decimal precision: 40)
  const liveDashboardValuation = useMemo(() => {
    const baseSnapshotXau = new FrontendGoldDecimal(
      overview.market.xauUsdSpot || '2740.00'
    );
    const baseSnapshotFx = new FrontendGoldDecimal(
      overview.market.usdThbRate || '35.6000'
    );
    const activeXau = new FrontendGoldDecimal(currentXauUsd || '2740.00');
    const activeFx = new FrontendGoldDecimal(currentUsdThb || '35.6000');

    const xauRatio = baseSnapshotXau.gt(0)
      ? activeXau.dividedBy(baseSnapshotXau)
      : new FrontendGoldDecimal(1);
    const fxRatio = baseSnapshotFx.gt(0)
      ? activeFx.dividedBy(baseSnapshotFx)
      : new FrontendGoldDecimal(1);
    const combinedRatio = xauRatio.times(fxRatio);

    const liveMktVal = new FrontendGoldDecimal(
      overview.totalMarketValueTHB || '0'
    ).times(combinedRatio);
    const costBasis = new FrontendGoldDecimal(
      overview.totalCostBasisTHB || '0'
    );
    const liveUnreal = liveMktVal.minus(costBasis);
    const liveGta965 = new FrontendGoldDecimal(
      overview.market.gtaGold965SellTHB || '46450.00'
    ).times(combinedRatio);

    return {
      marketValueTHB: liveMktVal.toFixed(2),
      unrealizedGLTHB: liveUnreal.toFixed(2),
      gtaGold965THB: liveGta965.toFixed(2),
    };
  }, [
    overview.market.xauUsdSpot,
    overview.market.usdThbRate,
    overview.market.gtaGold965SellTHB,
    overview.totalMarketValueTHB,
    overview.totalCostBasisTHB,
    currentXauUsd,
    currentUsdThb,
  ]);

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
            {t('eyebrow')}
          </p>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {t('title')}
          </h1>
          <p className="mt-1 max-w-3xl text-xs sm:text-sm leading-relaxed text-gray-500 dark:text-gray-400">
            {t('subtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {mounted && portfolios && portfolios.length > 0 && (
            <select
              aria-label={t('selectGoldPortfolio')}
              value={selectedPortfolioId}
              onChange={(e) => setSelectedPortfolioId(e.target.value)}
              className="h-10 rounded-xl border border-gray-200 bg-white px-3.5 text-xs font-semibold text-gray-800 shadow-xs focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#1E1E1E] dark:text-gray-100"
            >
              {portfolios.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.baseCurrency})
                </option>
              ))}
            </select>
          )}

          <Link
            href="/admin/audit-logs"
            data-testid="gold-open-audit-logs-link"
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs sm:text-sm font-semibold text-gray-800 shadow-2xs transition hover:bg-gray-50 dark:border-gray-700 dark:bg-[#1E1E1E] dark:text-gray-100"
          >
            <FileSearch className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
            {t('auditTrailLink')}
          </Link>

          <button
            type="button"
            data-testid="gold-open-add-modal"
            onClick={() => {
              setErrorMsg(null);
              setAddModalOpen(true);
            }}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm transition hover:bg-[#1c4739] dark:bg-[#4ade80] dark:text-[#0d221b]"
          >
            <Plus className="h-4 w-4" />
            {t('addTradeBtn')}
          </button>
        </div>
      </div>

      {rollSuccessBanner && (
        <div
          data-testid="gold-roll-success-banner"
          className="rounded-2xl border border-emerald-200 bg-emerald-50/90 px-4 py-3 text-xs sm:text-sm font-semibold text-emerald-900 dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-200"
        >
          {rollSuccessBanner}
        </div>
      )}

      {errorMsg && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300">
          {errorMsg}
        </div>
      )}

      {/* 4 Executive KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiMarketValue')}
            </span>
            <Coins className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          </div>
          <p
            data-testid="gold-total-market-value"
            className="mt-2 font-mono text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100"
          >
            {formatTHB(liveDashboardValuation.marketValueTHB)}
          </p>
          <p className="mt-1 text-[11px] font-medium text-gray-500 dark:text-gray-400">
            {t('kpiEquivWeight', {
              baht: Number(overview.totalEquivalentBaht965).toFixed(2),
              grams: Number(overview.totalFineGoldGrams).toFixed(1),
            })}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiGtaParity')}
            </span>
            <Scale className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <p className="font-mono text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
              {formatTHB(liveDashboardValuation.gtaGold965THB)}
            </p>
            <span className="font-mono text-xs text-gray-400">
              / {t('perThaiBaht')}
            </span>
          </div>
          <p className="mt-1 text-[11px] font-medium text-amber-700 dark:text-amber-400">
            {t('kpiDomesticPremium', {
              diff:
                Number(overview.market.domesticPremiumTHB) >= 0
                  ? `+${overview.market.domesticPremiumTHB}`
                  : overview.market.domesticPremiumTHB,
              pct: (Number(overview.market.domesticPremiumPct) * 100).toFixed(
                2
              ),
            })}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiUnrealizedGL')}
            </span>
            <TrendingUp className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p
            className={cn(
              'mt-2 font-mono text-2xl font-bold tracking-tight',
              Number(liveDashboardValuation.unrealizedGLTHB) >= 0
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-red-600 dark:text-red-400'
            )}
          >
            {formatSignedTHB(liveDashboardValuation.unrealizedGLTHB)}
          </p>
          <p className="mt-1 text-[11px] font-medium text-gray-500 dark:text-gray-400">
            {t('kpiRealizedSub', {
              realized: formatSignedTHB(overview.totalRealizedGLTHB),
            })}
            {overview.taxExemptRealizedGLTHB &&
              Number(overview.taxExemptRealizedGLTHB) > 0 && (
                <span className="ml-1.5 font-semibold text-[#14342a] dark:text-[#4ade80]">
                  • {t('taxExemptBullion')}{' '}
                  {formatTHB(overview.taxExemptRealizedGLTHB)}
                </span>
              )}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiBlockPremium')}
            </span>
            <Layers className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {formatTHB(overview.totalPremiumPaidTHB)}
          </p>
          <p className="mt-1 text-[11px] font-medium text-gray-500 dark:text-gray-400">
            {t('kpiPremiumDrag', {
              pct: (Number(overview.premiumDragPct) * 100).toFixed(2),
            })}
          </p>
        </div>
      </div>

      {/* Proactive Futures Expiry Strip when viewing Overview/Sensitivity tabs */}
      {activeTab !== 'rollover' && (
        <div
          data-testid="gold-proactive-rollover-strip"
          className="flex flex-col gap-3 rounded-2xl border border-amber-300/80 bg-amber-50/80 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between dark:border-amber-700/60 dark:bg-amber-950/30"
        >
          <div className="flex items-center gap-3">
            <span className="inline-flex h-2.5 w-2.5 shrink-0 rounded-full bg-amber-500" />
            <p className="text-xs sm:text-sm font-semibold text-amber-950 dark:text-amber-200">
              {tRollover('urgentBannerTitle', { count: 2 })} —{' '}
              <span className="font-mono font-bold">GOV26 (3d)</span>,{' '}
              <span className="font-mono font-bold">GCX26 (7d)</span>
            </p>
          </div>
          <button
            type="button"
            data-testid="jump-to-rollover-tab-btn"
            onClick={() => setActiveTab('rollover')}
            className="inline-flex shrink-0 items-center justify-center rounded-xl bg-[#14342a] px-3.5 py-2 text-xs font-semibold text-white shadow-2xs transition hover:bg-[#1c4739] dark:bg-[#4ade80] dark:text-[#0d221b]"
          >
            {tRollover('openManagerBtn')}
          </button>
        </div>
      )}

      {/* Main Analytics Tabs */}
      <Tabs
        value={activeTab}
        onValueChange={(v) =>
          setActiveTab(v as 'overview' | 'sensitivity' | 'rollover')
        }
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <TabsList className="flex-wrap">
            <TabsTrigger value="overview" data-testid="gold-tab-overview">
              {t('tabOverview')}
            </TabsTrigger>
            <TabsTrigger value="sensitivity" data-testid="gold-tab-sensitivity">
              {t('tabSensitivity')}
            </TabsTrigger>
            <TabsTrigger value="rollover" data-testid="gold-tab-rollover">
              {t('tabRollover')}
            </TabsTrigger>
          </TabsList>

          <div
            data-testid="gold-live-price-ticker"
            className="flex flex-wrap items-center gap-2.5 rounded-xl border border-gray-200/80 bg-white px-3.5 py-1.5 font-mono text-xs text-gray-700 shadow-2xs dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-200"
          >
            <span
              className={cn(
                'inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[10px] font-bold tracking-wide',
                liveFeed.status === 'LIVE'
                  ? 'bg-emerald-50 text-[#14342a] dark:bg-emerald-950/60 dark:text-[#4ade80]'
                  : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
              )}
            >
              <Radio
                className={cn(
                  'h-3 w-3',
                  liveFeed.status === 'LIVE' &&
                    'animate-pulse text-emerald-600 dark:text-[#4ade80]'
                )}
              />
              {liveFeed.status === 'LIVE' ? t('feedLive') : t('feedPaused')}
            </span>

            <span>
              XAU/USD: <strong>${currentXauUsd}</strong>
              {liveFeed.tickCount > 0 && (
                <span
                  className={cn(
                    'ml-1 text-[11px] font-semibold',
                    liveFeed.xauDirection === 'UP'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : liveFeed.xauDirection === 'DOWN'
                        ? 'text-red-600 dark:text-red-400'
                        : 'text-gray-400'
                  )}
                >
                  ({Number(liveFeed.xauDelta) >= 0 ? '+' : ''}
                  {liveFeed.xauDelta})
                </span>
              )}
            </span>

            <span className="text-gray-300 dark:text-gray-700">•</span>

            <span>
              USD/THB: <strong>{currentUsdThb}</strong>
              {liveFeed.tickCount > 0 && (
                <span
                  className={cn(
                    'ml-1 text-[11px] font-semibold',
                    liveFeed.fxDirection === 'UP'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : liveFeed.fxDirection === 'DOWN'
                        ? 'text-red-600 dark:text-red-400'
                        : 'text-gray-400'
                  )}
                >
                  ({Number(liveFeed.fxDelta) >= 0 ? '+' : ''}
                  {liveFeed.fxDelta})
                </span>
              )}
            </span>

            <div className="flex items-center gap-1 border-l border-gray-200 pl-2 dark:border-gray-700">
              <button
                type="button"
                title={t('simulateNextTick')}
                data-testid="gold-live-tick-btn"
                onClick={liveFeed.simulateNextTick}
                className="rounded-lg p-1 text-gray-500 transition hover:bg-gray-100 hover:text-[#14342a] dark:hover:bg-gray-800 dark:hover:text-[#4ade80]"
              >
                <RefreshCcw
                  className={cn('h-3.5 w-3.5', loading && 'animate-spin')}
                />
              </button>
              <button
                type="button"
                title={t('togglePriceFeed')}
                data-testid="gold-live-toggle-btn"
                onClick={liveFeed.toggleLiveFeed}
                className="rounded-lg p-1 text-gray-500 transition hover:bg-gray-100 hover:text-[#14342a] dark:hover:bg-gray-800 dark:hover:text-[#4ade80]"
              >
                {liveFeed.status === 'LIVE' ? (
                  <Pause className="h-3.5 w-3.5" />
                ) : (
                  <Play className="h-3.5 w-3.5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* TAB 1: Holdings Breakdown, Return Attribution & Gold FIFO Lots */}
        <TabsContent value="overview" className="mt-4 space-y-6">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Physical vs Paper Gold Breakdown Card */}
            <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm lg:col-span-5 dark:border-gray-800 dark:bg-[#1E1E1E]">
              <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
                {t('breakdownTitle')}
              </h2>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {t('breakdownSubtitle')}
              </p>

              <div className="mt-4 grid grid-cols-1 items-center gap-4 sm:grid-cols-2">
                <div className="h-48 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        dataKey="value"
                        nameKey="name"
                        innerRadius={52}
                        outerRadius={76}
                        paddingAngle={3}
                        isAnimationActive={false}
                      >
                        {pieData.map((entry, idx) => (
                          <Cell key={idx} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(val: number) => formatTHB(val)}
                        contentStyle={{
                          borderRadius: '12px',
                          fontSize: '12px',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-3">
                  <div className="rounded-xl border border-gray-100 bg-[#F8FAFC] p-3 dark:border-gray-800 dark:bg-gray-900/60">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="flex items-center gap-1.5 text-gray-800 dark:text-gray-200">
                        <span className="h-2.5 w-2.5 rounded-full bg-[#14342a]" />
                        {t('physicalLabel')}
                      </span>
                      <span className="font-mono text-[#14342a] dark:text-[#4ade80]">
                        {overview.breakdown.physicalGold.percentage}%
                      </span>
                    </div>
                    <p className="mt-1 font-mono text-sm font-bold text-gray-900 dark:text-gray-100">
                      {formatTHB(overview.breakdown.physicalGold.totalValueTHB)}
                    </p>
                    <p className="font-mono text-[11px] text-gray-500">
                      {Number(
                        overview.breakdown.physicalGold.totalWeight
                      ).toFixed(2)}{' '}
                      {t('equivalentBahtWeight')}
                    </p>
                  </div>

                  <div className="rounded-xl border border-gray-100 bg-[#F8FAFC] p-3 dark:border-gray-800 dark:bg-gray-900/60">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className="flex items-center gap-1.5 text-gray-800 dark:text-gray-200">
                        <span className="h-2.5 w-2.5 rounded-full bg-[#D97706]" />
                        {t('paperLabel')}
                      </span>
                      <span className="font-mono text-amber-700 dark:text-amber-400">
                        {overview.breakdown.paperGold.percentage}%
                      </span>
                    </div>
                    <p className="mt-1 font-mono text-sm font-bold text-gray-900 dark:text-gray-100">
                      {formatTHB(overview.breakdown.paperGold.totalValueTHB)}
                    </p>
                    <p className="font-mono text-[11px] text-gray-500">
                      {Number(overview.breakdown.paperGold.totalWeight).toFixed(
                        2
                      )}{' '}
                      {t('equivalentBahtWeight')}
                    </p>
                  </div>
                </div>
              </div>

              {overview.breakdown.paperGold.marginRequirement && (
                <div className="mt-4 flex items-center gap-2 rounded-xl border border-amber-200/80 bg-amber-50/70 px-3.5 py-2 text-xs font-semibold text-amber-900 dark:border-amber-800/50 dark:bg-amber-950/30 dark:text-amber-300">
                  <ShieldCheck className="h-4 w-4 shrink-0 text-amber-600" />
                  <span>
                    {t('marginBadge', {
                      margin: formatTHB(
                        overview.breakdown.paperGold.marginRequirement
                      ),
                    })}
                  </span>
                </div>
              )}
            </div>

            {/* Multiplicative Brinson Return Attribution Stacked BarChart Card */}
            <GoldAttributionChart
              overview={overview}
              currentXauUsd={currentXauUsd}
              currentUsdThb={currentUsdThb}
            />
          </div>

          {/* Gold FIFO Tax Lots Table */}
          <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
              {t('fifoTableTitle')}
            </h2>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-gray-100 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:text-gray-400">
                    <th className="pb-3 pr-4">{t('colSymbol')}</th>
                    <th className="pb-3 pr-4">{t('colSubclass')}</th>
                    <th className="pb-3 pr-4">{t('colPurity')}</th>
                    <th className="pb-3 pr-4">{t('colWeight')}</th>
                    <th className="pb-3 pr-4 text-right">{t('colCostUnit')}</th>
                    <th className="pb-3 pr-4 text-right">{t('colRealized')}</th>
                    <th className="pb-3 pr-4 text-right">
                      {t('colUnrealized')}
                    </th>
                    <th className="pb-3 text-right">{t('colStatus')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  {overview.lots.map((lot) => (
                    <tr
                      key={lot.id}
                      className="transition hover:bg-gray-50/70 dark:hover:bg-gray-800/40"
                    >
                      <td className="py-3.5 pr-4 font-mono font-bold text-gray-900 dark:text-gray-100">
                        {lot.symbol}
                      </td>
                      <td className="py-3.5 pr-4">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="inline-flex rounded-lg border border-gray-200 bg-gray-50 px-2.5 py-0.5 text-[11px] font-semibold text-gray-700 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">
                            {t(formatSubclassTranslationKey(lot.assetSubclass))}
                          </span>
                          {lot.isTaxExempt && (
                            <span
                              data-testid={`gold-tax-exempt-badge-${lot.symbol}`}
                              className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-[#14342a] dark:bg-emerald-950/60 dark:text-[#4ade80]"
                            >
                              <ShieldCheck className="h-3 w-3" />
                              {t('taxExemptPnd')}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 pr-4 font-mono text-xs text-amber-700 dark:text-amber-400">
                        {lot.purity}%
                      </td>
                      <td className="py-3.5 pr-4 font-mono text-xs text-gray-700 dark:text-gray-300">
                        {Number(lot.weight).toFixed(2)} /{' '}
                        <strong className="text-gray-900 dark:text-white">
                          {Number(lot.weightRemain).toFixed(2)}
                        </strong>{' '}
                        {t(formatUnitTranslationKey(lot.weightUnit))}
                      </td>
                      <td className="py-3.5 pr-4 text-right font-mono text-gray-800 dark:text-gray-200">
                        {formatTHB(lot.costPerUnit)}
                      </td>
                      <td
                        className={cn(
                          'py-3.5 pr-4 text-right font-mono font-semibold',
                          Number(lot.realizedGL) > 0
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : Number(lot.realizedGL) < 0
                              ? 'text-red-600 dark:text-red-400'
                              : 'text-gray-500'
                        )}
                      >
                        {Number(lot.realizedGL) === 0
                          ? '฿0.00'
                          : formatSignedTHB(lot.realizedGL)}
                      </td>
                      <td
                        className={cn(
                          'py-3.5 pr-4 text-right font-mono font-semibold',
                          Number(lot.unrealizedGL) >= 0
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-red-600 dark:text-red-400'
                        )}
                      >
                        {formatSignedTHB(lot.unrealizedGL)}
                      </td>
                      <td className="py-3.5 text-right">
                        <div className="inline-flex items-center justify-end gap-2">
                          <span
                            className={cn(
                              'inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-semibold',
                              lot.status === 'Hold' &&
                                'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300',
                              lot.status === 'Partial' &&
                                'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300',
                              lot.status === 'Sold' &&
                                'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
                            )}
                          >
                            {lot.status}
                          </span>

                          {lot.assetSubclass === 'GOLD_ONLINE_FUTURES' &&
                            Number(lot.weightRemain) > 0 && (
                              <button
                                type="button"
                                data-testid={`roll-position-btn-${lot.symbol}`}
                                onClick={() => openRollPositionModal(lot)}
                                className="inline-flex items-center gap-1 rounded-xl bg-[#14342a] px-3 py-1.5 text-[11px] font-semibold text-white shadow-2xs transition hover:bg-[#1c4739] dark:bg-[#4ade80] dark:text-[#0d221b]"
                              >
                                <Repeat className="h-3 w-3" />
                                {t('rollPositionLabel')}
                              </button>
                            )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* TAB 2: Interactive Stress Simulator + 5x5 Sensitivity Heatmap Matrix */}
        <TabsContent value="sensitivity" className="mt-4 space-y-6">
          <div
            data-testid="gold-stress-simulator"
            className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
          >
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
                  {t('simTitle')}
                </h2>
                <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                  {t('simSubtitle')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setGoldShockPctInput(0);
                  setFxShockPctInput(0);
                }}
                className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 px-3.5 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300"
              >
                <Sparkles className="h-3.5 w-3.5 text-[#14342a] dark:text-[#4ade80]" />
                {t('resetSimBtn')}
              </button>
            </div>

            <div className="mt-5 grid grid-cols-1 gap-6 md:grid-cols-2">
              <div className="rounded-2xl border border-gray-100 bg-[#F8FAFC] p-4 dark:border-gray-800 dark:bg-gray-900/50">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span>{t('goldShockLabel')}</span>
                  <span className="font-mono text-sm font-bold text-[#14342a] dark:text-[#4ade80]">
                    {goldShockPctInput >= 0
                      ? `+${goldShockPctInput}%`
                      : `${goldShockPctInput}%`}{' '}
                    (${currentXauUsd})
                  </span>
                </div>
                <input
                  type="range"
                  min={-15}
                  max={15}
                  step={1}
                  value={goldShockPctInput}
                  onChange={(e) => setGoldShockPctInput(Number(e.target.value))}
                  data-testid="gold-shock-slider"
                  className="mt-3 w-full accent-[#14342a]"
                />
                <div className="mt-2 flex justify-between text-[11px] font-mono text-gray-400">
                  <span>-15% {t('bear')}</span>
                  <span>0% {t('spot')}</span>
                  <span>+15% {t('rally')}</span>
                </div>
              </div>

              <div className="rounded-2xl border border-gray-100 bg-[#F8FAFC] p-4 dark:border-gray-800 dark:bg-gray-900/50">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span>{t('fxShockLabel')}</span>
                  <span className="font-mono text-sm font-bold text-amber-700 dark:text-amber-400">
                    {fxShockPctInput >= 0
                      ? `+${fxShockPctInput}%`
                      : `${fxShockPctInput}%`}{' '}
                    ({currentUsdThb} THB)
                  </span>
                </div>
                <input
                  type="range"
                  min={-8}
                  max={8}
                  step={0.5}
                  value={fxShockPctInput}
                  onChange={(e) => setFxShockPctInput(Number(e.target.value))}
                  data-testid="fx-shock-slider"
                  className="mt-3 w-full accent-[#D97706]"
                />
                <div className="mt-2 flex justify-between text-[11px] font-mono text-gray-400">
                  <span>-8% {t('bahtStrong')}</span>
                  <span>0% {t('spot')}</span>
                  <span>+8% {t('bahtWeak')}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 5x5 Sensitivity Heatmap Matrix */}
          <div
            data-testid="gold-sensitivity-matrix"
            className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
          >
            <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
              {t('matrixTitle')}
            </h2>
            <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
              {t('matrixSubtitle')}
            </p>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full border-separate border-spacing-2 text-xs">
                <thead>
                  <tr>
                    <th className="rounded-xl bg-gray-100 px-3 py-2.5 text-left font-mono text-[11px] font-bold text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                      {t('goldVsFxAxis')}
                    </th>
                    {FX_SHOCK_COLS.map((fxCol) => {
                      const pct = (Number(fxCol) * 100).toFixed(1);
                      return (
                        <th
                          key={fxCol}
                          className="rounded-xl bg-gray-100 px-3 py-2.5 text-center font-mono text-[11px] font-bold text-gray-700 dark:bg-gray-800 dark:text-gray-200"
                        >
                          {t('fxShockValue', { value: Number(fxCol) >= 0 ? `+${pct}%` : `${pct}%` })}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {GOLD_SHOCK_ROWS.map((gRow) => {
                    const gPct = (Number(gRow) * 100).toFixed(0);
                    return (
                      <tr key={gRow}>
                        <td className="rounded-xl bg-gray-100 px-3 py-3 font-mono text-[11px] font-bold text-gray-800 dark:bg-gray-800 dark:text-gray-200">
                          {t('goldShockValue', { value: Number(gRow) >= 0 ? `+${gPct}%` : `${gPct}%` })}
                        </td>
                        {FX_SHOCK_COLS.map((fxCol) => {
                          const cell = matrixLookup.get(`${gRow}|${fxCol}`);
                          if (!cell) return <td key={fxCol} />;
                          const gl = Number(cell.projectedNetGLTHB);
                          const retPct = (
                            Number(cell.projectedReturnPct) * 100
                          ).toFixed(1);
                          const isBase =
                            gRow === '0.0000' && fxCol === '0.0000';

                          return (
                            <td
                              key={fxCol}
                              className={cn(
                                'rounded-xl border p-2.5 text-center transition',
                                gl >= 0
                                  ? 'border-emerald-200/80 bg-emerald-50/70 dark:border-emerald-800/50 dark:bg-emerald-950/30'
                                  : 'border-red-200/80 bg-red-50/70 dark:border-red-900/50 dark:bg-red-950/30',
                                isBase &&
                                  'ring-2 ring-[#14342a] dark:ring-[#4ade80]'
                              )}
                            >
                              <p className="font-mono text-xs font-bold text-gray-900 dark:text-gray-100">
                                {formatTHB(cell.projectedPortfolioValueTHB)}
                              </p>
                              <p
                                className={cn(
                                  'mt-0.5 font-mono text-[11px] font-semibold',
                                  gl >= 0
                                    ? 'text-emerald-700 dark:text-emerald-400'
                                    : 'text-red-700 dark:text-red-400'
                                )}
                              >
                                {formatSignedTHB(cell.projectedNetGLTHB)} (
                                {gl >= 0 ? `+${retPct}%` : `${retPct}%`})
                              </p>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* TAB 3: Contract Rollover Manager (7d/3d/1d Expiry Alerts + Atomic Rollover + Contango Spread) */}
        <TabsContent value="rollover" className="mt-4">
          <ContractRolloverPanel
            portfolioId={selectedPortfolioId || overview.portfolioId}
            onRolloverCompleted={() => {
              void fetchGoldOverview(goldShockPctInput, fxShockPctInput);
            }}
          />
        </TabsContent>
      </Tabs>

      {/* Modal: Record New Gold Transaction */}
      <Dialog open={addModalOpen} onOpenChange={setAddModalOpen}>
        <DialogContent
          data-testid="gold-add-modal"
          className="max-w-xl rounded-2xl p-6 sm:p-7"
        >
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl font-bold">
              {t('modalTitle')}
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm">
              {t('modalSubtitle')}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreateGoldTrade} className="space-y-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldType')}
                </label>
                <select
                  data-testid="gold-tx-type-select"
                  value={txType}
                  onChange={(e) =>
                    setTxType(e.target.value as 'BUY' | 'SELL')
                  }
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 text-xs font-semibold dark:border-gray-700 dark:bg-gray-900"
                >
                  <option value="BUY">{t('buyTrade')}</option>
                  <option value="SELL">{t('sellTrade')}</option>
                </select>
              </div>

              <div className="col-span-1 sm:col-span-2">
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldSubclass')}
                </label>
                <select
                  data-testid="gold-subclass-select"
                  value={assetSubclass}
                  onChange={(e) =>
                    handleSubclassChange(e.target.value as GoldAssetSubclass)
                  }
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 text-xs font-semibold dark:border-gray-700 dark:bg-gray-900"
                >
                  <option value="PHYSICAL_GOLD">{t('subclassPhysicalGold')}</option>
                  <option value="GOLD_ONLINE_FUTURES">{t('subclassTfexGoldOnline')}</option>
                  <option value="XAU_SPOT">{t('subclassXauSpot')}</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldSymbol')}
                </label>
                <input
                  type="text"
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldDate')}
                </label>
                <input
                  type="date"
                  data-testid="gold-date-input"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-xs dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldPurity')}
                </label>
                <select
                  data-testid="gold-purity-select"
                  value={purity}
                  onChange={(e) => setPurity(e.target.value as GoldPurity)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-xs font-semibold dark:border-gray-700 dark:bg-gray-900"
                >
                  <option value="96.5">96.5% ({t('purityThaiStandard')})</option>
                  <option value="99.99">99.99% ({t('purityLbma')})</option>
                  <option value="99.9">99.9%</option>
                  <option value="99.5">99.5% ({t('purityGoodDelivery')})</option>
                </select>
              </div>
            </div>

            {showPurityMismatchWarning && (
              <div
                role="alert"
                data-testid="gold-purity-mismatch-warning"
                className="rounded-xl border border-amber-300 bg-amber-50 px-3.5 py-2.5 text-xs font-semibold leading-relaxed text-amber-900 shadow-2xs dark:border-amber-700/70 dark:bg-amber-950/50 dark:text-amber-200"
              >
                ⚠️ {t('purityMismatch')}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldWeight')}
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  data-testid="gold-weight-input"
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-sm font-semibold dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldWeightUnit')}
                </label>
                <select
                  value={weightUnit}
                  onChange={(e) =>
                    setWeightUnit(e.target.value as GoldWeightUnit)
                  }
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 text-xs font-semibold dark:border-gray-700 dark:bg-gray-900"
                >
                  <option value="THAI_BAHT">{t('unitThaiBahtWeight')}</option>
                  <option value="GRAM">{t('unitGram')}</option>
                  <option value="TROY_OUNCE">{t('unitTroyOunce')}</option>
                </select>
              </div>
            </div>

            <p className="rounded-xl bg-[#F8FAFC] px-3 py-2 font-mono text-[11px] font-medium text-[#14342a] dark:bg-gray-900 dark:text-[#4ade80]">
              {t('weightEquivHint', {
                grams: liveModalPreview.grams,
                baht: liveModalPreview.baht,
                oz: liveModalPreview.oz,
              })}
            </p>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="flex flex-col justify-end">
                <label className="mb-1 block text-[11px] font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldSpot')} ({liveModalPreview.nativeCurrency})
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={spotPricePerUnit}
                  onChange={(e) => setSpotPricePerUnit(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>

              <div className="flex flex-col justify-end">
                <label className="mb-1 block text-[11px] font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldPremium')}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={premiumPerUnit}
                  onChange={(e) => setPremiumPerUnit(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs dark:border-gray-700 dark:bg-gray-900"
                />
              </div>

              <div className="flex flex-col justify-end">
                <label className="mb-1 block text-[11px] font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldComm')}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={commission}
                  onChange={(e) => setCommission(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs dark:border-gray-700 dark:bg-gray-900"
                />
              </div>

              <div className="flex flex-col justify-end">
                <label className="mb-1 block text-[11px] font-semibold text-gray-700 dark:text-gray-300">
                  {t('fieldFx')}
                </label>
                <input
                  type="number"
                  step="0.0001"
                  data-testid="gold-fx-input"
                  value={fxRateAtPurchase}
                  onChange={(e) => setFxRateAtPurchase(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                />
              </div>
            </div>

            {/* Step 1: Automated BOT Historical FX Rate Indicator */}
            <div
              data-testid="bot-fx-auto-badge"
              className="flex items-center justify-between gap-2 rounded-xl border border-emerald-200 bg-emerald-50/75 px-3.5 py-2 text-[11px] font-semibold text-[#14342a] dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-200"
            >
              <span className="flex items-center gap-1.5">
                <Landmark className="h-3.5 w-3.5 shrink-0 text-[#14342a] dark:text-[#4ade80]" />
                <span>
                  {t('botHistoricalFxLabel', { date: botFxAutoMeta.date })}
                </span>
              </span>
              <span className="shrink-0 font-mono font-bold">
                1 USD = {fxRateAtPurchase} THB
              </span>
            </div>

            {/* Live Calculated Total Cost Box */}
            <div className="flex items-center justify-between rounded-2xl border border-[#14342a]/20 bg-[#14342a]/[0.04] px-4 py-3 dark:border-[#4ade80]/25 dark:bg-[#14342a]/30">
              <span className="text-xs font-semibold text-gray-700 dark:text-gray-200">
                {t('calcTotalPreview')}
              </span>
              <div className="text-right font-mono">
                <p className="text-base font-bold text-[#14342a] dark:text-[#4ade80]">
                  {formatTHB(liveModalPreview.thbTotal)}
                </p>
                {liveModalPreview.nativeCurrency === 'USD' && (
                  <p className="text-[11px] text-gray-500">
                    (${liveModalPreview.nativeTotal} USD × {fxRateAtPurchase})
                  </p>
                )}
              </div>
            </div>

            <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setAddModalOpen(false)}
                className="rounded-xl border border-gray-200 px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300"
              >
                {t('cancelBtn')}
              </button>
              <button
                type="submit"
                disabled={submittingTx}
                data-testid="gold-submit-trade-btn"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm hover:bg-[#1c4739] disabled:opacity-60 dark:bg-[#4ade80] dark:text-[#0d221b]"
              >
                {t('submitTradeBtn')}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Step 2 & 4: Gold Futures Roll Position Modal (Shows Rollover Fee & rolloverGroupId linkage) */}
      <Dialog open={rollModalOpen} onOpenChange={setRollModalOpen}>
        <DialogContent
          data-testid="gold-roll-position-modal"
          className="max-w-xl rounded-2xl p-6 sm:p-7"
        >
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl font-bold">
              {t('rollModalTitle', { symbol: rollTargetLot?.symbol ?? '', newSymbol: rollNewSymbol })}
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm leading-relaxed">
              {t('rollModalDescription')}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleConfirmRollPosition} className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-2xl border border-red-200/80 bg-red-50/40 p-3.5 space-y-2 dark:border-red-900/50 dark:bg-red-950/20">
                <p className="text-xs font-bold text-red-800 dark:text-red-300">
                  {t('rollCloseStep')}
                </p>
                <p className="font-mono text-xs font-bold text-gray-900 dark:text-white">
                  {rollTargetLot?.symbol} • {t('rollRemaining')}{' '}
                  {Number(rollTargetLot?.weightRemain ?? '0').toFixed(2)} {t('unitOunceShort')}
                </p>
                <div>
                  <label className="mb-1 block text-[11px] font-semibold text-gray-600 dark:text-gray-300">
                    {t('rollClosePrice')}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={rollClosePrice}
                    onChange={(e) => setRollClosePrice(e.target.value)}
                    className="h-9 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                    required
                  />
                </div>
              </div>

              <div className="rounded-2xl border border-emerald-200/80 bg-emerald-50/40 p-3.5 space-y-2 dark:border-emerald-900/50 dark:bg-emerald-950/20">
                <p className="text-xs font-bold text-[#14342a] dark:text-[#4ade80]">
                  {t('rollOpenStep')}
                </p>
                <div>
                  <label className="mb-1 block text-[11px] font-semibold text-gray-600 dark:text-gray-300">
                    {t('newContractSymbol')}
                  </label>
                  <input
                    type="text"
                    data-testid="rollover-new-symbol-input"
                    value={rollNewSymbol}
                    onChange={(e) => setRollNewSymbol(e.target.value)}
                    className="h-9 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs font-bold uppercase dark:border-gray-700 dark:bg-gray-900"
                    required
                  />
                </div>
                <div>
                  <label className="mb-1 block text-[11px] font-semibold text-gray-600 dark:text-gray-300">
                    {t('rollOpenPrice')}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={rollNewPrice}
                    onChange={(e) => setRollNewPrice(e.target.value)}
                    className="h-9 w-full rounded-xl border border-gray-300 bg-white px-2.5 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('rollQuantity')}
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={rollNewQty}
                  onChange={(e) => setRollNewQty(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-xs font-bold dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-amber-800 dark:text-amber-300">
                  {t('rollFee')}
                </label>
                <input
                  type="number"
                  step="0.01"
                  data-testid="rollover-fee-input"
                  value={rollFee}
                  onChange={(e) => setRollFee(e.target.value)}
                  className="h-10 w-full rounded-xl border border-amber-300 bg-amber-50/40 px-3 font-mono text-xs font-bold text-amber-900 dark:border-amber-700 dark:bg-gray-900 dark:text-amber-200"
                  required
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                  {t('transactionDate')}
                </label>
                <input
                  type="date"
                  value={rollDate}
                  onChange={(e) => setRollDate(e.target.value)}
                  className="h-10 w-full rounded-xl border border-gray-300 bg-white px-3 font-mono text-xs dark:border-gray-700 dark:bg-gray-900"
                  required
                />
              </div>
            </div>

            {/* Transparent Rollover Fee & Initial Cost Basis Box */}
            <div className="rounded-2xl border border-gray-200 bg-[#F8FAFC] p-4 space-y-2 dark:border-gray-800 dark:bg-gray-900/70">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-600 dark:text-gray-400">
                  {t('rollSpread')}
                </span>
                <span className="font-mono font-bold text-gray-900 dark:text-white">
                  ${liveRollPreview.spreadUSD} / {t('unitOunceShort')}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-800 dark:text-amber-300">
                  {t('rollFeeTransparent')}
                </span>
                <span className="font-mono font-bold text-amber-800 dark:text-amber-300">
                  ${liveRollPreview.feeUSD} USD ({formatTHB(liveRollPreview.feeTHB)})
                </span>
              </div>
              <div className="flex items-center justify-between border-t border-gray-200 pt-2 text-xs dark:border-gray-700">
                <span className="font-semibold text-[#14342a] dark:text-[#4ade80]">
                  {t('newCostBasis')}
                </span>
                <span className="font-mono text-sm font-bold text-[#14342a] dark:text-[#4ade80]">
                  {formatTHB(liveRollPreview.newBasisTHB)}
                </span>
              </div>
            </div>

            <div className="flex flex-col-reverse gap-2 pt-1 sm:flex-row sm:justify-end">
              <button
                type="button"
                onClick={() => setRollModalOpen(false)}
                className="rounded-xl border border-gray-200 px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300"
              >
                {t('cancelBtn')}
              </button>
              <button
                type="submit"
                disabled={rollSubmitting}
                data-testid="confirm-roll-position-btn"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm hover:bg-[#1c4739] disabled:opacity-60 dark:bg-[#4ade80] dark:text-[#0d221b]"
              >
                <Repeat className="h-4 w-4" />
                {t('confirmRollPosition')}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
