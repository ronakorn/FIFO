'use client';

import React, { useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import { useTranslations } from 'next-intl';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { CheckCircle2, Calculator, Scale, TrendingUp } from 'lucide-react';
import { cn, formatSignedTHB, formatTHB } from '@/lib/utils';
import type {
  GoldFXSensitivity,
  GoldOverviewSummary,
  MultiplicativeBrinsonItem,
} from '@/types/gold';

/**
 * Frontend Quantitative Decimal Engine (strictly precision: 40, ROUND_HALF_UP)
 */
const ChartDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

const DEC_BAHT_GRAMS = new ChartDecimal('15.244');
const DEC_OZ_GRAMS = new ChartDecimal('31.1034768');
const DEC_PURITY_965 = new ChartDecimal('0.965');
const DEC_GTA_FACTOR = DEC_BAHT_GRAMS.dividedBy(DEC_OZ_GRAMS).times(
  DEC_PURITY_965
);

export interface AttributionChartRow {
  symbol: string;
  mode: 'UNREALIZED' | 'REALIZED';
  costBasisTHB: string;
  endingValueTHB: string;
  totalGLTHB: string;
  goldPriceContributionTHB: string;
  fxContributionTHB: string;
  goldAlphaTHBNum: number;
  fxImpactTHBNum: number;
  rGoldRatio: string;
  rFxRatio: string;
  rTotalRatio: string;
  rGoldPctDisplay: string;
  rFxPctDisplay: string;
  rTotalPctDisplay: string;
  onePlusRGold: string;
  onePlusRFx: string;
  onePlusRTotal: string;
  entryUsdThb: string;
  currentUsdThb: string;
  unexplainedResidualTHB: string;
  isZeroResidualVerified: boolean;
}


type GoldDriverTranslationKey = 'goldDriverRally' | 'goldDriverPullback' | 'goldDriverFlat';
type FxDriverTranslationKey = 'fxDriverWeakening' | 'fxDriverStrengthening' | 'fxDriverFlat';

function getGoldDriverTranslationKey(ratio: string): GoldDriverTranslationKey {
  const value = new ChartDecimal(ratio || '0');
  return value.gt(0) ? 'goldDriverRally' : value.lt(0) ? 'goldDriverPullback' : 'goldDriverFlat';
}

function getFxDriverTranslationKey(ratio: string): FxDriverTranslationKey {
  const value = new ChartDecimal(ratio || '0');
  return value.gt(0) ? 'fxDriverWeakening' : value.lt(0) ? 'fxDriverStrengthening' : 'fxDriverFlat';
}

interface CustomTooltipPayloadEntry {
  payload?: AttributionChartRow;
}

interface CustomBrinsonTooltipProps {
  active?: boolean;
  payload?: CustomTooltipPayloadEntry[];
}

function formatSignedPctFromRatio(ratioStr: string): string {
  const pct = new ChartDecimal(ratioStr || '0').times(100);
  return `${pct.gte(0) ? '+' : ''}${pct.toFixed(2)}%`;
}

function formatSignedRatio(ratioStr: string): string {
  const dec = new ChartDecimal(ratioStr || '0');
  return `${dec.gte(0) ? '+' : ''}${dec.toFixed(6)}`;
}

/**
 * Recharts Custom Tooltip displaying exact Multiplicative Brinson formulas
 * and precision-40 Decimal values with Zero Unexplained Residual proof.
 */
function BrinsonFormulaTooltip({
  active,
  payload,
}: CustomBrinsonTooltipProps) {
  const t = useTranslations('GoldEngine');
  if (!active || !payload || payload.length === 0 || !payload[0]?.payload) {
    return null;
  }

  const row = payload[0].payload;
  const goldDriverText = t(getGoldDriverTranslationKey(row.rGoldRatio));
  const fxDriverText = t(getFxDriverTranslationKey(row.rFxRatio));

  return (
    <div
      data-testid="brinson-chart-tooltip"
      className="z-50 min-w-[300px] max-w-md rounded-2xl border border-gray-200 bg-white p-4 text-xs shadow-2xl ring-1 ring-gray-900/5 dark:border-gray-700 dark:bg-[#16191D]"
    >
      {/* Header */}
      <div className="flex items-center justify-between gap-3 border-b border-gray-100 pb-2.5 dark:border-gray-800">
        <div>
          <span className="font-mono text-sm font-bold text-gray-900 dark:text-gray-100">
            {row.symbol}
          </span>
          <span className="ml-2 rounded-md bg-gray-100 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-gray-600 dark:bg-gray-800 dark:text-gray-300">
            {row.mode === 'UNREALIZED' ? t('modeUnrealized') : t('modeRealized')}
          </span>
        </div>
        <span
          className={cn(
            'font-mono text-xs font-bold',
            Number(row.totalGLTHB) >= 0
              ? 'text-emerald-600 dark:text-emerald-400'
              : 'text-red-600 dark:text-red-400'
          )}
        >
          {formatSignedTHB(row.totalGLTHB)} ({row.rTotalPctDisplay})
        </span>
      </div>

      {/* Multiplicative Brinson Identity Formula */}
      <div className="mt-2.5 rounded-xl bg-[#F8FAFC] p-2.5 font-mono text-[11px] dark:bg-gray-900/80">
        <p className="font-semibold text-gray-700 dark:text-gray-200">
          (1 + R_total) = (1 + R_gold) × (1 + R_fx)
        </p>
        <p className="mt-0.5 text-[10px] text-gray-500 dark:text-gray-400">
          {row.onePlusRTotal} = {row.onePlusRGold} × {row.onePlusRFx}
        </p>
      </div>

      {/* Component 1: Gold Alpha (Green #16A34A) */}
      <div className="mt-2.5 space-y-2">
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/50 p-2.5 dark:border-emerald-800/50 dark:bg-emerald-950/25">
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 font-semibold text-emerald-800 dark:text-emerald-300">
              <span className="h-2.5 w-2.5 rounded-sm bg-[#16A34A]" />
              {t('goldAlpha')} • {goldDriverText}
            </span>
            <span className="font-mono font-bold text-emerald-700 dark:text-emerald-300">
              {formatSignedTHB(row.goldPriceContributionTHB)}
            </span>
          </div>
          <p className="mt-1 font-mono text-[10px] text-emerald-900/80 dark:text-emerald-200/80">
            {t('costBasisLabel')} × R_gold = {formatTHB(row.costBasisTHB)} × (
            {formatSignedRatio(row.rGoldRatio)})
          </p>
        </div>

        {/* Component 2: FX Impact (Blue #2563EB) */}
        <div className="rounded-xl border border-blue-200/70 bg-blue-50/50 p-2.5 dark:border-blue-800/50 dark:bg-blue-950/25">
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 font-semibold text-blue-800 dark:text-blue-300">
              <span className="h-2.5 w-2.5 rounded-sm bg-[#2563EB]" />
              {t('fxImpact')} • {fxDriverText}
            </span>
            <span className="font-mono font-bold text-blue-700 dark:text-blue-300">
              {formatSignedTHB(row.fxContributionTHB)}
            </span>
          </div>
          <p className="mt-1 font-mono text-[10px] text-blue-900/80 dark:text-blue-200/80">
            ({t('costPlusGold')}) × R_fx = (
            {formatTHB(
              new ChartDecimal(row.costBasisTHB)
                .plus(row.goldPriceContributionTHB)
                .toFixed(2)
            )}
            ) × ({formatSignedRatio(row.rFxRatio)})
          </p>
          <p className="mt-0.5 font-mono text-[10px] text-blue-800/70 dark:text-blue-300/70">
            USD/THB: {row.entryUsdThb} → {row.currentUsdThb} (
            {row.rFxPctDisplay})
          </p>
        </div>
      </div>

      {/* Zero Unexplained Residual Check */}
      <div className="mt-2.5 flex items-center justify-between border-t border-gray-100 pt-2 font-mono text-[10px] text-gray-600 dark:border-gray-800 dark:text-gray-300">
        <span>{t('zeroResidualCheck')}</span>
        <span className="inline-flex items-center gap-1 font-bold text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 className="h-3 w-3" />
          {t('formulaResidual', { amount: row.unexplainedResidualTHB })}
        </span>
      </div>
    </div>
  );
}

/**
 * Recomputes live Multiplicative Brinson Attribution row with Decimal.js (precision: 40)
 * when live feed prices (`currentXauUsd`, `currentUsdThb`) move.
 */
function buildChartRowFromBrinsonSource(params: {
  symbol: string;
  mode: 'UNREALIZED' | 'REALIZED';
  costBasisTHB: InstanceType<typeof ChartDecimal>;
  endingValueTHB: InstanceType<typeof ChartDecimal>;
  entryUsdThb: InstanceType<typeof ChartDecimal>;
  currentUsdThb: InstanceType<typeof ChartDecimal>;
}): AttributionChartRow {
  const one = new ChartDecimal(1);
  const { symbol, mode, costBasisTHB, endingValueTHB, entryUsdThb, currentUsdThb } =
    params;

  if (costBasisTHB.lte(0)) {
    return {
      symbol,
      mode,
      costBasisTHB: '0.00',
      endingValueTHB: '0.00',
      totalGLTHB: '0.00',
      goldPriceContributionTHB: '0.00',
      fxContributionTHB: '0.00',
      goldAlphaTHBNum: 0,
      fxImpactTHBNum: 0,
      rGoldRatio: '0.000000',
      rFxRatio: '0.000000',
      rTotalRatio: '0.000000',
      rGoldPctDisplay: '+0.00%',
      rFxPctDisplay: '+0.00%',
      rTotalPctDisplay: '+0.00%',
      onePlusRGold: '1.000000',
      onePlusRFx: '1.000000',
      onePlusRTotal: '1.000000',
      entryUsdThb: entryUsdThb.toFixed(4),
      currentUsdThb: currentUsdThb.toFixed(4),
      unexplainedResidualTHB: '0.00',
      isZeroResidualVerified: true,
    };
  }

  const onePlusRFx = currentUsdThb.dividedBy(entryUsdThb);
  const rFx = onePlusRFx.minus(one);

  const onePlusRTotal = endingValueTHB.dividedBy(costBasisTHB);
  const rTotal = onePlusRTotal.minus(one);

  const onePlusRGold = onePlusRTotal.dividedBy(onePlusRFx);
  const rGold = onePlusRGold.minus(one);

  const rawGoldContrib = costBasisTHB.times(rGold);
  const rawFxContrib = costBasisTHB.plus(rawGoldContrib).times(rFx);
  const rawTotalGL = endingValueTHB.minus(costBasisTHB);

  const totalGLSatang = new ChartDecimal(rawTotalGL.toFixed(2));
  const goldSatang = new ChartDecimal(rawGoldContrib.toFixed(2));
  const fxFormulaSatang = new ChartDecimal(rawFxContrib.toFixed(2));
  const fxSatang = goldSatang.plus(fxFormulaSatang).eq(totalGLSatang)
    ? fxFormulaSatang
    : totalGLSatang.minus(goldSatang);

  const residual = totalGLSatang.minus(goldSatang.plus(fxSatang));

  return {
    symbol,
    mode,
    costBasisTHB: costBasisTHB.toFixed(2),
    endingValueTHB: endingValueTHB.toFixed(2),
    totalGLTHB: totalGLSatang.toFixed(2),
    goldPriceContributionTHB: goldSatang.toFixed(2),
    fxContributionTHB: fxSatang.toFixed(2),
    goldAlphaTHBNum: Number(goldSatang.toFixed(2)),
    fxImpactTHBNum: Number(fxSatang.toFixed(2)),
    rGoldRatio: rGold.toFixed(6),
    rFxRatio: rFx.toFixed(6),
    rTotalRatio: rTotal.toFixed(6),
    rGoldPctDisplay: formatSignedPctFromRatio(rGold.toString()),
    rFxPctDisplay: formatSignedPctFromRatio(rFx.toString()),
    rTotalPctDisplay: formatSignedPctFromRatio(rTotal.toString()),
    onePlusRGold: onePlusRGold.toFixed(6),
    onePlusRFx: onePlusRFx.toFixed(6),
    onePlusRTotal: onePlusRTotal.toFixed(6),
    entryUsdThb: entryUsdThb.toFixed(4),
    currentUsdThb: currentUsdThb.toFixed(4),
    unexplainedResidualTHB: residual.toFixed(2),
    isZeroResidualVerified: residual.isZero(),
  };
}

function mapServerBrinsonItemToRow(
  item: MultiplicativeBrinsonItem
): AttributionChartRow {
  const one = new ChartDecimal(1);
  const rGold = new ChartDecimal(item.goldReturnRatio || '0');
  const rFx = new ChartDecimal(item.fxReturnRatio || '0');
  const rTotal = new ChartDecimal(item.totalReturnRatio || '0');

  return {
    symbol: item.symbol,
    mode: item.mode,
    costBasisTHB: item.costBasisTHB,
    endingValueTHB: item.endingValueTHB,
    totalGLTHB: item.totalGLTHB,
    goldPriceContributionTHB: item.goldPriceContributionTHB,
    fxContributionTHB: item.fxContributionTHB,
    goldAlphaTHBNum: Number(item.goldPriceContributionTHB),
    fxImpactTHBNum: Number(item.fxContributionTHB),
    rGoldRatio: item.goldReturnRatio,
    rFxRatio: item.fxReturnRatio,
    rTotalRatio: item.totalReturnRatio,
    rGoldPctDisplay: formatSignedPctFromRatio(item.goldReturnRatio),
    rFxPctDisplay: formatSignedPctFromRatio(item.fxReturnRatio),
    rTotalPctDisplay: formatSignedPctFromRatio(item.totalReturnRatio),
    onePlusRGold: one.plus(rGold).toFixed(6),
    onePlusRFx: one.plus(rFx).toFixed(6),
    onePlusRTotal: one.plus(rTotal).toFixed(6),
    entryUsdThb: item.entryUsdThb,
    currentUsdThb: item.currentUsdThb,
    unexplainedResidualTHB: item.unexplainedResidualTHB,
    isZeroResidualVerified: item.isZeroResidualVerified,
  };
}

export interface GoldAttributionChartProps {
  overview: GoldOverviewSummary;
  currentXauUsd: string;
  currentUsdThb: string;
}

export function GoldAttributionChart({
  overview,
  currentXauUsd,
  currentUsdThb,
}: GoldAttributionChartProps) {
  const t = useTranslations('GoldEngine');

  const [viewMode, setViewMode] = useState<'UNREALIZED' | 'REALIZED'>(
    'UNREALIZED'
  );
  const [selectedSymbol, setSelectedSymbol] = useState<string>('');

  // Live GTA 96.5% Parity Decomposition: (XAU/USD) × (15.244 / 31.1034768) × 0.965 × (USD/THB)
  const liveGtaParity = useMemo(() => {
    const xau = new ChartDecimal(currentXauUsd || '2740.00');
    const fx = new ChartDecimal(currentUsdThb || '35.6000');
    const parityTHB = xau.times(DEC_GTA_FACTOR).times(fx);

    const baseXau = new ChartDecimal(overview.market.xauUsdSpot || '2740.00');
    const baseFx = new ChartDecimal(overview.market.usdThbRate || '35.6000');
    const baseQuoted = new ChartDecimal(
      overview.market.gtaGold965SellTHB || '46450.00'
    );
    const scale =
      baseXau.gt(0) && baseFx.gt(0)
        ? xau.dividedBy(baseXau).times(fx.dividedBy(baseFx))
        : new ChartDecimal(1);
    const liveQuotedTHB = baseQuoted.times(scale);
    const spreadTHB = liveQuotedTHB.minus(parityTHB);

    return {
      xauStr: xau.toFixed(2),
      fxStr: fx.toFixed(4),
      factorStr: DEC_GTA_FACTOR.toFixed(6),
      parityTHB: parityTHB.toFixed(2),
      quotedTHB: liveQuotedTHB.toFixed(2),
      spreadTHB: spreadTHB.toFixed(2),
    };
  }, [
    currentXauUsd,
    currentUsdThb,
    overview.market.xauUsdSpot,
    overview.market.usdThbRate,
    overview.market.gtaGold965SellTHB,
  ]);

  // Build Live Unrealized Attribution Rows (scaled accurately with live XAU/USD & USD/THB)
  const unrealizedRows = useMemo<AttributionChartRow[]>(() => {
    const snapshotXau = new ChartDecimal(
      overview.market.xauUsdSpot || '2740.00'
    );
    const snapshotFx = new ChartDecimal(
      overview.market.usdThbRate || '35.6000'
    );
    const activeXau = new ChartDecimal(currentXauUsd || '2740.00');
    const activeFx = new ChartDecimal(currentUsdThb || '35.6000');

    const livePriceScale =
      snapshotXau.gt(0) && snapshotFx.gt(0)
        ? activeXau
            .dividedBy(snapshotXau)
            .times(activeFx.dividedBy(snapshotFx))
        : new ChartDecimal(1);

    if (
      overview.brinsonAttribution &&
      overview.brinsonAttribution.unrealizedItems.length > 0 &&
      livePriceScale.eq(1)
    ) {
      return overview.brinsonAttribution.unrealizedItems.map(
        mapServerBrinsonItemToRow
      );
    }

    return overview.fxSensitivities.map((s: GoldFXSensitivity) => {
      const lotForSym = overview.lots.filter(
        (l) => l.symbol === s.symbol && Number(l.weightRemain) > 0
      );
      const fallbackCost = lotForSym.reduce(
        (acc, l) =>
          acc.plus(
            new ChartDecimal(l.weightRemain).times(
              new ChartDecimal(l.costPerUnit)
            )
          ),
        new ChartDecimal(0)
      );
      const fallbackUnreal = lotForSym.reduce(
        (acc, l) => acc.plus(new ChartDecimal(l.unrealizedGL)),
        new ChartDecimal(0)
      );

      const costDec = s.costBasisTHB
        ? new ChartDecimal(s.costBasisTHB)
        : fallbackCost;
      const baseEndingDec = s.marketValueTHB
        ? new ChartDecimal(s.marketValueTHB)
        : fallbackCost.plus(fallbackUnreal);
      const liveEndingDec = baseEndingDec.times(livePriceScale);

      const entryFxDec = s.entryUsdThb
        ? new ChartDecimal(s.entryUsdThb)
        : new ChartDecimal(1).plus(s.fxImpactPct || '0').gt(0)
          ? snapshotFx.dividedBy(
              new ChartDecimal(1).plus(s.fxImpactPct || '0')
            )
          : activeFx;

      return buildChartRowFromBrinsonSource({
        symbol: s.symbol,
        mode: 'UNREALIZED',
        costBasisTHB: costDec,
        endingValueTHB: liveEndingDec,
        entryUsdThb: entryFxDec,
        currentUsdThb: activeFx,
      });
    });
  }, [
    overview.brinsonAttribution,
    overview.fxSensitivities,
    overview.lots,
    overview.market.xauUsdSpot,
    overview.market.usdThbRate,
    currentXauUsd,
    currentUsdThb,
  ]);

  // Build Realized FIFO Attribution Rows
  const realizedRows = useMemo<AttributionChartRow[]>(() => {
    if (
      overview.brinsonAttribution &&
      overview.brinsonAttribution.realizedItems.length > 0
    ) {
      return overview.brinsonAttribution.realizedItems.map(
        mapServerBrinsonItemToRow
      );
    }

    // Fallback from closed/partial FIFO lots (e.g. GOLD965 partial sale in mock preview)
    return overview.lots
      .filter((l) => Number(l.weightSold) > 0 && Number(l.realizedGL) !== 0)
      .map((l) => {
        const soldCost = new ChartDecimal(l.weightSold).times(
          new ChartDecimal(l.costPerUnit)
        );
        const proceeds = soldCost.plus(new ChartDecimal(l.realizedGL));
        return buildChartRowFromBrinsonSource({
          symbol: l.symbol,
          mode: 'REALIZED',
          costBasisTHB: soldCost,
          endingValueTHB: proceeds,
          entryUsdThb: new ChartDecimal('34.2000'),
          currentUsdThb: new ChartDecimal('35.1000'),
        });
      });
  }, [overview.brinsonAttribution, overview.lots]);

  const activeRows = viewMode === 'UNREALIZED' ? unrealizedRows : realizedRows;

  // Portfolio Aggregate Summary (proving Sum(Gold) + Sum(FX) === Sum(Total G/L) with 0.00 residual)
  const aggregateTotals = useMemo(() => {
    let goldSum = new ChartDecimal(0);
    let fxSum = new ChartDecimal(0);
    let totalGLSum = new ChartDecimal(0);
    let costSum = new ChartDecimal(0);

    for (const r of activeRows) {
      goldSum = goldSum.plus(r.goldPriceContributionTHB);
      fxSum = fxSum.plus(r.fxContributionTHB);
      totalGLSum = totalGLSum.plus(r.totalGLTHB);
      costSum = costSum.plus(r.costBasisTHB);
    }

    const residual = totalGLSum.minus(goldSum.plus(fxSum));
    return {
      costBasisTHB: costSum.toFixed(2),
      goldContributionTHB: goldSum.toFixed(2),
      fxContributionTHB: fxSum.toFixed(2),
      totalGLTHB: totalGLSum.toFixed(2),
      residualTHB: residual.toFixed(2),
      isZeroResidual: residual.isZero(),
    };
  }, [activeRows]);

  const inspectedRow = useMemo(() => {
    if (activeRows.length === 0) return null;
    return (
      activeRows.find((r) => r.symbol === selectedSymbol) ?? activeRows[0] ?? null
    );
  }, [activeRows, selectedSymbol]);

  return (
    <div
      data-testid="gold-attribution-chart-card"
      className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm lg:col-span-7 dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      {/* Header + Mode Switcher */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
              {t('attrChartTitle')}
            </h2>
            <span
              data-testid="brinson-zero-residual-badge"
              className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 font-mono text-[10px] font-bold text-[#14342a] dark:border-emerald-800/60 dark:bg-emerald-950/50 dark:text-[#4ade80]"
            >
              <CheckCircle2 className="h-3 w-3 text-emerald-600 dark:text-[#4ade80]" />
              {t('zeroResidualBadge', { amount: aggregateTotals.residualTHB })}
            </span>
          </div>
          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
            {t('attrChartSubtitle')}
          </p>
        </div>

        <div className="inline-flex shrink-0 rounded-xl border border-gray-200 bg-[#F8FAFC] p-0.5 dark:border-gray-800 dark:bg-gray-900">
          <button
            type="button"
            data-testid="brinson-mode-unrealized"
            onClick={() => setViewMode('UNREALIZED')}
            className={cn(
              'rounded-lg px-2.5 py-1 text-[11px] font-semibold transition',
              viewMode === 'UNREALIZED'
                ? 'bg-[#14342a] text-white shadow-2xs dark:bg-[#4ade80] dark:text-[#0d221b]'
                : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100'
            )}
          >
            {t('modeUnrealized')}
          </button>
          <button
            type="button"
            data-testid="brinson-mode-realized"
            onClick={() => setViewMode('REALIZED')}
            className={cn(
              'rounded-lg px-2.5 py-1 text-[11px] font-semibold transition',
              viewMode === 'REALIZED'
                ? 'bg-[#14342a] text-white shadow-2xs dark:bg-[#4ade80] dark:text-[#0d221b]'
                : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100'
            )}
          >
            {t('modeRealized')}
          </button>
        </div>
      </div>

      {/* Step 2: GTA 96.5% Parity Formula & Live Thai Gold Decomposition Strip */}
      <div
        data-testid="gold-gta-parity-strip"
        className="mt-3.5 flex flex-col gap-2 rounded-xl border border-gray-100 bg-[#F8FAFC] px-3.5 py-2.5 text-[11px] sm:flex-row sm:items-center sm:justify-between dark:border-gray-800 dark:bg-gray-900/60"
      >
        <div className="flex items-center gap-2 text-gray-700 dark:text-gray-300">
          <Scale className="h-3.5 w-3.5 shrink-0 text-[#14342a] dark:text-[#4ade80]" />
          <span className="font-mono">
            <strong>{t('gtaParityFormula')}</strong> = (${liveGtaParity.xauStr}) ×
            (15.244 / 31.1034768) × 0.965 × ({liveGtaParity.fxStr})
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-2 font-mono">
          <span className="font-bold text-gray-900 dark:text-gray-100">
            = {formatTHB(liveGtaParity.parityTHB)}
          </span>
          <span className="text-gray-400">•</span>
          <span className="text-amber-700 dark:text-amber-400">
            {t('gtaQuote')}: {formatTHB(liveGtaParity.quotedTHB)}
          </span>
        </div>
      </div>

      {/* Portfolio Total Monetary Attribution Summary Bar */}
      <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
        <div className="rounded-xl border border-emerald-200/70 bg-emerald-50/50 px-3 py-2 dark:border-emerald-800/50 dark:bg-emerald-950/20">
          <div className="flex items-center justify-between text-[11px] font-semibold text-emerald-800 dark:text-emerald-300">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-sm bg-[#16A34A]" />
              {t('goldAlpha')}
            </span>
          </div>
          <p
            data-testid="brinson-total-gold-contrib"
            className="mt-0.5 font-mono text-sm font-bold text-emerald-700 dark:text-emerald-300"
          >
            {formatSignedTHB(aggregateTotals.goldContributionTHB)}
          </p>
        </div>

        <div className="rounded-xl border border-blue-200/70 bg-blue-50/50 px-3 py-2 dark:border-blue-800/50 dark:bg-blue-950/20">
          <div className="flex items-center justify-between text-[11px] font-semibold text-blue-800 dark:text-blue-300">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-sm bg-[#2563EB]" />
              {t('fxImpact')}
            </span>
          </div>
          <p
            data-testid="brinson-total-fx-contrib"
            className="mt-0.5 font-mono text-sm font-bold text-blue-700 dark:text-blue-300"
          >
            {formatSignedTHB(aggregateTotals.fxContributionTHB)}
          </p>
        </div>

        <div className="rounded-xl border border-gray-200/80 bg-[#F8FAFC] px-3 py-2 dark:border-gray-800 dark:bg-gray-900/60">
          <div className="flex items-center justify-between text-[11px] font-semibold text-gray-600 dark:text-gray-300">
            <span className="flex items-center gap-1">
              <TrendingUp className="h-3 w-3 text-[#14342a] dark:text-[#4ade80]" />
              {t('totalGL')}
            </span>
          </div>
          <p
            data-testid="brinson-total-net-gl"
            className={cn(
              'mt-0.5 font-mono text-sm font-bold',
              Number(aggregateTotals.totalGLTHB) >= 0
                ? 'text-gray-900 dark:text-gray-100'
                : 'text-red-600 dark:text-red-400'
            )}
          >
            {formatSignedTHB(aggregateTotals.totalGLTHB)}
          </p>
        </div>
      </div>

      {/* Step 3: Recharts Multiplicative Brinson Stacked Bar Chart (Green Gold Alpha + Blue FX Impact) */}
      <div
        data-testid="gold-brinson-stacked-chart"
        className="mt-4 h-60 w-full"
      >
        {activeRows.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={activeRows}
              stackOffset="sign"
              margin={{ top: 10, right: 16, left: 8, bottom: 2 }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#E5E7EB"
              />
              <XAxis
                dataKey="symbol"
                tick={{ fontSize: 12, fontWeight: 700 }}
              />
              <YAxis
                tickFormatter={(v: number) => `฿${(v / 1000).toFixed(0)}k`}
                tick={{ fontSize: 11 }}
              />
              <ReferenceLine
                y={0}
                stroke="#9CA3AF"
                strokeDasharray="3 3"
              />
              <Tooltip
                cursor={{ fill: 'rgba(20, 52, 42, 0.05)' }}
                wrapperStyle={{ zIndex: 50 }}
                content={<BrinsonFormulaTooltip />}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '6px' }} />
              <Bar
                dataKey="goldAlphaTHBNum"
                stackId="brinson"
                name={
                  t('goldAlpha')
                }
                fill="#16A34A"
                radius={[0, 0, 0, 0]}
                isAnimationActive={false}
              />
              <Bar
                dataKey="fxImpactTHBNum"
                stackId="brinson"
                name={
                  t('fxImpact')
                }
                fill="#2563EB"
                radius={[6, 6, 0, 0]}
                isAnimationActive={false}
              />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex h-full items-center justify-center rounded-xl border border-dashed border-gray-200 text-xs text-gray-500 dark:border-gray-800 dark:text-gray-400">
            {t('noRealizedGoldTransactions')}
          </div>
        )}
      </div>

      {/* Per-Symbol Thai Gold Driver Classification Cards ("ทองโลกวิ่ง" vs "บาทอ่อน/แข็ง") */}
      {activeRows.length > 0 && (
        <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          {activeRows.map((row) => {
            const isSelected = inspectedRow?.symbol === row.symbol;
            return (
              <button
                key={`${row.mode}-${row.symbol}`}
                type="button"
                data-testid={`brinson-symbol-card-${row.symbol}`}
                onClick={() => setSelectedSymbol(row.symbol)}
                className={cn(
                  'rounded-xl border px-3.5 py-2.5 text-left transition',
                  isSelected
                    ? 'border-[#14342a] bg-emerald-50/40 shadow-2xs dark:border-[#4ade80] dark:bg-emerald-950/20'
                    : 'border-gray-100 bg-[#F8FAFC] hover:border-gray-300 dark:border-gray-800 dark:bg-gray-900/60'
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs font-bold text-gray-900 dark:text-gray-100">
                    {row.symbol}
                  </span>
                  <span
                    className={cn(
                      'whitespace-nowrap font-mono text-[11px] font-bold',
                      Number(row.totalGLTHB) >= 0
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-red-600 dark:text-red-400'
                    )}
                  >
                    {formatSignedTHB(row.totalGLTHB)} ({row.rTotalPctDisplay})
                  </span>
                </div>

                <div className="mt-1.5 space-y-1 text-[11px]">
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 whitespace-nowrap font-semibold text-emerald-700 dark:text-emerald-400">
                      <span className="h-2 w-2 shrink-0 rounded-xs bg-[#16A34A]" />
                      {t(getGoldDriverTranslationKey(row.rGoldRatio))}
                    </span>
                    <span className="whitespace-nowrap font-mono font-semibold text-emerald-700 dark:text-emerald-300">
                      {formatSignedTHB(row.goldPriceContributionTHB)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 whitespace-nowrap font-semibold text-blue-700 dark:text-blue-400">
                      <span className="h-2 w-2 shrink-0 rounded-xs bg-[#2563EB]" />
                      {t(getFxDriverTranslationKey(row.rFxRatio))}
                    </span>
                    <span className="whitespace-nowrap font-mono font-semibold text-blue-700 dark:text-blue-300">
                      {formatSignedTHB(row.fxContributionTHB)}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Pinned Exact Decimal Formula Proof Strip for Selected Symbol */}
      {inspectedRow && (
        <div
          data-testid="brinson-formula-inspector"
          className="mt-3 rounded-xl border border-gray-200/80 bg-[#F8FAFC] px-3.5 py-2.5 font-mono text-[11px] text-gray-700 dark:border-gray-800 dark:bg-gray-900/70 dark:text-gray-300"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="inline-flex items-center gap-1.5 font-sans text-xs font-bold text-gray-900 dark:text-gray-100">
              <Calculator className="h-3.5 w-3.5 text-[#14342a] dark:text-[#4ade80]" />
              {inspectedRow.symbol} — {t('brinsonProofTitle')}
            </span>
            <span className="text-[10px] font-semibold text-emerald-700 dark:text-[#4ade80]">
              (1 + R_total) = {inspectedRow.onePlusRGold} ×{' '}
              {inspectedRow.onePlusRFx} = {inspectedRow.onePlusRTotal}
            </span>
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px]">
            <span className="text-emerald-700 dark:text-emerald-300">
              {t('goldFormulaLabel')} = {formatTHB(inspectedRow.costBasisTHB)} × (
              {formatSignedRatio(inspectedRow.rGoldRatio)}) ={' '}
              <strong>
                {formatSignedTHB(inspectedRow.goldPriceContributionTHB)}
              </strong>
            </span>
            <span className="text-gray-400">+</span>
            <span className="text-blue-700 dark:text-blue-300">
              {t('fxImpactFormula')} = ({t('costBasisLabel')} + {t('goldAlpha')}) × ({formatSignedRatio(inspectedRow.rFxRatio)})
              = <strong>{formatSignedTHB(inspectedRow.fxContributionTHB)}</strong>
            </span>
            <span className="text-gray-400">===</span>
            <span className="font-bold text-gray-900 dark:text-gray-100">
              {t('totalGL')}: {formatSignedTHB(inspectedRow.totalGLTHB)} ({t('residual')}: ฿
              {inspectedRow.unexplainedResidualTHB})
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
