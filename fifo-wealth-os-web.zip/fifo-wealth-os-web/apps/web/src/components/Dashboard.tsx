'use client';

import React, { useCallback, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import Decimal from 'decimal.js';
import {
  ArrowDownRight,
  ArrowUpRight,
  Calculator,
  FolderKanban,
  LogIn,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UploadCloud,
} from 'lucide-react';
import { useDashboardAnalytics, usePortfolios } from '@/lib/queries';
import { useAuthStore, usePortfolioStore } from '@/lib/stores';
import { cn, extractApiErrorMessage, formatSignedTHB, formatTHB } from '@/lib/utils';
import { mockDashboardAnalyticsByBenchmark } from '@/mocks/mockAnalytics';
import { mockPortfolios } from '@/mocks/mockPortfolios';
import { BenchmarkSymbol } from '@/types/analytics';
import { PortfolioCard } from '@/components/PortfolioCard';
import { MultiAssetTickerBar } from '@/components/common/MultiAssetTickerBar';
import { TaxLossHarvester } from '@/components/wave1/TaxLossHarvester';
import {
  INITIAL_MOCK_TICKERS,
  TickerItem,
  tickerPricesToTHB,
} from '@/data/mockTickerData';
import { MetricsGrid } from '@/components/analytics/MetricsGrid';
import { PerformanceChart } from '@/components/analytics/PerformanceChart';
import { AssetAllocationChart } from '@/components/analytics/AssetAllocationChart';
import { ErrorMessage } from '@/components/ErrorMessage';
import { LoadingSpinner } from '@/components/LoadingSpinner';

const Dec = Decimal.clone({ precision: 28, rounding: Decimal.ROUND_HALF_UP });
const EMPTY_PORTFOLIOS = [] as typeof mockPortfolios;

export function Dashboard() {
  const t = useTranslations('dashboard');
  const user = useAuthStore((s) => s.user);
  const token = useAuthStore((s) => s.token);
  const isHydrated = useAuthStore((s) => s.isHydrated);

  const selectedTaxYear = usePortfolioStore((s) => s.selectedTaxYear);
  const setSelectedTaxYear = usePortfolioStore((s) => s.setSelectedTaxYear);

  const [benchmark, setBenchmark] = useState<BenchmarkSymbol>('SP500');
  const [selectedPortfolioFilter, setSelectedPortfolioFilter] = useState<string>('ALL');
  const [marketTickers, setMarketTickers] =
    useState<TickerItem[]>(INITIAL_MOCK_TICKERS);
  const [currentPrices, setCurrentPrices] = useState<Record<string, string>>(
    () => tickerPricesToTHB(INITIAL_MOCK_TICKERS)
  );

  const handleMarketPriceUpdate = useCallback((updatedTickers: TickerItem[]) => {
    setMarketTickers(updatedTickers);
    setCurrentPrices(tickerPricesToTHB(updatedTickers));
  }, []);

  const portfoliosQuery = usePortfolios();
  const activePortfolioParam =
    selectedPortfolioFilter === 'ALL' ? undefined : selectedPortfolioFilter;

  const analyticsQuery = useDashboardAnalytics(benchmark, activePortfolioParam);

  const portfolios = token
    ? (portfoliosQuery.data ?? EMPTY_PORTFOLIOS)
    : mockPortfolios;
  const activeAnalytics = token
    ? analyticsQuery.data
    : mockDashboardAnalyticsByBenchmark[benchmark];

  const aggregated = useMemo(() => {
    let totalMarketValue = new Dec(0);
    let totalOpenCostBasis = new Dec(0);
    let totalRealizedGL = new Dec(0);
    let totalUnrealizedGL = new Dec(0);
    let totalTxCount = 0;

    for (const p of portfolios) {
      totalTxCount += p.transactionCount ?? 0;
      if (p.fifoSummary) {
        totalMarketValue = totalMarketValue.plus(new Dec(p.fifoSummary.marketValueTHB || 0));
        totalOpenCostBasis = totalOpenCostBasis.plus(
          new Dec(p.fifoSummary.openCostBasisTHB || 0)
        );
        totalRealizedGL = totalRealizedGL.plus(new Dec(p.fifoSummary.totalRealizedGL || 0));
        totalUnrealizedGL = totalUnrealizedGL.plus(
          new Dec(p.fifoSummary.totalUnrealizedGL || 0)
        );
      }
    }

    // Also incorporate Cash + Allocation total if analytics is loaded and larger
    let allocSum = new Dec(0);
    for (const item of activeAnalytics?.assetAllocation ?? []) {
      allocSum = allocSum.plus(new Dec(item.valueTHB || '0'));
    }

    const portfolioValue = allocSum.gt(0) ? allocSum : totalMarketValue;
    const totalGain = totalRealizedGL.plus(totalUnrealizedGL);
    const baseDenominator = totalOpenCostBasis.gt(0) ? totalOpenCostBasis : new Dec(1);
    const gainPct = totalOpenCostBasis.gt(0)
      ? totalGain.dividedBy(baseDenominator).times(100).toDecimalPlaces(2).toFixed(2)
      : '0.00';

    return {
      portfolioValue: portfolioValue.toFixed(2),
      openCostBasis: totalOpenCostBasis.toFixed(2),
      realizedGL: totalRealizedGL.toFixed(2),
      unrealizedGL: totalUnrealizedGL.toFixed(2),
      totalGain: totalGain.toFixed(2),
      gainPct,
      totalTxCount,
      isGainPositive: totalGain.gte(0),
      isRealizedPositive: totalRealizedGL.gte(0),
      isUnrealizedPositive: totalUnrealizedGL.gte(0),
    };
  }, [portfolios, activeAnalytics]);

  if (!isHydrated || (token && portfoliosQuery.isLoading)) {
    return <LoadingSpinner fullScreen label={t('loadingPortfolio')} />;
  }

  if (token && portfoliosQuery.isError) {
    return (
      <ErrorMessage
        title={t('portfolioLoadError')}
        message={extractApiErrorMessage(portfoliosQuery.error, t('requestErrorFallback'))}
        onRetry={() => portfoliosQuery.refetch()}
      />
    );
  }

  const firstPortfolioId = portfolios[0]?.id ?? 'mock-portfolio-ibkr';

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-6"
    >
      {/* Preview Mode Minimalist Notice (when not signed in) */}
      {!token && (
        <div className="flex flex-col justify-between gap-3 rounded-2xl border border-emerald-200/70 bg-emerald-50/70 px-5 py-3.5 sm:flex-row sm:items-center dark:border-emerald-900/50 dark:bg-emerald-950/30">
          <div className="flex items-center gap-2.5 text-xs text-[#14342a] dark:text-emerald-200">
            <Sparkles className="h-4 w-4 shrink-0 text-[#059669] dark:text-[#4ade80]" />
            <span>
              <strong>{t('previewLead')}</strong> {t('previewDescription')}
            </span>
          </div>
          <Link
            href="/login"
            className="inline-flex items-center justify-center gap-1.5 self-start rounded-xl bg-[#14342a] px-3.5 py-2 text-xs font-semibold text-white shadow-sm transition hover:bg-[#1b4538] sm:self-auto"
          >
            <LogIn className="h-3.5 w-3.5" />
            {t('signInDemo')}
          </Link>
        </div>
      )}

      {/* Top Minimalist Header & Action Bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
            {token && user ? `${user.name}` : t('eyebrow')}
          </p>
          <h1
            data-testid="dashboard-heading"
            className="mt-1 text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100 sm:text-3xl"
          >
            {t('title')}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <span className="font-medium text-gray-500 dark:text-gray-400">{t('taxYearLabel')}</span>
            <select
              aria-label={t('selectTaxYear')}
              value={selectedTaxYear}
              onChange={(e) => setSelectedTaxYear(Number(e.target.value))}
              className="bg-transparent font-bold text-gray-900 tabular-nums focus:outline-none dark:text-gray-100"
            >
              {[2026, 2025, 2024].map((yr) => (
                <option
                  key={yr}
                  value={yr}
                  className="bg-white text-gray-900 dark:bg-[#1E1E1E] dark:text-gray-100"
                >
                  {yr} ({t('taxYearEra')} {yr + 543})
                </option>
              ))}
            </select>
          </div>

          <Link
            href="/upload"
            className="inline-flex items-center gap-2 rounded-xl bg-gray-100 px-4 py-2.5 text-xs font-semibold text-gray-900 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-100 dark:hover:bg-gray-700"
          >
            <UploadCloud className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
            {t('uploadCsv')}
          </Link>

          <Link
            href={`/tax/${firstPortfolioId}/${selectedTaxYear}`}
            className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#1b4538]"
          >
            <Calculator className="h-4 w-4" />
            {t('taxReport')}
          </Link>
        </div>
      </div>

      <MultiAssetTickerBar
        items={marketTickers}
        onPriceUpdate={handleMarketPriceUpdate}
      />
      <TaxLossHarvester currentPrices={currentPrices} />

      {/* Clean Minimalist Net Worth Hero Card + Realized/Unrealized Summary Cards */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Main Portfolio Value Card (text-4xl Primary / Deep Ink) */}
        <div className="flex flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] lg:col-span-6">
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                {t('totalPortfolioValue')}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-[#14342a]/8 px-2.5 py-0.5 text-[11px] font-semibold text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                <ShieldCheck className="h-3.5 w-3.5" />
                {t('fifoPrecision')}
              </span>
            </div>

            <p
              data-testid="hero-portfolio-value"
              className="mt-3 text-4xl font-bold tracking-tight text-[#14342a] tabular-nums dark:text-white"
            >
              {formatTHB(aggregated.portfolioValue)}
            </p>

            <div className="mt-3 flex flex-wrap items-center gap-2.5">
              <span
                className={cn(
                  'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-bold tabular-nums',
                  aggregated.isGainPositive
                    ? 'bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400'
                    : 'bg-red-50 text-[#DC2626] dark:bg-red-950/60 dark:text-rose-400'
                )}
              >
                {aggregated.isGainPositive ? (
                  <ArrowUpRight className="h-3.5 w-3.5" />
                ) : (
                  <ArrowDownRight className="h-3.5 w-3.5" />
                )}
                {formatSignedTHB(aggregated.totalGain)} (
                {aggregated.isGainPositive ? '+' : ''}
                {aggregated.gainPct}%)
              </span>
              <span className="text-xs text-gray-500 tabular-nums dark:text-gray-400">
                {t('portfolioTransactions', { portfolios: portfolios.length, transactions: aggregated.totalTxCount })}
              </span>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-4 border-t border-gray-100 pt-4 dark:border-gray-800">
            <div>
              <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">
                {t('openCostBasis')}
              </p>
              <p className="mt-0.5 text-base font-bold text-gray-900 tabular-nums dark:text-gray-100">
                {formatTHB(aggregated.openCostBasis)}
              </p>
            </div>
            <div>
              <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">
                {t('unrealizedGain')}
              </p>
              <p
                className={cn(
                  'mt-0.5 text-base font-bold tabular-nums',
                  aggregated.isUnrealizedPositive
                    ? 'text-[#059669] dark:text-emerald-400'
                    : 'text-[#DC2626] dark:text-rose-400'
                )}
              >
                {formatSignedTHB(aggregated.unrealizedGL)}
              </p>
            </div>
          </div>
        </div>

        {/* Realized P&L & Tax Readiness Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:col-span-6">
          <div className="flex flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
                  {t('realizedGain')}
                </span>
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400">
                  <TrendingUp className="h-4 w-4" />
                </div>
              </div>
              <p
                className={cn(
                  'mt-4 text-2xl sm:text-3xl font-bold tracking-tight tabular-nums',
                  aggregated.isRealizedPositive
                    ? 'text-[#059669] dark:text-emerald-400'
                    : 'text-[#DC2626] dark:text-rose-400'
                )}
              >
                {formatSignedTHB(aggregated.realizedGL)}
              </p>
            </div>
            <p className="mt-4 text-xs text-gray-500 dark:text-gray-400">
              {t('fifoMethod')}
            </p>
          </div>

          <div className="flex flex-col justify-between rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
                  {t('taxStatus', { year: selectedTaxYear })}
                </span>
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#14342a]/8 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                  <Calculator className="h-4 w-4" />
                </div>
              </div>
              <p className="mt-4 text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
                {t('taxPdfReady')}
              </p>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <span className="text-xs text-gray-500 dark:text-gray-400">
                {t('taxSections')}
              </span>
              <Link
                href={`/tax/${firstPortfolioId}/${selectedTaxYear}`}
                className="text-xs font-bold text-[#14342a] hover:underline dark:text-[#4ade80]"
              >
                {t('viewTaxSummary')}
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Quant Engine Section */}
      <section className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-gray-900 dark:text-gray-100">
              {t('quantTitle')}
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {t('quantSubtitle')}
            </p>
          </div>

          {token && (
            <div className="flex flex-wrap items-center gap-2">
              <select
                aria-label={t('quantPortfolioScope')}
                value={selectedPortfolioFilter}
                onChange={(e) => setSelectedPortfolioFilter(e.target.value)}
                className="rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs font-semibold text-gray-800 shadow-sm focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/15 dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-200"
              >
                <option value="ALL">{t('allPortfolios', { count: portfolios.length })}</option>
                {portfolios.map((p) => (
                  <option key={p.id} value={p.id}>
                    {t('specificPortfolio', { name: p.name })}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={() => analyticsQuery.refetch()}
                title={t('refreshAnalytics')}
                className="inline-flex items-center gap-1.5 rounded-xl bg-gray-100 px-3 py-2 text-xs font-semibold text-gray-800 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
              >
                <RefreshCw
                  className={cn('h-3.5 w-3.5', analyticsQuery.isFetching && 'animate-spin')}
                />
                {t('refresh')}
              </button>
            </div>
          )}
        </div>

        {token && analyticsQuery.isError ? (
          <ErrorMessage
            title={t('quantLoadError')}
            message={extractApiErrorMessage(analyticsQuery.error, t('requestErrorFallback'))}
            onRetry={() => analyticsQuery.refetch()}
          />
        ) : (
          <>
            <MetricsGrid
              metrics={activeAnalytics?.metrics}
              isLoading={Boolean(token && analyticsQuery.isLoading)}
            />

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
              <div className="lg:col-span-7">
                <PerformanceChart
                  data={activeAnalytics?.benchmarkSeries ?? []}
                  benchmark={benchmark}
                  onBenchmarkChange={setBenchmark}
                  isLoading={Boolean(token && analyticsQuery.isLoading)}
                />
              </div>
              <div className="lg:col-span-5">
                <AssetAllocationChart
                  allocations={activeAnalytics?.assetAllocation ?? []}
                  isLoading={Boolean(token && analyticsQuery.isLoading)}
                />
              </div>
            </div>
          </>
        )}
      </section>

      {/* Portfolio Cards Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-gray-900 dark:text-gray-100">
              {t('portfolioListTitle', { count: portfolios.length })}
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {t('portfolioListSubtitle')}
            </p>
          </div>

          <Link
            href="/portfolios"
            className="inline-flex items-center gap-1.5 rounded-xl bg-gray-100 px-3.5 py-2 text-xs font-semibold text-gray-900 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-100 dark:hover:bg-gray-700"
          >
            <Plus className="h-3.5 w-3.5" />
            {t('managePortfolios')}
          </Link>
        </div>

        {portfolios.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-200 bg-white p-10 text-center shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <FolderKanban className="mx-auto mb-3 h-10 w-10 text-[#14342a] dark:text-[#4ade80]" />
            <h3 className="text-base font-bold text-gray-900 dark:text-gray-100">
              {t('createFirstPortfolio')}
            </h3>
            <p className="mx-auto mt-1 max-w-md text-xs text-gray-500 dark:text-gray-400">
              {t('emptyPortfolioDescription')}
            </p>
            <Link
              href="/portfolios"
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-[#1b4538]"
            >
              <Plus className="h-4 w-4" />
              {t('createPortfolio')}
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {portfolios.map((portfolio) => (
              <PortfolioCard
                key={portfolio.id}
                portfolio={portfolio}
                taxYear={selectedTaxYear}
              />
            ))}
          </div>
        )}
      </section>
    </motion.div>
  );
}

export default Dashboard;
