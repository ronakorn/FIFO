'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import { useQueryClient } from '@tanstack/react-query';
import {
  ArrowRight,
  Award,
  CheckCircle2,
  Clock,
  FileCheck2,
  KeyRound,
  Loader2,
  Lock,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { Link } from '@/navigation';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import { cn, extractApiErrorMessage } from '@/lib/utils';
import type {
  ThaiBrokerConnectionPublic,
  ThaiBrokerDisconnectResult,
  ThaiBrokerId,
  ThaiBrokerSyncResult,
} from '@/types/thaiBrokers';

const INITIAL_BROKERS: ThaiBrokerConnectionPublic[] = [
  {
    id: null,
    broker: 'BITKUB',
    displayName: 'Bitkub Exchange',
    regulatoryBadge:
      'License status and API scope are pending provider confirmation.',
    partnerBadge: 'Partner integration ready',
    connectionMode: 'READ_ONLY_API',
    dataSource: 'NOT_TESTED',
    maskedAccountRef: null,
    portfolioId: null,
    status: 'DISCONNECTED',
    connected: false,
    readOnly: true,
    encryption: 'AES-256-GCM',
    pdpaConsented: false,
    pdpaConsentedAt: null,
    pdpaConsentVersion: null,
    lastSyncedAt: null,
    futureRoadmapNote: null,
  },
  {
    id: null,
    broker: 'DIME',
    displayName: 'Dime!',
    regulatoryBadge:
      'Confirm license status and service scope with the provider before live activation.',
    partnerBadge: 'Partner integration ready',
    connectionMode: 'OPEN_API_HYBRID',
    dataSource: 'NOT_TESTED',
    maskedAccountRef: null,
    portfolioId: null,
    status: 'DISCONNECTED',
    connected: false,
    readOnly: true,
    encryption: 'AES-256-GCM',
    pdpaConsented: false,
    pdpaConsentedAt: null,
    pdpaConsentVersion: null,
    lastSyncedAt: null,
    futureRoadmapNote:
      'Dime! Open API and statement automation are pending provider access.',
  },
  {
    id: null,
    broker: 'STREAMING',
    displayName: 'Settrade Streaming',
    regulatoryBadge:
      'Statement format and access rights require provider approval before live use.',
    partnerBadge: 'Partner integration ready',
    connectionMode: 'SECURE_STATEMENT_AUTOMATION',
    dataSource: 'NOT_TESTED',
    maskedAccountRef: null,
    portfolioId: null,
    status: 'DISCONNECTED',
    connected: false,
    readOnly: true,
    encryption: 'AES-256-GCM',
    pdpaConsented: false,
    pdpaConsentedAt: null,
    pdpaConsentVersion: null,
    lastSyncedAt: null,
    futureRoadmapNote: null,
  },
];

function BrokerBrandLogo({ broker }: { broker: ThaiBrokerId }) {
  if (broker === 'BITKUB') {
    return (
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#0B1F17] shadow-xs ring-1 ring-emerald-500/30">
        <svg
          viewBox="0 0 40 40"
          className="h-7 w-7"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M20 4L34 12V28L20 36L6 28V12L20 4Z"
            stroke="#00D66C"
            strokeWidth="2.6"
          />
          <path
            d="M14 14.5H21.5C23.7 14.5 25.2 15.8 25.2 17.6C25.2 19 24.3 20 22.9 20.4C24.7 20.8 25.8 22 25.8 23.8C25.8 25.9 24.1 27.3 21.4 27.3H14V14.5Z"
            fill="#00D66C"
          />
          <circle cx="30" cy="10" r="2.2" fill="#4ADE80" />
        </svg>
      </div>
    );
  }

  if (broker === 'DIME') {
    return (
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#00C853] to-[#14342a] shadow-xs ring-1 ring-emerald-400/40">
        <svg
          viewBox="0 0 40 40"
          className="h-7 w-7"
          fill="none"
          aria-hidden="true"
        >
          <rect
            x="6"
            y="8"
            width="28"
            height="24"
            rx="8"
            fill="#FFFFFF"
            fillOpacity="0.14"
          />
          <text
            x="19"
            y="25"
            textAnchor="middle"
            fill="#FFFFFF"
            fontSize="13.5"
            fontWeight="800"
            fontFamily="sans-serif"
          >
            Dime!
          </text>
          <circle cx="31" cy="11" r="2.5" fill="#BEF264" />
        </svg>
      </div>
    );
  }

  return (
    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#0F2C59] shadow-xs ring-1 ring-amber-400/40">
      <svg
        viewBox="0 0 40 40"
        className="h-7 w-7"
        fill="none"
        aria-hidden="true"
      >
        <path
          d="M8 28L15.5 20L21.5 24.5L31.5 12.5"
          stroke="#FBBF24"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M25.5 12.5H31.5V18.5"
          stroke="#FBBF24"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <rect x="9" y="30" width="22" height="2.5" rx="1.25" fill="#93C5FD" />
      </svg>
    </div>
  );
}

const BROKER_TRANSLATION_KEYS = {
  BITKUB: { short: 'BITKUB.short', protocol: 'BITKUB.protocol', assets: 'BITKUB.assets', integration: 'BITKUB.integration', regulatory: 'BITKUB.regulatory' },
  DIME: { short: 'DIME.short', protocol: 'DIME.protocol', assets: 'DIME.assets', integration: 'DIME.integration', regulatory: 'DIME.regulatory' },
  STREAMING: { short: 'STREAMING.short', protocol: 'STREAMING.protocol', assets: 'STREAMING.assets', integration: 'STREAMING.integration', regulatory: 'STREAMING.regulatory' },
} as const;

interface ThaiBrokerConnectionHubProps {
  selectedPortfolioId?: string;
  onSyncCompleted?: (result: ThaiBrokerSyncResult) => void;
}

export function ThaiBrokerConnectionHub({
  selectedPortfolioId,
  onSyncCompleted,
}: ThaiBrokerConnectionHubProps) {
  const queryClient = useQueryClient();
  const token = useAuthStore((s) => s.token);
  const t = useTranslations('thaiBroker');
  const tStatus = useTranslations('thaiBroker.status');
  const tMeta = useTranslations('thaiBroker.meta');
  const tBrokers = useTranslations('thaiBroker.brokers');
  const tConsent = useTranslations('thaiBroker.consent');

  const formatRelativeLastSynced = (isoDate: string | null): string => {
    if (!isoDate) return tStatus('neverSynced');
    const timestamp = Date.parse(isoDate);
    if (Number.isNaN(timestamp)) return tStatus('lastSynced');
    const diffMinutes = Math.floor(Math.max(0, Date.now() - timestamp) / 60_000);
    if (diffMinutes <= 0) return tStatus('justNow');
    if (diffMinutes === 1) return tStatus('oneMinute');
    if (diffMinutes < 60) return tStatus('minutes', { count: diffMinutes });
    return tStatus('hours', { count: Math.floor(diffMinutes / 60) });
  };

  const [connections, setConnections] =
    useState<ThaiBrokerConnectionPublic[]>(INITIAL_BROKERS);
  const [syncingBroker, setSyncingBroker] = useState<ThaiBrokerId | null>(null);
  const [purgingBroker, setPurgingBroker] = useState<ThaiBrokerId | null>(null);
  const [syncResults, setSyncResults] = useState<
     Partial<Record<ThaiBrokerId, ThaiBrokerSyncResult>>
  >({});
  const [purgeBanner, setPurgeBanner] = useState<string | null>(null);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  // Connect + PDPA Consent Modal states
  const [activeModalBroker, setActiveModalBroker] =
    useState<ThaiBrokerId | null>(null);
  const [pdpaAccepted, setPdpaAccepted] = useState(false);
  const [submittingConnect, setSubmittingConnect] = useState(false);

  // Credential fields
  const [bitkubApiKey, setBitkubApiKey] = useState('');
  const [bitkubApiSecret, setBitkubApiSecret] = useState('');
  const [dimeAccountRef, setDimeAccountRef] = useState('');
  const [dimePartnerToken, setDimePartnerToken] = useState('');
  const [streamingBrokerCode, setStreamingBrokerCode] = useState('INVX');
  const [streamingAccountRef, setStreamingAccountRef] = useState('');
  const [streamingSyncToken, setStreamingSyncToken] = useState('');

  const fetchHubStatus = useCallback(async () => {
    if (!token) return;
    try {
      const { data } = await api.get<{
        connections: ThaiBrokerConnectionPublic[];
      }>('/thai-brokers/status');
      if (data.connections && data.connections.length > 0) {
        setConnections(data.connections);
      }
    } catch {
      // Keep default state gracefully
    }
  }, [token]);

  useEffect(() => {
    fetchHubStatus();
  }, [fetchHubStatus]);

  const openConnectModal = (broker: ThaiBrokerId) => {
    setErrorBanner(null);
    setPurgeBanner(null);
    setPdpaAccepted(false);
    setActiveModalBroker(broker);
  };

  const handleDemoFill = (broker: ThaiBrokerId) => {
    if (broker === 'BITKUB') {
      setBitkubApiKey('btk_ro_partner_demo_9988');
      setBitkubApiSecret('btk_hmac_secret_readonly_2026_demo');
    } else if (broker === 'DIME') {
      setDimeAccountRef('DIME-KKP-884420');
      setDimePartnerToken('dime_oauth_ro_sandbox_2026');
    } else {
      setStreamingBrokerCode('INVX');
      setStreamingAccountRef('023-889910-2');
      setStreamingSyncToken('SET-STMT-AUTO-9901');
    }
    // Demo fill never records or implies consent; the person must actively check the consent box.
  };

  const handleConnectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeModalBroker) return;
    setErrorBanner(null);

    if (!pdpaAccepted) {
      setErrorBanner(tConsent('consentRequired'));
      return;
    }

    setSubmittingConnect(true);
    try {
      if (token) {
        const payload: Record<string, unknown> = {
          pdpaConsent: {
            accepted: true,
            consentVersion: 'PDPA-SEC-TH-2026.1',
            purposes: ['READ_ONLY_PORTFOLIO_SYNC', 'THAI_TAX_FIFO_CALCULATION'],
          },
        };
        if (
          selectedPortfolioId &&
          !selectedPortfolioId.startsWith('mock-')
        ) {
          payload.portfolioId = selectedPortfolioId;
        }

        if (activeModalBroker === 'BITKUB') {
          payload.apiKey = bitkubApiKey.trim();
          payload.apiSecret = bitkubApiSecret.trim();
          payload.permissionsScope = 'READ_ONLY';
        } else if (activeModalBroker === 'DIME') {
          payload.dimeAccountRef = dimeAccountRef.trim();
          payload.partnerAccessToken = dimePartnerToken.trim() || undefined;
          payload.mode = 'OPEN_API_HYBRID';
        } else {
          payload.memberBrokerCode = streamingBrokerCode.trim();
          payload.accountRef = streamingAccountRef.trim();
          payload.statementSyncToken = streamingSyncToken.trim();
        }

        const { data } = await api.post<{
          connection: ThaiBrokerConnectionPublic;
        }>(`/thai-brokers/${activeModalBroker}/connect`, payload);

        setConnections((prev) =>
          prev.map((c) =>
            c.broker === activeModalBroker ? data.connection : c
          )
        );
      } else {
        // Guest Pitch-Deck Preview Mode
        const nowIso = new Date().toISOString();
        setConnections((prev) =>
          prev.map((c) =>
            c.broker === activeModalBroker
              ? {
                  ...c,
                  id: `demo-${activeModalBroker}`,
                  status: 'CONNECTED',
                  connected: true,
                  maskedAccountRef: `${activeModalBroker}-****8899`,
                  pdpaConsented: true,
                  pdpaConsentedAt: nowIso,
                  pdpaConsentVersion: 'PDPA-SEC-TH-2026.1',
                }
              : c
          )
        );
      }

      setActiveModalBroker(null);
      setBitkubApiKey('');
      setBitkubApiSecret('');
      setDimeAccountRef('');
      setDimePartnerToken('');
      setStreamingAccountRef('');
      setStreamingSyncToken('');
    } catch (err) {
      setErrorBanner(extractApiErrorMessage(err, t('requestError')));
    } finally {
      setSubmittingConnect(false);
    }
  };

  const handleSyncNow = async (broker: ThaiBrokerId) => {
    setErrorBanner(null);
    setPurgeBanner(null);
    setSyncingBroker(broker);

    setConnections((prev) =>
      prev.map((c) => (c.broker === broker ? { ...c, status: 'SYNCING' } : c))
    );

    try {
      if (token) {
        const payload: { portfolioId?: string; delayMs?: number } = {
          delayMs: 350,
        };
        if (
          selectedPortfolioId &&
          !selectedPortfolioId.startsWith('mock-')
        ) {
          payload.portfolioId = selectedPortfolioId;
        }

        const { data } = await api.post<ThaiBrokerSyncResult>(
          `/thai-brokers/${broker}/sync`,
          payload
        );

        setConnections((prev) =>
          prev.map((c) =>
            c.broker === broker
              ? {
                  ...c,
                  status: 'CONNECTED',
                  connected: true,
                  dataSource: data.dataSource,
                  portfolioId: data.portfolioId,
                  lastSyncedAt: data.lastSyncedAt,
                }
              : c
          )
        );
        setSyncResults((prev) => ({ ...prev, [broker]: data }));

        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ['portfolios'] }),
          queryClient.invalidateQueries({ queryKey: ['portfolio'] }),
          queryClient.invalidateQueries({ queryKey: ['transactions'] }),
          queryClient.invalidateQueries({ queryKey: ['dashboardAnalytics'] }),
        ]);

        onSyncCompleted?.(data);
      } else {
        await new Promise((r) => setTimeout(r, 450));
        const nowIso = new Date().toISOString();
        const demoSync: ThaiBrokerSyncResult = {
          broker,
          connectionMode: 'READ_ONLY_API',
          dataSource: 'SANDBOX_MOCK',
          portfolioId: selectedPortfolioId ?? 'mock-portfolio-1',
          addedTransactions: 3,
          addedDividends: broker === 'BITKUB' ? 0 : 1,
          skippedTransactions: 0,
          skippedDividends: 0,
          status: 'CONNECTED',
          lastSyncedAt: nowIso,
        };
        setConnections((prev) =>
          prev.map((c) =>
            c.broker === broker
              ? {
                  ...c,
                  status: 'CONNECTED',
                  dataSource: 'SANDBOX_MOCK',
                  lastSyncedAt: nowIso,
                }
              : c
          )
        );
        setSyncResults((prev) => ({ ...prev, [broker]: demoSync }));
        onSyncCompleted?.(demoSync);
      }
    } catch (err) {
      setErrorBanner(extractApiErrorMessage(err, t('requestError')));
      setConnections((prev) =>
        prev.map((c) =>
          c.broker === broker ? { ...c, status: 'CONNECTED' } : c
        )
      );
    } finally {
      setSyncingBroker(null);
    }
  };

  const handleDisconnectAndPurge = async (broker: ThaiBrokerId) => {
    setErrorBanner(null);
    setPurgingBroker(broker);
    try {
      let purgedCount = 0;
      let purgedDividendsCount = 0;
      if (token) {
        const { data } = await api.delete<ThaiBrokerDisconnectResult>(
          `/thai-brokers/${broker}/disconnect?purgeData=true`
        );
        purgedCount = data.purgedTransactionsCount;
        purgedDividendsCount = data.purgedDividendsCount;
        setConnections((prev) =>
          prev.map((c) => (c.broker === broker ? data.connection : c))
        );

        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ['portfolios'] }),
          queryClient.invalidateQueries({ queryKey: ['portfolio'] }),
          queryClient.invalidateQueries({ queryKey: ['transactions'] }),
          queryClient.invalidateQueries({ queryKey: ['dashboardAnalytics'] }),
        ]);
      } else {
        const fallback = INITIAL_BROKERS.find((b) => b.broker === broker)!;
        setConnections((prev) =>
          prev.map((c) => (c.broker === broker ? fallback : c))
        );
      }

      setSyncResults((prev) => {
        const next = { ...prev };
        delete next[broker];
        return next;
      });
      const brokerKey = BROKER_TRANSLATION_KEYS[broker].short;
      setPurgeBanner(t('purgeSuccess', {
        broker: tBrokers(brokerKey),
        transactions: purgedCount,
        dividends: purgedDividendsCount,
      }));
    } catch (err) {
      setErrorBanner(extractApiErrorMessage(err, t('requestError')));
    } finally {
      setPurgingBroker(null);
    }
  };

  return (
    <section
      data-testid="thai-broker-connection-hub"
      className="rounded-2xl border border-gray-200/90 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      {/* Pitch-Deck Executive Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-gray-100 pb-5 dark:border-gray-800 lg:flex-row lg:items-start">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span
              data-testid="partner-integration-ready-badge"
              className="inline-flex items-center gap-1.5 rounded-full border border-amber-300/80 bg-gradient-to-r from-[#14342a] via-[#1b4538] to-[#14342a] px-3 py-1 text-xs font-bold text-amber-200 shadow-2xs"
            >
              <Award className="h-3.5 w-3.5 text-amber-300" />
              {tMeta('partnerReady')}
            </span>

            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-[#059669] dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-300">
              <ShieldCheck className="h-3.5 w-3.5" />
              {tMeta('regulatory')}
            </span>

            <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2.5 py-1 text-[11px] font-semibold text-gray-700 dark:bg-gray-800 dark:text-gray-300">
              <Lock className="h-3 w-3 text-[#14342a] dark:text-[#4ade80]" />
              {tMeta('readOnly')}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {tMeta('title')}
          </h2>
          <p className="max-w-3xl text-xs sm:text-sm leading-relaxed text-gray-500 dark:text-gray-400">
            {tMeta('subtitle')}
          </p>
        </div>
      </div>

      <div className="mt-4 rounded-xl border border-blue-200/80 bg-blue-50/70 px-4 py-3 text-[11px] leading-relaxed text-blue-950 dark:border-blue-900/50 dark:bg-blue-950/25 dark:text-blue-200">
        <strong>{tMeta('partnerNoticeTitle')}</strong> {tMeta('partnerNotice')}
      </div>

      {/* Feedback Banners */}
      {purgeBanner && (
        <div
          data-testid="pdpa-purge-success-banner"
          className="mt-4 flex items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/90 px-4 py-3 text-xs font-medium text-emerald-950 dark:border-emerald-800/60 dark:bg-emerald-950/35 dark:text-emerald-200"
        >
          <span className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-[#059669]" />
            {purgeBanner}
          </span>
          <button
            type="button"
            onClick={() => setPurgeBanner(null)}
            aria-label={tConsent('close')}
            className="text-emerald-700 hover:text-emerald-950 dark:text-emerald-300"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {errorBanner && !activeModalBroker && (
        <div className="mt-4 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
          {errorBanner}
        </div>
      )}

      {/* 3-Column Partner Cards Grid */}
      <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-3">
        {connections.map((conn) => {
          const brokerKeys = BROKER_TRANSLATION_KEYS[conn.broker];
          const meta = {
            shortTitle: tBrokers(brokerKeys.short),
            protocolLabel: tBrokers(brokerKeys.protocol),
            assetsSupported: tBrokers(brokerKeys.assets),
            integrationNote: tBrokers(brokerKeys.integration),
          };
          const isSyncing =
            syncingBroker === conn.broker || conn.status === 'SYNCING';
          const isPurging = purgingBroker === conn.broker;
          const syncRes = syncResults[conn.broker];

          return (
            <div
              key={conn.broker}
              data-testid={`thai-broker-card-${conn.broker}`}
              className={cn(
                'flex flex-col justify-between rounded-2xl border p-5 transition-all',
                conn.connected
                  ? 'border-emerald-300/80 bg-gradient-to-b from-emerald-50/35 via-white to-white shadow-xs dark:border-emerald-800/60 dark:from-emerald-950/20 dark:via-[#181B20] dark:to-[#181B20]'
                  : 'border-gray-200/90 bg-gray-50/40 dark:border-gray-800 dark:bg-[#16191D]'
              )}
            >
              <div className="space-y-4">
                {/* Brand Logo + Status Pill */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <BrokerBrandLogo broker={conn.broker} />
                    <div>
                      <h3 className="text-base font-bold text-gray-900 dark:text-gray-100">
                        {meta.shortTitle}
                      </h3>
                      <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">
                        {meta.protocolLabel}
                      </p>
                    </div>
                  </div>

                  {isSyncing ? (
                    <span
                      data-testid={`broker-status-${conn.broker}`}
                      className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-bold text-amber-900 dark:bg-amber-950/60 dark:text-amber-300"
                    >
                      <Loader2 className="h-3 w-3 animate-spin" />
                      {tStatus('syncing')}
                    </span>
                  ) : conn.connected ? (
                    <span
                      data-testid={`broker-status-${conn.broker}`}
                      className={cn(
                        'inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold',
                        conn.dataSource === 'SANDBOX_MOCK'
                          ? 'bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300'
                          : conn.dataSource === 'NOT_TESTED'
                            ? 'bg-gray-200 text-gray-700 dark:bg-gray-800 dark:text-gray-300'
                            : 'bg-emerald-100 text-[#059669] dark:bg-emerald-950/70 dark:text-emerald-300'
                      )}
                    >
                      <span
                        className={cn(
                          'h-1.5 w-1.5 rounded-full',
                          conn.dataSource === 'SANDBOX_MOCK'
                            ? 'bg-amber-500'
                            : conn.dataSource === 'NOT_TESTED'
                              ? 'bg-gray-400'
                              : 'bg-[#059669]'
                        )}
                      />
                      {conn.dataSource === 'NOT_TESTED'
                        ? tStatus('credentialsSaved')
                        : conn.dataSource === 'SANDBOX_MOCK'
                          ? tStatus('sandboxDemo')
                          : tStatus('connected')}
                    </span>
                  ) : (
                    <span
                      data-testid={`broker-status-${conn.broker}`}
                      className="inline-flex shrink-0 items-center rounded-full bg-gray-200/80 px-2.5 py-1 text-[11px] font-semibold text-gray-600 dark:bg-gray-800 dark:text-gray-400"
                    >
                      {tStatus('notConnected')}
                    </span>
                  )}
                </div>

                {/* Partner Badge + Assets */}
                <div className="space-y-2">
                  <div
                    title={
                      conn.broker === 'DIME' || conn.broker === 'STREAMING'
                        ? tMeta('partnerReadyHint')
                        : undefined
                    }
                    aria-label={tMeta('partnerReadyAria')}
                    data-testid={`partner-ready-badge-${conn.broker}`}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[10px] font-semibold text-emerald-700 dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-300"
                  >
                    <Sparkles className="h-3 w-3" />
                    {tMeta('partnerReady')}
                  </div>

                  <p className="text-xs leading-relaxed text-gray-600 dark:text-gray-300">
                    {meta.assetsSupported}
                  </p>
                  <p className="text-[11px] leading-relaxed text-gray-500 dark:text-gray-400">
                    {meta.integrationNote}
                  </p>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">
                    {tBrokers(brokerKeys.regulatory)}
                  </p>
                </div>

                {/* Streaming SET Open API Pitch-Deck Callout */}
                {conn.broker === 'STREAMING' && (
                  <div
                    data-testid="streaming-set-openapi-roadmap"
                    className="rounded-xl border border-amber-200/90 bg-amber-50/80 p-3 text-[11px] leading-relaxed text-amber-950 dark:border-amber-800/50 dark:bg-amber-950/30 dark:text-amber-200"
                  >
                    <p className="font-bold flex items-center gap-1.5">
                      <FileCheck2 className="h-3.5 w-3.5 shrink-0 text-amber-700 dark:text-amber-300" />
                      {tMeta('streamingRoadmapTitle')}
                    </p>
                    <p className="mt-0.5 font-medium">
                      {tMeta('roadmap')}
                    </p>
                  </div>
                )}

                {/* Last Synced Timestamp & Masked Account */}
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-gray-100 bg-white/80 px-3 py-2 text-[11px] text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                  <span className="inline-flex items-center gap-1.5 tabular-nums">
                    <Clock className="h-3.5 w-3.5 text-gray-400" />
                    {formatRelativeLastSynced(conn.lastSyncedAt)}
                  </span>
                  {conn.maskedAccountRef && (
                    <span className="font-mono font-semibold text-gray-700 dark:text-gray-300">
                      {conn.maskedAccountRef}
                    </span>
                  )}
                </div>

                {/* Sync Result Pill */}
                {syncRes && (
                  <div
                    data-testid={`thai-broker-sync-result-${conn.broker}`}
                    className="flex items-center justify-between gap-2 rounded-xl border border-emerald-200 bg-emerald-50/80 px-3 py-2 text-xs text-emerald-950 dark:border-emerald-800/60 dark:bg-emerald-950/35 dark:text-emerald-200"
                  >
                    <span className="font-semibold tabular-nums">
                      {t('syncResult', {
                        prefix: syncRes.dataSource === 'SANDBOX_MOCK'
                          ? t('syncSandboxPrefix')
                          : t('syncLivePrefix'),
                        transactions: syncRes.addedTransactions,
                      })}
                      {syncRes.addedDividends > 0 && t('syncDividends', { count: syncRes.addedDividends })}
                      {syncRes.addedDividends === 0 && syncRes.skippedTransactions > 0 && t('syncDuplicates', { count: syncRes.skippedTransactions })}
                    </span>
                    {!syncRes.portfolioId.startsWith('mock-') && (
                      <Link
                        href={`/portfolios/${syncRes.portfolioId}`}
                        className="inline-flex items-center gap-1 font-bold text-[#14342a] underline-offset-2 hover:underline dark:text-[#4ade80]"
                      >
                        {t('viewPortfolio')} <ArrowRight className="h-3 w-3" />
                      </Link>
                    )}
                  </div>
                )}
              </div>

              {/* Action Footer */}
              <div className="mt-5 border-t border-gray-100 pt-4 dark:border-gray-800">
                {conn.connected ? (
                  <div className="flex flex-col gap-2">
                    <button
                      type="button"
                      disabled={isSyncing || isPurging}
                      data-testid={`thai-broker-sync-btn-${conn.broker}`}
                      onClick={() => handleSyncNow(conn.broker)}
                      className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-60"
                    >
                      <RefreshCw
                        className={cn('h-3.5 w-3.5', isSyncing && 'animate-spin')}
                      />
                      <span>{isSyncing ? tStatus('syncing') : t('syncNow')}</span>
                    </button>

                    <button
                      type="button"
                      disabled={isSyncing || isPurging}
                      data-testid={`thai-broker-purge-btn-${conn.broker}`}
                      onClick={() => handleDisconnectAndPurge(conn.broker)}
                      className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-red-200/80 bg-white px-3 py-2 text-[11px] font-semibold text-red-600 transition hover:bg-red-50 dark:border-red-900/50 dark:bg-transparent dark:text-red-400 dark:hover:bg-red-950/30 disabled:opacity-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>
                        {isPurging
                          ? t('purging')
                          : t('disconnectPurge')}
                      </span>
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    data-testid={`thai-broker-connect-btn-${conn.broker}`}
                    onClick={() => openConnectModal(conn.broker)}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
                  >
                    <KeyRound className="h-3.5 w-3.5" />
                    <span>{t('connectReadOnly', { broker: meta.shortTitle })}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* PDPA Data Privacy Consent & Read-Only Connection Modal */}
      {activeModalBroker && (
        <div
          role="dialog"
          aria-modal="true"
          data-testid="pdpa-consent-modal"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 backdrop-blur-xs"
        >
          <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-2xl border border-gray-200 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div className="flex items-start justify-between gap-4 border-b border-gray-100 pb-4 dark:border-gray-800">
              <div className="flex items-center gap-3">
                <BrokerBrandLogo broker={activeModalBroker} />
                <div>
                  <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-bold text-[#059669] dark:bg-emerald-950/50 dark:text-emerald-300">
                    {tConsent('badge')}
                  </span>
                  <h3 className="mt-1 text-lg font-bold text-gray-900 dark:text-gray-100">
                    {tConsent('title', {
                      broker: tBrokers(BROKER_TRANSLATION_KEYS[activeModalBroker].short),
                    })}
                  </h3>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setActiveModalBroker(null)}
                className="rounded-lg p-1 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
                aria-label={tConsent('close')}
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleConnectSubmit} className="mt-4 space-y-4">
              {/* Statutory PDPA Data Privacy Consent Box */}
              <div className="space-y-2.5 rounded-2xl border border-emerald-200/80 bg-emerald-50/50 p-4 text-xs dark:border-emerald-800/50 dark:bg-emerald-950/20">
                <p className="font-bold text-[#14342a] dark:text-[#4ade80]">
                  {tConsent('heading')}
                </p>
                <ul className="space-y-1.5 text-gray-700 dark:text-gray-300">
                  <li>
                    • <strong>{tConsent('purposeTitle')}</strong> {tConsent('purpose')}
                  </li>
                  <li>
                    • <strong>{tConsent('accessTitle')}</strong> {tConsent('access')}
                  </li>
                  <li>
                    • <strong>{tConsent('storageTitle')}</strong> {tConsent('storage')}
                  </li>
                  <li>
                    • <strong>{tConsent('withdrawTitle')}</strong> {tConsent('withdraw')}
                  </li>
                </ul>
                <p className="rounded-lg bg-white/80 px-3 py-2 text-[11px] leading-relaxed text-gray-600 dark:bg-[#14171A] dark:text-gray-400">
{tConsent('privacyNotice')}
                </p>

                <label className="mt-2 flex cursor-pointer items-start gap-2.5 rounded-xl border border-emerald-300/70 bg-white p-3 dark:border-emerald-800 dark:bg-[#14171A]">
                  <input
                    type="checkbox"
                    data-testid="pdpa-consent-checkbox"
                    checked={pdpaAccepted}
                    onChange={(e) => setPdpaAccepted(e.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-gray-300 text-[#14342a] focus:ring-[#14342a]"
                  />
                  <span className="font-semibold text-gray-900 dark:text-gray-100">
{tConsent('checkbox')}
                  </span>
                </label>
              </div>

              {/* Quick Demo Fill Button for Pitch Deck Live Demos */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-gray-700 dark:text-gray-200">
                  {tConsent('credentialsTitle')}
                </span>
                <button
                  type="button"
                  data-testid="demo-fill-credentials-btn"
                  onClick={() => handleDemoFill(activeModalBroker)}
                  className="rounded-lg border border-[#14342a]/20 bg-[#14342a]/5 px-2.5 py-1 text-[11px] font-semibold text-[#14342a] hover:bg-[#14342a]/10 dark:border-[#4ade80]/30 dark:bg-[#4ade80]/10 dark:text-[#4ade80]"
                >
                  {tConsent('demoFill')}
                </button>
              </div>

              {activeModalBroker === 'BITKUB' && (
                <div className="space-y-3">
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                      {tConsent('bitkubKey')}
                    </label>
                    <input
                      type="text"
                      required
                      data-testid="bitkub-api-key-input"
                      value={bitkubApiKey}
                      onChange={(e) => setBitkubApiKey(e.target.value)}
                      placeholder={tConsent('bitkubKeyPlaceholder')}
                      className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-mono text-gray-900 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                      {tConsent('bitkubSecret')}
                    </label>
                    <input
                      type="password"
                      required
                      data-testid="bitkub-api-secret-input"
                      value={bitkubApiSecret}
                      onChange={(e) => setBitkubApiSecret(e.target.value)}
                      placeholder="••••••••••••••••••••••••" aria-label={tConsent('bitkubSecret')}
                      className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-mono text-gray-900 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                    />
                  </div>
                </div>
              )}

              {activeModalBroker === 'DIME' && (
                <div className="space-y-3">
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                      {tConsent('dimeAccount')}
                    </label>
                    <input
                      type="text"
                      required
                      data-testid="dime-account-input"
                      value={dimeAccountRef}
                      onChange={(e) => setDimeAccountRef(e.target.value)}
                      placeholder={tConsent('dimeAccountPlaceholder')}
                      className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-mono text-gray-900 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                      {tConsent('dimeToken')}
                    </label>
                    <input
                      type="password"
                      data-testid="dime-token-input"
                      value={dimePartnerToken}
                      onChange={(e) => setDimePartnerToken(e.target.value)}
                      placeholder={tConsent('optionalToken')}
                      className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-mono text-gray-900 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                    />
                  </div>
                </div>
              )}

              {activeModalBroker === 'STREAMING' && (
                <div className="space-y-3">
                  <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-xs text-amber-950 dark:border-amber-800/50 dark:bg-amber-950/30 dark:text-amber-200">
                    <strong>{tConsent('secureAutomation')}</strong>{' '}
                    {tMeta('roadmap')}
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                    <div>
                      <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                        {tConsent('streamingBroker')}
                      </label>
                      <select
                        value={streamingBrokerCode}
                        onChange={(e) => setStreamingBrokerCode(e.target.value)}
                        className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-xs font-semibold text-gray-900 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                      >
                        <option value="INVX">INVX (InnovestX)</option>
                        <option value="BLS">BLS (Bualuang)</option>
                        <option value="KS">KS (Kasikorn)</option>
                        <option value="KKPS">KKPS (Kiatnakin Phatra)</option>
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                        {tConsent('streamingAccount')}
                      </label>
                      <input
                        type="text"
                        required
                        data-testid="streaming-account-input"
                        value={streamingAccountRef}
                        onChange={(e) => setStreamingAccountRef(e.target.value)}
                        placeholder={tConsent('streamingAccountPlaceholder')}
                        className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-mono text-gray-900 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-semibold text-gray-700 dark:text-gray-300">
                      {tConsent('streamingToken')}
                    </label>
                    <input
                      type="password"
                      required
                      data-testid="streaming-token-input"
                      value={streamingSyncToken}
                      onChange={(e) => setStreamingSyncToken(e.target.value)}
                      placeholder={tConsent('streamingTokenPlaceholder')}
                      className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-mono text-gray-900 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                    />
                  </div>
                </div>
              )}

              {errorBanner && (
                <div className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
                  {errorBanner}
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 border-t border-gray-100 pt-4 dark:border-gray-800">
                <button
                  type="button"
                  onClick={() => setActiveModalBroker(null)}
                  className="rounded-xl border border-gray-200 px-4 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800"
                >
                  {tConsent('cancel')}
                </button>
                <button
                  type="submit"
                  disabled={!pdpaAccepted || submittingConnect}
                  data-testid="confirm-pdpa-connect-btn"
                  className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-5 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {submittingConnect ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <ShieldCheck className="h-4 w-4" />
                  )}
                  <span>{tConsent('confirm')}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}

export default ThaiBrokerConnectionHub;
