'use client';

import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, Copy, QrCode, ShieldCheck, X } from 'lucide-react';
import QRCode from 'qrcode';
import { useTranslations } from 'next-intl';

interface InviteModalProps {
  isOpen: boolean;
  onClose: () => void;
  inviteCode: string;
  groupName: string;
}

export function InviteModal({
  isOpen,
  onClose,
  inviteCode,
  groupName,
}: InviteModalProps) {
  const t = useTranslations('family');
  const [qrSvg, setQrSvg] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen || !inviteCode) return;
    let active = true;

    const payload = `FIFO-WEALTH-OS:${inviteCode}`;
    QRCode.toString(payload, {
      type: 'svg',
      margin: 1,
      width: 176,
      color: {
        dark: '#14342a',
        light: '#FFFFFF',
      },
    })
      .then((svg) => {
        if (active) setQrSvg(svg);
      })
      .catch(() => {
        if (active) setQrSvg('');
      });

    return () => {
      active = false;
    };
  }, [isOpen, inviteCode]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(inviteCode);
    } catch {
      // Fallback for restricted clipboard environments
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          data-testid="family-invite-modal"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            className="w-full max-w-md rounded-2xl border border-gray-100 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="inline-flex items-center gap-1.5 rounded-full bg-[#14342a]/5 px-2.5 py-0.5 text-[11px] font-semibold text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                  <QrCode className="h-3.5 w-3.5" />
                  <span>{groupName}</span>
                </div>
                <h3 className="mt-2 text-lg font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                  {t('inviteModalTitle')}
                </h3>
              </div>

              <button
                type="button"
                onClick={onClose}
                aria-label={t('closeInviteModal')}
                className="rounded-xl p-1.5 text-gray-400 transition hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <p className="mt-1.5 text-xs leading-relaxed text-gray-500 dark:text-gray-400">
              {t('inviteModalSubtitle')}
            </p>

            {/* Scannable Inline SVG QR Code */}
            <div className="mt-5 flex flex-col items-center justify-center rounded-2xl border border-gray-100 bg-[#FAFAFA] p-5 dark:border-gray-800 dark:bg-[#121212]">
              {qrSvg ? (
                <div
                  data-testid="invite-qr-svg"
                  className="overflow-hidden rounded-xl border border-gray-200 bg-white p-2.5 shadow-sm"
                  dangerouslySetInnerHTML={{ __html: qrSvg }}
                />
              ) : (
                <div className="flex h-44 w-44 items-center justify-center rounded-xl bg-white text-gray-400">
                  <QrCode className="h-12 w-12" />
                </div>
              )}

              <span className="mt-3 inline-flex items-center gap-1 text-[11px] font-medium text-[#059669]">
                <ShieldCheck className="h-3.5 w-3.5" />
                {t('privacyFirstSharing')}
              </span>
            </div>

            {/* Copyable Invite Code Box */}
            <div className="mt-4">
              <label className="mb-1.5 block text-xs font-semibold text-gray-600 dark:text-gray-300">
                {t('inviteCodeLabel')}
              </label>
              <div className="flex items-center gap-2">
                <div
                  data-testid="invite-code-display"
                  className="flex h-11 flex-1 items-center justify-center rounded-xl border border-gray-200 bg-[#FAFAFA] px-4 font-mono text-sm font-bold tracking-widest text-[#14342a] tabular-nums dark:border-gray-700 dark:bg-[#121212] dark:text-[#4ade80]"
                >
                  {inviteCode}
                </div>
                <motion.button
                  type="button"
                  whileTap={{ scale: 0.95 }}
                  data-testid="copy-invite-code-btn"
                  onClick={() => void handleCopy()}
                  className="inline-flex h-11 items-center gap-1.5 rounded-xl bg-[#14342a] px-4 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
                >
                  {copied ? (
                    <>
                      <Check className="h-4 w-4 text-emerald-300" />
                      <span>{t('copiedBtn')}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>{t('copyBtn')}</span>
                    </>
                  )}
                </motion.button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

export default InviteModal;
