'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Lock } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { useFamilyDashboard, useUpdateFamilyPrivacy } from '@/lib/queries';
import { useAssistantStore, useAuthStore } from '@/lib/stores';
import { cn } from '@/lib/utils';

export function PrivacyToggle() {
  const t = useTranslations('privacy');
  const token = useAuthStore((s) => s.token);
  const localHide = useAssistantStore((s) => s.hideFamilyTransactions);
  const setLocalHide = useAssistantStore((s) => s.setHideFamilyTransactions);

  const familyQuery = useFamilyDashboard();
  const privacyMutation = useUpdateFamilyPrivacy();
  const [savedNotice, setSavedNotice] = useState<boolean>(false);

  const serverHide = familyQuery.data?.group
    ? !familyQuery.data.group.currentUserPermissions.canSeeTransactions
    : localHide;

  const isHidden = token && familyQuery.data?.group ? serverHide : localHide;

  const handleToggle = async () => {
    const nextHide = !isHidden;
    setLocalHide(nextHide);

    if (token) {
      try {
        await privacyMutation.mutateAsync({ hideTransactions: nextHide });
      } catch {
        // Keep local preference gracefully
      }
    }

    setSavedNotice(true);
    window.setTimeout(() => setSavedNotice(false), 2200);
  };

  return (
    <div
      data-testid="privacy-toggle-card"
      className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#14342a]/5 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
            <Lock className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
              {t('cardTitle')}
            </h3>
            <p className="mt-1 text-xs font-semibold text-[#14342a] dark:text-[#4ade80]">
              {t('toggleLabel')}
            </p>
            <p className="mt-1 text-xs leading-relaxed text-gray-500 dark:text-gray-400">
              {t('toggleDescription')}
            </p>
          </div>
        </div>

        {/* Accessible Minimalist Switch */}
        <motion.button
          type="button"
          role="switch"
          aria-checked={isHidden}
          aria-label={t('toggleLabel')}
          data-testid="privacy-switch"
          whileTap={{ scale: 0.95 }}
          onClick={() => void handleToggle()}
          className={cn(
            'relative inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full transition-colors',
            isHidden ? 'bg-[#14342a]' : 'bg-gray-300 dark:bg-gray-700'
          )}
        >
          <span
            className={cn(
              'inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform',
              isHidden ? 'translate-x-6' : 'translate-x-1'
            )}
          />
        </motion.button>
      </div>

      {savedNotice && (
        <div className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#059669]">
          <CheckCircle2 className="h-3.5 w-3.5" />
          <span>{t('savedStatus')}</span>
        </div>
      )}
    </div>
  );
}

export default PrivacyToggle;
