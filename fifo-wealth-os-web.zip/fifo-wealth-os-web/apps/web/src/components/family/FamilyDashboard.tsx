'use client';

import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Crown,
  KeyRound,
  Lock,
  Plus,
  QrCode,
  ShieldCheck,
  Users,
  X,
} from 'lucide-react';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { useTheme } from 'next-themes';
import { useTranslations } from 'next-intl';
import {
  useCreateFamilyGroup,
  useFamilyDashboard,
  useJoinFamilyGroup,
} from '@/lib/queries';
import { useAuthStore } from '@/lib/stores';
import { mockFamilyDashboard } from '@/mocks/mockJournalFamily';
import { formatTHB } from '@/lib/utils';
import { InviteModal } from './InviteModal';
import { PrivacyToggle } from './PrivacyToggle';
import { EmptyState } from '@/components/ux/EmptyState';
import { ChartTooltip } from '@/components/common/ChartTooltip';

const MEMBER_COLORS = ['#14342a', '#10B981', '#0D9488', '#2563EB', '#D97706'];
const DARK_MEMBER_COLORS = ['#059669', '#4ade80', '#2dd4bf', '#60a5fa', '#fbbf24'];

export function FamilyDashboard() {
  const t = useTranslations('family');
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const palette = isDark ? DARK_MEMBER_COLORS : MEMBER_COLORS;
  const token = useAuthStore((s) => s.token);

  const dashboardQuery = useFamilyDashboard();
  const createGroupMutation = useCreateFamilyGroup();
  const joinGroupMutation = useJoinFamilyGroup();

  const [isInviteOpen, setIsInviteOpen] = useState<boolean>(false);
  const [isJoinOpen, setIsJoinOpen] = useState<boolean>(false);
  const [isCreateOpen, setIsCreateOpen] = useState<boolean>(false);
  const [joinCodeInput, setJoinCodeInput] = useState<string>('');
  const [newGroupName, setNewGroupName] = useState<string>('');
  const [actionError, setActionError] = useState<string | null>(null);

  const data = token ? dashboardQuery.data : mockFamilyDashboard;

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;
    setActionError(null);
    try {
      await createGroupMutation.mutateAsync({ name: newGroupName.trim() });
      setIsCreateOpen(false);
      setNewGroupName('');
    } catch {
      setActionError(t('actionCreateError'));
    }
  };

  const handleJoinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCodeInput.trim()) return;
    setActionError(null);
    try {
      await joinGroupMutation.mutateAsync({
        inviteCode: joinCodeInput.trim().toUpperCase(),
      });
      setIsJoinOpen(false);
      setJoinCodeInput('');
    } catch {
      setActionError(t('actionJoinError'));
    }
  };

  if (token && dashboardQuery.isLoading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-16 w-72 rounded-2xl bg-gray-200 dark:bg-gray-800" />
        <div className="h-44 rounded-2xl bg-gray-200 dark:bg-gray-800" />
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="h-80 rounded-2xl bg-gray-200 dark:bg-gray-800" />
          <div className="h-80 rounded-2xl bg-gray-200 dark:bg-gray-800" />
        </div>
      </div>
    );
  }

  const chartData = (data?.members ?? []).map((m, idx) => ({
    name: m.name,
    value: Number(m.netWorthTHB),
    sharePercent: m.sharePercent,
    netWorthTHB: m.netWorthTHB,
    color: palette[idx % palette.length]!,
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-8"
    >
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
            {t('eyebrow')}
          </p>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
            {t('title')}
          </h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {t('subtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <motion.button
            type="button"
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsJoinOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-gray-100 px-3.5 py-2.5 text-xs font-semibold text-gray-900 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-100"
          >
            <KeyRound className="h-3.5 w-3.5" />
            <span>{t('joinBtn')}</span>
          </motion.button>

          {data?.hasGroup && data.group ? (
            <motion.button
              type="button"
              whileTap={{ scale: 0.95 }}
              data-testid="open-invite-modal-btn"
              onClick={() => setIsInviteOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
            >
              <QrCode className="h-4 w-4" />
              <span>{t('inviteBtn')}</span>
            </motion.button>
          ) : (
            <motion.button
              type="button"
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsCreateOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e]"
            >
              <Plus className="h-4 w-4" />
              <span>{t('createGroupBtn')}</span>
            </motion.button>
          )}
        </div>
      </div>

      {!data?.hasGroup || !data.group ? (
        <EmptyState
          title={t('emptyTitle')}
          description={t('emptyDescription')}
          actionLabel={t('createGroupBtn')}
          onActionClick={() => setIsCreateOpen(true)}
        />
      ) : (
        <>
          {/* Hero Household Net Worth Card */}
          <div
            data-testid="household-net-worth-card"
            className="rounded-2xl border border-gray-100 bg-white p-6 sm:p-8 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-[#14342a]/5 px-3 py-1 text-xs font-semibold text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                  <Users className="h-3.5 w-3.5" />
                  <span>{data.group.name}</span>
                </div>
                <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-gray-500 dark:text-gray-400">
                  {t('householdNetWorth')}
                </p>
                <p
                  data-testid="household-net-worth-value"
                  className="mt-1 text-3xl sm:text-5xl font-extrabold tracking-tight text-[#14342a] tabular-nums dark:text-[#4ade80]"
                >
                  {formatTHB(data.householdNetWorthTHB)}
                </p>
              </div>

              <div className="rounded-2xl border border-emerald-200/70 bg-emerald-50/70 px-4 py-3 dark:border-emerald-900/50 dark:bg-emerald-950/30">
                <div className="flex items-center gap-2 text-xs font-bold text-[#059669] dark:text-emerald-400">
                  <ShieldCheck className="h-4 w-4 shrink-0" />
                  <span>{t('zeroExposureTitle')}</span>
                </div>
                <p className="mt-1 max-w-xs text-[11px] leading-relaxed text-gray-600 dark:text-gray-300">
                  {t('privacyBadge')}
                </p>
              </div>
            </div>
          </div>

          {/* 2-Column Grid: Member Share Donut Chart + Member Breakdown */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Donut Chart */}
            <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] lg:col-span-5">
              <h2 className="text-base font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                {t('shareChartTitle')}
              </h2>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                {t('shareChartSubtitle')}
              </p>

              <div className="mt-4 h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={62}
                      outerRadius={92}
                      paddingAngle={3}
                      strokeWidth={0}
                      isAnimationActive={false}
                    >
                      {chartData.map((entry, idx) => (
                        <Cell key={idx} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={(
                        <ChartTooltip
                          formatter={(value, name) => {
                            const member = chartData.find((item) => item.name === String(name ?? ''));
                            const amount = Array.isArray(value) ? value[0] ?? 0 : value ?? 0;
                            return {
                              label: name ?? t('tooltipNetWorth'),
                              value: formatTHB(amount),
                              detail: t('tooltipShare', { percent: member?.sharePercent ?? '0' }),
                            };
                          }}
                        />
                      )}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-2 space-y-2">
                {chartData.map((item) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="h-2.5 w-2.5 shrink-0 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="truncate font-medium text-gray-700 dark:text-gray-300">
                        {item.name}
                      </span>
                    </div>
                    <span className="font-bold text-[#14342a] tabular-nums dark:text-[#4ade80]">
                      {item.sharePercent}%
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Members List & Privacy Control */}
            <div className="space-y-4 lg:col-span-7">
              <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
                <h2 className="text-base font-bold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5]">
                  {t('membersListTitle')} ({data.members.length})
                </h2>

                <div className="mt-4 space-y-3">
                  {data.members.map((member, idx) => {
                    const color = MEMBER_COLORS[idx % MEMBER_COLORS.length]!;
                    return (
                      <div
                        key={member.memberId}
                        data-testid="family-member-row"
                        className="flex flex-col gap-3 rounded-xl border border-gray-100 bg-[#FAFAFA] p-4 sm:flex-row sm:items-center sm:justify-between dark:border-gray-800 dark:bg-[#121212]"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold text-white"
                            style={{ backgroundColor: color }}
                          >
                            {member.name.slice(0, 1).toUpperCase()}
                          </div>
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-sm font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                                {member.name}
                              </span>
                              <span className="inline-flex items-center gap-1 rounded-full bg-white px-2 py-0.5 text-[10px] font-semibold text-gray-600 shadow-sm dark:bg-[#1E1E1E] dark:text-gray-300">
                                {member.role === 'OWNER' && (
                                  <Crown className="h-3 w-3 text-amber-500" />
                                )}
                                {member.role === 'OWNER'
                                  ? t('roleOwner')
                                  : t('roleViewer')}
                              </span>
                            </div>
                            <div className="mt-1 flex items-center gap-2 text-[11px] text-gray-500 dark:text-gray-400">
                              <span>
                                {t('portfoliosCount', {
                                  count: member.portfolioCount,
                                })}
                              </span>
                              <span>•</span>
                              <span className="inline-flex items-center gap-1 text-[#059669] dark:text-emerald-400">
                                <Lock className="h-3 w-3" />
                                {t('txHiddenBadge')}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="text-left sm:text-right">
                          <p className="text-base font-bold text-[#1A1A1A] tabular-nums dark:text-[#F5F5F5]">
                            {formatTHB(member.netWorthTHB)}
                          </p>
                          <p className="text-xs font-bold text-[#059669] tabular-nums dark:text-emerald-400">
                            {member.sharePercent}%
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <PrivacyToggle />
            </div>
          </div>

          <InviteModal
            isOpen={isInviteOpen}
            onClose={() => setIsInviteOpen(false)}
            inviteCode={data.group.inviteCode}
            groupName={data.group.name}
          />
        </>
      )}

      {/* Join Group Modal */}
      <AnimatePresence>
        {isJoinOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="w-full max-w-md rounded-2xl border border-gray-100 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                  {t('joinModalTitle')}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsJoinOpen(false)}
                  className="rounded-xl p-1.5 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <form onSubmit={handleJoinSubmit} className="mt-4 space-y-4">
                <input
                  type="text"
                  required
                  value={joinCodeInput}
                  onChange={(e) => setJoinCodeInput(e.target.value)}
                  placeholder={t('joinInputPlaceholder')}
                  className="h-11 w-full rounded-xl border border-gray-200 bg-[#FAFAFA] px-4 font-mono text-sm uppercase tracking-wider focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212]"
                />
                {actionError && (
                  <p className="text-xs font-medium text-[#DC2626]">{actionError}</p>
                )}
                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.95 }}
                  className="w-full rounded-xl bg-[#14342a] py-2.5 text-xs font-semibold text-white transition hover:bg-[#0f261e]"
                >
                  {t('joinSubmitBtn')}
                </motion.button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Create Group Modal */}
      <AnimatePresence>
        {isCreateOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="w-full max-w-md rounded-2xl border border-gray-100 bg-white p-6 shadow-xl dark:border-gray-800 dark:bg-[#1E1E1E]"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-[#1A1A1A] dark:text-[#F5F5F5]">
                  {t('createModalTitle')}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="rounded-xl p-1.5 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <form onSubmit={handleCreateSubmit} className="mt-4 space-y-4">
                <input
                  type="text"
                  required
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder={t('createInputPlaceholder')}
                  className="h-11 w-full rounded-xl border border-gray-200 bg-[#FAFAFA] px-4 text-sm focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212]"
                />
                {actionError && (
                  <p className="text-xs font-medium text-[#DC2626]">{actionError}</p>
                )}
                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.95 }}
                  className="w-full rounded-xl bg-[#14342a] py-2.5 text-xs font-semibold text-white transition hover:bg-[#0f261e]"
                >
                  {t('createSubmitBtn')}
                </motion.button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default FamilyDashboard;
