'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import { useDropzone } from 'react-dropzone';
import {
  CheckCircle2,
  CloudUpload,
  Download,
  FileSpreadsheet,
  Sparkles,
  Upload,
} from 'lucide-react';
import { ErrorMessage } from './ErrorMessage';
import { LoadingSpinner } from './LoadingSpinner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { usePortfolios, useUploadCSV, useUploadDividends } from '@/lib/queries';
import { useAuthStore } from '@/lib/stores';
import {
  cn,
  extractApiErrorMessage,
  formatSignedTHB,
  formatTHB,
} from '@/lib/utils';
import {
  SAMPLE_BITKUB_CSV,
  SAMPLE_DIVIDENDS_CSV,
  SAMPLE_IBKR_CSV,
} from '@/mocks/mockTransactions';
import { UploadCSVResponse, UploadDividendsResponse } from '@/types/shared';

type UploadMode = 'IBKR' | 'BITKUB' | 'DIVIDENDS';

export function FileUploader({ defaultPortfolioId }: { defaultPortfolioId?: string }) {
  const t = useTranslations('upload.file');
  const token = useAuthStore((s) => s.token);
  const { data: portfolios, isLoading: loadingPortfolios } = usePortfolios();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const [mode, setMode] = useState<UploadMode>('IBKR');
  const [portfolioId, setPortfolioId] = useState<string>(defaultPortfolioId ?? '');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [tradeResult, setTradeResult] = useState<UploadCSVResponse | null>(null);
  const [divResult, setDivResult] = useState<UploadDividendsResponse | null>(null);
  const [localError, setLocalError] = useState<string | null>(null);

  const uploadCsvMutation = useUploadCSV();
  const uploadDivMutation = useUploadDividends();

  useEffect(() => {
    if (defaultPortfolioId && !defaultPortfolioId.startsWith('mock-')) {
      setPortfolioId(defaultPortfolioId);
      return;
    }
    if (!portfolioId && portfolios && portfolios.length > 0) {
      const first = portfolios[0];
      if (first) {
        setPortfolioId(first.id);
      }
    }
  }, [defaultPortfolioId, portfolioId, portfolios]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setLocalError(null);
    setTradeResult(null);
    setDivResult(null);
    const file = acceptedFiles[0];
    if (!file) {
      setLocalError(t('csvOnly'));
      return;
    }
    setSelectedFile(file);
  }, [t]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.ms-excel': ['.csv'],
    },
    maxFiles: 1,
    multiple: false,
  });

  const handleLoadSampleFile = (targetMode: UploadMode) => {
    setMode(targetMode);
    setLocalError(null);
    setTradeResult(null);
    setDivResult(null);

    const content =
      targetMode === 'IBKR'
        ? SAMPLE_IBKR_CSV
        : targetMode === 'BITKUB'
          ? SAMPLE_BITKUB_CSV
          : SAMPLE_DIVIDENDS_CSV;
    const filename =
      targetMode === 'IBKR'
        ? 'sample_ibkr_trades_2024.csv'
        : targetMode === 'BITKUB'
          ? 'sample_bitkub_trades_2024.csv'
          : 'sample_dividends_2024.csv';

    const file = new File([content], filename, { type: 'text/csv' });
    setSelectedFile(file);
  };

  const handleDownloadSample = (targetMode: UploadMode) => {
    const content =
      targetMode === 'IBKR'
        ? SAMPLE_IBKR_CSV
        : targetMode === 'BITKUB'
          ? SAMPLE_BITKUB_CSV
          : SAMPLE_DIVIDENDS_CSV;
    const filename =
      targetMode === 'IBKR'
        ? 'sample_ibkr_trades_2024.csv'
        : targetMode === 'BITKUB'
          ? 'sample_bitkub_trades_2024.csv'
          : 'sample_dividends_2024.csv';

    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const handleSubmitUpload = async () => {
    setLocalError(null);
    setTradeResult(null);
    setDivResult(null);

    if (!token) {
      setLocalError(t('loginRequired'));
      return;
    }
    if (!portfolioId) {
      setLocalError(t('portfolioRequired'));
      return;
    }
    if (!selectedFile) {
      setLocalError(t('fileRequired'));
      return;
    }

    try {
      if (mode === 'DIVIDENDS') {
        const res = await uploadDivMutation.mutateAsync({
          file: selectedFile,
          portfolioId,
        });
        setDivResult(res);
      } else {
        const res = await uploadCsvMutation.mutateAsync({
          file: selectedFile,
          portfolioId,
          exchange: mode,
        });
        setTradeResult(res);
      }
    } catch (err) {
      setLocalError(extractApiErrorMessage(err, t('genericUploadError')));
    }
  };

  const isSubmitting = uploadCsvMutation.isPending || uploadDivMutation.isPending;

  return (
    <div className="space-y-6">
      {!token && (
        <div className="flex flex-col justify-between gap-3 rounded-2xl border border-amber-200 bg-amber-50/80 p-4 sm:flex-row sm:items-center dark:border-amber-900/50 dark:bg-amber-950/30">
          <div>
            <p className="text-sm font-bold text-amber-900 dark:text-amber-300">
              {t('previewTitle')}
            </p>
            <p className="text-xs text-amber-800/80 dark:text-amber-200/80">
              {t('previewDescription')}
            </p>
          </div>
          <Link
            href="/login"
            className="inline-flex items-center justify-center rounded-xl bg-[#14342a] px-4 py-2 text-xs font-semibold text-white transition hover:bg-[#1b4538]"
          >
            {t('signInToUpload')}
          </Link>
        </div>
      )}

      <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        {/* Step 1: Select Broker Format */}
        <div className="mb-6">
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
            {t('stepBrokerFormat')}
          </label>
          <Tabs
            value={mode}
            onValueChange={(val) => {
              setMode(val as UploadMode);
              setSelectedFile(null);
              setTradeResult(null);
              setDivResult(null);
              setLocalError(null);
            }}
          >
            <TabsList className="w-full sm:w-auto flex-wrap">
              <TabsTrigger value="IBKR">{t('ibkrTab')}</TabsTrigger>
              <TabsTrigger value="BITKUB">{t('bitkubTab')}</TabsTrigger>
              <TabsTrigger value="DIVIDENDS">{t('dividendsTab')}</TabsTrigger>
            </TabsList>

            <TabsContent value="IBKR">
              <div className="rounded-xl border border-gray-100 bg-gray-50/80 p-3.5 text-xs text-gray-600 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-300">
                {t('ibkrDescription')}
              </div>
            </TabsContent>
            <TabsContent value="BITKUB">
              <div className="rounded-xl border border-gray-100 bg-gray-50/80 p-3.5 text-xs text-gray-600 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-300">
                {t('bitkubDescription')}
              </div>
            </TabsContent>
            <TabsContent value="DIVIDENDS">
              <div className="rounded-xl border border-gray-100 bg-gray-50/80 p-3.5 text-xs text-gray-600 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-300">
                {t('dividendsDescription')}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Step 2: Select Target Portfolio */}
        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="portfolio-select"
              className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400"
            >
              {t('stepPortfolio')}
            </label>
            {mounted && loadingPortfolios ? (
              <div className="flex h-11 items-center gap-2 rounded-xl border border-gray-200 bg-gray-50 px-3 text-xs text-gray-500 dark:border-gray-700 dark:bg-[#121212]">
                <LoadingSpinner size="sm" />
                {t('loadingPortfolios')}
              </div>
            ) : (
              <select
                id="portfolio-select"
                value={portfolioId}
                onChange={(e) => setPortfolioId(e.target.value)}
                className="h-11 w-full rounded-xl border border-gray-200 bg-white px-3.5 text-sm font-medium text-gray-900 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/15 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
              >
                <option value="">{t('choosePortfolio')}</option>
                {(mounted ? (portfolios ?? []) : []).map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.baseCurrency})
                  </option>
                ))}
              </select>
            )}
          </div>

          <div>
            <span className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
              {t('sampleTemplates')}
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleLoadSampleFile(mode)}
                className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-[#14342a]/8 px-3.5 text-xs font-bold text-[#14342a] transition hover:bg-[#14342a]/15 dark:bg-[#4ade80]/10 dark:text-[#4ade80] dark:hover:bg-[#4ade80]/20"
              >
                <Sparkles className="h-4 w-4" />
                {t('loadSample', { broker: mode })}
              </button>
              <button
                type="button"
                onClick={() => handleDownloadSample(mode)}
                className="inline-flex h-11 items-center justify-center gap-1.5 rounded-xl bg-gray-100 px-3.5 text-xs font-semibold text-gray-800 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
              >
                <Download className="h-3.5 w-3.5 text-[#059669] dark:text-emerald-400" />
                {t('downloadCsv')}
              </button>
            </div>
          </div>
        </div>

        {/* Step 3: Drag & Drop Zone */}
        <div>
          <span className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
            {t('stepUpload')}
          </span>
          <div
            {...getRootProps()}
            className={cn(
              'cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all',
              isDragActive
                ? 'border-[#059669] bg-emerald-50/70 dark:bg-emerald-950/30'
                : selectedFile
                  ? 'border-[#14342a] bg-[#14342a]/[0.03] dark:border-[#4ade80] dark:bg-[#4ade80]/5'
                  : 'border-gray-200 bg-gray-50/50 hover:border-[#14342a]/50 hover:bg-gray-50 dark:border-gray-700 dark:bg-[#121212] dark:hover:border-gray-600'
            )}
          >
            <input {...getInputProps()} data-testid="csv-file-input" />
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#14342a]/8 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              {selectedFile ? (
                <FileSpreadsheet className="h-7 w-7 text-[#059669] dark:text-emerald-400" />
              ) : (
                <CloudUpload className="h-7 w-7" />
              )}
            </div>

            {selectedFile ? (
              <div className="mt-4 space-y-1">
                <p className="text-sm font-bold text-[#059669] dark:text-emerald-400">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-gray-500 tabular-nums dark:text-gray-400">
                  {t('fileReady', { size: (selectedFile.size / 1024).toFixed(2) })}
                </p>
              </div>
            ) : (
              <div className="mt-4 space-y-1">
                <p className="text-sm font-bold text-gray-900 dark:text-gray-100">
                  {isDragActive
                    ? t('dropActive')
                    : t('dropPrompt')}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('fileLimit')}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-6 flex flex-col items-stretch justify-end gap-3 sm:flex-row sm:items-center">
          <button
            type="button"
            disabled={isSubmitting || !selectedFile}
            onClick={handleSubmitUpload}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1b4538] disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <LoadingSpinner size="sm" className="border-white border-t-transparent" />
                {t('uploading')}
              </>
            ) : (
              <>
                <Upload className="h-4 w-4" />
                {t('uploadAndCalculate')}
              </>
            )}
          </button>
        </div>
      </div>

      {localError && <ErrorMessage title={t('errorTitle')} message={localError} />}

      {/* Success Summary: Trades CSV */}
      {tradeResult && (
        <div className="rounded-2xl border border-emerald-200 bg-white p-6 shadow-sm dark:border-emerald-900/50 dark:bg-[#1E1E1E]">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-gray-900 dark:text-gray-100">
                  {t('tradeSuccess', { count: tradeResult.summary.count })}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('fileSaved', { filename: tradeResult.uploadedFile.filename })}
                </p>
              </div>
            </div>
            <Link
              href={`/portfolios/${portfolioId}`}
              className="inline-flex items-center justify-center rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-[#1b4538]"
            >
              {t('viewPortfolio')}
            </Link>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-xl bg-gray-50 p-3.5 dark:bg-[#121212]">
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{t('realizedGl')}</p>
              <p className="mt-1 text-base font-bold text-[#059669] tabular-nums dark:text-emerald-400">
                {formatSignedTHB(tradeResult.summary.totalRealizedGL)}
              </p>
            </div>
            <div className="rounded-xl bg-gray-50 p-3.5 dark:bg-[#121212]">
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{t('unrealizedGl')}</p>
              <p className="mt-1 text-base font-bold text-gray-900 tabular-nums dark:text-gray-100">
                {formatSignedTHB(tradeResult.summary.totalUnrealizedGL)}
              </p>
            </div>
            <div className="rounded-xl bg-gray-50 p-3.5 dark:bg-[#121212]">
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{t('costSold')}</p>
              <p className="mt-1 text-base font-bold text-gray-800 tabular-nums dark:text-gray-200">
                {formatTHB(tradeResult.summary.totalCostSold)}
              </p>
            </div>
            <div className="rounded-xl bg-gray-50 p-3.5 dark:bg-[#121212]">
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{t('netProceeds')}</p>
              <p className="mt-1 text-base font-bold text-gray-800 tabular-nums dark:text-gray-200">
                {formatTHB(tradeResult.summary.totalProceeds)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Success Summary: Dividends CSV */}
      {divResult && (
        <div className="rounded-2xl border border-emerald-200 bg-white p-6 shadow-sm dark:border-emerald-900/50 dark:bg-[#1E1E1E]">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-gray-900 dark:text-gray-100">
                  {t('dividendSuccess', { count: divResult.summary.count })}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('dividendTaxHint')}
                </p>
              </div>
            </div>
            <Link
              href={`/tax/${portfolioId}/2024`}
              className="inline-flex items-center justify-center rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-[#1b4538]"
            >
              {t('viewTaxReport')}
            </Link>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-gray-50 p-3.5 dark:bg-[#121212]">
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{t('grossDividend')}</p>
              <p className="mt-1 text-base font-bold text-gray-900 tabular-nums dark:text-gray-100">
                {formatTHB(divResult.summary.totalGrossTHB)}
              </p>
            </div>
            <div className="rounded-xl bg-gray-50 p-3.5 dark:bg-[#121212]">
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{t('wht')}</p>
              <p className="mt-1 text-base font-bold text-amber-700 tabular-nums dark:text-amber-300">
                {formatTHB(divResult.summary.totalWhtTHB)}
              </p>
            </div>
            <div className="rounded-xl bg-gray-50 p-3.5 dark:bg-[#121212]">
              <p className="text-[11px] text-gray-500 dark:text-gray-400">{t('netDividend')}</p>
              <p className="mt-1 text-base font-bold text-[#059669] tabular-nums dark:text-emerald-400">
                {formatTHB(divResult.summary.totalNetTHB)}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default FileUploader;
