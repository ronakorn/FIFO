'use client';

import React from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import {
  ArrowRight,
  Calculator,
  FolderKanban,
  Trash2,
  UploadCloud,
} from 'lucide-react';
import { Portfolio } from '@/types/shared';
import { cn, formatDateShort, formatSignedTHB, formatTHB } from '@/lib/utils';

interface PortfolioCardProps {
  portfolio: Portfolio;
  taxYear?: number;
  onDelete?: (portfolioId: string) => void;
}

export function PortfolioCard({
  portfolio,
  taxYear = 2024,
  onDelete,
}: PortfolioCardProps) {
  const t = useTranslations('portfolioCard');
  const locale = useLocale();
  const summary = portfolio.fifoSummary;
  const txCount = portfolio.transactionCount ?? 0;
  const marketVal = summary?.marketValueTHB ?? 0;
  const realizedGL = summary?.totalRealizedGL ?? 0;
  const isPositive = realizedGL >= 0;
  const isMock = portfolio.id.startsWith('mock-');

  return (
    <div className="group flex flex-col justify-between rounded-2xl border border-gray-100 bg-white p-5 shadow-sm transition hover:border-[#14342a]/30 hover:shadow-md dark:border-gray-800 dark:bg-[#1E1E1E] dark:hover:border-[#4ade80]/30">
      <div>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#14342a]/8 text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <FolderKanban className="h-5 w-5" />
            </div>
            <div>
              <Link
                href={`/portfolios/${portfolio.id}`}
                className="text-base font-bold tracking-tight text-gray-900 transition group-hover:text-[#14342a] dark:text-gray-100 dark:group-hover:text-[#4ade80]"
              >
                {portfolio.name}
              </Link>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t('baseCurrency')} {portfolio.baseCurrency} • {t('createdOn', { date: formatDateShort(portfolio.createdAt, locale === 'th' ? 'th-TH' : 'en-GB') })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="rounded-full bg-gray-100 px-2.5 py-1 text-[11px] font-semibold text-gray-700 tabular-nums dark:bg-[#121212] dark:text-gray-300">
              {t('transactionCount', { count: txCount })}
            </span>
            {onDelete && !isMock && (
              <button
                type="button"
                aria-label={t('deletePortfolio', { name: portfolio.name })}
                onClick={() => onDelete(portfolio.id)}
                className="rounded-lg p-1.5 text-gray-400 transition hover:bg-red-50 hover:text-[#DC2626] dark:hover:bg-red-950/40 dark:hover:text-rose-400"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Financial Metrics Summary */}
        <div className="mt-4 grid grid-cols-2 gap-3 rounded-xl bg-gray-50/80 p-3.5 dark:bg-[#121212]">
          <div>
            <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">
              {t('marketValue')}
            </p>
            <p className="mt-0.5 text-sm sm:text-base font-bold text-gray-900 tabular-nums dark:text-gray-100">
              {formatTHB(marketVal)}
            </p>
          </div>
          <div>
            <p className="text-[11px] font-medium text-gray-500 dark:text-gray-400">
              {t('realizedGL')}
            </p>
            <p
              className={cn(
                'mt-0.5 text-sm sm:text-base font-bold tabular-nums',
                isPositive
                  ? 'text-[#059669] dark:text-emerald-400'
                  : 'text-[#DC2626] dark:text-rose-400'
              )}
            >
              {formatSignedTHB(realizedGL)}
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-gray-100 pt-3.5 dark:border-gray-800">
        <div className="flex items-center gap-1.5">
          <Link
            href={`/upload?portfolioId=${portfolio.id}`}
            className="inline-flex items-center gap-1 rounded-xl bg-gray-100 px-3 py-1.5 text-xs font-semibold text-gray-800 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
          >
            <UploadCloud className="h-3.5 w-3.5" />
            {t('csvImport')}
          </Link>
          <Link
            href={`/tax/${portfolio.id}/${taxYear}`}
            className="inline-flex items-center gap-1 rounded-xl bg-[#14342a]/8 px-3 py-1.5 text-xs font-semibold text-[#14342a] transition hover:bg-[#14342a]/15 dark:bg-[#4ade80]/10 dark:text-[#4ade80] dark:hover:bg-[#4ade80]/20"
          >
            <Calculator className="h-3.5 w-3.5" />
            {t('taxYear', { year: taxYear })}
          </Link>
        </div>

        <Link
          href={`/portfolios/${portfolio.id}`}
          className="inline-flex items-center gap-1 text-xs font-bold text-[#14342a] transition hover:translate-x-0.5 dark:text-[#4ade80]"
        >
          {t('openPortfolio')}
          <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  );
}

export default PortfolioCard;
