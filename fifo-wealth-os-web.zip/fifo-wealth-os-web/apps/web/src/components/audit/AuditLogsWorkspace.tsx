'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import {
  ArrowLeft,
  CheckCircle2,
  Eye,
  FileJson2,
  Lock,
  PlusCircle,
  RefreshCw,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import { Link } from '@/navigation';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import { cn, extractApiErrorMessage } from '@/lib/utils';

export type AuditActionType = 'CREATE' | 'UPDATE' | 'DELETE';
export type AuditEntityKind = 'GOLD_TRANSACTION' | 'PORTFOLIO';

export interface AuditLogClientItem {
  id: string;
  userId: string;
  action: AuditActionType;
  entityType: AuditEntityKind;
  entityId: string;
  beforeState: string | null;
  afterState: string | null;
  ipAddress: string | null;
  timestamp: string;
}

const DEMO_AUDIT_LOGS: AuditLogClientItem[] = [
  {
    id: 'audit-demo-roll-open-1',
    userId: 'demo-user',
    action: 'CREATE',
    entityType: 'GOLD_TRANSACTION',
    entityId: 'tx-roll-goh27-open',
    beforeState: null,
    afterState: JSON.stringify({
      symbol: 'GOH27',
      type: 'BUY',
      weight: '3.0000',
      spotPricePerUnit: '2781.00',
      commission: '12.50',
      rolloverFee: '12.50',
      isRollover: true,
      legAction: 'OPEN_LONG',
      rolloverGroupId: '8f4c2b10-91e4-4d88-a2b1-77c90e12d445',
    }),
    ipAddress: '203.150.214.18',
    timestamp: '2026-10-26T08:42:10.000Z',
  },
  {
    id: 'audit-demo-roll-close-1',
    userId: 'demo-user',
    action: 'CREATE',
    entityType: 'GOLD_TRANSACTION',
    entityId: 'tx-roll-goz26-close',
    beforeState: null,
    afterState: JSON.stringify({
      symbol: 'GOZ26',
      type: 'SELL',
      weight: '3.0000',
      spotPricePerUnit: '2758.50',
      rolloverFee: '12.50',
      isRollover: true,
      legAction: 'CLOSE_LONG',
      rolloverGroupId: '8f4c2b10-91e4-4d88-a2b1-77c90e12d445',
    }),
    ipAddress: '203.150.214.18',
    timestamp: '2026-10-26T08:42:09.000Z',
  },
  {
    id: 'audit-demo-update-1',
    userId: 'demo-user',
    action: 'UPDATE',
    entityType: 'GOLD_TRANSACTION',
    entityId: 'tx-gold965-lot-01',
    beforeState: JSON.stringify({
      symbol: 'GOLD965',
      type: 'BUY',
      weight: '5.0000',
      spotPricePerUnit: '41000.00',
      premiumPerUnit: '200.00',
      totalCost: '206000.00',
    }),
    afterState: JSON.stringify({
      symbol: 'GOLD965',
      type: 'BUY',
      weight: '5.0000',
      spotPricePerUnit: '41250.00',
      premiumPerUnit: '250.00',
      totalCost: '207500.00',
    }),
    ipAddress: '203.150.214.18',
    timestamp: '2026-10-26T07:15:30.000Z',
  },
  {
    id: 'audit-demo-delete-1',
    userId: 'demo-user',
    action: 'DELETE',
    entityType: 'GOLD_TRANSACTION',
    entityId: 'tx-xauusd-draft-09',
    beforeState: JSON.stringify({
      symbol: 'XAUUSD',
      type: 'BUY',
      date: '2024-10-01',
      weight: '1.0000',
      spotPricePerUnit: '2650.00',
      fxRateAtPurchase: '36.7500',
    }),
    afterState: null,
    ipAddress: '203.150.214.18',
    timestamp: '2026-10-26T06:50:12.000Z',
  },
];

interface AuditSummaryLabels {
  quantity: string;
  fx: string;
  rolloverFee: string;
  group: string;
}

function summarizeJsonState(jsonStr: string | null, labels: AuditSummaryLabels): string {
  if (!jsonStr) return 'null';
  try {
    const parsed = JSON.parse(jsonStr) as Record<string, unknown>;
    const parts: string[] = [];
    if (parsed['symbol']) parts.push(`${String(parsed['symbol'])}`);
    if (parsed['type']) parts.push(`${String(parsed['type'])}`);
    if (parsed['weight']) parts.push(`${labels.quantity} ${String(parsed['weight'])}`);
    if (parsed['spotPricePerUnit'])
      parts.push(`@${String(parsed['spotPricePerUnit'])}`);
    if (parsed['fxRateAtPurchase'])
      parts.push(`${labels.fx} ${String(parsed['fxRateAtPurchase'])}`);
    if (parsed['rolloverFee'])
      parts.push(`${labels.rolloverFee} $${String(parsed['rolloverFee'])}`);
    if (parsed['rolloverGroupId'])
      parts.push(`${labels.group} #${String(parsed['rolloverGroupId']).slice(0, 8)}`);
    return parts.length > 0 ? parts.join(' • ') : jsonStr.slice(0, 80);
  } catch {
    return jsonStr.slice(0, 80);
  }
}

function prettyJson(jsonStr: string | null): string {
  if (!jsonStr) return 'null';
  try {
    return JSON.stringify(JSON.parse(jsonStr), null, 2);
  } catch {
    return jsonStr;
  }
}

export function AuditLogsWorkspace() {
  const t = useTranslations('AuditTrail');
  const token = useAuthStore((s) => s.token);
  const auditSummaryLabels: AuditSummaryLabels = {
    quantity: t('summaryQuantity'),
    fx: t('summaryFx'),
    rolloverFee: t('summaryRolloverFee'),
    group: t('summaryGroup'),
  };

  const [logs, setLogs] = useState<AuditLogClientItem[]>(DEMO_AUDIT_LOGS);
  const [filterAction, setFilterAction] = useState<'ALL' | AuditActionType>(
    'ALL'
  );
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [inspectedLog, setInspectedLog] = useState<AuditLogClientItem | null>(
    null
  );

  const fetchAuditLogs = useCallback(async () => {
    if (!token) {
      setLogs(DEMO_AUDIT_LOGS);
      return;
    }
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await api.get<{ logs: AuditLogClientItem[] }>('/audit-logs');
      setLogs(res.data.logs);
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setLoading(false);
    }
  }, [token, t]);

  useEffect(() => {
    void fetchAuditLogs();
  }, [fetchAuditLogs]);

  const counts = useMemo(() => {
    return {
      total: logs.length,
      creates: logs.filter((l) => l.action === 'CREATE').length,
      updates: logs.filter((l) => l.action === 'UPDATE').length,
      deletes: logs.filter((l) => l.action === 'DELETE').length,
    };
  }, [logs]);

  const filteredLogs = useMemo(() => {
    if (filterAction === 'ALL') return logs;
    return logs.filter((l) => l.action === filterAction);
  }, [logs, filterAction]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
            {t('eyebrow')}
          </p>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {t('title')}
          </h1>
          <p className="mt-1 max-w-3xl text-xs sm:text-sm leading-relaxed text-gray-500 dark:text-gray-400">
            {t('subtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => void fetchAuditLogs()}
            className="inline-flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-gray-700 shadow-2xs hover:bg-gray-50 dark:border-gray-700 dark:bg-[#1E1E1E] dark:text-gray-200"
          >
            <RefreshCw className={cn('h-3.5 w-3.5', loading && 'animate-spin')} />
            {t('refreshBtn')}
          </button>

          <Link
            href="/gold"
            className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-sm transition hover:bg-[#1c4739] dark:bg-[#4ade80] dark:text-[#0d221b]"
          >
            <ArrowLeft className="h-4 w-4" />
            {t('backToGoldBtn')}
          </Link>
        </div>
      </div>

      {/* PDPA / GDPR Security Assurance Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-200/80 bg-emerald-50/70 px-4 py-3.5 text-xs text-[#14342a] dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-200">
        <div className="flex items-center gap-2.5 font-semibold">
          <Lock className="h-4 w-4 shrink-0 text-[#14342a] dark:text-[#4ade80]" />
          <span>
            {t('immutableBanner')}
          </span>
        </div>
        <span className="rounded-full bg-[#14342a] px-2.5 py-0.5 font-mono text-[10px] font-bold text-white dark:bg-[#4ade80] dark:text-[#0d221b]">
          {t('complianceReady')}
        </span>
      </div>

      {errorMsg && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-semibold text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300">
          {errorMsg}
        </div>
      )}

      {/* 4 Audit KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiTotal')}
            </span>
            <ShieldCheck className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-gray-900 dark:text-gray-100">
            {counts.total}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiCreates')}
            </span>
            <PlusCircle className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-emerald-600 dark:text-emerald-400">
            {counts.creates}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiUpdates')}
            </span>
            <CheckCircle2 className="h-4 w-4 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-amber-600 dark:text-amber-400">
            {counts.updates}
          </p>
        </div>

        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
              {t('kpiDeletes')}
            </span>
            <Trash2 className="h-4 w-4 text-red-600 dark:text-red-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-red-600 dark:text-red-400">
            {counts.deletes}
          </p>
        </div>
      </div>

      {/* Audit Logs Ledger Table */}
      <div
        data-testid="audit-trail-table"
        className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
      >
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4">
          <div className="flex flex-wrap items-center gap-1.5">
            {(['ALL', 'CREATE', 'UPDATE', 'DELETE'] as const).map((act) => (
              <button
                key={act}
                type="button"
                onClick={() => setFilterAction(act)}
                className={cn(
                  'rounded-xl px-3.5 py-1.5 font-mono text-xs font-bold transition',
                  filterAction === act
                    ? 'bg-[#14342a] text-white dark:bg-[#4ade80] dark:text-[#0d221b]'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300'
                )}
              >
                {act === 'ALL' ? t('filterAll') : act}
              </button>
            ))}
          </div>
        </div>

        {filteredLogs.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-200 py-12 text-center text-xs sm:text-sm text-gray-500 dark:border-gray-800">
            {t('emptyState')}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:text-gray-400">
                  <th className="pb-3 pr-4">{t('colTimestamp')}</th>
                  <th className="pb-3 pr-4">{t('colAction')}</th>
                  <th className="pb-3 pr-4">{t('colEntity')}</th>
                  <th className="pb-3 pr-4">{t('colIp')}</th>
                  <th className="pb-3 pr-4">{t('colStateDiff')}</th>
                  <th className="pb-3 text-right">{t('colJson')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {filteredLogs.map((log) => (
                  <tr
                    key={log.id}
                    className="transition hover:bg-gray-50/70 dark:hover:bg-gray-800/40"
                  >
                    <td className="py-3.5 pr-4 font-mono text-xs whitespace-nowrap text-gray-600 dark:text-gray-300">
                      {new Date(log.timestamp).toISOString().replace('T', ' ').slice(0, 19)} UTC
                    </td>
                    <td className="py-3.5 pr-4">
                      <span
                        className={cn(
                          'inline-flex rounded-full px-2.5 py-0.5 font-mono text-[11px] font-bold',
                          log.action === 'CREATE' &&
                            'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300',
                          log.action === 'UPDATE' &&
                            'bg-amber-50 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300',
                          log.action === 'DELETE' &&
                            'bg-red-50 text-red-700 dark:bg-red-950/60 dark:text-red-300'
                        )}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="py-3.5 pr-4 font-mono text-xs">
                      <p className="font-bold text-gray-900 dark:text-gray-100">
                        {log.entityType}
                      </p>
                      <p className="text-[11px] text-gray-400">
                        #{log.entityId.slice(0, 14)}
                      </p>
                    </td>
                    <td className="py-3.5 pr-4 font-mono text-xs text-gray-500">
                      {log.ipAddress ?? '—'}
                    </td>
                    <td className="py-3.5 pr-4 font-mono text-[11px] leading-relaxed">
                      {log.beforeState && (
                        <div className="text-red-600 dark:text-red-400">
                          <span className="font-bold">{t('beforeLabel')}</span>{' '}
                          {summarizeJsonState(log.beforeState, auditSummaryLabels)}
                        </div>
                      )}
                      {log.afterState && (
                        <div className="text-emerald-700 dark:text-emerald-400">
                          <span className="font-bold">{t('afterLabel')}</span>{' '}
                          {summarizeJsonState(log.afterState, auditSummaryLabels)}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 text-right">
                      <button
                        type="button"
                        onClick={() => setInspectedLog(log)}
                        className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-[11px] font-semibold text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-200"
                      >
                        <Eye className="h-3.5 w-3.5" />
                        {t('inspectBtn')}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Full JSON Diff Inspector Modal */}
      <Dialog
        open={Boolean(inspectedLog)}
        onOpenChange={(open) => {
          if (!open) setInspectedLog(null);
        }}
      >
        <DialogContent className="max-w-2xl rounded-2xl p-6">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-lg font-bold">
              <FileJson2 className="h-5 w-5 text-[#14342a] dark:text-[#4ade80]" />
              {t('recordSnapshotTitle', { action: inspectedLog?.action ?? '' })}
            </DialogTitle>
            <DialogDescription className="font-mono text-xs">
              ID: {inspectedLog?.id} • {t('entityLabel')}: {inspectedLog?.entityType} (#
              {inspectedLog?.entityId})
            </DialogDescription>
          </DialogHeader>

          {inspectedLog && (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <p className="font-mono text-xs font-bold text-red-700 dark:text-red-400">
                  {t('beforeStateJson')}
                </p>
                <pre className="max-h-72 overflow-auto rounded-xl border border-gray-200 bg-[#F8FAFC] p-3 font-mono text-[11px] text-gray-800 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-200">
                  {prettyJson(inspectedLog.beforeState)}
                </pre>
              </div>
              <div className="space-y-1.5">
                <p className="font-mono text-xs font-bold text-emerald-700 dark:text-emerald-400">
                  {t('afterStateJson')}
                </p>
                <pre className="max-h-72 overflow-auto rounded-xl border border-gray-200 bg-[#F8FAFC] p-3 font-mono text-[11px] text-gray-800 dark:border-gray-800 dark:bg-gray-900 dark:text-gray-200">
                  {prettyJson(inspectedLog.afterState)}
                </pre>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
