'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { useQueryClient } from '@tanstack/react-query';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Coins,
  Fingerprint,
  Layers,
  Loader2,
  Lock,
  Plus,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Trash2,
  Wallet,
} from 'lucide-react';
import { Link } from '@/navigation';
import api from '@/lib/api';
import { useAuthStore } from '@/lib/stores';
import { cn, extractApiErrorMessage } from '@/lib/utils';
import type {
  CryptoWalletPublic,
  CryptoWalletSyncResult,
  SupportedChain,
} from '@/types/crypto';

const EVM_ADDRESS_RE = /^0x[a-fA-F0-9]{40}$/;
const BTC_ADDRESS_RE =
  /^(bc1[ac-hj-np-z02-9]{25,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/;
const SOLANA_ADDRESS_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

const EVM_PRIVKEY_RE = /^(0x)?[a-fA-F0-9]{64}$/;
const BTC_WIF_RE = /^[5KL][1-9A-HJ-NP-Za-km-z]{50,51}$/;
const EXT_PRIVKEY_RE = /^(xprv|yprv|zprv|tprv)[a-zA-Z0-9]{90,120}$/;
const SOL_SECRET_BASE58_RE = /^[1-9A-HJ-NP-Za-km-z]{80,96}$/;
const SOL_SECRET_JSON_RE = /^\[\s*\d+(?:\s*,\s*\d+){31,64}\s*\]$/;

interface AddressInspection {
  isPrivateKeyRisk: boolean;
  detectedChain: SupportedChain | null;
  reasonKey?: 'blockedSeed' | 'blockedPrivateKey';
}

function inspectAddressClientSide(raw: string): AddressInspection {
  const trimmed = raw.trim();
  if (!trimmed) {
    return { isPrivateKeyRisk: false, detectedChain: null };
  }

  const words = trimmed.split(/\s+/).filter(Boolean);
  if (words.length >= 3 && words.every((w) => /^[a-zA-Z]+$/.test(w))) {
    return {
      isPrivateKeyRisk: true,
      detectedChain: null,
      reasonKey: 'blockedSeed',
    };
  }

  if (
    EVM_PRIVKEY_RE.test(trimmed) ||
    BTC_WIF_RE.test(trimmed) ||
    EXT_PRIVKEY_RE.test(trimmed) ||
    SOL_SECRET_BASE58_RE.test(trimmed) ||
    SOL_SECRET_JSON_RE.test(trimmed)
  ) {
    return {
      isPrivateKeyRisk: true,
      detectedChain: null,
      reasonKey: 'blockedPrivateKey',
    };
  }

  if (EVM_ADDRESS_RE.test(trimmed)) {
    return { isPrivateKeyRisk: false, detectedChain: 'EVM' };
  }
  if (BTC_ADDRESS_RE.test(trimmed)) {
    return { isPrivateKeyRisk: false, detectedChain: 'BTC' };
  }
  if (SOLANA_ADDRESS_RE.test(trimmed)) {
    return { isPrivateKeyRisk: false, detectedChain: 'SOLANA' };
  }

  return { isPrivateKeyRisk: false, detectedChain: null };
}

const SAMPLE_PUBLIC_ADDRESSES: Array<{
  chain: SupportedChain;
  labelKey: 'sampleLedger' | 'samplePhantom' | 'sampleColdcard';
  address: string;
  tagKey: 'sampleEvmTag' | 'sampleSolanaTag' | 'sampleBitcoinTag';
}> = [
  {
    chain: 'EVM',
    labelKey: 'sampleLedger',
    address: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
    tagKey: 'sampleEvmTag',
  },
  {
    chain: 'SOLANA',
    labelKey: 'samplePhantom',
    address: '9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin',
    tagKey: 'sampleSolanaTag',
  },
  {
    chain: 'BTC',
    labelKey: 'sampleColdcard',
    address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    tagKey: 'sampleBitcoinTag',
  },
];

interface CryptoWalletManagerProps {
  selectedPortfolioId?: string;
  onSyncCompleted?: (result: CryptoWalletSyncResult) => void;
}

export function CryptoWalletManager({
  selectedPortfolioId,
  onSyncCompleted,
}: CryptoWalletManagerProps) {
  const queryClient = useQueryClient();
  const token = useAuthStore((s) => s.token);
  const locale = useLocale();
  const t = useTranslations('upload.wallet');
  const chainMeta: Record<SupportedChain, { badge: string; standards: string; accentClass: string }> = {
    EVM: { badge: t('evmBadge'), standards: t('evmStandards'), accentClass: 'border-indigo-200 bg-indigo-50 text-indigo-900 dark:border-indigo-800/60 dark:bg-indigo-950/40 dark:text-indigo-200' },
    SOLANA: { badge: t('solanaBadge'), standards: t('solanaStandards'), accentClass: 'border-purple-200 bg-purple-50 text-purple-900 dark:border-purple-800/60 dark:bg-purple-950/40 dark:text-purple-200' },
    BTC: { badge: t('bitcoinBadge'), standards: t('bitcoinStandards'), accentClass: 'border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-800/60 dark:bg-amber-950/40 dark:text-amber-200' },
  };
  const chainNames: Record<SupportedChain, string> = { EVM: t('evmName'), SOLANA: t('solanaName'), BTC: t('bitcoinName') };

  const [wallets, setWallets] = useState<CryptoWalletPublic[]>([]);
  const [loadingWallets, setLoadingWallets] = useState(false);

  // Add Wallet form states
  const [addressInput, setAddressInput] = useState('');
  const [labelInput, setLabelInput] = useState('');
  const [manualChainOverride, setManualChainOverride] = useState<
    SupportedChain | 'AUTO'
  >('AUTO');
  const [addingWallet, setAddingWallet] = useState(false);

  // Sync & Error states
  const [syncingWalletId, setSyncingWalletId] = useState<string | null>(null);
  const [syncResultsByWallet, setSyncResultsByWallet] = useState<
    Record<string, CryptoWalletSyncResult>
  >({});
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const inspection = useMemo(
    () => inspectAddressClientSide(addressInput),
    [addressInput]
  );

  const effectiveChain: SupportedChain | null =
    manualChainOverride === 'AUTO'
      ? inspection.detectedChain
      : manualChainOverride;

  const fetchWallets = useCallback(async () => {
    if (!token) return;
    setLoadingWallets(true);
    try {
      const { data } = await api.get<{ wallets: CryptoWalletPublic[] }>(
        '/crypto/wallets'
      );
      setWallets(data.wallets ?? []);
    } catch {
      // Keep graceful state
    } finally {
      setLoadingWallets(false);
    }
  }, [token]);

  useEffect(() => {
    fetchWallets();
  }, [fetchWallets]);

  const handleAddWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (inspection.isPrivateKeyRisk) {
      setErrorMessage(
        t(inspection.reasonKey ?? 'blockedPrivateKey')
      );
      return;
    }

    if (!effectiveChain || !inspection.detectedChain) {
      setErrorMessage(
        t('invalidAddress')
      );
      return;
    }

    if (effectiveChain !== inspection.detectedChain) {
      setErrorMessage(
        t('chainMismatch', { detected: chainNames[inspection.detectedChain], selected: chainNames[effectiveChain] })
      );
      return;
    }

    setAddingWallet(true);
    try {
      if (token) {
        const payload: {
          address: string;
          chain: SupportedChain;
          label?: string;
          portfolioId?: string;
        } = {
          address: addressInput.trim(),
          chain: effectiveChain,
        };
        if (labelInput.trim()) payload.label = labelInput.trim();
        if (
          selectedPortfolioId &&
          !selectedPortfolioId.startsWith('mock-')
        ) {
          payload.portfolioId = selectedPortfolioId;
        }

        const { data } = await api.post<{ wallet: CryptoWalletPublic }>(
          '/crypto/wallets',
          payload
        );
        setWallets((prev) => [data.wallet, ...prev]);
      } else {
        // Offline / Guest Demo Preview
        const trimmed = addressInput.trim();
        const demoWallet: CryptoWalletPublic = {
          id: `demo-wallet-${Date.now()}`,
          portfolioId: selectedPortfolioId ?? 'mock-portfolio-crypto',
          chain: effectiveChain,
          addressMasked: `${trimmed.slice(0, 6)}...${trimmed.slice(-4)}`,
          addressHash:
            '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
          label: labelInput.trim() || t('defaultWalletLabel', { chain: chainNames[effectiveChain] }),
          isActive: true,
          lastSyncedAt: null,
          createdAt: new Date().toISOString(),
          readOnly: true,
          privacyProtection: 'AES-256-GCM + SHA-256',
        };
        setWallets((prev) => [demoWallet, ...prev]);
      }

      setAddressInput('');
      setLabelInput('');
      setManualChainOverride('AUTO');
    } catch (err) {
      setErrorMessage(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setAddingWallet(false);
    }
  };

  const handleSyncWallet = async (wallet: CryptoWalletPublic) => {
    setErrorMessage(null);
    setSyncingWalletId(wallet.id);
    try {
      if (token && !wallet.id.startsWith('demo-wallet-')) {
        const payload: { portfolioId?: string; delayMs?: number } = {
          delayMs: 350,
        };
        if (
          selectedPortfolioId &&
          !selectedPortfolioId.startsWith('mock-')
        ) {
          payload.portfolioId = selectedPortfolioId;
        }

        const { data } = await api.post<CryptoWalletSyncResult>(
          `/crypto/wallets/${wallet.id}/sync`,
          payload
        );

        setWallets((prev) =>
          prev.map((w) => (w.id === wallet.id ? data.wallet : w))
        );
        setSyncResultsByWallet((prev) => ({ ...prev, [wallet.id]: data }));

        await Promise.all([
          queryClient.invalidateQueries({ queryKey: ['portfolios'] }),
          queryClient.invalidateQueries({ queryKey: ['portfolio'] }),
          queryClient.invalidateQueries({ queryKey: ['transactions'] }),
          queryClient.invalidateQueries({ queryKey: ['dashboardAnalytics'] }),
        ]);

        onSyncCompleted?.(data);
      } else {
        await new Promise((r) => setTimeout(r, 450));
        const nowIso = new Date().toISOString();
        const demoResult: CryptoWalletSyncResult = {
          wallet: { ...wallet, lastSyncedAt: nowIso },
          providerName: 'MOCK_CROSSCHAIN_INDEXER_V1',
          portfolioId: wallet.portfolioId ?? 'mock-portfolio-1',
          tokenBalances: [
            {
              chain: wallet.chain,
              symbol: wallet.chain === 'SOLANA' ? 'SOL' : 'ETH',
              name: wallet.chain === 'SOLANA' ? 'Solana' : 'Ethereum',
              standard: 'NATIVE',
              contractAddress: null,
              decimals: 18,
              balance: '1.6955',
              priceUSD: '2580.00',
              valueUSD: '4374.39',
            },
            {
              chain: wallet.chain,
              symbol: wallet.chain === 'SOLANA' ? 'USDC' : 'USDT',
              name:
                wallet.chain === 'SOLANA'
                  ? 'USD Coin (SPL)'
                  : 'Tether USD (ERC-20)',
              standard: wallet.chain === 'SOLANA' ? 'SPL' : 'ERC20',
              contractAddress: '0xdac1...1ec7',
              decimals: 6,
              balance: '2000.00',
              priceUSD: '1.00',
              valueUSD: '2000.00',
            },
          ],
          discoveredOnChainCount: 3,
          generatedCdmCount: 5,
          addedTransactions: 5,
          skippedTransactions: 0,
          breakdown: {
            swaps: 1,
            transfers: 2,
            buyLegs: 3,
            sellLegs: 1,
            feeLegs: 1,
          },
          syncedAt: nowIso,
        };
        setWallets((prev) =>
          prev.map((w) => (w.id === wallet.id ? demoResult.wallet : w))
        );
        setSyncResultsByWallet((prev) => ({
          ...prev,
          [wallet.id]: demoResult,
        }));
        onSyncCompleted?.(demoResult);
      }
    } catch (err) {
      setErrorMessage(extractApiErrorMessage(err, t('errorFallback')));
    } finally {
      setSyncingWalletId(null);
    }
  };

  const handleDeleteWallet = async (walletId: string) => {
    setErrorMessage(null);
    try {
      if (token && !walletId.startsWith('demo-wallet-')) {
        await api.delete(`/crypto/wallets/${walletId}`);
      }
      setWallets((prev) => prev.filter((w) => w.id !== walletId));
      setSyncResultsByWallet((prev) => {
        const next = { ...prev };
        delete next[walletId];
        return next;
      });
    } catch (err) {
      setErrorMessage(extractApiErrorMessage(err, t('errorFallback')));
    }
  };

  return (
    <section
      data-testid="crypto-wallet-manager"
      className="rounded-2xl border border-gray-200/90 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]"
    >
      {/* Top Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-gray-100 pb-5 dark:border-gray-800 sm:flex-row sm:items-start">
        <div className="space-y-1.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#14342a]/10 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-[#14342a] dark:bg-[#4ade80]/15 dark:text-[#4ade80]">
              <Wallet className="h-3.5 w-3.5" />
              {t('badge')}
            </span>
            <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-[11px] font-semibold text-[#059669] dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-300">
              <Lock className="h-3 w-3" />
              {t('privacyBadge')}
            </span>
          </div>

          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {t('title')}
          </h2>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
            {t('description')}
          </p>
        </div>
      </div>

      {/* Mandatory Zero-Private-Key Security Banner */}
      <div
        data-testid="no-private-key-guarantee"
        className="mt-5 flex items-start gap-3 rounded-2xl border border-emerald-200/90 bg-gradient-to-r from-emerald-50/90 via-white to-emerald-50/40 p-4 dark:border-emerald-800/50 dark:from-emerald-950/35 dark:via-[#181B20] dark:to-emerald-950/20"
      >
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#14342a] text-white">
          <ShieldCheck className="h-5 w-5" />
        </div>
        <div className="space-y-0.5 text-xs">
          <p className="font-bold text-[#14342a] dark:text-[#4ade80] text-sm">
            {t('securityTitle')}
          </p>
          <p className="leading-relaxed text-gray-600 dark:text-gray-300">
{t('securityDescription')}
          </p>
        </div>
      </div>

      {/* Add Wallet Form with Live Auto-Chain Detection */}
      <form onSubmit={handleAddWallet} className="mt-5 space-y-3.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <label
            htmlFor="crypto-wallet-address-input"
            className="text-xs font-bold text-gray-700 dark:text-gray-200"
          >
            {t('addressLabel')}
          </label>

          {/* 1-Click Sample Public Addresses for Instant Verification */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] text-gray-400">{t('trySample')}</span>
            {SAMPLE_PUBLIC_ADDRESSES.map((sample) => (
              <button
                key={sample.chain}
                type="button"
                data-testid={`sample-address-btn-${sample.chain}`}
                onClick={() => {
                  setAddressInput(sample.address);
                  setLabelInput(t(sample.labelKey));
                  setManualChainOverride('AUTO');
                  setErrorMessage(null);
                }}
                className="rounded-lg border border-gray-200 bg-gray-50 px-2 py-0.5 text-[11px] font-semibold text-gray-700 transition hover:border-[#14342a] hover:text-[#14342a] dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:border-[#4ade80] dark:hover:text-[#4ade80]"
              >
                {t(sample.tagKey)}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
          <div className="relative md:col-span-6">
            <input
              id="crypto-wallet-address-input"
              data-testid="crypto-wallet-address-input"
              type="text"
              autoComplete="off"
              spellCheck={false}
              value={addressInput}
              onChange={(e) => {
                setAddressInput(e.target.value);
                setErrorMessage(null);
              }}
              placeholder={t('addressPlaceholder')}
              className={cn(
                'w-full rounded-xl border bg-white px-3.5 py-2.5 text-xs sm:text-sm font-mono text-gray-900 placeholder:font-sans placeholder:text-gray-400 focus:outline-none focus:ring-2 dark:bg-[#121212] dark:text-gray-100',
                inspection.isPrivateKeyRisk
                  ? 'border-red-500 focus:border-red-600 focus:ring-red-500/20'
                  : inspection.detectedChain
                    ? 'border-[#059669] focus:border-[#14342a] focus:ring-[#14342a]/15'
                    : 'border-gray-200 focus:border-[#14342a] focus:ring-[#14342a]/15 dark:border-gray-700'
              )}
            />
          </div>

          <div className="md:col-span-3">
            <input
              type="text"
              data-testid="crypto-wallet-label-input"
              value={labelInput}
              onChange={(e) => setLabelInput(e.target.value)}
              placeholder={t('walletLabelPlaceholder')}
              className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-xs sm:text-sm text-gray-900 placeholder:text-gray-400 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
            />
          </div>

          <div className="flex items-center gap-2 md:col-span-3">
            <select
              aria-label={t('selectChain')}
              data-testid="crypto-chain-select"
              value={manualChainOverride}
              onChange={(e) =>
                setManualChainOverride(
                  e.target.value as SupportedChain | 'AUTO'
                )
              }
              className="w-28 shrink-0 rounded-xl border border-gray-200 bg-white px-2.5 py-2.5 text-xs font-semibold text-gray-700 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-200"
            >
              <option value="AUTO">{t('autoDetect')}</option>
              <option value="EVM">EVM</option>
              <option value="SOLANA">SOLANA</option>
              <option value="BTC">BTC</option>
            </select>

            <button
              type="submit"
              data-testid="add-crypto-wallet-btn"
              disabled={
                addingWallet ||
                inspection.isPrivateKeyRisk ||
                !inspection.detectedChain
              }
              className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {addingWallet ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
              <span>{t('addWallet')}</span>
            </button>
          </div>
        </div>

        {/* Live Auto-Detected Chain Pill OR Private-Key Security Rejection */}
        {addressInput.trim().length > 0 && (
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {inspection.isPrivateKeyRisk ? (
              <div
                data-testid="private-key-blocked-alert"
                className="inline-flex items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3 py-1.5 font-semibold text-red-700 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300"
              >
                <ShieldAlert className="h-4 w-4 shrink-0" />
                <span>{t(inspection.reasonKey ?? 'blockedPrivateKey')}</span>
              </div>
            ) : inspection.detectedChain ? (
              <div
                data-testid="detected-chain-badge"
                className="inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50/80 px-3 py-1.5 font-semibold text-[#14342a] dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-[#4ade80]"
              >
                <Sparkles className="h-3.5 w-3.5 text-[#059669]" />
                <span>
                  {t('chainDetected')}{' '}
                  <strong>{chainMeta[inspection.detectedChain].badge}</strong>{' '}
                  ({chainMeta[inspection.detectedChain].standards})
                </span>
              </div>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-gray-500 dark:text-gray-400">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                {t('checkingAddress')}
              </span>
            )}
          </div>
        )}

        {errorMessage && (
          <div
            data-testid="crypto-wallet-error"
            className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300"
          >
            {errorMessage}
          </div>
        )}
      </form>

      {/* Connected Wallets List */}
      <div className="mt-6 space-y-4">
        {loadingWallets ? (
          <div className="flex items-center gap-2 py-4 text-xs text-gray-500">
            <Loader2 className="h-4 w-4 animate-spin text-[#14342a]" />
            {t('loadingWallets')}
          </div>
        ) : wallets.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-200 bg-gray-50/60 px-4 py-6 text-center text-xs text-gray-500 dark:border-gray-800 dark:bg-[#16191D] dark:text-gray-400">
            {t('emptyWallets')}
          </div>
        ) : (
          wallets.map((wallet) => {
            const isSyncing = syncingWalletId === wallet.id;
            const syncRes = syncResultsByWallet[wallet.id];
            const meta = chainMeta[wallet.chain];

            return (
              <div
                key={wallet.id}
                data-testid={`crypto-wallet-item-${wallet.chain}`}
                className="rounded-2xl border border-gray-200/90 bg-gray-50/50 p-4 transition dark:border-gray-800 dark:bg-[#16191D]"
              >
                <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={cn(
                          'inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[11px] font-bold',
                          meta.accentClass
                        )}
                      >
                        <Layers className="h-3 w-3" />
                        {meta.badge}
                      </span>
                      <span className="font-mono text-sm font-bold text-gray-900 dark:text-gray-100">
                        {wallet.addressMasked}
                      </span>
                      {wallet.label && (
                        <span className="rounded-lg bg-white px-2 py-0.5 text-xs font-semibold text-gray-600 shadow-2xs dark:bg-gray-800 dark:text-gray-300">
                          {wallet.label}
                        </span>
                      )}
                      <span className="inline-flex items-center gap-1 text-[11px] text-gray-400 font-mono">
                        <Fingerprint className="h-3 w-3" />
                        {t('addressHash', { hash: wallet.addressHash.slice(0, 10) })}
                      </span>
                    </div>

                    <p className="text-[11px] text-gray-500 dark:text-gray-400 tabular-nums">
                      {wallet.lastSyncedAt
                        ? t('lastSynced', { date: new Date(wallet.lastSyncedAt).toLocaleString(locale === 'th' ? 'th-TH' : 'en-GB') })
                        : t('neverSynced')}
                    </p>
                  </div>

                  <div className="flex shrink-0 items-center gap-2">
                    <button
                      type="button"
                      disabled={isSyncing || !wallet.isActive}
                      data-testid={`sync-onchain-btn-${wallet.chain}`}
                      onClick={() => handleSyncWallet(wallet)}
                      className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#0f261e] disabled:opacity-60"
                    >
                      <RefreshCw
                        className={cn('h-3.5 w-3.5', isSyncing && 'animate-spin')}
                      />
                      <span>
                        {isSyncing
                          ? t('syncing')
                          : t('syncButton')}
                      </span>
                    </button>

                    <button
                      type="button"
                      aria-label={t('deleteWallet')}
                      onClick={() => handleDeleteWallet(wallet.id)}
                      className="rounded-xl border border-gray-200 bg-white p-2.5 text-gray-500 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-red-950/40 dark:hover:text-red-300"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                {/* Sync Result Summary: Discovered Tx Count, CDM Swap Breakdown & Token Balances */}
                {syncRes && (
                  <div
                    data-testid={`crypto-sync-result-${wallet.chain}`}
                    className="mt-4 space-y-3 border-t border-gray-200/80 pt-4 dark:border-gray-800"
                  >
                    <div className="flex flex-col justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50/70 px-4 py-3 text-xs dark:border-emerald-800/50 dark:bg-emerald-950/25 sm:flex-row sm:items-center">
                      <div className="flex items-start gap-2.5">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#059669]" />
                        <div className="space-y-0.5 text-emerald-950 dark:text-emerald-200">
                          <p className="font-bold">
                            {t('syncSuccess', {
                              discovered: syncRes.discoveredOnChainCount,
                              generated: syncRes.generatedCdmCount,
                            })}
                          </p>
                          <p className="text-[11px] text-emerald-800 dark:text-emerald-300/90 tabular-nums">
                            {t('imported', { count: syncRes.addedTransactions })} · {t('breakdown', {
                              buy: syncRes.breakdown.buyLegs,
                              sell: syncRes.breakdown.sellLegs,
                              fees: syncRes.breakdown.feeLegs,
                              skipped: syncRes.skippedTransactions,
                            })}
                          </p>
                        </div>
                      </div>

                      {!syncRes.portfolioId.startsWith('mock-') && (
                        <Link
                          href={`/portfolios/${syncRes.portfolioId}`}
                          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-[#14342a] px-3 py-1.5 text-[11px] font-semibold text-white hover:bg-[#0f261e]"
                        >
                          <span>{t('viewPortfolio')}</span>
                          <ArrowRight className="h-3 w-3" />
                        </Link>
                      )}
                    </div>

                    {/* Token Balances Strip */}
                    <div>
                      <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                        <Coins className="h-3.5 w-3.5 text-[#14342a] dark:text-[#4ade80]" />
                        {t('tokenBalances')}
                      </p>
                      <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
                        {syncRes.tokenBalances.map((tb) => (
                          <div
                            key={`${tb.chain}-${tb.symbol}`}
                            className="flex items-center justify-between rounded-xl border border-gray-200/80 bg-white px-3.5 py-2.5 dark:border-gray-800 dark:bg-[#1E1E1E]"
                          >
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-bold text-gray-900 dark:text-gray-100">
                                  {tb.symbol}
                                </span>
                                <span className="rounded bg-gray-100 px-1.5 py-0.2 text-[10px] font-semibold text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                                  {tb.standard}
                                </span>
                              </div>
                              <p className="text-[11px] text-gray-500 dark:text-gray-400">
                                {tb.name}
                              </p>
                            </div>
                            <div className="text-right tabular-nums">
                              <p className="text-xs font-bold text-gray-900 dark:text-gray-100">
                                {tb.balance}
                              </p>
                              <p className="text-[11px] font-semibold text-[#059669] dark:text-[#4ade80]">
                                $
                                {Number(tb.valueUSD).toLocaleString(locale === 'th' ? 'th-TH' : 'en-US', {
                                  minimumFractionDigits: 2,
                                })}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </section>
  );
}

export default CryptoWalletManager;
