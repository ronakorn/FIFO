'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ErrorMessageProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  className?: string;
}

export function ErrorMessage({
  title,
  message,
  onRetry,
  className,
}: ErrorMessageProps) {
  const t = useTranslations('common');
  const resolvedTitle = title ?? t('errorTitle');
  return (
    <div
      role="alert"
      className={cn(
        'rounded-2xl border border-red-200 bg-red-50/70 p-5 text-gray-900 shadow-sm dark:border-red-900/50 dark:bg-red-950/30 dark:text-gray-100',
        className
      )}
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-100 text-[#DC2626] dark:bg-red-900/40 dark:text-rose-400">
            <AlertTriangle className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-[#DC2626] dark:text-rose-400">{resolvedTitle}</h3>
            <p className="text-xs sm:text-sm text-gray-700 leading-relaxed dark:text-gray-300">
              {message}
            </p>
          </div>
        </div>
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="inline-flex items-center justify-center gap-2 self-start rounded-xl border border-red-200 bg-white px-4 py-2 text-xs font-semibold text-gray-900 shadow-sm transition hover:bg-red-50 sm:self-center dark:border-red-900/60 dark:bg-[#1E1E1E] dark:text-gray-100"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            {t('retry')}
          </button>
        )}
      </div>
    </div>
  );
}

export default ErrorMessage;
