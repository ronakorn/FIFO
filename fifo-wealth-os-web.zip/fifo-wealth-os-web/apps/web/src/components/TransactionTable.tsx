'use client';

import React, { useMemo, useState } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { ArrowDownUp, ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { Transaction } from '@/types/shared';
import {
  cn,
  formatCurrencyAmount,
  formatDateShort,
  formatQuantity,
  formatTHB,
} from '@/lib/utils';

interface TransactionTableProps {
  transactions: Transaction[];
  pageSize?: number;
}

export function TransactionTable({
  transactions,
  pageSize = 10,
}: TransactionTableProps) {
  const t = useTranslations('transactions');
  const locale = useLocale();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'BUY' | 'SELL' | 'FEE'>('ALL');
  const [sortDesc, setSortDesc] = useState(true);
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return transactions
      .filter((tx) => {
        if (typeFilter !== 'ALL' && (tx.type as string) !== typeFilter) return false;
        if (q) {
          return (
            tx.symbol.toLowerCase().includes(q) ||
            tx.originalCurrency.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        const diff = new Date(a.date).getTime() - new Date(b.date).getTime();
        return sortDesc ? -diff : diff;
      });
  }, [transactions, search, typeFilter, sortDesc]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginated = filtered.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handleFilterResetPage = <T,>(
    setter: React.Dispatch<React.SetStateAction<T>>,
    val: T
  ) => {
    setter(val);
    setPage(1);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-base font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {t('title')}
          </h3>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {t('subtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => handleFilterResetPage(setSearch, e.target.value)}
              placeholder={t('searchPlaceholder')}
              className="w-52 rounded-xl border border-gray-200 bg-white py-2 pl-8 pr-3 text-xs text-gray-900 placeholder:text-gray-400 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/15 dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-100"
            />
          </div>

          <select
            aria-label={t('filterLabel')}
            value={typeFilter}
            onChange={(e) =>
              handleFilterResetPage(
                setTypeFilter,
                e.target.value as 'ALL' | 'BUY' | 'SELL' | 'FEE'
              )
            }
            className="rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs font-medium text-gray-700 focus:border-[#14342a] focus:outline-none dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-200"
          >
            <option value="ALL">{t('allTypes')}</option>
            <option value="BUY">{t('buyOnly')}</option>
            <option value="SELL">{t('sellOnly')}</option>
            <option value="FEE">{t('feeOnly')}</option>
          </select>

          <button
            type="button"
            aria-label={t('sortLabel')}
            onClick={() => setSortDesc((s) => !s)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-gray-100 px-3 py-2 text-xs font-semibold text-gray-800 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
          >
            <ArrowDownUp className="h-3.5 w-3.5" />
            {sortDesc ? t('sortNewest') : t('sortOldest')}
          </button>
        </div>
      </div>

      {/* Slimmer Minimalist Table with Subtle Borders & Very Soft Green Hover */}
      <div className="overflow-x-auto rounded-2xl border border-gray-100 bg-white shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50/70 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
              <th className="px-4 py-2.5">{t('date')}</th>
              <th className="px-4 py-2.5">{t('side')}</th>
              <th className="px-4 py-2.5">{t('asset')}</th>
              <th className="px-4 py-2.5 text-right">{t('quantity')}</th>
              <th className="px-4 py-2.5 text-right">{t('unitPrice')}</th>
              <th className="px-4 py-2.5 text-right">{t('fee')}</th>
              <th className="px-4 py-2.5 text-right">{t('fxRate')}</th>
              <th className="px-4 py-2.5 text-right">{t('netTHB')}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800/80">
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-gray-400">
                  {t('noResults')}
                </td>
              </tr>
            ) : (
              paginated.map((tx) => {
                const rawType = tx.type as string;
                const isBuy = rawType === 'BUY';
                const isFee = rawType === 'FEE';
                const commVat = Number(tx.comm || '0') + Number(tx.vat || '0');
                return (
                  <tr
                    key={tx.id}
                    className="transition-colors hover:bg-[#14342a]/[0.03] dark:hover:bg-emerald-950/20"
                  >
                    <td className="whitespace-nowrap px-4 py-2.5 text-gray-600 tabular-nums dark:text-gray-300">
                      {formatDateShort(tx.date, locale === 'th' ? 'th-TH' : 'en-GB')}
                    </td>
                    <td className="px-4 py-2.5">
                      <span
                        className={cn(
                          'inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-bold',
                          isBuy
                            ? 'bg-green-100 text-green-800 dark:bg-emerald-950/70 dark:text-emerald-300'
                            : isFee
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300'
                              : 'bg-red-100 text-red-800 dark:bg-red-950/70 dark:text-rose-300'
                        )}
                      >
                        {rawType === 'BUY' ? t('buy') : rawType === 'SELL' ? t('sell') : t('feeType')}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 font-bold text-gray-900 dark:text-gray-100">
                      {tx.symbol}
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-right font-medium text-gray-900 tabular-nums dark:text-gray-100">
                      {formatQuantity(tx.qty)}
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-right text-gray-600 tabular-nums dark:text-gray-300">
                      {formatCurrencyAmount(tx.price, tx.originalCurrency)}
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-right text-gray-500 tabular-nums dark:text-gray-400">
                      {formatCurrencyAmount(commVat, tx.originalCurrency)}
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-right text-gray-500 tabular-nums dark:text-gray-400">
                      {tx.originalCurrency === 'THB'
                        ? '1.0000'
                        : tx.fxRate
                          ? Number(tx.fxRate).toFixed(4)
                          : '—'}
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-right font-bold text-gray-900 tabular-nums dark:text-gray-100">
                      {formatTHB(tx.netTHB ?? tx.net)}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-gray-500 dark:text-gray-400">
        <span className="tabular-nums">
          {t('showingCount', { current: paginated.length, total: filtered.length })}
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={currentPage <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="inline-flex items-center gap-1 rounded-xl border border-gray-200 bg-white px-2.5 py-1.5 font-medium text-gray-700 transition hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-40 dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-200"
          >
            <ChevronLeft className="h-3.5 w-3.5" />
            {t('previous')}
          </button>
          <span className="px-2 font-semibold text-gray-800 tabular-nums dark:text-gray-200">
            {t('pageIndicator', { page: currentPage, total: totalPages })}
          </span>
          <button
            type="button"
            disabled={currentPage >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="inline-flex items-center gap-1 rounded-xl border border-gray-200 bg-white px-2.5 py-1.5 font-medium text-gray-700 transition hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-40 dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-200"
          >
            {t('next')}
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default TransactionTable;
