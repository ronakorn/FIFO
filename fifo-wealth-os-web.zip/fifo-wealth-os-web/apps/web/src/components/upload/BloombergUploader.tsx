'use client';

import React, { ChangeEvent, useEffect, useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import {
  AlertTriangle,
  ArrowUpRight,
  BadgeCheck,
  CheckCircle2,
  FileSpreadsheet,
  Fingerprint,
  PlugZap,
  ShieldCheck,
  Upload,
} from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { usePortfolios } from '@/lib/queries';
import { useAuthStore } from '@/lib/stores';
import { extractApiErrorMessage } from '@/lib/utils';

type BloombergTab = 'trades' | 'actions' | 'tickers' | 'port';

type ParsedTicker = {
  symbol: string;
  market: string;
  assetType: string;
  fullTicker: string;
  isin?: string;
  cusip?: string;
  sedol?: string;
};

type TradeImportResponse = {
  success: boolean;
  importedCount: number;
  duplicateCount: number;
  totalParsed: number;
  warnings: string[];
  transactions: Array<{
    id: string;
    date: string;
    symbol: string;
    assetClass: string;
    type: string;
    qty: number;
    price: string;
    originalCurrency: string;
  }>;
};

type CorporateActionResponse = {
  success: boolean;
  previewOnly: boolean;
  count: number;
  notice: string;
  corporateActions: Array<{
    actionId: string;
    ticker: ParsedTicker;
    effectiveDate: string;
    announcementDate: string;
    actionType: string;
    ratio?: string;
    cashAmount?: string;
    currency?: string;
    description: string;
  }>;
};

type PortResponse = {
  environment: string;
  mode: string;
  connected: false;
  liveEnabled: boolean;
  message: string;
  positions: unknown[];
  trades: unknown[];
  corporateActions: unknown[];
};

const tickerExamples = [
  { raw: 'AAPL US Equity', symbol: 'AAPL', market: 'US', assetType: 'Equity' },
  { raw: 'US000361AQ64 Corp', symbol: 'US000361AQ64', market: '—', assetType: 'Corp' },
  { raw: 'XAU Curncy', symbol: 'XAU', market: '—', assetType: 'Curncy' },
];

export function BloombergUploader({ defaultPortfolioId }: { defaultPortfolioId?: string }) {
  const t = useTranslations('upload.bloomberg');
  const token = useAuthStore((state) => state.token);
  const { data: portfolios, isLoading: portfoliosLoading } = usePortfolios();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<BloombergTab>('trades');
  const [portfolioId, setPortfolioId] = useState(defaultPortfolioId ?? '');
  const [mounted, setMounted] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tradeResult, setTradeResult] = useState<TradeImportResponse | null>(null);
  const [actionResult, setActionResult] = useState<CorporateActionResponse | null>(null);
  const [tickerInput, setTickerInput] = useState('AAPL US Equity');
  const [parsedTicker, setParsedTicker] = useState<ParsedTicker | null>(null);
  const [portResult, setPortResult] = useState<PortResponse | null>(null);

  useEffect(() => {
    setMounted(true);
    if (defaultPortfolioId && !defaultPortfolioId.startsWith('mock-')) {
      setPortfolioId(defaultPortfolioId);
      return;
    }
    if (!portfolioId && portfolios?.length) setPortfolioId(portfolios[0]!.id);
  }, [defaultPortfolioId, portfolioId, portfolios]);

  const selectedPortfolio = useMemo(
    () => portfolios?.find((portfolio) => portfolio.id === portfolioId),
    [portfolioId, portfolios],
  );

  const resetForTab = (tab: BloombergTab) => {
    setActiveTab(tab);
    setError(null);
    setSelectedFile(null);
    setTradeResult(null);
    setActionResult(null);
    setParsedTicker(null);
    setPortResult(null);
  };

  const handleFileSelect = (event: ChangeEvent<HTMLInputElement>) => {
    setError(null);
    setTradeResult(null);
    setActionResult(null);
    const file = event.target.files?.[0] ?? null;
    if (!file) {
      setSelectedFile(null);
      return;
    }
    const extension = file.name.toLowerCase().split('.').pop();
    if (!['csv', 'tsv', 'xlsx'].includes(extension ?? '')) {
      setSelectedFile(null);
      setError(t('unsupportedFile'));
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setSelectedFile(null);
      setError(t('fileTooLarge'));
      return;
    }
    setSelectedFile(file);
  };

  const submitFile = async (kind: 'trades' | 'actions') => {
    setError(null);
    setTradeResult(null);
    setActionResult(null);
    if (!token) {
      setError(t('loginRequired'));
      return;
    }
    if (!selectedFile) {
      setError(t('chooseFileError'));
      return;
    }
    if (kind === 'trades' && !portfolioId) {
      setError(t('choosePortfolioError'));
      return;
    }

    const form = new FormData();
    form.append('file', selectedFile);
    if (kind === 'trades') form.append('portfolioId', portfolioId);
    setBusy(true);
    try {
      if (kind === 'trades') {
        const response = await api.post<TradeImportResponse>('/upload/bloomberg-trades', form);
        setTradeResult(response.data);
        await queryClient.invalidateQueries();
      } else {
        const response = await api.post<CorporateActionResponse>('/upload/bloomberg-corporate-actions', form);
        setActionResult(response.data);
      }
    } catch (requestError) {
      setError(extractApiErrorMessage(requestError, t('importError')));
    } finally {
      setBusy(false);
    }
  };

  const handleParseTicker = async (ticker: string) => {
    setTickerInput(ticker);
    setError(null);
    setParsedTicker(null);
    if (!token) {
      setError(t('loginTickerError'));
      return;
    }
    setBusy(true);
    try {
      const response = await api.post<{ ticker: ParsedTicker }>('/bloomberg/tickers/parse', { ticker });
      setParsedTicker(response.data.ticker);
    } catch (requestError) {
      setError(extractApiErrorMessage(requestError, t('tickerError')));
    } finally {
      setBusy(false);
    }
  };

  const handlePortSandboxCheck = async () => {
    setError(null);
    setPortResult(null);
    if (!token) {
      setError(t('loginSandboxError'));
      return;
    }
    if (!portfolioId) {
      setError(t('chooseSandboxPortfolioError'));
      return;
    }
    setBusy(true);
    try {
      const response = await api.post<PortResponse>('/connect/bloomberg-port', {
        portfolioId,
        environment: 'SANDBOX',
      });
      setPortResult(response.data);
    } catch (requestError) {
      setError(extractApiErrorMessage(requestError, t('sandboxError')));
    } finally {
      setBusy(false);
    }
  };

  const downloadTradeTemplate = () => {
    const template = [
      'Trade ID,Ticker,Trade Date,Settlement Date,Side,Quantity,Price,Gross Amount,Commission,Taxes,Net Amount,Currency,Exchange,FX Rate to THB',
      'SAMPLE-001,"AAPL US Equity",2026-10-20,2026-10-22,BUY,10,150.50,1505.00,1.00,0.07,1506.07,USD,NASDAQ,33.12',
    ].join('\n');
    const url = URL.createObjectURL(new Blob([template], { type: 'text/csv;charset=utf-8' }));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'bloomberg-trade-template.csv';
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const tabButton = (tab: BloombergTab, label: string) => (
    <button
      key={tab}
      type="button"
      onClick={() => resetForTab(tab)}
      aria-pressed={activeTab === tab}
      className={`rounded-xl px-3.5 py-2.5 text-xs font-semibold transition sm:text-sm ${
        activeTab === tab
          ? 'bg-[#14342a] text-white shadow-sm'
          : 'text-slate-600 hover:bg-[#14342a]/[0.06] hover:text-[#14342a] dark:text-slate-300 dark:hover:bg-white/5 dark:hover:text-white'
      }`}
    >
      {label}
    </button>
  );

  return (
    <section
      data-testid="bloomberg-uploader"
      className="overflow-hidden rounded-2xl border border-[#dbe7df] bg-white shadow-sm dark:border-[#294339] dark:bg-[#111b17]"
    >
      <div className="border-b border-[#e7eee9] bg-gradient-to-br from-[#f6faf7] via-white to-[#f3f7f4] px-5 py-5 dark:border-[#294339] dark:from-[#14251d] dark:via-[#111b17] dark:to-[#132019] sm:px-7 sm:py-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex gap-3.5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#14342a] text-white shadow-sm">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-bold tracking-tight text-slate-950 dark:text-white sm:text-xl">
                  {t('title')}
                </h2>
                <span className="inline-flex items-center gap-1 rounded-full border border-amber-300/70 bg-amber-50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
                  <BadgeCheck className="h-3.5 w-3.5" /> {t('institutionalGrade')}
                </span>
              </div>
              <p className="mt-1.5 max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">
                {t('description')}
              </p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2 rounded-xl border border-[#dbe7df] bg-white/80 px-3 py-2 text-[11px] font-semibold text-[#14342a] dark:border-[#294339] dark:bg-white/5 dark:text-[#c8e4d3]">
            <ShieldCheck className="h-4 w-4" />
            {t('sourceUntouched')}
          </div>
        </div>

        <div className="mt-5 flex flex-wrap gap-2" role="tablist" aria-label={t('tabsAria')}>
          {tabButton('trades', t('tradeImport'))}
          {tabButton('actions', t('corporateActions'))}
          {tabButton('tickers', t('tickerFormats'))}
          {tabButton('port', t('portSandbox'))}
        </div>
      </div>

      <div className="space-y-5 px-5 py-5 sm:px-7 sm:py-6">
        {!token && (
          <div className="flex flex-col gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-amber-800/50 dark:bg-amber-950/20">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700 dark:text-amber-300" />
              <div>
                <p className="text-sm font-semibold text-amber-950 dark:text-amber-200">{t('signInTitle')}</p>
                <p className="mt-0.5 text-xs text-amber-800 dark:text-amber-300/80">{t('signInDescription')}</p>
              </div>
            </div>
            <Link href="/login" className="inline-flex items-center gap-1 text-xs font-bold text-[#14342a] dark:text-emerald-300">{t('signIn')} <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        )}

        {activeTab === 'trades' && (
          <div className="space-y-5" data-testid="bloomberg-trades-tab">
            <div className="grid gap-4 md:grid-cols-[1fr_1fr]">
              <div>
                <label htmlFor="bloomberg-portfolio" className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                  {t('destinationPortfolio')}
                </label>
                <select
                  id="bloomberg-portfolio"
                  value={portfolioId}
                  onChange={(event) => setPortfolioId(event.target.value)}
                  disabled={!mounted || portfoliosLoading}
                  className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-medium text-slate-900 outline-none transition focus:border-[#14342a] focus:ring-2 focus:ring-[#14342a]/10 dark:border-slate-700 dark:bg-[#0d1511] dark:text-white"
                >
                  <option value="">{t('choosePortfolio')}</option>
                  {(mounted ? (portfolios ?? []) : []).map((portfolio) => (
                    <option key={portfolio.id} value={portfolio.id}>{portfolio.name} · {portfolio.baseCurrency}</option>
                  ))}
                </select>
                {selectedPortfolio && selectedPortfolio.baseCurrency !== 'THB' && (
                  <p className="mt-2 text-xs text-rose-700 dark:text-rose-300">{t('thbRequired')}</p>
                )}
              </div>
              <div className="rounded-2xl border border-[#e2ebe5] bg-[#f7faf8] p-4 dark:border-[#294339] dark:bg-[#0d1511]">
                <p className="text-xs font-bold uppercase tracking-[0.12em] text-[#14342a] dark:text-emerald-300">{t('supportedFormats')}</p>
                <p className="mt-2 text-sm font-semibold text-slate-800 dark:text-slate-100">{t('formatsList')}</p>
                <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">{t('sizeLimit')}</p>
                <button type="button" onClick={downloadTradeTemplate} className="mt-2 text-[11px] font-bold text-[#14342a] underline decoration-[#14342a]/30 underline-offset-2 hover:decoration-[#14342a] dark:text-emerald-300">{t('downloadTemplate')}</button>
              </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-[minmax(0,1.15fr)_minmax(260px,0.85fr)]">
              <label className="group flex min-h-[172px] cursor-pointer flex-col justify-center rounded-2xl border-2 border-dashed border-[#cbd9d0] bg-[#fbfdfb] p-5 transition hover:border-[#14342a]/60 hover:bg-[#f6faf7] dark:border-[#365447] dark:bg-[#0d1511] dark:hover:bg-[#132019]">
                <input
                  type="file"
                  accept=".csv,.tsv,.txt,.xlsx"
                  onChange={handleFileSelect}
                  className="sr-only"
                  data-testid="bloomberg-file-input"
                />
                <div className="flex items-start gap-3.5">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[#14342a]/[0.07] text-[#14342a] dark:bg-emerald-400/10 dark:text-emerald-300">
                    {selectedFile ? <CheckCircle2 className="h-5 w-5" /> : <Upload className="h-5 w-5" />}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{selectedFile ? selectedFile.name : t('chooseBloombergExport')}</p>
                    <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">
                      {selectedFile ? t('fileReady', { size: (selectedFile.size / 1024).toFixed(1) }) : t('chooseFileHint')}
                    </p>
                    <span className="mt-3 inline-flex rounded-lg bg-[#14342a] px-3 py-2 text-[11px] font-bold text-white">{t('browseFiles')}</span>
                  </div>
                </div>
              </label>
              <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-[#0d1511]">
                <p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-700 dark:text-slate-200">{t('importRules')}</p>
                <ul className="mt-3 space-y-2.5 text-xs leading-5 text-slate-600 dark:text-slate-400">
                  <li className="flex gap-2"><span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-[#14342a] dark:bg-emerald-400" />{t('ruleFields')}</li>
                  <li className="flex gap-2"><span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-[#14342a] dark:bg-emerald-400" />{t('ruleFx')}</li>
                  <li className="flex gap-2"><span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-[#14342a] dark:bg-emerald-400" />{t('ruleUnsupported')}</li>
                </ul>
              </div>
            </div>

            <button
              type="button"
              onClick={() => void submitFile('trades')}
              disabled={busy || !selectedFile || !portfolioId}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-[#1b4538] disabled:cursor-not-allowed disabled:opacity-45 sm:w-auto"
            >
              <Upload className="h-4 w-4" /> {busy ? t('processing') : t('validateImport') }
            </button>

            {tradeResult && (
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/20" data-testid="bloomberg-trade-result">
                <div className="flex flex-wrap items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-700 dark:text-emerald-300" />
                  <p className="text-sm font-bold text-emerald-950 dark:text-emerald-200">{t('importComplete')}</p>
                  <span className="rounded-full bg-white/80 px-2.5 py-1 text-[11px] font-bold text-emerald-900 dark:bg-emerald-900/30 dark:text-emerald-200">{t('imported', { count: tradeResult.importedCount })}</span>
                  <span className="rounded-full bg-white/80 px-2.5 py-1 text-[11px] font-semibold text-slate-600 dark:bg-white/5 dark:text-slate-300">{t('duplicates', { count: tradeResult.duplicateCount })}</span>
                </div>
                <p className="mt-2 text-xs text-emerald-900/80 dark:text-emerald-200/80">{t('rowsParsed', { count: tradeResult.totalParsed, portfolio: selectedPortfolio?.name ?? t('choosePortfolio') })}</p>
                <div className="mt-3 space-y-1 text-xs text-emerald-950/80 dark:text-emerald-100/80">
                  {tradeResult.transactions.slice(0, 4).map((transaction) => (
                    <p key={transaction.id} className="font-mono">{transaction.date} · {transaction.symbol} · {transaction.assetClass} · {transaction.type}</p>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'actions' && (
          <div className="space-y-4" data-testid="bloomberg-actions-tab">
            <div className="rounded-2xl border border-amber-200 bg-amber-50/70 p-4 dark:border-amber-900/50 dark:bg-amber-950/20">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700 dark:text-amber-300" />
                <div>
                  <p className="text-sm font-bold text-amber-950 dark:text-amber-200">{t('reviewActions')}</p>
                  <p className="mt-1 text-xs leading-5 text-amber-900/80 dark:text-amber-200/80">{t('actionsNotice')}</p>
                </div>
              </div>
            </div>
            <FilePicker file={selectedFile} onChange={handleFileSelect} testId="bloomberg-action-file-input" chooseLabel={t('chooseActionExport')} formatLabel={t('tickerSuffixFormat')} />
            <button type="button" onClick={() => void submitFile('actions')} disabled={busy || !selectedFile} className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#14342a]/20 bg-white px-5 py-3 text-sm font-bold text-[#14342a] transition hover:bg-[#f4f8f5] disabled:cursor-not-allowed disabled:opacity-45 dark:border-[#547b68] dark:bg-[#132019] dark:text-emerald-200 dark:hover:bg-[#1a2b22]">
              <FileSpreadsheet className="h-4 w-4" /> {busy ? t('parsing') : t('parseActions') }
            </button>
            {actionResult && (
              <div className="rounded-2xl border border-[#dbe7df] bg-[#f7faf8] p-4 dark:border-[#294339] dark:bg-[#0d1511]" data-testid="bloomberg-action-result">
                <div className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-700 dark:text-emerald-300" /><p className="text-sm font-bold text-slate-900 dark:text-white">{t('actionsParsed', { count: actionResult.count })}</p></div>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {actionResult.corporateActions.slice(0, 4).map((action) => (
                    <div key={action.actionId} className="rounded-xl border border-white bg-white/80 p-3 dark:border-slate-700 dark:bg-white/[0.03]">
                      <p className="text-xs font-bold text-slate-900 dark:text-white">{action.ticker.symbol} · {action.actionType.replace(/_/g, ' ')}</p>
                      <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">{t('effectiveDate', { date: action.effectiveDate })}{action.ratio ? ` · ${action.ratio}` : ''}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'tickers' && (
          <div className="space-y-5" data-testid="bloomberg-tickers-tab">
            <div>
              <p className="text-sm font-bold text-slate-900 dark:text-white">{t('tickerParser')}</p>
              <p className="mt-1 text-xs leading-5 text-slate-500 dark:text-slate-400">{t('tickerParserDescription')}</p>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <input
                value={tickerInput}
                onChange={(event) => setTickerInput(event.target.value)}
                onKeyDown={(event) => { if (event.key === 'Enter') void handleParseTicker(tickerInput); }}
                aria-label={t('tickerAria')}
                placeholder={t('tickerExample')}
                className="h-11 flex-1 rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-mono text-slate-900 outline-none focus:border-[#14342a] focus:ring-2 focus:ring-[#14342a]/10 dark:border-slate-700 dark:bg-[#0d1511] dark:text-white"
              />
              <button type="button" onClick={() => void handleParseTicker(tickerInput)} disabled={busy || !tickerInput.trim()} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 text-xs font-bold text-white disabled:opacity-45">{busy ? t('parsing') : t('parseTicker') }</button>
            </div>
            {parsedTicker && (
              <div className="grid gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 sm:grid-cols-4 dark:border-emerald-900/60 dark:bg-emerald-950/20" data-testid="bloomberg-ticker-result">
                <TickerValue label={t('symbol')} value={parsedTicker.symbol} />
                <TickerValue label={t('market')} value={parsedTicker.market || t('notSupplied')} />
                <TickerValue label={t('assetType')} value={parsedTicker.assetType} />
                <TickerValue label={t('mappedCdm')} value={parsedTicker.assetType === 'Curncy' ? 'FOREX' : ['Corp', 'Govt', 'Mortgage', 'Muni'].includes(parsedTicker.assetType) ? 'BOND' : ['Option', 'Warrant', 'Future'].includes(parsedTicker.assetType) ? (parsedTicker.assetType === 'Future' ? t('optionImportBlocked') : 'OPTION') : ['Comdty'].includes(parsedTicker.assetType) ? 'COMMODITY' : 'EQUITY'} />
              </div>
            )}
            <div className="grid gap-3 md:grid-cols-3">
              {tickerExamples.map((example) => (
                <button key={example.raw} type="button" onClick={() => void handleParseTicker(example.raw)} className="rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-[#14342a]/40 hover:bg-[#f8fbf9] dark:border-slate-700 dark:bg-[#0d1511] dark:hover:bg-white/[0.03]">
                  <p className="font-mono text-sm font-bold text-slate-900 dark:text-white">{example.raw}</p>
                  <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">{example.symbol} · {example.market} · {example.assetType}</p>
                </button>
              ))}
            </div>
            <p className="text-[11px] leading-5 text-slate-500 dark:text-slate-400">{t('suffixNotice')}</p>
          </div>
        )}

        {activeTab === 'port' && (
          <div className="grid gap-5 lg:grid-cols-[minmax(0,1.1fr)_minmax(280px,0.9fr)]" data-testid="bloomberg-port-tab">
            <div className="rounded-2xl border border-[#dbe7df] bg-[#f7faf8] p-5 dark:border-[#294339] dark:bg-[#0d1511]">
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[#14342a] text-white"><PlugZap className="h-5 w-5" /></div>
                <div>
                  <p className="text-sm font-bold text-slate-950 dark:text-white">{t('portBoundary')}</p>
                  <p className="mt-1 text-xs leading-5 text-slate-600 dark:text-slate-400">{t('portNotice')}</p>
                </div>
              </div>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                <div className="rounded-xl border border-emerald-200 bg-white px-3 py-2.5 dark:border-emerald-900/50 dark:bg-white/[0.03]">
                  <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-emerald-700 dark:text-emerald-300">{t('sandbox')}</p>
                  <p className="mt-1 text-xs font-semibold text-slate-800 dark:text-slate-200">{t('mockNoData')}</p>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-white/[0.03]">
                  <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">{t('liveConnection')}</p>
                  <p className="mt-1 text-xs font-semibold text-slate-800 dark:text-slate-200">{t('notConfigured')}</p>
                </div>
              </div>
              <button type="button" onClick={() => void handlePortSandboxCheck()} disabled={busy || !portfolioId} className="mt-4 inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-3 text-xs font-bold text-white disabled:cursor-not-allowed disabled:opacity-45">
                <PlugZap className="h-4 w-4" /> {busy ? t('checking') : t('checkSandbox') }
              </button>
            </div>
            <div className="space-y-3">
              <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 dark:border-amber-900/50 dark:bg-amber-950/20">
                <div className="flex items-start gap-2.5"><Fingerprint className="mt-0.5 h-4 w-4 shrink-0 text-amber-700 dark:text-amber-300" /><div><p className="text-xs font-bold text-amber-950 dark:text-amber-200">{t('credentialSafety')}</p><p className="mt-1 text-[11px] leading-5 text-amber-900/80 dark:text-amber-200/80">{t('noCredentials')}</p></div></div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-[#0d1511]">
                <p className="text-xs font-bold text-slate-900 dark:text-white">{t('beforeLive')}</p>
                <ul className="mt-2 space-y-1.5 text-[11px] leading-5 text-slate-500 dark:text-slate-400">
                  <li>{t('liveStep1')}</li>
                  <li>{t('liveStep2')}</li>
                  <li>{t('liveStep3')}</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {portResult && activeTab === 'port' && (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/20" data-testid="bloomberg-port-result">
            <div className="flex flex-wrap items-center gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-700 dark:text-emerald-300" /><p className="text-sm font-bold text-emerald-950 dark:text-emerald-200">{portResult.mode.toUpperCase() === 'SANDBOX' ? t('sandbox') : portResult.mode}</p><span className="rounded-full bg-white/80 px-2.5 py-1 text-[10px] font-bold text-emerald-900 dark:bg-emerald-900/30 dark:text-emerald-200">{t('liveDisabled')}</span></div>
            <p className="mt-2 text-xs leading-5 text-emerald-900/80 dark:text-emerald-200/80">{portResult.message}</p>
            <p className="mt-2 font-mono text-[11px] text-emerald-900 dark:text-emerald-100">{t('portCounts', { positions: portResult.positions.length, trades: portResult.trades.length, actions: portResult.corporateActions.length })}</p>
          </div>
        )}

        {error && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs font-medium leading-5 text-rose-800 dark:border-rose-900/50 dark:bg-rose-950/20 dark:text-rose-200">{error}</p>}

        <div className="flex flex-col gap-2 border-t border-slate-100 pt-4 text-[11px] leading-5 text-slate-500 dark:border-slate-800 dark:text-slate-400 sm:flex-row sm:items-start sm:justify-between">
          <p>{t('compatibilityNotice')}</p>
          <p className="shrink-0 font-semibold text-[#14342a] dark:text-emerald-300">{t('decimalPrecision')}</p>
        </div>
      </div>
    </section>
  );
}

function FilePicker({ file, onChange, testId, chooseLabel, formatLabel }: { file: File | null; onChange: (event: ChangeEvent<HTMLInputElement>) => void; testId: string; chooseLabel: string; formatLabel: string }) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4 transition hover:border-[#14342a]/40 dark:border-slate-700 dark:bg-[#0d1511]">
      <input type="file" accept=".csv,.tsv,.txt,.xlsx" onChange={onChange} className="sr-only" data-testid={testId} />
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#14342a]/[0.07] text-[#14342a] dark:bg-emerald-400/10 dark:text-emerald-300"><FileSpreadsheet className="h-4 w-4" /></span>
      <span><span className="block text-xs font-bold text-slate-900 dark:text-white">{file?.name ?? chooseLabel}</span><span className="mt-1 block text-[11px] text-slate-500 dark:text-slate-400">{formatLabel}</span></span>
    </label>
  );
}

function TickerValue({ label, value }: { label: string; value: string }) {
  return <div><p className="text-[10px] font-bold uppercase tracking-[0.12em] text-emerald-700 dark:text-emerald-300">{label}</p><p className="mt-1 truncate text-sm font-semibold text-slate-900 dark:text-white">{value}</p></div>;
}
