import { FamilyDashboardResponse } from '@/types/family';
import { JournalEntryItem } from '@/types/journalAi';

export const mockJournalEntries: JournalEntryItem[] = [
  {
    id: 'mock-journal-1',
    userId: 'mock-user',
    portfolioId: 'mock-portfolio-ibkr',
    portfolioName: 'US Tech & Flagship Equities (IBKR)',
    date: '2026-10-05',
    title: 'DCA หุ้นเทคโนโลยีสหรัฐฯ ตามวินัยต้นเดือน',
    content:
      'ทยอยสะสม NVDA และ AAPL ตามแผน DCA รายเดือน ผลประกอบการกลุ่ม AI Infrastructure ยังเติบโตแข็งแกร่ง รักษาสัดส่วนตามเป้าหมายระยะยาว',
    mood: 'BULLISH',
    createdAt: '2026-10-05T09:00:00.000Z',
  },
  {
    id: 'mock-journal-2',
    userId: 'mock-user',
    portfolioId: null,
    portfolioName: null,
    date: '2026-10-14',
    title: 'ทบทวนสัดส่วนเงินสดและอัตราแลกเปลี่ยน USD/THB',
    content:
      'ค่าเงินบาทผันผวนเล็กน้อยหลังตัวเลขเงินเฟ้อสหรัฐฯ ตรวจสอบต้นทุน FIFO ในสกุลบาทเรียบร้อย ยังไม่ต้องปรับพอร์ตเกินความจำเป็น',
    mood: 'NEUTRAL',
    createdAt: '2026-10-14T11:30:00.000Z',
  },
  {
    id: 'mock-journal-3',
    userId: 'mock-user',
    portfolioId: null,
    portfolioName: null,
    date: '2026-10-21',
    title: 'ระมัดระวังความผันผวนก่อนประกาศงบไตรมาส',
    content:
      'ชะลอการไล่ราคาสินทรัพย์ดิจิทัลระยะสั้น และสำรองสภาพคล่องเงินสด 15% เพื่อรองรับจังหวะย่อตัวของตลาด',
    mood: 'BEARISH',
    createdAt: '2026-10-21T16:15:00.000Z',
  },
  {
    id: 'mock-journal-4',
    userId: 'mock-user',
    portfolioId: 'mock-portfolio-ibkr',
    portfolioName: 'US Tech & Flagship Equities (IBKR)',
    date: '2026-10-26',
    title: 'อัปเดตแผน FIRE และเป้าหมายครอบครัวไตรมาส 4',
    content:
      'อัตราความสำเร็จ Monte Carlo อยู่ที่ระดับ >90% และภาพรวม Household Net Worth เติบโตตามเป้าหมายประจำปี',
    mood: 'BULLISH',
    createdAt: '2026-10-26T08:30:00.000Z',
  },
];

export const mockFamilyDashboard: FamilyDashboardResponse = {
  hasGroup: true,
  group: {
    id: 'mock-family-group-1',
    name: 'ครอบครัวพอร์ตมั่งคั่ง (Thanakorn Family Office)',
    inviteCode: 'FAM-2026-THAI',
    createdByUserId: 'mock-user-1',
    currentUserRole: 'OWNER',
    currentUserPermissions: {
      canSeeTransactions: false,
      canSeeTotalNetWorth: true,
    },
    createdAt: '2026-10-01T00:00:00.000Z',
  },
  householdNetWorthTHB: '385231.19',
  memberCount: 2,
  members: [
    {
      memberId: 'mock-member-1',
      userId: 'mock-user-1',
      name: 'คุณธนกร พอร์ตมั่งคั่ง (Thanakorn Wealth)',
      role: 'OWNER',
      netWorthTHB: '231231.19',
      sharePercent: '60.02',
      portfolioCount: 2,
      permissions: { canSeeTransactions: false, canSeeTotalNetWorth: true },
      isCurrentUser: true,
    },
    {
      memberId: 'mock-member-2',
      userId: 'mock-user-2',
      name: 'คุณสมหญิง พอร์ตมั่งคั่ง (Somying Wealth)',
      role: 'VIEWER',
      netWorthTHB: '154000.00',
      sharePercent: '39.98',
      portfolioCount: 1,
      permissions: { canSeeTransactions: false, canSeeTotalNetWorth: true },
      isCurrentUser: false,
    },
  ],
  privacyGuarantee: {
    transactionsExposed: false,
    aggregationEngine: 'Decimal.js-40',
  },
};
