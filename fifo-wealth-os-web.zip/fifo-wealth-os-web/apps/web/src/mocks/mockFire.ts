import Decimal from 'decimal.js';
import { FIRESummaryResponse, SimulationPath } from '@/types/fire';

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

function buildPreviewSimulations(): FIRESummaryResponse['monteCarlo'] {
  const startYear = 2026;
  const years = 18;
  const numPaths = 120;
  const simulations: SimulationPath[] = [];

  for (let i = 0; i < numPaths; i++) {
    let val = new Dec('2781169.89');
    const path: SimulationPath = [{ year: startYear, value: val.toFixed(2) }];
    for (let y = 1; y <= years; y++) {
      // Deterministic pseudo-random wave per path index & year using pure Decimal
      const phase = ((i * 37 + y * 19) % 100) - 48; // -48..+51
      const shock = new Dec(phase).dividedBy(new Dec(320)); // ~ +/- 15% volatility
      const annualRate = new Dec('0.085').plus(shock);
      const factor = Decimal.max(new Dec('0.65'), new Dec(1).plus(annualRate));
      val = val.times(factor).plus(new Dec('420000'));
      path.push({ year: startYear + y, value: val.toFixed(2) });
    }
    simulations.push(path);
  }

  const percentileSeries = [];
  for (let y = 0; y <= years; y++) {
    const col = simulations
      .map((p) => new Dec(p[y]!.value))
      .sort((a, b) => a.comparedTo(b));
    const p10 = col[Math.floor(col.length * 0.1)]!;
    const med = col[Math.floor(col.length * 0.5)]!;
    const p90 = col[Math.floor(col.length * 0.9)]!;
    percentileSeries.push({
      year: startYear + y,
      p10: p10.toFixed(2),
      median: med.toFixed(2),
      p90: p90.toFixed(2),
    });
  }

  return {
    successRate: 85.83,
    p90Year: 2037,
    medianYear: 2040,
    p10Year: 2043,
    simulations,
    percentileSeries,
    targetAmount: '12000000.00',
  };
}

export const mockFireSummary: FIRESummaryResponse = {
  fireNumber: '12000000.00',
  yearsToFIRE: '14.20',
  successRate: 85.83,
  currentPortfolioValueTHB: '231169.89',
  monthlyContributionTHB: '35000.00',
  annualExpensesTHB: '480000.00',
  withdrawalRate: '0.04',
  expectedReturn: '0.085',
  inflationRate: '0.03',
  volatility: '0.15',
  goalsCount: 3,
  onTrackCount: 2,
  goals: [
    {
      goal: {
        id: 'mock-fire-goal-1',
        userId: 'mock-user-01',
        name: 'อิสรภาพทางการเงินหลัก (Core FIRE @ อายุ 50)',
        targetAmount: '12000000.00',
        currentAmount: '2550000.00',
        monthlyContribution: '35000.00',
        expectedReturn: '0.085',
        inflationRate: '0.03',
        targetYear: 2044,
        currentAge: 32,
        retirementAge: 50,
      },
      progress: {
        goalId: 'mock-fire-goal-1',
        currentAmount: '2781169.89',
        targetAmount: '12000000.00',
        progressPct: '23.18',
        yearsRemaining: 18,
        onTrack: true,
      },
    },
    {
      goal: {
        id: 'mock-fire-goal-2',
        userId: 'mock-user-01',
        name: 'กองทุน Coast FIRE & Passive Dividend',
        targetAmount: '5000000.00',
        currentAmount: '3650000.00',
        monthlyContribution: '20000.00',
        expectedReturn: '0.08',
        inflationRate: '0.03',
        targetYear: 2033,
        currentAge: 32,
        retirementAge: 39,
      },
      progress: {
        goalId: 'mock-fire-goal-2',
        currentAmount: '3881169.89',
        targetAmount: '5000000.00',
        progressPct: '77.62',
        yearsRemaining: 7,
        onTrack: true,
      },
    },
    {
      goal: {
        id: 'mock-fire-goal-3',
        userId: 'mock-user-01',
        name: 'บ้านตากอากาศเชียงใหม่ & ท่องเที่ยวรอบโลก',
        targetAmount: '8500000.00',
        currentAmount: '3200000.00',
        monthlyContribution: '10000.00',
        expectedReturn: '0.07',
        inflationRate: '0.03',
        targetYear: 2034,
        currentAge: 32,
        retirementAge: 40,
      },
      progress: {
        goalId: 'mock-fire-goal-3',
        currentAmount: '3431169.89',
        targetAmount: '8500000.00',
        progressPct: '40.37',
        yearsRemaining: 8,
        onTrack: false,
      },
    },
  ],
  monteCarlo: buildPreviewSimulations(),
};
