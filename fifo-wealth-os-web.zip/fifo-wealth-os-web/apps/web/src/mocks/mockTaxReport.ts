import { TaxReport } from '@/types/shared';

export const mockTaxReport: TaxReport = {
  taxYear: 2024,
  totalTaxableIncome: '5545.46',
  totalTaxWithheld: '10.69',
  totalTaxPayable: '0.00',
  generatedAt: '2024-12-31T00:00:00.000Z',
  capitalGains: [
    {
      id: 'cg-aapl-1',
      type: 'CAPITAL_GAIN',
      symbol: 'AAPL',
      date: '2024-10-01T00:00:00.000Z',
      amountTHB: '1624.40',
      taxableIncome: '1624.40',
      taxWithheld: '0.00',
      netTaxPayable: '0.00',
    },
    {
      id: 'cg-nvda-1',
      type: 'CAPITAL_GAIN',
      symbol: 'NVDA',
      date: '2024-10-02T00:00:00.000Z',
      amountTHB: '3849.79',
      taxableIncome: '3849.79',
      taxWithheld: '0.00',
      netTaxPayable: '0.00',
    },
  ],
  dividends: [
    {
      id: 'div-aapl-1',
      type: 'DIVIDEND',
      symbol: 'AAPL',
      date: '2024-10-15T00:00:00.000Z',
      amountTHB: '45.69',
      taxableIncome: '45.69',
      taxWithheld: '6.85',
      netTaxPayable: '0.00',
    },
    {
      id: 'div-nvda-1',
      type: 'DIVIDEND',
      symbol: 'NVDA',
      date: '2024-10-15T00:00:00.000Z',
      amountTHB: '25.58',
      taxableIncome: '25.58',
      taxWithheld: '3.84',
      netTaxPayable: '0.00',
    },
  ],
};
