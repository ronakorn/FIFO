'use client';

import React from 'react';
import { Dashboard } from '@/components/Dashboard';
import { useTranslations } from 'next-intl';
import { ErrorBoundary } from '@/components/ErrorBoundary';

export default function HomePage() {
  const t = useTranslations('dashboard');
  return (
    <ErrorBoundary fallbackTitle={t('errorBoundaryTitle')}>
      <Dashboard />
    </ErrorBoundary>
  );
}
