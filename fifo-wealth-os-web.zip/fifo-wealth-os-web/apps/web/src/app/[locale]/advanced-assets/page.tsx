import React from 'react';
import { getTranslations } from 'next-intl/server';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { AdvancedAssetsWorkspace } from '@/components/advancedAssets/AdvancedAssetsWorkspace';

export default async function AdvancedAssetsPage() {
  const t = await getTranslations('appMessages');
  return (
    <ErrorBoundary fallbackTitle={t('advancedAssetsPageError')}>
      <AdvancedAssetsWorkspace />
    </ErrorBoundary>
  );
}
