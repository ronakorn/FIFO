'use client';

import React, { FormEvent, useEffect, useMemo, useState } from 'react';
import Decimal from 'decimal.js';
import {
  ArrowRight,
  CheckCircle2,
  CircleDollarSign,
  HeartHandshake,
  Landmark,
  LoaderCircle,
  LockKeyhole,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import { useAuthStore } from '@/lib/stores';
import { extractApiErrorMessage } from '@/lib/utils';
import { useCommunityFundraising, useCreateDonation, useEarlyBirdStatus } from '@/lib/billingQueries';

const DonationDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

function formatTHB(value?: string): string {
  if (value === undefined) return '—';
  try {
    const [whole = '0', fraction = '00'] = new DonationDecimal(value).toFixed(2).split('.');
    const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return fraction === '00' ? `฿${grouped}` : `฿${grouped}.${fraction}`;
  } catch {
    return '—';
  }
}

export default function SupportPage() {
  const t = useTranslations('support');
  const token = useAuthStore((state) => state.token);
  const createDonation = useCreateDonation();
  const community = useCommunityFundraising();
  const rewardStatus = useEarlyBirdStatus(Boolean(token));
  const donorReward = rewardStatus.data?.donorProYear;
  const communityProgress = Math.max(0, Math.min(100, Number(community.data?.progressPercentage ?? '0')));
  const donorRewardProgress = donorReward
    ? Math.max(0, Math.min(100, new DonationDecimal(donorReward.donatedTHB).dividedBy(donorReward.thresholdTHB).times(100).toNumber()))
    : 0;
  const [selectedPreset, setSelectedPreset] = useState<string | null>('500');
  const [customAmount, setCustomAmount] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [mockCheckoutReady, setMockCheckoutReady] = useState(false);

  const donationAmount = selectedPreset ?? customAmount;
  const presets = [
    { amount: '100', label: t('coffee'), icon: Sparkles },
    { amount: '500', label: t('server'), icon: Landmark },
    { amount: '1000', label: t('feature'), icon: CircleDollarSign },
    { amount: '5000', label: t('institutional'), icon: ShieldCheck },
  ];

  const amountIsValid = useMemo(() => {
    if (!donationAmount) return false;
    try {
      const amount = new DonationDecimal(donationAmount);
      return (
        amount.isFinite() &&
        amount.gte(10) &&
        amount.lte(1_000_000) &&
        amount.decimalPlaces() <= 2
      );
    } catch {
      return false;
    }
  }, [donationAmount]);

  const formattedAmount = useMemo(() => {
    if (!amountIsValid) return '';
    return new DonationDecimal(donationAmount)
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2);
  }, [amountIsValid, donationAmount]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    setMockCheckoutReady(params.get('mock_checkout') === 'ready');
  }, []);

  const handlePreset = (amount: string) => {
    setSelectedPreset(amount);
    setCustomAmount('');
    setError(null);
  };

  const handleCustomAmount = (value: string) => {
    setSelectedPreset(null);
    setCustomAmount(value);
    setError(null);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    if (!token) {
      setError(t('loginRequired'));
      return;
    }
    if (!amountIsValid) {
      setError(t('amountError'));
      return;
    }

    try {
      const response = await createDonation.mutateAsync({
        amountTHB: formattedAmount,
        ...(message.trim() ? { message: message.trim() } : {}),
      });
      // The mock adapter returns a query-relative URL; a live Stripe adapter returns
      // Stripe's absolute Checkout URL. Both work through the same browser redirect.
      window.location.assign(new URL(response.checkout.url, window.location.href).toString());
    } catch (submitError) {
      setError(extractApiErrorMessage(submitError, t('checkoutError')));
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-7" data-testid="support-page">
      <section className="relative isolate overflow-hidden rounded-2xl bg-[#14342a] px-6 py-8 text-white shadow-sm sm:px-9 sm:py-10 lg:px-12">
        <div className="pointer-events-none absolute -right-12 -top-24 -z-10 h-72 w-72 rounded-full border border-white/10" />
        <div className="pointer-events-none absolute -right-1 -top-12 -z-10 h-52 w-52 rounded-full border border-white/10" />
        <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-emerald-100">
              <HeartHandshake className="h-3.5 w-3.5" />
              {t('eyebrow')}
            </div>
            <h1 className="mt-5 text-3xl font-bold tracking-tight sm:text-4xl" data-testid="support-title">
              {t('title')}
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-emerald-50/90 sm:text-base sm:leading-8">
              {t('mission')}
            </p>
            <p className="mt-3 max-w-2xl text-xs leading-6 text-emerald-100/75 sm:text-sm">
              {t('missionDetail')}
            </p>
          </div>

          <div className="rounded-2xl border border-white/15 bg-white/[0.08] p-5 backdrop-blur-sm sm:p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-emerald-200/80">
                  FIFO Wealth OS
                </p>
                <p className="mt-2 text-lg font-semibold tracking-tight">{t('productPrinciple')}</p>
              </div>
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/10 text-emerald-200">
                <Landmark className="h-5 w-5" />
              </span>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-white/10 bg-black/10 p-3.5">
                <p className="text-[10px] font-medium text-emerald-100/70">{t('accessLabel')}</p>
                <p className="mt-1 text-sm font-bold">{t('allProAccess')}</p>
              </div>
              <div className="rounded-xl border border-white/10 bg-black/10 p-3.5">
                <p className="text-[10px] font-medium text-emerald-100/70">{t('betaPlanLabel')}</p>
                <p className="mt-1 text-sm font-bold">{t('betaPrice')}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {mockCheckoutReady && (
        <div
          className="flex flex-col gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-950 sm:flex-row sm:items-start"
          role="status"
          data-testid="mock-checkout-notice"
        >
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#059669]" />
          <div>
            <p className="text-sm font-bold">{t('mockReadyTitle')}</p>
            <p className="mt-1 text-xs leading-5 text-emerald-900/80">{t('mockReadyBody')}</p>
          </div>
        </div>
      )}

      <section className="rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] sm:p-6" data-testid="community-fundraising-card">
        <div className="grid gap-4 sm:grid-cols-[0.8fr_1.2fr] sm:items-center">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#059669]">{t('communityTitle')}</p>
            <p className="mt-1.5 text-2xl font-extrabold tabular-nums text-gray-900 dark:text-gray-100" data-testid="community-total-raised">
              {formatTHB(community.data?.totalRaisedTHB)}
            </p>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{t('communityGoal', { target: formatTHB(community.data?.targetTHB) })}</p>
          </div>
          <div>
            <div
              className="h-3 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800"
              role="progressbar"
              aria-label={t('communityTitle')}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={communityProgress}
              data-testid="community-progress"
            >
              <div className="h-full rounded-full bg-[#059669] transition-[width]" style={{ width: `${communityProgress}%` }} />
            </div>
            <p className="mt-2 text-[10px] leading-5 text-gray-500 dark:text-gray-400">{t('communityNote')}</p>
            <p className="mt-0.5 text-[10px] text-gray-400 dark:text-gray-500">
              {t('communityDonations', { count: community.data?.successfulDonationCount ?? 0 })}
            </p>
          </div>
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <section className="rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] sm:p-7">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#059669]">
                {t('optionalContribution')}
              </p>
              <h2 className="mt-1.5 text-xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
                {t('chooseAmount')}
              </h2>
            </div>
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#14342a]/[0.06] text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
              <CircleDollarSign className="h-5 w-5" />
            </span>
          </div>

          <form className="mt-6 space-y-5" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2" role="group" aria-label={t('chooseAmount')}>
              {presets.map(({ amount, label, icon: Icon }) => {
                const isSelected = selectedPreset === amount;
                const formattedPreset = new DonationDecimal(amount)
                  .toFixed(0)
                  .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                return (
                  <button
                    key={amount}
                    type="button"
                    data-testid={`donation-preset-${amount}`}
                    aria-pressed={isSelected}
                    onClick={() => handlePreset(amount)}
                    className={`group flex items-center justify-between gap-3 rounded-2xl border p-4 text-left transition ${
                      isSelected
                        ? 'border-[#14342a] bg-[#14342a]/[0.04] ring-2 ring-[#14342a]/10 dark:border-[#4ade80] dark:bg-[#4ade80]/[0.06] dark:ring-[#4ade80]/10'
                        : 'border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50 dark:border-gray-700 dark:bg-[#1E1E1E] dark:hover:border-gray-600 dark:hover:bg-gray-800/60'
                    }`}
                  >
                    <span className="flex min-w-0 items-center gap-3">
                      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${isSelected ? 'bg-[#14342a] text-white dark:bg-[#4ade80] dark:text-[#14342a]' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300'}`}>
                        <Icon className="h-4 w-4" />
                      </span>
                      <span className="min-w-0">
                        <span className="block text-lg font-bold tabular-nums text-gray-900 dark:text-gray-100">
                          ฿{formattedPreset}
                        </span>
                        <span className="mt-0.5 block truncate text-[11px] font-medium text-gray-500 dark:text-gray-400">
                          {label}
                        </span>
                      </span>
                    </span>
                    {isSelected && <CheckCircle2 className="h-4 w-4 shrink-0 text-[#059669] dark:text-[#4ade80]" />}
                  </button>
                );
              })}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('customAmount')}
                </span>
                <span className="relative block">
                  <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-gray-400">฿</span>
                  <input
                    data-testid="donation-custom-amount"
                    type="text"
                    inputMode="decimal"
                    autoComplete="off"
                    value={customAmount}
                    onChange={(event) => handleCustomAmount(event.currentTarget.value)}
                    placeholder={t('customPlaceholder')}
                    aria-invalid={Boolean(customAmount) && !amountIsValid}
                    className="w-full rounded-xl border border-gray-200 bg-white py-3 pl-8 pr-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-[#14342a] focus:ring-2 focus:ring-[#14342a]/10 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100 dark:focus:border-[#4ade80] dark:focus:ring-[#4ade80]/10"
                  />
                </span>
                <span className="mt-1.5 block text-[10px] text-gray-400">{t('minimumAmount')} · {t('maximumAmount')}</span>
              </label>

              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                  {t('messageLabel')}
                </span>
                <input
                  data-testid="donation-message"
                  type="text"
                  maxLength={280}
                  value={message}
                  onChange={(event) => setMessage(event.currentTarget.value)}
                  placeholder={t('messagePlaceholder')}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-[#14342a] focus:ring-2 focus:ring-[#14342a]/10 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100 dark:focus:border-[#4ade80] dark:focus:ring-[#4ade80]/10"
                />
              </label>
            </div>

            {error && (
              <div role="alert" className="rounded-xl border border-amber-200 bg-amber-50 px-3.5 py-3 text-xs font-medium text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
                {error}
                {!token && (
                  <Link href="/login" className="ml-2 inline-flex items-center gap-1 font-bold underline underline-offset-2">
                    {t('loginLink')} <ArrowRight className="h-3 w-3" />
                  </Link>
                )}
              </div>
            )}

            {!token && (
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t('loginRequired')}{' '}
                <Link href="/login" className="font-semibold text-[#14342a] underline underline-offset-2 dark:text-[#4ade80]">
                  {t('loginLink')}
                </Link>
              </p>
            )}

            <button
              type="submit"
              data-testid="support-stripe-button"
              disabled={createDonation.isPending}
              className="inline-flex w-full items-center justify-center gap-2.5 rounded-xl bg-[#14342a] px-5 py-3.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#0f261e] focus:outline-none focus:ring-2 focus:ring-[#059669] focus:ring-offset-2 disabled:cursor-wait disabled:opacity-70 dark:focus:ring-offset-[#1E1E1E]"
            >
              {createDonation.isPending ? (
                <LoaderCircle className="h-4 w-4 animate-spin" />
              ) : (
                <LockKeyhole className="h-4 w-4" />
              )}
              {t('supportButton')}
            </button>

            <div className="flex items-start gap-2 rounded-xl bg-gray-50 px-3.5 py-3 dark:bg-[#121212]">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#059669]" />
              <p className="text-[10px] leading-5 text-gray-500 dark:text-gray-400">
                {t('secureNote')} {t('privacyNote')}
              </p>
            </div>
          </form>
        </section>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] sm:p-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-[#059669] dark:bg-emerald-950/50 dark:text-emerald-400">
              <Sparkles className="h-5 w-5" />
            </div>
            <h2 className="mt-4 text-base font-bold text-gray-900 dark:text-gray-100">{t('impactTitle')}</h2>
            <p className="mt-2 text-xs leading-6 text-gray-500 dark:text-gray-400">{t('impactBody')}</p>
            <div className="mt-4 space-y-2.5">
              {[t('precisionTools'), t('thaiTaxTools'), t('privacyTools')].map((item) => (
                <div key={item} className="flex items-center gap-2.5 text-xs font-medium text-gray-700 dark:text-gray-300">
                  <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-[#059669] dark:text-emerald-400" />
                  {item}
                </div>
              ))}
            </div>
          </div>

          <section className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-5 shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/25" data-testid="donor-pro-year-reward">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#14342a] text-emerald-100">
                <CircleDollarSign className="h-5 w-5" />
              </span>
              <div>
                <h2 className="text-sm font-extrabold text-[#14342a] dark:text-emerald-200">{t('donorRewardTitle')}</h2>
                <p className="mt-2 text-[11px] leading-5 text-gray-700 dark:text-gray-300">{t('donorRewardDescription')}</p>
              </div>
            </div>
            {token && donorReward ? (
              <div className="mt-4 rounded-xl border border-emerald-200/80 bg-white/80 p-3 dark:border-emerald-900/50 dark:bg-[#121212]/80">
                <p className="text-[10px] font-semibold text-gray-700 dark:text-gray-300">
                  {t('donorRewardProgress', { donated: formatTHB(donorReward.donatedTHB), threshold: formatTHB(donorReward.thresholdTHB) })}
                </p>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-emerald-100 dark:bg-gray-800" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={donorRewardProgress}>
                  <div className="h-full rounded-full bg-[#059669]" style={{ width: `${donorRewardProgress}%` }} />
                </div>
                <p className="mt-2 text-[10px] font-bold text-[#14342a] dark:text-emerald-200">
                  {donorReward.eligible ? t('donorRewardQualified') : t('donorRewardRemaining', { remaining: formatTHB(donorReward.remainingTHB) })}
                </p>
              </div>
            ) : (
              <p className="mt-3 rounded-xl bg-white/80 px-3 py-2 text-[10px] text-gray-600 dark:bg-[#121212]/80 dark:text-gray-300">{t('donorRewardSignIn')}</p>
            )}
            <div className="mt-4 border-t border-emerald-200/80 pt-3 dark:border-emerald-900/50">
              <p className="text-[10px] leading-5 text-gray-600 dark:text-gray-400">{t('donorRewardSeparate')}</p>
              <Link href="/pricing" className="mt-2 inline-flex items-center gap-1.5 text-[10px] font-bold text-[#14342a] hover:underline dark:text-emerald-300" data-testid="support-early-bird-link">
                {t('earlyBirdLink')} <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          </section>

          <Link
            href="/settings/billing"
            className="group flex items-center justify-between gap-4 rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm transition hover:border-emerald-200 hover:bg-emerald-50/30 dark:border-gray-800 dark:bg-[#1E1E1E] dark:hover:border-emerald-900/70 dark:hover:bg-emerald-950/10 sm:p-6"
          >
            <div>
              <p className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('backToBilling')}</p>
              <p className="mt-1 text-[11px] text-gray-500 dark:text-gray-400">{t('betaPlanAccess')}</p>
            </div>
            <ArrowRight className="h-4 w-4 text-[#14342a] transition group-hover:translate-x-1 dark:text-[#4ade80]" />
          </Link>
        </aside>
      </div>
    </div>
  );
}
