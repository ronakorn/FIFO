'use client';

import React, { Suspense, useEffect, useState } from 'react';
import { CalendarRange, TrendingDown } from 'lucide-react';
import { useSearchParams } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { CorporateActionAlert } from '@/components/wave1/CorporateActionAlert';
import { DividendCalendar } from '@/components/wave1/DividendCalendar';
import { TaxLossHarvester } from '@/components/wave1/TaxLossHarvester';
import { usePortfolioStore } from '@/lib/stores';

function Wave1PlanningContent() {
  const t = useTranslations('wave1');
  const searchParams = useSearchParams();
  const selectedPortfolioId = usePortfolioStore((s) => s.selectedPortfolioId);

  const initialTab =
    searchParams.get('tab') === 'calendar' ? 'calendar' : 'harvester';
  const [activeTab, setActiveTab] = useState<'harvester' | 'calendar'>(
    initialTab
  );
  const [refreshCounter, setRefreshCounter] = useState(0);

  useEffect(() => {
    const qTab = searchParams.get('tab');
    if (qTab === 'calendar' || qTab === 'harvester') {
      setActiveTab(qTab);
    }
  }, [searchParams]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <header className="space-y-2">
        <p className="text-[11px] font-bold uppercase tracking-widest text-[#059669]">
          {t('eyebrow')}
        </p>
        <h1 className="text-2xl font-extrabold tracking-tight text-[#1A1A1A] dark:text-[#F5F5F5] sm:text-3xl">
          {t('title')}
        </h1>
        <p className="max-w-3xl text-sm text-gray-500 dark:text-gray-400">
          {t('subtitle')}
        </p>
      </header>

      {/* Corporate Action Alert Banner */}
      <CorporateActionAlert
        portfolioId={selectedPortfolioId}
        onAdjustmentApplied={() => setRefreshCounter((c) => c + 1)}
      />

      {/* Segmented Tab Switcher */}
      <div className="inline-flex rounded-2xl border border-gray-200/80 bg-white p-1.5 shadow-2xs dark:border-gray-800 dark:bg-[#1E1E1E]">
        <button
          type="button"
          data-testid="wave1-tab-harvester"
          onClick={() => setActiveTab('harvester')}
          className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            activeTab === 'harvester'
              ? 'bg-[#14342a] text-white shadow-sm'
              : 'text-gray-600 hover:text-[#1A1A1A] dark:text-gray-400 dark:hover:text-white'
          }`}
        >
          <TrendingDown className="h-3.5 w-3.5" />
          <span>{t('tabHarvester')}</span>
        </button>

        <button
          type="button"
          data-testid="wave1-tab-calendar"
          onClick={() => setActiveTab('calendar')}
          className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            activeTab === 'calendar'
              ? 'bg-[#14342a] text-white shadow-sm'
              : 'text-gray-600 hover:text-[#1A1A1A] dark:text-gray-400 dark:hover:text-white'
          }`}
        >
          <CalendarRange className="h-3.5 w-3.5" />
          <span>{t('tabCalendar')}</span>
        </button>
      </div>

      {/* Active Module Content */}
      {activeTab === 'harvester' ? (
        <TaxLossHarvester
          portfolioId={selectedPortfolioId}
          refreshTrigger={refreshCounter}
        />
      ) : (
        <DividendCalendar portfolioId={selectedPortfolioId} year={2026} />
      )}
    </div>
  );
}

export default function Wave1PlanningPage() {
  const t = useTranslations('appMessages');
  return (
    <ErrorBoundary fallbackTitle={t('planningPageError')}>
      <Suspense fallback={<div className="h-64 animate-pulse rounded-2xl bg-gray-100 dark:bg-gray-800" />}>
        <Wave1PlanningContent />
      </Suspense>
    </ErrorBoundary>
  );
}
