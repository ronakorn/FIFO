'use client';

import { useTranslations } from 'next-intl';
import React from 'react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { GoldSensitivityWorkspace } from '@/components/gold/GoldSensitivityWorkspace';

export default function GoldPage() {
  const t = useTranslations('appMessages');
  return (
    <ErrorBoundary fallbackTitle={t('goldPageError')}>
      <GoldSensitivityWorkspace />
    </ErrorBoundary>
  );
}
