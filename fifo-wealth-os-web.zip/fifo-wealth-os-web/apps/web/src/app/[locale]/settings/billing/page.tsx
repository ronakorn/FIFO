'use client';

import React from 'react';
import type { BillingInterval, BillingTier } from '@/types/billing';
import {
  ArrowRight,
  Check,
  CheckCircle2,
  CircleDollarSign,
  Clock3,
  CreditCard,
  HeartHandshake,
  LockKeyhole,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import { useBillingStatus, useCommunityFundraising } from '@/lib/billingQueries';

function formatTHB(amount: string | undefined): string {
  if (amount === undefined) return '—';
  try {
    const [whole = '0', fraction = '00'] = amount.split('.');
    const groupedWhole = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return fraction === '00' ? `฿${groupedWhole}` : `฿${groupedWhole}.${fraction}`;
  } catch {
    return '—';
  }
}

const TIERS: { tier: BillingTier; audienceKey: string; featuresKey: string; current: boolean }[] = [
  { tier: 'FREE', audienceKey: 'freeAudience', featuresKey: 'freeFeatures', current: true },
  { tier: 'PRO', audienceKey: 'proAudience', featuresKey: 'proFeatures', current: false },
  { tier: 'FAMILY', audienceKey: 'familyAudience', featuresKey: 'familyFeatures', current: false },
  { tier: 'ADVISOR', audienceKey: 'advisorAudience', featuresKey: 'advisorFeatures', current: false },
];

const FEATURE_MATRIX: { key: string; translationKey: string; kind: 'boolean' | 'limit' }[] = [
  { key: 'maxPortfolios', translationKey: 'matrixPortfolios', kind: 'limit' },
  { key: 'maxTransactionsPerYear', translationKey: 'matrixTransactions', kind: 'limit' },
  { key: 'csvUpload', translationKey: 'matrixCsv', kind: 'boolean' },
  { key: 'basicNetWorth', translationKey: 'matrixBasicNetWorth', kind: 'boolean' },
  { key: 'taxReportPDF', translationKey: 'matrixTaxPdf', kind: 'boolean' },
  { key: 'advancedAnalytics', translationKey: 'matrixAnalytics', kind: 'boolean' },
  { key: 'firePlanner', translationKey: 'matrixFire', kind: 'boolean' },
  { key: 'aiAssistant', translationKey: 'matrixAi', kind: 'boolean' },
  { key: 'familyWealth', translationKey: 'matrixFamily', kind: 'boolean' },
  { key: 'auditTrail', translationKey: 'matrixAudit', kind: 'boolean' },
  { key: 'prioritySupport', translationKey: 'matrixPriority', kind: 'boolean' },
  { key: 'maxFamilyMembers', translationKey: 'matrixFamilyMembers', kind: 'limit' },
  { key: 'whiteLabel', translationKey: 'matrixWhiteLabel', kind: 'boolean' },
  { key: 'clientManagement', translationKey: 'matrixClientManagement', kind: 'boolean' },
  { key: 'maxClients', translationKey: 'matrixMaxClients', kind: 'limit' },
];

export default function BillingSettingsPage() {
  const t = useTranslations('billing');
  const billingStatus = useBillingStatus();
  const community = useCommunityFundraising();
  const [billingInterval, setBillingInterval] = React.useState<BillingInterval>('month');
  const pricing = billingStatus.data?.pricing;

  const featureCell = (tier: BillingTier, row: (typeof FEATURE_MATRIX)[number]) => {
    const featureConfig = pricing?.tiers.find((item) => item.tier === tier)?.features;
    const value = featureConfig?.[row.key];
    if (row.kind === 'boolean') {
      return { included: value === true, detail: '' };
    }
    const limit = typeof value === 'number' ? value : 0;
    return {
      included: limit !== 0,
      detail: limit < 0 ? t('matrixUnlimited') : limit > 0 ? String(limit) : '',
    };
  };

  const progress = Math.max(0, Math.min(100, Number(community.data?.progressPercentage ?? '0')));

  return (
    <div className="mx-auto max-w-6xl space-y-7" data-testid="billing-settings-page">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#059669]">{t('eyebrow')}</p>
          <h1 className="mt-1.5 text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100 sm:text-3xl">{t('title')}</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-gray-500 dark:text-gray-400">{t('subtitle')}</p>
        </div>
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide text-[#059669] dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-300" data-testid="open-beta-badge">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#059669] dark:bg-emerald-400" />
          {t('openBeta')}
        </span>
      </header>

      {billingStatus.isError && (
        <div role="alert" className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
          {t('loadError')}
        </div>
      )}

      <section
        className="relative overflow-hidden rounded-2xl border border-emerald-900/20 bg-[#14342a] p-6 text-white shadow-sm sm:p-8"
        data-testid="beta-all-access-card"
        aria-busy={billingStatus.isLoading}
      >
        <div className="pointer-events-none absolute -right-12 -top-20 h-64 w-64 rounded-full border border-white/10" />
        <div className="relative grid gap-7 lg:grid-cols-[1fr_auto] lg:items-center">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200/25 bg-emerald-200/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-emerald-100">
                <Sparkles className="h-3.5 w-3.5" /> {t('statusValue')}
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-300 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-[#14342a]" data-testid="all-access-green-badge">
                <CheckCircle2 className="h-3.5 w-3.5" /> {t('unlimitedBadge')}
              </span>
            </div>
            <h2 className="mt-4 text-xl font-bold tracking-tight sm:text-2xl" data-testid="billing-plan-title">
              {billingStatus.data?.planName ?? t('planTitle')}
            </h2>
            <p className="mt-2 max-w-2xl text-sm font-semibold leading-6 text-emerald-50">{t('betaMessage')}</p>
            <p className="mt-1 max-w-2xl text-xs leading-5 text-emerald-100/75">{t('betaDetail')}</p>
            <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] text-emerald-100/80">
              <span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" />{t('statusLabel')}: {billingStatus.data?.status ?? t('statusValue')}</span>
              <span className="inline-flex items-center gap-1.5"><CreditCard className="h-3.5 w-3.5" />{t('zeroMonthly')}</span>
            </div>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row lg:flex-col">
            <Link
              href="/support"
              data-testid="support-project-link"
              className="inline-flex min-w-[210px] items-center justify-center gap-2 rounded-xl bg-white px-4 py-3 text-xs font-bold text-[#14342a] shadow-sm transition hover:bg-emerald-50"
            >
              <HeartHandshake className="h-4 w-4" aria-hidden="true" /> {t('supportButton')} <ArrowRight className="h-3.5 w-3.5" />
            </Link>
            <Link
              href="/pricing"
              data-testid="pricing-page-link"
              className="inline-flex min-w-[210px] items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-[11px] font-semibold text-emerald-50 transition hover:bg-white/10"
            >
              <CircleDollarSign className="h-3.5 w-3.5" /> {t('pricingTitle')} <ArrowRight className="h-3.5 w-3.5" />
            </Link>
            <span title={t('upgradeTooltip')} data-testid="upgrade-tooltip-wrapper">
              <button
                type="button"
                disabled
                aria-disabled="true"
                aria-describedby="upgrade-tooltip-text"
                title={t('upgradeTooltip')}
                data-testid="upgrade-to-pro"
                className="inline-flex w-full min-w-[210px] cursor-not-allowed items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-[11px] font-semibold text-emerald-100/65"
              >
                <LockKeyhole className="h-3.5 w-3.5" /> {t('upgradeToPro')}
              </button>
            </span>
            <span id="upgrade-tooltip-text" className="sr-only">{t('upgradeTooltip')}</span>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-gray-200/80 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] sm:p-6" data-testid="billing-community-fundraising">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#059669]">{t('communityGoalTitle')}</p>
            <p className="mt-1.5 text-xl font-extrabold tabular-nums text-gray-900 dark:text-gray-100">
              {t('communityRaised', { raised: formatTHB(community.data?.totalRaisedTHB) })}
            </p>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              {t('communityGoal', { target: formatTHB(community.data?.targetTHB) })}
            </p>
          </div>
          <div className="w-full max-w-xl">
            <div
              className="h-2.5 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800"
              role="progressbar"
              aria-label={t('communityGoalTitle')}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={progress}
            >
              <div className="h-full rounded-full bg-[#059669] transition-[width]" style={{ width: `${progress}%` }} />
            </div>
            <p className="mt-2 text-[10px] leading-5 text-gray-500 dark:text-gray-400">{t('communityNote')}</p>
          </div>
        </div>
      </section>

      <section className="space-y-4" aria-labelledby="pricing-heading" data-testid="billing-pricing">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#059669]">{t('pricingEyebrow')}</p>
            <h2 id="pricing-heading" className="mt-1 text-xl font-bold tracking-tight text-gray-900 dark:text-gray-100">{t('pricingTitle')}</h2>
            <p className="mt-1.5 max-w-3xl text-xs leading-5 text-gray-500 dark:text-gray-400">{t('pricingIntro')}</p>
          </div>
          <div className="inline-flex w-fit rounded-xl border border-gray-200 bg-white p-1 shadow-sm dark:border-gray-700 dark:bg-[#1E1E1E]" role="group" aria-label={t('billingInterval')}>
            {(['month', 'year'] as const).map((interval) => (
              <button
                key={interval}
                type="button"
                aria-pressed={billingInterval === interval}
                onClick={() => setBillingInterval(interval)}
                className={`rounded-lg px-3 py-2 text-[11px] font-bold transition ${billingInterval === interval ? 'bg-[#14342a] text-white' : 'text-gray-500 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white'}`}
              >
                {t(interval === 'month' ? 'monthly' : 'yearly')}
              </button>
            ))}
          </div>
        </div>

        {pricing?.earlyBird.discountActive && (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 px-4 py-3 text-xs leading-5 text-[#14342a] dark:border-emerald-900/50 dark:bg-emerald-950/25 dark:text-emerald-100" data-testid="early-bird-banner">
            <span className="font-extrabold">{t('earlyBirdLabel')}</span>{' '}
            {t('earlyBirdMessage', { discount: pricing.earlyBird.discountPercentage, validUntil: pricing.earlyBird.validUntil })}
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {TIERS.map((plan) => {
            const planPricing = pricing?.tiers.find((item) => item.tier === plan.tier);
            const basePrice = billingInterval === 'month' ? planPricing?.monthlyPriceTHB : planPricing?.yearlyPriceTHB;
            const earlyBirdPrice = billingInterval === 'month' ? planPricing?.earlyBirdMonthlyPriceTHB : planPricing?.earlyBirdYearlyPriceTHB;
            const discountActive = Boolean(
              pricing?.earlyBird.discountActive && plan.tier !== 'FREE' && basePrice !== undefined && earlyBirdPrice !== undefined && earlyBirdPrice !== basePrice
            );
            const shownPrice = discountActive ? earlyBirdPrice : basePrice;

            return (
              <article
                key={plan.tier}
                data-testid={`billing-price-${plan.tier.toLowerCase()}`}
                className={`flex min-h-[246px] flex-col rounded-2xl border p-5 shadow-sm ${plan.tier === 'PRO' ? 'border-emerald-900/30 bg-[#14342a] text-white' : 'border-gray-200/80 bg-white text-gray-900 dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-100'}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-xs font-extrabold uppercase tracking-[0.12em]">{plan.tier}</h3>
                    <p className={`mt-1 text-[11px] leading-4 ${plan.tier === 'PRO' ? 'text-emerald-100/75' : 'text-gray-500 dark:text-gray-400'}`}>{t(plan.audienceKey)}</p>
                  </div>
                  {discountActive && <span className="rounded-full bg-emerald-300 px-2 py-1 text-[9px] font-extrabold uppercase tracking-wide text-[#14342a]">{pricing?.earlyBird.discountPercentage}% OFF</span>}
                </div>
                <div className="mt-5 flex items-baseline gap-2">
                  <span className="text-2xl font-extrabold tracking-tight" data-testid={`billing-amount-${plan.tier.toLowerCase()}`}>{formatTHB(shownPrice)}</span>
                  {discountActive && <del className={`text-xs ${plan.tier === 'PRO' ? 'text-emerald-100/55' : 'text-gray-400'}`}>{formatTHB(basePrice)}</del>}
                </div>
                <p className={`mt-1 text-[10px] ${plan.tier === 'PRO' ? 'text-emerald-100/70' : 'text-gray-500 dark:text-gray-400'}`}>
                  {t(billingInterval === 'month' ? 'perMonth' : 'perYear')}
                  {billingInterval === 'year' && planPricing && Number(planPricing.yearlySavingsPercentage) > 0
                    ? ` · ${t('yearlySavings', { percent: planPricing.yearlySavingsPercentage })}`
                    : ''}
                </p>
                <div className="mt-auto pt-5">
                  <span className={`inline-flex w-full items-center justify-center gap-1.5 rounded-xl border px-3 py-2.5 text-[10px] font-bold ${plan.tier === 'PRO' ? 'border-white/20 bg-white/5 text-emerald-50' : 'border-gray-200 bg-gray-50 text-gray-500 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300'}`}>
                    <LockKeyhole className="h-3 w-3" /> {t('noCheckout')}
                  </span>
                </div>
              </article>
            );
          })}
        </div>
        <p className="rounded-xl border border-gray-200/80 bg-gray-50 px-4 py-3 text-[11px] leading-5 text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400" data-testid="billing-no-charges-note">{t('chargesDisabled')}</p>
      </section>

      <section className="space-y-4" aria-labelledby="future-upgrades-heading">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-gray-400">{t('planDetailsEyebrow')}</p>
            <h2 id="future-upgrades-heading" className="mt-1 text-xl font-bold tracking-tight text-gray-900 dark:text-gray-100">{t('futureTitle')}</h2>
            <p className="mt-1.5 max-w-3xl text-xs leading-5 text-gray-500 dark:text-gray-400">{t('comparisonIntro')}</p>
          </div>
          <span className="inline-flex w-fit items-center gap-1.5 rounded-full border border-gray-200 bg-gray-50 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide text-gray-500 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">
            <Clock3 className="h-3.5 w-3.5" /> {t('futureBadge')}
          </span>
        </div>

        <div className="overflow-hidden rounded-2xl border border-gray-200/80 bg-white shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]" data-testid="billing-feature-comparison">
          <div className="overflow-x-auto">
            <table className="min-w-[760px] w-full border-collapse text-left">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50/80 text-[10px] font-bold uppercase tracking-wide text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                  <th scope="col" className="sticky left-0 z-10 bg-gray-50/95 px-4 py-3 dark:bg-[#121212]">{t('matrixPlan')}</th>
                  {TIERS.map(({ tier }) => <th key={tier} scope="col" data-testid={`billing-tier-${tier.toLowerCase()}`} className="px-4 py-3 text-center">{tier}</th>)}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {FEATURE_MATRIX.map((row) => (
                  <tr key={row.key} data-testid={`billing-feature-row-${row.key}`} className="text-xs">
                    <th scope="row" className="sticky left-0 z-10 min-w-[210px] bg-white px-4 py-3 text-left font-semibold text-gray-700 dark:bg-[#1E1E1E] dark:text-gray-200">{t(row.translationKey)}</th>
                    {TIERS.map(({ tier }) => {
                      const cell = featureCell(tier, row);
                      return (
                        <td key={tier} data-testid={`billing-feature-${tier.toLowerCase()}-${row.key}`} className="px-4 py-3 text-center">
                          {cell.included ? (
                            <span className="inline-flex items-center justify-center gap-1.5 font-semibold text-[#059669] dark:text-emerald-300" aria-label={t('matrixIncluded')}>
                              <Check className="h-4 w-4" aria-hidden="true" />
                              {cell.detail && <span className="text-[10px] text-gray-600 dark:text-gray-300">{cell.detail}</span>}
                            </span>
                          ) : (
                            <span className="inline-flex items-center justify-center text-gray-300 dark:text-gray-600" aria-label={t('matrixExcluded')}>
                              <X className="h-4 w-4" aria-hidden="true" />
                            </span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <div className="flex flex-col gap-3 rounded-2xl border border-emerald-200/70 bg-emerald-50/60 p-4 sm:flex-row sm:items-center sm:justify-between dark:border-emerald-900/50 dark:bg-emerald-950/20">
        <p className="max-w-3xl text-xs leading-5 text-emerald-950/80 dark:text-emerald-100/80">{t('freeNowNote')}</p>
        <Link href="/support" className="inline-flex shrink-0 items-center gap-1.5 text-xs font-bold text-[#14342a] hover:underline dark:text-[#4ade80]">{t('supportButton')} <ArrowRight className="h-3.5 w-3.5" /></Link>
      </div>
    </div>
  );
}
