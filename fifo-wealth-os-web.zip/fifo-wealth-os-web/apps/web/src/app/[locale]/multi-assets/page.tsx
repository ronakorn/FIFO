'use client';

import { useTranslations } from 'next-intl';
import React from 'react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { MultiAssetWorkspace } from '@/components/multiAsset/MultiAssetWorkspace';

export default function MultiAssetsPage() {
  const t = useTranslations('appMessages');
  return (
    <ErrorBoundary fallbackTitle={t('multiAssetPageError')}>
      <MultiAssetWorkspace />
    </ErrorBoundary>
  );
}
