'use client';

import React, { useState } from 'react';
import { useTranslations } from 'next-intl';
import { Link, useRouter } from '@/navigation';
import { Activity, ArrowRight, Lock, Mail, ShieldCheck, Sparkles } from 'lucide-react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { ErrorMessage } from '@/components/ErrorMessage';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { useLoginMutation } from '@/lib/queries';
import { extractApiErrorMessage } from '@/lib/utils';

export default function LoginPage() {
  const t = useTranslations('auth.login');
  const router = useRouter();
  const loginMutation = useLoginMutation();

  const [email, setEmail] = useState('demo@wealthos.th');
  const [password, setPassword] = useState('WealthOS2024!');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    try {
      await loginMutation.mutateAsync({ email: email.trim(), password });
      router.push('/');
    } catch (err) {
      setErrorMsg(extractApiErrorMessage(err, t('demoError')));
    }
  };

  const handleFillDemo = () => {
    setEmail('demo@wealthos.th');
    setPassword('WealthOS2024!');
    setErrorMsg(null);
  };

  return (
    <ErrorBoundary fallbackTitle={t('boundaryTitle')}>
      <div className="flex min-h-screen flex-col justify-center px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto w-full max-w-md">
          {/* Clean Brand Header */}
          <div className="text-center">
            <Link href="/" className="inline-flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#14342a] text-white shadow-sm">
                <Activity className="h-5 w-5 stroke-[2.5]" />
              </div>
              <div className="text-left">
                <p className="text-lg font-bold tracking-tight text-gray-900 dark:text-gray-100">
                  FIFO Wealth OS
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('tagline')}
                </p>
              </div>
            </Link>

            <h1 className="mt-8 text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
              {t('heading')}
            </h1>
            <p className="mt-1.5 text-xs sm:text-sm text-gray-500 dark:text-gray-400">
              {t('subtitle')}
            </p>
          </div>

          {/* Minimalist Auth Card */}
          <div className="mt-8 rounded-2xl border border-gray-100 bg-white p-6 sm:p-8 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            {/* Demo Quick Fill Badge */}
            <div className="mb-6 flex items-center justify-between gap-2 rounded-xl bg-[#14342a]/[0.06] px-3.5 py-2.5 text-xs dark:bg-[#4ade80]/10">
              <div className="flex items-center gap-2 font-medium text-[#14342a] dark:text-[#4ade80]">
                <Sparkles className="h-4 w-4 shrink-0" />
                <span>{t('demoBadge')}</span>
              </div>
              <button
                type="button"
                onClick={handleFillDemo}
                className="font-bold text-[#14342a] underline hover:opacity-80 dark:text-[#4ade80]"
              >
                {t('fillDemo')}
              </button>
            </div>

            {errorMsg && (
              <div className="mb-5">
                <ErrorMessage title={t('errorTitle')} message={errorMsg} />
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="login-email"
                  className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200"
                >
                  {t('emailLabel')}
                </label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <input
                    id="login-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder={t('emailPlaceholder')}
                    className="h-11 w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/15 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="login-password"
                  className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200"
                >
                  {t('passwordLabel')}
                </label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                  <input
                    id="login-password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={t('passwordPlaceholder')}
                    className="h-11 w-full rounded-xl border border-gray-200 bg-white pl-10 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/15 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loginMutation.isPending}
                className="mt-2 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#14342a] px-5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1b4538] disabled:opacity-60"
              >
                {loginMutation.isPending ? (
                  <>
                    <LoadingSpinner size="sm" className="border-white border-t-transparent" />
                    {t('submitting')}
                  </>
                ) : (
                  <>
                    {t('submit')}
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 border-t border-gray-100 pt-5 text-center text-xs text-gray-500 dark:border-gray-800 dark:text-gray-400">
              {t('signupPrompt')}{' '}
              <Link
                href="/register"
                className="font-bold text-[#14342a] hover:underline dark:text-[#4ade80]"
              >
                {t('signupLink')}
              </Link>
              {' • '}
              <Link href="/" className="text-gray-700 hover:underline dark:text-gray-300">
                {t('homeLink')}
              </Link>
            </div>
          </div>

          <div className="mt-6 flex items-center justify-center gap-2 text-xs text-gray-500 dark:text-gray-400">
            <ShieldCheck className="h-4 w-4 text-[#059669] dark:text-emerald-400" />
            <span>{t('securityNote')}</span>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}
