'use client';

import { useTranslations } from 'next-intl';
import React from 'react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { WealthJournal } from '@/components/journal/WealthJournal';

export default function WealthJournalPage() {
  const t = useTranslations('appMessages');
  return (
    <ErrorBoundary fallbackTitle={t('journalPageError')}>
      <WealthJournal />
    </ErrorBoundary>
  );
}
