'use client';
import { useTranslations } from 'next-intl';

import React from 'react';
import { ErrorMessage } from '@/components/ErrorMessage';

export default function GlobalError({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  const t = useTranslations('appMessages');
  return (
    <div className="py-10">
      <ErrorMessage
        title={t('globalErrorTitle')}
        message={t('globalErrorMessage')}
        onRetry={reset}
      />
    </div>
  );
}
