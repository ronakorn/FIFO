'use client';

import React, { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import api from '@/lib/api';
import { useTranslations } from 'next-intl';
import { Link, useRouter } from '@/navigation';
import {
  ArrowRight,
  Calendar,
  CreditCard,
  LogIn,
  LogOut,
  Loader2,
  Moon,
  ShieldCheck,
  Sun,
  User as UserIcon,
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { PrivacyToggle } from '@/components/family/PrivacyToggle';
import { useAuthStore, usePortfolioStore } from '@/lib/stores';
import { cn, extractApiErrorMessage } from '@/lib/utils';

interface UserProfileResponse {
  id: string;
  dateOfBirth: string | null;
}

export default function ProfilePage() {
  const t = useTranslations('profile');
  const router = useRouter();
  const { resolvedTheme, setTheme } = useTheme();
  const user = useAuthStore((s) => s.user);
  const token = useAuthStore((s) => s.token);
  const logout = useAuthStore((s) => s.logout);
  const selectedTaxYear = usePortfolioStore((s) => s.selectedTaxYear);
  const setSelectedTaxYear = usePortfolioStore((s) => s.setSelectedTaxYear);
  const queryClient = useQueryClient();
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [dateOfBirthMessage, setDateOfBirthMessage] = useState<string | null>(null);
  const profileQuery = useQuery<UserProfileResponse>({
    queryKey: ['user-profile', user?.id],
    enabled: Boolean(token && user),
    queryFn: async () => {
      const { data } = await api.get<{ user: UserProfileResponse }>('/auth/me');
      return data.user;
    },
    staleTime: 60_000,
  });
  const dateOfBirthMutation = useMutation({
    mutationFn: async () => {
      const { data } = await api.patch<{ user: UserProfileResponse }>('/auth/me', {
        dateOfBirth: dateOfBirth || null,
      });
      return data.user;
    },
    onSuccess: (savedProfile) => {
      setDateOfBirth(savedProfile.dateOfBirth ?? '');
      setDateOfBirthMessage(t('dateSaved'))
      queryClient.setQueryData(['user-profile', user?.id], savedProfile);
      queryClient.invalidateQueries({ queryKey: ['multi-assets'] });
    },
    onError: (error) => setDateOfBirthMessage(extractApiErrorMessage(error, t('loadBirthErrorFallback'))),
  });

  useEffect(() => {
    setDateOfBirth(profileQuery.data?.dateOfBirth ?? '');
  }, [profileQuery.data?.dateOfBirth]);

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  return (
    <ErrorBoundary fallbackTitle={t('boundaryTitle')}>
      <div className="mx-auto max-w-2xl space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
            {t('eyebrow')}
          </p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {t('title')}
          </h1>
        </div>

        {/* Account Card */}
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          {token && user ? (
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#14342a] text-xl font-bold text-white dark:text-[#4ade80]">
                  {user.name.slice(0, 1).toUpperCase()}
                </div>
                <div>
                  <h2 className="text-lg font-bold tracking-tight text-gray-900 dark:text-gray-100">
                    {user.name}
                  </h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
                  <span className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-semibold text-[#059669] dark:bg-emerald-950/60 dark:text-emerald-400">
                    <ShieldCheck className="h-3 w-3" />
                    {t('verifiedSession')}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleLogout}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-xs font-semibold text-[#DC2626] transition hover:bg-red-100 dark:border-red-900/50 dark:bg-red-950/40 dark:text-rose-400"
              >
                <LogOut className="h-4 w-4" />
                {t('logout')}
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3.5">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400">
                  <UserIcon className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">
                    {t('guestMode')}
                  </h2>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('guestDescription')}
                  </p>
                </div>
              </div>
              <Link
                href="/login"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-[#1b4538]"
              >
                <LogIn className="h-4 w-4" />
                {t('loginRegister')}
              </Link>
            </div>
          )}
        </div>

        {token && user && (
          <section className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div>
              <h3 className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('rmfDateTitle')}</h3>
              <p className="mt-1 max-w-xl text-xs leading-relaxed text-gray-500 dark:text-gray-400">
                {t('rmfDateDescription')}
              </p>
            </div>
            <form
              className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end"
              onSubmit={(event) => {
                event.preventDefault();
                setDateOfBirthMessage(null);
                dateOfBirthMutation.mutate();
              }}
            >
              <label className="block w-full max-w-xs">
                <span className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-300">{t('dateOfBirth')}</span>
                <input
                  aria-label={t('dateOfBirthAria')}
                  className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-sm text-gray-900 outline-none focus:border-[#14342a] focus:ring-2 focus:ring-[#14342a]/10 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                  type="date"
                  max={new Date().toISOString().slice(0, 10)}
                  value={dateOfBirth}
                  onChange={(event) => setDateOfBirth(event.target.value)}
                  disabled={profileQuery.isLoading || dateOfBirthMutation.isPending}
                />
              </label>
              <button
                type="submit"
                disabled={profileQuery.isLoading || dateOfBirthMutation.isPending}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-[#1b4538] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {dateOfBirthMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                {t('saveDateOfBirth')}
              </button>
            </form>
            {dateOfBirthMessage && (
              <p className={`mt-3 text-xs ${dateOfBirthMutation.isError ? 'text-red-600 dark:text-red-400' : 'text-gray-500 dark:text-gray-400'}`}>
                {dateOfBirthMessage}
              </p>
            )}
            {profileQuery.isError && (
              <p className="mt-3 text-xs text-red-600 dark:text-red-400">{t('loadBirthError', { error: extractApiErrorMessage(profileQuery.error, t('loadBirthErrorFallback')) })}</p>
            )}
          </section>
        )}

        {/* Theme Appearance Card */}
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <h3 className="text-sm font-bold tracking-tight text-gray-900 dark:text-gray-100">
            {t('appearanceHeading')}
          </h3>
          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
            {t('appearanceIntro')}
          </p>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setTheme('light')}
              className={cn(
                'flex items-center justify-center gap-2 rounded-xl border p-3.5 text-xs font-semibold transition',
                resolvedTheme !== 'dark'
                  ? 'border-[#14342a] bg-[#14342a]/5 text-[#14342a]'
                  : 'border-gray-200 text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300 dark:hover:bg-gray-800'
              )}
            >
              <Sun className="h-4 w-4" />
              {t('lightTheme')}
            </button>

            <button
              type="button"
              onClick={() => setTheme('dark')}
              className={cn(
                'flex items-center justify-center gap-2 rounded-xl border p-3.5 text-xs font-semibold transition',
                resolvedTheme === 'dark'
                  ? 'border-[#4ade80] bg-[#4ade80]/10 text-[#4ade80]'
                  : 'border-gray-200 text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300'
              )}
            >
              <Moon className="h-4 w-4" />
              {t('darkTheme')}
            </button>
          </div>
        </div>

        {/* Default Tax Year */}
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Calendar className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
              <div>
                <h3 className="text-sm font-bold text-gray-900 dark:text-gray-100">
                  {t('defaultTaxYear')}
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('taxYearDescription')}
                </p>
              </div>
            </div>

            <div className="inline-flex rounded-xl bg-gray-100 p-1 dark:bg-gray-800">
              {[2024, 2025, 2026].map((yr) => (
                <button
                  key={yr}
                  type="button"
                  onClick={() => setSelectedTaxYear(yr)}
                  className={cn(
                    'rounded-lg px-3 py-1.5 text-xs font-semibold tabular-nums transition',
                    selectedTaxYear === yr
                      ? 'bg-[#14342a] text-white shadow-sm'
                      : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100'
                  )}
                >
                  {yr}
                </button>
              ))}
            </div>
          </div>
        </div>

        <section className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#14342a]/[0.06] text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                <CreditCard className="h-5 w-5" />
              </span>
              <div>
                <h3 className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('billingTitle')}</h3>
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{t('billingDesc')}</p>
              </div>
            </div>
            <Link
              href="/settings/billing"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-[#0f261e]"
            >
              {t('billingLink')} <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </section>

        {/* Family Wealth Privacy Rule Switch */}
        <PrivacyToggle />
      </div>
    </ErrorBoundary>
  );
}
