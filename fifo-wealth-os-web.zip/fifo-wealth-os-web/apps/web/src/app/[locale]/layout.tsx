import type { Metadata } from 'next';
import localFont from 'next/font/local';
import { notFound } from 'next/navigation';
import { NextIntlClientProvider } from 'next-intl';
import { getMessages } from 'next-intl/server';
import { AppLocale, locales } from '@/i18n';
import { AppShell } from '@/components/AppShell';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { Providers } from '@/components/Providers';
import { BottomNav } from '@/components/layout/BottomNav';

const plusJakarta = localFont({
  src: '../../fonts/PlusJakartaSans-Variable.ttf',
  weight: '200 800',
  variable: '--font-plus-jakarta',
  display: 'swap',
});

const sarabun = localFont({
  src: [
    {
      path: '../../fonts/Sarabun-Regular.ttf',
      weight: '400',
      style: 'normal',
    },
    {
      path: '../../fonts/Sarabun-Bold.ttf',
      weight: '700',
      style: 'normal',
    },
  ],
  variable: '--font-sarabun',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'FIFO Wealth OS | Private Wealth, Tax, FIRE & Family Office',
  description:
    'Clean, minimalist multi-asset FIFO portfolio analytics, AI RAG assistant, Wealth Journal, Family Office, and Thai Revenue Department (PND 90) compliance platform.',
};

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;

  if (!locales.includes(locale as AppLocale)) {
    notFound();
  }

  const messages = await getMessages();
  const isEnglish = locale === 'en';

  return (
    <html
      lang={locale}
      data-locale={locale}
      suppressHydrationWarning
      className={`${plusJakarta.variable} ${sarabun.variable}`}
    >
      <body
        style={{
          fontFamily: isEnglish
            ? 'var(--font-plus-jakarta), var(--font-sarabun), system-ui, sans-serif'
            : 'var(--font-sarabun), var(--font-plus-jakarta), system-ui, sans-serif',
        }}
        className="min-h-screen bg-[#FAFAFA] text-[#1A1A1A] antialiased dark:bg-[#121212] dark:text-[#F5F5F5]"
      >
        <NextIntlClientProvider locale={locale} messages={messages}>
          <Providers>
            <AppShell>
              <ErrorBoundary>{children}</ErrorBoundary>
            </AppShell>
            <BottomNav />
          </Providers>
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
