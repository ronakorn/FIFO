'use client';

import React from 'react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { FamilyDashboard } from '@/components/family/FamilyDashboard';
import { useTranslations } from 'next-intl';

export default function FamilyWealthPage() {
  const t = useTranslations('family');
  return (
    <ErrorBoundary fallbackTitle={t('errorBoundaryTitle')}>
      <FamilyDashboard />
    </ErrorBoundary>
  );
}
