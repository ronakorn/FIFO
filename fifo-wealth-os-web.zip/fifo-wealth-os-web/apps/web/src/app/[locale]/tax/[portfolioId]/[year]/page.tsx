'use client';

import React from 'react';
import { useParams } from 'next/navigation';
import { useRouter } from '@/navigation';
import { useTranslations } from 'next-intl';
import { Calendar, FolderKanban } from 'lucide-react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { LegalDisclaimer } from '@/components/common/LegalDisclaimer';
import { ErrorMessage } from '@/components/ErrorMessage';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { TaxReportViewer } from '@/components/TaxReportViewer';
import { usePortfolio, usePortfolios, useTaxSummary } from '@/lib/queries';
import { useAuthStore, usePortfolioStore } from '@/lib/stores';
import { extractApiErrorMessage } from '@/lib/utils';
import { mockPortfolios } from '@/mocks/mockPortfolios';
import { mockTaxReport } from '@/mocks/mockTaxReport';

const AVAILABLE_YEARS = [2024, 2025, 2026];

export default function TaxReportPage() {
  const t = useTranslations('tax.page');
  const params = useParams<{ portfolioId: string; year: string }>();
  const router = useRouter();

  const portfolioId = params.portfolioId;
  const parsedYear = Number(params.year) || 2024;

  const token = useAuthStore((s) => s.token);
  const setSelectedPortfolioId = usePortfolioStore((s) => s.setSelectedPortfolioId);
  const setSelectedTaxYear = usePortfolioStore((s) => s.setSelectedTaxYear);

  const isMock = !token || portfolioId.startsWith('mock-');

  const portfoliosQuery = usePortfolios();
  const portfolioQuery = usePortfolio(isMock ? undefined : portfolioId);
  const taxQuery = useTaxSummary(isMock ? undefined : portfolioId, parsedYear);

  const portfolioList = token ? (portfoliosQuery.data ?? []) : mockPortfolios;
  const activePortfolio = isMock
    ? mockPortfolios.find((p) => p.id === portfolioId) ?? mockPortfolios[0]
    : portfolioQuery.data;

  const handlePortfolioChange = (nextPortfolioId: string) => {
    setSelectedPortfolioId(nextPortfolioId);
    router.push(`/tax/${nextPortfolioId}/${parsedYear}`);
  };

  const handleYearChange = (nextYear: number) => {
    setSelectedTaxYear(nextYear);
    router.push(`/tax/${portfolioId}/${nextYear}`);
  };

  return (
    <ErrorBoundary fallbackTitle={t('boundaryTitle')}>
      <div className="space-y-6">
        {/* Clean Minimalist Top Switcher Bar */}
        <div className="flex flex-col gap-4 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between dark:border-gray-800 dark:bg-[#1E1E1E]">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-gray-500 dark:text-gray-400">
              <FolderKanban className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
              <span>{t('portfolioLabel')}</span>
            </div>
            <select
              aria-label={t('portfolioAria')}
              value={activePortfolio?.id ?? portfolioId}
              onChange={(e) => handlePortfolioChange(e.target.value)}
              className="rounded-xl border border-gray-200 bg-white px-3.5 py-2 text-xs sm:text-sm font-semibold text-gray-900 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/15 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
            >
              {portfolioList.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">{t('yearLabel')}</span>
            <div className="inline-flex rounded-xl bg-gray-100 p-1 dark:bg-[#121212]">
              {AVAILABLE_YEARS.map((yr) => (
                <button
                  key={yr}
                  type="button"
                  onClick={() => handleYearChange(yr)}
                  className={
                    yr === parsedYear
                      ? 'rounded-lg bg-[#14342a] px-3 py-1 text-xs font-bold text-white shadow-sm tabular-nums dark:text-[#4ade80]'
                      : 'rounded-lg px-3 py-1 text-xs font-medium text-gray-600 hover:text-gray-900 tabular-nums dark:text-gray-400 dark:hover:text-gray-100'
                  }
                >
                  {yr}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Content State */}
        {!isMock && taxQuery.isLoading ? (
          <LoadingSpinner
            fullScreen
            label={t('loading', { year: parsedYear })}
          />
        ) : !isMock && taxQuery.isError ? (
          <ErrorMessage
            title={t('errorTitle')}
            message={extractApiErrorMessage(taxQuery.error, t('errorFallback'))}
            onRetry={() => taxQuery.refetch()}
          />
        ) : (
          <TaxReportViewer
            report={
              isMock
                ? { ...mockTaxReport, taxYear: parsedYear }
                : (taxQuery.data ?? { ...mockTaxReport, taxYear: parsedYear })
            }
            portfolioId={portfolioId}
            portfolioName={activePortfolio?.name}
            isMock={isMock}
          />
        )}
        <LegalDisclaimer />
      </div>
    </ErrorBoundary>
  );
}
