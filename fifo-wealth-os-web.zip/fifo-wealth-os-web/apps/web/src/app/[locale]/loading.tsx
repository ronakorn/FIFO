import { getTranslations } from 'next-intl/server';

import React from 'react';
import { LoadingSpinner } from '@/components/LoadingSpinner';

export default async function GlobalLoading() {
  const t = await getTranslations('appMessages');
  return (
    <LoadingSpinner
      fullScreen
      label={t('loadingLabel')}
      sublabel={t('loadingSubline')}
    />
  );
}
