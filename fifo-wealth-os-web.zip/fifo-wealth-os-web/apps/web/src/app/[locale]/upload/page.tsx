'use client';

import React, { Suspense } from 'react';
import { useTranslations } from 'next-intl';
import { useSearchParams } from 'next/navigation';
import { CryptoWalletManager } from '@/components/CryptoWalletManager';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { FileUploader } from '@/components/FileUploader';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { ThaiBrokerConnectionHub } from '@/components/ThaiBrokerConnectionHub';
import { BrokerConnectionCard } from '@/components/sync/BrokerConnectionCard';
import { BloombergUploader } from '@/components/upload/BloombergUploader';

function UploadPageContent() {
  const t = useTranslations('upload.page');
  const searchParams = useSearchParams();
  const portfolioId = searchParams.get('portfolioId') ?? undefined;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
          {t('eyebrow')}
        </p>
        <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
          {t('title')}
        </h1>
        <p className="mt-1 text-xs sm:text-sm text-gray-500 dark:text-gray-400">
          {t('description')}
        </p>
      </div>

      {/* Bloomberg export adapter and explicit Port sandbox boundary */}
      <BloombergUploader defaultPortfolioId={portfolioId} />

      {/* Thai broker import and access options; live availability is shown per connection */}
      <ThaiBrokerConnectionHub selectedPortfolioId={portfolioId} />

      {/* Direct Global Broker API Connector (IBKR Read-Only Manual Sync on Demand) */}
      <BrokerConnectionCard selectedPortfolioId={portfolioId} />

      {/* Read-Only Cross-Chain Crypto Wallet Sync (EVM, Solana, Bitcoin) */}
      <CryptoWalletManager selectedPortfolioId={portfolioId} />

      {/* Manual CSV Statement Upload */}
      <FileUploader defaultPortfolioId={portfolioId} />
    </div>
  );
}

export default function UploadPage() {
  const t = useTranslations('upload.page');

  return (
    <ErrorBoundary fallbackTitle={t('errorTitle')}>
      <Suspense fallback={<LoadingSpinner label={t('loading')} />}>
        <UploadPageContent />
      </Suspense>
    </ErrorBoundary>
  );
}
