'use client';

import { useTranslations } from 'next-intl';
import React from 'react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { FIRESummaryDashboard } from '@/components/fire/FIRESummaryDashboard';

export default function FIREPlannerPage() {
  const t = useTranslations('appMessages');
  return (
    <ErrorBoundary fallbackTitle={t('firePageError')}>
      <FIRESummaryDashboard />
    </ErrorBoundary>
  );
}
