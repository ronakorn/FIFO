'use client';

import React, { useState } from 'react';
import { useTranslations } from 'next-intl';
import { Link } from '@/navigation';
import { Plus, UploadCloud } from 'lucide-react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { ErrorMessage } from '@/components/ErrorMessage';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { PortfolioCard } from '@/components/PortfolioCard';
import { EmptyState } from '@/components/ux/EmptyState';
import { CorporateActionAlert } from '@/components/wave1/CorporateActionAlert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  useCreatePortfolio,
  useDeletePortfolio,
  usePortfolios,
} from '@/lib/queries';
import { useAuthStore, usePortfolioStore } from '@/lib/stores';
import { extractApiErrorMessage } from '@/lib/utils';
import { mockPortfolios } from '@/mocks/mockPortfolios';

export default function PortfoliosPage() {
  const t = useTranslations('portfolioList');
  const token = useAuthStore((s) => s.token);
  const isHydrated = useAuthStore((s) => s.isHydrated);
  const selectedTaxYear = usePortfolioStore((s) => s.selectedTaxYear);

  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState('');
  const [baseCurrency, setBaseCurrency] = useState('THB');
  const [formError, setFormError] = useState<string | null>(null);

  const portfoliosQuery = usePortfolios();
  const createMutation = useCreatePortfolio();
  const deleteMutation = useDeletePortfolio();

  const list = token ? (portfoliosQuery.data ?? []) : mockPortfolios;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!name.trim()) {
      setFormError(t('formErrorName'))
      return;
    }
    try {
      await createMutation.mutateAsync({
        name: name.trim(),
        baseCurrency,
      });
      setName('');
      setCreateOpen(false);
    } catch (err) {
      setFormError(extractApiErrorMessage(err, t('loadError')));
    }
  };

  return (
    <ErrorBoundary fallbackTitle={t('boundaryTitle')}>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#14342a] dark:text-[#4ade80]">
              {t('eyebrow')}
            </p>
            <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
              {t('title')}
            </h1>
            <p className="mt-1 text-xs sm:text-sm text-gray-500 dark:text-gray-400">
              {t('subtitle')}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <Link
              href="/upload"
              className="inline-flex items-center gap-2 rounded-xl border border-[#14342a]/20 bg-[#14342a]/5 px-4 py-2.5 text-xs font-semibold text-[#14342a] transition hover:bg-[#14342a]/10 dark:border-[#4ade80]/30 dark:bg-[#4ade80]/10 dark:text-[#4ade80]"
            >
              <UploadCloud className="h-4 w-4" />
              {t('syncImport')}
            </Link>

            {token ? (
              <Dialog open={createOpen} onOpenChange={setCreateOpen}>
                <DialogTrigger asChild>
                  <button
                    type="button"
                    className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#1b4538]"
                  >
                    <Plus className="h-4 w-4" />
                    {t('createNew')}
                  </button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{t('dialogTitle')}</DialogTitle>
                    <DialogDescription>
                      {t('dialogDescription')}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreate} className="mt-2 space-y-4">
                    <div>
                      <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                        {t('nameLabel')}
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={t('namePlaceholder')}
                        className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-sm text-gray-900 placeholder:text-gray-400 focus:border-[#14342a] focus:outline-none focus:ring-2 focus:ring-[#14342a]/15 dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                      />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs font-semibold text-gray-700 dark:text-gray-200">
                        {t('currencyLabel')}
                      </label>
                      <select
                        value={baseCurrency}
                        onChange={(e) => setBaseCurrency(e.target.value)}
                        className="w-full rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-sm text-gray-900 focus:border-[#14342a] focus:outline-none dark:border-gray-700 dark:bg-[#121212] dark:text-gray-100"
                      >
                        <option value="THB">{t('thbOption')}</option>
                        <option value="USD">{t('usdOption')}</option>
                      </select>
                    </div>
                    {formError && <p className="text-xs text-[#DC2626]">{formError}</p>}
                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setCreateOpen(false)}
                        className="rounded-xl bg-gray-100 px-4 py-2 text-xs font-semibold text-gray-800 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200"
                      >
                        {t('cancel')}
                      </button>
                      <button
                        type="submit"
                        disabled={createMutation.isPending}
                        className="rounded-xl bg-[#14342a] px-5 py-2 text-xs font-semibold text-white hover:bg-[#1b4538] disabled:opacity-50"
                      >
                        {createMutation.isPending ? t('saving') : t('create')}
                      </button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            ) : (
              <Link
                href="/login"
                className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-[#1b4538]"
              >
                {t('loginToCreate')}
              </Link>
            )}
          </div>
        </div>

        {/* Unapplied Corporate Action Alert Banner & Before/After Preview */}
        <CorporateActionAlert
          onlyUnapplied
          onAdjustmentApplied={() => {
            if (token) {
              portfoliosQuery.refetch();
            }
          }}
        />

        {!isHydrated || (token && portfoliosQuery.isLoading) ? (
          <LoadingSpinner label={t('loading')} />
        ) : token && portfoliosQuery.isError ? (
          <ErrorMessage
            message={extractApiErrorMessage(portfoliosQuery.error, t('loadError'))}
            onRetry={() => portfoliosQuery.refetch()}
          />
        ) : list.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {list.map((p) => (
              <PortfolioCard
                key={p.id}
                portfolio={p}
                taxYear={selectedTaxYear}
                onDelete={(id) => deleteMutation.mutate(id)}
              />
            ))}
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}
