'use client';

import React, { useMemo } from 'react';
import { Link } from '@/navigation';
import { useLocale, useTranslations } from 'next-intl';
import { useParams } from 'next/navigation';
import {
  ArrowLeft,
  Calculator,
  Layers,
  TrendingUp,
  UploadCloud,
  Wallet,
} from 'lucide-react';
import { AssetAllocationPieChart } from '@/components/Chart';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { ErrorMessage } from '@/components/ErrorMessage';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { TransactionTable } from '@/components/TransactionTable';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CorporateActionAlert } from '@/components/wave1/CorporateActionAlert';
import { usePortfolio, useTransactions } from '@/lib/queries';
import { useAuthStore, usePortfolioStore } from '@/lib/stores';
import {
  cn,
  extractApiErrorMessage,
  formatDateShort,
  formatQuantity,
  formatSignedTHB,
  formatTHB,
} from '@/lib/utils';
import { mockPortfolios } from '@/mocks/mockPortfolios';
import { mockTransactions } from '@/mocks/mockTransactions';

export default function PortfolioDetailPage() {
  const t = useTranslations('portfolioDetail');
  const locale = useLocale();
  const params = useParams<{ id: string }>();
  const portfolioId = params.id;

  const token = useAuthStore((s) => s.token);
  const selectedTaxYear = usePortfolioStore((s) => s.selectedTaxYear);

  const isMockId = portfolioId.startsWith('mock-');
  const portfolioQuery = usePortfolio(portfolioId);
  const transactionsQuery = useTransactions(portfolioId);

  const portfolio = isMockId
    ? mockPortfolios.find((p) => p.id === portfolioId) ?? mockPortfolios[0]
    : portfolioQuery.data;

  const transactions = isMockId
    ? mockTransactions.filter((t) => t.portfolioId === portfolioId)
    : (transactionsQuery.data ?? []);

  const lots = useMemo(
    () => portfolio?.fifoSummary?.lots ?? [],
    [portfolio?.fifoSummary?.lots]
  );

  const allocationData = useMemo(() => {
    const map = new Map<string, number>();
    for (const lot of lots) {
      if (lot.qtyRemain > 0) {
        const val = lot.costPerUnit * lot.qtyRemain + lot.unrealizedGL;
        map.set(lot.symbol, (map.get(lot.symbol) ?? 0) + Math.max(0, val));
      }
    }
    return Array.from(map.entries()).map(([name, value]) => ({
      name,
      value: Number(value.toFixed(2)),
    }));
  }, [lots]);

  if (!isMockId && token && (portfolioQuery.isLoading || transactionsQuery.isLoading)) {
    return <LoadingSpinner fullScreen label={t('loading')} />;
  }

  if (!isMockId && token && portfolioQuery.isError) {
    return (
      <ErrorMessage
        title={t('missingTitle')}
        message={extractApiErrorMessage(portfolioQuery.error, t('errorFallback'))}
        onRetry={() => portfolioQuery.refetch()}
      />
    );
  }

  if (!portfolio) {
    return (
      <ErrorMessage
        title={t('cannotOpenTitle')}
        message={t('loginOrChoose')}
      />
    );
  }

  const summary = portfolio.fifoSummary;

  return (
    <ErrorBoundary fallbackTitle={t('boundaryTitle')}>
      <div className="space-y-6">
        {/* Breadcrumb & Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <Link
              href="/portfolios"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-500 transition hover:text-[#14342a] dark:text-gray-400 dark:hover:text-[#4ade80]"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              {t('back')}
            </Link>
            <div className="mt-2 flex flex-wrap items-center gap-2.5">
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">
                {portfolio.name}
              </h1>
              <span className="rounded-lg bg-[#14342a]/8 px-2.5 py-0.5 text-xs font-bold text-[#14342a] dark:bg-[#4ade80]/10 dark:text-[#4ade80]">
                {t('base', { currency: portfolio.baseCurrency })}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <Link
              href={`/upload?portfolioId=${portfolio.id}`}
              className="inline-flex items-center gap-2 rounded-xl bg-gray-100 px-4 py-2.5 text-xs font-semibold text-gray-900 transition hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-100 dark:hover:bg-gray-700"
            >
              <UploadCloud className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
              {t('importCsv')}
            </Link>
            <Link
              href={`/tax/${portfolio.id}/${selectedTaxYear}`}
              className="inline-flex items-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-semibold text-white shadow-sm transition hover:bg-[#1b4538]"
            >
              <Calculator className="h-4 w-4" />
              {t('taxReport', { year: selectedTaxYear })}
            </Link>
          </div>
        </div>

        {/* Unapplied Corporate Action Alert Banner & Before/After Preview */}
        <CorporateActionAlert
          portfolioId={portfolio.id}
          portfolioLots={lots}
          onlyUnapplied
          onAdjustmentApplied={() => {
            if (!isMockId && token) {
              portfolioQuery.refetch();
              transactionsQuery.refetch();
            }
          }}
        />

        {/* Summary Metrics */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div className="flex items-center justify-between text-xs font-medium text-gray-500 dark:text-gray-400">
              <span>{t('marketValue')}</span>
              <Wallet className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
            </div>
            <p className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight text-[#14342a] tabular-nums dark:text-white">
              {formatTHB(summary?.marketValueTHB ?? 0)}
            </p>
            <p className="mt-1 text-xs text-gray-500 tabular-nums dark:text-gray-400">
              {t('openCostBasis', { amount: formatTHB(summary?.openCostBasisTHB ?? 0) })}
            </p>
          </div>

          <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div className="flex items-center justify-between text-xs font-medium text-gray-500 dark:text-gray-400">
              <span>{t('realizedGL')}</span>
              <TrendingUp className="h-4 w-4 text-[#059669] dark:text-emerald-400" />
            </div>
            <p
              className={cn(
                'mt-2 text-2xl sm:text-3xl font-bold tracking-tight tabular-nums',
                (summary?.totalRealizedGL ?? 0) >= 0
                  ? 'text-[#059669] dark:text-emerald-400'
                  : 'text-[#DC2626] dark:text-rose-400'
              )}
            >
              {formatSignedTHB(summary?.totalRealizedGL ?? 0)}
            </p>
            <p className="mt-1 text-xs text-gray-500 tabular-nums dark:text-gray-400">
              {t('totalSales', { amount: formatTHB(summary?.totalProceeds ?? 0) })}
            </p>
          </div>

          <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E]">
            <div className="flex items-center justify-between text-xs font-medium text-gray-500 dark:text-gray-400">
              <span>{t('unrealizedGL')}</span>
              <Layers className="h-4 w-4 text-[#14342a] dark:text-[#4ade80]" />
            </div>
            <p
              className={cn(
                'mt-2 text-2xl sm:text-3xl font-bold tracking-tight tabular-nums',
                (summary?.totalUnrealizedGL ?? 0) >= 0
                  ? 'text-[#059669] dark:text-emerald-400'
                  : 'text-[#DC2626] dark:text-rose-400'
              )}
            >
              {formatSignedTHB(summary?.totalUnrealizedGL ?? 0)}
            </p>
            <p className="mt-1 text-xs text-gray-500 tabular-nums dark:text-gray-400">
              {t('lotCount', { count: lots.length })}
            </p>
          </div>
        </div>

        {/* Allocation + Tabs (FIFO Lots & Cost Stats) */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <AssetAllocationPieChart
              data={allocationData}
              title={t('allocationTitle')}
              subtitle={t('allocationSubtitle')}
            />
          </div>

          <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-[#1E1E1E] lg:col-span-7">
            <Tabs defaultValue="lots">
              <TabsList>
                <TabsTrigger value="lots">{t('lotsTab', { count: lots.length })}</TabsTrigger>
                <TabsTrigger value="stats">{t('statsTab')}</TabsTrigger>
              </TabsList>

              <TabsContent value="lots">
                {lots.length === 0 ? (
                  <div className="py-10 text-center text-xs text-gray-400">
                    {t('emptyLots')}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="border-b border-gray-100 bg-gray-50/70 text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-400">
                        <tr>
                          <th className="px-3 py-2.5">{t('asset')}</th>
                          <th className="px-3 py-2.5">{t('buyDate')}</th>
                          <th className="px-3 py-2.5 text-right">{t('buyRemaining')}</th>
                          <th className="px-3 py-2.5 text-right">{t('unitCost')}</th>
                          <th className="px-3 py-2.5 text-right">{t('realizedGL')}</th>
                          <th className="px-3 py-2.5 text-center">{t('status')}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-gray-800/80">
                        {lots.map((lot) => (
                          <tr
                            key={lot.id}
                            className="transition-colors hover:bg-[#14342a]/[0.03] dark:hover:bg-emerald-950/20"
                          >
                            <td className="px-3 py-2.5 font-bold text-gray-900 dark:text-gray-100">
                              {lot.symbol}
                            </td>
                            <td className="whitespace-nowrap px-3 py-2.5 text-gray-500 tabular-nums dark:text-gray-400">
                              {formatDateShort(lot.date, locale === 'th' ? 'th-TH' : 'en-GB')}
                            </td>
                            <td className="px-3 py-2.5 text-right text-gray-600 tabular-nums dark:text-gray-300">
                              {formatQuantity(lot.buyQty)} /{' '}
                              <span className="font-bold text-gray-900 dark:text-gray-100">
                                {formatQuantity(lot.qtyRemain)}
                              </span>
                            </td>
                            <td className="px-3 py-2.5 text-right text-gray-700 tabular-nums dark:text-gray-200">
                              {formatTHB(lot.costPerUnit)}
                            </td>
                            <td
                              className={cn(
                                'px-3 py-2.5 text-right font-bold tabular-nums',
                                lot.realizedGL > 0
                                  ? 'text-[#059669] dark:text-emerald-400'
                                  : lot.realizedGL < 0
                                    ? 'text-[#DC2626] dark:text-rose-400'
                                    : 'text-gray-500'
                              )}
                            >
                              {formatSignedTHB(lot.realizedGL)}
                            </td>
                            <td className="px-3 py-2.5 text-center">
                              {/* Pastel Status Badges: Sold / Partial / Hold */}
                              <span
                                className={cn(
                                  'inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold',
                                  lot.status === 'Sold'
                                    ? 'bg-green-100 text-green-800 dark:bg-emerald-950/70 dark:text-emerald-300'
                                    : lot.status === 'Partial'
                                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300'
                                      : 'bg-emerald-50 text-[#14342a] dark:bg-teal-950/70 dark:text-teal-300'
                                )}
                              >
                                {lot.status === 'Sold' ? t('statusSold') : lot.status === 'Partial' ? t('statusPartial') : t('statusHold')}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="stats">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-gray-100 bg-gray-50/80 p-4 dark:border-gray-800 dark:bg-[#121212]">
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {t('totalCostSold')}
                    </p>
                    <p className="mt-1 text-lg font-bold text-gray-900 tabular-nums dark:text-gray-100">
                      {formatTHB(summary?.totalCostSold ?? 0)}
                    </p>
                  </div>
                  <div className="rounded-xl border border-gray-100 bg-gray-50/80 p-4 dark:border-gray-800 dark:bg-[#121212]">
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {t('totalProceeds')}
                    </p>
                    <p className="mt-1 text-lg font-bold text-gray-900 tabular-nums dark:text-gray-100">
                      {formatTHB(summary?.totalProceeds ?? 0)}
                    </p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Full Transaction Ledger */}
        <TransactionTable transactions={transactions} />
      </div>
    </ErrorBoundary>
  );
}
