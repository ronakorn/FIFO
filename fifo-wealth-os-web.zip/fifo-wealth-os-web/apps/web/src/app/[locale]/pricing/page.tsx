'use client';

import React from 'react';
import Decimal from 'decimal.js';
import {
  ArrowRight,
  BadgeCheck,
  Check,
  CircleDollarSign,
  Clock3,
  LoaderCircle,
  LockKeyhole,
  Sparkles,
  X,
} from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Link, useRouter } from '@/navigation';
import type { BillingInterval, BillingTier, BillingTierPricing } from '@/types/billing';
import {
  useBillingPricing,
  useClaimEarlyBird,
  useEarlyBirdStatus,
  useReserveProTrial,
} from '@/lib/billingQueries';
import { useAuthStore } from '@/lib/stores';
import { extractApiErrorMessage } from '@/lib/utils';

const DisplayDecimal = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });
const SALES_EMAIL = process.env.NEXT_PUBLIC_SALES_EMAIL ?? 'sales@fifo-wealth-os.com';

type FeatureKey =
  | 'maxPortfolios'
  | 'maxTransactionsPerYear'
  | 'csvUpload'
  | 'basicNetWorth'
  | 'taxReportPDF'
  | 'advancedAnalytics'
  | 'firePlanner'
  | 'aiAssistant'
  | 'familyWealth'
  | 'auditTrail'
  | 'prioritySupport'
  | 'maxFamilyMembers'
  | 'whiteLabel'
  | 'clientManagement'
  | 'maxClients';

const PLAN_ORDER: BillingTier[] = ['FREE', 'PRO', 'FAMILY', 'ADVISOR'];
const FEATURE_ORDER: { key: FeatureKey; translation: string; kind: 'boolean' | 'limit' }[] = [
  { key: 'maxPortfolios', translation: 'featurePortfolios', kind: 'limit' },
  { key: 'maxTransactionsPerYear', translation: 'featureTransactions', kind: 'limit' },
  { key: 'csvUpload', translation: 'featureCsv', kind: 'boolean' },
  { key: 'basicNetWorth', translation: 'featureBasicNetWorth', kind: 'boolean' },
  { key: 'taxReportPDF', translation: 'featureTaxPdf', kind: 'boolean' },
  { key: 'advancedAnalytics', translation: 'featureAnalytics', kind: 'boolean' },
  { key: 'firePlanner', translation: 'featureFire', kind: 'boolean' },
  { key: 'aiAssistant', translation: 'featureAi', kind: 'boolean' },
  { key: 'familyWealth', translation: 'featureFamily', kind: 'boolean' },
  { key: 'auditTrail', translation: 'featureAudit', kind: 'boolean' },
  { key: 'prioritySupport', translation: 'featurePriority', kind: 'boolean' },
  { key: 'maxFamilyMembers', translation: 'featureFamilyMembers', kind: 'limit' },
  { key: 'whiteLabel', translation: 'featureWhiteLabel', kind: 'boolean' },
  { key: 'clientManagement', translation: 'featureClientManagement', kind: 'boolean' },
  { key: 'maxClients', translation: 'featureMaxClients', kind: 'limit' },
];

const PLAN_COPY: Record<BillingTier, { name: string; audience: string }> = {
  FREE: { name: 'freeName', audience: 'freeAudience' },
  PRO: { name: 'proName', audience: 'proAudience' },
  FAMILY: { name: 'familyName', audience: 'familyAudience' },
  ADVISOR: { name: 'advisorName', audience: 'advisorAudience' },
};

function formatTHB(value?: string): string {
  if (value === undefined) return '—';
  try {
    const fixed = new DisplayDecimal(value).toFixed(2);
    const [whole = '0', fraction = '00'] = fixed.split('.');
    const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return fraction === '00' ? `฿${grouped}` : `฿${grouped}.${fraction}`;
  } catch {
    return '—';
  }
}

function planLimitLabel(t: ReturnType<typeof useTranslations>, key: FeatureKey, value: number): string {
  if (value === -1) return t('unlimited');
  if (key === 'maxPortfolios') return t('portfolioCount', { count: value });
  if (key === 'maxTransactionsPerYear') return t('transactionCount', { count: value });
  if (key === 'maxFamilyMembers') return t('memberCount', { count: value });
  if (key === 'maxClients') return t('clientCount', { count: value });
  return String(value);
}

export default function PricingPage() {
  const t = useTranslations('pricing');
  const router = useRouter();
  const token = useAuthStore((state) => state.token);
  const pricingQuery = useBillingPricing();
  const earlyBirdStatus = useEarlyBirdStatus(Boolean(token));
  const claimEarlyBird = useClaimEarlyBird();
  const reserveTrial = useReserveProTrial();
  const [billingInterval, setBillingInterval] = React.useState<BillingInterval>('month');
  const [notice, setNotice] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  const pricing = pricingQuery.data?.pricing;
  const earlyBird = pricing?.earlyBird;
  const claimState = earlyBirdStatus.data?.earlyBird;
  const donorTrial = earlyBirdStatus.data?.trial;
  const hasClaimedEarlyBird = claimState?.claimed ?? earlyBird?.claimed ?? false;
  const earlyBirdCanceled = claimState?.canceled ?? earlyBird?.canceled ?? false;
  const earlyBirdActive = claimState?.discountActive ?? earlyBird?.discountActive ?? earlyBird?.eligible ?? false;
  const trialReserved = donorTrial?.reserved ?? false;

  const tierPrices = React.useMemo(() => {
    const byTier = new Map<BillingTier, BillingTierPricing>();
    for (const plan of pricing?.tiers ?? []) byTier.set(plan.tier, plan);
    return byTier;
  }, [pricing?.tiers]);

  const claim = async () => {
    setError(null);
    setNotice(null);
    if (!token) {
      router.push('/login');
      return;
    }
    try {
      await claimEarlyBird.mutateAsync();
      setNotice(t('claimSuccess'));
    } catch (claimError) {
      setError(extractApiErrorMessage(claimError, t('claimError')));
    }
  };

  const startTrial = async () => {
    setError(null);
    setNotice(null);
    if (!token) {
      router.push('/login');
      return;
    }
    try {
      await reserveTrial.mutateAsync();
      setNotice(t('trialSuccess'));
    } catch (trialError) {
      setError(extractApiErrorMessage(trialError, t('trialError')));
    }
  };

  return (
    <div className="mx-auto max-w-6xl space-y-7" data-testid="pricing-page">
      <header className="max-w-3xl">
        <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-[#059669]">{t('eyebrow')}</p>
        <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-gray-900 dark:text-gray-100 sm:text-4xl" data-testid="pricing-title">
          {t('title')}
        </h1>
        <p className="mt-3 text-sm leading-7 text-gray-500 dark:text-gray-400">{t('subtitle')}</p>
      </header>

      {pricingQuery.isError && (
        <div role="alert" className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
          {t('loadError')}
        </div>
      )}

      {earlyBird && (earlyBird.eligible || hasClaimedEarlyBird || earlyBirdCanceled) && (
        <section
          className={`rounded-2xl border px-5 py-4 shadow-sm sm:flex sm:items-center sm:justify-between sm:gap-6 ${earlyBirdCanceled ? 'border-gray-200 bg-gray-50 dark:border-gray-800 dark:bg-[#1E1E1E]' : 'border-emerald-200 bg-emerald-50/80 dark:border-emerald-900/60 dark:bg-emerald-950/30'}`}
          data-testid="early-bird-banner"
          aria-label={t('earlyBirdLabel')}
        >
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#14342a] text-emerald-100">
              <Sparkles className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-extrabold text-[#14342a] dark:text-emerald-200">{t('earlyBirdLabel')}</p>
              <p className="mt-1 max-w-3xl text-xs leading-5 text-gray-700 dark:text-gray-300">
                {earlyBirdCanceled ? t('earlyBirdCanceled') : t('earlyBirdDescription')}
              </p>
            </div>
          </div>
          {!earlyBirdCanceled && (
            <div className="mt-4 shrink-0 sm:mt-0">
              {hasClaimedEarlyBird ? (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300 bg-white px-3 py-2 text-[11px] font-bold text-[#14342a] dark:border-emerald-800 dark:bg-[#121212] dark:text-emerald-200" data-testid="early-bird-claimed">
                  <BadgeCheck className="h-4 w-4" /> {t('earlyBirdClaimed')}
                </span>
              ) : (
                <button
                  type="button"
                  onClick={claim}
                  disabled={claimEarlyBird.isPending || !earlyBird.canClaim}
                  data-testid="claim-early-bird"
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#14342a] px-4 py-2.5 text-xs font-bold text-white transition hover:bg-[#0f261e] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {claimEarlyBird.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <BadgeCheck className="h-4 w-4" />}
                  {token ? t('claimEarlyBird') : t('signInToClaim')}
                </button>
              )}
            </div>
          )}
        </section>
      )}

      <section className="space-y-4" aria-label={t('featureHeading')} data-testid="pricing-tiers">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-gray-400">{t('featureHeading')}</p>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{t('chargesDisabled')}</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex rounded-xl border border-gray-200 bg-white p-1 shadow-sm dark:border-gray-700 dark:bg-[#1E1E1E]" role="group" aria-label={t('yearly')} data-testid="pricing-interval-toggle">
              {(['month', 'year'] as const).map((interval) => (
                <button
                  key={interval}
                  type="button"
                  aria-pressed={billingInterval === interval}
                  data-testid={`pricing-interval-${interval}`}
                  onClick={() => setBillingInterval(interval)}
                  className={`rounded-lg px-3.5 py-2 text-[11px] font-bold transition ${billingInterval === interval ? 'bg-[#14342a] text-white' : 'text-gray-500 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white'}`}
                >
                  {t(interval === 'month' ? 'monthly' : 'yearly')}
                </button>
              ))}
            </div>
            {billingInterval === 'year' && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-2 text-[10px] font-extrabold text-[#059669] dark:bg-emerald-950/50 dark:text-emerald-300" data-testid="yearly-savings-badge">
                <CircleDollarSign className="h-3.5 w-3.5" />
                {t('yearlySavings', { percent: '20' })}
              </span>
            )}
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {PLAN_ORDER.map((tier) => {
            const plan = tierPrices.get(tier);
            const copy = PLAN_COPY[tier];
            const basePrice = billingInterval === 'month' ? plan?.monthlyPriceTHB : plan?.yearlyPriceTHB;
            const earlyBirdPrice = billingInterval === 'month' ? plan?.earlyBirdMonthlyPriceTHB : plan?.earlyBirdYearlyPriceTHB;
            const hasDiscount = Boolean(
              tier !== 'FREE' && earlyBirdActive && basePrice !== undefined && earlyBirdPrice !== undefined && earlyBirdPrice !== basePrice
            );
            const displayedPrice = hasDiscount ? earlyBirdPrice : basePrice;
            const included = FEATURE_ORDER.filter(({ key, kind }) => {
              const value = plan?.features[key];
              return kind === 'boolean' ? value === true : typeof value === 'number' && (value === -1 || value > 0);
            });
            const highlighted = tier === 'PRO';

            return (
              <article
                key={tier}
                data-testid={`pricing-tier-${tier.toLowerCase()}`}
                className={`relative flex flex-col overflow-hidden rounded-2xl border p-5 shadow-sm transition ${highlighted ? 'border-[#14342a] bg-[#14342a] text-white shadow-lg shadow-[#14342a]/10 ring-1 ring-[#14342a]' : 'border-gray-200/80 bg-white text-gray-900 dark:border-gray-800 dark:bg-[#1E1E1E] dark:text-gray-100'}`}
              >
                {highlighted && (
                  <span className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-full bg-emerald-300 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-wide text-[#14342a]" data-testid="pro-recommended-badge">
                    <Sparkles className="h-3 w-3" /> {t('recommended')}
                  </span>
                )}
                <div className="flex items-start justify-between gap-3 pr-16">
                  <div>
                    <h2 className="text-xs font-extrabold uppercase tracking-[0.16em]">{t(copy.name)}</h2>
                    <p className={`mt-1.5 text-[11px] leading-5 ${highlighted ? 'text-emerald-100/80' : 'text-gray-500 dark:text-gray-400'}`}>
                      {t(copy.audience)}
                    </p>
                  </div>
                </div>

                <div className="mt-5 flex items-end gap-2">
                  <span className="text-3xl font-extrabold tracking-tight tabular-nums" data-testid={`pricing-amount-${tier.toLowerCase()}`}>
                    {formatTHB(displayedPrice)}
                  </span>
                  {hasDiscount && (
                    <del className={`pb-1 text-xs ${highlighted ? 'text-emerald-100/60' : 'text-gray-400'}`} data-testid={`pricing-base-${tier.toLowerCase()}`}>
                      {formatTHB(basePrice)}
                    </del>
                  )}
                </div>
                <p className={`mt-1 text-[10px] ${highlighted ? 'text-emerald-100/70' : 'text-gray-500 dark:text-gray-400'}`}>
                  {t(billingInterval === 'month' ? 'perMonth' : 'perYear')}
                  {billingInterval === 'year' && plan && Number(plan.yearlySavingsPercentage) > 0
                    ? ` · ${t('yearlySavings', { percent: String(Number(plan.yearlySavingsPercentage)) })}`
                    : ''}
                </p>

                <div className="mt-5 border-t border-current/10 pt-4">
                  <p className={`text-[9px] font-extrabold uppercase tracking-[0.14em] ${highlighted ? 'text-emerald-100/70' : 'text-gray-400'}`}>
                    {t('featureHeading')}
                  </p>
                  <ul className="mt-3 space-y-2.5">
                    {included.map(({ key, translation, kind }) => {
                      const value = plan?.features[key];
                      const detail = kind === 'limit' && typeof value === 'number'
                        ? `: ${planLimitLabel(t, key, value)}`
                        : '';
                      return (
                        <li key={key} className={`flex items-start gap-2 text-[10px] leading-4 ${highlighted ? 'text-emerald-50' : 'text-gray-600 dark:text-gray-300'}`}>
                          <Check className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${highlighted ? 'text-emerald-300' : 'text-[#059669] dark:text-emerald-400'}`} />
                          <span>{t(translation)}{detail}</span>
                        </li>
                      );
                    })}
                    {FEATURE_ORDER.filter(({ key, kind }) => kind === 'boolean' && plan?.features[key] !== true).length > 0 && tier === 'FREE' && (
                      <li className="flex items-start gap-2 border-t border-current/10 pt-2 text-[10px] leading-4 text-gray-400 dark:text-gray-500">
                        <X className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                        <span>{t('none')}: {t('featureTaxPdf')}, {t('featureAnalytics')}, {t('featureFire')}, {t('featureAi')}</span>
                      </li>
                    )}
                  </ul>
                </div>

                <div className="mt-auto pt-6">
                  {tier === 'PRO' ? (
                    <button
                      type="button"
                      onClick={startTrial}
                      disabled={trialReserved || reserveTrial.isPending}
                      data-testid="start-pro-trial"
                      className={`inline-flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-xs font-extrabold transition ${trialReserved ? 'cursor-default border border-white/20 bg-white/10 text-emerald-50' : 'bg-white text-[#14342a] hover:bg-emerald-50 disabled:cursor-wait disabled:opacity-70'}`}
                    >
                      {reserveTrial.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : trialReserved ? <BadgeCheck className="h-4 w-4" /> : <ArrowRight className="h-4 w-4" />}
                      {trialReserved ? t('trialReserved') : t('startTrial')}
                    </button>
                  ) : tier === 'ADVISOR' ? (
                    <a
                      href={`mailto:${SALES_EMAIL}?subject=FIFO%20Wealth%20OS%20Advisor%20plan`}
                      title={t('salesNote')}
                      data-testid="contact-sales"
                      className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-xs font-extrabold text-[#14342a] transition hover:bg-emerald-50 dark:border-gray-700 dark:bg-gray-800 dark:text-emerald-200 dark:hover:bg-gray-700"
                    >
                      {t('contactSales')} <ArrowRight className="h-4 w-4" />
                    </a>
                  ) : tier === 'FREE' ? (
                    <span className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-extrabold text-[#14342a] dark:border-emerald-900/60 dark:bg-emerald-950/40 dark:text-emerald-200">
                      <BadgeCheck className="h-4 w-4" /> {pricingQuery.data?.openBeta ? t('currentPlan') : t('freeName')}
                    </span>
                  ) : (
                    <span className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-[10px] font-bold text-gray-500 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300" title={t('chargesDisabled')}>
                      <LockKeyhole className="h-3.5 w-3.5" /> {t('unavailable')}
                    </span>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {trialReserved && (
        <div className="flex items-start gap-2.5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs text-emerald-950 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-100" role="status" data-testid="trial-reserved-note">
          <Clock3 className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{t('trialNote')}</span>
        </div>
      )}
      {!trialReserved && (
        <p className="flex items-start gap-2.5 rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-xs leading-5 text-gray-600 dark:border-gray-800 dark:bg-[#121212] dark:text-gray-300" data-testid="trial-start-note">
          <Clock3 className="mt-0.5 h-4 w-4 shrink-0 text-[#059669]" />
          <span>{t('trialNote')}</span>
        </p>
      )}

      {notice && <div role="status" className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-100">{notice}</div>}
      {error && <div role="alert" className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs font-semibold text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-100">{error}</div>}

      <footer className="flex flex-col gap-3 rounded-2xl border border-emerald-900/10 bg-[#14342a]/[0.04] p-4 sm:flex-row sm:items-center sm:justify-between dark:border-emerald-900/40 dark:bg-emerald-950/20">
        <p className="max-w-3xl text-xs leading-5 text-gray-600 dark:text-gray-300">{t('chargesDisabled')}</p>
        <Link href="/settings/billing" className="inline-flex shrink-0 items-center gap-1.5 text-xs font-bold text-[#14342a] hover:underline dark:text-[#4ade80]">
          {t('currentPlan')} <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </footer>
    </div>
  );
}
