'use client';

import { useTranslations } from 'next-intl';
import React from 'react';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { AuditLogsWorkspace } from '@/components/audit/AuditLogsWorkspace';

export default function AdminAuditLogsPage() {
  const t = useTranslations('appMessages');
  return (
    <ErrorBoundary fallbackTitle={t('auditPageError')}>
      <AuditLogsWorkspace />
    </ErrorBoundary>
  );
}
