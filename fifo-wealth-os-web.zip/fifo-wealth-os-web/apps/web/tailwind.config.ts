import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#14342a',
          hover: '#1b4538',
          soft: '#edf5f2',
          darkAccent: '#4ade80',
        },
        success: '#059669',
        danger: '#DC2626',
        bg: {
          light: '#FAFAFA',
          dark: '#121212',
        },
        surface: {
          light: '#FFFFFF',
          dark: '#1E1E1E',
        },
      },
      fontFamily: {
        sans: ['var(--font-plus-jakarta)', 'var(--font-sarabun)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-plus-jakarta)', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      borderRadius: {
        card: '1rem',
        button: '0.75rem',
      },
      boxShadow: {
        premium: '0 1px 3px 0 rgba(17, 24, 39, 0.04), 0 4px 16px -4px rgba(20, 52, 42, 0.06)',
      },
    },
  },
  plugins: [],
};

export default config;
