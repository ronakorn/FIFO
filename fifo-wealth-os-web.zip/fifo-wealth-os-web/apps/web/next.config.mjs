import path from 'node:path';
import { fileURLToPath } from 'node:url';
import createNextIntlPlugin from 'next-intl/plugin';

const withNextIntl = createNextIntlPlugin('./src/i18n.ts');
const appDirectory = path.dirname(fileURLToPath(import.meta.url));
const workspaceRoot = path.resolve(appDirectory, '../..');

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  allowedDevOrigins: ['*.e2b.app', 'localhost:3001', '127.0.0.1:3001'],
  outputFileTracingRoot: workspaceRoot,
  transpilePackages: ['@fifo/api', '@fifo/types', '@fifo/utils'],
  async rewrites() {
    const backendOrigin = process.env.BACKEND_ORIGIN || 'http://127.0.0.1:3000';
    return [
      {
        source: '/api/:path*',
        destination: `${backendOrigin}/api/:path*`,
      },
      {
        source: '/api-docs/:path*',
        destination: `${backendOrigin}/api-docs/:path*`,
      },
    ];
  },
};

export default withNextIntl(nextConfig);
