import {
  buildRolloverHistory,
  calculateDaysToExpiry,
  calculateRolloverSpreadAnalytics,
  classifyExpirySeverity,
  scanExpiringFuturesContracts,
} from './contractRolloverEngine';
import { GoldTransaction } from '../types/gold';
import { DerivativesContractExtensionDTO } from '../types/rollover';

describe('Contract Rollover Manager — Quantitative & Expiry Alert Engine Tests (Decimal.js precision: 40)', () => {
  describe('1. Expiry Tracking & Proactive Alert Engine (7d / 3d / 1d / Expired)', () => {
    it('calculates exact UTC calendar days to expiry without timezone drift and triggers audio alerts <= 7d', () => {
      expect(calculateDaysToExpiry('2026-10-27', '2026-10-26')).toBe(1);
      expect(classifyExpirySeverity(1)).toEqual({
        severity: 'CRITICAL_1D',
        shouldPlayAudioAlert: true,
      });

      expect(calculateDaysToExpiry('2026-10-29', '2026-10-26')).toBe(3);
      expect(classifyExpirySeverity(3)).toEqual({
        severity: 'URGENT_3D',
        shouldPlayAudioAlert: true,
      });

      expect(calculateDaysToExpiry('2026-11-02', '2026-10-26')).toBe(7);
      expect(classifyExpirySeverity(7)).toEqual({
        severity: 'WARNING_7D',
        shouldPlayAudioAlert: true,
      });

      expect(calculateDaysToExpiry('2026-12-29', '2026-10-26')).toBe(64);
      expect(classifyExpirySeverity(64)).toEqual({
        severity: 'SAFE',
        shouldPlayAudioAlert: false,
      });

      expect(calculateDaysToExpiry('2026-10-20', '2026-10-26')).toBe(-6);
      expect(classifyExpirySeverity(-6)).toEqual({
        severity: 'EXPIRED',
        shouldPlayAudioAlert: true,
      });
    });

    it('scans open GOLD_ONLINE_FUTURES lots, ranks most urgent first, and suggests next series rollover contract', () => {
      const createdAt = new Date('2026-10-01T00:00:00Z');
      const txs: GoldTransaction[] = [
        {
          id: 'tx-goz26',
          portfolioId: 'p1',
          date: '2026-09-10',
          symbol: 'GOZ26',
          assetSubclass: 'GOLD_ONLINE_FUTURES',
          weight: '2.0000',
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          spotPricePerUnit: '2600.00',
          premiumPerUnit: '0.00',
          commission: '4.00',
          totalCost: '5204.00',
          fxRateAtPurchase: '34.50',
          type: 'BUY',
          createdAt,
        },
        {
          id: 'tx-gov26',
          portfolioId: 'p1',
          date: '2026-09-25',
          symbol: 'GOV26',
          assetSubclass: 'GOLD_ONLINE_FUTURES',
          weight: '3.0000',
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          spotPricePerUnit: '2620.00',
          premiumPerUnit: '0.00',
          commission: '4.50',
          totalCost: '7864.50',
          fxRateAtPurchase: '34.80',
          type: 'BUY',
          createdAt,
        },
      ];

      const alerts = scanExpiringFuturesContracts({
        transactions: txs,
        extensionsByTxId: new Map(),
        asOfDate: '2026-10-26',
        xauUsdSpot: '2740.00',
        usdThbRate: '35.60',
        gtaGold965SellTHB: '46450.00',
      });

      expect(alerts).toHaveLength(2);
      // GOV26 expires 2026-10-29 (3 days) -> sorted before GOZ26 (64 days)
      expect(alerts[0]!.symbol).toBe('GOV26');
      expect(alerts[0]!.daysToExpiry).toBe(3);
      expect(alerts[0]!.severity).toBe('URGENT_3D');
      expect(alerts[0]!.shouldPlayAudioAlert).toBe(true);
      expect(alerts[0]!.suggestedBackSymbol).toBe('GOZ26');

      expect(alerts[1]!.symbol).toBe('GOZ26');
      expect(alerts[1]!.severity).toBe('SAFE');
      expect(alerts[1]!.suggestedBackSymbol).toBe('GOH27');
    });
  });

  describe('2. Rollover Spread Cost Analytics (Contango vs Backwardation & Exact FIFO Realized PnL)', () => {
    const createdAt = new Date('2026-09-25T00:00:00Z');
    const baseTx: GoldTransaction = {
      id: 'open-gov26',
      portfolioId: 'p1',
      date: '2026-09-25',
      symbol: 'GOV26',
      assetSubclass: 'GOLD_ONLINE_FUTURES',
      weight: '3.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.5',
      spotPricePerUnit: '2600.00',
      premiumPerUnit: '0.00',
      commission: '0.00',
      totalCost: '7800.00', // 7800 USD * 34.00 = 265,200.00 THB
      fxRateAtPurchase: '34.00',
      type: 'BUY',
      createdAt,
    };

    it('calculates CONTANGO spread cost, exact Close Leg FIFO Realized G/L, and Back-Month Cost Basis', () => {
      const contango = calculateRolloverSpreadAnalytics({
        existingTransactions: [baseTx],
        portfolioId: 'p1',
        date: '2026-10-26',
        frontSymbol: 'GOV26',
        backSymbol: 'GOZ26',
        weight: '3.0000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        frontClosePriceUSD: '2740.00', // Close proceeds = (3 * 2740 - 5) * 35.00 = 287,525.00 THB
        backOpenPriceUSD: '2758.00', // +18.00 USD/oz Contango
        closeCommissionUSD: '5.00',
        openCommissionUSD: '5.00',
        fxRateUSDTHB: '35.00',
      });

      expect(contango.regime).toBe('CONTANGO');
      expect(contango.spreadPerUnitUSD).toBe('18.00');
      expect(contango.totalSpreadCostUSD).toBe('54.00');
      // 54 USD * 35.00 = 1,890.00 THB Contango drag
      expect(contango.totalSpreadCostTHB).toBe('1890.00');
      // Commissions: (5 + 5) * 35.00 = 350.00 THB => Net friction = 2,240.00 THB
      expect(contango.totalCommissionTHB).toBe('350.00');
      expect(contango.netRolloverFrictionTHB).toBe('2240.00');

      // Realized G/L on GOV26: 287,525.00 - 265,200.00 = +22,325.00 THB
      expect(contango.estimatedCloseRealizedGLTHB).toBe('22325.00');
      // New GOZ26 Cost Basis: ((3 * 2758) + 5) * 35.00 = 8279 * 35 = 289,765.00 THB
      expect(contango.newBackContractCostBasisTHB).toBe('289765.00');
    });

    it('detects BACKWARDATION (negative spread = positive roll yield) accurately', () => {
      const backwardation = calculateRolloverSpreadAnalytics({
        existingTransactions: [baseTx],
        portfolioId: 'p1',
        date: '2026-10-26',
        frontSymbol: 'GOV26',
        backSymbol: 'GOZ26',
        weight: '3.0000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        frontClosePriceUSD: '2750.00',
        backOpenPriceUSD: '2738.00', // -12.00 USD/oz Backwardation
        closeCommissionUSD: '0.00',
        openCommissionUSD: '0.00',
        fxRateUSDTHB: '35.00',
      });

      expect(backwardation.regime).toBe('BACKWARDATION');
      expect(backwardation.spreadPerUnitUSD).toBe('-12.00');
      expect(backwardation.totalSpreadCostTHB).toBe('-1260.00');
    });

    it('reconstructs linked RolloverHistoryItem pairs from rolloverGroupId', () => {
      const txs: GoldTransaction[] = [
        baseTx,
        {
          id: 'close-gov26',
          portfolioId: 'p1',
          date: '2026-10-26',
          symbol: 'GOV26',
          assetSubclass: 'GOLD_ONLINE_FUTURES',
          weight: '3.0000',
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          spotPricePerUnit: '2740.00',
          premiumPerUnit: '0.00',
          commission: '5.00',
          totalCost: '8215.00',
          fxRateAtPurchase: '35.00',
          type: 'SELL',
          createdAt,
        },
        {
          id: 'open-goz26',
          portfolioId: 'p1',
          date: '2026-10-26',
          symbol: 'GOZ26',
          assetSubclass: 'GOLD_ONLINE_FUTURES',
          weight: '3.0000',
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          spotPricePerUnit: '2758.00',
          premiumPerUnit: '0.00',
          commission: '5.00',
          totalCost: '8279.00',
          fxRateAtPurchase: '35.00',
          type: 'BUY',
          createdAt,
        },
      ];

      const extMap = new Map<string, DerivativesContractExtensionDTO>([
        [
          'close-gov26',
          {
            id: 'e1',
            transactionId: 'close-gov26',
            contractMonth: 'V26',
            expirationDate: '2026-10-29',
            legAction: 'CLOSE_LONG',
            isRollover: true,
            rolloverGroupId: 'rg-001',
            rolloverSpread: '18.00',
          },
        ],
        [
          'open-goz26',
          {
            id: 'e2',
            transactionId: 'open-goz26',
            contractMonth: 'Z26',
            expirationDate: '2026-12-29',
            legAction: 'OPEN_LONG',
            isRollover: true,
            rolloverGroupId: 'rg-001',
            rolloverSpread: '18.00',
          },
        ],
      ]);

      const history = buildRolloverHistory({
        transactions: txs,
        extensionsByTxId: extMap,
        xauUsdSpot: '2760.00',
        usdThbRate: '35.00',
        gtaGold965SellTHB: '46450.00',
      });

      expect(history).toHaveLength(1);
      expect(history[0]!.rolloverGroupId).toBe('rg-001');
      expect(history[0]!.frontSymbol).toBe('GOV26');
      expect(history[0]!.backSymbol).toBe('GOZ26');
      expect(history[0]!.realizedGLClosedLegTHB).toBe('22325.00');
      expect(history[0]!.spreadCostTHB).toBe('1890.00');
    });
  });
});
