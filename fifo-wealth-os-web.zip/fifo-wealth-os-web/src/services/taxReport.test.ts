import fs from 'fs';
import os from 'os';
import path from 'path';
import { TaxEvent, TaxReport } from '../types';
import { generateTaxReportPDF } from './taxReportGenerator';

describe('FIFO Wealth OS - Phase 4 PDF Tax Report Generator', () => {
  let tmpDir: string;

  beforeEach(async () => {
    tmpDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'fifo-wealth-os-pdf-'));
  });

  afterEach(async () => {
    await fs.promises.rm(tmpDir, { recursive: true, force: true });
  });

  it('generates a valid 5-page Thai Tax Compliance PDF from Excel Baseline TaxReport', async () => {
    const baselineReport: TaxReport = {
      taxYear: 2024,
      capitalGains: [
        {
          id: 'TAX-CG-LOT-1',
          type: 'CAPITAL_GAIN',
          date: '2024-10-01',
          symbol: 'A',
          amountTHB: '8.57',
          taxableIncome: '8.57',
          taxWithheld: '0.00',
          netTaxPayable: '0.00',
        },
        {
          id: 'TAX-CG-LOT-7',
          type: 'CAPITAL_GAIN',
          date: '2024-10-07',
          symbol: 'A',
          amountTHB: '8.22',
          taxableIncome: '8.22',
          taxWithheld: '0.00',
          netTaxPayable: '0.00',
        },
        {
          id: 'TAX-CG-LOT-9',
          type: 'CAPITAL_GAIN',
          date: '2024-10-09',
          symbol: 'A',
          amountTHB: '8.22',
          taxableIncome: '8.22',
          taxWithheld: '0.00',
          netTaxPayable: '0.00',
        },
      ],
      dividends: [
        {
          id: 'TAX-DIV-1',
          type: 'DIVIDEND',
          date: '2024-10-15T00:00:00.000Z',
          symbol: 'A',
          amountTHB: '2.13',
          taxableIncome: '3.06',
          taxWithheld: '0.93',
          netTaxPayable: '-0.93',
        },
      ],
      totalTaxableIncome: '28.07',
      totalTaxWithheld: '0.93',
      totalTaxPayable: '-0.93',
      generatedAt: '2024-12-31T23:59:59.000Z',
    };

    const outputPath = path.join(tmpDir, 'Thai_Tax_Report_2024.pdf');
    const result = await generateTaxReportPDF(baselineReport, outputPath, {
      taxpayerName: 'คุณสมชาย ใจดี (Somchai Jaidee)',
      taxpayerTaxId: '1-1005-00123-45-6',
    });

    expect(fs.existsSync(result.filePath)).toBe(true);
    expect(result.sizeBytes).toBeGreaterThan(5000);
    // Exact 5 pages: Cover + Summary + Capital Gains + Dividends + Filing Guide
    expect(result.pageCount).toBe(5);

    const fileBuffer = await fs.promises.readFile(result.filePath);
    expect(fileBuffer.subarray(0, 5).toString('ascii')).toBe('%PDF-');
    expect(fileBuffer.toString('latin1')).toContain('%%EOF');
  });

  it('automatically paginates when Capital Gains schedule exceeds a single page', async () => {
    const manyCapGains: TaxEvent[] = Array.from({ length: 45 }, (_, idx) => ({
      id: `TAX-CG-${idx + 1}`,
      type: 'CAPITAL_GAIN',
      date: '2024-10-15',
      symbol: 'NVDA',
      amountTHB: '1000.00',
      taxableIncome: '1000.00',
      taxWithheld: '0.00',
      netTaxPayable: '50.00',
    }));

    const largeReport: TaxReport = {
      taxYear: 2024,
      capitalGains: manyCapGains,
      dividends: [],
      totalTaxableIncome: '45000.00',
      totalTaxWithheld: '0.00',
      totalTaxPayable: '0.00',
      generatedAt: '2024-12-31T23:59:59.000Z',
    };

    const outputPath = path.join(tmpDir, 'Large_Tax_Report_2024.pdf');
    const result = await generateTaxReportPDF(largeReport, outputPath);

    expect(fs.existsSync(result.filePath)).toBe(true);
    expect(result.pageCount).toBeGreaterThanOrEqual(6);
  });
});
