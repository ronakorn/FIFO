import Decimal from 'decimal.js';
import { formatExactDecimalString } from '../parsers/csvUtils';
import { BASE_CURRENCY, Transaction } from '../types';
import { FXRateProvider } from './fxRateService';

/**
 * Isolated IEEE 754-2008 decimal128 configuration (34 significant digits)
 * ensuring zero intermediate rounding during FX conversion.
 */
const Dec = Decimal.clone({
  precision: 34,
  rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Enriches an array of Transactions with historical FX rates and exact Base Currency (`netTHB`)
 * string values without mutating input transactions.
 *
 * Rules enforced:
 * - Strict `decimal.js` string multiplication (never JS `Number * Number`).
 * - Zero Intermediate Rounding: preserves every exact decimal place in `netTHB`.
 * - If `originalCurrency === baseCurrency`, sets `fxRate = '1.00'` and `netTHB = originalNet`.
 */
export async function enrichTransactionsWithFX(
  transactions: Transaction[],
  fxProvider: FXRateProvider,
  baseCurrency: string = BASE_CURRENCY
): Promise<Transaction[]> {
  const normalizedBase = baseCurrency.trim().toUpperCase();
  if (!normalizedBase) {
    throw new Error('baseCurrency must be a non-empty currency code.');
  }

  const enriched: Transaction[] = [];

  for (const tx of transactions) {
    const normalizedOrigCurrency = tx.originalCurrency.trim().toUpperCase();
    if (!normalizedOrigCurrency) {
      throw new Error(`Missing originalCurrency on transaction ID "${tx.id}".`);
    }

    const rawOriginalNet = tx.originalNet.trim();
    if (!rawOriginalNet) {
      throw new Error(`Missing originalNet on transaction ID "${tx.id}".`);
    }

    const originalNetDec = new Dec(rawOriginalNet);
    if (!originalNetDec.isFinite() || originalNetDec.lt(0)) {
      throw new Error(
        `Invalid originalNet "${tx.originalNet}" on transaction ID "${tx.id}": must be a non-negative decimal string.`
      );
    }

    if (normalizedOrigCurrency === normalizedBase) {
      enriched.push({
        ...tx,
        originalCurrency: normalizedOrigCurrency,
        fxRate: '1.00',
        netTHB: rawOriginalNet,
      });
      continue;
    }

    const fxRate = await fxProvider.getHistoricalRate(
      normalizedOrigCurrency,
      normalizedBase,
      tx.date
    );

    const fxRateDec = new Dec(fxRate.trim());
    if (!fxRateDec.isFinite() || fxRateDec.lte(0)) {
      throw new Error(
        `Invalid FX rate "${fxRate}" returned for ${normalizedOrigCurrency}/${normalizedBase} on "${tx.date}".`
      );
    }

    // Strict Decimal multiplication ONLY — Zero Intermediate Rounding
    const netTargetDec = originalNetDec.times(fxRateDec);
    const exactNetTHB = formatExactDecimalString(netTargetDec);

    enriched.push({
      ...tx,
      originalCurrency: normalizedOrigCurrency,
      fxRate: fxRate.trim(),
      netTHB: exactNetTHB,
    });
  }

  return enriched;
}
