import { calculateFIFO } from '../fifoEngine';
import { parseBitkubCSV } from '../parsers/bitkubParser';
import { parseIBKRCsv } from '../parsers/ibkrParser';
import { BASE_CURRENCY, Transaction } from '../types';
import { MockFXRateProvider } from './fxRateService';
import { enrichTransactionsWithFX } from './transactionEnricher';

describe('FIFO Wealth OS - Phase 3 Historical FX Rate Engine & Multi-Currency Enrichment', () => {
  describe('Step 2 & 3: MockFXRateProvider & enrichTransactionsWithFX', () => {
    it('enriches USD and THB transactions accurately against hand-calculated baseline', async () => {
      const fxProvider = new MockFXRateProvider();

      const mockTransactions: Transaction[] = [
        {
          id: 'TX-AAPL-BUY',
          date: '2024-10-01',
          symbol: 'AAPL',
          qty: 10,
          price: 150.5,
          gross: 1505.0,
          comm: 1.0,
          vat: 0,
          net: 1506.0,
          type: 'BUY',
          exchange: 'IBKR',
          currency: 'USD',
          originalCurrency: 'USD',
          originalNet: '1506.00',
          fxRate: null,
          netTHB: null,
        },
        {
          id: 'TX-BTC-BUY',
          date: '2024-10-02',
          symbol: 'BTC',
          qty: 0.001,
          price: 2000000,
          gross: 2000.0,
          comm: 10.0,
          vat: 0,
          net: 2010.0,
          type: 'BUY',
          exchange: 'BITKUB',
          currency: 'THB',
          originalCurrency: 'THB',
          originalNet: '2010.00',
          fxRate: null,
          netTHB: null,
        },
      ];

      const enriched = await enrichTransactionsWithFX(
        mockTransactions,
        fxProvider,
        BASE_CURRENCY
      );

      expect(enriched).toHaveLength(2);

      // Transaction 1: 1506.00 USD * 36.75 THB/USD = 55345.50 THB
      expect(enriched[0]!.fxRate).toBe('36.75');
      expect(enriched[0]!.netTHB).toBe('55345.50');

      // Transaction 2: THB base currency => fxRate = '1.00', netTHB = '2010.00'
      expect(enriched[1]!.fxRate).toBe('1.00');
      expect(enriched[1]!.netTHB).toBe('2010.00');

      // Ensure input array and objects were not mutated
      expect(mockTransactions[0]!.fxRate).toBeNull();
      expect(mockTransactions[0]!.netTHB).toBeNull();
    });

    it('returns "1.00" when querying THB/THB directly on MockFXRateProvider', async () => {
      const fxProvider = new MockFXRateProvider();
      await expect(fxProvider.getHistoricalRate('THB', 'THB', '2024-10-01')).resolves.toBe(
        '1.00'
      );
      await expect(fxProvider.getHistoricalRate('USD', 'THB', '2024-10-02')).resolves.toBe(
        '36.80'
      );
      await expect(fxProvider.getHistoricalRate('USD', 'THB', '2024-10-09')).resolves.toBe(
        '36.50'
      );
    });

    it('enforces Strict Decimal multiplication & Zero Intermediate Rounding (no IEEE-754 drift)', async () => {
      // Note: In raw JS Number * Number: 19.99 * 36.751 === 734.6524899999999 (corrupted by IEEE-754!)
      // Hand calculation: (20 - 0.01) * 36.751 = 735.02 - 0.36751 = 734.65249 (exact 5 decimals)
      // Also: 123.4567 * 36.7513 = 4537.19421871 (exact 8 decimals preserved without rounding)
      const customProvider = new MockFXRateProvider({
        '2024-10-01': {
          'USD/THB': '36.751',
        },
        '2024-10-02': {
          'USD/THB': '36.7513',
        },
      });

      const txs: Transaction[] = [
        {
          id: 'TX-FLOAT-TRAP',
          date: '2024-10-01',
          symbol: 'NVDA',
          qty: 1,
          price: 19.99,
          gross: 19.99,
          comm: 0,
          vat: 0,
          net: 19.99,
          type: 'BUY',
          exchange: 'IBKR',
          originalCurrency: 'USD',
          originalNet: '19.99',
          fxRate: null,
          netTHB: null,
        },
        {
          id: 'TX-EXACT-8DP',
          date: '2024-10-02',
          symbol: 'NVDA',
          qty: 1,
          price: 123.4567,
          gross: 123.4567,
          comm: 0,
          vat: 0,
          net: 123.4567,
          type: 'BUY',
          exchange: 'IBKR',
          originalCurrency: 'USD',
          originalNet: '123.4567',
          fxRate: null,
          netTHB: null,
        },
      ];

      const enriched = await enrichTransactionsWithFX(txs, customProvider, 'THB');
      expect(enriched[0]!.fxRate).toBe('36.751');
      expect(enriched[0]!.netTHB).toBe('734.65249');

      expect(enriched[1]!.fxRate).toBe('36.7513');
      expect(enriched[1]!.netTHB).toBe('4537.19421871');
    });

    it('throws descriptive error if historical FX rate is missing for a date/pair', async () => {
      const fxProvider = new MockFXRateProvider();
      const tx: Transaction = {
        id: 'TX-MISSING-FX',
        date: '2020-01-01',
        symbol: 'AAPL',
        qty: 1,
        price: 100,
        gross: 100,
        comm: 0,
        vat: 0,
        net: 100,
        type: 'BUY',
        exchange: 'IBKR',
        originalCurrency: 'USD',
        originalNet: '100.00',
        fxRate: null,
        netTHB: null,
      };

      await expect(enrichTransactionsWithFX([tx], fxProvider, 'THB')).rejects.toThrow(
        /Historical FX rate not found/
      );
    });
  });

  describe('Step 4: End-to-End Multi-Currency THB FIFO & Thai Revenue Dept Rounding', () => {
    it('aggregates USD (AAPL) and THB (BTC) trades into unified THB Realized & Unrealized G/L', async () => {
      const fxProvider = new MockFXRateProvider();

      const rawTransactions: Transaction[] = [
        // 1. BUY 10 AAPL on 2024-10-01: 1506.00 USD * 36.75 = 55,345.50 THB (cost/unit = 5,534.55 THB)
        {
          id: 'AAPL-BUY-1',
          date: '2024-10-01',
          symbol: 'AAPL',
          qty: 10,
          price: 150.5,
          gross: 1505,
          comm: 1,
          vat: 0,
          net: 1506,
          type: 'BUY',
          exchange: 'IBKR',
          originalCurrency: 'USD',
          originalNet: '1506.00',
          fxRate: null,
          netTHB: null,
        },
        // 2. BUY 0.001 BTC on 2024-10-02: 2010.00 THB * 1.00 = 2,010.00 THB (cost/unit = 2,010,000 THB)
        {
          id: 'BTC-BUY-1',
          date: '2024-10-02',
          symbol: 'BTC',
          qty: 0.001,
          price: 2000000,
          gross: 2000,
          comm: 10,
          vat: 0,
          net: 2010,
          type: 'BUY',
          exchange: 'BITKUB',
          originalCurrency: 'THB',
          originalNet: '2010.00',
          fxRate: null,
          netTHB: null,
        },
        // 3. SELL 5 AAPL on 2024-10-09: 799.00 USD * 36.50 = 29,163.50 THB
        //    Matched 5 AAPL cost = 5 * 5,534.55 = 27,672.75 THB
        //    AAPL Realized G/L (THB) = 29,163.50 - 27,672.75 = +1,490.75 THB
        {
          id: 'AAPL-SELL-1',
          date: '2024-10-09',
          symbol: 'AAPL',
          qty: 5,
          price: 160,
          gross: 800,
          comm: 1,
          vat: 0,
          net: 799,
          type: 'SELL',
          exchange: 'IBKR',
          originalCurrency: 'USD',
          originalNet: '799.00',
          fxRate: null,
          netTHB: null,
        },
        // 4. SELL 0.0005 BTC on 2024-10-09: 1044.75 THB * 1.00 = 1,044.75 THB
        //    Matched 0.0005 BTC cost = 0.0005 * 2,010,000 = 1,005.00 THB
        //    BTC Realized G/L (THB) = 1,044.75 - 1,005.00 = +39.75 THB
        {
          id: 'BTC-SELL-1',
          date: '2024-10-09',
          symbol: 'BTC',
          qty: 0.0005,
          price: 2100000,
          gross: 1050,
          comm: 5.25,
          vat: 0,
          net: 1044.75,
          type: 'SELL',
          exchange: 'BITKUB',
          originalCurrency: 'THB',
          originalNet: '1044.75',
          fxRate: null,
          netTHB: null,
        },
      ];

      const enriched = await enrichTransactionsWithFX(
        rawTransactions,
        fxProvider,
        BASE_CURRENCY
      );

      const buys = enriched.filter((t) => t.type === 'BUY');
      const sells = enriched.filter((t) => t.type === 'SELL');

      // Current prices in THB: AAPL = 6,000 THB/share, BTC = 2,200,000 THB/BTC
      const fifoResult = calculateFIFO(buys, sells, {
        AAPL: 6000,
        BTC: 2200000,
      });

      const aaplLot = fifoResult.lots.find((l) => l.symbol === 'AAPL')!;
      const btcLot = fifoResult.lots.find((l) => l.symbol === 'BTC')!;

      expect(aaplLot).toMatchObject({
        id: 'AAPL-BUY-1',
        costPerUnit: 5534.55,
        qtySold: 5,
        qtyRemain: 5,
        realizedGL: 1490.75,
        // Unrealized G/L = (6000 - 5534.55) * 5 = 465.45 * 5 = 2327.25 THB
        unrealizedGL: 2327.25,
        status: 'Partial',
      });

      expect(btcLot).toMatchObject({
        id: 'BTC-BUY-1',
        costPerUnit: 2010000,
        qtySold: 0.0005,
        qtyRemain: 0.0005,
        realizedGL: 39.75,
        // Unrealized G/L = (2,200,000 - 2,010,000) * 0.0005 = +95.00 THB
        unrealizedGL: 95,
        status: 'Partial',
      });

      // Combined Portfolio Totals in THB:
      // Total Realized G/L   = 1,490.75 + 39.75 = 1,530.50 THB
      // Total Unrealized G/L = 2,327.25 + 95.00 = 2,422.25 THB
      // Total Cost Sold      = 27,672.75 + 1,005.00 = 28,677.75 THB
      // Total Proceeds       = 29,163.50 + 1,044.75 = 30,208.25 THB
      expect(fifoResult.totalRealizedGL).toBe(1530.5);
      expect(fifoResult.totalUnrealizedGL).toBe(2422.25);
      expect(fifoResult.totalCostSold).toBe(28677.75);
      expect(fifoResult.totalProceeds).toBe(30208.25);
    });

    it('applies Final Tax Rounding (2 decimal places, ROUND_HALF_UP) only at output boundary', async () => {
      // Exact .005 THB boundary verification:
      // Buy:  originalNet '1.00' USD * 33.335 = 33.335 THB (stored exact as '33.335')
      // Sell: originalNet '1.00' USD * 35.34  = 35.34 THB
      // Exact Realized G/L = 35.34 - 33.335 = 2.005 THB -> ROUND_HALF_UP (2dp) = 2.01 THB
      const customProvider = new MockFXRateProvider({
        '2024-10-01': { 'USD/THB': '33.335' },
        '2024-10-09': { 'USD/THB': '35.34' },
      });

      const txs: Transaction[] = [
        {
          id: 'HALF-UP-BUY',
          date: '2024-10-01',
          symbol: 'MSFT',
          qty: 1,
          price: 1,
          gross: 1,
          comm: 0,
          vat: 0,
          net: 1,
          type: 'BUY',
          exchange: 'IBKR',
          originalCurrency: 'USD',
          originalNet: '1.00',
          fxRate: null,
          netTHB: null,
        },
        {
          id: 'HALF-UP-SELL',
          date: '2024-10-09',
          symbol: 'MSFT',
          qty: 1,
          price: 1,
          gross: 1,
          comm: 0,
          vat: 0,
          net: 1,
          type: 'SELL',
          exchange: 'IBKR',
          originalCurrency: 'USD',
          originalNet: '1.00',
          fxRate: null,
          netTHB: null,
        },
      ];

      const enriched = await enrichTransactionsWithFX(txs, customProvider, 'THB');
      expect(enriched[0]!.netTHB).toBe('33.335'); // Zero Intermediate Rounding preserved!
      expect(enriched[1]!.netTHB).toBe('35.34');

      const result = calculateFIFO([enriched[0]!], [enriched[1]!], {});
      // 35.34 - 33.335 = 2.005 -> ROUND_HALF_UP => 2.01
      expect(result.lots[0]!.realizedGL).toBe(2.01);
      expect(result.totalRealizedGL).toBe(2.01);
    });

    it('runs full pipeline: IBKR CSV + Bitkub CSV -> FX Enrichment -> FIFO THB Engine', async () => {
      const ibkrCSV = `
        TradeDate,Symbol,Quantity,TradePrice,Commission,NetAmount,Currency
        20241001,AAPL,10,150.50,1.00,-1506.00,USD
        20241010,AAPL,-5,160.00,1.00,799.00,USD
      `;

      const bitkubCSV = `
        วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม
        2024-10-01 10:00:00,ซื้อ,BTC/THB,2000000,0.001,2000,10
        2024-10-05 14:30:00,ขาย,BTC/THB,2100000,0.0005,1050,5.25
      `;

      const allRawTxs = [...parseIBKRCsv(ibkrCSV), ...parseBitkubCSV(bitkubCSV)];
      const fxProvider = new MockFXRateProvider(); // 2024-10-01: 36.75, 2024-10-10: 36.60

      const enrichedTxs = await enrichTransactionsWithFX(allRawTxs, fxProvider, 'THB');
      const buys = enrichedTxs.filter((t) => t.type === 'BUY');
      const sells = enrichedTxs.filter((t) => t.type === 'SELL');

      const result = calculateFIFO(buys, sells, {
        AAPL: 6100,
        BTC: 2200000,
      });

      // AAPL: Buy 10 @ 55,345.50 THB (5,534.55/sh), Sell 5 on 2024-10-10 @ 799 * 36.60 = 29,243.40 THB
      // AAPL Realized G/L = 29,243.40 - 27,672.75 = 1,570.65 THB
      // BTC:  Realized G/L = 39.75 THB
      // Total Realized G/L = 1,570.65 + 39.75 = 1,610.40 THB
      expect(result.totalRealizedGL).toBe(1610.4);
    });
  });
});
