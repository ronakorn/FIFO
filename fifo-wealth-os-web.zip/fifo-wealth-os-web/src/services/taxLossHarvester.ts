import Decimal from 'decimal.js';
import { Portfolio } from '../types/shared';
import {
  HarvestingInput,
  HarvestingSimulation,
  TaxLossHarvestingOpportunity,
} from '../types/wave1';

const FinDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type { HarvestingInput, HarvestingSimulation };

const KNOWN_US_SYMBOLS = new Set([
  'AAPL',
  'NVDA',
  'MSFT',
  'GOOGL',
  'GOOG',
  'AMZN',
  'META',
  'TSLA',
  'AMD',
  'AVGO',
  'NFLX',
  'VOO',
  'SPY',
  'QQQ',
  'SCHD',
  'BRK.B',
]);

const CRYPTO_OR_TH_SYMBOLS = new Set([
  'BTC',
  'ETH',
  'SOL',
  'XRP',
  'ADA',
  'DOGE',
  'BNB',
  'PTT',
  'AOT',
  'ADVANC',
  'DELTA',
  'SCB',
  'KBANK',
  'CPALL',
  'BDMS',
]);

export interface HarvestingOptions {
  marginalTaxRate?: Decimal.Value;
  referenceDate?: string; // ISO YYYY-MM-DD, defaults to 2026-10-26
  recentBuyDatesBySymbol?: Record<string, string[]>;
}

function diffCalendarDays(startIso: string, endIso: string): number {
  const startMs = Date.parse(`${startIso.slice(0, 10)}T00:00:00Z`);
  const endMs = Date.parse(`${endIso.slice(0, 10)}T00:00:00Z`);
  if (Number.isNaN(startMs) || Number.isNaN(endMs)) return 0;
  return Math.max(0, Math.floor((endMs - startMs) / 86_400_000));
}

function isUsEquitySymbol(symbol: string): boolean {
  const upper = symbol.trim().toUpperCase();
  if (KNOWN_US_SYMBOLS.has(upper)) return true;
  if (CRYPTO_OR_TH_SYMBOLS.has(upper)) return false;
  return !upper.endsWith('.BK') && !upper.includes('/THB');
}

/**
 * Calculates positive Unrealized Loss magnitude when `currentPrice < avgCost`,
 * or returns `'0.00'` when the position is at break-even or profit (`currentPrice >= avgCost`).
 *
 * Note: Uses `pnl = (currentPrice - avgCost) * qty` so a losing position produces `pnl < 0`
 * (`pnl.isNegative() === true`) and returns `pnl.abs().toFixed(2, ROUND_HALF_UP)`.
 */
export function calculateUnrealizedLoss(
  avgCost: Decimal.Value,
  currentPrice: Decimal.Value,
  qty: Decimal.Value
): string {
  const cost = new FinDecimal(avgCost);
  const price = new FinDecimal(currentPrice);
  const quantity = new FinDecimal(qty);

  const pnl = price.minus(cost).times(quantity);
  return pnl.isNegative()
    ? pnl.abs().toFixed(2, Decimal.ROUND_HALF_UP)
    : '0.00';
}

/**
 * Calculates Tax Saving Potential = Unrealized Loss * Marginal Tax Rate via Decimal.js (precision: 40).
 */
export function calculateTaxSaving(
  unrealizedLoss: Decimal.Value,
  marginalTaxRate: Decimal.Value
): string {
  const loss = new FinDecimal(unrealizedLoss);
  const rate = new FinDecimal(marginalTaxRate);
  if (rate.lt(0) || rate.gt(1)) {
    throw new Error('marginalTaxRate must be between 0 and 1.');
  }
  return loss.times(rate).toFixed(2, Decimal.ROUND_HALF_UP);
}

export interface DirectHarvestPosition {
  symbol: string;
  avgCost: string;
  currentPrice: string;
  qty: number;
  daysHeld: number;
  lotId?: string;
}

export function findHarvestingOpportunities(
  portfolio: DirectHarvestPosition[],
  marginalTaxRate?: string
): TaxLossHarvestingOpportunity[];
export function findHarvestingOpportunities(
  portfolio: Portfolio,
  currentPrices: Record<string, string>,
  options?: HarvestingOptions
): TaxLossHarvestingOpportunity[];
export function findHarvestingOpportunities(
  portfolioOrPositions: Portfolio | DirectHarvestPosition[],
  pricesOrRate: Record<string, string> | string = '0.20',
  options: HarvestingOptions = {}
): TaxLossHarvestingOpportunity[] {
  // Branch 1: Direct array of summarized positions
  if (Array.isArray(portfolioOrPositions)) {
    const rateStr =
      typeof pricesOrRate === 'string' ? pricesOrRate : '0.20';

    return portfolioOrPositions
      .filter((p) => {
        const loss = calculateUnrealizedLoss(p.avgCost, p.currentPrice, p.qty);
        return new FinDecimal(loss).gt(0);
      })
      .map((p, idx): TaxLossHarvestingOpportunity => {
        const loss = calculateUnrealizedLoss(p.avgCost, p.currentPrice, p.qty);
        const taxSaving = calculateTaxSaving(loss, rateStr);
        const washSaleRisk = p.daysHeld < 30;
        const sym = p.symbol.trim().toUpperCase();

        return {
          symbol: sym,
          lotId: p.lotId ?? `${sym}-${idx + 1}`,
          qtyRemain: new FinDecimal(p.qty).toDecimalPlaces(8).toString(),
          currentPrice: new FinDecimal(p.currentPrice).toFixed(
            2,
            Decimal.ROUND_HALF_UP
          ),
          avgCost: new FinDecimal(p.avgCost).toFixed(2, Decimal.ROUND_HALF_UP),
          unrealizedLoss: loss,
          daysHeld: p.daysHeld,
          taxSavingPotential: taxSaving,
          marginalTaxRate: rateStr,
          washSaleRisk,
          status: washSaleRisk ? 'WASH_SALE_RISK' : 'AVAILABLE',
          washSaleNote: washSaleRisk
            ? `${sym}: ถือครองไม่ถึง 30 วัน เสี่ยง Wash Sale Rule`
            : isUsEquitySymbol(sym)
              ? 'US Equity: หลังขายทำ Tax-Loss Harvesting ห้ามซื้อหุ้นเดิมกลับภายใน 30 วัน (Wash Sale Rule)'
              : null,
        };
      })
      .sort((a, b) =>
        new FinDecimal(b.taxSavingPotential).comparedTo(
          new FinDecimal(a.taxSavingPotential)
        )
      );
  }

  // Branch 2: Full Portfolio object with FIFO Open Lots + currentPrices map
  const currentPrices =
    typeof pricesOrRate === 'object' && pricesOrRate !== null
      ? pricesOrRate
      : {};
  const rateStr = new FinDecimal(options.marginalTaxRate ?? '0.20').toString();
  const marginalRate = new FinDecimal(rateStr);
  if (marginalRate.lt(0) || marginalRate.gt(1)) {
    throw new Error('marginalTaxRate must be between 0 and 1.');
  }

  const refDate = options.referenceDate ?? '2026-10-26';
  const openLots = (portfolioOrPositions.fifoSummary?.lots ?? []).filter(
    (lot) => new FinDecimal(lot.qtyRemain).gt(0)
  );

  const grouped = new Map<
    string,
    {
      symbol: string;
      firstLotId: string;
      totalQty: Decimal;
      totalCostTHB: Decimal;
      totalLossTHB: Decimal;
      currentPriceDec: Decimal;
      oldestLotDate: string;
      newestLotDate: string;
    }
  >();

  for (const lot of openLots) {
    const sym = lot.symbol.trim().toUpperCase();
    const rawPriceStr = currentPrices[sym] ?? currentPrices[lot.symbol];
    if (rawPriceStr === undefined) continue;

    const lotLossStr = calculateUnrealizedLoss(
      lot.costPerUnit,
      rawPriceStr,
      lot.qtyRemain
    );
    const lotLossDec = new FinDecimal(lotLossStr);
    if (lotLossDec.lte(0)) continue;

    const currentPriceDec = new FinDecimal(rawPriceStr);
    const qtyRemainDec = new FinDecimal(lot.qtyRemain);
    const lotCost = new FinDecimal(lot.costPerUnit).times(qtyRemainDec);

    const existing = grouped.get(sym);
    if (!existing) {
      grouped.set(sym, {
        symbol: sym,
        firstLotId: lot.id,
        totalQty: qtyRemainDec,
        totalCostTHB: lotCost,
        totalLossTHB: lotLossDec,
        currentPriceDec,
        oldestLotDate: lot.date.slice(0, 10),
        newestLotDate: lot.date.slice(0, 10),
      });
    } else {
      existing.totalQty = existing.totalQty.plus(qtyRemainDec);
      existing.totalCostTHB = existing.totalCostTHB.plus(lotCost);
      existing.totalLossTHB = existing.totalLossTHB.plus(lotLossDec);
      if (lot.date.slice(0, 10) < existing.oldestLotDate) {
        existing.oldestLotDate = lot.date.slice(0, 10);
      }
      if (lot.date.slice(0, 10) > existing.newestLotDate) {
        existing.newestLotDate = lot.date.slice(0, 10);
      }
    }
  }

  const opportunities: TaxLossHarvestingOpportunity[] = [];

  for (const item of grouped.values()) {
    const avgCost = item.totalCostTHB.dividedBy(item.totalQty);
    const unrealizedLossStr = item.totalLossTHB.toFixed(
      2,
      Decimal.ROUND_HALF_UP
    );
    const taxSavingStr = calculateTaxSaving(unrealizedLossStr, marginalRate);
    const daysHeld = diffCalendarDays(item.oldestLotDate, refDate);

    let washSaleRisk = false;
    let washSaleNote: string | null = null;

    if (isUsEquitySymbol(item.symbol)) {
      const recentDates = [
        item.newestLotDate,
        ...(options.recentBuyDatesBySymbol?.[item.symbol] ?? []),
      ];
      const boughtWithin30Days = recentDates.some(
        (d) => diffCalendarDays(d, refDate) < 30
      );

      if (boughtWithin30Days) {
        washSaleRisk = true;
        washSaleNote = `${item.symbol}: ถือครองไม่ถึง 30 วัน เสี่ยง Wash Sale Rule`;
      } else {
        washSaleNote =
          'US Equity: หลังขายทำ Tax-Loss Harvesting ห้ามซื้อหุ้นเดิมกลับภายใน 30 วัน (Wash Sale Rule)';
      }
    }

    opportunities.push({
      lotId: item.firstLotId,
      symbol: item.symbol,
      qtyRemain: item.totalQty.toDecimalPlaces(8).toString(),
      currentPrice: item.currentPriceDec.toFixed(2, Decimal.ROUND_HALF_UP),
      avgCost: avgCost.toFixed(2, Decimal.ROUND_HALF_UP),
      unrealizedLoss: unrealizedLossStr,
      daysHeld,
      taxSavingPotential: taxSavingStr,
      marginalTaxRate: rateStr,
      washSaleRisk,
      status: washSaleRisk ? 'WASH_SALE_RISK' : 'AVAILABLE',
      washSaleNote,
    });
  }

  opportunities.sort((a, b) =>
    new FinDecimal(b.taxSavingPotential).comparedTo(
      new FinDecimal(a.taxSavingPotential)
    )
  );

  return opportunities;
}

/**
 * Simulates harvesting a selected set of opportunities against `currentTaxLiability`.
 * - Only `AVAILABLE` lots (clear of the 30-day Wash Sale Rule) contribute to `totalTaxSaving` and `harvestedLots`.
 * - `WASH_SALE_RISK` lots emit actionable Thai warnings in `washSaleWarnings`.
 */
export function simulateHarvesting(
  opportunities: TaxLossHarvestingOpportunity[],
  currentTaxLiability: string
): HarvestingSimulation {
  const initialTax = new FinDecimal(currentTaxLiability || '0');
  if (initialTax.lt(0)) {
    throw new Error('currentTaxLiability cannot be negative.');
  }

  let totalSaving = new FinDecimal(0);
  let totalHarvestedLoss = new FinDecimal(0);
  const harvestedLots: string[] = [];
  const washSaleWarnings: string[] = [];

  opportunities.forEach((opp, idx) => {
    const effectiveStatus =
      opp.status ?? (opp.washSaleRisk ? 'WASH_SALE_RISK' : 'AVAILABLE');

    if (effectiveStatus === 'AVAILABLE') {
      totalSaving = totalSaving.plus(
        new FinDecimal(opp.taxSavingPotential || '0')
      );
      totalHarvestedLoss = totalHarvestedLoss.plus(
        new FinDecimal(opp.unrealizedLoss || '0')
      );
      harvestedLots.push(opp.lotId || `${opp.symbol}-${idx + 1}`);
    } else if (effectiveStatus === 'WASH_SALE_RISK') {
      washSaleWarnings.push(
        `${opp.symbol}: ถือครองไม่ถึง 30 วัน เสี่ยง Wash Sale Rule`
      );
    }
  });

  const newLiability = initialTax.minus(totalSaving);

  return {
    totalTaxSaving: totalSaving.toFixed(2, Decimal.ROUND_HALF_UP),
    newTaxLiability: newLiability.gt(0)
      ? newLiability.toFixed(2, Decimal.ROUND_HALF_UP)
      : '0.00',
    harvestedLots,
    washSaleWarnings,
    totalHarvestedLoss: totalHarvestedLoss.toFixed(2, Decimal.ROUND_HALF_UP),
  };
}
