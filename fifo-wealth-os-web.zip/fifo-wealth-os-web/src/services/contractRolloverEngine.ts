import crypto from 'crypto';
import { getPrismaClient } from '../db/prisma';
import { AppError } from '../middleware/errorHandler';
import { GoldTransaction } from '../types/gold';
import {
  DerivativesContractExtensionDTO,
  ExecuteRolloverInput,
  ExecuteRolloverResult,
  ExpiringContractAlert,
  ExpiryAlertSeverity,
  FuturesContractSpec,
  MarketStructureRegime,
  RolloverHistoryItem,
  RolloverLegAction,
  RolloverSpreadAnalytics,
} from '../types/rollover';
import {
  calculateGoldFIFO,
  calculateGoldTransactionTotalCost,
  GoldDecimal,
  toCleanGoldDecimal,
} from './goldEngine';

/**
 * Institutional Gold Futures Expiry Calendar (TFEX Gold Online `GO` & COMEX `GC`)
 * Evaluated relative to current date (e.g., 2026-10-26 in Asia/Bangkok).
 */
export const FUTURES_CONTRACT_CATALOG: FuturesContractSpec[] = [
  {
    symbol: 'GOV26',
    exchange: 'TFEX',
    contractMonth: 'V26',
    expirationDate: '2026-10-29', // 3 days from 2026-10-26 -> URGENT_3D Alert!
    noticeDate: '2026-10-30',
    suggestedNextSymbol: 'GOZ26',
    suggestedNextMonth: 'Z26',
    suggestedNextExpirationDate: '2026-12-29',
    currentMarketPriceUSD: '2742.00',
    weightUnit: 'TROY_OUNCE',
    purity: '99.5',
  },
  {
    symbol: 'GCX26',
    exchange: 'COMEX',
    contractMonth: 'X26',
    expirationDate: '2026-11-02', // 7 days from 2026-10-26 -> WARNING_7D Alert!
    noticeDate: '2026-10-30',
    suggestedNextSymbol: 'GCZ26',
    suggestedNextMonth: 'Z26',
    suggestedNextExpirationDate: '2026-12-29',
    currentMarketPriceUSD: '2746.50',
    weightUnit: 'TROY_OUNCE',
    purity: '99.5',
  },
  {
    symbol: 'GOZ26',
    exchange: 'TFEX',
    contractMonth: 'Z26',
    expirationDate: '2026-12-29',
    noticeDate: '2026-12-30',
    suggestedNextSymbol: 'GOH27',
    suggestedNextMonth: 'H27',
    suggestedNextExpirationDate: '2027-03-30',
    currentMarketPriceUSD: '2758.50', // +16.50 USD Contango above GOV26
    weightUnit: 'TROY_OUNCE',
    purity: '99.5',
  },
  {
    symbol: 'GCZ26',
    exchange: 'COMEX',
    contractMonth: 'Z26',
    expirationDate: '2026-12-29',
    noticeDate: '2026-12-01',
    suggestedNextSymbol: 'GCG27',
    suggestedNextMonth: 'G27',
    suggestedNextExpirationDate: '2027-02-25',
    currentMarketPriceUSD: '2761.00',
    weightUnit: 'TROY_OUNCE',
    purity: '99.5',
  },
  {
    symbol: 'GOH27',
    exchange: 'TFEX',
    contractMonth: 'H27',
    expirationDate: '2027-03-30',
    noticeDate: '2027-03-31',
    suggestedNextSymbol: 'GOM27',
    suggestedNextMonth: 'M27',
    suggestedNextExpirationDate: '2027-06-29',
    currentMarketPriceUSD: '2781.00', // +22.50 USD Contango above GOZ26
    weightUnit: 'TROY_OUNCE',
    purity: '99.5',
  },
  {
    symbol: 'GOM27',
    exchange: 'TFEX',
    contractMonth: 'M27',
    expirationDate: '2027-06-29',
    noticeDate: '2027-06-30',
    suggestedNextSymbol: 'GOU27',
    suggestedNextMonth: 'U27',
    suggestedNextExpirationDate: '2027-09-29',
    currentMarketPriceUSD: '2802.00',
    weightUnit: 'TROY_OUNCE',
    purity: '99.5',
  },
];

function parseUtcMidnight(isoDate: string): number {
  const clean = isoDate.trim().slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) {
    throw new Error(`Invalid ISO date "${isoDate}". Expected YYYY-MM-DD.`);
  }
  const y = Number(parts[0]);
  const m = Number(parts[1]);
  const d = Number(parts[2]);
  return Date.UTC(y, m - 1, d);
}

export function calculateDaysToExpiry(
  expirationDate: string,
  asOfDate: string
): number {
  const expMs = parseUtcMidnight(expirationDate);
  const nowMs = parseUtcMidnight(asOfDate);
  return Math.round((expMs - nowMs) / (24 * 60 * 60 * 1000));
}

export function classifyExpirySeverity(daysToExpiry: number): {
  severity: ExpiryAlertSeverity;
  shouldPlayAudioAlert: boolean;
} {
  if (daysToExpiry < 0) {
    return { severity: 'EXPIRED', shouldPlayAudioAlert: true };
  }
  if (daysToExpiry <= 1) {
    return { severity: 'CRITICAL_1D', shouldPlayAudioAlert: true };
  }
  if (daysToExpiry <= 3) {
    return { severity: 'URGENT_3D', shouldPlayAudioAlert: true };
  }
  if (daysToExpiry <= 7) {
    return { severity: 'WARNING_7D', shouldPlayAudioAlert: true };
  }
  if (daysToExpiry <= 30) {
    return { severity: 'UPCOMING_30D', shouldPlayAudioAlert: false };
  }
  return { severity: 'SAFE', shouldPlayAudioAlert: false };
}

export function classifySpreadRegime(
  spreadPerUnit: InstanceType<typeof GoldDecimal>
): MarketStructureRegime {
  if (spreadPerUnit.gt(0)) return 'CONTANGO';
  if (spreadPerUnit.lt(0)) return 'BACKWARDATION';
  return 'FLAT';
}

export function findContractSpec(symbol: string): FuturesContractSpec | null {
  const upper = symbol.trim().toUpperCase();
  return FUTURES_CONTRACT_CATALOG.find((c) => c.symbol === upper) ?? null;
}

/**
 * Scans open `GOLD_ONLINE_FUTURES` FIFO lots and generates proactive expiry alerts
 * (7-day, 3-day, 1-day, and expired warnings + recommended rollover back-month contract).
 */
export function scanExpiringFuturesContracts(params: {
  transactions: GoldTransaction[];
  extensionsByTxId: Map<string, DerivativesContractExtensionDTO>;
  asOfDate: string;
  xauUsdSpot: string;
  usdThbRate: string;
  gtaGold965SellTHB: string;
}): ExpiringContractAlert[] {
  const fifo = calculateGoldFIFO(params.transactions, {
    xauUsdSpot: params.xauUsdSpot,
    usdThbRate: params.usdThbRate,
    gtaGold965SellTHB: params.gtaGold965SellTHB,
  });

  const openFuturesLots = fifo.lots.filter(
    (lot) =>
      lot.assetSubclass === 'GOLD_ONLINE_FUTURES' &&
      toCleanGoldDecimal(lot.weightRemain).gt(0)
  );

  const alerts: ExpiringContractAlert[] = [];

  for (const lot of openFuturesLots) {
    const ext = params.extensionsByTxId.get(lot.transactionId);
    const catalogSpec = findContractSpec(lot.symbol);

    const contractMonth =
      ext?.contractMonth ??
      catalogSpec?.contractMonth ??
      (lot.symbol.length >= 3 ? lot.symbol.slice(-3) : 'Z26');

    const expirationDate =
      ext?.expirationDate ?? catalogSpec?.expirationDate ?? '2026-12-29';

    const daysToExpiry = calculateDaysToExpiry(expirationDate, params.asOfDate);
    const { severity, shouldPlayAudioAlert } =
      classifyExpirySeverity(daysToExpiry);

    const frontPriceUSD = toCleanGoldDecimal(
      catalogSpec?.currentMarketPriceUSD ?? params.xauUsdSpot
    );
    const nextSpec = catalogSpec?.suggestedNextSymbol
      ? findContractSpec(catalogSpec.suggestedNextSymbol)
      : null;

    const suggestedBackSymbol =
      catalogSpec?.suggestedNextSymbol ?? `${lot.symbol.slice(0, 2)}H27`;
    const suggestedBackMonth = catalogSpec?.suggestedNextMonth ?? 'H27';
    const suggestedBackExpirationDate =
      catalogSpec?.suggestedNextExpirationDate ?? '2027-03-30';
    const suggestedBackPriceUSD = nextSpec
      ? toCleanGoldDecimal(nextSpec.currentMarketPriceUSD)
      : frontPriceUSD.plus(new GoldDecimal('18.00'));

    const estSpreadUSD = suggestedBackPriceUSD.minus(frontPriceUSD);
    const regime = classifySpreadRegime(estSpreadUSD);

    const alertMessageTH =
      daysToExpiry <= 0
        ? `สัญญา ${lot.symbol} ถึงกำหนดหมดอายุแล้ว! กรุณา Execute Rollover ไปยัง ${suggestedBackSymbol} ทันทีเพื่อป้องกันการถูกบังคับปิดสถานะ (Force Close)`
        : daysToExpiry <= 7
          ? `แจ้งเตือนด่วน: สัญญา ${lot.symbol} จะหมดอายุในอีก ${daysToExpiry} วัน (${expirationDate}) แนะนำ Rollover ไปยัง ${suggestedBackSymbol}`
          : `สัญญา ${lot.symbol} เหลืออายุอีก ${daysToExpiry} วัน (วันซื้อขายวันสุดท้าย ${expirationDate})`;

    const alertMessageEN =
      daysToExpiry <= 0
        ? `Contract ${lot.symbol} has reached expiration! Execute rollover to ${suggestedBackSymbol} immediately to avoid broker force-liquidation.`
        : daysToExpiry <= 7
          ? `Urgent: ${lot.symbol} expires in ${daysToExpiry} day(s) (${expirationDate}). Roll over to ${suggestedBackSymbol} before notice day.`
          : `Contract ${lot.symbol} has ${daysToExpiry} days remaining until Last Trading Day (${expirationDate}).`;

    alerts.push({
      lotId: lot.id,
      transactionId: lot.transactionId,
      symbol: lot.symbol,
      contractMonth,
      expirationDate,
      daysToExpiry,
      severity,
      shouldPlayAudioAlert,
      openWeight: lot.weightRemain,
      weightUnit: lot.weightUnit,
      purity: lot.purity,
      entryCostPerUnitTHB: lot.costPerUnit,
      currentFrontPriceUSD: frontPriceUSD.toFixed(2),
      suggestedBackSymbol,
      suggestedBackMonth,
      suggestedBackExpirationDate,
      suggestedBackPriceUSD: suggestedBackPriceUSD.toFixed(2),
      estimatedSpreadPerUnitUSD: estSpreadUSD.toFixed(2),
      regime,
      alertMessageTH,
      alertMessageEN,
    });
  }

  // Sort most urgent (fewest daysToExpiry) first
  alerts.sort((a, b) => a.daysToExpiry - b.daysToExpiry);
  return alerts;
}

/**
 * Pure Quantitative Calculator for Rollover Spread Cost (Contango / Backwardation),
 * Exact FIFO Realized PnL on the Front-Month Close Leg, and Back-Month Cost Basis.
 */
export function calculateRolloverSpreadAnalytics(params: {
  existingTransactions: GoldTransaction[];
  portfolioId: string;
  date: string;
  frontSymbol: string;
  backSymbol: string;
  weight: string;
  weightUnit: GoldTransaction['weightUnit'];
  purity: GoldTransaction['purity'];
  frontClosePriceUSD: string;
  backOpenPriceUSD: string;
  closeCommissionUSD: string;
  openCommissionUSD: string;
  fxRateUSDTHB: string;
}): RolloverSpreadAnalytics {
  const w = toCleanGoldDecimal(params.weight);
  const frontPrice = toCleanGoldDecimal(params.frontClosePriceUSD);
  const backPrice = toCleanGoldDecimal(params.backOpenPriceUSD);
  const closeComm = toCleanGoldDecimal(params.closeCommissionUSD);
  const openComm = toCleanGoldDecimal(params.openCommissionUSD);
  const fx = toCleanGoldDecimal(params.fxRateUSDTHB);

  if (w.lte(0)) {
    throw new Error('Rollover weight must be strictly positive.');
  }
  if (frontPrice.lte(0) || backPrice.lte(0) || fx.lte(0)) {
    throw new Error('Contract prices and FX rate must be strictly positive.');
  }
  if (closeComm.isNegative() || openComm.isNegative()) {
    throw new Error('Rollover commissions cannot be negative.');
  }

  // Spread = Back-Month Open Price - Front-Month Close Price
  const spreadPerUnitUSD = backPrice.minus(frontPrice);
  const spreadPerUnitTHB = spreadPerUnitUSD.times(fx);
  const regime = classifySpreadRegime(spreadPerUnitUSD);

  const totalSpreadCostUSD = spreadPerUnitUSD.times(w);
  const totalSpreadCostTHB = totalSpreadCostUSD.times(fx);
  const totalCommissionTHB = closeComm.plus(openComm).times(fx);
  const netRolloverFrictionTHB = totalSpreadCostTHB.plus(totalCommissionTHB);

  // Compute exact incremental FIFO Realized G/L from closing `frontSymbol`
  const marketSnapshot = {
    xauUsdSpot: frontPrice.toFixed(2),
    usdThbRate: fx.toFixed(4),
    gtaGold965SellTHB: '46450.00',
  };

  const beforeFifo = calculateGoldFIFO(
    params.existingTransactions,
    marketSnapshot
  );

  const closeTotalCostUSD = calculateGoldTransactionTotalCost({
    weight: w.toFixed(4),
    spotPricePerUnit: frontPrice.toFixed(2),
    premiumPerUnit: '0',
    commission: closeComm.toFixed(2),
    type: 'SELL',
  });

  const simulatedCloseTx: GoldTransaction = {
    id: 'zz-rollover-preview-close',
    portfolioId: params.portfolioId,
    date: params.date.slice(0, 10),
    symbol: params.frontSymbol.trim().toUpperCase(),
    assetSubclass: 'GOLD_ONLINE_FUTURES',
    weight: w.toFixed(4),
    weightUnit: params.weightUnit,
    purity: params.purity,
    spotPricePerUnit: frontPrice.toFixed(2),
    premiumPerUnit: '0.00',
    commission: closeComm.toFixed(2),
    totalCost: closeTotalCostUSD,
    fxRateAtPurchase: fx.toFixed(4),
    type: 'SELL',
    createdAt: new Date(),
  };

  const afterFifo = calculateGoldFIFO(
    [...params.existingTransactions, simulatedCloseTx],
    marketSnapshot
  );

  const incrementalRealizedTHB = toCleanGoldDecimal(
    afterFifo.totalRealizedGLTHB
  ).minus(toCleanGoldDecimal(beforeFifo.totalRealizedGLTHB));

  // New Back-Month Contract Initial Cost Basis (THB)
  const openTotalCostUSD = calculateGoldTransactionTotalCost({
    weight: w.toFixed(4),
    spotPricePerUnit: backPrice.toFixed(2),
    premiumPerUnit: '0',
    commission: openComm.toFixed(2),
    type: 'BUY',
  });
  const newBackCostBasisTHB = toCleanGoldDecimal(openTotalCostUSD).times(fx);

  return {
    frontSymbol: params.frontSymbol.trim().toUpperCase(),
    backSymbol: params.backSymbol.trim().toUpperCase(),
    weight: w.toFixed(4),
    weightUnit: params.weightUnit,
    frontClosePriceUSD: frontPrice.toFixed(2),
    backOpenPriceUSD: backPrice.toFixed(2),
    fxRateUSDTHB: fx.toFixed(4),
    spreadPerUnitUSD: spreadPerUnitUSD.toFixed(2),
    spreadPerUnitTHB: spreadPerUnitTHB.toFixed(2),
    regime,
    totalSpreadCostUSD: totalSpreadCostUSD.toFixed(2),
    totalSpreadCostTHB: totalSpreadCostTHB.toFixed(2),
    totalCommissionTHB: totalCommissionTHB.toFixed(2),
    netRolloverFrictionTHB: netRolloverFrictionTHB.toFixed(2),
    estimatedCloseRealizedGLTHB: incrementalRealizedTHB.toFixed(2),
    newBackContractCostBasisTHB: newBackCostBasisTHB.toFixed(2),
  };
}

/**
 * Reconstructs historical rollover pairs linked by `rolloverGroupId` and calculates
 * exact realized G/L and Contango/Backwardation spread impact per rollover event.
 */
export function buildRolloverHistory(params: {
  transactions: GoldTransaction[];
  extensionsByTxId: Map<string, DerivativesContractExtensionDTO>;
  xauUsdSpot: string;
  usdThbRate: string;
  gtaGold965SellTHB: string;
}): RolloverHistoryItem[] {
  const grouped = new Map<
    string,
    {
      closeTx?: GoldTransaction;
      closeExt?: DerivativesContractExtensionDTO;
      openTx?: GoldTransaction;
      openExt?: DerivativesContractExtensionDTO;
    }
  >();

  for (const tx of params.transactions) {
    const ext = params.extensionsByTxId.get(tx.id);
    if (!ext || !ext.isRollover || !ext.rolloverGroupId) continue;

    const entry = grouped.get(ext.rolloverGroupId) ?? {};
    if (ext.legAction.startsWith('CLOSE') || tx.type === 'SELL') {
      entry.closeTx = tx;
      entry.closeExt = ext;
    } else {
      entry.openTx = tx;
      entry.openExt = ext;
    }
    grouped.set(ext.rolloverGroupId, entry);
  }

  // Compute full FIFO lots to extract realized G/L per closed front-month symbol
  const fifo = calculateGoldFIFO(params.transactions, {
    xauUsdSpot: params.xauUsdSpot,
    usdThbRate: params.usdThbRate,
    gtaGold965SellTHB: params.gtaGold965SellTHB,
  });

  const history: RolloverHistoryItem[] = [];

  for (const [groupId, pair] of grouped.entries()) {
    if (!pair.closeTx || !pair.openTx) continue;

    const frontPrice = toCleanGoldDecimal(pair.closeTx.spotPricePerUnit);
    const backPrice = toCleanGoldDecimal(pair.openTx.spotPricePerUnit);
    const weight = toCleanGoldDecimal(pair.openTx.weight);
    const fx = toCleanGoldDecimal(pair.openTx.fxRateAtPurchase);

    const spreadUSD = pair.openExt?.rolloverSpread
      ? toCleanGoldDecimal(pair.openExt.rolloverSpread)
      : backPrice.minus(frontPrice);
    const regime = classifySpreadRegime(spreadUSD);
    const spreadCostTHB = spreadUSD.times(weight).times(fx);
    const newOpenCostTHB = toCleanGoldDecimal(pair.openTx.totalCost).times(fx);

    const matchingClosedLots = fifo.lots.filter(
      (l) => l.symbol === pair.closeTx!.symbol
    );
    const realizedGLTHB = matchingClosedLots.reduce(
      (acc, l) => acc.plus(toCleanGoldDecimal(l.realizedGL)),
      new GoldDecimal(0)
    );

    history.push({
      rolloverGroupId: groupId,
      executedDate: pair.openTx.date,
      frontSymbol: pair.closeTx.symbol,
      frontContractMonth: pair.closeExt?.contractMonth ?? '',
      backSymbol: pair.openTx.symbol,
      backContractMonth: pair.openExt?.contractMonth ?? '',
      rolledWeight: weight.toFixed(4),
      weightUnit: pair.openTx.weightUnit,
      frontClosePriceUSD: frontPrice.toFixed(2),
      backOpenPriceUSD: backPrice.toFixed(2),
      rolloverSpreadUSD: spreadUSD.toFixed(2),
      regime,
      spreadCostTHB: spreadCostTHB.toFixed(2),
      realizedGLClosedLegTHB: realizedGLTHB.toFixed(2),
      newOpenCostBasisTHB: newOpenCostTHB.toFixed(2),
    });
  }

  history.sort((a, b) => b.executedDate.localeCompare(a.executedDate));
  return history;
}

/**
 * Atomic Rollover Execution Flow:
 * Executes CLOSE_LONG (Front-Month SELL) + OPEN_LONG (Back-Month BUY) + paired
 * `DerivativesContractExtension` rows inside a single Prisma database transaction.
 * Guarantees all-or-nothing atomicity and preserves exact FIFO Realized PnL & Cost Basis.
 */
export async function executeAtomicContractRollover(
  input: ExecuteRolloverInput
): Promise<ExecuteRolloverResult> {
  const prisma = getPrismaClient();

  const frontSymbol = input.frontSymbol.trim().toUpperCase();
  const backSymbol = input.backSymbol.trim().toUpperCase();
  if (frontSymbol === backSymbol) {
    throw new AppError(
      400,
      'INVALID_ROLLOVER_CONTRACTS',
      'Front-month and Back-month contract symbols must be distinct.'
    );
  }

  return prisma.$transaction(async (tx) => {
    const existingRows = await tx.goldTransactionRecord.findMany({
      where: { portfolioId: input.portfolioId },
      orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
    });

    const existingTxs: GoldTransaction[] = existingRows.map((r) => ({
      id: r.id,
      portfolioId: r.portfolioId,
      date: r.date,
      symbol: r.symbol,
      assetSubclass: r.assetSubclass as GoldTransaction['assetSubclass'],
      weight: r.weight,
      weightUnit: r.weightUnit as GoldTransaction['weightUnit'],
      purity: r.purity as GoldTransaction['purity'],
      spotPricePerUnit: r.spotPricePerUnit,
      premiumPerUnit: r.premiumPerUnit,
      commission: r.commission,
      totalCost: r.totalCost,
      fxRateAtPurchase: r.fxRateAtPurchase,
      type: r.type as 'BUY' | 'SELL',
      createdAt: r.createdAt,
    }));

    // Pre-validate FIFO integrity & compute exact Rollover Spread Analytics
    let analytics: RolloverSpreadAnalytics;
    try {
      analytics = calculateRolloverSpreadAnalytics({
        existingTransactions: existingTxs,
        portfolioId: input.portfolioId,
        date: input.date,
        frontSymbol,
        backSymbol,
        weight: input.weight,
        weightUnit: input.weightUnit,
        purity: input.purity,
        frontClosePriceUSD: input.frontClosePriceUSD,
        backOpenPriceUSD: input.backOpenPriceUSD,
        closeCommissionUSD: input.closeCommissionUSD,
        openCommissionUSD: input.openCommissionUSD,
        fxRateUSDTHB: input.fxRateUSDTHB,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Invalid rollover parameters.';
      throw new AppError(
        400,
        msg.toLowerCase().includes('oversell')
          ? 'ROLLOVER_INSUFFICIENT_POSITION'
          : 'ROLLOVER_VALIDATION_ERROR',
        msg
      );
    }

    const weightStr = toCleanGoldDecimal(input.weight).toFixed(4);
    const frontPriceStr = toCleanGoldDecimal(input.frontClosePriceUSD).toFixed(2);
    const backPriceStr = toCleanGoldDecimal(input.backOpenPriceUSD).toFixed(2);
    const closeCommStr = toCleanGoldDecimal(input.closeCommissionUSD).toFixed(2);
    const openCommStr = toCleanGoldDecimal(input.openCommissionUSD).toFixed(2);
    const fxStr = toCleanGoldDecimal(input.fxRateUSDTHB).toFixed(4);
    const isoDate = input.date.trim().slice(0, 10);

    const closeTotalCostUSD = calculateGoldTransactionTotalCost({
      weight: weightStr,
      spotPricePerUnit: frontPriceStr,
      premiumPerUnit: '0',
      commission: closeCommStr,
      type: 'SELL',
    });

    const openTotalCostUSD = calculateGoldTransactionTotalCost({
      weight: weightStr,
      spotPricePerUnit: backPriceStr,
      premiumPerUnit: '0',
      commission: openCommStr,
      type: 'BUY',
    });

    const rolloverGroupId = crypto.randomUUID();

    // Leg 1: CLOSE_LONG on expiring Front-Month Contract
    const createdClose = await tx.goldTransactionRecord.create({
      data: {
        portfolioId: input.portfolioId,
        date: isoDate,
        symbol: frontSymbol,
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        weight: weightStr,
        weightUnit: input.weightUnit,
        purity: input.purity,
        spotPricePerUnit: frontPriceStr,
        premiumPerUnit: '0.00',
        commission: closeCommStr,
        totalCost: closeTotalCostUSD,
        fxRateAtPurchase: fxStr,
        type: 'SELL',
      },
    });

    const createdCloseExt = await tx.derivativesContractExtension.create({
      data: {
        transactionId: createdClose.id,
        contractMonth: input.frontContractMonth.trim().toUpperCase(),
        expirationDate: input.frontExpirationDate.trim().slice(0, 10),
        legAction: 'CLOSE_LONG' satisfies RolloverLegAction,
        isRollover: true,
        rolloverGroupId,
        rolloverSpread: analytics.spreadPerUnitUSD,
      },
    });

    // Leg 2: OPEN_LONG on new Back-Month Contract
    const createdOpen = await tx.goldTransactionRecord.create({
      data: {
        portfolioId: input.portfolioId,
        date: isoDate,
        symbol: backSymbol,
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        weight: weightStr,
        weightUnit: input.weightUnit,
        purity: input.purity,
        spotPricePerUnit: backPriceStr,
        premiumPerUnit: '0.00',
        commission: openCommStr,
        totalCost: openTotalCostUSD,
        fxRateAtPurchase: fxStr,
        type: 'BUY',
      },
    });

    const createdOpenExt = await tx.derivativesContractExtension.create({
      data: {
        transactionId: createdOpen.id,
        contractMonth: input.backContractMonth.trim().toUpperCase(),
        expirationDate: input.backExpirationDate.trim().slice(0, 10),
        legAction: 'OPEN_LONG' satisfies RolloverLegAction,
        isRollover: true,
        rolloverGroupId,
        rolloverSpread: analytics.spreadPerUnitUSD,
      },
    });

    return {
      rolloverGroupId,
      closeTransaction: {
        id: createdClose.id,
        portfolioId: createdClose.portfolioId,
        date: createdClose.date,
        symbol: createdClose.symbol,
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        weight: createdClose.weight,
        weightUnit: input.weightUnit,
        purity: input.purity,
        spotPricePerUnit: createdClose.spotPricePerUnit,
        premiumPerUnit: createdClose.premiumPerUnit,
        commission: createdClose.commission,
        totalCost: createdClose.totalCost,
        fxRateAtPurchase: createdClose.fxRateAtPurchase,
        type: 'SELL',
        createdAt: createdClose.createdAt,
      },
      openTransaction: {
        id: createdOpen.id,
        portfolioId: createdOpen.portfolioId,
        date: createdOpen.date,
        symbol: createdOpen.symbol,
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        weight: createdOpen.weight,
        weightUnit: input.weightUnit,
        purity: input.purity,
        spotPricePerUnit: createdOpen.spotPricePerUnit,
        premiumPerUnit: createdOpen.premiumPerUnit,
        commission: createdOpen.commission,
        totalCost: createdOpen.totalCost,
        fxRateAtPurchase: createdOpen.fxRateAtPurchase,
        type: 'BUY',
        createdAt: createdOpen.createdAt,
      },
      closeExtension: {
        id: createdCloseExt.id,
        transactionId: createdCloseExt.transactionId,
        contractMonth: createdCloseExt.contractMonth,
        expirationDate: createdCloseExt.expirationDate,
        legAction: createdCloseExt.legAction as RolloverLegAction,
        isRollover: createdCloseExt.isRollover,
        rolloverGroupId: createdCloseExt.rolloverGroupId,
        rolloverSpread: createdCloseExt.rolloverSpread,
      },
      openExtension: {
        id: createdOpenExt.id,
        transactionId: createdOpenExt.transactionId,
        contractMonth: createdOpenExt.contractMonth,
        expirationDate: createdOpenExt.expirationDate,
        legAction: createdOpenExt.legAction as RolloverLegAction,
        isRollover: createdOpenExt.isRollover,
        rolloverGroupId: createdOpenExt.rolloverGroupId,
        rolloverSpread: createdOpenExt.rolloverSpread,
      },
      analytics,
    };
  });
}
