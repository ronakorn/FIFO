import Decimal from 'decimal.js';
import type { Request } from 'express';
import { getPrismaClient } from '../db/prisma';

export type AuditAction = 'CREATE' | 'UPDATE' | 'DELETE';
export type AuditEntityType = 'GOLD_TRANSACTION' | 'PORTFOLIO';

export interface AuditLogEntry {
  id: string;
  userId: string;
  action: AuditAction;
  entityType: AuditEntityType;
  entityId: string;
  beforeState: string | null;
  afterState: string | null;
  ipAddress: string | null;
  timestamp: Date;
}

const SENSITIVE_FIELD_NAMES = new Set<string>([
  'password',
  'passwordhash',
  'token',
  'accesstoken',
  'refreshtoken',
  'flexquerytoken',
  'flexquerytokenencrypted',
  'secret',
  'secretkey',
  'authorization',
]);

/**
 * PDPA / GDPR Safe Canonical Sanitizer:
 * - Redacts any credential/secret fields if accidentally passed
 * - Normalizes `Date` -> ISO 8601 string and `Decimal` -> exact string
 * - Sorts object keys deterministically so JSON diffs are reproducible
 */
export function sanitizeStateForAudit(input: unknown): unknown {
  if (input === null || input === undefined) {
    return null;
  }
  if (input instanceof Date) {
    return input.toISOString();
  }
  if (Decimal.isDecimal(input)) {
    return input.toString();
  }
  if (Array.isArray(input)) {
    return input.map((item) => sanitizeStateForAudit(item));
  }
  if (typeof input === 'object') {
    const record = input as Record<string, unknown>;
    const sortedKeys = Object.keys(record).sort();
    const out: Record<string, unknown> = {};
    for (const key of sortedKeys) {
      const value = record[key];
      if (value === undefined) continue;
      if (SENSITIVE_FIELD_NAMES.has(key.toLowerCase())) {
        out[key] = '[REDACTED_PDPA]';
      } else {
        out[key] = sanitizeStateForAudit(value);
      }
    }
    return out;
  }
  return input;
}

export function serializeAuditState(state: unknown | null | undefined): string | null {
  if (state === null || state === undefined) {
    return null;
  }
  return JSON.stringify(sanitizeStateForAudit(state));
}

export function extractClientIp(req: Request): string | null {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.trim().length > 0) {
    return forwarded.split(',')[0]?.trim() ?? null;
  }
  if (Array.isArray(forwarded) && forwarded[0]) {
    return forwarded[0].trim();
  }
  if (typeof req.ip === 'string' && req.ip.trim().length > 0) {
    return req.ip.trim();
  }
  return req.socket?.remoteAddress ?? null;
}

/**
 * Append-Only Immutable Audit Logger (PDPA / GDPR Ready).
 * Explicitly exposes ONLY `create` and user-scoped `read` operations —
 * audit records are never mutated or deleted.
 */
export async function logAction(
  userId: string,
  action: AuditAction,
  entityType: AuditEntityType,
  entityId: string,
  before: unknown | null,
  after: unknown | null,
  ip?: string | null
): Promise<AuditLogEntry> {
  if (!userId.trim()) {
    throw new Error('AuditLog requires a non-empty userId.');
  }
  if (!entityId.trim()) {
    throw new Error('AuditLog requires a non-empty entityId.');
  }

  const prisma = getPrismaClient();
  const beforeState = serializeAuditState(before);
  const afterState = serializeAuditState(after);
  const normalizedIp = ip && ip.trim().length > 0 ? ip.trim() : null;

  const created = await prisma.auditLog.create({
    data: {
      userId: userId.trim(),
      action,
      entityType,
      entityId: entityId.trim(),
      beforeState,
      afterState,
      ipAddress: normalizedIp,
    },
  });

  return {
    id: created.id,
    userId: created.userId,
    action: created.action as AuditAction,
    entityType: created.entityType as AuditEntityType,
    entityId: created.entityId,
    beforeState: created.beforeState,
    afterState: created.afterState,
    ipAddress: created.ipAddress,
    timestamp: created.timestamp,
  };
}

export interface ListAuditLogsFilter {
  action?: AuditAction;
  entityType?: AuditEntityType;
  limit?: number;
}

export async function getAuditLogsForUser(
  userId: string,
  filter: ListAuditLogsFilter = {}
): Promise<AuditLogEntry[]> {
  const prisma = getPrismaClient();
  const take = Math.min(Math.max(filter.limit ?? 100, 1), 500);

  const rows = await prisma.auditLog.findMany({
    where: {
      userId,
      ...(filter.action ? { action: filter.action } : {}),
      ...(filter.entityType ? { entityType: filter.entityType } : {}),
    },
    orderBy: { timestamp: 'desc' },
    take,
  });

  return rows.map((row) => ({
    id: row.id,
    userId: row.userId,
    action: row.action as AuditAction,
    entityType: row.entityType as AuditEntityType,
    entityId: row.entityId,
    beforeState: row.beforeState,
    afterState: row.afterState,
    ipAddress: row.ipAddress,
    timestamp: row.timestamp,
  }));
}
