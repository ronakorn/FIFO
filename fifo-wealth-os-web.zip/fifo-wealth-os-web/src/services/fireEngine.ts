import Decimal from 'decimal.js';
import seedrandom from 'seedrandom';
import {
  FIREGoal,
  GoalProgress,
  MonteCarloPercentilePoint,
  MonteCarloResult,
  SimulationPath,
} from '../types/fire';

/**
 * Institutional-grade Decimal configuration with precision 40
 * Zero native JS Number arithmetic is permitted in financial calculations.
 */
const Dec = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface MonteCarloOptions {
  targetAmount?: string;
  startYear?: number;
}

/**
 * 1. Calculates the target FIRE Number based on Safe Withdrawal Rate (e.g. 4% Rule).
 * Formula: Annual Expenses / Withdrawal Rate
 */
export function calculateFIRENumber(
  annualExpenses: string,
  withdrawalRate: string
): string {
  const expenses = new Dec(annualExpenses);
  const rate = new Dec(withdrawalRate);

  if (expenses.isNegative()) {
    throw new Error('annualExpenses must be greater than or equal to zero.');
  }
  if (rate.lte(0) || rate.gt(1)) {
    throw new Error(
      'withdrawalRate must be a decimal strictly between 0 and 1 (e.g. "0.04" for 4%).'
    );
  }

  return expenses
    .dividedBy(rate)
    .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
    .toFixed(2);
}

/**
 * 2. Calculates real inflation-adjusted Years to FIRE using the Future Value of Annuity formula
 * and Fisher Real Return: (1 + r_nominal) / (1 + r_inflation) - 1.
 *
 * Solves: FV = PV*(1 + r_m)^N + PMT * [((1 + r_m)^N - 1) / r_m] for N months, Years = N / 12.
 */
export function calculateYearsToFIRE(
  currentAmount: string,
  monthlyContribution: string,
  targetAmount: string,
  expectedReturn: string,
  inflationRate: string
): string {
  const pv = new Dec(currentAmount);
  const pmt = new Dec(monthlyContribution);
  const fv = new Dec(targetAmount);
  const nomReturn = new Dec(expectedReturn);
  const inflation = new Dec(inflationRate);

  if (pv.isNegative()) {
    throw new Error('currentAmount cannot be negative.');
  }
  if (pmt.isNegative()) {
    throw new Error('monthlyContribution cannot be negative.');
  }
  if (fv.lte(0)) {
    throw new Error('targetAmount must be greater than zero.');
  }
  if (inflation.lte(-1) || nomReturn.lte(-1)) {
    throw new Error('Rates must be greater than -100% (-1.0).');
  }

  if (pv.gte(fv)) {
    return '0.00';
  }

  const one = new Dec(1);
  const twelve = new Dec(12);

  // Fisher equation for exact inflation-adjusted real annual return
  const realAnnualReturn = one
    .plus(nomReturn)
    .dividedBy(one.plus(inflation))
    .minus(one);

  if (realAnnualReturn.isZero()) {
    if (pmt.lte(0)) {
      throw new Error(
        'Target FIRE amount is unreachable with zero real return and zero monthly contribution.'
      );
    }
    const months = fv.minus(pv).dividedBy(pmt);
    return months
      .dividedBy(twelve)
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2);
  }

  // Monthly effective real rate: (1 + r_real)^(1/12) - 1
  const monthlyRate = one
    .plus(realAnnualReturn)
    .pow(one.dividedBy(twelve))
    .minus(one);

  const numerator = fv.times(monthlyRate).plus(pmt);
  const denominator = pv.times(monthlyRate).plus(pmt);

  if (denominator.lte(0) || numerator.lte(0)) {
    throw new Error(
      'Target FIRE amount is unreachable under the given real return and monthly contribution.'
    );
  }

  const growthRatio = numerator.dividedBy(denominator);
  if (growthRatio.lte(one)) {
    throw new Error(
      'Target FIRE amount is unreachable because portfolio shrinks in real terms.'
    );
  }

  const totalMonths = growthRatio.ln().dividedBy(one.plus(monthlyRate).ln());
  const years = totalMonths.dividedBy(twelve);

  return years.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
}

/**
 * Generates a standard normal random variable Z ~ N(0, 1) deterministically
 * via the Marsaglia Polar Method using 100% pure Decimal.js (precision 40).
 */
function sampleStandardNormalDecimal(rng: seedrandom.PRNG): Decimal {
  const one = new Dec(1);
  const two = new Dec(2);
  const minusTwo = new Dec(-2);

  // Deterministic rejection loop on unit disk
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const u1 = new Dec(rng().toString());
    const u2 = new Dec(rng().toString());
    const v1 = u1.times(two).minus(one);
    const v2 = u2.times(two).minus(one);
    const s = v1.times(v1).plus(v2.times(v2));

    if (s.gt(0) && s.lt(one)) {
      const factor = s.ln().times(minusTwo).dividedBy(s).sqrt();
      return v1.times(factor);
    }
  }
}

/**
 * Helper to select an exact quantile from a sorted ascending array of Decimals.
 */
function pickQuantileDecimal(sortedValues: Decimal[], quantile: string): Decimal {
  if (sortedValues.length === 0) {
    return new Dec(0);
  }
  if (sortedValues.length === 1) {
    return sortedValues[0]!;
  }

  const q = new Dec(quantile);
  const maxIdx = new Dec(sortedValues.length - 1);
  const pos = q.times(maxIdx);
  const lowerIdx = pos.floor().toNumber();
  const upperIdx = pos.ceil().toNumber();
  const weight = pos.minus(new Dec(lowerIdx));

  const lowVal = sortedValues[lowerIdx]!;
  const highVal = sortedValues[upperIdx]!;
  return lowVal.plus(highVal.minus(lowVal).times(weight));
}

/**
 * Helper to compute deterministic nominal FV over `t` years using Decimal.js,
 * used as a sensible FIRE target benchmark if `targetAmount` is omitted.
 */
function computeNominalFV(
  pv: Decimal,
  monthlyContribution: Decimal,
  annualReturn: Decimal,
  yearsDec: Decimal
): Decimal {
  const one = new Dec(1);
  const annualContrib = monthlyContribution.times(new Dec(12));
  if (annualReturn.isZero()) {
    return pv.plus(annualContrib.times(yearsDec));
  }
  const compound = one.plus(annualReturn).pow(yearsDec);
  return pv
    .times(compound)
    .plus(annualContrib.times(compound.minus(one)).dividedBy(annualReturn));
}

/**
 * 3. Runs a deterministic Geometric Brownian Motion (GBM) Monte Carlo simulation
 * using Decimal.js (precision 40) and seedrandom.
 *
 * Annual GBM step:
 *   G_t = exp((mu - 0.5 * sigma^2) + sigma * Z_t)
 *   W_t = max(0, W_{t-1} * G_t + AnnualContribution * sqrt(G_t))
 */
export function runMonteCarloSimulation(
  currentAmount: string,
  monthlyContribution: string,
  expectedReturn: string,
  volatility: string,
  years: number,
  numSimulations: number,
  seed?: string,
  optionsOrTarget?: string | MonteCarloOptions
): MonteCarloResult {
  const pv = new Dec(currentAmount);
  const pmtMonthly = new Dec(monthlyContribution);
  const mu = new Dec(expectedReturn);
  const sigma = new Dec(volatility);

  if (pv.isNegative()) {
    throw new Error('currentAmount cannot be negative.');
  }
  if (pmtMonthly.isNegative()) {
    throw new Error('monthlyContribution cannot be negative.');
  }
  if (sigma.isNegative()) {
    throw new Error('volatility cannot be negative.');
  }
  if (!Number.isInteger(years) || years < 1 || years > 80) {
    throw new Error('years must be an integer between 1 and 80.');
  }
  if (!Number.isInteger(numSimulations) || numSimulations < 1 || numSimulations > 5000) {
    throw new Error('numSimulations must be an integer between 1 and 5000.');
  }

  const opts: MonteCarloOptions =
    typeof optionsOrTarget === 'string'
      ? { targetAmount: optionsOrTarget }
      : (optionsOrTarget ?? {});

  const startYear = opts.startYear ?? new Date().getFullYear();

  // If explicit targetAmount is not supplied, calibrate benchmark target at 65% of horizon FV
  // so P90 (bull), Median, and P10 (bear) crossing years are well-separated within the horizon.
  const targetDec = opts.targetAmount
    ? new Dec(opts.targetAmount)
    : computeNominalFV(
        pv,
        pmtMonthly,
        mu,
        new Dec(years).times(new Dec('0.65'))
      );

  const rng = seedrandom(seed ?? 'fifo-wealth-os-fire-2026');
  const half = new Dec('0.5');
  const zero = new Dec(0);
  const annualContrib = pmtMonthly.times(new Dec(12));
  const drift = mu.minus(half.times(sigma.times(sigma)));

  // Matrix of Decimal values: rawMatrix[simIdx][yearStep]
  const rawMatrix: Decimal[][] = [];
  const simulations: SimulationPath[] = [];
  let successCount = 0;

  for (let sim = 0; sim < numSimulations; sim++) {
    let wealth: Decimal = pv;
    let depleted = false;
    const pathDecimals: Decimal[] = [wealth];
    const pathFormatted: SimulationPath = [
      {
        year: startYear,
        value: wealth.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
      },
    ];

    for (let step = 1; step <= years; step++) {
      const z = sampleStandardNormalDecimal(rng);
      const logReturn = drift.plus(sigma.times(z));
      const growthFactor = logReturn.exp();
      const inflowFactor = growthFactor.sqrt();

      wealth = Decimal.max(
        zero,
        wealth.times(growthFactor).plus(annualContrib.times(inflowFactor))
      );

      if (wealth.lte(zero) && pv.plus(annualContrib).gt(zero)) {
        depleted = true;
      }

      pathDecimals.push(wealth);
      pathFormatted.push({
        year: startYear + step,
        value: wealth.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
      });
    }

    // Success = portfolio never depleted AND reaches target FIRE wealth by targetYear
    if (!depleted && wealth.gte(targetDec)) {
      successCount += 1;
    }

    rawMatrix.push(pathDecimals);
    simulations.push(pathFormatted);
  }

  // Build cross-sectional P10 (bear), Median (P50), and P90 (bull) wealth trajectories
  const percentileSeries: MonteCarloPercentilePoint[] = [];
  let p90CrossYear: number | null = null;
  let medianCrossYear: number | null = null;
  let p10CrossYear: number | null = null;

  for (let step = 0; step <= years; step++) {
    const crossSection: Decimal[] = rawMatrix.map((row) => row[step]!);
    crossSection.sort((a, b) => a.comparedTo(b));

    const p10Val = pickQuantileDecimal(crossSection, '0.10');
    const medVal = pickQuantileDecimal(crossSection, '0.50');
    const p90Val = pickQuantileDecimal(crossSection, '0.90');

    const calYear = startYear + step;

    if (p90CrossYear === null && p90Val.gte(targetDec)) {
      p90CrossYear = calYear;
    }
    if (medianCrossYear === null && medVal.gte(targetDec)) {
      medianCrossYear = calYear;
    }
    if (p10CrossYear === null && p10Val.gte(targetDec)) {
      p10CrossYear = calYear;
    }

    percentileSeries.push({
      year: calYear,
      p10: p10Val.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
      median: medVal.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
      p90: p90Val.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
    });
  }

  const fallbackEndYear = startYear + years;
  const resolvedP90Year = p90CrossYear ?? fallbackEndYear;
  const resolvedMedianYear = medianCrossYear ?? fallbackEndYear;
  const resolvedP10Year = p10CrossYear ?? fallbackEndYear + 5;

  const successRateDec = new Dec(successCount)
    .dividedBy(new Dec(numSimulations))
    .times(new Dec(100))
    .toDecimalPlaces(2, Decimal.ROUND_HALF_UP);

  return {
    successRate: successRateDec.toNumber(),
    medianYear: resolvedMedianYear,
    p10Year: resolvedP10Year,
    p90Year: resolvedP90Year,
    simulations,
    percentileSeries,
    targetAmount: targetDec.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
  };
}

/**
 * 4. Evaluates real-time progress toward a FIREGoal against actual portfolio value.
 */
export function calculateGoalProgress(
  goal: FIREGoal,
  currentPortfolioValue: string,
  referenceYear?: number
): GoalProgress {
  const portfolioDec = new Dec(currentPortfolioValue || '0');
  const goalSavedDec = new Dec(goal.currentAmount || '0');

  // Use actual portfolio value when positive, or explicit goal currentAmount when standalone
  const effectiveCurrent = portfolioDec.gt(0) ? portfolioDec : goalSavedDec;
  const targetDec = new Dec(goal.targetAmount);

  if (targetDec.lte(0)) {
    throw new Error('Goal targetAmount must be greater than zero.');
  }

  const hundred = new Dec(100);
  const zero = new Dec(0);

  const rawPct = effectiveCurrent.dividedBy(targetDec).times(hundred);
  const clampedPct = Decimal.min(hundred, Decimal.max(zero, rawPct));

  const nowYear = referenceYear ?? new Date().getFullYear();
  const yearsRemaining = Math.max(0, goal.targetYear - nowYear);

  let onTrack = false;
  if (effectiveCurrent.gte(targetDec)) {
    onTrack = true;
  } else {
    try {
      const yearsNeededStr = calculateYearsToFIRE(
        effectiveCurrent.toFixed(4),
        goal.monthlyContribution,
        targetDec.toFixed(4),
        goal.expectedReturn,
        goal.inflationRate
      );
      const yearsNeeded = new Dec(yearsNeededStr);
      onTrack = yearsNeeded.lte(new Dec(yearsRemaining));
    } catch {
      onTrack = false;
    }
  }

  return {
    goalId: goal.id,
    currentAmount: effectiveCurrent
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2),
    targetAmount: targetDec.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
    progressPct: clampedPct.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
    yearsRemaining,
    onTrack,
  };
}
