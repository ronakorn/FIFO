import Decimal from 'decimal.js';
import { calculateFIFO } from '../fifoEngine';
import { parseDividends } from '../parsers/dividendParser';
import { BASE_CURRENCY, Transaction } from '../types';
import { enrichDividendsWithFX } from './dividendEnricher';
import { MockFXRateProvider } from './fxRateService';
import { calculateProgressivePIT, calculateThaiTax } from './thaiTaxEngine';

describe('FIFO Wealth OS - Phase 4 Thai Tax Compliance Engine', () => {
  describe('Excel Baseline Tax Verification (Symbol A + Dividends)', () => {
    const baselineBuys: Transaction[] = [
      {
        id: 'LOT-1',
        date: '2024-10-01',
        symbol: 'A',
        qty: 1.0,
        price: 100.0,
        gross: 100.0,
        comm: 0,
        vat: 0,
        net: 100.0,
        type: 'BUY',
        exchange: 'IBKR',
        originalCurrency: 'THB',
        originalNet: '100.00',
        fxRate: '1.00',
        netTHB: '100.00',
      },
      {
        id: 'LOT-7',
        date: '2024-10-07',
        symbol: 'A',
        qty: 1.0,
        price: 100.0,
        gross: 100.0,
        comm: 0.3271,
        vat: 0.0229,
        net: 100.35,
        type: 'BUY',
        exchange: 'IBKR',
        originalCurrency: 'THB',
        originalNet: '100.35',
        fxRate: '1.00',
        netTHB: '100.35',
      },
      {
        id: 'LOT-9',
        date: '2024-10-09',
        symbol: 'A',
        qty: 1.0,
        price: 100.0,
        gross: 100.0,
        comm: 0.3271,
        vat: 0.0229,
        net: 100.35,
        type: 'BUY',
        exchange: 'IBKR',
        originalCurrency: 'THB',
        originalNet: '100.35',
        fxRate: '1.00',
        netTHB: '100.35',
      },
    ];

    const baselineSells: Transaction[] = [
      {
        id: 'SELL-1',
        date: '2024-10-01',
        symbol: 'A',
        qty: 3.0,
        price: 109.0,
        gross: 327.0,
        comm: 1.2056,
        vat: 0.0844,
        net: 325.71,
        type: 'SELL',
        exchange: 'IBKR',
        originalCurrency: 'THB',
        originalNet: '325.71',
        fxRate: '1.00',
        netTHB: '325.71',
      },
    ];

    const baselineDividendCSV = `
      Date,Symbol,Qty,Div/Share,Gross,Tax,Net
      2024-10-15,A,3,1.02,3.06,0.93,2.13
    `;

    it('matches hand-calculated Excel Baseline: Capital Gains 25.01 + Dividend Gross 3.06 = 28.07 THB, WHT = 0.93 THB', async () => {
      const fifoResult = calculateFIFO(baselineBuys, baselineSells, { A: 20.0 });
      expect(fifoResult.totalRealizedGL).toBe(25.01);

      const rawDividends = parseDividends(baselineDividendCSV);
      const fxProvider = new MockFXRateProvider();
      const enrichedDividends = await enrichDividendsWithFX(
        rawDividends,
        fxProvider,
        BASE_CURRENCY
      );

      expect(enrichedDividends).toHaveLength(1);
      expect(enrichedDividends[0]).toMatchObject({
        symbol: 'A',
        grossTHB: '3.06',
        whtTHB: '0.93',
        netTHB: '2.13',
      });

      const taxReport = calculateThaiTax(fifoResult, enrichedDividends, 2024, {
        generatedAt: '2024-12-31T23:59:59.000Z',
      });

      expect(taxReport.taxYear).toBe(2024);
      expect(taxReport.capitalGains).toHaveLength(3);
      expect(taxReport.dividends).toHaveLength(1);

      // Dividend event check: Net = 2.13, Gross Taxable = 3.06, WHT = 0.93
      expect(taxReport.dividends[0]).toMatchObject({
        type: 'DIVIDEND',
        symbol: 'A',
        amountTHB: '2.13',
        taxableIncome: '3.06',
        taxWithheld: '0.93',
      });

      // Exact Excel Baseline Summary assertions
      expect(taxReport.totalTaxableIncome).toBe('28.07');
      expect(taxReport.totalTaxWithheld).toBe('0.93');
      // 28.07 THB is within 0 - 150,000 THB (0% exempt bracket), so net payable = 0.00 - 0.93 = -0.93 (refundable)
      expect(taxReport.totalTaxPayable).toBe('-0.93');
    });
  });

  describe('Dividend Parser & Multi-Currency FX Enricher', () => {
    it('parses USD Dividends and enriches Gross, WHT, and Net to THB via Decimal without rounding drift', async () => {
      const usdDividendCSV = `
        Date,Symbol,Qty,Div/Share,Gross,Tax,Net,Currency
        2024-10-01,AAPL,10,0.25,2.50,0.375,2.125,USD
      `;

      const parsed = parseDividends(usdDividendCSV);
      expect(parsed[0]).toMatchObject({
        symbol: 'AAPL',
        qty: 10,
        divPerShare: '0.25',
        gross: '2.50',
        whtRate: 0.15,
        wht: '0.375',
        net: '2.125',
        originalCurrency: 'USD',
      });

      const fxProvider = new MockFXRateProvider(); // 2024-10-01 USD/THB = '36.75'
      const enriched = await enrichDividendsWithFX(parsed, fxProvider, 'THB');

      // Hand calculation:
      // Gross THB = 2.50 * 36.75 = 91.875
      // WHT THB   = 0.375 * 36.75 = 13.78125
      // Net THB   = 2.125 * 36.75 = 78.09375
      expect(enriched[0]).toMatchObject({
        fxRate: '36.75',
        grossTHB: '91.875',
        whtTHB: '13.78125',
        netTHB: '78.09375',
      });
    });
  });

  describe('Thai Revenue Code Rules & Progressive Tax Brackets (0% - 35%)', () => {
    it('exempts SET-listed Thai Equity capital gains while taxing Crypto & remitted Foreign Equity', () => {
      const fifoResult = {
        lots: [
          {
            id: 'PTT-1',
            date: '2024-03-01',
            symbol: 'PTT',
            buyQty: 1000,
            costPerUnit: 30,
            qtySold: 1000,
            qtyRemain: 0,
            realizedGL: 50000, // Exempt SET stock!
            unrealizedGL: 0,
            status: 'Sold' as const,
          },
          {
            id: 'AAPL-UNREMITTED',
            date: '2024-04-01',
            symbol: 'AAPL',
            buyQty: 10,
            costPerUnit: 5000,
            qtySold: 10,
            qtyRemain: 0,
            realizedGL: 20000, // Kept offshore (not remitted in 2024) -> Exempt in 2024!
            unrealizedGL: 0,
            status: 'Sold' as const,
          },
          {
            id: 'BTC-1',
            date: '2024-05-01',
            symbol: 'BTC',
            buyQty: 0.5,
            costPerUnit: 1000000,
            qtySold: 0.5,
            qtyRemain: 0,
            realizedGL: 200000, // Crypto -> Taxable under Sec. 40(4)(h)!
            unrealizedGL: 0,
            status: 'Sold' as const,
          },
        ],
        totalRealizedGL: 270000,
        totalUnrealizedGL: 0,
        totalCostSold: 580000,
        totalProceeds: 850000,
      };

      const report = calculateThaiTax(fifoResult, [], 2024, {
        symbolProfiles: {
          PTT: { category: 'THAI_EQUITY' },
          AAPL: { category: 'FOREIGN_EQUITY', remittedToThailand: false },
          BTC: { category: 'CRYPTO' },
        },
      });

      // Only BTC's 200,000 THB is assessable:
      // 0 - 150,000 => 0 THB
      // 150,001 - 200,000 (50,000 @ 5%) => 2,500.00 THB
      expect(report.totalTaxableIncome).toBe('200000.00');
      expect(report.totalTaxPayable).toBe('2500.00');
    });

    it('calculates progressive PIT accurately across all brackets up to 35%', () => {
      // Hand calculation for 600,000 THB:
      // 0-150k: 0 | 150k-300k: 7,500 | 300k-500k: 20,000 | 500k-600k (100k @ 15%): 15,000 => Total = 42,500
      expect(calculateProgressivePIT(new Decimal('600000')).toFixed(2)).toBe('42500.00');

      // Hand calculation for 6,000,000 THB (reaches 35% top bracket):
      // Cumulative at 5,000,000 = 7,500 + 20,000 + 37,500 + 50,000 + 250,000 + 900,000 = 1,265,000
      // Excess above 5,000,000 = 1,000,000 * 35% = 350,000 => Total = 1,615,000.00
      expect(calculateProgressivePIT(new Decimal('6000000')).toFixed(2)).toBe('1615000.00');
    });

    it('supports Thai 10% Dividend Final Tax election (Sec. 48(3))', () => {
      const fifoResult = {
        lots: [],
        totalRealizedGL: 0,
        totalUnrealizedGL: 0,
        totalCostSold: 0,
        totalProceeds: 0,
      };

      const thaiDividends = [
        {
          id: 'DIV-PTT',
          date: '2024-09-01T00:00:00.000Z',
          symbol: 'PTT',
          qty: 10000,
          divPerShare: '2.00',
          gross: '20000.00',
          whtRate: 0.1,
          wht: '2000.00',
          net: '18000.00',
          originalCurrency: 'THB',
          fxRate: '1.00',
          grossTHB: '20000.00',
          whtTHB: '2000.00',
          netTHB: '18000.00',
        },
      ];

      // High-earner in 30% bracket (otherNetIncomeTHB = 2,500,000) elects Final Tax on 10% WHT dividend:
      const report = calculateThaiTax(fifoResult, thaiDividends, 2024, {
        otherNetIncomeTHB: '2500000.00',
        electFinalTaxOnDividends: true,
      });

      expect(report.totalTaxableIncome).toBe('0.00');
      expect(report.totalTaxPayable).toBe('0.00');
    });
  });
});
