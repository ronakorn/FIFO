import fs from 'fs';
import os from 'os';
import path from 'path';
import { execSync } from 'child_process';
import Decimal from 'decimal.js';
import request from 'supertest';
import { createApp } from '../api/app';
import { getPrismaClient, setPrismaClient } from '../db/prisma';
import {
  applyReverseSplit,
  applyStockSplit,
  detectCorporateActions,
} from './corporateActionEngine';
import {
  buildDividendCalendarReport,
  generateDividendCalendar,
  getUpcomingDividends,
} from './dividendCalendar';
import {
  calculateTaxSaving,
  calculateUnrealizedLoss,
  findHarvestingOpportunities,
  simulateHarvesting,
} from './taxLossHarvester';
import { Dividend, Lot } from '../types';
import { Portfolio } from '../types/shared';
import { CorporateAction, DividendForecast } from '../types/wave1';

describe('Wave 1 Features', () => {
  describe('Tax-Loss Harvesting', () => {
    it('คำนวณ Unrealized Loss ถูกต้อง (รวมถึงพอร์ต AAPL ขาดทุน 10,000 THB -> Tax Saving 2,000 THB)', () => {
      const loss = calculateUnrealizedLoss('150.00', '140.00', 100);
      expect(loss).toBe('1000.00');

      // AAPL ขาดทุน 10,000 THB @ อัตราภาษี 20% -> Tax Saving = 2,000.00 THB
      const aaplLoss = calculateUnrealizedLoss('500.00', '400.00', 100);
      expect(aaplLoss).toBe('10000.00');
      expect(calculateTaxSaving(aaplLoss, '0.20')).toBe('2000.00');

      // กรณีมีกำไรหรือเท่าทุน ต้องคืน 0.00 เสมอ
      expect(calculateUnrealizedLoss('140.00', '150.00', 100)).toBe('0.00');
      expect(calculateUnrealizedLoss('150.00', '150.00', 100)).toBe('0.00');
    });

    it('คำนวณ Tax Saving ถูกต้อง (อัตรา 20%)', () => {
      const saving = calculateTaxSaving('1000.00', '0.20');
      expect(saving).toBe('200.00');
    });

    it('ค้นหา Harvesting Opportunities และเรียงตาม Tax Saving (มาก -> น้อย) พร้อมตรวจสอบ Wash Sale Rule (< 30 วัน)', () => {
      const portfolio = [
        {
          symbol: 'AAPL',
          avgCost: '150.00',
          currentPrice: '140.00',
          qty: 100,
          daysHeld: 180,
        },
        {
          symbol: 'TSLA',
          avgCost: '250.00',
          currentPrice: '200.00',
          qty: 50,
          daysHeld: 25,
        },
      ];

      const opportunities = findHarvestingOpportunities(portfolio, '0.20');
      expect(opportunities).toHaveLength(2);
      // TSLA ขาดทุน 2,500 (Tax Saving 500.00) มากกว่า AAPL ขาดทุน 1,000 (Tax Saving 200.00) จึงเรียงอยู่ลำดับแรก [0]
      expect(opportunities[0]!.symbol).toBe('TSLA');
      expect(opportunities[0]!.taxSavingPotential).toBe('500.00');
      expect(opportunities[0]!.washSaleRisk).toBe(true); // TSLA ถือครอง 25 วัน (< 30 วัน)
      expect(opportunities[0]!.status).toBe('WASH_SALE_RISK');

      expect(opportunities[1]!.symbol).toBe('AAPL');
      expect(opportunities[1]!.taxSavingPotential).toBe('200.00');
      expect(opportunities[1]!.washSaleRisk).toBe(false); // AAPL ถือครอง 180 วัน (>= 30 วัน)
      expect(opportunities[1]!.status).toBe('AVAILABLE');
    });

    it('จำลอง Harvesting และคำนวณภาษีใหม่ พร้อมแจ้งเตือน Wash Sale Rule', () => {
      const opportunities = [
        {
          symbol: 'AAPL',
          lotId: '1',
          currentPrice: '140.00',
          avgCost: '150.00',
          unrealizedLoss: '1000.00',
          daysHeld: 180,
          taxSavingPotential: '200.00',
          marginalTaxRate: '0.20',
          washSaleRisk: false,
          status: 'AVAILABLE' as const,
        },
        {
          symbol: 'TSLA',
          lotId: '2',
          currentPrice: '200.00',
          avgCost: '250.00',
          unrealizedLoss: '2500.00',
          daysHeld: 25,
          taxSavingPotential: '500.00',
          marginalTaxRate: '0.20',
          washSaleRisk: true,
          status: 'WASH_SALE_RISK' as const,
        },
      ];

      const simulation = simulateHarvesting(opportunities, '5000.00');
      expect(simulation.totalTaxSaving).toBe('200.00');
      expect(simulation.newTaxLiability).toBe('4800.00');
      expect(simulation.harvestedLots).toEqual(['1']);
      expect(simulation.washSaleWarnings).toEqual([
        'TSLA: ถือครองไม่ถึง 30 วัน เสี่ยง Wash Sale Rule',
      ]);
    });

    it('รองรับการสแกนจาก Portfolio FIFO Open Lots โดยตรง', () => {
      const fifoPortfolio: Portfolio = {
        id: 'port-fifo-1',
        userId: 'user-1',
        name: 'FIFO Portfolio',
        baseCurrency: 'THB',
        createdAt: '2026-01-01T00:00:00.000Z',
        fifoSummary: {
          totalRealizedGL: 0,
          totalUnrealizedGL: -10000,
          totalCostSold: 0,
          totalProceeds: 0,
          openCostBasisTHB: 50000,
          marketValueTHB: 40000,
          lots: [
            {
              id: 'lot-aapl-fifo',
              date: '2026-03-01',
              symbol: 'AAPL',
              buyQty: 100,
              costPerUnit: 500,
              qtySold: 0,
              qtyRemain: 100,
              realizedGL: 0,
              unrealizedGL: -10000,
              status: 'Hold',
            },
          ],
        },
      };

      const res = findHarvestingOpportunities(
        fifoPortfolio,
        { AAPL: '400.00' },
        { marginalTaxRate: '0.20', referenceDate: '2026-10-26' }
      );
      expect(res).toHaveLength(1);
      expect(res[0]!.unrealizedLoss).toBe('10000.00');
      expect(res[0]!.taxSavingPotential).toBe('2000.00');
    });
  });

  describe('Corporate Actions', () => {
    it('ปรับ Stock Split 2:1 ถูกต้อง (100 หุ้น @ 200 THB -> 200 หุ้น @ 100.0000 THB มูลค่ารวม 20,000 เท่าเดิม และไม่รีเซ็ตวันถือครอง)', () => {
      const lots = [
        {
          id: '1',
          symbol: 'AAPL',
          qty: 100,
          costPerUnit: '200.00',
          date: '2024-01-01',
        },
        {
          id: '2',
          symbol: 'AAPL',
          qty: 20,
          costPerUnit: '105.00',
          date: '2024-07-01', // ซื้อหลังวันแตกพาร์ -> ต้องไม่ถูกคูณซ้ำ
        },
      ];
      const action: CorporateAction = {
        id: '1',
        symbol: 'AAPL',
        type: 'STOCK_SPLIT',
        ratio: 2.0,
        effectiveDate: '2024-06-01',
        announcementDate: '2024-05-01',
        adjustmentFactor: 0.5,
        description: 'Test Split',
      };

      const updated = applyStockSplit(lots, action);
      expect(updated[0]!.qty).toBe(200);
      expect(updated[0]!.costPerUnit).toBe('100.0000');
      expect(
        new Decimal(updated[0]!.qty).times(updated[0]!.costPerUnit).toFixed(2)
      ).toBe('20000.00');
      expect(updated[0]!.date).toBe('2024-01-01');

      // Lot ที่ซื้อหลัง effectiveDate คงเดิม
      expect(updated[1]!.qty).toBe(20);
      expect(updated[1]!.costPerUnit).toBe('105.00');
    });

    it('ปรับ Reverse Split 1:10 ถูกต้อง และค้นหา Mock Corporate Actions ได้', () => {
      const lots = [
        {
          id: '1',
          symbol: 'XYZ',
          qty: 1000,
          costPerUnit: '10.00',
          date: '2024-01-01',
        },
      ];
      const action: CorporateAction = {
        id: '1',
        symbol: 'XYZ',
        type: 'REVERSE_SPLIT',
        ratio: 10.0,
        effectiveDate: '2024-06-01',
        announcementDate: '2024-05-01',
        adjustmentFactor: 10.0,
        description: 'Test Reverse Split',
      };

      const updated = applyReverseSplit(lots, action);
      expect(updated[0]!.qty).toBe(100);
      expect(updated[0]!.costPerUnit).toBe('100.0000');
      expect(updated[0]!.date).toBe('2024-01-01');

      // ทดสอบบน FIFOLot ของ Core Engine ด้วย
      const fifoLots: Lot[] = [
        {
          id: 'fifo-1',
          date: '2026-01-15',
          symbol: 'NVDA',
          buyQty: 100,
          costPerUnit: 200,
          qtySold: 0,
          qtyRemain: 100,
          realizedGL: 0,
          unrealizedGL: 0,
          status: 'Hold',
        },
      ];
      const fifoSplit = applyStockSplit(fifoLots, {
        id: 'ca-nvda',
        symbol: 'NVDA',
        type: 'STOCK_SPLIT',
        ratio: 2,
        effectiveDate: '2026-10-15',
        adjustmentFactor: 0.5,
      });
      expect(fifoSplit[0]!.buyQty).toBe(200);
      expect(fifoSplit[0]!.costPerUnit).toBe(100);

      const detected2020 = detectCorporateActions('AAPL', {
        start: '2020-01-01',
        end: '2020-12-31',
      });
      expect(detected2020[0]!.id).toBe('CA-001');
    });
  });

  describe('Dividend Calendar', () => {
    it('สร้างปฏิทินปันผลรายเดือนถูกต้อง และคำนวณรวม 12 เดือน 120,000 THB -> เฉลี่ย 10,000.00 THB/เดือน', () => {
      const dividends = [
        {
          symbol: 'AAPL',
          exDate: '2026-02-07',
          payDate: '2026-02-13',
          amountPerShare: '0.24',
          currency: 'USD',
          estimatedTHB: '850.00',
          frequency: 'QUARTERLY' as const,
        },
        {
          symbol: 'MSFT',
          exDate: '2026-02-19',
          payDate: '2026-03-14',
          amountPerShare: '0.75',
          currency: 'USD',
          estimatedTHB: '2650.00',
          frequency: 'QUARTERLY' as const,
        },
      ];

      const calendar = generateDividendCalendar(dividends, 2026);
      expect(calendar).toHaveLength(12);
      expect(calendar[1]!.totalDividends).toBe('850.00'); // กุมภาพันธ์ (index 1 = month 2)
      expect(calendar[2]!.totalDividends).toBe('2650.00'); // มีนาคม (index 2 = month 3)

      // ทดสอบรวมปันผลทั้งปี 120,000 THB -> Average Monthly = 10,000.00 THB
      const actuals: Dividend[] = [
        {
          id: 'd1',
          date: '2026-01-20',
          symbol: 'PTT',
          qty: 10000,
          divPerShare: '6.00',
          gross: '60000.00',
          whtRate: 0,
          wht: '0.00',
          net: '60000.00',
          originalCurrency: 'THB',
          fxRate: '1.00',
          grossTHB: '60000.00',
          whtTHB: '0.00',
          netTHB: '60000.00',
        },
      ];
      const forecasts: DividendForecast[] = [
        {
          symbol: 'ADVANC',
          exDate: '2026-11-05',
          payDate: '2026-11-20',
          amountPerShare: '6.00',
          sharesHeld: 10000,
          currency: 'THB',
          fxRate: '1.00',
        },
      ];
      const merged = generateDividendCalendar(actuals, forecasts);
      const report = buildDividendCalendarReport(
        merged,
        2026,
        '2026-10-26',
        30
      );
      expect(report.yearlyDividendTHB).toBe('120000.00');
      expect(report.averageMonthlyTHB).toBe('10000.00');

      const upcoming = getUpcomingDividends(merged, 30, '2026-10-26');
      expect(upcoming).toHaveLength(1);
      expect(upcoming[0]!.symbol).toBe('ADVANC');
    });
  });

  describe('Wave 1 REST API Endpoints (Supertest Integration)', () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fifo-wave1-api-'));
    const testDbPath = path.join(tmpDir, 'wave1.db');
    let token = '';
    let portfolioId = '';

    beforeAll(async () => {
      process.env['DATABASE_URL'] = `file:${testDbPath}`;
      process.env['JWT_SECRET'] = 'wave1-supertest-secret-key';
      setPrismaClient(null);

      execSync('npx prisma db push --skip-generate --accept-data-loss', {
        cwd: path.resolve(__dirname, '../..'),
        env: { ...process.env, DATABASE_URL: `file:${testDbPath}` },
        stdio: 'pipe',
      });

      const app = createApp();
      const regRes = await request(app).post('/api/auth/register').send({
        email: 'wave1@wealthos.th',
        password: 'Password123!',
        name: 'Wave 1 Investor',
      });
      expect(regRes.status).toBe(201);
      token = regRes.body.token as string;

      const portRes = await request(app)
        .post('/api/portfolios')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'Wave 1 Test Portfolio', baseCurrency: 'THB' });
      expect(portRes.status).toBe(201);
      portfolioId = portRes.body.id as string;

      await getPrismaClient().transaction.create({
        data: {
          portfolioId,
          date: '2026-02-15',
          symbol: 'AAPL',
          type: 'BUY',
          qty: 100,
          price: 500,
          gross: '50000.00',
          comm: '0.00',
          vat: '0.00',
          net: '50000.00',
          originalCurrency: 'THB',
          fxRate: '1.00',
          netTHB: '50000.00',
        },
      });
    });

    afterAll(async () => {
      await getPrismaClient().$disconnect();
      setPrismaClient(null);
      fs.rmSync(tmpDir, { recursive: true, force: true });
    });

    it('GET /api/tax-loss-harvesting/opportunities & POST /api/tax-loss-harvesting/simulate', async () => {
      const app = createApp();
      const oppRes = await request(app)
        .get('/api/tax-loss-harvesting/opportunities')
        .query({
          portfolioId,
          marginalTaxRate: '0.20',
          currentPrices: JSON.stringify({ AAPL: '400.00' }),
        })
        .set('Authorization', `Bearer ${token}`);

      expect(oppRes.status).toBe(200);
      expect(oppRes.body.opportunities).toHaveLength(1);
      expect(oppRes.body.opportunities[0].symbol).toBe('AAPL');
      expect(oppRes.body.opportunities[0].unrealizedLoss).toBe('10000.00');
      expect(oppRes.body.opportunities[0].taxSavingPotential).toBe('2000.00');

      const simRes = await request(app)
        .post('/api/tax-loss-harvesting/simulate')
        .set('Authorization', `Bearer ${token}`)
        .send({
          opportunities: oppRes.body.opportunities,
          currentTaxLiability: '15000.00',
        });

      expect(simRes.status).toBe(200);
      expect(simRes.body.simulation.totalTaxSaving).toBe('2000.00');
      expect(simRes.body.simulation.newTaxLiability).toBe('13000.00');
    });

    it('GET /api/corporate-actions & POST /api/corporate-actions/apply', async () => {
      const app = createApp();
      const histRes = await request(app)
        .get('/api/corporate-actions')
        .query({
          symbol: 'AAPL',
          startDate: '2020-01-01',
          endDate: '2020-12-31',
        })
        .set('Authorization', `Bearer ${token}`);

      expect(histRes.status).toBe(200);
      expect(histRes.body.actions).toHaveLength(1);
      expect(histRes.body.actions[0].id).toBe('CA-001');

      const inlineApplyRes = await request(app)
        .post('/api/corporate-actions/apply')
        .set('Authorization', `Bearer ${token}`)
        .send({
          actionId: 'CA-001',
          lots: [
            {
              id: 'lot-1',
              symbol: 'AAPL',
              qty: 100,
              costPerUnit: '200.0000',
              date: '2020-05-01',
            },
          ],
        });
      expect(inlineApplyRes.status).toBe(200);
      expect(inlineApplyRes.body.updatedLots[0].qty).toBe(400);
      expect(inlineApplyRes.body.updatedLots[0].costPerUnit).toBe('50.0000');

      const dbApplyRes = await request(app)
        .post('/api/corporate-actions/apply')
        .set('Authorization', `Bearer ${token}`)
        .send({ actionId: 'ca-aapl-split-2026', portfolioId });

      expect(dbApplyRes.status).toBe(200);
      expect(dbApplyRes.body.totalCostBeforeTHB).toBe('50000.00');
      expect(dbApplyRes.body.totalCostAfterTHB).toBe('50000.00');
      expect(dbApplyRes.body.updatedLots[0].buyQty).toBe(400);
      expect(dbApplyRes.body.updatedLots[0].costPerUnit).toBe(125);
    });

    it('GET /api/dividend-calendar returns { calendar, upcoming } & 12-month Jan-Dec breakdown', async () => {
      const app = createApp();
      const calRes = await request(app)
        .get('/api/dividend-calendar')
        .query({ portfolioId, year: 2026 })
        .set('Authorization', `Bearer ${token}`);

      expect(calRes.status).toBe(200);
      expect(calRes.body.year).toBe(2026);
      expect(calRes.body.calendar).toHaveLength(12);
      expect(Array.isArray(calRes.body.upcoming)).toBe(true);
      expect(calRes.body.monthlyIncome).toHaveLength(12);
    });
  });
});
