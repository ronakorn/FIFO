import {
  BrinsonDecimal,
  buildPortfolioGoldBrinsonReport,
  calculateGtaGold965Parity,
  calculateMultiplicativeBrinsonAttribution,
  calculateRealizedBrinsonAttributions,
  calculateThaiGold965GtaAttribution,
  calculateUnrealizedBrinsonAttributions,
} from './goldBrinsonAttribution';
import {
  buildGoldMarketEnvironment,
  calculateGoldFIFO,
} from './goldEngine';
import { calculateGoldFXSensitivities } from './goldFxSensitivityEngine';
import { GoldTransaction } from '../types/gold';

describe('Multiplicative Brinson Attribution Engine for Thai & Global Gold (Decimal.js precision: 40)', () => {
  describe('1. Exact Multiplicative Identity: (1 + R_total) = (1 + R_gold) × (1 + R_fx)', () => {
    it('decomposes Bullish Gold (+10%) + Weakening THB (+5%) with 0.00 THB residual ("ทองโลกวิ่งขึ้น" + "บาทอ่อนค่า")', () => {
      const res = calculateMultiplicativeBrinsonAttribution({
        symbol: 'XAUUSD',
        assetSubclass: 'XAU_SPOT',
        costBasisTHB: '340000.00', // 4 Oz * $2,500 * 34.00 THB
        entryXauUsd: '2500.00',
        currentXauUsd: '2750.00', // +10%
        entryUsdThb: '34.00',
        currentUsdThb: '35.70', // +5%
      });

      // (1 + 0.10) * (1 + 0.05) = 1.155 -> R_total = +15.50%
      expect(res.goldReturnRatio).toBe('0.100000');
      expect(res.fxReturnRatio).toBe('0.050000');
      expect(res.totalReturnRatio).toBe('0.155000');

      // Gold Price Contribution = 340,000 * 0.10 = 34,000.00 THB
      expect(res.goldPriceContributionTHB).toBe('34000.00');
      // FX Contribution = (340,000 + 34,000) * 0.05 = 374,000 * 0.05 = 18,700.00 THB
      expect(res.fxContributionTHB).toBe('18700.00');
      // Total G/L = 340,000 * 0.155 = 52,700.00 THB
      expect(res.totalGLTHB).toBe('52700.00');

      const sumContrib = new BrinsonDecimal(res.goldPriceContributionTHB).plus(
        res.fxContributionTHB
      );
      expect(sumContrib.toFixed(2)).toBe(res.totalGLTHB);
      expect(res.unexplainedResidualTHB).toBe('0.00');
      expect(res.isZeroResidualVerified).toBe(true);
      expect(res.goldDriverLabelTH).toBe('ทองโลกวิ่งขึ้น');
      expect(res.fxDriverLabelTH).toBe('บาทอ่อนค่า');
    });

    it('captures the classic Thai Gold headwind: World Gold Rallies (+4%) while THB Strengthens (-6%) -> Net Loss explained to the satang', () => {
      const res = calculateMultiplicativeBrinsonAttribution({
        symbol: 'GOLD965',
        assetSubclass: 'PHYSICAL_GOLD',
        costBasisTHB: '415000.00',
        entryXauUsd: '2600.00',
        currentXauUsd: '2704.00', // +4.00% World Gold Rally
        entryUsdThb: '36.50',
        currentUsdThb: '34.31', // -6.00% THB Strengthening (บาทแข็งค่า)
      });

      // (1 + 0.04) * (1 - 0.06) = 1.04 * 0.94 = 0.9776 -> R_total = -0.0224 (-2.24%)
      expect(res.goldReturnRatio).toBe('0.040000');
      expect(res.fxReturnRatio).toBe('-0.060000');
      expect(res.totalReturnRatio).toBe('-0.022400');

      // Gold Price Contribution = 415,000 * 0.04 = +16,600.00 THB ("ทองโลกวิ่งขึ้น")
      expect(res.goldPriceContributionTHB).toBe('16600.00');
      // FX Contribution = (415,000 + 16,600) * (-0.06) = 431,600 * (-0.06) = -25,896.00 THB ("บาทแข็งค่า")
      expect(res.fxContributionTHB).toBe('-25896.00');
      // Net Total G/L = 16,600.00 - 25,896.00 = -9,296.00 THB
      expect(res.totalGLTHB).toBe('-9296.00');

      const sumContrib = new BrinsonDecimal(res.goldPriceContributionTHB).plus(
        res.fxContributionTHB
      );
      expect(sumContrib.toFixed(2)).toBe(res.totalGLTHB);
      expect(res.unexplainedResidualTHB).toBe('0.00');
      expect(res.goldDriverLabelTH).toBe('ทองโลกวิ่งขึ้น');
      expect(res.fxDriverLabelTH).toBe('บาทแข็งค่า');
      expect(res.primaryDriver).toBe('FX_IMPACT');
    });

    it('captures World Gold Pullback (-5%) cushioned by THB Weakening (+8%) -> Net Gain explained 100%', () => {
      const res = calculateMultiplicativeBrinsonAttribution({
        symbol: 'GOZ26',
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        costBasisTHB: '250000.00',
        entryXauUsd: '2800.00',
        currentXauUsd: '2660.00', // -5.00%
        entryUsdThb: '33.50',
        currentUsdThb: '36.18', // +8.00%
      });

      // (1 - 0.05) * (1 + 0.08) = 0.95 * 1.08 = 1.026 -> +2.60%
      expect(res.goldPriceContributionTHB).toBe('-12500.00');
      // (250,000 - 12,500) * 0.08 = 237,500 * 0.08 = +19,000.00
      expect(res.fxContributionTHB).toBe('19000.00');
      expect(res.totalGLTHB).toBe('6500.00');

      const sum = new BrinsonDecimal(res.goldPriceContributionTHB).plus(
        res.fxContributionTHB
      );
      expect(sum.toFixed(2)).toBe(res.totalGLTHB);
      expect(res.goldDriverLabelTH).toBe('ทองโลกย่อตัว');
      expect(res.fxDriverLabelTH).toBe('บาทอ่อนค่า');
    });
  });

  describe('2. Thai Gold 96.5% GTA Parity Complexity: (XAU/USD) × (15.244 / 31.1034768) × 0.965 × (USD/THB)', () => {
    it('computes exact GTA 96.5% Theoretical Parity with 40-digit Decimal precision and separates Domestic Association Spread', () => {
      const parity = calculateGtaGold965Parity({
        xauUsdSpot: '2740.00',
        usdThbRate: '35.60',
        gtaAssociationSellTHB: '46450.00',
      });

      // Manual 40-digit verification: 2740 * (15.244 / 31.1034768) * 0.965 * 35.60
      const expectedRaw = new BrinsonDecimal('2740')
        .times('15.244')
        .dividedBy('31.1034768')
        .times('0.965')
        .times('35.60');

      expect(parity.rawGtaParityPriceTHB).toBe(expectedRaw.toString());
      expect(parity.gtaParityPriceTHB).toBe('46133.66');
      expect(parity.domesticPremiumTHB).toBe('316.34');
    });

    it('decomposes Thai 96.5% Gold Bullion (both Pure GTA Parity and Quoted GTA + Block Premium) with Zero Unexplained Residual', () => {
      // Case A: Pure GTA Theoretical Parity (10 บาททองคำ)
      const pureGta = calculateThaiGold965GtaAttribution({
        symbol: 'GOLD965',
        weightBaht965: '10.0000',
        entryXauUsd: '2450.00',
        currentXauUsd: '2740.00',
        entryUsdThb: '34.20',
        currentUsdThb: '35.60',
      });

      const pureSum = new BrinsonDecimal(
        pureGta.attribution.goldPriceContributionTHB
      ).plus(pureGta.attribution.fxContributionTHB);
      expect(pureSum.toFixed(2)).toBe(pureGta.attribution.totalGLTHB);
      expect(pureGta.attribution.unexplainedResidualTHB).toBe('0.00');
      expect(pureGta.attribution.isZeroResidualVerified).toBe(true);

      // Verify R_gold matches pure XAU/USD return (2740 - 2450) / 2450 to 6 dp
      const expectedRGold = new BrinsonDecimal('2740')
        .minus('2450')
        .dividedBy('2450')
        .toFixed(6);
      expect(pureGta.attribution.goldReturnRatio).toBe(expectedRGold);

      // Case B: Actual Thai Gold Shop Quote + Block Premium (ค่าบล็อก 250 บาท/บาททองคำ)
      const shopGta = calculateThaiGold965GtaAttribution({
        symbol: 'GOLD965',
        weightBaht965: '8.0000',
        entryXauUsd: '2450.00',
        currentXauUsd: '2740.00',
        entryUsdThb: '34.20',
        currentUsdThb: '35.60',
        entryQuotedPricePerBahtTHB: '40200.00',
        currentQuotedPricePerBahtTHB: '46450.00',
        blockPremiumPerBahtTHB: '250.00',
      });

      // Cost = 8 * (40200 + 250) = 323,600.00 THB; Market = 8 * 46450 = 371,600.00 THB; G/L = +48,000.00 THB
      expect(shopGta.attribution.costBasisTHB).toBe('323600.00');
      expect(shopGta.attribution.endingValueTHB).toBe('371600.00');
      expect(shopGta.attribution.totalGLTHB).toBe('48000.00');

      const shopSum = new BrinsonDecimal(
        shopGta.attribution.goldPriceContributionTHB
      ).plus(shopGta.attribution.fxContributionTHB);
      expect(shopSum.toFixed(2)).toBe('48000.00');
      expect(shopGta.attribution.unexplainedResidualTHB).toBe('0.00');
    });
  });

  describe('3. Full FIFO Portfolio Proof: Unrealized G/L AND Realized G/L === Gold Contribution + FX Contribution', () => {
    const createdAt = new Date('2026-10-01T09:00:00Z');
    const ledger: GoldTransaction[] = [
      {
        id: 'tx-965-buy',
        portfolioId: 'p-brinson',
        date: '2026-03-15',
        symbol: 'GOLD965',
        assetSubclass: 'PHYSICAL_GOLD',
        weight: '10.0000',
        weightUnit: 'THAI_BAHT',
        purity: '96.5',
        spotPricePerUnit: '40200.00',
        premiumPerUnit: '250.00',
        commission: '0.00',
        totalCost: '404500.00',
        fxRateAtPurchase: '34.20',
        type: 'BUY',
        createdAt,
      },
      {
        id: 'tx-965-sell',
        portfolioId: 'p-brinson',
        date: '2026-07-20',
        symbol: 'GOLD965',
        assetSubclass: 'PHYSICAL_GOLD',
        weight: '2.0000',
        weightUnit: 'THAI_BAHT',
        purity: '96.5',
        spotPricePerUnit: '43500.00',
        premiumPerUnit: '0.00',
        commission: '0.00',
        totalCost: '87000.00', // Realized G/L = 87,000 - (2 * 40,450) = +6,100.00 THB
        fxRateAtPurchase: '35.10',
        type: 'SELL',
        createdAt,
      },
      {
        id: 'tx-9999-buy',
        portfolioId: 'p-brinson',
        date: '2026-05-10',
        symbol: 'GOLD9999',
        assetSubclass: 'PHYSICAL_GOLD',
        weight: '76.2200', // Fractional gram weight testing 40-digit cost basis
        weightUnit: 'GRAM',
        purity: '99.99',
        spotPricePerUnit: '2760.00',
        premiumPerUnit: '18.00',
        commission: '150.00',
        totalCost: '211829.16',
        fxRateAtPurchase: '34.50',
        type: 'BUY',
        createdAt,
      },
      {
        id: 'tx-xau-buy',
        portfolioId: 'p-brinson',
        date: '2026-06-12',
        symbol: 'XAUUSD',
        assetSubclass: 'XAU_SPOT',
        weight: '4.0000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.99',
        spotPricePerUnit: '2460.00',
        premiumPerUnit: '1.50',
        commission: '8.00',
        totalCost: '9854.00',
        fxRateAtPurchase: '34.40',
        type: 'BUY',
        createdAt,
      },
      {
        id: 'tx-xau-sell',
        portfolioId: 'p-brinson',
        date: '2026-09-10',
        symbol: 'XAUUSD',
        assetSubclass: 'XAU_SPOT',
        weight: '1.5000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.99',
        spotPricePerUnit: '2695.00',
        premiumPerUnit: '0.00',
        commission: '5.00',
        totalCost: '4037.50', // USD proceeds @ FX 33.85 (บาทแข็งค่าตอนขาย!)
        fxRateAtPurchase: '33.85',
        type: 'SELL',
        createdAt,
      },
      {
        id: 'tx-goz26-buy',
        portfolioId: 'p-brinson',
        date: '2026-08-18',
        symbol: 'GOZ26',
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        weight: '3.0000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        spotPricePerUnit: '2580.00',
        premiumPerUnit: '2.00',
        commission: '6.00',
        totalCost: '7752.00',
        fxRateAtPurchase: '34.75',
        type: 'BUY',
        createdAt,
      },
    ];

    const market = buildGoldMarketEnvironment({
      xauUsdSpot: '2740.00',
      usdThbRate: '35.60',
      gtaGold965SellTHB: '46450.00',
    });

    it('proves Unrealized Gold Contribution + FX Contribution === FIFO Lot Unrealized G/L (100% exact per symbol & portfolio)', () => {
      const fifo = calculateGoldFIFO(ledger, market);
      const unrealized = calculateUnrealizedBrinsonAttributions(
        fifo.lots,
        ledger,
        market
      );
      const sensitivities = calculateGoldFXSensitivities(
        fifo.lots,
        ledger,
        market
      );

      expect(unrealized.items).toHaveLength(4);
      expect(sensitivities).toHaveLength(4);

      for (const item of unrealized.items) {
        const lotMatch = fifo.lots.find((l) => l.symbol === item.symbol)!;
        expect(item.totalGLTHB).toBe(lotMatch.unrealizedGL);

        const sum = new BrinsonDecimal(item.goldPriceContributionTHB).plus(
          item.fxContributionTHB
        );
        expect(sum.toFixed(2)).toBe(item.totalGLTHB);
        expect(item.unexplainedResidualTHB).toBe('0.00');
        expect(item.isZeroResidualVerified).toBe(true);
      }

      // Portfolio Unrealized Summary matches FIFO totalUnrealizedGLTHB to the exact satang
      expect(unrealized.summary.totalGLTHB).toBe(fifo.totalUnrealizedGLTHB);
      const portfolioSum = new BrinsonDecimal(
        unrealized.summary.goldPriceContributionTHB
      ).plus(unrealized.summary.fxContributionTHB);
      expect(portfolioSum.toFixed(2)).toBe(fifo.totalUnrealizedGLTHB);
      expect(unrealized.summary.unexplainedResidualTHB).toBe('0.00');
    });

    it('proves Realized Gold Contribution + FX Contribution === FIFO Realized G/L (100% exact per symbol & portfolio)', () => {
      const fifo = calculateGoldFIFO(ledger, market);
      const realized = calculateRealizedBrinsonAttributions(
        ledger,
        market.usdThbRate
      );
      const fullReport = buildPortfolioGoldBrinsonReport(
        fifo.lots,
        ledger,
        market
      );

      expect(realized.items).toHaveLength(2); // GOLD965 and XAUUSD had SELL legs
      expect(fullReport.realizedItems).toHaveLength(2);

      for (const item of realized.items) {
        const lotMatch = fifo.lots.find((l) => l.symbol === item.symbol)!;
        expect(item.totalGLTHB).toBe(lotMatch.realizedGL);

        const sum = new BrinsonDecimal(item.goldPriceContributionTHB).plus(
          item.fxContributionTHB
        );
        expect(sum.toFixed(2)).toBe(item.totalGLTHB);
        expect(item.unexplainedResidualTHB).toBe('0.00');
        expect(item.isZeroResidualVerified).toBe(true);
      }

      // Verify XAUUSD realized sale where world gold rose ($2460->$2695) while THB strengthened (34.40->33.85)
      const xauRealized = realized.items.find((i) => i.symbol === 'XAUUSD')!;
      expect(xauRealized.goldDriverLabelTH).toBe('ทองโลกวิ่งขึ้น');
      expect(xauRealized.fxDriverLabelTH).toBe('บาทแข็งค่า');

      // Portfolio Realized Summary matches FIFO totalRealizedGLTHB to the exact satang
      expect(realized.summary.totalGLTHB).toBe(fifo.totalRealizedGLTHB);
      const realizedPortfolioSum = new BrinsonDecimal(
        realized.summary.goldPriceContributionTHB
      ).plus(realized.summary.fxContributionTHB);
      expect(realizedPortfolioSum.toFixed(2)).toBe(fifo.totalRealizedGLTHB);
      expect(realized.summary.unexplainedResidualTHB).toBe('0.00');
    });
  });

  describe('4. Exhaustive 200-Scenario Quantitative Stress Proof (Prime Decimals, Repeating Fractions & Half-Satang Ties)', () => {
    it('guarantees Gold Contribution + FX Contribution === Total G/L with 0.00 residual across all 200 scenarios (100%)', () => {
      // Include explicit half-satang tie-breaker edge case (e.g. 10.005 + 20.005 = 30.01)
      const halfSatangTie = calculateMultiplicativeBrinsonAttribution({
        symbol: 'TIE_TEST',
        costBasisTHB: '1000.00',
        endingValueTHB: '1030.01', // Total G/L = +30.01 THB
        entryUsdThb: '100.0000',
        currentUsdThb: '101.9811871875', // Engineered near half-satang boundary
      });
      expect(
        new BrinsonDecimal(halfSatangTie.goldPriceContributionTHB)
          .plus(halfSatangTie.fxContributionTHB)
          .toFixed(2)
      ).toBe('30.01');
      expect(halfSatangTie.unexplainedResidualTHB).toBe('0.00');

      // 200 deterministic prime/non-terminating combinations covering -40% to +60% Gold and -20% to +25% FX
      for (let i = 1; i <= 200; i++) {
        const costBasis = new BrinsonDecimal(10007)
          .times(i)
          .dividedBy(3)
          .toFixed(2);
        const entryXau = new BrinsonDecimal('1850.13').plus(
          new BrinsonDecimal(i).times('7.37')
        );
        const goldFactor = new BrinsonDecimal('0.63').plus(
          new BrinsonDecimal((i * 37) % 97).dividedBy(100)
        );
        const currentXau = entryXau.times(goldFactor);

        const entryFx = new BrinsonDecimal('31.17').plus(
          new BrinsonDecimal((i * 19) % 71).dividedBy(10)
        );
        const fxFactor = new BrinsonDecimal('0.83').plus(
          new BrinsonDecimal((i * 29) % 43).dividedBy(100)
        );
        const currentFx = entryFx.times(fxFactor);

        const res = calculateMultiplicativeBrinsonAttribution({
          symbol: `SCENARIO_${i}`,
          costBasisTHB: costBasis,
          entryXauUsd: entryXau,
          currentXauUsd: currentXau,
          entryUsdThb: entryFx,
          currentUsdThb: currentFx,
        });

        // 1. Satang-exact Monetary Identity: Gold Contrib + FX Contrib === Total G/L
        const sumSatang = new BrinsonDecimal(res.goldPriceContributionTHB).plus(
          res.fxContributionTHB
        );
        expect(sumSatang.toFixed(2)).toBe(res.totalGLTHB);
        expect(res.unexplainedResidualTHB).toBe('0.00');
        expect(res.isZeroResidualVerified).toBe(true);

        // 2. 40-digit Multiplicative Return Identity: (1 + R_gold) * (1 + R_fx) === (1 + R_total)
        const rG = currentXau.dividedBy(entryXau).minus(1);
        const rF = currentFx.dividedBy(entryFx).minus(1);
        const rT = new BrinsonDecimal(1)
          .plus(rG)
          .times(new BrinsonDecimal(1).plus(rF))
          .minus(1);
        expect(res.totalReturnRatio).toBe(rT.toFixed(6));
      }
    });
  });
});
