import {
  GoldFXSensitivity,
  GoldLot,
  GoldMarketEnvironment,
  GoldPortfolioBreakdown,
  GoldSensitivityMatrixCell,
  GoldTransaction,
} from '../types/gold';
import {
  buildGoldMarketEnvironment,
  calculateGoldFIFO,
  convertToEquivalentThaiBaht965,
  getUnitMarketPriceTHB,
  GoldDecimal,
  toCleanGoldDecimal,
} from './goldEngine';
import {
  buildPortfolioGoldBrinsonReport,
  calculateGtaGold965Parity,
  calculateMultiplicativeBrinsonAttribution,
  calculateRealizedBrinsonAttributions,
  calculateThaiGold965GtaAttribution,
  calculateUnrealizedBrinsonAttributions,
  mapBrinsonItemToGoldFXSensitivity,
} from './goldBrinsonAttribution';

export {
  buildPortfolioGoldBrinsonReport,
  calculateGtaGold965Parity,
  calculateMultiplicativeBrinsonAttribution,
  calculateRealizedBrinsonAttributions,
  calculateThaiGold965GtaAttribution,
  calculateUnrealizedBrinsonAttributions,
  mapBrinsonItemToGoldFXSensitivity,
};

export const DEFAULT_GOLD_SHOCKS = ['-0.10', '-0.05', '0.00', '0.05', '0.10'];
export const DEFAULT_FX_SHOCKS = ['-0.05', '-0.025', '0.00', '0.025', '0.05'];

/**
 * TFEX Gold Online Futures / Broker Initial Margin Ratio (10% standard risk parameter)
 */
const FUTURES_INITIAL_MARGIN_RATE = new GoldDecimal('0.10');

/**
 * Multiplicative Brinson Return Decomposition for Gold + USD/THB FX Sensitivity
 * (delegated strictly to `goldBrinsonAttribution.ts` with Decimal.js precision: 40):
 *
 *   (1 + R_total) = (1 + R_gold) × (1 + R_fx)
 *   Gold Price Contribution = Cost Basis THB × R_gold
 *   FX Contribution         = (Cost Basis THB + Gold Price Contribution) × R_fx
 *   => Gold Price Contribution + FX Contribution === Total Unrealized G/L (THB)
 *      (Zero Unexplained Residual to every satang!)
 */
export function calculateGoldFXSensitivities(
  lots: GoldLot[],
  transactions: GoldTransaction[],
  market: Pick<
    GoldMarketEnvironment,
    'xauUsdSpot' | 'usdThbRate' | 'gtaGold965SellTHB'
  >
): GoldFXSensitivity[] {
  const { items } = calculateUnrealizedBrinsonAttributions(
    lots,
    transactions,
    market
  );
  return items.map(mapBrinsonItemToGoldFXSensitivity);
}

/**
 * Splits open gold holdings into Physical Bullion (`PHYSICAL_GOLD`) vs
 * Paper / Spot Derivatives (`GOLD_ONLINE_FUTURES` + `XAU_SPOT`), normalized to
 * equivalent 96.5% Thai Baht Gold weight (`บาททองคำ`).
 */
export function calculateGoldPortfolioBreakdown(
  lots: GoldLot[],
  market: Pick<
    GoldMarketEnvironment,
    'xauUsdSpot' | 'usdThbRate' | 'gtaGold965SellTHB'
  >
): GoldPortfolioBreakdown {
  let physWeightBaht = new GoldDecimal(0);
  let physValueTHB = new GoldDecimal(0);

  let paperWeightBaht = new GoldDecimal(0);
  let paperValueTHB = new GoldDecimal(0);
  let futuresNotionalTHB = new GoldDecimal(0);

  for (const lot of lots) {
    const remain = toCleanGoldDecimal(lot.weightRemain);
    if (remain.lte(0)) continue;

    const equivBaht = convertToEquivalentThaiBaht965(
      lot.weightRemain,
      lot.weightUnit,
      lot.purity
    );
    const unitMktPriceTHB = getUnitMarketPriceTHB(lot, market);
    const lotValueTHB = remain.times(unitMktPriceTHB);

    if (lot.assetSubclass === 'PHYSICAL_GOLD') {
      physWeightBaht = physWeightBaht.plus(equivBaht);
      physValueTHB = physValueTHB.plus(lotValueTHB);
    } else {
      paperWeightBaht = paperWeightBaht.plus(equivBaht);
      paperValueTHB = paperValueTHB.plus(lotValueTHB);
      if (lot.assetSubclass === 'GOLD_ONLINE_FUTURES') {
        futuresNotionalTHB = futuresNotionalTHB.plus(lotValueTHB);
      }
    }
  }

  const grandTotalTHB = physValueTHB.plus(paperValueTHB);
  const physPct = grandTotalTHB.gt(0)
    ? physValueTHB.times(100).dividedBy(grandTotalTHB)
    : new GoldDecimal(0);
  const paperPct = grandTotalTHB.gt(0)
    ? new GoldDecimal(100).minus(physPct)
    : new GoldDecimal(0);

  const marginRequirement = futuresNotionalTHB.gt(0)
    ? futuresNotionalTHB.times(FUTURES_INITIAL_MARGIN_RATE).toFixed(2)
    : undefined;

  return {
    physicalGold: {
      totalWeight: physWeightBaht.toFixed(4),
      totalValueTHB: physValueTHB.toFixed(2),
      percentage: physPct.toFixed(2),
    },
    paperGold: {
      totalWeight: paperWeightBaht.toFixed(4),
      totalValueTHB: paperValueTHB.toFixed(2),
      percentage: paperPct.toFixed(2),
      ...(marginRequirement ? { marginRequirement } : {}),
    },
  };
}

/**
 * Generates a 2D Gold Spot × USD/THB Stress-Test Matrix (e.g. 5×5 = 25 scenarios)
 * preserving domestic premium spread percentages when projecting GTA 96.5% prices.
 */
export function generateGoldFXSensitivityMatrix(
  transactions: GoldTransaction[],
  baseMarket: GoldMarketEnvironment,
  goldShocks: string[] = DEFAULT_GOLD_SHOCKS,
  fxShocks: string[] = DEFAULT_FX_SHOCKS
): GoldSensitivityMatrixCell[] {
  const baseXau = toCleanGoldDecimal(baseMarket.xauUsdSpot);
  const baseFx = toCleanGoldDecimal(baseMarket.usdThbRate);
  const baseGta965 = toCleanGoldDecimal(baseMarket.gtaGold965SellTHB);
  const one = new GoldDecimal(1);

  const cells: GoldSensitivityMatrixCell[] = [];

  for (const gShockStr of goldShocks) {
    const gShock = toCleanGoldDecimal(gShockStr);
    const projXau = baseXau.times(one.plus(gShock));

    for (const fShockStr of fxShocks) {
      const fShock = toCleanGoldDecimal(fShockStr);
      const projFx = baseFx.times(one.plus(fShock));

      // Domestic GTA 96.5% scales multiplicatively by (1 + goldShock) × (1 + fxShock)
      const projGta965 = baseGta965
        .times(one.plus(gShock))
        .times(one.plus(fShock));

      const shockedEnv = buildGoldMarketEnvironment({
        xauUsdSpot: projXau.toFixed(4),
        usdThbRate: projFx.toFixed(6),
        gtaGold965SellTHB: projGta965.toFixed(4),
      });

      const fifo = calculateGoldFIFO(transactions, shockedEnv);
      const costTHB = toCleanGoldDecimal(fifo.totalCostBasisTHB);
      const mktTHB = toCleanGoldDecimal(fifo.totalMarketValueTHB);
      const netUnrealizedTHB = toCleanGoldDecimal(fifo.totalUnrealizedGLTHB);
      const returnPct = costTHB.gt(0)
        ? netUnrealizedTHB.dividedBy(costTHB)
        : new GoldDecimal(0);

      cells.push({
        goldShockPct: gShock.toFixed(4),
        fxShockPct: fShock.toFixed(4),
        projectedXauUsd: projXau.toFixed(2),
        projectedUsdThb: projFx.toFixed(4),
        projectedGold965THB: projGta965.toFixed(2),
        projectedPortfolioValueTHB: mktTHB.toFixed(2),
        projectedNetGLTHB: netUnrealizedTHB.toFixed(2),
        projectedReturnPct: returnPct.toFixed(4),
      });
    }
  }

  return cells;
}
