import {
  buildGoldMarketEnvironment,
  buildGoldTaxEnginePayload,
  calculateFineGoldGrams,
  calculateGoldFIFO,
  calculateGoldTransactionTotalCost,
  calculateTheoreticalThaiGold965THB,
  convertGoldWeight,
  convertToEquivalentThaiBaht965,
  GoldDecimal,
  isThaiPhysicalGoldTaxExempt,
} from './goldEngine';
import {
  calculateGoldFXSensitivities,
  calculateGoldPortfolioBreakdown,
  generateGoldFXSensitivityMatrix,
} from './goldFxSensitivityEngine';
import { GoldTransaction } from '../types/gold';

describe('Gold Premium & FX Sensitivity Engine — Quantitative Unit Tests (Decimal.js precision: 40)', () => {
  describe('1. Thai Gold Weight & Purity Standards (15.244g Baht & 31.1034768g Troy Ounce)', () => {
    it('converts 5.00 Thai Baht Gold to exact 76.2200 Grams and back losslessly', () => {
      const grams = convertGoldWeight('5.00', 'THAI_BAHT', 'GRAM', 4);
      expect(grams).toBe('76.2200');

      const backToBaht = convertGoldWeight(grams, 'GRAM', 'THAI_BAHT', 4);
      expect(backToBaht).toBe('5.0000');
    });

    it('converts 1.0000 Troy Ounce to exact 31.1035 Grams (~2.0404 Thai Baht)', () => {
      const grams = convertGoldWeight('1', 'TROY_OUNCE', 'GRAM', 4);
      expect(grams).toBe('31.1035');

      const baht = convertGoldWeight('1', 'TROY_OUNCE', 'THAI_BAHT', 4);
      // 31.1034768 / 15.244 = 2.0403750196... -> 2.0404
      expect(baht).toBe('2.0404');
    });

    it('normalizes 96.5% vs 99.99% purity into Fine Gold Grams & Equivalent 96.5% Baht', () => {
      // 10 Baht of 96.5% gold -> 10 * 15.244 * 0.965 = 147.1046 fine grams -> 10.0000 equiv Baht 96.5%
      const fine965 = calculateFineGoldGrams('10', 'THAI_BAHT', '96.5');
      expect(fine965.toFixed(4)).toBe('147.1046');

      const equiv965 = convertToEquivalentThaiBaht965('10', 'THAI_BAHT', '96.5');
      expect(equiv965.toFixed(4)).toBe('10.0000');

      // 100 Grams of 99.99% gold has MORE pure gold than 100 Grams of 96.5% gold
      const equivFrom9999 = convertToEquivalentThaiBaht965('100', 'GRAM', '99.99');
      const equivFrom965 = convertToEquivalentThaiBaht965('100', 'GRAM', '96.5');
      expect(equivFrom9999.gt(equivFrom965)).toBe(true);
    });
  });

  describe('2. Total Cost Formula, GTA Theoretical Parity & FIFO Lot Accounting', () => {
    it('computes totalCost = (spotPrice + premiumPerUnit) × weight + commission for BUY and - commission for SELL', () => {
      const buyCost = calculateGoldTransactionTotalCost({
        weight: '5.00',
        spotPricePerUnit: '41000.00',
        premiumPerUnit: '250.00', // ค่าบล็อก 250 THB/บาททองคำ
        commission: '100.00',
        type: 'BUY',
      });
      // (41000 + 250) * 5 + 100 = 206,350.00
      expect(buyCost).toBe('206350.00');

      const sellProceeds = calculateGoldTransactionTotalCost({
        weight: '2.00',
        spotPricePerUnit: '44000.00',
        premiumPerUnit: '0.00',
        commission: '50.00',
        type: 'SELL',
      });
      // 44000 * 2 - 50 = 87,950.00
      expect(sellProceeds).toBe('87950.00');
    });

    it('computes GTA Theoretical 96.5% Baht Parity & Domestic Premium accurately', () => {
      // XAUUSD = 2700, USDTHB = 35.00 => 2700 * (15.244 / 31.1034768) * 0.965 * 35.00 = 44693.99 THB
      const parity = calculateTheoreticalThaiGold965THB('2700.00', '35.00');
      expect(parity.toFixed(2)).toBe('44693.99');

      const env = buildGoldMarketEnvironment({
        xauUsdSpot: '2700.00',
        usdThbRate: '35.00',
        gtaGold965SellTHB: '44950.00',
      });
      expect(env.theoreticalGold965THB).toBe('44693.99');
      expect(env.domesticPremiumTHB).toBe('256.01');
      expect(Number(env.domesticPremiumPct)).toBeGreaterThan(0);
    });

    it('tracks Gold FIFO Partial, Sold, and Hold lots with Block Premium included in costPerUnit', () => {
      const createdAt = new Date('2026-10-01T00:00:00Z');
      const txs: GoldTransaction[] = [
        {
          id: 'tx-1',
          portfolioId: 'p1',
          date: '2026-01-10',
          symbol: 'GOLD965',
          assetSubclass: 'PHYSICAL_GOLD',
          weight: '5.00',
          weightUnit: 'THAI_BAHT',
          purity: '96.5',
          spotPricePerUnit: '40000.00',
          premiumPerUnit: '200.00',
          commission: '0.00',
          totalCost: '201000.00', // 40,200 / Baht
          fxRateAtPurchase: '34.00',
          type: 'BUY',
          createdAt,
        },
        {
          id: 'tx-2',
          portfolioId: 'p1',
          date: '2026-06-15',
          symbol: 'GOLD965',
          assetSubclass: 'PHYSICAL_GOLD',
          weight: '2.00',
          weightUnit: 'THAI_BAHT',
          purity: '96.5',
          spotPricePerUnit: '43200.00',
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: '86400.00', // 43,200 / Baht
          fxRateAtPurchase: '35.00',
          type: 'SELL',
          createdAt,
        },
      ];

      const fifo = calculateGoldFIFO(txs, {
        xauUsdSpot: '2740.00',
        usdThbRate: '35.50',
        gtaGold965SellTHB: '45200.00',
      });

      expect(fifo.lots).toHaveLength(1);
      const lot = fifo.lots[0]!;
      expect(lot.status).toBe('Partial');
      expect(lot.costPerUnit).toBe('40200.00');
      expect(lot.weightSold).toBe('2.0000');
      expect(lot.weightRemain).toBe('3.0000');
      // Realized G/L: 2 * (43200 - 40200) = +6,000.00 THB
      expect(lot.realizedGL).toBe('6000.00');
      // Unrealized G/L: 3 * (45200 - 40200) = +15,000.00 THB
      expect(lot.unrealizedGL).toBe('15000.00');
      expect(fifo.totalPremiumPaidTHB).toBe('1000.00');
    });

    it('throws descriptive error when attempting to oversell gold weight', () => {
      const createdAt = new Date('2026-10-01T00:00:00Z');
      const txs: GoldTransaction[] = [
        {
          id: 'tx-1',
          portfolioId: 'p1',
          date: '2026-01-10',
          symbol: 'GOLD965',
          assetSubclass: 'PHYSICAL_GOLD',
          weight: '2.00',
          weightUnit: 'THAI_BAHT',
          purity: '96.5',
          spotPricePerUnit: '40000.00',
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: '80000.00',
          fxRateAtPurchase: '34.00',
          type: 'BUY',
          createdAt,
        },
        {
          id: 'tx-oversell',
          portfolioId: 'p1',
          date: '2026-02-10',
          symbol: 'GOLD965',
          assetSubclass: 'PHYSICAL_GOLD',
          weight: '3.00',
          weightUnit: 'THAI_BAHT',
          purity: '96.5',
          spotPricePerUnit: '41000.00',
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: '123000.00',
          fxRateAtPurchase: '34.00',
          type: 'SELL',
          createdAt,
        },
      ];

      expect(() =>
        calculateGoldFIFO(txs, {
          xauUsdSpot: '2700',
          usdThbRate: '35',
          gtaGold965SellTHB: '45000',
        })
      ).toThrow(/Oversell error/i);
    });
  });

  describe('3. Gold Alpha vs USD/THB FX Attribution, Physical/Paper Breakdown & 5x5 Matrix', () => {
    const createdAt = new Date('2026-10-01T00:00:00Z');
    const sampleTxs: GoldTransaction[] = [
      {
        id: 'xau-1',
        portfolioId: 'p1',
        date: '2026-04-01',
        symbol: 'XAUUSD',
        assetSubclass: 'XAU_SPOT',
        weight: '2.0000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.99',
        spotPricePerUnit: '2500.00', // +10% to 2750
        premiumPerUnit: '0.00',
        commission: '0.00',
        totalCost: '5000.00', // USD -> * 34.00 = 170,000 THB
        fxRateAtPurchase: '34.00', // +5% to 35.70
        type: 'BUY',
        createdAt,
      },
      {
        id: 'phys-1',
        portfolioId: 'p1',
        date: '2026-04-05',
        symbol: 'GOLD965',
        assetSubclass: 'PHYSICAL_GOLD',
        weight: '4.0000',
        weightUnit: 'THAI_BAHT',
        purity: '96.5',
        spotPricePerUnit: '41000.00',
        premiumPerUnit: '200.00',
        commission: '0.00',
        totalCost: '164800.00',
        fxRateAtPurchase: '34.00',
        type: 'BUY',
        createdAt,
      },
      {
        id: 'fut-1',
        portfolioId: 'p1',
        date: '2026-05-01',
        symbol: 'GOZ26',
        assetSubclass: 'GOLD_ONLINE_FUTURES',
        weight: '1.0000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.5',
        spotPricePerUnit: '2600.00',
        premiumPerUnit: '0.00',
        commission: '0.00',
        totalCost: '2600.00',
        fxRateAtPurchase: '35.00',
        type: 'BUY',
        createdAt,
      },
    ];

    const market = buildGoldMarketEnvironment({
      xauUsdSpot: '2750.00', // exact +10% over 2500
      usdThbRate: '35.70', // exact +5% over 34.00
      gtaGold965SellTHB: '46500.00',
    });

    it('decomposes XAUUSD return into exact +10.00% Gold Alpha and +5.00% FX Impact with zero residual', () => {
      const fifo = calculateGoldFIFO(sampleTxs, market);
      const sensitivities = calculateGoldFXSensitivities(
        fifo.lots,
        sampleTxs,
        market
      );

      const xauAttr = sensitivities.find((s) => s.symbol === 'XAUUSD')!;
      expect(xauAttr).toBeDefined();
      // (1.10 * 1.05) - 1 = +0.1550 (+15.50% total THB return)
      expect(xauAttr.goldAlphaPct).toBe('0.1000');
      expect(xauAttr.fxImpactPct).toBe('0.0500');
      expect(xauAttr.totalReturnPct).toBe('0.1550');

      // Cost = 170,000 THB, Market = 2 * 2750 * 35.70 = 196,350 THB => Total PnL = +26,350.00 THB
      const sumContrib = new GoldDecimal(
        xauAttr.attribution.goldPriceContribution
      ).plus(new GoldDecimal(xauAttr.attribution.fxContribution));
      expect(sumContrib.toFixed(2)).toBe('26350.00');
      expect(xauAttr.attribution.goldPriceContribution).toBe('17000.00');
      expect(xauAttr.attribution.fxContribution).toBe('9350.00');
    });

    it('computes Physical vs Paper Gold Breakdown and 10% Futures Margin Requirement', () => {
      const fifo = calculateGoldFIFO(sampleTxs, market);
      const breakdown = calculateGoldPortfolioBreakdown(fifo.lots, market);

      expect(breakdown.physicalGold.totalWeight).toBe('4.0000');
      expect(breakdown.physicalGold.totalValueTHB).toBe('186000.00');
      expect(Number(breakdown.paperGold.totalWeight)).toBeGreaterThan(6);
      // GOZ26 1 oz * 2750 * 35.70 = 98,175.00 THB -> 10% margin = 9,817.50 THB
      expect(breakdown.paperGold.marginRequirement).toBe('9817.50');

      const pctSum = new GoldDecimal(breakdown.physicalGold.percentage).plus(
        new GoldDecimal(breakdown.paperGold.percentage)
      );
      expect(pctSum.toFixed(2)).toBe('100.00');
    });

    it('generates 5x5 = 25 Gold Spot × USD/THB Stress Scenarios monotonically', () => {
      const matrix = generateGoldFXSensitivityMatrix(sampleTxs, market);
      expect(matrix).toHaveLength(25);

      const worstCase = matrix[0]!; // -10% Gold, -5% FX
      const baseCase = matrix[12]!; // 0% Gold, 0% FX
      const bullCase = matrix[24]!; // +10% Gold, +5% FX

      expect(worstCase.goldShockPct).toBe('-0.1000');
      expect(baseCase.goldShockPct).toBe('0.0000');
      expect(bullCase.goldShockPct).toBe('0.1000');

      expect(
        new GoldDecimal(worstCase.projectedPortfolioValueTHB).lt(
          new GoldDecimal(baseCase.projectedPortfolioValueTHB)
        )
      ).toBe(true);
      expect(
        new GoldDecimal(bullCase.projectedPortfolioValueTHB).gt(
          new GoldDecimal(baseCase.projectedPortfolioValueTHB)
        )
      ).toBe(true);
    });
  });

  describe('4. Thai Gold Tax Nuance (isTaxExempt Flag for Thai Physical Bullion)', () => {
    it('flags PHYSICAL_GOLD matching Thai standards (GOLD965, GOLD9999) as isTaxExempt: true and skips taxable capital gains', () => {
      expect(isThaiPhysicalGoldTaxExempt('PHYSICAL_GOLD', 'GOLD965')).toBe(true);
      expect(isThaiPhysicalGoldTaxExempt('PHYSICAL_GOLD', 'gold9999')).toBe(true);
      expect(isThaiPhysicalGoldTaxExempt('GOLD_ONLINE_FUTURES', 'GOZ26')).toBe(false);
      expect(isThaiPhysicalGoldTaxExempt('XAU_SPOT', 'XAUUSD')).toBe(false);
      expect(isThaiPhysicalGoldTaxExempt('PHYSICAL_GOLD', 'FOREIGN_BAR')).toBe(false);

      const createdAt = new Date('2026-10-01T00:00:00Z');
      const mixedTxs: GoldTransaction[] = [
        {
          id: 'tax-phys-buy',
          portfolioId: 'p-tax',
          date: '2026-02-01',
          symbol: 'GOLD965',
          assetSubclass: 'PHYSICAL_GOLD',
          weight: '5.00',
          weightUnit: 'THAI_BAHT',
          purity: '96.5',
          spotPricePerUnit: '40000.00',
          premiumPerUnit: '200.00',
          commission: '0.00',
          totalCost: '201000.00',
          fxRateAtPurchase: '34.50',
          type: 'BUY',
          createdAt,
        },
        {
          id: 'tax-phys-sell',
          portfolioId: 'p-tax',
          date: '2026-08-01',
          symbol: 'GOLD965',
          assetSubclass: 'PHYSICAL_GOLD',
          weight: '5.00',
          weightUnit: 'THAI_BAHT',
          purity: '96.5',
          spotPricePerUnit: '45000.00',
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: '225000.00', // Realized Gain = +24,000.00 THB (Tax Exempt!)
          fxRateAtPurchase: '35.50',
          type: 'SELL',
          createdAt,
        },
        {
          id: 'tax-fut-buy',
          portfolioId: 'p-tax',
          date: '2026-03-01',
          symbol: 'GOZ26',
          assetSubclass: 'GOLD_ONLINE_FUTURES',
          weight: '2.00',
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          spotPricePerUnit: '2500.00',
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: '5000.00', // 5000 * 35.00 = 175,000.00 THB
          fxRateAtPurchase: '35.00',
          type: 'BUY',
          createdAt,
        },
        {
          id: 'tax-fut-sell',
          portfolioId: 'p-tax',
          date: '2026-09-01',
          symbol: 'GOZ26',
          assetSubclass: 'GOLD_ONLINE_FUTURES',
          weight: '2.00',
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          spotPricePerUnit: '2700.00',
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: '5400.00', // 5400 * 35.00 = 189,000.00 THB -> Taxable Gain = +14,000.00 THB
          fxRateAtPurchase: '35.00',
          type: 'SELL',
          createdAt,
        },
      ];

      const fifo = calculateGoldFIFO(mixedTxs, {
        xauUsdSpot: '2740.00',
        usdThbRate: '35.60',
        gtaGold965SellTHB: '46450.00',
      });

      expect(fifo.totalRealizedGLTHB).toBe('38000.00');
      expect(fifo.taxExemptRealizedGLTHB).toBe('24000.00');
      expect(fifo.taxableRealizedGLTHB).toBe('14000.00');

      const physLot = fifo.lots.find((l) => l.symbol === 'GOLD965')!;
      const futLot = fifo.lots.find((l) => l.symbol === 'GOZ26')!;
      expect(physLot.isTaxExempt).toBe(true);
      expect(futLot.isTaxExempt).toBe(false);

      const physTaxPayload = buildGoldTaxEnginePayload(physLot);
      expect(physTaxPayload.isTaxExempt).toBe(true);
      expect(physTaxPayload.taxableCapitalGainTHB).toBe('0.00');
      expect(physTaxPayload.exemptionCode).toBe('TH_RD_SEC_42_9_PHYSICAL_GOLD');

      const futTaxPayload = buildGoldTaxEnginePayload(futLot);
      expect(futTaxPayload.isTaxExempt).toBe(false);
      expect(futTaxPayload.taxableCapitalGainTHB).toBe('14000.00');
      expect(futTaxPayload.exemptionCode).toBeNull();
    });
  });
});
