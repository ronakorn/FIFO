import Decimal from 'decimal.js';
import { Dividend } from '../types';
import {
  DividendCalendarReport,
  DividendEvent,
  DividendForecast,
  MonthlyDividendBucket,
  MonthlyDividendSummary,
} from '../types/wave1';

const FinDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

function toCleanDecimal(value: Decimal.Value | undefined | null): Decimal {
  if (value === undefined || value === null || value === '') {
    return new FinDecimal(0);
  }
  if (typeof value === 'string') {
    const cleaned = value.replace(/,/g, '').trim();
    return cleaned ? new FinDecimal(cleaned) : new FinDecimal(0);
  }
  return new FinDecimal(value);
}

export type { MonthlyDividendSummary };

const MONTH_META: { key: string; th: string }[] = [
  { key: 'Jan', th: 'ม.ค.' },
  { key: 'Feb', th: 'ก.พ.' },
  { key: 'Mar', th: 'มี.ค.' },
  { key: 'Apr', th: 'เม.ย.' },
  { key: 'May', th: 'พ.ค.' },
  { key: 'Jun', th: 'มิ.ย.' },
  { key: 'Jul', th: 'ก.ค.' },
  { key: 'Aug', th: 'ส.ค.' },
  { key: 'Sep', th: 'ก.ย.' },
  { key: 'Oct', th: 'ต.ค.' },
  { key: 'Nov', th: 'พ.ย.' },
  { key: 'Dec', th: 'ธ.ค.' },
];

const DEFAULT_UPCOMING_FORECASTS: DividendForecast[] = [
  {
    symbol: 'AAPL',
    exDate: '2026-11-08',
    payDate: '2026-11-14',
    amountPerShare: '0.25',
    sharesHeld: 20,
    currency: 'USD',
    fxRate: '35.50',
  },
  {
    symbol: 'ADVANC',
    exDate: '2026-11-18',
    payDate: '2026-11-25',
    amountPerShare: '4.85',
    sharesHeld: 500,
    currency: 'THB',
    fxRate: '1.00',
  },
  {
    symbol: 'SCHD',
    exDate: '2026-12-10',
    payDate: '2026-12-16',
    amountPerShare: '0.72',
    sharesHeld: 50,
    currency: 'USD',
    fxRate: '35.50',
  },
];

/**
 * Parses an ISO date string (`YYYY-MM-DD...`) or Date into deterministic UTC midnight milliseconds
 * and `{ year, month }` without local-timezone off-by-one shifts.
 */
function parseIsoDateUtc(input: string | Date): {
  utcMs: number;
  year: number;
  month: number; // 1 - 12
} | null {
  if (input instanceof Date) {
    if (Number.isNaN(input.getTime())) return null;
    const y = input.getUTCFullYear();
    const m = input.getUTCMonth() + 1;
    const d = input.getUTCDate();
    return {
      utcMs: Date.UTC(y, m - 1, d),
      year: y,
      month: m,
    };
  }

  const trimmed = input.trim();
  const isoMatch = /^(\d{4})-(\d{2})-(\d{2})/.exec(trimmed);
  if (isoMatch) {
    const year = Number(isoMatch[1]);
    const month = Number(isoMatch[2]);
    const day = Number(isoMatch[3]);
    return {
      utcMs: Date.UTC(year, month - 1, day),
      year,
      month,
    };
  }

  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) return null;
  const year = parsed.getUTCFullYear();
  const month = parsed.getUTCMonth() + 1;
  const day = parsed.getUTCDate();
  return {
    utcMs: Date.UTC(year, month - 1, day),
    year,
    month,
  };
}

/**
 * Overload 1: Aggregates `DividendEvent[]` for a target `year` into 12 `MonthlyDividendSummary`
 * entries (`month: 1..12`, `totalDividends`, `dividendCount`, `averageMonthlyIncome`) using Decimal.js (precision: 40).
 *
 * Overload 2: Merges historical actual `Dividend[]` records with projected `DividendForecast[]`
 * schedules into a unified chronological `DividendEvent[]` list.
 */
export function generateDividendCalendar(
  dividends: DividendEvent[],
  year: number
): MonthlyDividendSummary[];
export function generateDividendCalendar(
  dividends: Dividend[],
  forecast: DividendForecast[]
): DividendEvent[];
export function generateDividendCalendar(
  dividends: DividendEvent[] | Dividend[],
  yearOrForecast: number | DividendForecast[]
): MonthlyDividendSummary[] | DividendEvent[] {
  // Branch 1: (dividends: DividendEvent[], year: number) -> MonthlyDividendSummary[]
  if (typeof yearOrForecast === 'number') {
    const year = yearOrForecast;
    const events = dividends as DividendEvent[];
    const monthlyData: Record<number, { total: Decimal; count: number }> = {};

    for (let i = 1; i <= 12; i++) {
      monthlyData[i] = { total: new FinDecimal(0), count: 0 };
    }

    events.forEach((div) => {
      const parsedPay = parseIsoDateUtc(div.payDate);
      if (parsedPay && parsedPay.year === year) {
        const bucket = monthlyData[parsedPay.month];
        if (bucket) {
          bucket.total = bucket.total.plus(toCleanDecimal(div.estimatedTHB));
          bucket.count += 1;
        }
      }
    });

    const yearlyTotal = Object.values(monthlyData).reduce(
      (sum, m) => sum.plus(m.total),
      new FinDecimal(0)
    );
    const averageMonthly = yearlyTotal.dividedBy(12);
    const avgStr = averageMonthly.toFixed(2, Decimal.ROUND_HALF_UP);

    return Object.entries(monthlyData).map(([monthKey, data]) => ({
      month: parseInt(monthKey, 10),
      year,
      totalDividends: data.total.toFixed(2, Decimal.ROUND_HALF_UP),
      dividendCount: data.count,
      averageMonthlyIncome: avgStr,
    }));
  }

  // Branch 2: (dividends: Dividend[], forecast: DividendForecast[]) -> DividendEvent[]
  const actualsInput = dividends as Dividend[];
  const forecast = yearOrForecast;

  const actualEvents: DividendEvent[] = actualsInput.map((div) => {
    const thbAmount = div.netTHB
      ? new FinDecimal(div.netTHB)
      : div.grossTHB
        ? new FinDecimal(div.grossTHB)
        : div.fxRate
          ? new FinDecimal(div.net).times(new FinDecimal(div.fxRate))
          : new FinDecimal(div.net);

    return {
      id: div.id,
      symbol: div.symbol.toUpperCase(),
      exDate: div.date.slice(0, 10),
      payDate: div.date.slice(0, 10),
      amountPerShare: new FinDecimal(div.divPerShare).toFixed(4),
      currency: div.originalCurrency,
      estimatedTHB: thbAmount.toFixed(2, Decimal.ROUND_HALF_UP),
      isForecast: false,
      sharesHeld: new FinDecimal(div.qty).toString(),
    };
  });

  const forecastEvents: DividendEvent[] = forecast.map((f, index) => {
    const defaultFx = f.currency.toUpperCase() === 'THB' ? '1.00' : '35.50';
    const fx = new FinDecimal(f.fxRate ?? defaultFx);
    const estThb = new FinDecimal(f.amountPerShare)
      .times(new FinDecimal(f.sharesHeld))
      .times(fx);

    return {
      id: `forecast-${f.symbol}-${f.payDate}-${index}`,
      symbol: f.symbol.toUpperCase(),
      exDate: f.exDate.slice(0, 10),
      payDate: f.payDate.slice(0, 10),
      amountPerShare: new FinDecimal(f.amountPerShare).toFixed(4),
      currency: f.currency.toUpperCase(),
      estimatedTHB: estThb.toFixed(2, Decimal.ROUND_HALF_UP),
      isForecast: true,
      sharesHeld: new FinDecimal(f.sharesHeld).toString(),
    };
  });

  const combined = [...actualEvents, ...forecastEvents];
  combined.sort((a, b) => a.payDate.localeCompare(b.payDate));
  return combined;
}

/**
 * Overload 1: Filters `dividends` whose `exDate` falls within `[today (UTC day start), today + daysAhead]`
 * and sorts ascending by `exDate`.
 *
 * Overload 2: Legacy/Service helper `(daysAhead, events?, referenceDate?)` filtering upcoming events.
 */
export function getUpcomingDividends(
  dividends: DividendEvent[],
  daysAhead: number,
  referenceDate?: string | Date
): DividendEvent[];
export function getUpcomingDividends(
  daysAhead: number,
  events?: DividendEvent[],
  referenceDate?: string
): DividendEvent[];
export function getUpcomingDividends(
  dividendsOrDays: DividendEvent[] | number,
  daysOrEvents?: number | DividendEvent[],
  referenceDate?: string | Date
): DividendEvent[] {
  // Branch 1: (dividends: DividendEvent[], daysAhead: number, referenceDate?)
  if (Array.isArray(dividendsOrDays)) {
    const dividends = dividendsOrDays;
    const daysAhead = typeof daysOrEvents === 'number' ? daysOrEvents : 30;
    if (daysAhead < 0) {
      throw new Error('daysAhead must be non-negative.');
    }

    const refParsed = parseIsoDateUtc(referenceDate ?? new Date());
    const startUtcMs = refParsed ? refParsed.utcMs : Date.now();
    const cutoffUtcMs = startUtcMs + daysAhead * 24 * 60 * 60 * 1000;

    return dividends
      .filter((div) => {
        const exParsed = parseIsoDateUtc(div.exDate);
        return (
          exParsed !== null &&
          exParsed.utcMs >= startUtcMs &&
          exParsed.utcMs <= cutoffUtcMs
        );
      })
      .sort((a, b) => {
        const aMs = parseIsoDateUtc(a.exDate)?.utcMs ?? 0;
        const bMs = parseIsoDateUtc(b.exDate)?.utcMs ?? 0;
        return aMs - bMs;
      });
  }

  // Branch 2: (daysAhead: number, events?: DividendEvent[], referenceDate = '2026-10-26')
  const daysAhead = dividendsOrDays;
  if (daysAhead < 0) {
    throw new Error('daysAhead must be non-negative.');
  }

  const sourceEvents = Array.isArray(daysOrEvents)
    ? daysOrEvents
    : generateDividendCalendar([], DEFAULT_UPCOMING_FORECASTS);

  const refIso =
    typeof referenceDate === 'string' ? referenceDate : '2026-10-26';
  const startUtcMs =
    parseIsoDateUtc(refIso)?.utcMs ?? Date.UTC(2026, 9, 26);
  const endUtcMs = startUtcMs + daysAhead * 86_400_000;

  return sourceEvents
    .filter((ev) => {
      const payParsed = parseIsoDateUtc(ev.payDate);
      return (
        payParsed !== null &&
        payParsed.utcMs >= startUtcMs &&
        payParsed.utcMs <= endUtcMs
      );
    })
    .sort((a, b) => a.payDate.localeCompare(b.payDate));
}

/**
 * Aggregates DividendEvent[] across all 12 months (Jan - Dec) of a target year,
 * computing exact Yearly Dividend Income and Average Monthly Passive Income via Decimal.js.
 */
export function buildDividendCalendarReport(
  events: DividendEvent[],
  year: number,
  referenceDate: string = '2026-10-26',
  upcomingWindowDays: number = 60
): DividendCalendarReport {
  const yearEvents = events.filter((e) => {
    const parsed = parseIsoDateUtc(e.payDate);
    return parsed !== null && parsed.year === year;
  });

  const buckets: {
    actual: Decimal;
    forecast: Decimal;
    events: DividendEvent[];
  }[] = Array.from({ length: 12 }, () => ({
    actual: new FinDecimal(0),
    forecast: new FinDecimal(0),
    events: [],
  }));

  let yearlySum = new FinDecimal(0);

  for (const ev of yearEvents) {
    const parsed = parseIsoDateUtc(ev.payDate);
    if (!parsed || parsed.month < 1 || parsed.month > 12) continue;

    const bucket = buckets[parsed.month - 1]!;
    const val = toCleanDecimal(ev.estimatedTHB);
    if (ev.isForecast) {
      bucket.forecast = bucket.forecast.plus(val);
    } else {
      bucket.actual = bucket.actual.plus(val);
    }
    bucket.events.push(ev);
    yearlySum = yearlySum.plus(val);
  }

  const monthlyIncome: MonthlyDividendBucket[] = buckets.map((b, idx) => {
    const meta = MONTH_META[idx]!;
    const total = b.actual.plus(b.forecast);
    return {
      month: idx + 1,
      monthKey: meta.key,
      monthNameTH: meta.th,
      actualTHB: b.actual.toFixed(2, Decimal.ROUND_HALF_UP),
      forecastTHB: b.forecast.toFixed(2, Decimal.ROUND_HALF_UP),
      totalTHB: total.toFixed(2, Decimal.ROUND_HALF_UP),
      eventCount: b.events.length,
      events: b.events,
    };
  });

  const avgMonthly = yearlySum.dividedBy(new FinDecimal(12));

  return {
    year,
    events: yearEvents,
    monthlyIncome,
    yearlyDividendTHB: yearlySum.toFixed(2, Decimal.ROUND_HALF_UP),
    averageMonthlyTHB: avgMonthly.toFixed(2, Decimal.ROUND_HALF_UP),
    upcomingDividends: getUpcomingDividends(
      events,
      upcomingWindowDays,
      referenceDate
    ),
  };
}
