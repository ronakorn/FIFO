import Decimal from 'decimal.js';
import {
  GoldAssetSubclass,
  GoldLot,
  GoldMarketEnvironment,
  GoldPurity,
  GoldTaxHandoffRecord,
  GoldTransaction,
  GoldWeightUnit,
} from '../types/gold';

export const GoldDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Thai Gold Association (GTA) & LBMA Exact Physical Constants:
 * - 1 บาททองคำแท่งมาตรฐาน (96.5%) = 15.244 กรัม
 * - 1 Troy Ounce (สากล LBMA)     = 31.1034768 กรัม
 */
export const GRAMS_PER_THAI_BAHT = new GoldDecimal('15.244');
export const GRAMS_PER_TROY_OUNCE = new GoldDecimal('31.1034768');
export const STANDARD_THAI_PURITY = new GoldDecimal('0.965');

/**
 * Recognized Thai Gold Traders Association (GTA) & domestic physical bullion symbols
 * eligible for Personal Income Tax exemption under Thai Revenue Code Sec. 42(9).
 */
export const THAI_STANDARD_PHYSICAL_GOLD_SYMBOLS = new Set<string>([
  'GOLD965',
  'GOLD9999',
  'GTA965',
  'GTA9999',
  'THGOLD965',
  'THGOLD9999',
]);

/**
 * Thai Gold Tax Nuance (กฎสรรพากรไทย มาตรา 42(9)):
 * Checks if `assetSubclass === 'PHYSICAL_GOLD'` and `symbol` matches Thai gold bullion
 * standards (e.g., 'GOLD965', 'GOLD9999'). Returns `true` so downstream Tax Engine
 * skips Capital Gains Tax calculation for domestic physical gold bars.
 */
export function isThaiPhysicalGoldTaxExempt(
  assetSubclass: GoldAssetSubclass,
  symbol: string
): boolean {
  if (assetSubclass !== 'PHYSICAL_GOLD') {
    return false;
  }
  const normalizedSymbol = symbol.trim().toUpperCase();
  return THAI_STANDARD_PHYSICAL_GOLD_SYMBOLS.has(normalizedSymbol);
}

/**
 * Builds the Tax Engine handoff object for a processed Gold FIFO lot,
 * explicitly attaching `isTaxExempt: true` when eligible under Thai Revenue Code.
 */
export function buildGoldTaxEnginePayload(lot: GoldLot): GoldTaxHandoffRecord {
  const exempt = isThaiPhysicalGoldTaxExempt(lot.assetSubclass, lot.symbol);
  return {
    lotId: lot.id,
    transactionId: lot.transactionId,
    symbol: lot.symbol,
    assetSubclass: lot.assetSubclass,
    purity: lot.purity,
    realizedGLTHB: lot.realizedGL,
    isTaxExempt: exempt,
    taxableCapitalGainTHB: exempt ? '0.00' : lot.realizedGL,
    exemptionCode: exempt ? 'TH_RD_SEC_42_9_PHYSICAL_GOLD' : null,
  };
}

export function toCleanGoldDecimal(
  value: string | number | Decimal
): InstanceType<typeof GoldDecimal> {
  if (Decimal.isDecimal(value)) {
    return new GoldDecimal(value.toString());
  }
  const cleaned = String(value).replace(/,/g, '').trim();
  if (!cleaned) {
    throw new Error('Numeric value for Gold Engine cannot be empty.');
  }
  return new GoldDecimal(cleaned);
}

/**
 * Converts weight across THAI_BAHT (15.244g), GRAM (1g), and TROY_OUNCE (31.1034768g).
 */
export function convertGoldWeight(
  weight: string,
  fromUnit: GoldWeightUnit,
  toUnit: GoldWeightUnit,
  decimalPlaces = 4
): string {
  const w = toCleanGoldDecimal(weight);
  if (w.isNegative()) {
    throw new Error('Gold weight cannot be negative.');
  }
  if (fromUnit === toUnit) {
    return w.toFixed(decimalPlaces);
  }

  let grams: InstanceType<typeof GoldDecimal>;
  switch (fromUnit) {
    case 'GRAM':
      grams = w;
      break;
    case 'THAI_BAHT':
      grams = w.times(GRAMS_PER_THAI_BAHT);
      break;
    case 'TROY_OUNCE':
      grams = w.times(GRAMS_PER_TROY_OUNCE);
      break;
  }

  let converted: InstanceType<typeof GoldDecimal>;
  switch (toUnit) {
    case 'GRAM':
      converted = grams;
      break;
    case 'THAI_BAHT':
      converted = grams.dividedBy(GRAMS_PER_THAI_BAHT);
      break;
    case 'TROY_OUNCE':
      converted = grams.dividedBy(GRAMS_PER_TROY_OUNCE);
      break;
  }

  return converted.toFixed(decimalPlaces);
}

/**
 * Returns 100% pure fine gold mass in grams: grams × (purity / 100).
 */
export function calculateFineGoldGrams(
  weight: string,
  weightUnit: GoldWeightUnit,
  purity: GoldPurity
): InstanceType<typeof GoldDecimal> {
  const gramsStr = convertGoldWeight(weight, weightUnit, 'GRAM', 16);
  const grams = new GoldDecimal(gramsStr);
  const purityRatio = toCleanGoldDecimal(purity).dividedBy(100);
  return grams.times(purityRatio);
}

/**
 * Normalizes any gold holding (99.99% Kg/Gram, XAU Troy Oz, 96.5% Baht)
 * into equivalent 96.5% Thai Baht Gold units for unified portfolio aggregation.
 */
export function convertToEquivalentThaiBaht965(
  weight: string,
  weightUnit: GoldWeightUnit,
  purity: GoldPurity
): InstanceType<typeof GoldDecimal> {
  const fineGrams = calculateFineGoldGrams(weight, weightUnit, purity);
  const fineGramsPerBaht965 = GRAMS_PER_THAI_BAHT.times(STANDARD_THAI_PURITY);
  return fineGrams.dividedBy(fineGramsPerBaht965);
}

/**
 * Determines whether a gold subclass is quoted natively in USD (XAU_SPOT / GOLD_ONLINE_FUTURES)
 * vs THB (PHYSICAL_GOLD).
 */
export function isUsdQuotedSubclass(assetSubclass: GoldAssetSubclass): boolean {
  return (
    assetSubclass === 'XAU_SPOT' || assetSubclass === 'GOLD_ONLINE_FUTURES'
  );
}

/**
 * Calculates native settlement value:
 * - BUY:  (spotPricePerUnit + premiumPerUnit) × weight + commission
 * - SELL: (spotPricePerUnit + premiumPerUnit) × weight - commission
 */
export function calculateGoldTransactionTotalCost(params: {
  weight: string;
  spotPricePerUnit: string;
  premiumPerUnit: string;
  commission: string;
  type: 'BUY' | 'SELL';
}): string {
  const w = toCleanGoldDecimal(params.weight);
  const spot = toCleanGoldDecimal(params.spotPricePerUnit);
  const premium = toCleanGoldDecimal(params.premiumPerUnit);
  const comm = toCleanGoldDecimal(params.commission);

  if (w.lte(0)) {
    throw new Error('Gold transaction weight must be strictly positive.');
  }
  if (spot.lte(0)) {
    throw new Error('Gold spotPricePerUnit must be strictly positive.');
  }
  if (premium.isNegative() || comm.isNegative()) {
    throw new Error('Gold premiumPerUnit and commission cannot be negative.');
  }

  const gross = spot.plus(premium).times(w);
  const total =
    params.type === 'BUY' ? gross.plus(comm) : gross.minus(comm);
  return total.toFixed(2);
}

/**
 * Converts a GoldTransaction's total settlement value into THB.
 * - USD-quoted (`XAU_SPOT`, `GOLD_ONLINE_FUTURES`): totalCost (USD) × fxRateAtPurchase
 * - THB-quoted (`PHYSICAL_GOLD`): totalCost is already in THB
 */
export function getTransactionTotalTHB(
  tx: Pick<
    GoldTransaction,
    'assetSubclass' | 'totalCost' | 'fxRateAtPurchase'
  >
): InstanceType<typeof GoldDecimal> {
  const totalNative = toCleanGoldDecimal(tx.totalCost);
  if (isUsdQuotedSubclass(tx.assetSubclass)) {
    const fx = toCleanGoldDecimal(tx.fxRateAtPurchase);
    if (fx.lte(0)) {
      throw new Error('USD-quoted gold transaction requires positive fxRateAtPurchase.');
    }
    return totalNative.times(fx);
  }
  return totalNative;
}

/**
 * Calculates Thai Gold Association (GTA) Theoretical World Parity Price (THB / บาททองคำ 96.5%):
 * Parity = XAUUSD × (15.244 / 31.1034768) × 0.965 × USDTHB
 */
export function calculateTheoreticalThaiGold965THB(
  xauUsdSpot: string,
  usdThbRate: string
): InstanceType<typeof GoldDecimal> {
  const xau = toCleanGoldDecimal(xauUsdSpot);
  const fx = toCleanGoldDecimal(usdThbRate);
  if (xau.lte(0) || fx.lte(0)) {
    throw new Error('XAU/USD spot and USD/THB rate must be strictly positive.');
  }

  return xau
    .times(GRAMS_PER_THAI_BAHT)
    .dividedBy(GRAMS_PER_TROY_OUNCE)
    .times(STANDARD_THAI_PURITY)
    .times(fx);
}

export function buildGoldMarketEnvironment(params: {
  xauUsdSpot: string;
  usdThbRate: string;
  gtaGold965SellTHB: string;
}): GoldMarketEnvironment {
  const theoretical = calculateTheoreticalThaiGold965THB(
    params.xauUsdSpot,
    params.usdThbRate
  );
  const domesticSell = toCleanGoldDecimal(params.gtaGold965SellTHB);
  const diffTHB = domesticSell.minus(theoretical);
  const diffPct = theoretical.gt(0)
    ? diffTHB.dividedBy(theoretical)
    : new GoldDecimal(0);

  return {
    xauUsdSpot: toCleanGoldDecimal(params.xauUsdSpot).toFixed(2),
    usdThbRate: toCleanGoldDecimal(params.usdThbRate).toFixed(4),
    gtaGold965SellTHB: domesticSell.toFixed(2),
    theoreticalGold965THB: theoretical.toFixed(2),
    domesticPremiumTHB: diffTHB.toFixed(2),
    domesticPremiumPct: diffPct.toFixed(4),
  };
}

/**
 * Computes current THB market value per 1 unit of a specific GoldLot/Position
 * given the prevailing GoldMarketEnvironment.
 */
export function getUnitMarketPriceTHB(
  item: {
    assetSubclass: GoldAssetSubclass;
    weightUnit: GoldWeightUnit;
    purity: GoldPurity;
  },
  market: Pick<
    GoldMarketEnvironment,
    'xauUsdSpot' | 'usdThbRate' | 'gtaGold965SellTHB'
  >
): InstanceType<typeof GoldDecimal> {
  const xau = toCleanGoldDecimal(market.xauUsdSpot);
  const fx = toCleanGoldDecimal(market.usdThbRate);
  const gta965 = toCleanGoldDecimal(market.gtaGold965SellTHB);

  // If Physical 96.5% Thai Baht Gold, value directly off domestic GTA 96.5% quote
  if (
    item.assetSubclass === 'PHYSICAL_GOLD' &&
    item.weightUnit === 'THAI_BAHT' &&
    item.purity === '96.5'
  ) {
    return gta965;
  }

  // Otherwise derive exact parity from world XAUUSD (99.99%/fine basis) scaled by weight & purity
  const oneUnitGrams = new GoldDecimal(
    convertGoldWeight('1', item.weightUnit, 'GRAM', 16)
  );
  const purityFactor =
    item.assetSubclass === 'XAU_SPOT' ||
    item.assetSubclass === 'GOLD_ONLINE_FUTURES'
      ? new GoldDecimal(1)
      : toCleanGoldDecimal(item.purity).dividedBy(new GoldDecimal('99.99'));

  const usdPerGram = xau.dividedBy(GRAMS_PER_TROY_OUNCE);
  return oneUnitGrams.times(usdPerGram).times(purityFactor).times(fx);
}

export interface GoldFIFOResult {
  lots: GoldLot[];
  taxHandoffRecords: GoldTaxHandoffRecord[];
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  taxExemptRealizedGLTHB: string;
  taxableRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
  totalPremiumPaidTHB: string;
  premiumDragPct: string;
}

interface InternalGoldLot {
  id: string;
  transactionId: string;
  date: string;
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  weight: InstanceType<typeof GoldDecimal>;
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
  costPerUnitTHB: InstanceType<typeof GoldDecimal>;
  weightSold: InstanceType<typeof GoldDecimal>;
  weightRemain: InstanceType<typeof GoldDecimal>;
  realizedGLTHB: InstanceType<typeof GoldDecimal>;
}

/**
 * Pure Functional FIFO Engine for Gold Holdings (Zero modification to core `fifoEngine.ts`).
 * Computes exact THB Cost Basis (including block premium & commission), Realized G/L,
 * Unrealized G/L, and Block Premium Drag %.
 */
export function calculateGoldFIFO(
  transactions: GoldTransaction[],
  market: Pick<
    GoldMarketEnvironment,
    'xauUsdSpot' | 'usdThbRate' | 'gtaGold965SellTHB'
  >
): GoldFIFOResult {
  const sorted = [...transactions].sort((a, b) => {
    const dateCmp = a.date.localeCompare(b.date);
    if (dateCmp !== 0) return dateCmp;
    if (a.type !== b.type) return a.type === 'BUY' ? -1 : 1;
    return a.id.localeCompare(b.id);
  });

  const queues = new Map<string, InternalGoldLot[]>();
  const allLots: InternalGoldLot[] = [];
  let totalBuyGrossTHB = new GoldDecimal(0);
  let totalPremiumPaidTHB = new GoldDecimal(0);

  for (const tx of sorted) {
    const weightDec = toCleanGoldDecimal(tx.weight);
    if (weightDec.lte(0)) {
      throw new Error(`Invalid non-positive weight on GoldTransaction ${tx.id}`);
    }

    const totalTHB = getTransactionTotalTHB(tx);
    const key = `${tx.symbol.toUpperCase()}|${tx.assetSubclass}|${tx.weightUnit}|${tx.purity}`;

    if (tx.type === 'BUY') {
      const costPerUnitTHB = totalTHB.dividedBy(weightDec);
      const premUnit = toCleanGoldDecimal(tx.premiumPerUnit);
      const fxMult = isUsdQuotedSubclass(tx.assetSubclass)
        ? toCleanGoldDecimal(tx.fxRateAtPurchase)
        : new GoldDecimal(1);

      totalPremiumPaidTHB = totalPremiumPaidTHB.plus(
        premUnit.times(weightDec).times(fxMult)
      );
      totalBuyGrossTHB = totalBuyGrossTHB.plus(totalTHB);

      const lot: InternalGoldLot = {
        id: `glot-${tx.id}`,
        transactionId: tx.id,
        date: tx.date,
        symbol: tx.symbol.toUpperCase(),
        assetSubclass: tx.assetSubclass,
        weight: weightDec,
        weightUnit: tx.weightUnit,
        purity: tx.purity,
        costPerUnitTHB,
        weightSold: new GoldDecimal(0),
        weightRemain: weightDec,
        realizedGLTHB: new GoldDecimal(0),
      };

      const q = queues.get(key) ?? [];
      q.push(lot);
      queues.set(key, q);
      allLots.push(lot);
    } else {
      const q = queues.get(key) ?? [];
      const available = q.reduce(
        (acc, l) => acc.plus(l.weightRemain),
        new GoldDecimal(0)
      );

      if (weightDec.gt(available)) {
        throw new Error(
          `Oversell error on ${tx.symbol}: attempting to sell ${weightDec.toFixed(4)} ${tx.weightUnit}, but only ${available.toFixed(4)} available.`
        );
      }

      const sellProceedsPerUnitTHB = totalTHB.dividedBy(weightDec);
      let remainingToMatch = weightDec;

      for (const lot of q) {
        if (remainingToMatch.isZero()) break;
        if (lot.weightRemain.isZero()) continue;

        const matchedWeight = GoldDecimal.min(
          lot.weightRemain,
          remainingToMatch
        );
        const proceedsTHB = matchedWeight.times(sellProceedsPerUnitTHB);
        const costBasisTHB = matchedWeight.times(lot.costPerUnitTHB);
        const gainTHB = proceedsTHB.minus(costBasisTHB);

        lot.weightSold = lot.weightSold.plus(matchedWeight);
        lot.weightRemain = lot.weightRemain.minus(matchedWeight);
        lot.realizedGLTHB = lot.realizedGLTHB.plus(gainTHB);

        remainingToMatch = remainingToMatch.minus(matchedWeight);
      }
    }
  }

  let totalCostBasisTHB = new GoldDecimal(0);
  let totalMarketValueTHB = new GoldDecimal(0);
  let totalRealizedGLTHB = new GoldDecimal(0);
  let taxExemptRealizedGLTHB = new GoldDecimal(0);
  let taxableRealizedGLTHB = new GoldDecimal(0);
  let totalUnrealizedGLTHB = new GoldDecimal(0);

  const formattedLots: GoldLot[] = allLots.map((lot) => {
    const unitMktPriceTHB = getUnitMarketPriceTHB(lot, market);
    const openCostTHB = lot.weightRemain.times(lot.costPerUnitTHB);
    const openMktTHB = lot.weightRemain.times(unitMktPriceTHB);
    const unrealizedTHB = lot.weightRemain.gt(0)
      ? openMktTHB.minus(openCostTHB)
      : new GoldDecimal(0);
    const isTaxExempt = isThaiPhysicalGoldTaxExempt(
      lot.assetSubclass,
      lot.symbol
    );

    totalCostBasisTHB = totalCostBasisTHB.plus(openCostTHB);
    totalMarketValueTHB = totalMarketValueTHB.plus(openMktTHB);
    totalRealizedGLTHB = totalRealizedGLTHB.plus(lot.realizedGLTHB);
    if (isTaxExempt) {
      taxExemptRealizedGLTHB = taxExemptRealizedGLTHB.plus(lot.realizedGLTHB);
    } else {
      taxableRealizedGLTHB = taxableRealizedGLTHB.plus(lot.realizedGLTHB);
    }
    totalUnrealizedGLTHB = totalUnrealizedGLTHB.plus(unrealizedTHB);

    const status: GoldLot['status'] = lot.weightRemain.isZero()
      ? 'Sold'
      : lot.weightSold.isZero()
        ? 'Hold'
        : 'Partial';

    return {
      id: lot.id,
      transactionId: lot.transactionId,
      symbol: lot.symbol,
      assetSubclass: lot.assetSubclass,
      weight: lot.weight.toFixed(4),
      weightUnit: lot.weightUnit,
      purity: lot.purity,
      costPerUnit: lot.costPerUnitTHB.toFixed(2),
      weightSold: lot.weightSold.toFixed(4),
      weightRemain: lot.weightRemain.toFixed(4),
      realizedGL: lot.realizedGLTHB.toFixed(2),
      unrealizedGL: unrealizedTHB.toFixed(2),
      status,
      isTaxExempt,
    };
  });

  const taxHandoffRecords = formattedLots.map(buildGoldTaxEnginePayload);

  const premiumDragPct = totalBuyGrossTHB.gt(0)
    ? totalPremiumPaidTHB.dividedBy(totalBuyGrossTHB)
    : new GoldDecimal(0);

  return {
    lots: formattedLots,
    taxHandoffRecords,
    totalCostBasisTHB: totalCostBasisTHB.toFixed(2),
    totalMarketValueTHB: totalMarketValueTHB.toFixed(2),
    totalRealizedGLTHB: totalRealizedGLTHB.toFixed(2),
    taxExemptRealizedGLTHB: taxExemptRealizedGLTHB.toFixed(2),
    taxableRealizedGLTHB: taxableRealizedGLTHB.toFixed(2),
    totalUnrealizedGLTHB: totalUnrealizedGLTHB.toFixed(2),
    totalPremiumPaidTHB: totalPremiumPaidTHB.toFixed(2),
    premiumDragPct: premiumDragPct.toFixed(4),
  };
}
