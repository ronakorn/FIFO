import Decimal from 'decimal.js';
import { computeCorporateActionHash } from '../adapters/ibkrFlexAdapter';
import { Lot as FIFOLot } from '../types';
import {
  CorporateAction,
  CorporateActionLot,
  CorporateActionType,
  LotBeforeAfterPreview,
  SplitAdjustmentPreview,
} from '../types/wave1';

/**
 * Institutional Accounting Decimal Engine (strictly precision: 40, ROUND_HALF_UP)
 */
export const ProcessorDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface SplitActionInput {
  id?: string;
  symbol: string;
  ratio: number | string;
  effectiveDate: string;
  type?: CorporateActionType;
}

function isSimpleCorporateActionLot(
  lot: CorporateActionLot | FIFOLot
): lot is CorporateActionLot {
  return 'qty' in lot && typeof lot.costPerUnit === 'string';
}

function normalizeIsoDate(rawDate: string): string {
  const clean = rawDate.trim().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    const parsed = new Date(rawDate);
    if (Number.isNaN(parsed.getTime())) {
      throw new Error(`Invalid date "${rawDate}" in corporateActionProcessor.`);
    }
    return parsed.toISOString().slice(0, 10);
  }
  return clean;
}

/**
 * Computes exact UTC holding period in calendar days (`Days Held`) from `lotDate` to `asOfDate`.
 */
export function calculateLotDaysHeld(
  lotDate: string,
  asOfDate = '2026-10-26'
): number {
  const lotIso = normalizeIsoDate(lotDate);
  const refIso = normalizeIsoDate(asOfDate);
  const lotMs = Date.parse(`${lotIso}T00:00:00.000Z`);
  const refMs = Date.parse(`${refIso}T00:00:00.000Z`);
  return Math.max(0, Math.floor((refMs - lotMs) / 86_400_000));
}

/**
 * Resolves the exact 40-digit share quantity multiplier `m` such that:
 *   newQty         = oldQty × m
 *   newCostPerUnit = (oldQty × oldCostPerUnit) / newQty  (= oldCostPerUnit / m)
 *
 * Supports both Forward Splits (`m > 1`) and Reverse Splits (whether expressed as
 * `type: 'REVERSE_SPLIT', ratio: 10` -> `m = 0.1` OR `ratio: 0.1` -> `m = 0.1`).
 */
export function resolveShareSplitMultiplier(
  action: SplitActionInput
): InstanceType<typeof ProcessorDecimal> {
  const rawRatio = new ProcessorDecimal(String(action.ratio).trim());
  if (!rawRatio.isFinite() || rawRatio.lte(0)) {
    throw new Error('CorporateAction split ratio must be strictly positive.');
  }

  if (action.type === 'REVERSE_SPLIT') {
    return rawRatio.gt(1)
      ? new ProcessorDecimal(1).dividedBy(rawRatio)
      : rawRatio;
  }

  return rawRatio;
}

/**
 * Step 2: `applySplitToLots(lots, action)`
 *
 * Adjusts `Qty` and `Cost/Unit` of eligible FIFO lots (`symbol` match AND `lot.date <= effectiveDate`)
 * using `Decimal.js (precision: 40)` while strictly preserving:
 *   1. Original acquisition `date` (`Days Held` is NEVER reset)
 *   2. Exact `Total Cost Basis` (`Before Total Cost === After Total Cost` 100% per accounting standards)
 */
export function applySplitToLots(
  lots: FIFOLot[],
  action: SplitActionInput
): FIFOLot[];
export function applySplitToLots(
  lots: CorporateActionLot[],
  action: SplitActionInput
): CorporateActionLot[];
export function applySplitToLots(
  lots: (FIFOLot | CorporateActionLot)[],
  action: SplitActionInput
): (FIFOLot | CorporateActionLot)[] {
  const shareMultiplier = resolveShareSplitMultiplier(action);
  const targetSymbol = action.symbol.trim().toUpperCase();
  const effectiveIso = normalizeIsoDate(action.effectiveDate);

  return lots.map((lot) => {
    const lotSymbol = lot.symbol.trim().toUpperCase();
    const lotIso = normalizeIsoDate(lot.date);

    // Post-split lots or other symbols remain 100% untouched
    if (lotSymbol !== targetSymbol || lotIso > effectiveIso) {
      return { ...lot };
    }

    if (isSimpleCorporateActionLot(lot)) {
      const oldQtyDec = new ProcessorDecimal(lot.qty);
      const oldUnitCostDec = new ProcessorDecimal(lot.costPerUnit);
      const exactTotalCost = oldQtyDec.times(oldUnitCostDec);

      const newQtyDec = oldQtyDec.times(shareMultiplier);
      const newUnitCostDec = newQtyDec.gt(0)
        ? exactTotalCost.dividedBy(newQtyDec)
        : oldUnitCostDec.dividedBy(shareMultiplier);

      return {
        ...lot,
        date: lot.date, // Preserve exact acquisition date (Days Held never resets)
        qty: newQtyDec.toDecimalPlaces(8, Decimal.ROUND_HALF_UP).toNumber(),
        costPerUnit: newUnitCostDec.toFixed(4, Decimal.ROUND_HALF_UP),
      };
    }

    // Core CDM FIFOLot (`buyQty`, `qtySold`, `qtyRemain`, `costPerUnit`)
    const oldBuyQtyDec = new ProcessorDecimal(lot.buyQty);
    const oldSoldQtyDec = new ProcessorDecimal(lot.qtySold);
    const oldRemainQtyDec = new ProcessorDecimal(lot.qtyRemain);
    const oldUnitCostDec = new ProcessorDecimal(lot.costPerUnit);

    const exactBuyCostBasis = oldBuyQtyDec.times(oldUnitCostDec);

    const newBuyQtyDec = oldBuyQtyDec.times(shareMultiplier);
    const newSoldQtyDec = oldSoldQtyDec.times(shareMultiplier);
    const newRemainQtyDec = oldRemainQtyDec.times(shareMultiplier);

    const newUnitCostDec = newBuyQtyDec.gt(0)
      ? exactBuyCostBasis.dividedBy(newBuyQtyDec)
      : oldUnitCostDec.dividedBy(shareMultiplier);

    return {
      ...lot,
      date: lot.date, // Preserve exact acquisition date (Days Held never resets)
      buyQty: newBuyQtyDec.toDecimalPlaces(8, Decimal.ROUND_HALF_UP).toNumber(),
      qtySold: newSoldQtyDec
        .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
        .toNumber(),
      qtyRemain: newRemainQtyDec
        .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
        .toNumber(),
      costPerUnit: newUnitCostDec
        .toDecimalPlaces(10, Decimal.ROUND_HALF_UP)
        .toNumber(),
    };
  });
}

/**
 * Generates a Before/After Adjustment Preview for UI confirmation & audit verification,
 * proving Total Cost Basis and Days Held remain 100% invariant before saving.
 */
export function previewSplitOnLots(
  lots: FIFOLot[],
  action: CorporateAction,
  asOfDate = '2026-10-26'
): SplitAdjustmentPreview {
  const adjustedLots = applySplitToLots(lots, action);
  const targetSymbol = action.symbol.trim().toUpperCase();
  const effectiveIso = normalizeIsoDate(action.effectiveDate);

  const lotPreviews: LotBeforeAfterPreview[] = [];
  let sumBefore = new ProcessorDecimal(0);
  let sumAfter = new ProcessorDecimal(0);
  let affectedLotCount = 0;
  let allDaysHeldPreserved = true;

  for (let i = 0; i < lots.length; i += 1) {
    const before = lots[i]!;
    const after = adjustedLots[i]!;
    if (before.symbol.trim().toUpperCase() !== targetSymbol) continue;

    const beforeQty = new ProcessorDecimal(
      before.qtyRemain > 0 ? before.qtyRemain : before.buyQty
    );
    const afterQty = new ProcessorDecimal(
      after.qtyRemain > 0 ? after.qtyRemain : after.buyQty
    );
    const beforeUnit = new ProcessorDecimal(before.costPerUnit);
    const afterUnit = new ProcessorDecimal(after.costPerUnit);

    const beforeTotal = beforeQty.times(beforeUnit);
    const afterTotal = afterQty.times(afterUnit);

    const affected = normalizeIsoDate(before.date) <= effectiveIso;
    if (affected) {
      affectedLotCount += 1;
    }

    const daysBefore = calculateLotDaysHeld(before.date, asOfDate);
    const daysAfter = calculateLotDaysHeld(after.date, asOfDate);
    if (daysBefore !== daysAfter || before.date !== after.date) {
      allDaysHeldPreserved = false;
    }

    sumBefore = sumBefore.plus(beforeTotal);
    sumAfter = sumAfter.plus(afterTotal);

    lotPreviews.push({
      lotId: before.id,
      symbol: before.symbol,
      date: before.date,
      daysHeldBefore: daysBefore,
      daysHeldAfter: daysAfter,
      qtyBefore: beforeQty.toDecimalPlaces(4).toString(),
      qtyAfter: afterQty.toDecimalPlaces(4).toString(),
      costPerUnitBefore: beforeUnit.toFixed(2),
      costPerUnitAfter: afterUnit.toFixed(2),
      totalCostBasisBefore: beforeTotal.toFixed(2),
      totalCostBasisAfter: afterTotal.toFixed(2),
      affected,
    });
  }

  const beforeStr = sumBefore.toFixed(2);
  const afterStr = sumAfter.toFixed(2);

  return {
    actionId: action.id,
    symbol: action.symbol,
    type: action.type,
    ratio: action.ratio,
    effectiveDate: action.effectiveDate,
    affectedLotCount,
    totalCostBeforeTHB: beforeStr,
    totalCostAfterTHB: afterStr,
    isCostBasisPreserved: beforeStr === afterStr,
    isDaysHeldPreserved: allDaysHeldPreserved,
    lotPreviews,
  };
}

// ============================================================================
// Idempotent Portfolio Corporate Action & Pre-Split Hash Registry
// ============================================================================

const syncedActionsByPortfolio = new Map<string, Map<string, CorporateAction>>();
const appliedActionKeys = new Set<string>();
const historicalPreSplitTxHashesByPortfolio = new Map<string, Set<string>>();

export function registerSyncedCorporateActions(
  portfolioId: string,
  actions: CorporateAction[]
): CorporateAction[] {
  const existingMap =
    syncedActionsByPortfolio.get(portfolioId) ??
    new Map<string, CorporateAction>();

  const newlyAdded: CorporateAction[] = [];

  for (const action of actions) {
    const hash =
      action.idempotencyHash ??
      computeCorporateActionHash({
        effectiveDate: action.effectiveDate,
        symbol: action.symbol,
        type: action.type,
        ratio: action.ratio,
      });

    if (!existingMap.has(hash)) {
      const normalized: CorporateAction = {
        ...action,
        idempotencyHash: hash,
      };
      existingMap.set(hash, normalized);
      newlyAdded.push(normalized);
    }
  }

  syncedActionsByPortfolio.set(portfolioId, existingMap);
  return newlyAdded;
}

export function getSyncedCorporateActionsForPortfolios(
  portfolioIds: string[]
): CorporateAction[] {
  const deduped = new Map<string, CorporateAction>();
  for (const pid of portfolioIds) {
    const map = syncedActionsByPortfolio.get(pid);
    if (!map) continue;
    for (const [hash, action] of map.entries()) {
      if (!deduped.has(hash)) {
        deduped.set(hash, { ...action });
      }
    }
  }
  return Array.from(deduped.values());
}

export function findSyncedCorporateActionById(
  portfolioIds: string[],
  actionId: string
): CorporateAction | undefined {
  for (const pid of portfolioIds) {
    const map = syncedActionsByPortfolio.get(pid);
    if (!map) continue;
    for (const action of map.values()) {
      if (action.id === actionId) {
        return { ...action };
      }
    }
  }
  return undefined;
}

export function isPortfolioCorporateActionApplied(
  portfolioIds: string[],
  actionId: string,
  fallbackUserId?: string
): boolean {
  if (portfolioIds.length === 0 && fallbackUserId) {
    return appliedActionKeys.has(`user:${fallbackUserId}:${actionId}`);
  }
  return (
    portfolioIds.length > 0 &&
    portfolioIds.every((pid) => appliedActionKeys.has(`port:${pid}:${actionId}`))
  );
}

export function markPortfolioCorporateActionApplied(
  portfolioIds: string[],
  actionId: string,
  preSplitTxHashes: string[] = [],
  fallbackUserId?: string
): void {
  if (portfolioIds.length === 0 && fallbackUserId) {
    appliedActionKeys.add(`user:${fallbackUserId}:${actionId}`);
    return;
  }
  for (const pid of portfolioIds) {
    appliedActionKeys.add(`port:${pid}:${actionId}`);
    if (preSplitTxHashes.length > 0) {
      const set =
        historicalPreSplitTxHashesByPortfolio.get(pid) ?? new Set<string>();
      for (const h of preSplitTxHashes) {
        set.add(h);
      }
      historicalPreSplitTxHashesByPortfolio.set(pid, set);
    }
  }
}

export function getHistoricalPreSplitTxHashes(
  portfolioId: string
): Set<string> {
  return (
    historicalPreSplitTxHashesByPortfolio.get(portfolioId) ?? new Set<string>()
  );
}
