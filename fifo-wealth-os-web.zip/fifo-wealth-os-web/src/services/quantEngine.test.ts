import Decimal from 'decimal.js';
import {
  buildDashboardAnalytics,
  calculateAssetAllocationFromBuckets,
  calculateMaxDrawdown,
  calculateSharpeRatio,
  calculateSortinoRatio,
  calculateTWR,
  calculateTotalReturn,
  calculateXIRR,
} from './quantEngine';

describe('FIFO Wealth OS - Advanced Analytics & Quant Engine (Decimal.js)', () => {
  describe('1. calculateXIRR (Newton-Raphson with Decimal.js)', () => {
    it('calculates exact 20.00% XIRR ("0.2000") for -100,000 -> +120,000 over 365 days', () => {
      const cashFlows = [
        { date: '2023-01-01', amount: '-100000' },
        { date: '2024-01-01', amount: '120000' },
      ];
      expect(calculateXIRR(cashFlows)).toBe('0.2000');
    });

    it('accounts accurately for 366-day leap year (-100,000 on 2024-01-01 -> +120,000 on 2025-01-01 => ~19.94%)', () => {
      const cashFlows = [
        { date: '2024-01-01', amount: '-100000' },
        { date: '2025-01-01', amount: '120000' },
      ];
      // (1.2)^(365/366) - 1 = 0.199398...
      expect(calculateXIRR(cashFlows)).toBe('0.1994');
    });

    it('solves multi-period irregular DCA cash flows matching analytical NPV = 0', () => {
      const cashFlows = [
        { date: '2023-01-01', amount: '-100000' },
        { date: '2023-07-02', amount: '-50000' }, // +182 days
        { date: '2024-01-01', amount: '175000' }, // +365 days
      ];

      const xirr = calculateXIRR(cashFlows);
      const r = new Decimal(xirr);

      // Verify NPV at solved rate is effectively ~0 (within 4-decimal rounding tolerance)
      const npv = new Decimal('-100000')
        .plus(
          new Decimal('-50000').dividedBy(
            new Decimal(1).plus(r).pow(new Decimal(182).dividedBy(365))
          )
        )
        .plus(new Decimal('175000').dividedBy(new Decimal(1).plus(r)));

      expect(npv.abs().toNumber()).toBeLessThan(8); // < 8 THB on 175,000 THB due to 4-dp output rounding
      expect(Number(xirr)).toBeGreaterThan(0.19);
      expect(Number(xirr)).toBeLessThan(0.21);
    });

    it('calculates negative XIRR accurately for loss scenarios (-15.00%)', () => {
      const cashFlows = [
        { date: '2023-01-01', amount: '-100000' },
        { date: '2024-01-01', amount: '85000' },
      ];
      expect(calculateXIRR(cashFlows)).toBe('-0.1500');
    });

    it('is invariant to input cash flow ordering and does not mutate input array', () => {
      const unsorted = [
        { date: '2024-01-01', amount: '120000' },
        { date: '2023-01-01', amount: '-100000' },
      ];
      const copy = JSON.parse(JSON.stringify(unsorted));
      expect(calculateXIRR(unsorted)).toBe('0.2000');
      expect(unsorted).toEqual(copy);
    });

    it('throws descriptive errors for invalid cash flow signs or insufficient entries', () => {
      expect(() =>
        calculateXIRR([{ date: '2023-01-01', amount: '-100000' }])
      ).toThrow(/at least 2 cash flows/i);

      expect(() =>
        calculateXIRR([
          { date: '2023-01-01', amount: '-100000' },
          { date: '2024-01-01', amount: '-50000' },
        ])
      ).toThrow(/negative.*positive/i);
    });
  });

  describe('2. calculateTWR (Geometric Sub-Period Linking)', () => {
    it('captures volatility drag accurately: +10% followed by -10% equals -1.00% ("-0.0100")', () => {
      expect(calculateTWR(['0.10', '-0.10'])).toBe('-0.0100');
    });

    it('compounds multi-period returns without IEEE-754 floating-point drift', () => {
      // 1.1 * 1.2 - 1 = 0.32 exactly
      expect(calculateTWR(['0.1', '0.2'])).toBe('0.3200');
      // 1.05 * 1.03 * 0.98 * 1.04 - 1 = 0.1022668 -> 0.1023
      expect(calculateTWR(['0.05', '0.03', '-0.02', '0.04'])).toBe('0.1023');
    });

    it('returns "0.0000" for empty sub-period array and rejects <-100% loss', () => {
      expect(calculateTWR([])).toBe('0.0000');
      expect(() => calculateTWR(['0.05', '-1.05'])).toThrow(/>100% loss/i);
    });
  });

  describe('3. calculateSharpeRatio & calculateSortinoRatio', () => {
    it('matches hand-calculated Sample Sharpe Ratio baseline ("1.5492")', () => {
      // Mean = 0.05, Rf = 0.01 => Excess = 0.04
      // Sample Variance = (0.0009 + 0.0001 + 0.0001 + 0.0009) / 3 = 0.002 / 3
      // StdDev = sqrt(0.002 / 3) = 0.02581988897...
      // Sharpe = 0.04 / 0.02581988897... = 1.549193... -> "1.5492"
      const sharpe = calculateSharpeRatio(['0.02', '0.04', '0.06', '0.08'], '0.01');
      expect(sharpe).toBe('1.5492');
    });

    it('returns "0.0000" safely when return series has zero volatility', () => {
      expect(calculateSharpeRatio(['0.03', '0.03', '0.03'], '0.01')).toBe('0.0000');
    });

    it('matches hand-calculated Sortino Ratio baseline ("0.2774")', () => {
      // Mean = 0.015, Rf = 0.01 => Excess = 0.005
      // Downside vs 0.01: [0, -0.03, 0, -0.02] => sq sum = 0.0013
      // DownsideDev = sqrt(0.0013 / 4) = 0.018027756...
      // Sortino = 0.005 / 0.018027756... = 0.27735... -> "0.2774"
      const sortino = calculateSortinoRatio(['0.05', '-0.02', '0.04', '-0.01'], '0.01');
      expect(sortino).toBe('0.2774');
    });
  });

  describe('4. calculateMaxDrawdown (Peak-to-Trough Decline)', () => {
    it('identifies the deepest Peak-to-Trough decline across multiple peaks and recoveries ("0.3000")', () => {
      // Peak 120,000 -> Trough 84,000 = 36,000 / 120,000 = 0.3000 (30.00% drawdown)
      const curve = ['100000', '120000', '90000', '115000', '84000', '135000'];
      expect(calculateMaxDrawdown(curve)).toBe('0.3000');
    });

    it('returns "0.0000" when equity curve rises monotonically', () => {
      expect(calculateMaxDrawdown(['100', '105.50', '112.75', '130.00'])).toBe('0.0000');
    });

    it('throws descriptive error on empty or non-positive equity values', () => {
      expect(() => calculateMaxDrawdown([])).toThrow(/at least 1/i);
      expect(() => calculateMaxDrawdown(['100', '0', '90'])).toThrow(/must be > 0/i);
    });
  });

  describe('5. Total Return, 5-Bucket Asset Allocation & Dashboard Quant Aggregator', () => {
    it('computes exact Total Return and 5-category THB Asset Allocation weights', () => {
      expect(calculateTotalReturn('100000', '124560')).toBe('0.2456');

      const allocation = calculateAssetAllocationFromBuckets({
        THAI_EQUITY: '50000',
        FOREIGN_EQUITY: '75000',
        CRYPTO: '50000',
        GOLD: '15000',
        CASH: '10000',
      });

      expect(allocation).toHaveLength(5);
      const foreign = allocation.find((a) => a.category === 'FOREIGN_EQUITY');
      const crypto = allocation.find((a) => a.category === 'CRYPTO');
      expect(foreign?.weightPct).toBe('37.50');
      expect(crypto?.weightPct).toBe('25.00');
    });

    it('builds complete DashboardAnalyticsResponse for SP500 and SET50 benchmarks', () => {
      const response = buildDashboardAnalytics({
        cashFlows: [
          { date: '2024-05-01', amount: '-150000' },
          { date: '2024-08-15', amount: '-25000' },
        ],
        openLots: [
          {
            id: 'L1',
            date: '2024-05-01',
            symbol: 'AAPL',
            buyQty: 10,
            costPerUnit: 5000,
            qtySold: 0,
            qtyRemain: 10,
            realizedGL: 0,
            unrealizedGL: 8000,
            status: 'Hold',
          },
          {
            id: 'L2',
            date: '2024-05-02',
            symbol: 'BTC',
            buyQty: 0.06,
            costPerUnit: 2000000,
            qtySold: 0,
            qtyRemain: 0.06,
            realizedGL: 0,
            unrealizedGL: 15000,
            status: 'Hold',
          },
        ],
        realizedProceedsCashTHB: '12000',
        benchmark: 'SET50',
      });

      expect(response.benchmark).toBe('SET50');
      expect(response.benchmarkSeries).toHaveLength(6);
      expect(response.assetAllocation).toHaveLength(5);
      expect(Number(response.metrics.totalReturn)).toBeGreaterThan(0);
      expect(Number(response.metrics.maxDrawdown)).toBeGreaterThan(0);
    });
  });
});
