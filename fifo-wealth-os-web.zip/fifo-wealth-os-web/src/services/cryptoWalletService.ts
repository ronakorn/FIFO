import { CryptoWallet as PrismaCryptoWallet } from '@prisma/client';
import { computeTransactionHash } from '../adapters/ibkrFlexAdapter';
import {
  assertPublicAddressOnly,
  CryptoDecimal,
  defaultCryptoIndexer,
  detectChainFromAddress,
  encryptWalletAddress,
  hashWalletAddress,
  mapOnChainActivitiesToCDM,
  maskWalletAddress,
  PrivateKeySecurityError,
} from '../adapters/cryptoIndexerAdapter';
import { getPrismaClient } from '../db/prisma';
import { AppError } from '../middleware/errorHandler';
import { formatExactDecimalString } from '../parsers/csvUtils';
import {
  CDMOnChainTransaction,
  ChainIndexerProvider,
  CryptoWalletPublic,
  CryptoWalletSyncResult,
  SupportedChain,
} from '../types/crypto';
import {
  defaultBotFxProvider,
  FXRateProvider as BotFXRateProvider,
} from './botFxProvider';
import { assertTransactionDatesWithinAnnualLimit } from './entitlementService';
import { decryptData } from './encryptionService';

export function toPublicCryptoWallet(
  row: PrismaCryptoWallet
): CryptoWalletPublic {
  return {
    id: row.id,
    portfolioId: row.portfolioId,
    chain: row.chain as SupportedChain,
    addressMasked: row.addressMasked,
    addressHash: row.addressHash,
    label: row.label,
    isActive: row.isActive,
    lastSyncedAt: row.lastSyncedAt ? row.lastSyncedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    readOnly: true,
    privacyProtection: 'AES-256-GCM + SHA-256',
  };
}

export interface RegisterCryptoWalletInput {
  userId: string;
  address: string;
  chain?: SupportedChain;
  label?: string;
  portfolioId?: string;
}

export async function registerCryptoWallet(
  input: RegisterCryptoWalletInput
): Promise<CryptoWalletPublic> {
  const prisma = getPrismaClient();

  try {
    assertPublicAddressOnly(input.address);
  } catch (err) {
    if (err instanceof PrivateKeySecurityError) {
      throw new AppError(400, err.code, err.message);
    }
    throw new AppError(
      400,
      'INVALID_WALLET_ADDRESS',
      err instanceof Error ? err.message : 'Invalid wallet address.'
    );
  }

  const detectedChain = detectChainFromAddress(input.address);
  if (!detectedChain) {
    throw new AppError(
      400,
      'UNSUPPORTED_ADDRESS_FORMAT',
      'Unable to detect supported chain (EVM 0x..., Solana Base58, or BTC bc1.../1.../3...) from wallet address.'
    );
  }

  const chain: SupportedChain = input.chain ?? detectedChain;
  if (chain !== detectedChain) {
    throw new AppError(
      400,
      'CHAIN_ADDRESS_MISMATCH',
      `Address format corresponds to ${detectedChain}, not ${chain}.`
    );
  }

  if (input.portfolioId) {
    const owned = await prisma.portfolio.findFirst({
      where: { id: input.portfolioId, userId: input.userId },
    });
    if (!owned) {
      throw new AppError(
        403,
        'FORBIDDEN_PORTFOLIO_ACCESS',
        'You do not have permission to link this portfolio.'
      );
    }
  }

  const addressHash = hashWalletAddress(chain, input.address);
  const encryptedAddress = encryptWalletAddress(chain, input.address);
  const addressMasked = maskWalletAddress(chain, input.address);
  const cleanLabel = input.label?.trim() ? input.label.trim() : null;

  const existing = await prisma.cryptoWallet.findUnique({
    where: {
      userId_chain_addressHash: {
        userId: input.userId,
        chain,
        addressHash,
      },
    },
  });

  if (existing) {
    throw new AppError(
      409,
      'WALLET_ALREADY_CONNECTED',
      `This ${chain} wallet (${addressMasked}) is already connected to your account.`
    );
  }

  const created = await prisma.$transaction(async (txClient) => {
    const wallet = await txClient.cryptoWallet.create({
      data: {
        userId: input.userId,
        portfolioId: input.portfolioId ?? null,
        chain,
        address: encryptedAddress,
        addressHash,
        addressMasked,
        label: cleanLabel,
        isActive: true,
      },
    });

    await txClient.auditLog.create({
      data: {
        userId: input.userId,
        entityType: 'CRYPTO_WALLET',
        entityId: wallet.id,
        action: 'CREATE',
        beforeState: null,
        afterState: JSON.stringify(toPublicCryptoWallet(wallet)),
      },
    });

    return wallet;
  });

  return toPublicCryptoWallet(created);
}

export async function listUserCryptoWallets(
  userId: string
): Promise<CryptoWalletPublic[]> {
  const prisma = getPrismaClient();
  const rows = await prisma.cryptoWallet.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  });
  return rows.map(toPublicCryptoWallet);
}

export async function setCryptoWalletActiveState(
  userId: string,
  walletId: string,
  isActive: boolean
): Promise<CryptoWalletPublic> {
  const prisma = getPrismaClient();
  const existing = await prisma.cryptoWallet.findUnique({
    where: { id: walletId },
  });
  if (!existing) {
    throw new AppError(404, 'WALLET_NOT_FOUND', 'Crypto wallet not found.');
  }
  if (existing.userId !== userId) {
    throw new AppError(
      403,
      'FORBIDDEN_WALLET_ACCESS',
      'You do not have permission to modify this wallet.'
    );
  }

  const updated = await prisma.$transaction(async (txClient) => {
    const w = await txClient.cryptoWallet.update({
      where: { id: walletId },
      data: { isActive },
    });

    await txClient.auditLog.create({
      data: {
        userId,
        entityType: 'CRYPTO_WALLET',
        entityId: walletId,
        action: 'UPDATE',
        beforeState: JSON.stringify(toPublicCryptoWallet(existing)),
        afterState: JSON.stringify(toPublicCryptoWallet(w)),
      },
    });

    return w;
  });

  return toPublicCryptoWallet(updated);
}

export async function deleteCryptoWallet(
  userId: string,
  walletId: string
): Promise<{ id: string; deleted: true }> {
  const prisma = getPrismaClient();
  const existing = await prisma.cryptoWallet.findUnique({
    where: { id: walletId },
  });
  if (!existing) {
    throw new AppError(404, 'WALLET_NOT_FOUND', 'Crypto wallet not found.');
  }
  if (existing.userId !== userId) {
    throw new AppError(
      403,
      'FORBIDDEN_WALLET_ACCESS',
      'You do not have permission to delete this wallet.'
    );
  }

  await prisma.$transaction(async (txClient) => {
    await txClient.cryptoWallet.delete({ where: { id: walletId } });
    await txClient.auditLog.create({
      data: {
        userId,
        entityType: 'CRYPTO_WALLET',
        entityId: walletId,
        action: 'DELETE',
        beforeState: JSON.stringify(toPublicCryptoWallet(existing)),
        afterState: null,
      },
    });
  });

  return { id: walletId, deleted: true };
}

export interface SyncCryptoWalletOptions {
  portfolioId?: string;
  indexer?: ChainIndexerProvider;
  botFxProvider?: BotFXRateProvider;
}

export async function syncCryptoWalletOnChain(
  userId: string,
  walletId: string,
  options: SyncCryptoWalletOptions = {}
): Promise<CryptoWalletSyncResult> {
  const prisma = getPrismaClient();
  const wallet = await prisma.cryptoWallet.findUnique({
    where: { id: walletId },
  });

  if (!wallet) {
    throw new AppError(404, 'WALLET_NOT_FOUND', 'Crypto wallet not found.');
  }
  if (wallet.userId !== userId) {
    throw new AppError(
      403,
      'FORBIDDEN_WALLET_ACCESS',
      'You do not have permission to sync this wallet.'
    );
  }
  if (!wallet.isActive) {
    throw new AppError(
      400,
      'WALLET_INACTIVE',
      'This wallet is currently paused. Activate it before syncing on-chain data.'
    );
  }

  // Resolve target portfolio owned by `userId`
  const requestedPortfolioId =
    options.portfolioId ?? wallet.portfolioId ?? undefined;
  let targetPortfolio = requestedPortfolioId
    ? await prisma.portfolio.findFirst({
        where: { id: requestedPortfolioId, userId },
      })
    : null;

  if (requestedPortfolioId && !targetPortfolio) {
    throw new AppError(
      403,
      'FORBIDDEN_PORTFOLIO_ACCESS',
      'Target portfolio not found or not owned by user.'
    );
  }

  if (!targetPortfolio) {
    const userPortfolios = await prisma.portfolio.findMany({
      where: { userId },
      orderBy: { createdAt: 'asc' },
    });
    targetPortfolio =
      userPortfolios.find(
        (p) =>
          p.name.toUpperCase().includes('CRYPTO') ||
          p.name.toUpperCase().includes('ON-CHAIN') ||
          p.name.toUpperCase().includes('BITKUB')
      ) ??
      userPortfolios[0] ??
      null;
  }

  if (!targetPortfolio) {
    targetPortfolio = await prisma.portfolio.create({
      data: {
        userId,
        name: `Cross-Chain Crypto Vault (${wallet.chain})`,
        baseCurrency: 'THB',
      },
    });
  }

  // Decrypt wallet address strictly in memory, query indexer, then wipe reference immediately
  let plainAddress = '';
  const chain = wallet.chain as SupportedChain;
  const indexer = options.indexer ?? defaultCryptoIndexer;

  let tokenBalances;
  let activities;
  try {
    plainAddress = decryptData(wallet.address);
    [tokenBalances, activities] = await Promise.all([
      indexer.getTokenBalances(chain, plainAddress),
      indexer.getTransactionHistory(chain, plainAddress),
    ]);
  } finally {
    plainAddress = '';
  }

  const cdmTransactions = mapOnChainActivitiesToCDM(activities);

  // Deduplicate against existing DB transactions in `targetPortfolio`
  const existingDbTxs = await prisma.transaction.findMany({
    where: { portfolioId: targetPortfolio.id },
  });

  const existingHashes = new Set<string>(
    existingDbTxs.map((t) =>
      computeTransactionHash({
        date: t.date,
        symbol: t.symbol,
        qty: t.qty,
        price: t.price,
        type: t.type,
      })
    )
  );

  const uniqueNewCdm: CDMOnChainTransaction[] = [];
  let skippedTransactions = 0;

  for (const cdm of cdmTransactions) {
    const dbFingerprint = computeTransactionHash({
      date: cdm.date,
      symbol: cdm.symbol,
      qty: cdm.qty,
      price: cdm.price,
      type: cdm.type,
    });

    if (existingHashes.has(dbFingerprint)) {
      skippedTransactions += 1;
    } else {
      existingHashes.add(dbFingerprint);
      uniqueNewCdm.push(cdm);
    }
  }

  // Enrich USD -> portfolio baseCurrency (THB) using BOT FX rate at 40-digit Decimal precision
  const fxService = options.botFxProvider ?? defaultBotFxProvider;
  const targetBase = targetPortfolio.baseCurrency.trim().toUpperCase();
  const enrichedCdm: CDMOnChainTransaction[] = [];

  for (const cdm of uniqueNewCdm) {
    if (targetBase === 'USD') {
      enrichedCdm.push({
        ...cdm,
        fxRate: '1.00',
        netTHB: cdm.originalNet,
      });
    } else {
      const rateStr = await fxService.getHistoricalRate('USD', cdm.date);
      const rateDec = new CryptoDecimal(rateStr);
      const netThbDec = new CryptoDecimal(cdm.originalNet).times(rateDec);
      enrichedCdm.push({
        ...cdm,
        fxRate: rateStr,
        netTHB: formatExactDecimalString(netThbDec),
      });
    }
  }

  await assertTransactionDatesWithinAnnualLimit(
    userId,
    enrichedCdm.map((transaction) => transaction.date)
  );

  const syncedAt = new Date();
  const portfolioId = targetPortfolio.id;

  const updatedWallet = await prisma.$transaction(async (txClient) => {
    for (const cdm of enrichedCdm) {
      await txClient.transaction.create({
        data: {
          portfolioId,
          date: cdm.date,
          symbol: cdm.symbol,
          type: cdm.type,
          exchange: cdm.exchange,
          qty: cdm.qty,
          price: cdm.price,
          gross: cdm.exactGrossDecimal,
          comm: cdm.exactCommDecimal,
          vat: '0.00',
          net: cdm.originalNet,
          originalCurrency: cdm.originalCurrency,
          fxRate: cdm.fxRate,
          netTHB: cdm.netTHB,
        },
      });
    }

    const savedWallet = await txClient.cryptoWallet.update({
      where: { id: wallet.id },
      data: {
        lastSyncedAt: syncedAt,
        portfolioId,
      },
    });

    await txClient.auditLog.create({
      data: {
        userId,
        entityType: 'CRYPTO_WALLET',
        entityId: wallet.id,
        action: 'SYNC_ONCHAIN',
        beforeState: JSON.stringify({
          lastSyncedAt: wallet.lastSyncedAt?.toISOString() ?? null,
        }),
        afterState: JSON.stringify({
          walletMasked: wallet.addressMasked,
          chain,
          portfolioId,
          discoveredOnChainCount: activities.length,
          addedTransactions: enrichedCdm.length,
          skippedTransactions,
          lastSyncedAt: syncedAt.toISOString(),
        }),
      },
    });

    return savedWallet;
  });

  const swaps = activities.filter((a) => a.kind === 'SWAP').length;
  const transfers = activities.filter((a) => a.kind === 'TRANSFER').length;
  const buyLegs = cdmTransactions.filter((c) => c.type === 'BUY').length;
  const sellLegs = cdmTransactions.filter((c) => c.type === 'SELL').length;
  const feeLegs = cdmTransactions.filter((c) => c.type === 'FEE').length;

  return {
    wallet: toPublicCryptoWallet(updatedWallet),
    providerName: indexer.providerName,
    portfolioId,
    tokenBalances,
    discoveredOnChainCount: activities.length,
    generatedCdmCount: cdmTransactions.length,
    addedTransactions: enrichedCdm.length,
    skippedTransactions,
    breakdown: {
      swaps,
      transfers,
      buyLegs,
      sellLegs,
      feeLegs,
    },
    syncedAt: syncedAt.toISOString(),
  };
}
