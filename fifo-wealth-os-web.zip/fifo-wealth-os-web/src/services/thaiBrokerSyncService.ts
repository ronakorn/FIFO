import { BrokerConnection as PrismaBrokerConnection } from '@prisma/client';
import {
  computeDividendHash,
  computeTransactionHash,
} from '../adapters/ibkrFlexAdapter';
import {
  defaultBitkubAdapter,
  defaultDimeAdapter,
  defaultStreamingModule,
  maskCredentialIdentifier,
  THAI_BROKER_CATALOG,
} from '../adapters/thaiBrokerAdapters';
import { mapEngineTransactionToPrismaCreate } from '../api/mappers';
import { getPrismaClient } from '../db/prisma';
import { AppError } from '../middleware/errorHandler';
import { Dividend, Transaction } from '../types';
import { BrokerSyncStatus } from '../types/sync';
import {
  CURRENT_PDPA_CONSENT_VERSION,
  PdpaConsentInput,
  THAI_BROKER_IDS,
  ThaiBrokerConnectionMode,
  ThaiBrokerConnectionPublic,
  ThaiBrokerCredentials,
  ThaiBrokerDisconnectResult,
  ThaiBrokerDataSource,
  ThaiBrokerId,
  ThaiBrokerParseResult,
  ThaiBrokerSyncResult,
} from '../types/thaiBrokers';
import { decryptData, encryptData, getDefaultEncryptionKey } from './encryptionService';
import { assertTransactionDatesWithinAnnualLimit } from './entitlementService';

function requireThaiBrokerEncryptionKey(): string {
  const configured = process.env['ENCRYPTION_KEY'];
  if (configured && configured.trim().length >= 32) return configured;

  // The shared encryption service has a deterministic mock fallback for legacy tests.
  // Thai broker credentials must never use it in an application/runtime environment.
  if (process.env['NODE_ENV'] === 'test') return getDefaultEncryptionKey();

  throw new AppError(
    500,
    'BROKER_ENCRYPTION_KEY_NOT_CONFIGURED',
    'Thai broker connections are disabled until a dedicated ENCRYPTION_KEY of at least 32 characters is configured.'
  );
}

export function toPublicThaiBrokerConnection(
  broker: ThaiBrokerId,
  row: PrismaBrokerConnection | null
): ThaiBrokerConnectionPublic {
  const catalog = THAI_BROKER_CATALOG[broker];

  if (!row || row.status === 'DISCONNECTED') {
    return {
      id: null,
      broker,
      displayName: catalog.displayName,
      regulatoryBadge: catalog.regulatoryBadge,
      partnerBadge: 'Official Partner Integration Ready',
      connectionMode: catalog.defaultMode,
      dataSource: 'NOT_TESTED',
      maskedAccountRef: null,
      portfolioId: null,
      status: 'DISCONNECTED',
      connected: false,
      readOnly: true,
      encryption: 'AES-256-GCM',
      pdpaConsented: false,
      pdpaConsentedAt: null,
      pdpaConsentVersion: null,
      lastSyncedAt: null,
      futureRoadmapNote: catalog.futureRoadmapNote,
    };
  }

  return {
    id: row.id,
    broker,
    displayName: catalog.displayName,
    regulatoryBadge: catalog.regulatoryBadge,
    partnerBadge: 'Official Partner Integration Ready',
    connectionMode:
      (row.connectionMode as ThaiBrokerConnectionMode) || catalog.defaultMode,
    dataSource: (row.dataSource as ThaiBrokerDataSource) || 'NOT_TESTED',
    maskedAccountRef: row.flexQueryId,
    portfolioId: row.portfolioId,
    status: row.status as BrokerSyncStatus,
    connected: row.status === 'CONNECTED' || row.status === 'SYNCING',
    readOnly: true,
    encryption: 'AES-256-GCM',
    pdpaConsented: Boolean(row.pdpaConsentedAt),
    pdpaConsentedAt: row.pdpaConsentedAt
      ? row.pdpaConsentedAt.toISOString()
      : null,
    pdpaConsentVersion: row.pdpaConsentVersion,
    lastSyncedAt: row.lastSyncedAt ? row.lastSyncedAt.toISOString() : null,
    futureRoadmapNote: catalog.futureRoadmapNote,
  };
}

export async function listThaiBrokerConnections(
  userId: string
): Promise<ThaiBrokerConnectionPublic[]> {
  const prisma = getPrismaClient();
  const rows = await prisma.brokerConnection.findMany({
    where: {
      userId,
      brokerName: { in: [...THAI_BROKER_IDS] },
    },
  });

  const byBroker = new Map<string, PrismaBrokerConnection>();
  for (const r of rows) {
    byBroker.set(r.brokerName, r);
  }

  return THAI_BROKER_IDS.map((broker) =>
    toPublicThaiBrokerConnection(broker, byBroker.get(broker) ?? null)
  );
}

export interface ConnectThaiBrokerInput {
  userId: string;
  credentials: ThaiBrokerCredentials;
  pdpaConsent: PdpaConsentInput;
  portfolioId?: string;
}

export async function connectThaiBroker(
  input: ConnectThaiBrokerInput
): Promise<ThaiBrokerConnectionPublic> {
  const prisma = getPrismaClient();

  // Strict PDPA B.E. 2562 & Thai SEC Data Privacy Consent Enforcement
  if (!input.pdpaConsent || input.pdpaConsent.accepted !== true) {
    throw new AppError(
      400,
      'PDPA_CONSENT_REQUIRED',
      'ต้องให้ความยินยอมเปิดเผยข้อมูลส่วนบุคคลตาม พ.ร.บ. คุ้มครองข้อมูลส่วนบุคคล (PDPA) และหลักเกณฑ์ Read-Only ก่อนเชื่อมต่อโบรกเกอร์'
    );
  }

  if (input.portfolioId) {
    const owned = await prisma.portfolio.findFirst({
      where: { id: input.portfolioId, userId: input.userId },
    });
    if (!owned) {
      throw new AppError(
        403,
        'FORBIDDEN_PORTFOLIO_ACCESS',
        'You do not have permission to access this portfolio.'
      );
    }
  }

  const broker = input.credentials.broker;
  let maskedRef: string;
  let connectionMode: ThaiBrokerConnectionMode;

  try {
    if (input.credentials.broker === 'BITKUB') {
      defaultBitkubAdapter.validateCredentials(input.credentials);
      maskedRef = maskCredentialIdentifier('BTK', input.credentials.apiKey);
      connectionMode = 'READ_ONLY_API';
    } else if (input.credentials.broker === 'DIME') {
      defaultDimeAdapter.validateCredentials(input.credentials);
      maskedRef = maskCredentialIdentifier(
        'DIME',
        input.credentials.dimeAccountRef
      );
      connectionMode = input.credentials.mode ?? 'OPEN_API_HYBRID';
    } else {
      defaultStreamingModule.validateCredentials(input.credentials);
      maskedRef = maskCredentialIdentifier(
        input.credentials.memberBrokerCode.toUpperCase(),
        input.credentials.accountRef
      );
      connectionMode = 'SECURE_STATEMENT_AUTOMATION';
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Invalid credentials.';
    const code = msg.includes('SECURITY_SCOPE_REJECTED')
      ? 'SECURITY_SCOPE_REJECTED'
      : 'INVALID_BROKER_CREDENTIALS';
    throw new AppError(400, code, msg);
  }

  // Encrypt full credential JSON strictly via AES-256-GCM
  const encryptedPayload = encryptData(
    JSON.stringify(input.credentials),
    requireThaiBrokerEncryptionKey()
  );
  const consentedAt = new Date();
  const consentVersion =
    input.pdpaConsent.consentVersion?.trim() || CURRENT_PDPA_CONSENT_VERSION;

  const saved = await prisma.$transaction(async (txClient) => {
    const row = await txClient.brokerConnection.upsert({
      where: {
        userId_brokerName: {
          userId: input.userId,
          brokerName: broker,
        },
      },
      create: {
        userId: input.userId,
        portfolioId: input.portfolioId ?? null,
        brokerName: broker,
        flexQueryTokenEncrypted: encryptedPayload,
        flexQueryId: maskedRef,
        connectionMode,
        dataSource: 'NOT_TESTED',
        pdpaConsentedAt: consentedAt,
        pdpaConsentVersion: consentVersion,
        status: 'CONNECTED',
      },
      update: {
        portfolioId: input.portfolioId ?? undefined,
        flexQueryTokenEncrypted: encryptedPayload,
        flexQueryId: maskedRef,
        connectionMode,
        dataSource: 'NOT_TESTED',
        pdpaConsentedAt: consentedAt,
        pdpaConsentVersion: consentVersion,
        status: 'CONNECTED',
      },
    });

    await txClient.auditLog.create({
      data: {
        userId: input.userId,
        entityType: 'THAI_BROKER_CONNECTION',
        entityId: row.id,
        action: 'GRANT_PDPA_CONSENT_AND_CONNECT',
        beforeState: null,
        afterState: JSON.stringify({
          broker,
          maskedAccountRef: maskedRef,
          connectionMode,
          pdpaConsentedAt: consentedAt.toISOString(),
          pdpaConsentVersion: consentVersion,
          purposes: input.pdpaConsent.purposes ?? [
            'READ_ONLY_PORTFOLIO_SYNC',
            'THAI_TAX_FIFO_CALCULATION',
          ],
          encryption: 'AES-256-GCM',
        }),
      },
    });

    return row;
  });

  return toPublicThaiBrokerConnection(broker, saved);
}

export async function triggerThaiBrokerSync(
  userId: string,
  broker: ThaiBrokerId,
  options: { portfolioId?: string; delayMs?: number } = {}
): Promise<ThaiBrokerSyncResult> {
  const prisma = getPrismaClient();
  const connection = await prisma.brokerConnection.findUnique({
    where: {
      userId_brokerName: {
        userId,
        brokerName: broker,
      },
    },
  });

  if (!connection || connection.status === 'DISCONNECTED') {
    throw new AppError(
      404,
      'BROKER_NOT_CONNECTED',
      `No active ${broker} Read-Only connection found.`
    );
  }

  if (!connection.pdpaConsentedAt) {
    throw new AppError(
      403,
      'PDPA_CONSENT_MISSING',
      `PDPA Data Privacy Consent is required before syncing ${broker}.`
    );
  }

  let decryptedJson = '';
  let parsedCreds: ThaiBrokerCredentials;
  try {
    decryptedJson = decryptData(
      connection.flexQueryTokenEncrypted,
      requireThaiBrokerEncryptionKey()
    );
    parsedCreds = JSON.parse(decryptedJson) as ThaiBrokerCredentials;
  } catch {
    await prisma.brokerConnection.update({
      where: { id: connection.id },
      data: { status: 'ERROR' },
    });
    throw new AppError(
      500,
      'CREDENTIAL_DECRYPTION_FAILED',
      `Unable to authenticate stored AES-256-GCM credentials for ${broker}.`
    );
  } finally {
    decryptedJson = '';
  }

  await prisma.brokerConnection.update({
    where: { id: connection.id },
    data: { status: 'SYNCING' },
  });

  try {
    if (options.delayMs && options.delayMs > 0) {
      await new Promise((r) => setTimeout(r, Math.min(options.delayMs!, 5000)));
    }

    const requestedPortfolioId =
      options.portfolioId ?? connection.portfolioId ?? undefined;
    let targetPortfolio = requestedPortfolioId
      ? await prisma.portfolio.findFirst({
          where: { id: requestedPortfolioId, userId },
        })
      : null;

    if (requestedPortfolioId && !targetPortfolio) {
      throw new AppError(
        403,
        'FORBIDDEN_PORTFOLIO_ACCESS',
        'You do not have permission to sync into this portfolio.'
      );
    }

    if (!targetPortfolio) {
      const userPortfolios = await prisma.portfolio.findMany({
        where: { userId },
        orderBy: { createdAt: 'asc' },
      });
      targetPortfolio =
        userPortfolios.find((p) =>
          p.name.toUpperCase().includes(broker)
        ) ??
        userPortfolios[0] ??
        null;
    }

    if (!targetPortfolio) {
      targetPortfolio = await prisma.portfolio.create({
        data: {
          userId,
          name: `${THAI_BROKER_CATALOG[broker].displayName} Portfolio`,
          baseCurrency: 'THB',
        },
      });
    }

    let parsedResult: ThaiBrokerParseResult;
    if (parsedCreds.broker === 'BITKUB') {
      parsedResult = await defaultBitkubAdapter.syncReadOnly(parsedCreds);
    } else if (parsedCreds.broker === 'DIME') {
      parsedResult = await defaultDimeAdapter.syncReadOnly(parsedCreds);
    } else {
      parsedResult = await defaultStreamingModule.syncReadOnly(parsedCreds);
    }

    // Wipe parsed credential fields in memory
    parsedCreds = { broker: 'DIME', dimeAccountRef: 'REDACTED' };

    const [existingTxs, existingDivs] = await Promise.all([
      prisma.transaction.findMany({
        where: { portfolioId: targetPortfolio.id },
      }),
      prisma.dividend.findMany({
        where: { portfolioId: targetPortfolio.id },
      }),
    ]);

    const seenTxHashes = new Set<string>(
      existingTxs.map((t) =>
        computeTransactionHash({
          date: t.date,
          symbol: t.symbol,
          qty: t.qty,
          price: t.price,
          type: t.type,
        })
      )
    );

    const seenDivHashes = new Set<string>(
      existingDivs.map((d) =>
        computeDividendHash({
          date: d.date,
          symbol: d.symbol,
          qty: d.qty,
          gross: d.gross,
        })
      )
    );

    const uniqueNewTxs: Transaction[] = [];
    let skippedTransactions = 0;
    for (const tx of parsedResult.transactions) {
      const hash =
        parsedResult.transactionHashes[tx.id] ??
        computeTransactionHash({
          date: tx.date,
          symbol: tx.symbol,
          qty: tx.qty,
          price: tx.price,
          type: tx.type,
        });

      if (seenTxHashes.has(hash)) {
        skippedTransactions += 1;
      } else {
        seenTxHashes.add(hash);
        uniqueNewTxs.push(tx);
      }
    }

    const uniqueNewDivs: Dividend[] = [];
    let skippedDividends = 0;
    for (const div of parsedResult.dividends) {
      const hash =
        parsedResult.dividendHashes[div.id] ??
        computeDividendHash({
          date: div.date,
          symbol: div.symbol,
          qty: div.qty,
          gross: div.gross,
        });

      if (seenDivHashes.has(hash)) {
        skippedDividends += 1;
      } else {
        seenDivHashes.add(hash);
        uniqueNewDivs.push(div);
      }
    }

    await assertTransactionDatesWithinAnnualLimit(
      userId,
      uniqueNewTxs.map((transaction) => transaction.date)
    );

    const syncedAt = new Date();
    const portfolioId = targetPortfolio.id;
    const dataSource: ThaiBrokerDataSource =
      broker === 'BITKUB' && process.env['BITKUB_PARTNER_API_URL']
        ? 'LIVE_PARTNER_API'
        : 'SANDBOX_MOCK';

    await prisma.$transaction(async (txClient) => {
      for (const tx of uniqueNewTxs) {
        await txClient.transaction.create({
          data: {
            ...mapEngineTransactionToPrismaCreate(tx, portfolioId),
            sourceConnector: broker,
          },
        });
      }

      for (const div of uniqueNewDivs) {
        await txClient.dividend.create({
          data: {
            sourceConnector: broker,
            portfolioId,
            date: div.date,
            symbol: div.symbol,
            qty: div.qty,
            divPerShare: div.divPerShare,
            gross: div.gross,
            whtRate: div.whtRate,
            wht: div.wht,
            net: div.net,
            originalCurrency: div.originalCurrency,
            fxRate: div.fxRate,
            grossTHB: div.grossTHB,
            whtTHB: div.whtTHB,
            netTHB: div.netTHB,
          },
        });
      }

      await txClient.brokerConnection.update({
        where: { id: connection.id },
        data: {
          status: 'CONNECTED',
          dataSource,
          lastSyncedAt: syncedAt,
          portfolioId,
        },
      });

      await txClient.auditLog.create({
        data: {
          userId,
          entityType: 'THAI_BROKER_CONNECTION',
          entityId: connection.id,
          action: 'SYNC_READ_ONLY',
          beforeState: null,
          afterState: JSON.stringify({
            broker,
            portfolioId,
            dataSource,
            addedTransactions: uniqueNewTxs.length,
            addedDividends: uniqueNewDivs.length,
            skippedTransactions,
            skippedDividends,
            syncedAt: syncedAt.toISOString(),
          }),
        },
      });
    });

    return {
      broker,
      connectionMode: parsedResult.connectionMode,
      dataSource,
      portfolioId,
      addedTransactions: uniqueNewTxs.length,
      addedDividends: uniqueNewDivs.length,
      skippedTransactions,
      skippedDividends,
      status: 'CONNECTED',
      lastSyncedAt: syncedAt.toISOString(),
    };
  } catch (err) {
    const connectionStatus =
      err instanceof AppError && err.code === 'SUBSCRIPTION_LIMIT_REACHED'
        ? 'CONNECTED'
        : 'ERROR';
    await prisma.brokerConnection
      .update({
        where: { id: connection.id },
        data: { status: connectionStatus },
      })
      .catch(() => undefined);
    throw err;
  }
}

/**
 * PDPA Right to be Forgotten ("Disconnect & Purge Data"):
 * Atomically deletes encrypted API credentials, revokes PDPA consent, AND purges
 * synced transactions and dividends tagged to `broker` across the user's owned portfolios.
 */
export async function disconnectAndPurgeThaiBroker(
  userId: string,
  broker: ThaiBrokerId,
  options: { purgeSyncedData?: boolean } = { purgeSyncedData: true }
): Promise<ThaiBrokerDisconnectResult> {
  const prisma = getPrismaClient();
  const shouldPurge = options.purgeSyncedData !== false;

  const existing = await prisma.brokerConnection.findUnique({
    where: {
      userId_brokerName: {
        userId,
        brokerName: broker,
      },
    },
  });

  const userPortfolios = await prisma.portfolio.findMany({
    where: { userId },
    select: { id: true },
  });
  const ownedPortfolioIds = userPortfolios.map((p) => p.id);

  let purgedTransactionsCount = 0;
  let purgedDividendsCount = 0;

  await prisma.$transaction(async (txClient) => {
    if (shouldPurge && ownedPortfolioIds.length > 0) {
      const [deletedTxs, deletedDividends] = await Promise.all([
        txClient.transaction.deleteMany({
          where: {
            portfolioId: { in: ownedPortfolioIds },
            sourceConnector: broker,
          },
        }),
        txClient.dividend.deleteMany({
          where: {
            portfolioId: { in: ownedPortfolioIds },
            sourceConnector: broker,
          },
        }),
      ]);
      purgedTransactionsCount = deletedTxs.count;
      purgedDividendsCount = deletedDividends.count;
    }

    await txClient.brokerConnection.deleteMany({
      where: {
        userId,
        brokerName: broker,
      },
    });

    await txClient.auditLog.create({
      data: {
        userId,
        entityType: 'THAI_BROKER_CONNECTION',
        entityId: existing?.id ?? `${userId}:${broker}`,
        action: 'PURGE_RIGHT_TO_BE_FORGOTTEN',
        beforeState: existing
          ? JSON.stringify({
              broker,
              maskedAccountRef: existing.flexQueryId,
              pdpaConsentedAt: existing.pdpaConsentedAt?.toISOString() ?? null,
            })
          : null,
        afterState: JSON.stringify({
          disconnected: true,
          credentialsPurged: true,
          pdpaConsentRevoked: true,
          purgedTransactionsCount,
          purgedDividendsCount,
        }),
      },
    });
  });

  return {
    broker,
    disconnected: true,
    credentialsPurged: true,
    pdpaConsentRevoked: true,
    purgedTransactionsCount,
    purgedDividendsCount,
    connection: toPublicThaiBrokerConnection(broker, null),
  };
}
