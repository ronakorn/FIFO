export {
  FXRateProvider,
  HistoricalRateTable,
  MockFXRateProvider,
  normalizeFXDateKey,
} from './fxRateService';
export { enrichTransactionsWithFX } from './transactionEnricher';
export { enrichDividendsWithFX } from './dividendEnricher';
export {
  THAI_PIT_BRACKETS,
  ProgressiveTaxBracket,
  calculateProgressivePIT,
  calculateThaiTax,
  formatTaxAmount,
} from './thaiTaxEngine';
export {
  TaxReportPDFOptions,
  TaxReportPDFResult,
  generateTaxReportPDF,
  generateTaxReportPDFBuffer,
} from './taxReportGenerator';
export {
  QuantPortfolioSnapshotInput,
  buildDashboardAnalytics,
  calculateAssetAllocationFromBuckets,
  calculateMaxDrawdown,
  calculateSharpeRatio,
  calculateSortinoRatio,
  calculateTWR,
  calculateTotalReturn,
  calculateXIRR,
  classifySymbolToAssetClass,
} from './quantEngine';
export {
  MonteCarloOptions,
  calculateFIRENumber,
  calculateGoalProgress,
  calculateYearsToFIRE,
  runMonteCarloSimulation,
} from './fireEngine';
