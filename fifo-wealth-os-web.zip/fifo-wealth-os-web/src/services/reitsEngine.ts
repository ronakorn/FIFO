import Decimal from 'decimal.js';
import type { REITDistributionFrequency } from '../types/advancedAssets';

export const ReitDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface REITValuation {
  navPerUnit: string;
  marketPrice: string;
  premiumDiscount: string;
  distributionYield: string;
  /** Distribution / NAV proxy only; it is not a property-level real-estate cap rate. */
  capRate: string;
  ffoPerUnit: string;
  affoPerUnit: string;
  capRateIsProxy: true;
  affoMaintenanceCapexPerUnit: string;
  notes: string[];
}

export interface REITDistributionSchedule {
  periodAmount: string;
  annualTotal: string;
  periodsPerYear: number;
  paymentDates: string[];
}

function parseDecimal(value: string, label: string): Decimal {
  try {
    const result = new ReitDecimal(value);
    if (!result.isFinite()) throw new Error();
    return result;
  } catch {
    throw new Error(`${label} must be a finite decimal string.`);
  }
}

function positive(value: string, label: string): Decimal {
  const result = parseDecimal(value, label);
  if (!result.gt(0)) throw new Error(`${label} must be greater than zero.`);
  return result;
}

function nonNegative(value: string, label: string): Decimal {
  const result = parseDecimal(value, label);
  if (result.isNegative()) throw new Error(`${label} cannot be negative.`);
  return result;
}

function fixed(value: Decimal, places: number): string {
  return value.toDecimalPlaces(places, ReitDecimal.ROUND_HALF_UP).toFixed(places);
}

/**
 * Calculate unit-level REIT ratios using exact decimal arithmetic.
 * When maintenance capex is omitted, AFFO uses an explicitly disclosed 10% of FFO proxy.
 */
export function calculateREITValuation(
  navPerUnit: string,
  marketPrice: string,
  annualDistributionPerUnit: string,
  ffoPerUnit: string,
  maintenanceCapexPerUnit?: string,
): REITValuation {
  const nav = positive(navPerUnit, 'navPerUnit');
  const price = positive(marketPrice, 'marketPrice');
  const distribution = nonNegative(annualDistributionPerUnit, 'annualDistributionPerUnit');
  const ffo = nonNegative(ffoPerUnit, 'ffoPerUnit');
  const capex = maintenanceCapexPerUnit === undefined || maintenanceCapexPerUnit.trim() === ''
    ? ffo.times('0.10')
    : nonNegative(maintenanceCapexPerUnit, 'maintenanceCapexPerUnit');
  if (capex.gt(ffo)) throw new Error('maintenanceCapexPerUnit cannot exceed ffoPerUnit.');

  const premiumDiscount = price.minus(nav).dividedBy(nav);
  const distributionYield = distribution.dividedBy(price);
  const distributionToNavProxy = distribution.dividedBy(nav);
  const affo = ffo.minus(capex);
  const notes = [
    'Distribution / NAV is a proxy and must not be presented as a property-level capitalization rate.',
    ...(maintenanceCapexPerUnit === undefined || maintenanceCapexPerUnit.trim() === ''
      ? ['AFFO uses a default 10% of FFO maintenance-capex proxy; replace with fund-reported capex when available.']
      : []),
  ];

  return {
    navPerUnit: fixed(nav, 4),
    marketPrice: fixed(price, 4),
    premiumDiscount: fixed(premiumDiscount, 4),
    distributionYield: fixed(distributionYield, 4),
    capRate: fixed(distributionToNavProxy, 4),
    ffoPerUnit: fixed(ffo, 4),
    affoPerUnit: fixed(affo, 4),
    capRateIsProxy: true,
    affoMaintenanceCapexPerUnit: fixed(capex, 4),
    notes,
  };
}

/** Annualized distribution schedule; actual payment dates are supplied by a fund's statement separately. */
export function calculateREITDistributionSchedule(
  annualDistributionPerUnit: string,
  frequency: REITDistributionFrequency,
  unitsHeld: number | string,
): REITDistributionSchedule {
  const annualPerUnit = nonNegative(annualDistributionPerUnit, 'annualDistributionPerUnit');
  const units = positive(String(unitsHeld), 'unitsHeld');
  const periodsByFrequency: Record<REITDistributionFrequency, number> = {
    MONTHLY: 12,
    QUARTERLY: 4,
    SEMI_ANNUAL: 2,
    ANNUAL: 1,
  };
  const periodsPerYear = periodsByFrequency[frequency];
  if (!periodsPerYear) throw new Error('Unsupported REIT distribution frequency.');
  const annualTotal = annualPerUnit.times(units);
  return {
    periodAmount: fixed(annualTotal.dividedBy(periodsPerYear), 2),
    annualTotal: fixed(annualTotal, 2),
    periodsPerYear,
    paymentDates: [],
  };
}
