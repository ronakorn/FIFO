import Decimal from 'decimal.js';
import { formatExactDecimalString } from '../parsers/csvUtils';
import { BASE_CURRENCY, Dividend } from '../types';
import { FXRateProvider } from './fxRateService';

/**
 * Isolated IEEE 754-2008 decimal128 configuration (34 significant digits)
 * ensuring zero intermediate rounding during Dividend FX enrichment.
 */
const Dec = Decimal.clone({
  precision: 34,
  rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Enriches an array of Dividend records into Base Currency (THB) using historical FX rates
 * on each dividend's receipt date (`div.date`).
 *
 * Strictly uses `decimal.js` string multiplication with zero intermediate rounding.
 */
export async function enrichDividendsWithFX(
  dividends: Dividend[],
  fxProvider: FXRateProvider,
  baseCurrency: string = BASE_CURRENCY
): Promise<Dividend[]> {
  const normalizedBase = baseCurrency.trim().toUpperCase();
  if (!normalizedBase) {
    throw new Error('baseCurrency must be a non-empty currency code.');
  }

  const enriched: Dividend[] = [];

  for (const div of dividends) {
    const normalizedOrig = div.originalCurrency.trim().toUpperCase();
    if (!normalizedOrig) {
      throw new Error(`Missing originalCurrency on dividend ID "${div.id}".`);
    }

    const grossDec = new Dec(div.gross.trim());
    const whtDec = new Dec(div.wht.trim());
    const netDec = new Dec(div.net.trim());

    if (grossDec.lt(0) || whtDec.lt(0) || netDec.lt(0)) {
      throw new Error(`Negative dividend fields are invalid on dividend ID "${div.id}".`);
    }

    if (normalizedOrig === normalizedBase) {
      enriched.push({
        ...div,
        originalCurrency: normalizedOrig,
        fxRate: '1.00',
        grossTHB: div.gross.trim(),
        whtTHB: div.wht.trim(),
        netTHB: div.net.trim(),
      });
      continue;
    }

    const fxRate = await fxProvider.getHistoricalRate(normalizedOrig, normalizedBase, div.date);
    const fxRateDec = new Dec(fxRate.trim());

    if (!fxRateDec.isFinite() || fxRateDec.lte(0)) {
      throw new Error(
        `Invalid FX rate "${fxRate}" returned for ${normalizedOrig}/${normalizedBase} on "${div.date}".`
      );
    }

    // Strict Decimal multiplication ONLY — Zero Intermediate Rounding
    const grossTHB = formatExactDecimalString(grossDec.times(fxRateDec));
    const whtTHB = formatExactDecimalString(whtDec.times(fxRateDec));
    const netTHB = formatExactDecimalString(netDec.times(fxRateDec));

    enriched.push({
      ...div,
      originalCurrency: normalizedOrig,
      fxRate: fxRate.trim(),
      grossTHB,
      whtTHB,
      netTHB,
    });
  }

  return enriched;
}
