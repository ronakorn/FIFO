import Decimal from 'decimal.js';
import { Lot as FIFOLot } from '../types';
import { CorporateAction, CorporateActionLot } from '../types/wave1';

const FinDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type Lot = CorporateActionLot;

/**
 * Curated institutional Corporate Action feed (Mock Yahoo Finance / Bloomberg corporate actions)
 * Includes historical benchmark splits (e.g. AAPL 2020-08-31 4:1 Split, NVDA 2024-06-10 10:1 Split)
 * as well as current 2026 corporate actions for live portfolio testing.
 */
const MOCK_CORPORATE_ACTIONS_FEED: CorporateAction[] = [
  {
    id: 'CA-001',
    symbol: 'AAPL',
    type: 'STOCK_SPLIT',
    ratio: 4.0, // 4:1 split
    effectiveDate: '2020-08-31',
    announcementDate: '2020-07-30',
    adjustmentFactor: 0.25,
    description: 'Apple 4-for-1 Stock Split',
    title: 'Apple Inc. (AAPL) — 4:1 Forward Stock Split (2020)',
  },
  {
    id: 'CA-002',
    symbol: 'NVDA',
    type: 'STOCK_SPLIT',
    ratio: 10.0, // 10:1 split
    effectiveDate: '2024-06-10',
    announcementDate: '2024-05-22',
    adjustmentFactor: 0.1,
    description: 'NVIDIA 10-for-1 Forward Stock Split',
    title: 'NVIDIA Corp. (NVDA) — 10:1 Forward Stock Split (2024)',
  },
  {
    id: 'ca-nvda-split-2026',
    symbol: 'NVDA',
    type: 'STOCK_SPLIT',
    ratio: 2,
    effectiveDate: '2026-10-15',
    announcementDate: '2026-09-25',
    adjustmentFactor: 0.5,
    description: 'NVIDIA Corp. (NVDA) — 2:1 Forward Stock Split',
    title: 'NVIDIA Corp. (NVDA) — 2:1 Forward Stock Split',
  },
  {
    id: 'ca-aapl-split-2026',
    symbol: 'AAPL',
    type: 'STOCK_SPLIT',
    ratio: 4,
    effectiveDate: '2026-10-20',
    announcementDate: '2026-10-01',
    adjustmentFactor: 0.25,
    description: 'Apple Inc. (AAPL) — 4:1 Forward Stock Split',
    title: 'Apple Inc. (AAPL) — 4:1 Forward Stock Split',
  },
  {
    id: 'ca-tsla-split-2026',
    symbol: 'TSLA',
    type: 'STOCK_SPLIT',
    ratio: 3,
    effectiveDate: '2026-08-25',
    announcementDate: '2026-08-05',
    adjustmentFactor: 0.3333,
    description: 'Tesla Inc. (TSLA) — 3:1 Forward Stock Split',
    title: 'Tesla Inc. (TSLA) — 3:1 Forward Stock Split',
  },
  {
    id: 'ca-lcid-revsplit-2026',
    symbol: 'LCID',
    type: 'REVERSE_SPLIT',
    ratio: 10,
    effectiveDate: '2026-09-10',
    announcementDate: '2026-08-20',
    adjustmentFactor: 10,
    description: 'Lucid Group (LCID) — 1:10 Reverse Stock Split',
    title: 'Lucid Group (LCID) — 1:10 Reverse Stock Split',
  },
];

function isSimpleCorporateActionLot(
  lot: CorporateActionLot | FIFOLot
): lot is CorporateActionLot {
  return 'qty' in lot && typeof lot.costPerUnit === 'string';
}

function validateRatio(ratio: number): Decimal {
  const ratioDec = new FinDecimal(ratio);
  if (!ratioDec.isFinite() || ratioDec.lte(0)) {
    throw new Error(
      'CorporateAction ratio must be strictly greater than zero.'
    );
  }
  return ratioDec;
}

/**
 * Applies a Forward Stock Split (`Qty * ratio`, `Cost/Unit / ratio`) via Decimal.js (precision: 40).
 * - Only adjusts lots of matching symbol acquired on or before `action.effectiveDate`
 *   (preventing post-split lots from being split a second time).
 * - Preserves `lot.date` so holding period (`Days Held`) is never reset.
 * - Supports both `CorporateActionLot[]` (`{ qty, costPerUnit: string }`) and Core `FIFOLot[]`.
 */
export function applyStockSplit(
  lots: CorporateActionLot[],
  action: CorporateAction
): CorporateActionLot[];
export function applyStockSplit(
  lots: FIFOLot[],
  action: CorporateAction
): FIFOLot[];
export function applyStockSplit(
  lots: (CorporateActionLot | FIFOLot)[],
  action: CorporateAction
): (CorporateActionLot | FIFOLot)[] {
  if (action.type === 'REVERSE_SPLIT') {
    return applyReverseSplit(lots as FIFOLot[], action);
  }

  const ratioDec = validateRatio(action.ratio);
  const targetSymbol = action.symbol.trim().toUpperCase();
  const effectiveIso = action.effectiveDate.slice(0, 10);

  return lots.map((lot) => {
    const lotSymbol = lot.symbol.trim().toUpperCase();
    const lotDateIso = lot.date.slice(0, 10);

    if (lotSymbol !== targetSymbol || lotDateIso > effectiveIso) {
      return { ...lot };
    }

    if (isSimpleCorporateActionLot(lot)) {
      const newQty = new FinDecimal(lot.qty)
        .times(ratioDec)
        .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
        .toNumber();
      const newCostPerUnit = new FinDecimal(lot.costPerUnit)
        .dividedBy(ratioDec)
        .toFixed(4, Decimal.ROUND_HALF_UP);

      return {
        ...lot,
        date: lot.date,
        qty: newQty,
        costPerUnit: newCostPerUnit,
      };
    }

    const newBuyQty = new FinDecimal(lot.buyQty)
      .times(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();
    const newQtySold = new FinDecimal(lot.qtySold)
      .times(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();
    const newQtyRemain = new FinDecimal(lot.qtyRemain)
      .times(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();
    const newCostPerUnit = new FinDecimal(lot.costPerUnit)
      .dividedBy(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();

    return {
      ...lot,
      date: lot.date,
      buyQty: newBuyQty,
      qtySold: newQtySold,
      qtyRemain: newQtyRemain,
      costPerUnit: newCostPerUnit,
    };
  });
}

/**
 * Applies a Reverse Stock Split (`Qty / ratio`, `Cost/Unit * ratio`) via Decimal.js (precision: 40).
 * - Only adjusts lots of matching symbol acquired on or before `action.effectiveDate`.
 * - Preserves `lot.date` so holding period (`Days Held`) is never reset.
 * - Supports both `CorporateActionLot[]` (`{ qty, costPerUnit: string }`) and Core `FIFOLot[]`.
 */
export function applyReverseSplit(
  lots: CorporateActionLot[],
  action: CorporateAction
): CorporateActionLot[];
export function applyReverseSplit(
  lots: FIFOLot[],
  action: CorporateAction
): FIFOLot[];
export function applyReverseSplit(
  lots: (CorporateActionLot | FIFOLot)[],
  action: CorporateAction
): (CorporateActionLot | FIFOLot)[] {
  const ratioDec = validateRatio(action.ratio);
  const targetSymbol = action.symbol.trim().toUpperCase();
  const effectiveIso = action.effectiveDate.slice(0, 10);

  return lots.map((lot) => {
    const lotSymbol = lot.symbol.trim().toUpperCase();
    const lotDateIso = lot.date.slice(0, 10);

    if (lotSymbol !== targetSymbol || lotDateIso > effectiveIso) {
      return { ...lot };
    }

    if (isSimpleCorporateActionLot(lot)) {
      const newQty = new FinDecimal(lot.qty)
        .dividedBy(ratioDec)
        .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
        .toNumber();
      const newCostPerUnit = new FinDecimal(lot.costPerUnit)
        .times(ratioDec)
        .toFixed(4, Decimal.ROUND_HALF_UP);

      return {
        ...lot,
        date: lot.date,
        qty: newQty,
        costPerUnit: newCostPerUnit,
      };
    }

    const newBuyQty = new FinDecimal(lot.buyQty)
      .dividedBy(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();
    const newQtySold = new FinDecimal(lot.qtySold)
      .dividedBy(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();
    const newQtyRemain = new FinDecimal(lot.qtyRemain)
      .dividedBy(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();
    const newCostPerUnit = new FinDecimal(lot.costPerUnit)
      .times(ratioDec)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toNumber();

    return {
      ...lot,
      date: lot.date,
      buyQty: newBuyQty,
      qtySold: newQtySold,
      qtyRemain: newQtyRemain,
      costPerUnit: newCostPerUnit,
    };
  });
}

/**
 * Detects Stock Splits and Reverse Splits for a symbol (or 'ALL') within an ISO date range.
 */
export function detectCorporateActions(
  symbol: string,
  dateRange: { start: string; end: string }
): CorporateAction[] {
  const normalizedSymbol = symbol.trim().toUpperCase();
  const startIso = dateRange.start.slice(0, 10);
  const endIso = dateRange.end.slice(0, 10);

  return MOCK_CORPORATE_ACTIONS_FEED.filter((ca) => {
    const symbolMatch =
      !normalizedSymbol ||
      normalizedSymbol === 'ALL' ||
      normalizedSymbol === '*' ||
      ca.symbol.toUpperCase() === normalizedSymbol;

    const eff = ca.effectiveDate.slice(0, 10);
    return symbolMatch && eff >= startIso && eff <= endIso;
  }).map((item) => ({ ...item }));
}

export function findCorporateActionById(
  id: string
): CorporateAction | undefined {
  const found = MOCK_CORPORATE_ACTIONS_FEED.find((a) => a.id === id);
  return found ? { ...found } : undefined;
}
