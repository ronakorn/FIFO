import Decimal from 'decimal.js';
import {
  blackScholesPrice,
  calculateImpliedVolatility,
  calculateOptionPayoff,
  cumulativeNormalCDF,
  OptDecimal,
} from './optionsEngine';
import { calculateREITDistributionSchedule, calculateREITValuation } from './reitsEngine';
import { calculateIRR, calculatePEMetrics, generateJCurveData } from './privateEquityEngine';
import {
  calculateLiquidationPrice,
  calculateMarginHealth,
  calculateMarkToMarket,
  type FuturesPosition,
} from './futuresRiskEngine';
import {
  buildSampleOptionsChain,
  filterSamplePEFunds,
  getSamplePEFundDetail,
  getSamplePEFunds,
  getSampleREITPeers,
  sortREITPeers,
  toggleREITPeerSelection,
} from './advancedAssetPolish';
import type { PECashFlow } from '../types/advancedAssets';

const TestDecimal = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

function within(actual: string | Decimal, expected: string, tolerance: string): boolean {
  return new TestDecimal(actual).minus(expected).abs().lte(tolerance);
}

const atTheMoneyCall = {
  underlyingPrice: '100',
  strikePrice: '100',
  timeToExpiry: '0.25',
  riskFreeRate: '0.05',
  volatility: '0.20',
  optionType: 'CALL' as const,
};

const datedReturnFlows: PECashFlow[] = [
  { date: '2020-01-01', amount: '-100', type: 'CALL' },
  { date: '2020-12-31', amount: '110', type: 'DISTRIBUTION' },
];

const futuresScenario: FuturesPosition = {
  id: 'test-s50',
  symbol: 'S50Z26',
  side: 'LONG',
  qty: 8,
  entryPrice: '870',
  markPrice: '886',
  contractSize: 200,
  multiplier: '1',
  initialMargin: '150000',
  maintenanceMargin: '120000',
};

describe('Options engine — Decimal Black–Scholes, Greeks, IV and payoff', () => {
  it('uses a symmetric standard-normal CDF approximation around zero', () => {
    expect(within(cumulativeNormalCDF(new OptDecimal(0)), '0.5', '0.0000001')).toBe(true);
    const positive = cumulativeNormalCDF(new OptDecimal('1.25'));
    const negative = cumulativeNormalCDF(new OptDecimal('-1.25'));
    expect(within(positive.plus(negative), '1', '0.0000001')).toBe(true);
  });

  it('matches a standard-normal reference point near 1.96 sigma', () => {
    expect(within(cumulativeNormalCDF(new OptDecimal('1.96')), '0.975002', '0.00001')).toBe(true);
  });

  it('prices the reference at-the-money call near 4.615, not 3.99', () => {
    const result = blackScholesPrice(atTheMoneyCall);
    expect(within(result.theoreticalPrice, '4.6150', '0.005')).toBe(true);
  });

  it('returns the complete call Greeks with expected signs and units', () => {
    const result = blackScholesPrice(atTheMoneyCall);
    expect(within(result.delta, '0.5695', '0.001')).toBe(true);
    expect(new TestDecimal(result.gamma).isPositive()).toBe(true);
    expect(new TestDecimal(result.theta).isNegative()).toBe(true);
    expect(new TestDecimal(result.vega).isPositive()).toBe(true);
    expect(new TestDecimal(result.rho).isPositive()).toBe(true);
  });

  it('returns put Greeks with negative delta and negative rho', () => {
    const result = blackScholesPrice({ ...atTheMoneyCall, optionType: 'PUT' });
    expect(within(result.delta, '-0.4305', '0.001')).toBe(true);
    expect(new TestDecimal(result.rho).isNegative()).toBe(true);
  });

  it('respects put-call parity within displayed price rounding', () => {
    const call = blackScholesPrice(atTheMoneyCall);
    const put = blackScholesPrice({ ...atTheMoneyCall, optionType: 'PUT' });
    const discount = new TestDecimal('-0.05').times('0.25').exp();
    const left = new TestDecimal(call.theoreticalPrice).minus(put.theoreticalPrice);
    const right = new TestDecimal('100').minus(new TestDecimal('100').times(discount));
    expect(left.minus(right).abs().lte('0.0002')).toBe(true);
  });

  it('keeps call and put deltas one unit apart', () => {
    const call = blackScholesPrice(atTheMoneyCall);
    const put = blackScholesPrice({ ...atTheMoneyCall, optionType: 'PUT' });
    expect(within(new TestDecimal(call.delta).minus(put.delta), '1', '0.0002')).toBe(true);
  });

  it('handles expiry with intrinsic value and finite limiting delta', () => {
    const result = blackScholesPrice({ ...atTheMoneyCall, underlyingPrice: '110', timeToExpiry: '0' });
    expect(result.theoreticalPrice).toBe('10.0000');
    expect(result.delta).toBe('1.0000');
    expect(result.gamma).toBe('0.000000');
  });

  it('handles expiry-at-the-money with the half-delta convention', () => {
    const result = blackScholesPrice({ ...atTheMoneyCall, timeToExpiry: '0' });
    expect(result.delta).toBe('0.5000');
    expect(result.theoreticalPrice).toBe('0.0000');
  });

  it('rejects negative time to expiry', () => {
    expect(() => blackScholesPrice({ ...atTheMoneyCall, timeToExpiry: '-0.1' })).toThrow('timeToExpiry cannot be negative');
  });

  it('rejects zero volatility for positive expiry', () => {
    expect(() => blackScholesPrice({ ...atTheMoneyCall, volatility: '0' })).toThrow('volatility must be greater than zero');
  });

  it('rejects volatility above the configured 500% cap', () => {
    expect(() => blackScholesPrice({ ...atTheMoneyCall, volatility: '5.01' })).toThrow('volatility cannot exceed');
  });

  it('round-trips a call market price through the implied-volatility solver', () => {
    const market = blackScholesPrice({ ...atTheMoneyCall, volatility: '0.35' }).theoreticalPrice;
    const implied = calculateImpliedVolatility(market, '100', '100', '0.25', '0.05', 'CALL');
    expect(within(implied, '0.35', '0.0001')).toBe(true);
  });

  it('round-trips a put market price through the implied-volatility solver', () => {
    const market = blackScholesPrice({ ...atTheMoneyCall, volatility: '0.22', optionType: 'PUT' }).theoreticalPrice;
    const implied = calculateImpliedVolatility(market, '100', '100', '0.25', '0.05', 'PUT');
    expect(within(implied, '0.22', '0.0001')).toBe(true);
  });

  it('rejects option prices outside no-arbitrage bounds', () => {
    expect(() => calculateImpliedVolatility('150', '100', '100', '0.25', '0.05', 'CALL')).toThrow('no-arbitrage bounds');
  });

  it('reports the minimum positive volatility for a price at the call no-arbitrage lower bound', () => {
    const discountedStrike = new OptDecimal('100').times(new OptDecimal('-0.05').times('0.25').exp());
    const lowerBound = new OptDecimal('100').minus(discountedStrike).toString();
    expect(calculateImpliedVolatility(lowerBound, '100', '100', '0.25', '0.05', 'CALL')).toBe('0.000001');
  });

  it('calculates a long call net payoff at expiry including contract size', () => {
    expect(calculateOptionPayoff('CALL', '100', '120', '5', 100)).toBe('1500.00');
  });

  it('calculates a long put net payoff at expiry', () => {
    expect(calculateOptionPayoff('PUT', '100', '80', '5', 10)).toBe('150.00');
  });

  it('returns the premium loss when a long call expires out of the money', () => {
    expect(calculateOptionPayoff('CALL', '100', '90', '5', 100)).toBe('-500.00');
  });

  it('rejects a non-integer or zero contract size', () => {
    expect(() => calculateOptionPayoff('CALL', '100', '120', '5', 0)).toThrow('contractSize must be a positive whole number');
    expect(() => calculateOptionPayoff('CALL', '100', '120', '5', 1.5)).toThrow('contractSize must be a positive whole number');
  });
});

describe('REIT engine — valuation and distribution schedule', () => {
  it('calculates premium/discount, distribution yield and NAV proxy', () => {
    const result = calculateREITValuation('12', '10', '0.6', '1');
    expect(result.premiumDiscount).toBe('-0.1667');
    expect(result.distributionYield).toBe('0.0600');
    expect(result.capRate).toBe('0.0500');
    expect(result.capRateIsProxy).toBe(true);
  });

  it('uses and discloses a default maintenance-capex proxy for AFFO', () => {
    const result = calculateREITValuation('12', '10', '0.6', '1');
    expect(result.affoPerUnit).toBe('0.9000');
    expect(result.affoMaintenanceCapexPerUnit).toBe('0.1000');
    expect(result.notes.some((note) => note.includes('10%'))).toBe(true);
  });

  it('accepts fund-reported maintenance capex instead of the default proxy', () => {
    const result = calculateREITValuation('12', '10', '0.6', '1', '0.18');
    expect(result.affoPerUnit).toBe('0.8200');
    expect(result.affoMaintenanceCapexPerUnit).toBe('0.1800');
    expect(result.notes.some((note) => note.includes('default 10%'))).toBe(false);
  });

  it('rejects zero NAV or market price', () => {
    expect(() => calculateREITValuation('0', '10', '0.6', '1')).toThrow('navPerUnit must be greater than zero');
    expect(() => calculateREITValuation('12', '0', '0.6', '1')).toThrow('marketPrice must be greater than zero');
  });

  it('rejects capex greater than FFO', () => {
    expect(() => calculateREITValuation('12', '10', '0.6', '1', '1.01')).toThrow('cannot exceed ffoPerUnit');
  });

  it('rejects negative annual distributions', () => {
    expect(() => calculateREITValuation('12', '10', '-0.1', '1')).toThrow('annualDistributionPerUnit cannot be negative');
  });

  it('estimates a quarterly payout and annual total for held units', () => {
    const result = calculateREITDistributionSchedule('0.65', 'QUARTERLY', '30000');
    expect(result.periodAmount).toBe('4875.00');
    expect(result.annualTotal).toBe('19500.00');
    expect(result.periodsPerYear).toBe(4);
    expect(result.paymentDates).toEqual([]);
  });

  it('calculates monthly, semi-annual and annual schedules', () => {
    expect(calculateREITDistributionSchedule('12', 'MONTHLY', '1').periodAmount).toBe('1.00');
    expect(calculateREITDistributionSchedule('12', 'SEMI_ANNUAL', '1').periodAmount).toBe('6.00');
    expect(calculateREITDistributionSchedule('12', 'ANNUAL', '1').periodAmount).toBe('12.00');
  });

  it('rounds per-period distributions half-up at currency precision', () => {
    const result = calculateREITDistributionSchedule('0.10', 'QUARTERLY', '1');
    expect(result.periodAmount).toBe('0.03');
  });

  it('rejects zero units held', () => {
    expect(() => calculateREITDistributionSchedule('0.65', 'QUARTERLY', '0')).toThrow('unitsHeld must be greater than zero');
  });
});

describe('Private equity engine — XIRR, fund multiples and J-curve series', () => {
  it('calculates a one-year dated return with actual/365 day count', () => {
    expect(calculateIRR(datedReturnFlows)).toBe('0.100000');
  });

  it('sorts out-of-order cash flows before calculating XIRR', () => {
    const flows: PECashFlow[] = [
      { date: '2020-12-31', amount: '110', type: 'DISTRIBUTION' },
      { date: '2020-01-01', amount: '-100', type: 'CALL' },
    ];
    expect(calculateIRR(flows)).toBe('0.100000');
  });

  it('requires cash flows with both negative and positive signs', () => {
    expect(() => calculateIRR([
      { date: '2020-01-01', amount: '-100', type: 'CALL' },
      { date: '2020-12-31', amount: '-110', type: 'FEE' },
    ])).toThrow('at least one negative and one positive');
  });

  it('rejects a single cash flow', () => {
    expect(() => calculateIRR([{ date: '2020-01-01', amount: '-100', type: 'CALL' }])).toThrow('At least two dated cash flows');
  });

  it('rejects invalid calendar dates rather than silently normalizing them', () => {
    expect(() => calculateIRR([
      { date: '2020-02-30', amount: '-100', type: 'CALL' },
      { date: '2020-12-31', amount: '110', type: 'DISTRIBUTION' },
    ])).toThrow('Invalid calendar date');
  });

  it('calculates TVPI, DPI, RVPI and MOIC from paid-in capital', () => {
    const result = calculatePEMetrics('150', '110', '100', '20', '100');
    expect(result.tvpi).toBe('1.2000');
    expect(result.dpi).toBe('0.2000');
    expect(result.rvpi).toBe('1.0000');
    expect(result.moic).toBe('1.2000');
    expect(result.uncalledCapital).toBe('40.00');
  });

  it('calculates optional XIRR alongside fund multiples', () => {
    const result = calculatePEMetrics('150', '110', '100', '20', '100', datedReturnFlows);
    expect(result.irr).toBe('0.100000');
  });

  it('returns zero multiples when paid-in capital is zero and returns are zero', () => {
    const result = calculatePEMetrics('100', '0', '0', '0', '0');
    expect(result.tvpi).toBe('0.0000');
    expect(result.dpi).toBe('0.0000');
    expect(result.rvpi).toBe('0.0000');
  });

  it('rejects called capital greater than committed capital', () => {
    expect(() => calculatePEMetrics('100', '101', '100', '0', '0')).toThrow('calledCapital cannot exceed committedCapital');
  });

  it('rejects invested capital greater than called capital', () => {
    expect(() => calculatePEMetrics('100', '80', '81', '0', '0')).toThrow('investedCapital cannot exceed calledCapital');
  });

  it('generates chronologically sorted cumulative J-curve points', () => {
    const points = generateJCurveData([
      { date: '2022-01-01', amount: '40', type: 'DISTRIBUTION' },
      { date: '2020-01-01', amount: '-100', type: 'CALL' },
      { date: '2021-01-01', amount: '-20', type: 'CALL' },
    ]);
    expect(points.map((point) => point.date)).toEqual(['2020-01-01', '2021-01-01', '2022-01-01']);
    expect(points.map((point) => point.cumulativeCashFlow)).toEqual(['-100.00', '-120.00', '-80.00']);
    expect(points[0]?.irr).toBe('0.000000');
    expect(points[2]?.irr).not.toBe('0.000000');
  });
});

describe('Futures risk engine — P/L, margin status and liquidation estimate', () => {
  it('calculates long mark-to-market P/L with contracts, size and multiplier', () => {
    expect(calculateMarkToMarket({
      side: 'LONG', qty: 8, entryPrice: '870', markPrice: '886', contractSize: 200, multiplier: '1',
    })).toBe('25600.00');
  });

  it('calculates short mark-to-market P/L with the opposite sign', () => {
    expect(calculateMarkToMarket({
      side: 'SHORT', qty: 8, entryPrice: '870', markPrice: '886', contractSize: 200, multiplier: '1',
    })).toBe('-25600.00');
  });

  it('calculates account equity, total margins, available margin and status', () => {
    const result = calculateMarginHealth([futuresScenario], '1080000');
    expect(result.totalEquity).toBe('1105600.00');
    expect(result.totalInitialMargin).toBe('1200000.00');
    expect(result.totalMaintenanceMargin).toBe('960000.00');
    expect(result.availableMargin).toBe('-94400.00');
    expect(result.status).toBe('DANGER');
    expect(within(result.marginLevel, '115.1666667', '0.01')).toBe(true);
  });

  it('moves to margin-call status below one hundred percent', () => {
    const result = calculateMarginHealth([{ ...futuresScenario, qty: 1, markPrice: '870' }], '99999');
    expect(result.status).toBe('MARGIN_CALL');
  });

  it('keeps the danger band between one hundred and one hundred twenty percent', () => {
    const result = calculateMarginHealth([{ ...futuresScenario, qty: 1, markPrice: '870', initialMargin: '120', maintenanceMargin: '100' }], '110');
    expect(result.marginLevel).toBe('110.00');
    expect(result.status).toBe('DANGER');
  });

  it('keeps the warning band between one hundred twenty and two hundred percent', () => {
    const result = calculateMarginHealth([{ ...futuresScenario, qty: 1, markPrice: '870', initialMargin: '120', maintenanceMargin: '100' }], '150');
    expect(result.status).toBe('WARNING');
  });

  it('marks margin health at two hundred percent or above as healthy', () => {
    const result = calculateMarginHealth([{ ...futuresScenario, qty: 1, markPrice: '870', initialMargin: '120', maintenanceMargin: '100' }], '200');
    expect(result.status).toBe('HEALTHY');
  });

  it('handles an empty position set as a healthy account without a divide-by-zero', () => {
    const result = calculateMarginHealth([], '5000');
    expect(result.status).toBe('HEALTHY');
    expect(result.marginLevel).toBe('0.00');
    expect(result.availableMargin).toBe('5000.00');
  });

  it('estimates a long liquidation level from per-contract margin cushion', () => {
    expect(calculateLiquidationPrice('LONG', '870', '150000', '120000', '1', 8, 200)).toBe('720.0000');
  });

  it('estimates a short liquidation level above entry', () => {
    expect(calculateLiquidationPrice('SHORT', '870', '150000', '120000', '1', 8, 200)).toBe('1020.0000');
  });

  it('validates per-contract initial and maintenance margin ordering', () => {
    expect(() => calculateLiquidationPrice('LONG', '870', '100', '120', '1', 1, 1)).toThrow('initialMarginPerContract cannot be less than maintenanceMarginPerContract');
  });

  it('rejects zero contract quantity in P/L calculations', () => {
    expect(() => calculateMarkToMarket({ side: 'LONG', qty: 0, entryPrice: '100', markPrice: '101', contractSize: 1, multiplier: '1' })).toThrow('qty must be greater than zero');
  });
});

const optionChainCases = (['AAPL', 'SPY'] as const).flatMap((symbol) =>
  [0, 1, 2].flatMap((expiryIndex) =>
    [0, 1, 2, 3, 4].map((strikeIndex) => ({ symbol, expiryIndex, strikeIndex })),
  ),
);

describe('Advanced polish — Decimal options-chain model', () => {
  it.each(optionChainCases)(
    '$symbol expiry $expiryIndex strike row $strikeIndex has ordered, non-negative markets and finite Greeks',
    ({ symbol, expiryIndex, strikeIndex }) => {
      const chain = buildSampleOptionsChain(symbol, '2026-10-27');
      const expiry = chain.expiries[expiryIndex];
      const quote = expiry?.quotes[strikeIndex];
      expect(expiry).toBeDefined();
      expect(quote).toBeDefined();
      if (!expiry || !quote) throw new Error('Expected a sample chain expiry and quote.');

      expect(new TestDecimal(quote.callBid).gte(0)).toBe(true);
      expect(new TestDecimal(quote.putBid).gte(0)).toBe(true);
      expect(new TestDecimal(quote.callAsk).gte(quote.callBid)).toBe(true);
      expect(new TestDecimal(quote.putAsk).gte(quote.putBid)).toBe(true);
      expect(new TestDecimal(quote.callIV).gt(0) && new TestDecimal(quote.callIV).lte(5)).toBe(true);
      expect(new TestDecimal(quote.putIV).gt(0) && new TestDecimal(quote.putIV).lte(5)).toBe(true);
      expect(new TestDecimal(quote.callDelta).gte(0) && new TestDecimal(quote.callDelta).lte(1)).toBe(true);
      expect(new TestDecimal(quote.putDelta).gte(-1) && new TestDecimal(quote.putDelta).lte(0)).toBe(true);
      expect(['ITM', 'ATM', 'OTM']).toContain(quote.callMoneyness);
      expect(['ITM', 'ATM', 'OTM']).toContain(quote.putMoneyness);
    },
  );

  it('returns five AAPL strikes for each of the three requested expiries', () => {
    const chain = buildSampleOptionsChain('AAPL', '2026-10-27');
    expect(chain.symbol).toBe('AAPL');
    expect(chain.underlyingPrice).toBe('238.00');
    expect(chain.expiries.map((expiry) => expiry.expiryDate)).toEqual(['2026-12-18', '2027-01-15', '2027-03-19']);
    expect(chain.expiries.every((expiry) => expiry.quotes.length >= 5)).toBe(true);
    expect(chain.source).toBe('ILLUSTRATIVE_MODEL');
  });

  it('returns the SPY sample underlying and strike ladder', () => {
    const chain = buildSampleOptionsChain('SPY', '2026-10-27');
    expect(chain.underlyingPrice).toBe('610.00');
    expect(chain.expiries[0]?.quotes.map((quote) => quote.strike)).toEqual(['580.00', '600.00', '610.00', '620.00', '640.00']);
  });

  it('computes actual/365 time-to-expiry using decimal division', () => {
    const chain = buildSampleOptionsChain('AAPL', '2026-10-27');
    expect(chain.expiries.map((expiry) => expiry.daysToExpiry)).toEqual([52, 80, 143]);
    expect(chain.expiries[0]?.timeToExpiry).toBe('0.14246575');
  });

  it('filters expiries already passed without returning stale rows', () => {
    const chain = buildSampleOptionsChain('AAPL', '2026-12-20');
    expect(chain.expiries.map((expiry) => expiry.expiryDate)).toEqual(['2027-01-15', '2027-03-19']);
  });

  it('classifies call and put moneyness on opposite sides of the same strike', () => {
    const chain = buildSampleOptionsChain('AAPL', '2026-10-27');
    const callInTheMoney = chain.expiries[0]?.quotes.find((quote) => quote.strike === '220.00');
    const putInTheMoney = chain.expiries[0]?.quotes.find((quote) => quote.strike === '240.00');
    expect(callInTheMoney?.callMoneyness).toBe('ITM');
    expect(callInTheMoney?.putMoneyness).toBe('OTM');
    expect(putInTheMoney?.callMoneyness).toBe('ATM');
    expect(putInTheMoney?.putMoneyness).toBe('ATM');
  });

  it('prices call and put midpoints from the established Black–Scholes engine', () => {
    const chain = buildSampleOptionsChain('AAPL', '2026-10-27');
    const expiry = chain.expiries[0];
    const quote = expiry?.quotes.find((row) => row.strike === '240.00');
    expect(expiry).toBeDefined();
    expect(quote).toBeDefined();
    if (!expiry || !quote) throw new Error('Expected the near-ATM AAPL option quote.');
    const callModel = blackScholesPrice({
      underlyingPrice: chain.underlyingPrice,
      strikePrice: quote.strike,
      timeToExpiry: expiry.timeToExpiry,
      riskFreeRate: chain.riskFreeRate,
      volatility: quote.callIV,
      optionType: 'CALL',
    });
    const callMid = new TestDecimal(quote.callBid).plus(quote.callAsk).dividedBy(2);
    expect(callMid.minus(callModel.theoreticalPrice).abs().lte('0.01')).toBe(true);
  });

  it('rejects malformed as-of dates and dates after all sample expiries', () => {
    expect(() => buildSampleOptionsChain('AAPL', '2026-02-30')).toThrow('valid calendar date');
    expect(() => buildSampleOptionsChain('SPY', '2027-04-01')).toThrow('All sample expiries have passed');
  });
});

describe('Advanced polish — REIT peer comparison data and selection', () => {
  const peers = getSampleREITPeers();

  it('includes all five requested sample peers and keeps source figures as decimal strings', () => {
    expect(peers.map((peer) => peer.symbol)).toEqual(['WHART', 'CPNREIT', 'FTREIT', 'SIRI', 'LHHOTEL']);
    expect(peers.every((peer) => typeof peer.marketCapTHB === 'string')).toBe(true);
  });

  it.each([
    ['WHART', '0.061905', '0.905172'],
    ['CPNREIT', '0.069643', '0.903226'],
    ['FTREIT', '0.063441', '0.920792'],
    ['SIRI', '0.073563', '0.956044'],
    ['LHHOTEL', '0.085000', '0.925926'],
  ])('%s ratios are calculated at 40-digit Decimal precision', (symbol, distributionYield, priceToNAV) => {
    const peer = peers.find((candidate) => candidate.symbol === symbol);
    expect(peer?.distributionYield).toBe(distributionYield);
    expect(peer?.priceToNAV).toBe(priceToNAV);
  });

  it('sorts yield descending without mutating its source list', () => {
    const originalOrder = peers.map((peer) => peer.symbol);
    const sorted = sortREITPeers(peers, 'distributionYield', 'DESC');
    expect(sorted.map((peer) => peer.symbol)).toEqual(['LHHOTEL', 'SIRI', 'CPNREIT', 'FTREIT', 'WHART']);
    expect(peers.map((peer) => peer.symbol)).toEqual(originalOrder);
  });

  it('sorts yield ascending with exact decimal comparisons', () => {
    expect(sortREITPeers(peers, 'distributionYield', 'ASC').map((peer) => peer.symbol)).toEqual([
      'WHART', 'FTREIT', 'CPNREIT', 'SIRI', 'LHHOTEL',
    ]);
  });

  it('sorts Price/NAV and occupancy using decimal ratios', () => {
    expect(sortREITPeers(peers, 'priceToNAV', 'DESC')[0]?.symbol).toBe('SIRI');
    expect(sortREITPeers(peers, 'occupancyRate', 'DESC')[0]?.symbol).toBe('FTREIT');
  });

  it('sorts market capitalization by decimal strings', () => {
    expect(sortREITPeers(peers, 'marketCapTHB', 'ASC').map((peer) => peer.symbol)).toEqual([
      'SIRI', 'LHHOTEL', 'WHART', 'CPNREIT', 'FTREIT',
    ]);
  });

  it('adds a peer once and removes an already-selected peer', () => {
    expect(toggleREITPeerSelection(['WHART'], 'CPNREIT')).toEqual(['WHART', 'CPNREIT']);
    expect(toggleREITPeerSelection(['WHART', 'CPNREIT'], 'WHART')).toEqual(['CPNREIT']);
  });

  it('deduplicates a pre-existing selection before applying the five-peer cap', () => {
    expect(toggleREITPeerSelection(['WHART', 'WHART'], 'CPNREIT')).toEqual(['WHART', 'CPNREIT']);
  });

  it('supports a custom comparison cap and rejects additions beyond that cap', () => {
    expect(toggleREITPeerSelection(['WHART'], 'CPNREIT', 2)).toEqual(['WHART', 'CPNREIT']);
    expect(() => toggleREITPeerSelection(['WHART', 'CPNREIT'], 'FTREIT', 2)).toThrow('no more than 2 REITs');
  });

  it('enforces the required five-peer maximum', () => {
    expect(() => toggleREITPeerSelection(['WHART', 'CPNREIT', 'FTREIT', 'SIRI', 'LHHOTEL'], 'WHART')).not.toThrow();
    expect(() => toggleREITPeerSelection(['WHART', 'CPNREIT', 'FTREIT', 'SIRI', 'LHHOTEL'], 'FTREIT')).not.toThrow();
    expect(() => toggleREITPeerSelection(['WHART', 'CPNREIT', 'FTREIT', 'SIRI', 'LHHOTEL'], 'WHART')).not.toThrow();
    expect(() => toggleREITPeerSelection(['WHART', 'CPNREIT', 'FTREIT', 'SIRI', 'LHHOTEL'], 'LHHOTEL')).not.toThrow();
    expect(() => toggleREITPeerSelection(['WHART', 'CPNREIT', 'FTREIT', 'SIRI', 'LHHOTEL'], 'CPNREIT')).not.toThrow();
  });

  it('rejects unknown peers and invalid maximum values', () => {
    expect(() => toggleREITPeerSelection([], 'UNKNOWN')).toThrow('Unknown REIT peer');
    expect(() => toggleREITPeerSelection([], 'WHART', 0)).toThrow('maximum must be a positive integer');
  });
});

describe('Advanced polish — private-equity screener filters and details', () => {
  const funds = getSamplePEFunds();

  it('includes five illustrative sample funds with complete performance fields', () => {
    expect(funds.map((fund) => fund.name)).toEqual([
      'Northstar Growth III', 'Siam Ventures Select', 'GGV Capital Growth Fund', 'East Ventures', 'Openspace Ventures IV',
    ]);
    expect(funds.every((fund) => fund.tvpi !== '' && fund.dpi !== '' && fund.irr !== '')).toBe(true);
  });

  it('calculates the Northstar sample multiples and dated-flow IRR with Decimal', () => {
    const fund = funds.find((candidate) => candidate.id === 'northstar-growth-iii');
    expect(fund).toMatchObject({ tvpi: '1.5526', dpi: '0.3947', rvpi: '1.1579', moic: '1.5526', irr: '0.120834' });
  });

  it.each([
    ['VENTURE', ['Siam Ventures Select', 'East Ventures']],
    ['GROWTH', ['Northstar Growth III', 'Openspace Ventures IV']],
    ['BUYOUT', ['GGV Capital Growth Fund']],
  ] as const)('filters by %s stage', (stage, expectedNames) => {
    const filtered = filterSamplePEFunds({ stage });
    expect(filtered.map((fund) => fund.name).sort()).toEqual([...expectedNames].sort());
  });

  it('filters vintage years inclusively within the 2020–2026 screen', () => {
    const filtered = filterSamplePEFunds({ vintageFrom: 2022, vintageTo: 2023 });
    expect(filtered.map((fund) => fund.vintage).every((year) => year >= 2022 && year <= 2023)).toBe(true);
    expect(filtered).toHaveLength(3);
  });

  it('applies minimum and maximum IRR bounds as fractional decimal rates', () => {
    const highIRR = filterSamplePEFunds({ minIRR: '0.10' });
    expect(highIRR.map((fund) => fund.name).sort()).toEqual(['GGV Capital Growth Fund', 'Northstar Growth III']);
    const cappedIRR = filterSamplePEFunds({ maxIRR: '0.08' });
    expect(cappedIRR.map((fund) => fund.name).sort()).toEqual(['East Ventures', 'Openspace Ventures IV', 'Siam Ventures Select']);
  });

  it('applies inclusive TVPI bounds without binary-float comparisons', () => {
    const filtered = filterSamplePEFunds({ minTVPI: '1.25', maxTVPI: '1.32' });
    expect(filtered.map((fund) => fund.name).sort()).toEqual(['Openspace Ventures IV', 'Siam Ventures Select']);
  });

  it('combines stage, vintage, IRR and TVPI filters', () => {
    const filtered = filterSamplePEFunds({ stage: 'GROWTH', vintageFrom: 2021, vintageTo: 2022, minIRR: '0.07', maxIRR: '0.13', minTVPI: '1.3', maxTVPI: '1.6' });
    expect(filtered.map((fund) => fund.name)).toEqual(['Northstar Growth III', 'Openspace Ventures IV']);
  });

  it('sorts by IRR descending and ascending with deterministic name tie-breaks', () => {
    expect(filterSamplePEFunds({ sortBy: 'IRR', sortDirection: 'DESC' }).map((fund) => fund.name)).toEqual([
      'GGV Capital Growth Fund', 'Northstar Growth III', 'Siam Ventures Select', 'Openspace Ventures IV', 'East Ventures',
    ]);
    expect(filterSamplePEFunds({ sortBy: 'IRR', sortDirection: 'ASC' }).map((fund) => fund.name)).toEqual([
      'East Ventures', 'Openspace Ventures IV', 'Siam Ventures Select', 'Northstar Growth III', 'GGV Capital Growth Fund',
    ]);
  });

  it('sorts by TVPI in either direction', () => {
    expect(filterSamplePEFunds({ sortBy: 'TVPI', sortDirection: 'DESC' }).map((fund) => fund.name)).toEqual([
      'GGV Capital Growth Fund', 'Northstar Growth III', 'Openspace Ventures IV', 'Siam Ventures Select', 'East Ventures',
    ]);
    expect(filterSamplePEFunds({ sortBy: 'TVPI', sortDirection: 'ASC' }).map((fund) => fund.name)).toEqual([
      'East Ventures', 'Siam Ventures Select', 'Openspace Ventures IV', 'Northstar Growth III', 'GGV Capital Growth Fund',
    ]);
  });

  it('returns an empty result when bounds exclude every fund', () => {
    expect(filterSamplePEFunds({ minTVPI: '4', maxTVPI: '5' })).toHaveLength(0);
  });

  it('rejects reversed IRR, TVPI and vintage ranges', () => {
    expect(() => filterSamplePEFunds({ minIRR: '0.30', maxIRR: '0.10' })).toThrow('minIRR cannot be greater than maxIRR');
    expect(() => filterSamplePEFunds({ minTVPI: '2.0', maxTVPI: '1.0' })).toThrow('minTVPI cannot be greater than maxTVPI');
    expect(() => filterSamplePEFunds({ vintageFrom: 2025, vintageTo: 2020 })).toThrow('vintageFrom cannot be greater');
  });

  it('rejects malformed or non-integer screen bounds', () => {
    expect(() => filterSamplePEFunds({ minIRR: 'ten' })).toThrow('minIRR must be a finite decimal string');
    expect(() => filterSamplePEFunds({ minTVPI: '-1' })).toThrow('TVPI bounds cannot be negative');
    expect(() => filterSamplePEFunds({ vintageFrom: 2020.5 })).toThrow('vintageFrom must be an integer');
  });

  it('returns a private copy of sample cash-flow arrays', () => {
    const first = getSamplePEFunds();
    const second = getSamplePEFunds();
    expect(first[0]?.cashFlows).not.toBe(second[0]?.cashFlows);
    expect(first[0]?.cashFlows[0]).not.toBe(second[0]?.cashFlows[0]);
  });

  it('provides a J-curve and dated cash-flow timeline for fund details', () => {
    const detail = getSamplePEFundDetail('northstar-growth-iii');
    expect(detail.jCurve).toHaveLength(detail.cashFlows.length);
    expect(detail.jCurve[0]?.cumulativeCashFlow).toBe('-1200000000.00');
    expect(detail.cashFlows[0]?.date).toBe('2021-06-30');
    expect(detail.jCurve[detail.jCurve.length - 1]?.cumulativeCashFlow).toBe('2100000000.00');
  });

  it('rejects unknown sample fund detail requests', () => {
    expect(() => getSamplePEFundDetail('missing-fund')).toThrow('Unknown sample PE fund');
  });
});
