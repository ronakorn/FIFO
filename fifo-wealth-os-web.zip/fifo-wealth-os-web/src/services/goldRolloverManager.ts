import { randomUUID } from 'crypto';
import { getPrismaClient } from '../db/prisma';
import {
  GoldAssetSubclass,
  GoldPurity,
  GoldTransaction,
  GoldWeightUnit,
} from '../types/gold';
import { logAction } from './auditLogger';
import { defaultBotFxProvider, FXRateProvider } from './botFxProvider';
import { FUTURES_CONTRACT_CATALOG } from './contractRolloverEngine';
import {
  calculateGoldFIFO,
  calculateGoldTransactionTotalCost,
  GoldDecimal,
  isUsdQuotedSubclass,
  toCleanGoldDecimal,
} from './goldEngine';

export interface ExecuteGoldRolloverOptions {
  /** Closing price per unit of the expiring contract; defaults to current catalog market quote or entry spot price */
  closePrice?: string;
  /** Execution date (ISO YYYY-MM-DD); defaults to 2026-10-26 */
  executionDate?: string;
  /** Explicit FX rate; if omitted, automatically fetched via BOT Historical FX Provider */
  fxRateAtRollover?: string;
  /** Optional new contract expiration date (ISO YYYY-MM-DD) */
  newExpirationDate?: string;
  /** Optional authenticated userId + IP to emit PDPA/GDPR AuditLog records automatically */
  auditContext?: {
    userId: string;
    ipAddress?: string | null;
  };
  /** Injectable FXRateProvider (defaults to `defaultBotFxProvider`) */
  fxProvider?: FXRateProvider;
}

export interface GoldRolloverExecutionResult {
  rolloverGroupId: string;
  oldTransactionId: string;
  closeTransaction: GoldTransaction;
  openTransaction: GoldTransaction;
  rolloverFee: string;
  rolloverFeeTHB: string;
  rolloverSpreadPerUnit: string;
  newInitialCostBasisNative: string;
  newInitialCostBasisTHB: string;
  realizedGLClosedPositionTHB: string;
  fxRateApplied: string;
}

function lookupCatalogSpec(symbol: string) {
  const clean = symbol.trim().toUpperCase();
  return FUTURES_CONTRACT_CATALOG.find((c) => c.symbol === clean);
}

function inferContractMonthCode(symbol: string): string {
  const clean = symbol.trim().toUpperCase();
  const catalogMatch = lookupCatalogSpec(clean);
  if (catalogMatch) return catalogMatch.contractMonth;
  return clean.length >= 3 ? clean.slice(-3) : clean;
}

function inferExpirationDate(symbol: string, fallbackDate: string): string {
  const catalogMatch = lookupCatalogSpec(symbol);
  if (catalogMatch) return catalogMatch.expirationDate;
  const dt = new Date(`${fallbackDate}T00:00:00.000Z`);
  dt.setUTCDate(dt.getUTCDate() + 60);
  return dt.toISOString().slice(0, 10);
}

/**
 * Institutional Gold Futures Rollover Manager (`Decimal.js` precision: 40).
 *
 * Atomically executes a position rollover from an existing Gold Futures transaction:
 * 1. Creates a `'SELL'` transaction closing `newQty` of the expiring contract.
 * 2. Creates a `'BUY'` transaction opening `newQty` of `newContractSymbol` at `newPrice`.
 * 3. Links both legs with a shared `rolloverGroupId` (UUID) inside `DerivativesContractExtension`.
 * 4. Records `rolloverFee` transparently in both `DerivativesContractExtension.rolloverFee`
 *    and the new contract's initial FIFO Cost Basis (`newPrice × newQty + rolloverFee`).
 */
export async function executeRollover(
  oldTransactionId: string,
  newContractSymbol: string,
  newQty: string,
  newPrice: string,
  rolloverFee: string,
  options: ExecuteGoldRolloverOptions = {}
): Promise<GoldRolloverExecutionResult> {
  if (!oldTransactionId.trim()) {
    throw new Error('oldTransactionId is required for rollover.');
  }
  const cleanNewSymbol = newContractSymbol.trim().toUpperCase();
  if (cleanNewSymbol.length < 2) {
    throw new Error('newContractSymbol must be at least 2 characters.');
  }

  const qtyDec = toCleanGoldDecimal(newQty);
  const openPriceDec = toCleanGoldDecimal(newPrice);
  const feeDec = toCleanGoldDecimal(rolloverFee);

  if (qtyDec.lte(0)) {
    throw new Error('Rollover quantity (newQty) must be strictly positive.');
  }
  if (openPriceDec.lte(0)) {
    throw new Error('New contract price (newPrice) must be strictly positive.');
  }
  if (feeDec.isNegative()) {
    throw new Error('Rollover fee (rolloverFee) cannot be negative.');
  }

  const prisma = getPrismaClient();
  const executionDate = (options.executionDate ?? '2026-10-26').slice(0, 10);
  const fxProvider = options.fxProvider ?? defaultBotFxProvider;

  const oldRecord = await prisma.goldTransactionRecord.findUnique({
    where: { id: oldTransactionId.trim() },
    include: { derivativesExt: true },
  });

  if (!oldRecord) {
    throw new Error(`Original gold transaction "${oldTransactionId}" not found.`);
  }
  if (oldRecord.type !== 'BUY') {
    throw new Error(
      `Cannot roll over a "${oldRecord.type}" transaction. Select an opening BUY transaction.`
    );
  }
  if (cleanNewSymbol === oldRecord.symbol.toUpperCase()) {
    throw new Error(
      'newContractSymbol must be a new contract series distinct from the expiring symbol.'
    );
  }

  const assetSubclass = oldRecord.assetSubclass as GoldAssetSubclass;
  const weightUnit = oldRecord.weightUnit as GoldWeightUnit;
  const purity = oldRecord.purity as GoldPurity;

  const fxRateStr = options.fxRateAtRollover
    ? toCleanGoldDecimal(options.fxRateAtRollover).toFixed(4)
    : isUsdQuotedSubclass(assetSubclass)
      ? toCleanGoldDecimal(
          await fxProvider.getHistoricalRate('USD', executionDate)
        ).toFixed(4)
      : '1.0000';
  const fxDec = toCleanGoldDecimal(fxRateStr);

  const catalogOld = lookupCatalogSpec(oldRecord.symbol);
  const closePriceDec = options.closePrice
    ? toCleanGoldDecimal(options.closePrice)
    : catalogOld
      ? toCleanGoldDecimal(catalogOld.currentMarketPriceUSD)
      : toCleanGoldDecimal(oldRecord.spotPricePerUnit);

  if (closePriceDec.lte(0)) {
    throw new Error('Closing price for old contract must be strictly positive.');
  }

  const rolloverGroupId = randomUUID();
  const spreadDec = openPriceDec.minus(closePriceDec);

  const closeTotalProceeds = calculateGoldTransactionTotalCost({
    weight: qtyDec.toFixed(4),
    spotPricePerUnit: closePriceDec.toFixed(2),
    premiumPerUnit: '0.00',
    commission: '0.00',
    type: 'SELL',
  });

  // Transparently capitalize rolloverFee into new contract cost basis while recording it separately
  const openTotalCost = calculateGoldTransactionTotalCost({
    weight: qtyDec.toFixed(4),
    spotPricePerUnit: openPriceDec.toFixed(2),
    premiumPerUnit: '0.00',
    commission: feeDec.toFixed(2),
    type: 'BUY',
  });

  const { closeDbRow, openDbRow, realizedDeltaTHB } = await prisma.$transaction(
    async (tx) => {
      const portfolioRows = await tx.goldTransactionRecord.findMany({
        where: { portfolioId: oldRecord.portfolioId },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      });

      const mappedExisting: GoldTransaction[] = portfolioRows.map((r) => ({
        id: r.id,
        portfolioId: r.portfolioId,
        date: r.date,
        symbol: r.symbol,
        assetSubclass: r.assetSubclass as GoldAssetSubclass,
        weight: r.weight,
        weightUnit: r.weightUnit as GoldWeightUnit,
        purity: r.purity as GoldPurity,
        spotPricePerUnit: r.spotPricePerUnit,
        premiumPerUnit: r.premiumPerUnit,
        commission: r.commission,
        totalCost: r.totalCost,
        fxRateAtPurchase: r.fxRateAtPurchase,
        type: r.type as 'BUY' | 'SELL',
        createdAt: r.createdAt,
      }));

      const preFifo = calculateGoldFIFO(mappedExisting, {
        xauUsdSpot: closePriceDec.toFixed(2),
        usdThbRate: fxDec.gt(1) ? fxDec.toFixed(4) : '35.6000',
        gtaGold965SellTHB: '46450.00',
      });

      const matchingOpenWeight = preFifo.lots
        .filter(
          (l) =>
            l.symbol.toUpperCase() === oldRecord.symbol.toUpperCase() &&
            l.assetSubclass === assetSubclass &&
            l.weightUnit === weightUnit &&
            l.purity === purity
        )
        .reduce(
          (acc, l) => acc.plus(toCleanGoldDecimal(l.weightRemain)),
          new GoldDecimal(0)
        );

      if (qtyDec.gt(matchingOpenWeight)) {
        throw new Error(
          `Insufficient open position on ${oldRecord.symbol}: requested rollover qty ${qtyDec.toFixed(4)} exceeds open qty ${matchingOpenWeight.toFixed(4)}.`
        );
      }

      // 1. SELL Transaction to Close Old Contract Position
      const createdClose = await tx.goldTransactionRecord.create({
        data: {
          portfolioId: oldRecord.portfolioId,
          date: executionDate,
          symbol: oldRecord.symbol.toUpperCase(),
          assetSubclass,
          weight: qtyDec.toFixed(4),
          weightUnit,
          purity,
          spotPricePerUnit: closePriceDec.toFixed(2),
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: closeTotalProceeds,
          fxRateAtPurchase: fxRateStr,
          type: 'SELL',
          derivativesExt: {
            create: {
              contractMonth:
                oldRecord.derivativesExt?.contractMonth ??
                inferContractMonthCode(oldRecord.symbol),
              expirationDate:
                oldRecord.derivativesExt?.expirationDate ?? executionDate,
              legAction: 'CLOSE_LONG',
              isRollover: true,
              rolloverGroupId,
              rolloverSpread: spreadDec.toFixed(2),
              rolloverFee: feeDec.toFixed(2),
            },
          },
        },
        include: { derivativesExt: true },
      });

      // 2. BUY Transaction to Open New Back-Month Contract Position
      const createdOpen = await tx.goldTransactionRecord.create({
        data: {
          portfolioId: oldRecord.portfolioId,
          date: executionDate,
          symbol: cleanNewSymbol,
          assetSubclass,
          weight: qtyDec.toFixed(4),
          weightUnit,
          purity,
          spotPricePerUnit: openPriceDec.toFixed(2),
          premiumPerUnit: '0.00',
          commission: feeDec.toFixed(2),
          totalCost: openTotalCost,
          fxRateAtPurchase: fxRateStr,
          type: 'BUY',
          derivativesExt: {
            create: {
              contractMonth: inferContractMonthCode(cleanNewSymbol),
              expirationDate:
                options.newExpirationDate ??
                inferExpirationDate(cleanNewSymbol, executionDate),
              legAction: 'OPEN_LONG',
              isRollover: true,
              rolloverGroupId,
              rolloverSpread: spreadDec.toFixed(2),
              rolloverFee: feeDec.toFixed(2),
            },
          },
        },
        include: { derivativesExt: true },
      });

      const postCloseFifo = calculateGoldFIFO(
        [
          ...mappedExisting,
          {
            id: createdClose.id,
            portfolioId: createdClose.portfolioId,
            date: createdClose.date,
            symbol: createdClose.symbol,
            assetSubclass,
            weight: createdClose.weight,
            weightUnit,
            purity,
            spotPricePerUnit: createdClose.spotPricePerUnit,
            premiumPerUnit: createdClose.premiumPerUnit,
            commission: createdClose.commission,
            totalCost: createdClose.totalCost,
            fxRateAtPurchase: createdClose.fxRateAtPurchase,
            type: 'SELL',
            createdAt: createdClose.createdAt,
          },
        ],
        {
          xauUsdSpot: openPriceDec.toFixed(2),
          usdThbRate: fxDec.gt(1) ? fxDec.toFixed(4) : '35.6000',
          gtaGold965SellTHB: '46450.00',
        }
      );

      const deltaTHB = toCleanGoldDecimal(postCloseFifo.totalRealizedGLTHB).minus(
        toCleanGoldDecimal(preFifo.totalRealizedGLTHB)
      );

      return {
        closeDbRow: createdClose,
        openDbRow: createdOpen,
        realizedDeltaTHB: deltaTHB,
      };
    }
  );

  const closeTxDto: GoldTransaction = {
    id: closeDbRow.id,
    portfolioId: closeDbRow.portfolioId,
    date: closeDbRow.date,
    symbol: closeDbRow.symbol,
    assetSubclass,
    weight: closeDbRow.weight,
    weightUnit,
    purity,
    spotPricePerUnit: closeDbRow.spotPricePerUnit,
    premiumPerUnit: closeDbRow.premiumPerUnit,
    commission: closeDbRow.commission,
    totalCost: closeDbRow.totalCost,
    fxRateAtPurchase: closeDbRow.fxRateAtPurchase,
    type: 'SELL',
    createdAt: closeDbRow.createdAt,
  };

  const openTxDto: GoldTransaction = {
    id: openDbRow.id,
    portfolioId: openDbRow.portfolioId,
    date: openDbRow.date,
    symbol: openDbRow.symbol,
    assetSubclass,
    weight: openDbRow.weight,
    weightUnit,
    purity,
    spotPricePerUnit: openDbRow.spotPricePerUnit,
    premiumPerUnit: openDbRow.premiumPerUnit,
    commission: openDbRow.commission,
    totalCost: openDbRow.totalCost,
    fxRateAtPurchase: openDbRow.fxRateAtPurchase,
    type: 'BUY',
    createdAt: openDbRow.createdAt,
  };

  if (options.auditContext?.userId) {
    await logAction(
      options.auditContext.userId,
      'CREATE',
      'GOLD_TRANSACTION',
      closeTxDto.id,
      null,
      {
        ...closeTxDto,
        isRollover: true,
        legAction: 'CLOSE_LONG',
        rolloverGroupId,
        rolloverFee: feeDec.toFixed(2),
      },
      options.auditContext.ipAddress
    );

    await logAction(
      options.auditContext.userId,
      'CREATE',
      'GOLD_TRANSACTION',
      openTxDto.id,
      null,
      {
        ...openTxDto,
        isRollover: true,
        legAction: 'OPEN_LONG',
        rolloverGroupId,
        rolloverFee: feeDec.toFixed(2),
      },
      options.auditContext.ipAddress
    );
  }

  const fxMultiplier = isUsdQuotedSubclass(assetSubclass)
    ? fxDec
    : new GoldDecimal(1);
  const feeTHB = feeDec.times(fxMultiplier);
  const newBasisNative = toCleanGoldDecimal(openTotalCost);
  const newBasisTHB = newBasisNative.times(fxMultiplier);

  return {
    rolloverGroupId,
    oldTransactionId: oldRecord.id,
    closeTransaction: closeTxDto,
    openTransaction: openTxDto,
    rolloverFee: feeDec.toFixed(2),
    rolloverFeeTHB: feeTHB.toFixed(2),
    rolloverSpreadPerUnit: spreadDec.toFixed(2),
    newInitialCostBasisNative: newBasisNative.toFixed(2),
    newInitialCostBasisTHB: newBasisTHB.toFixed(2),
    realizedGLClosedPositionTHB: realizedDeltaTHB.toFixed(2),
    fxRateApplied: fxRateStr,
  };
}
