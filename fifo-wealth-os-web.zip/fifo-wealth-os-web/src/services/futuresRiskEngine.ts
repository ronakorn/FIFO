import Decimal from 'decimal.js';

export const FutDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface FuturesPosition {
  id: string;
  symbol: string;
  side: 'LONG' | 'SHORT';
  /** Number of contracts. */
  qty: number | string;
  entryPrice: string;
  markPrice: string;
  /** Underlying units per contract. */
  contractSize: number | string;
  /** Currency multiplier applied to each underlying price point. */
  multiplier: string;
  /** Per-contract initial margin in the account currency. */
  initialMargin: string;
  /** Per-contract maintenance margin in the account currency. */
  maintenanceMargin: string;
}

export interface MarginHealthResult {
  totalEquity: string;
  totalInitialMargin: string;
  totalMaintenanceMargin: string;
  availableMargin: string;
  marginLevel: string;
  status: 'HEALTHY' | 'WARNING' | 'DANGER' | 'MARGIN_CALL';
}

export interface MarkToMarketInput {
  side: 'LONG' | 'SHORT';
  qty: number | string;
  entryPrice: string;
  markPrice: string;
  contractSize: number | string;
  multiplier: string;
}

function parseDecimal(value: string, label: string): Decimal {
  try {
    const result = new FutDecimal(value);
    if (!result.isFinite()) throw new Error();
    return result;
  } catch {
    throw new Error(`${label} must be a finite decimal string.`);
  }
}

function positive(value: string | number, label: string): Decimal {
  const result = parseDecimal(String(value), label);
  if (!result.gt(0)) throw new Error(`${label} must be greater than zero.`);
  return result;
}

function nonNegative(value: string, label: string): Decimal {
  const result = parseDecimal(value, label);
  if (result.isNegative()) throw new Error(`${label} cannot be negative.`);
  return result;
}

function fixed(value: Decimal, places = 2): string {
  return value.toDecimalPlaces(places, FutDecimal.ROUND_HALF_UP).toFixed(places);
}

function validateSide(side: string): asserts side is 'LONG' | 'SHORT' {
  if (side !== 'LONG' && side !== 'SHORT') throw new Error('side must be LONG or SHORT.');
}

function validatePosition(position: FuturesPosition): {
  qty: Decimal;
  contractSize: Decimal;
  multiplier: Decimal;
  initialMargin: Decimal;
  maintenanceMargin: Decimal;
} {
  validateSide(position.side);
  const qty = positive(position.qty, 'qty');
  const contractSize = positive(position.contractSize, 'contractSize');
  const multiplier = positive(position.multiplier, 'multiplier');
  const initialMargin = nonNegative(position.initialMargin, 'initialMargin');
  const maintenanceMargin = nonNegative(position.maintenanceMargin, 'maintenanceMargin');
  if (initialMargin.lt(maintenanceMargin)) throw new Error('initialMargin cannot be less than maintenanceMargin.');
  parseDecimal(position.entryPrice, 'entryPrice');
  parseDecimal(position.markPrice, 'markPrice');
  return { qty, contractSize, multiplier, initialMargin, maintenanceMargin };
}

/** Account-level margin calculation. Margin amounts are per contract and are multiplied by position quantity. */
export function calculateMarginHealth(
  positions: readonly FuturesPosition[],
  accountBalance: string,
): MarginHealthResult {
  const balance = parseDecimal(accountBalance, 'accountBalance');
  let totalInitialMargin = new FutDecimal(0);
  let totalMaintenanceMargin = new FutDecimal(0);
  let totalUnrealizedPnL = new FutDecimal(0);

  for (const position of positions) {
    const validated = validatePosition(position);
    totalInitialMargin = totalInitialMargin.plus(validated.initialMargin.times(validated.qty));
    totalMaintenanceMargin = totalMaintenanceMargin.plus(validated.maintenanceMargin.times(validated.qty));
    const priceDifference = new FutDecimal(position.markPrice).minus(position.entryPrice);
    const direction = position.side === 'LONG' ? new FutDecimal(1) : new FutDecimal(-1);
    totalUnrealizedPnL = totalUnrealizedPnL.plus(
      direction.times(validated.qty).times(validated.contractSize).times(validated.multiplier).times(priceDifference),
    );
  }

  const totalEquity = balance.plus(totalUnrealizedPnL);
  const marginLevel = totalMaintenanceMargin.isZero()
    ? new FutDecimal(0)
    : totalEquity.dividedBy(totalMaintenanceMargin).times(100);
  const status = totalMaintenanceMargin.isZero() || marginLevel.gte(200)
    ? 'HEALTHY'
    : marginLevel.lt(100)
      ? 'MARGIN_CALL'
      : marginLevel.lt(120)
        ? 'DANGER'
        : marginLevel.lt(200)
          ? 'WARNING'
          : 'HEALTHY';

  return {
    totalEquity: fixed(totalEquity),
    totalInitialMargin: fixed(totalInitialMargin),
    totalMaintenanceMargin: fixed(totalMaintenanceMargin),
    availableMargin: fixed(totalEquity.minus(totalInitialMargin)),
    marginLevel: fixed(marginLevel, 2),
    status,
  };
}

/** Unrealized P/L = side × contracts × units per contract × multiplier × (mark - entry). */
export function calculateMarkToMarket(input: MarkToMarketInput): string {
  validateSide(input.side);
  const qty = positive(input.qty, 'qty');
  const contractSize = positive(input.contractSize, 'contractSize');
  const multiplier = positive(input.multiplier, 'multiplier');
  const entryPrice = parseDecimal(input.entryPrice, 'entryPrice');
  const markPrice = parseDecimal(input.markPrice, 'markPrice');
  const direction = input.side === 'LONG' ? new FutDecimal(1) : new FutDecimal(-1);
  return fixed(direction.times(qty).times(contractSize).times(multiplier).times(markPrice.minus(entryPrice)));
}

/**
 * Estimate the maintenance-margin liquidation level, assuming margin per contract and a linear contract.
 * Quantity cancels because both the margin cushion and price P/L scale with the contract count.
 */
export function calculateLiquidationPrice(
  side: 'LONG' | 'SHORT',
  entryPrice: string,
  initialMarginPerContract: string,
  maintenanceMarginPerContract: string,
  multiplier: string,
  qty: number | string,
  contractSize: number | string = 1,
): string {
  validateSide(side);
  const entry = parseDecimal(entryPrice, 'entryPrice');
  const initial = nonNegative(initialMarginPerContract, 'initialMarginPerContract');
  const maintenance = nonNegative(maintenanceMarginPerContract, 'maintenanceMarginPerContract');
  const multiplierDecimal = positive(multiplier, 'multiplier');
  positive(qty, 'qty');
  const contractSizeDecimal = positive(contractSize, 'contractSize');
  if (initial.lt(maintenance)) throw new Error('initialMarginPerContract cannot be less than maintenanceMarginPerContract.');
  const distance = initial.minus(maintenance).dividedBy(multiplierDecimal.times(contractSizeDecimal));
  const liquidationPrice = side === 'LONG' ? entry.minus(distance) : entry.plus(distance);
  return fixed(liquidationPrice, 4);
}
