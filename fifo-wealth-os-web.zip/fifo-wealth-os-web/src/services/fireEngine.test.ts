import Decimal from 'decimal.js';
import request from 'supertest';
import { createApp } from '../api/app';
import { getPrismaClient } from '../db/prisma';
import {
  calculateFIRENumber,
  calculateGoalProgress,
  calculateYearsToFIRE,
  runMonteCarloSimulation,
} from './fireEngine';
import { FIREGoal } from '../types/fire';

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

describe('FIFO Wealth OS - Goals & FIRE Planner Engine (Decimal.js + Seedrandom)', () => {
  describe('1. calculateFIRENumber (Annual Expenses / Withdrawal Rate)', () => {
    it('calculates 12,000,000.00 THB for 40,000 THB/month (480,000/yr) at 4% withdrawal rate', () => {
      const annualExpenses = new Dec('40000').times(12).toFixed(2); // "480000.00"
      const result = calculateFIRENumber(annualExpenses, '0.04');
      expect(result).toBe('12000000.00');
    });

    it('calculates exact Decimal precision for 3.5% conservative withdrawal rate without float drift', () => {
      // 420,000 / 0.035 = 12,000,000.00 exact
      expect(calculateFIRENumber('420000', '0.035')).toBe('12000000.00');
    });

    it('throws descriptive errors for invalid expenses or withdrawal rates', () => {
      expect(() => calculateFIRENumber('-100', '0.04')).toThrow();
      expect(() => calculateFIRENumber('480000', '0')).toThrow();
      expect(() => calculateFIRENumber('480000', '1.5')).toThrow();
    });
  });

  describe('2. calculateYearsToFIRE (Inflation-Adjusted Future Value of Annuity)', () => {
    it('calculates ~22 years for 1M initial, 20k/month, 8% return, 3% inflation, 12M target', () => {
      const yearsStr = calculateYearsToFIRE(
        '1000000',
        '20000',
        '12000000',
        '0.08',
        '0.03'
      );
      const yearsNum = Number(yearsStr);
      // Fisher real rate ~4.854% -> 21.85 years (~22 years)
      expect(yearsNum).toBeGreaterThanOrEqual(21);
      expect(yearsNum).toBeLessThanOrEqual(22.5);
    });

    it('returns "0.00" immediately when currentAmount already meets or exceeds targetAmount', () => {
      expect(
        calculateYearsToFIRE('12500000', '20000', '12000000', '0.08', '0.03')
      ).toBe('0.00');
    });

    it('handles zero real return (expectedReturn === inflationRate) accurately', () => {
      // Need 1,200,000 more at 20,000/month -> 60 months = 5.00 years
      expect(
        calculateYearsToFIRE('1000000', '20000', '2200000', '0.03', '0.03')
      ).toBe('5.00');
    });
  });

  describe('3. runMonteCarloSimulation (Deterministic GBM with Seedrandom)', () => {
    it('produces 100% deterministic results for a fixed seed and valid successRate in [0, 100]', () => {
      const runA = runMonteCarloSimulation(
        '1000000',
        '25000',
        '0.085',
        '0.16',
        25,
        200,
        'wealthos-seed-42',
        { targetAmount: '12000000', startYear: 2026 }
      );
      const runB = runMonteCarloSimulation(
        '1000000',
        '25000',
        '0.085',
        '0.16',
        25,
        200,
        'wealthos-seed-42',
        { targetAmount: '12000000', startYear: 2026 }
      );

      expect(runA.successRate).toBe(runB.successRate);
      expect(runA.medianYear).toBe(runB.medianYear);
      expect(runA.p10Year).toBe(runB.p10Year);
      expect(runA.p90Year).toBe(runB.p90Year);
      expect(runA.simulations[0]).toEqual(runB.simulations[0]);

      expect(runA.successRate).toBeGreaterThanOrEqual(0);
      expect(runA.successRate).toBeLessThanOrEqual(100);
      expect(runA.simulations).toHaveLength(200);
      expect(runA.simulations[0]).toHaveLength(26); // year 0..25 inclusive
    });

    it('orders FIRE crossing years logically across bull (P90), median (P50), and bear (P10) paths', () => {
      const result = runMonteCarloSimulation(
        '1000000',
        '20000',
        '0.08',
        '0.18',
        30,
        300,
        'wealthos-crossing-order-2026',
        { targetAmount: '12000000', startYear: 2026 }
      );

      // P90 (90th percentile optimistic wealth path) hits FIRE earliest,
      // followed by Median (50th percentile), while P10 (10th percentile bear path) hits latest.
      expect(result.p90Year).toBeLessThan(result.medianYear);
      expect(result.medianYear).toBeLessThan(result.p10Year);

      // At final year, wealth percentiles strictly satisfy P10 < Median < P90
      const finalPoint =
        result.percentileSeries![result.percentileSeries!.length - 1]!;
      expect(new Dec(finalPoint.p10).lt(new Dec(finalPoint.median))).toBe(true);
      expect(new Dec(finalPoint.median).lt(new Dec(finalPoint.p90))).toBe(true);
    });
  });

  describe('4. calculateGoalProgress', () => {
    const sampleGoal: FIREGoal = {
      id: 'goal-01',
      userId: 'user-01',
      name: 'Core FIRE Goal',
      targetAmount: '10000000',
      currentAmount: '500000',
      monthlyContribution: '35000',
      expectedReturn: '0.09',
      inflationRate: '0.03',
      targetYear: 2046,
      currentAge: 30,
      retirementAge: 50,
    };

    it('computes accurate Decimal progress percentage, yearsRemaining, and onTrack status', () => {
      const progress = calculateGoalProgress(sampleGoal, '2500000', 2026);
      expect(progress.progressPct).toBe('25.00');
      expect(progress.yearsRemaining).toBe(20);
      expect(progress.onTrack).toBe(true);
    });

    it('marks goal as off-track when targetYear is too close for current contribution rate', () => {
      const tightGoal: FIREGoal = {
        ...sampleGoal,
        monthlyContribution: '5000',
        targetYear: 2030,
      };
      const progress = calculateGoalProgress(tightGoal, '500000', 2026);
      expect(progress.yearsRemaining).toBe(4);
      expect(progress.onTrack).toBe(false);
    });
  });

  describe('5. Backend REST API Endpoints (/api/fire) via Supertest', () => {
    const app = createApp();
    const prisma = getPrismaClient();
    const testRunId = Date.now().toString();
    const userAEmail = `fire.a.${testRunId}@wealthos.th`;
    const userBEmail = `fire.b.${testRunId}@wealthos.th`;

    let tokenA = '';
    let tokenB = '';
    let userAId = '';
    let userBId = '';
    let createdGoalId = '';
    let portfolioId = '';

    beforeAll(async () => {
      const regA = await request(app).post('/api/auth/register').send({
        email: userAEmail,
        password: 'Password123!',
        name: 'FIRE Planner User A',
      });
      expect(regA.status).toBe(201);
      tokenA = regA.body.token;
      userAId = regA.body.user.id;

      const regB = await request(app).post('/api/auth/register').send({
        email: userBEmail,
        password: 'Password123!',
        name: 'FIRE Planner User B',
      });
      expect(regB.status).toBe(201);
      tokenB = regB.body.token;
      userBId = regB.body.user.id;

      // Create portfolio + upload Bitkub CSV for User A so live portfolio value > 0
      const pRes = await request(app)
        .post('/api/portfolios')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ name: 'FIRE Live Crypto Portfolio', baseCurrency: 'THB' });
      expect(pRes.status).toBe(201);
      portfolioId = pRes.body.id;

      const bitkubCsv = [
        'วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม',
        '2024-10-01 10:00:00,ซื้อ,BTC/THB,2000000,0.5,1000000,2500',
      ].join('\n');

      const upRes = await request(app)
        .post('/api/upload/csv')
        .set('Authorization', `Bearer ${tokenA}`)
        .field('portfolioId', portfolioId)
        .field('exchange', 'BITKUB')
        .attach('file', Buffer.from(bitkubCsv, 'utf8'), 'fire_btc.csv');
      expect(upRes.status).toBe(201);
    });

    afterAll(async () => {
      await prisma.user.deleteMany({
        where: { id: { in: [userAId, userBId].filter(Boolean) } },
      });
    });

    it('creates a new FIRE goal via POST /api/fire/goals and lists via GET /api/fire/goals', async () => {
      const createRes = await request(app)
        .post('/api/fire/goals')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({
          name: 'Early Retirement at 48',
          targetAmount: '12000000',
          currentAmount: '200000',
          monthlyContribution: '30000',
          expectedReturn: '0.08',
          inflationRate: '0.03',
          targetYear: 2045,
          currentAge: 29,
          retirementAge: 48,
        });

      expect(createRes.status).toBe(201);
      expect(createRes.body.name).toBe('Early Retirement at 48');
      expect(createRes.body.targetAmount).toBe('12000000.00');
      createdGoalId = createRes.body.id;

      const listRes = await request(app)
        .get('/api/fire/goals')
        .set('Authorization', `Bearer ${tokenA}`);
      expect(listRes.status).toBe(200);
      expect(listRes.body).toHaveLength(1);
      expect(listRes.body[0].id).toBe(createdGoalId);
    });

    it('pulls real FIFO portfolio value in GET /api/fire/goals/:id/progress and enforces multi-user isolation', async () => {
      const progRes = await request(app)
        .get(`/api/fire/goals/${createdGoalId}/progress`)
        .set('Authorization', `Bearer ${tokenA}`);

      expect(progRes.status).toBe(200);
      // 0.5 BTC @ 2,000,000 = 1,000,000 THB live portfolio + 200,000 goal cash = 1,200,000 THB (10.00% of 12M)
      expect(progRes.body.livePortfolioValueTHB).toBe('1000000.00');
      expect(progRes.body.currentAmount).toBe('1200000.00');
      expect(progRes.body.progressPct).toBe('10.00');

      // User B must be blocked with 403 Forbidden
      const forbiddenRes = await request(app)
        .get(`/api/fire/goals/${createdGoalId}/progress`)
        .set('Authorization', `Bearer ${tokenB}`);
      expect(forbiddenRes.status).toBe(403);
    });

    it('runs Monte Carlo simulation via POST /api/fire/monte-carlo and serves GET /api/fire/summary', async () => {
      const mcRes = await request(app)
        .post('/api/fire/monte-carlo')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({
          currentAmount: '1200000',
          monthlyContribution: '30000',
          expectedReturn: '0.085',
          volatility: '0.15',
          years: 20,
          numSimulations: 120,
          seed: 'supertest-fire-seed',
          targetAmount: '12000000',
        });

      expect(mcRes.status).toBe(200);
      expect(mcRes.body.simulations).toHaveLength(120);
      expect(mcRes.body.successRate).toBeGreaterThanOrEqual(0);
      expect(mcRes.body.successRate).toBeLessThanOrEqual(100);

      const summaryRes = await request(app)
        .get('/api/fire/summary')
        .set('Authorization', `Bearer ${tokenA}`);

      expect(summaryRes.status).toBe(200);
      expect(summaryRes.body.fireNumber).toBe('12000000.00');
      expect(summaryRes.body.currentPortfolioValueTHB).toBe('1000000.00');
      expect(summaryRes.body.goalsCount).toBe(1);
    });
  });
});
