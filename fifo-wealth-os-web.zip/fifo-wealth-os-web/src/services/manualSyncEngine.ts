import {
  computeDividendHash,
  computeTransactionHash,
  fetchAndParseIBKRFlexData,
} from '../adapters/ibkrFlexAdapter';
import { defaultApiFXProvider } from '../api/fxProvider';
import { mapEngineTransactionToPrismaCreate } from '../api/mappers';
import { getPrismaClient } from '../db/prisma';
import { AppError } from '../middleware/errorHandler';
import { Dividend, Transaction } from '../types';
import { ManualSyncResult } from '../types/sync';
import {
  getHistoricalPreSplitTxHashes,
  registerSyncedCorporateActions,
} from './corporateActionProcessor';
import { enrichDividendsWithFX } from './dividendEnricher';
import { decryptData } from './encryptionService';
import { FXRateProvider } from './fxRateService';
import { enrichTransactionsWithFX } from './transactionEnricher';
import { assertTransactionDatesWithinAnnualLimit } from './entitlementService';

export interface TriggerSyncOptions {
  portfolioId?: string;
  fxProvider?: FXRateProvider;
  flexBaseUrl?: string;
  artificialDelayMs?: number;
}

function formatUtcIsoDate(date: Date): string {
  return date.toISOString().slice(0, 10);
}

/**
 * Manual Sync Engine (On-Demand Read-Only IBKR Flex Sync):
 * 1. Retrieves & decrypts AES-256-GCM credentials in memory (zero token logging)
 * 2. Sets connection status -> 'SYNCING'
 * 3. Determines sync date range (lastSyncedAt -> now, or 30 days lookback on initial sync)
 * 4. Fetches & parses IBKR Flex XML into Canonical Data Model (`Transaction[]` & `Dividend[]`)
 * 5. Enforces SHA-256 Idempotency Check (`date + symbol + qty + price + type`)
 * 6. Enriches new records to THB via `enrichTransactionsWithFX` & `enrichDividendsWithFX`
 * 7. Atomically commits new records + updates `lastSyncedAt` & `status: 'CONNECTED'` via Prisma `$transaction`
 */
export async function triggerManualSync(
  userId: string,
  options: TriggerSyncOptions = {}
): Promise<ManualSyncResult> {
  const prisma = getPrismaClient();

  const connection = await prisma.brokerConnection.findUnique({
    where: {
      userId_brokerName: {
        userId,
        brokerName: 'IBKR',
      },
    },
  });

  if (!connection || connection.status === 'DISCONNECTED') {
    throw new AppError(
      404,
      'BROKER_NOT_CONNECTED',
      'No active IBKR Read-Only connection found for this user.'
    );
  }

  // Decrypt token strictly in memory — never log decrypted value
  let decryptedToken: string;
  try {
    decryptedToken = decryptData(connection.flexQueryTokenEncrypted);
  } catch {
    await prisma.brokerConnection.update({
      where: { id: connection.id },
      data: { status: 'ERROR' },
    });
    throw new AppError(
      500,
      'CREDENTIAL_DECRYPTION_FAILED',
      'Unable to decrypt stored IBKR Read-Only credentials.'
    );
  }

  // Step 2: Mark status as 'SYNCING'
  await prisma.brokerConnection.update({
    where: { id: connection.id },
    data: { status: 'SYNCING' },
  });

  try {
    if (options.artificialDelayMs && options.artificialDelayMs > 0) {
      await new Promise((resolve) =>
        setTimeout(resolve, Math.min(options.artificialDelayMs!, 5000))
      );
    }

    // Resolve target portfolio owned by `userId`
    const requestedPortfolioId =
      options.portfolioId ?? connection.portfolioId ?? undefined;
    let targetPortfolio = requestedPortfolioId
      ? await prisma.portfolio.findFirst({
          where: { id: requestedPortfolioId, userId },
        })
      : null;

    if (!targetPortfolio) {
      const userPortfolios = await prisma.portfolio.findMany({
        where: { userId },
        orderBy: { createdAt: 'asc' },
      });
      targetPortfolio =
        userPortfolios.find((p) => p.name.toUpperCase().includes('IBKR')) ??
        userPortfolios[0] ??
        null;
    }

    if (!targetPortfolio) {
      targetPortfolio = await prisma.portfolio.create({
        data: {
          userId,
          name: 'Interactive Brokers (IBKR Auto-Sync)',
          baseCurrency: 'THB',
        },
      });
    }

    // Step 3: Compute sync window (lastSyncedAt -> now, or 30 days back on first sync)
    const now = new Date();
    const fromDateObj = connection.lastSyncedAt
      ? connection.lastSyncedAt
      : new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const fromDate = formatUtcIsoDate(fromDateObj);
    const toDate = formatUtcIsoDate(now);

    // Step 4: Fetch & parse IBKR Flex XML into Canonical `Transaction[]` & `Dividend[]`
    const parsed = await fetchAndParseIBKRFlexData(
      decryptedToken,
      connection.flexQueryId,
      fromDate,
      toDate,
      options.flexBaseUrl ? { baseUrl: options.flexBaseUrl } : undefined
    );

    // Wipe local token reference as soon as HTTP/mock request completes
    decryptedToken = '';

    // Step 5: Idempotency Check against existing DB records in target portfolio
    const [existingTxs, existingDivs] = await Promise.all([
      prisma.transaction.findMany({
        where: { portfolioId: targetPortfolio.id },
      }),
      prisma.dividend.findMany({
        where: { portfolioId: targetPortfolio.id },
      }),
    ]);

    const seenTxHashes = new Set<string>([
      ...existingTxs.map((t) =>
        computeTransactionHash({
          date: t.date,
          symbol: t.symbol,
          qty: t.qty,
          price: t.price,
          type: t.type,
        })
      ),
      ...getHistoricalPreSplitTxHashes(targetPortfolio.id),
    ]);

    const seenDivHashes = new Set<string>(
      existingDivs.map((d) =>
        computeDividendHash({
          date: d.date,
          symbol: d.symbol,
          qty: d.qty,
          gross: d.gross,
        })
      )
    );

    const uniqueNewTxs: Transaction[] = [];
    let skippedTransactions = 0;
    for (const tx of parsed.transactions) {
      const hash =
        parsed.transactionHashes[tx.id] ??
        computeTransactionHash({
          date: tx.date,
          symbol: tx.symbol,
          qty: tx.qty,
          price: tx.price,
          type: tx.type,
        });

      if (seenTxHashes.has(hash)) {
        skippedTransactions += 1;
      } else {
        seenTxHashes.add(hash);
        uniqueNewTxs.push(tx);
      }
    }

    const uniqueNewDivs: Dividend[] = [];
    let skippedDividends = 0;
    for (const div of parsed.dividends) {
      const hash =
        parsed.dividendHashes[div.id] ??
        computeDividendHash({
          date: div.date,
          symbol: div.symbol,
          qty: div.qty,
          gross: div.gross,
        });

      if (seenDivHashes.has(hash)) {
        skippedDividends += 1;
      } else {
        seenDivHashes.add(hash);
        uniqueNewDivs.push(div);
      }
    }

    // Register any IBKR Corporate Actions detected in the Flex XML (idempotent)
    const newlyRegisteredActions = registerSyncedCorporateActions(
      targetPortfolio.id,
      parsed.corporateActions
    );

    // Step 6: Enrich new records into portfolio baseCurrency (THB)
    // Note: `fetchAndParseIBKRFlexData` -> `parseIBKRDividends` already converted THB dividends via `botFxProvider` on `payDate`.
    const fxProvider = options.fxProvider ?? defaultApiFXProvider;
    const [enrichedTxs, enrichedDivs] = await Promise.all([
      uniqueNewTxs.length > 0
        ? enrichTransactionsWithFX(
            uniqueNewTxs,
            fxProvider,
            targetPortfolio.baseCurrency
          )
        : Promise.resolve([]),
      uniqueNewDivs.length > 0
        ? !options.fxProvider &&
          targetPortfolio.baseCurrency.toUpperCase() === 'THB' &&
          uniqueNewDivs.every(
            (d) =>
              d.fxRate !== null &&
              d.grossTHB !== null &&
              d.whtTHB !== null &&
              d.netTHB !== null
          )
          ? Promise.resolve(uniqueNewDivs)
          : enrichDividendsWithFX(
              uniqueNewDivs,
              fxProvider,
              targetPortfolio.baseCurrency
            )
        : Promise.resolve([]),
    ]);

    await assertTransactionDatesWithinAnnualLimit(
      userId,
      enrichedTxs.map((transaction) => transaction.date)
    );

    // Step 7 & 8: Transactional DB persistence + connection state update
    const syncedAt = new Date();
    const portfolioId = targetPortfolio.id;

    await prisma.$transaction(async (txClient) => {
      for (const tx of enrichedTxs) {
        await txClient.transaction.create({
          data: mapEngineTransactionToPrismaCreate(tx, portfolioId),
        });
      }

      for (const div of enrichedDivs) {
        await txClient.dividend.create({
          data: {
            portfolioId,
            date: div.date,
            symbol: div.symbol,
            qty: div.qty,
            divPerShare: div.divPerShare,
            gross: div.gross,
            whtRate: div.whtRate,
            wht: div.wht,
            net: div.net,
            originalCurrency: div.originalCurrency,
            fxRate: div.fxRate,
            grossTHB: div.grossTHB,
            whtTHB: div.whtTHB,
            netTHB: div.netTHB,
          },
        });
      }

      await txClient.brokerConnection.update({
        where: { id: connection.id },
        data: {
          status: 'CONNECTED',
          lastSyncedAt: syncedAt,
          portfolioId,
        },
      });
    });

    return {
      addedTransactions: enrichedTxs.length,
      addedDividends: enrichedDivs.length,
      skippedTransactions,
      skippedDividends,
      detectedCorporateActions: newlyRegisteredActions.length,
      corporateActions: parsed.corporateActions,
      portfolioId,
      status: 'CONNECTED',
      lastSyncedAt: syncedAt.toISOString(),
    };
  } catch (err) {
    const connectionStatus =
      err instanceof AppError && err.code === 'SUBSCRIPTION_LIMIT_REACHED'
        ? 'CONNECTED'
        : 'ERROR';
    await prisma.brokerConnection
      .update({
        where: { id: connection.id },
        data: { status: connectionStatus },
      })
      .catch(() => undefined);
    throw err;
  }
}
