import Decimal from 'decimal.js';
import { blackScholesPrice } from './optionsEngine';
import { calculatePEMetrics, generateJCurveData } from './privateEquityEngine';
import type { PECashFlow } from '../types/advancedAssets';

/** Decimal context for sample-chain and comparison calculations (40 digits, half-up). */
export const PolishDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type OptionChainSymbol = 'AAPL' | 'SPY';
export type OptionMoneyness = 'ITM' | 'ATM' | 'OTM';

export interface OptionsChainQuote {
  strike: string;
  callBid: string;
  callAsk: string;
  callIV: string;
  callDelta: string;
  callMoneyness: OptionMoneyness;
  putBid: string;
  putAsk: string;
  putIV: string;
  putDelta: string;
  putMoneyness: OptionMoneyness;
}

export interface OptionsChainExpiry {
  expiryDate: string;
  label: string;
  daysToExpiry: number;
  timeToExpiry: string;
  quotes: OptionsChainQuote[];
}

export interface OptionsChainResult {
  symbol: OptionChainSymbol;
  underlyingPrice: string;
  currency: 'USD';
  asOfDate: string;
  riskFreeRate: string;
  source: 'ILLUSTRATIVE_MODEL';
  expiries: OptionsChainExpiry[];
}

const OPTION_UNDERLYINGS: Record<OptionChainSymbol, { price: string; baseVolatility: string; strikes: readonly string[] }> = {
  AAPL: { price: '238.00', baseVolatility: '0.3100', strikes: ['200', '210', '220', '230', '240'] },
  SPY: { price: '610.00', baseVolatility: '0.2200', strikes: ['580', '600', '610', '620', '640'] },
};

const OPTION_EXPIRIES = [
  { expiryDate: '2026-12-18', label: 'Dec 18, 2026' },
  { expiryDate: '2027-01-15', label: 'Jan 15, 2027' },
  { expiryDate: '2027-03-19', label: 'Mar 19, 2027' },
] as const;

const RISK_FREE_RATE = '0.0400';
const MINIMUM_HALF_SPREAD = new PolishDecimal('0.01');

function parseDecimal(value: string, label: string): Decimal {
  try {
    const result = new PolishDecimal(value);
    if (!result.isFinite()) throw new Error();
    return result;
  } catch {
    throw new Error(`${label} must be a finite decimal string.`);
  }
}

function fixed(value: Decimal, places: number): string {
  return value.toDecimalPlaces(places, PolishDecimal.ROUND_HALF_UP).toFixed(places);
}

function dateOrdinal(value: string, label: string): number {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new Error(`${label} must use YYYY-MM-DD format.`);
  }
  const timestamp = Date.parse(`${value}T00:00:00.000Z`);
  if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString().slice(0, 10) !== value) {
    throw new Error(`${label} must be a valid calendar date.`);
  }
  return Math.trunc(timestamp / 86_400_000);
}

function moneynessFor(
  optionType: 'CALL' | 'PUT',
  underlying: Decimal,
  strike: Decimal,
): OptionMoneyness {
  const relativeDistance = strike.minus(underlying).abs().dividedBy(underlying);
  if (relativeDistance.lte('0.01')) return 'ATM';
  if (optionType === 'CALL') return strike.lt(underlying) ? 'ITM' : 'OTM';
  return strike.gt(underlying) ? 'ITM' : 'OTM';
}

function quoteSides(midPrice: string): { bid: string; ask: string } {
  const mid = parseDecimal(midPrice, 'midPrice');
  const halfSpread = PolishDecimal.max(mid.times('0.01'), MINIMUM_HALF_SPREAD);
  return {
    bid: fixed(PolishDecimal.max(mid.minus(halfSpread), 0), 2),
    ask: fixed(mid.plus(halfSpread), 2),
  };
}

/**
 * Builds an illustrative options chain using the same Black–Scholes engine as the Options Desk.
 * Prices are model-derived snapshots, not live or executable quotes.
 */
export function buildSampleOptionsChain(
  symbol: OptionChainSymbol,
  asOfDate = new Date().toISOString().slice(0, 10),
): OptionsChainResult {
  const underlyingConfig = OPTION_UNDERLYINGS[symbol];
  if (!underlyingConfig) throw new Error('Only AAPL and SPY sample chains are available.');

  const asOfOrdinal = dateOrdinal(asOfDate, 'asOfDate');
  const underlying = parseDecimal(underlyingConfig.price, 'underlyingPrice');
  const baseVolatility = parseDecimal(underlyingConfig.baseVolatility, 'baseVolatility');
  const expiries = OPTION_EXPIRIES.flatMap((expiry, expiryIndex): OptionsChainExpiry[] => {
    const daysToExpiry = dateOrdinal(expiry.expiryDate, 'expiryDate') - asOfOrdinal;
    if (daysToExpiry <= 0) return [];

    const timeToExpiry = new PolishDecimal(String(daysToExpiry)).dividedBy(365);
    const termAdjustment = new PolishDecimal(String(expiryIndex)).times('0.005');
    const quotes = underlyingConfig.strikes.map((strikeValue): OptionsChainQuote => {
      const strike = parseDecimal(strikeValue, 'strikePrice');
      const relativeDistance = strike.minus(underlying).abs().dividedBy(underlying);
      const volatility = baseVolatility.plus(relativeDistance.times('0.20')).plus(termAdjustment);
      const modelInputs = {
        underlyingPrice: underlying.toString(),
        strikePrice: strike.toString(),
        timeToExpiry: timeToExpiry.toString(),
        riskFreeRate: RISK_FREE_RATE,
        volatility: volatility.toString(),
      };
      const call = blackScholesPrice({ ...modelInputs, optionType: 'CALL' });
      const put = blackScholesPrice({ ...modelInputs, optionType: 'PUT' });
      const callSides = quoteSides(call.theoreticalPrice);
      const putSides = quoteSides(put.theoreticalPrice);

      return {
        strike: fixed(strike, 2),
        callBid: callSides.bid,
        callAsk: callSides.ask,
        callIV: fixed(volatility, 4),
        callDelta: call.delta,
        callMoneyness: moneynessFor('CALL', underlying, strike),
        putBid: putSides.bid,
        putAsk: putSides.ask,
        putIV: fixed(volatility, 4),
        putDelta: put.delta,
        putMoneyness: moneynessFor('PUT', underlying, strike),
      };
    });

    return [{
      expiryDate: expiry.expiryDate,
      label: expiry.label,
      daysToExpiry,
      timeToExpiry: fixed(timeToExpiry, 8),
      quotes,
    }];
  });

  if (expiries.length === 0) {
    throw new Error('All sample expiries have passed; choose an as-of date before December 18, 2026.');
  }

  return {
    symbol,
    underlyingPrice: fixed(underlying, 2),
    currency: 'USD',
    asOfDate,
    riskFreeRate: RISK_FREE_RATE,
    source: 'ILLUSTRATIVE_MODEL',
    expiries,
  };
}

export interface REITPeerSeed {
  symbol: string;
  name: string;
  propertyType: string;
  marketPrice: string;
  navPerUnit: string;
  annualDistributionPerUnit: string;
  occupancyRate: string;
  marketCapTHB: string;
}

export interface REITPeer extends REITPeerSeed {
  distributionYield: string;
  priceToNAV: string;
}

const REIT_PEER_SEEDS: readonly REITPeerSeed[] = [
  {
    symbol: 'WHART', name: 'WHA Premium Growth Freehold & Leasehold', propertyType: 'Logistics',
    marketPrice: '10.50', navPerUnit: '11.60', annualDistributionPerUnit: '0.65', occupancyRate: '0.92', marketCapTHB: '15000000000',
  },
  {
    symbol: 'CPNREIT', name: 'CPN Retail Growth Leasehold REIT', propertyType: 'Retail',
    marketPrice: '11.20', navPerUnit: '12.40', annualDistributionPerUnit: '0.78', occupancyRate: '0.91', marketCapTHB: '17000000000',
  },
  {
    symbol: 'FTREIT', name: 'Frasers Property Thailand Industrial REIT', propertyType: 'Industrial',
    marketPrice: '9.30', navPerUnit: '10.10', annualDistributionPerUnit: '0.59', occupancyRate: '0.94', marketCapTHB: '18000000000',
  },
  {
    symbol: 'SIRI', name: 'SIRI · illustrative residential peer', propertyType: 'Residential / mixed-use',
    marketPrice: '8.70', navPerUnit: '9.10', annualDistributionPerUnit: '0.64', occupancyRate: '0.88', marketCapTHB: '11000000000',
  },
  {
    symbol: 'LHHOTEL', name: 'LH Hotel Leasehold Real Estate Investment Trust', propertyType: 'Hospitality',
    marketPrice: '10.00', navPerUnit: '10.80', annualDistributionPerUnit: '0.85', occupancyRate: '0.76', marketCapTHB: '14000000000',
  },
];

/** Returns sample REIT peers with exact ratios; all market data is illustrative, not live. */
export function getSampleREITPeers(): REITPeer[] {
  return REIT_PEER_SEEDS.map((peer) => {
    const price = parseDecimal(peer.marketPrice, 'marketPrice');
    const nav = parseDecimal(peer.navPerUnit, 'navPerUnit');
    const distribution = parseDecimal(peer.annualDistributionPerUnit, 'annualDistributionPerUnit');
    return {
      ...peer,
      distributionYield: fixed(distribution.dividedBy(price), 6),
      priceToNAV: fixed(price.dividedBy(nav), 6),
    };
  });
}

export type REITPeerSortBy = 'distributionYield' | 'priceToNAV' | 'occupancyRate' | 'marketCapTHB';
export type SortDirection = 'ASC' | 'DESC';

export function sortREITPeers(
  peers: readonly REITPeer[],
  sortBy: REITPeerSortBy,
  direction: SortDirection = 'DESC',
): REITPeer[] {
  const multiplier = direction === 'ASC' ? 1 : -1;
  return [...peers].sort((left, right) => {
    const comparison = parseDecimal(left[sortBy], sortBy).comparedTo(parseDecimal(right[sortBy], sortBy));
    return comparison * multiplier || left.symbol.localeCompare(right.symbol);
  });
}

/** Add/remove a REIT from the CSV/chart selection, enforcing the five-peer limit. */
export function toggleREITPeerSelection(
  selectedSymbols: readonly string[],
  symbol: string,
  maximum = 5,
): string[] {
  if (!Number.isInteger(maximum) || maximum < 1) throw new Error('maximum must be a positive integer.');
  if (!REIT_PEER_SEEDS.some((peer) => peer.symbol === symbol)) throw new Error(`Unknown REIT peer: ${symbol}.`);
  const uniqueSelection = [...new Set(selectedSymbols)];
  if (uniqueSelection.includes(symbol)) return uniqueSelection.filter((selected) => selected !== symbol);
  if (uniqueSelection.length >= maximum) throw new Error(`Select no more than ${maximum} REITs for comparison.`);
  return [...uniqueSelection, symbol];
}

export type PEStage = 'VENTURE' | 'GROWTH' | 'BUYOUT';
export type PEFundStatus = 'INVESTING' | 'VALUE_CREATION' | 'HARVESTING';

export interface SamplePEFundSeed {
  id: string;
  name: string;
  vintage: number;
  stage: PEStage;
  committedCapital: string;
  calledCapital: string;
  investedCapital: string;
  distributedCapital: string;
  residualValue: string;
  aumTHB: string;
  status: PEFundStatus;
  cashFlows: readonly PECashFlow[];
}

export interface SamplePEFund extends Omit<SamplePEFundSeed, 'cashFlows'> {
  tvpi: string;
  dpi: string;
  rvpi: string;
  moic: string;
  irr: string;
  cashFlows: PECashFlow[];
  jCurve: ReturnType<typeof generateJCurveData>;
}

const PE_FUND_SEEDS: readonly SamplePEFundSeed[] = [
  {
    id: 'northstar-growth-iii', name: 'Northstar Growth III', vintage: 2021, stage: 'GROWTH',
    committedCapital: '5000000000', calledCapital: '4100000000', investedCapital: '3800000000',
    distributedCapital: '1500000000', residualValue: '4400000000', aumTHB: '5000000000', status: 'HARVESTING',
    cashFlows: [
      { date: '2021-06-30', amount: '-1200000000', type: 'CALL' },
      { date: '2022-06-30', amount: '-1400000000', type: 'CALL' },
      { date: '2023-06-30', amount: '-1200000000', type: 'CALL' },
      { date: '2024-06-30', amount: '200000000', type: 'DISTRIBUTION' },
      { date: '2025-06-30', amount: '600000000', type: 'DISTRIBUTION' },
      { date: '2026-06-30', amount: '5100000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'siam-ventures-select', name: 'Siam Ventures Select', vintage: 2023, stage: 'VENTURE',
    committedCapital: '2200000000', calledCapital: '1750000000', investedCapital: '1400000000',
    distributedCapital: '140000000', residualValue: '1610000000', aumTHB: '2200000000', status: 'INVESTING',
    cashFlows: [
      { date: '2023-04-01', amount: '-700000000', type: 'CALL' },
      { date: '2024-04-01', amount: '-700000000', type: 'CALL' },
      { date: '2025-10-01', amount: '140000000', type: 'DISTRIBUTION' },
      { date: '2026-10-01', amount: '1610000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'ggv-capital-growth', name: 'GGV Capital Growth Fund', vintage: 2022, stage: 'BUYOUT',
    committedCapital: '2500000000', calledCapital: '2200000000', investedCapital: '2000000000',
    distributedCapital: '800000000', residualValue: '2800000000', aumTHB: '2500000000', status: 'HARVESTING',
    cashFlows: [
      { date: '2022-03-31', amount: '-800000000', type: 'CALL' },
      { date: '2023-03-31', amount: '-1200000000', type: 'CALL' },
      { date: '2024-12-31', amount: '400000000', type: 'DISTRIBUTION' },
      { date: '2025-12-31', amount: '400000000', type: 'DISTRIBUTION' },
      { date: '2026-10-01', amount: '2800000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'east-ventures-fund', name: 'East Ventures', vintage: 2024, stage: 'VENTURE',
    committedCapital: '1200000000', calledCapital: '900000000', investedCapital: '700000000',
    distributedCapital: '0', residualValue: '770000000', aumTHB: '1200000000', status: 'INVESTING',
    cashFlows: [
      { date: '2024-02-01', amount: '-350000000', type: 'CALL' },
      { date: '2025-02-01', amount: '-350000000', type: 'CALL' },
      { date: '2026-02-01', amount: '770000000', type: 'DISTRIBUTION' },
    ],
  },
  {
    id: 'openspace-ventures-iv', name: 'Openspace Ventures IV', vintage: 2022, stage: 'GROWTH',
    committedCapital: '1800000000', calledCapital: '1700000000', investedCapital: '1500000000',
    distributedCapital: '300000000', residualValue: '1680000000', aumTHB: '1800000000', status: 'VALUE_CREATION',
    cashFlows: [
      { date: '2022-01-15', amount: '-700000000', type: 'CALL' },
      { date: '2023-01-15', amount: '-800000000', type: 'CALL' },
      { date: '2024-06-30', amount: '100000000', type: 'DISTRIBUTION' },
      { date: '2025-06-30', amount: '200000000', type: 'DISTRIBUTION' },
      { date: '2026-06-30', amount: '1680000000', type: 'DISTRIBUTION' },
    ],
  },
];

export function getSamplePEFunds(): SamplePEFund[] {
  return PE_FUND_SEEDS.map((fund) => {
    const metrics = calculatePEMetrics(
      fund.committedCapital,
      fund.calledCapital,
      fund.investedCapital,
      fund.distributedCapital,
      fund.residualValue,
      fund.cashFlows,
    );
    const cashFlows = fund.cashFlows.map((cashFlow) => ({ ...cashFlow }));
    return {
      ...fund,
      tvpi: metrics.tvpi,
      dpi: metrics.dpi,
      rvpi: metrics.rvpi,
      moic: metrics.moic,
      irr: metrics.irr,
      cashFlows,
      jCurve: generateJCurveData(cashFlows),
    };
  });
}

export interface PEFundFilters {
  stage?: PEStage | 'ALL';
  vintageFrom?: number;
  vintageTo?: number;
  /** Fractional rate; 0.10 represents a 10% IRR. */
  minIRR?: string;
  /** Fractional rate; 0.10 represents a 10% IRR. */
  maxIRR?: string;
  minTVPI?: string;
  maxTVPI?: string;
  sortBy?: 'IRR' | 'TVPI';
  sortDirection?: SortDirection;
}

export function filterSamplePEFunds(filters: PEFundFilters = {}): SamplePEFund[] {
  const minVintage = filters.vintageFrom;
  const maxVintage = filters.vintageTo;
  if (minVintage !== undefined && !Number.isInteger(minVintage)) throw new Error('vintageFrom must be an integer year.');
  if (maxVintage !== undefined && !Number.isInteger(maxVintage)) throw new Error('vintageTo must be an integer year.');
  if (minVintage !== undefined && maxVintage !== undefined && minVintage > maxVintage) {
    throw new Error('vintageFrom cannot be greater than vintageTo.');
  }

  const minIRR = filters.minIRR === undefined || filters.minIRR === '' ? undefined : parseDecimal(filters.minIRR, 'minIRR');
  const maxIRR = filters.maxIRR === undefined || filters.maxIRR === '' ? undefined : parseDecimal(filters.maxIRR, 'maxIRR');
  const minTVPI = filters.minTVPI === undefined || filters.minTVPI === '' ? undefined : parseDecimal(filters.minTVPI, 'minTVPI');
  const maxTVPI = filters.maxTVPI === undefined || filters.maxTVPI === '' ? undefined : parseDecimal(filters.maxTVPI, 'maxTVPI');
  if (minTVPI?.isNegative() || maxTVPI?.isNegative()) throw new Error('TVPI bounds cannot be negative.');
  if (minIRR && maxIRR && minIRR.gt(maxIRR)) throw new Error('minIRR cannot be greater than maxIRR.');
  if (minTVPI && maxTVPI && minTVPI.gt(maxTVPI)) throw new Error('minTVPI cannot be greater than maxTVPI.');

  const funds = getSamplePEFunds().filter((fund) => {
    if (filters.stage !== undefined && filters.stage !== 'ALL' && fund.stage !== filters.stage) return false;
    if (minVintage !== undefined && fund.vintage < minVintage) return false;
    if (maxVintage !== undefined && fund.vintage > maxVintage) return false;
    const irr = parseDecimal(fund.irr, 'fund.irr');
    const tvpi = parseDecimal(fund.tvpi, 'fund.tvpi');
    if (minIRR && irr.lt(minIRR)) return false;
    if (maxIRR && irr.gt(maxIRR)) return false;
    if (minTVPI && tvpi.lt(minTVPI)) return false;
    if (maxTVPI && tvpi.gt(maxTVPI)) return false;
    return true;
  });

  if (filters.sortBy) {
    const key = filters.sortBy === 'IRR' ? 'irr' : 'tvpi';
    const multiplier = filters.sortDirection === 'ASC' ? 1 : -1;
    funds.sort((left, right) => {
      const comparison = parseDecimal(left[key], key).comparedTo(parseDecimal(right[key], key));
      return comparison * multiplier || left.name.localeCompare(right.name);
    });
  }

  return funds;
}

export function getSamplePEFundDetail(fundId: string): SamplePEFund {
  const fund = getSamplePEFunds().find((candidate) => candidate.id === fundId);
  if (!fund) throw new Error(`Unknown sample PE fund: ${fundId}.`);
  return fund;
}
