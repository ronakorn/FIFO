import fs from 'fs';
import path from 'path';
import Decimal from 'decimal.js';
import PDFDocument from 'pdfkit';
import { TaxEvent, TaxReport } from '../types';
import { THAI_PIT_BRACKETS, formatTaxAmount } from './thaiTaxEngine';

const Dec = Decimal.clone({
  precision: 34,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface TaxReportPDFOptions {
  taxpayerName?: string;
  taxpayerTaxId?: string;
  otherNetIncomeTHB?: string;
}

export interface TaxReportPDFResult {
  filePath: string;
  pageCount: number;
  sizeBytes: number;
}

const COLORS = {
  navy: '#0F172A',
  navyMid: '#1E293B',
  teal: '#0D9488',
  tealLight: '#F0FDFA',
  gold: '#D97706',
  slateText: '#334155',
  mutedText: '#64748B',
  border: '#CBD5E1',
  borderLight: '#E2E8F0',
  rowAlt: '#F8FAFC',
  white: '#FFFFFF',
  positive: '#047857',
  negative: '#B91C1C',
  refundBg: '#ECFDF5',
  payableBg: '#FEF2F2',
} as const;

/**
 * Formats an exact decimal string with thousand separators (pure string/Decimal, no Number math).
 */
function formatDisplayTHB(amountStr: string): string {
  const dec = new Dec(amountStr.trim());
  const fixed = formatTaxAmount(dec);
  const isNeg = fixed.startsWith('-');
  const unsigned = isNeg ? fixed.slice(1) : fixed;
  const [intPart = '0', fracPart = '00'] = unsigned.split('.');
  const withCommas = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${isNeg ? '-' : ''}${withCommas}.${fracPart}`;
}

function formatShortDate(isoOrDate: string): string {
  const match = /^(\d{4}-\d{2}-\d{2})/.exec(isoOrDate.trim());
  return match?.[1] ?? isoOrDate.slice(0, 10);
}

function registerReportFonts(doc: PDFKit.PDFDocument): {
  regular: string;
  bold: string;
} {
  const regularPath = path.resolve(__dirname, '../../assets/fonts/Sarabun-Regular.ttf');
  const boldPath = path.resolve(__dirname, '../../assets/fonts/Sarabun-Bold.ttf');

  if (fs.existsSync(regularPath) && fs.existsSync(boldPath)) {
    doc.registerFont('Sarabun', regularPath);
    doc.registerFont('Sarabun-Bold', boldPath);
    return { regular: 'Sarabun', bold: 'Sarabun-Bold' };
  }

  return { regular: 'Helvetica', bold: 'Helvetica-Bold' };
}

/**
 * Draws the custom vector FIFO Wealth OS geometric emblem logo.
 */
function drawBrandLogo(
  doc: PDFKit.PDFDocument,
  x: number,
  y: number,
  size: number,
  darkTheme: boolean
): void {
  doc.save();
  doc
    .roundedRect(x, y, size, size, size * 0.22)
    .fill(darkTheme ? COLORS.teal : COLORS.navy);

  // Three ascending FIFO bars inside emblem
  const pad = size * 0.22;
  const barWidth = size * 0.14;
  const gap = size * 0.07;
  const baseBottom = y + size - pad;

  const heights = [size * 0.26, size * 0.42, size * 0.56];
  heights.forEach((barH, idx) => {
    const bx = x + pad + idx * (barWidth + gap);
    const by = baseBottom - barH;
    doc
      .roundedRect(bx, by, barWidth, barH, 1.5)
      .fill(idx === 2 ? '#FBBF24' : COLORS.white);
  });

  doc.restore();
}

function drawSectionBanner(
  doc: PDFKit.PDFDocument,
  fonts: { regular: string; bold: string },
  badge: string,
  titleTH: string,
  subtitleEN: string
): number {
  const left = 48;
  const width = doc.page.width - 96;

  drawBrandLogo(doc, left, 36, 26, false);
  doc
    .font(fonts.bold)
    .fontSize(11)
    .fillColor(COLORS.navy)
    .text('FIFO WEALTH OS', left + 34, 38, { lineBreak: false });
  doc
    .font(fonts.regular)
    .fontSize(8.5)
    .fillColor(COLORS.mutedText)
    .text('Thai Tax Compliance & Multi-Currency FIFO Ledger', left + 34, 51, {
      lineBreak: false,
    });

  doc
    .font(fonts.bold)
    .fontSize(9)
    .fillColor(COLORS.teal)
    .text(badge, left, 38, { width, align: 'right', lineBreak: false });

  doc
    .moveTo(left, 72)
    .lineTo(left + width, 72)
    .lineWidth(1)
    .strokeColor(COLORS.border)
    .stroke();

  doc
    .font(fonts.bold)
    .fontSize(16)
    .fillColor(COLORS.navy)
    .text(titleTH, left, 86, { width });

  doc
    .font(fonts.regular)
    .fontSize(9.5)
    .fillColor(COLORS.mutedText)
    .text(subtitleEN, left, 108, { width });

  return 132;
}

interface TableColumn {
  header: string;
  width: number;
  align?: 'left' | 'right' | 'center';
}

function drawStyledTable(
  doc: PDFKit.PDFDocument,
  fonts: { regular: string; bold: string },
  startY: number,
  columns: TableColumn[],
  rows: string[][],
  totalRow: string[] | null,
  continuationTitle: { badge: string; titleTH: string; subtitleEN: string }
): number {
  const left = 48;
  const totalWidth = columns.reduce((sum, c) => sum + c.width, 0);
  const headerHeight = 26;
  const rowHeight = 22;
  const maxBottomY = doc.page.height - 68;

  let currentY = startY;

  const renderHeader = (yPos: number): number => {
    doc.rect(left, yPos, totalWidth, headerHeight).fill(COLORS.navy);
    let colX = left;
    for (const col of columns) {
      doc
        .font(fonts.bold)
        .fontSize(8.5)
        .fillColor(COLORS.white)
        .text(col.header, colX + 6, yPos + 7, {
          width: col.width - 12,
          align: col.align ?? 'left',
          lineBreak: false,
        });
      colX += col.width;
    }
    return yPos + headerHeight;
  };

  currentY = renderHeader(currentY);

  rows.forEach((row, rowIndex) => {
    if (currentY + rowHeight > maxBottomY) {
      doc.addPage();
      currentY = drawSectionBanner(
        doc,
        fonts,
        continuationTitle.badge,
        `${continuationTitle.titleTH} (ต่อ)`,
        `${continuationTitle.subtitleEN} (Continued)`
      );
      currentY = renderHeader(currentY);
    }

    const bgColor = rowIndex % 2 === 1 ? COLORS.rowAlt : COLORS.white;
    doc.rect(left, currentY, totalWidth, rowHeight).fill(bgColor);
    doc
      .moveTo(left, currentY + rowHeight)
      .lineTo(left + totalWidth, currentY + rowHeight)
      .lineWidth(0.5)
      .strokeColor(COLORS.borderLight)
      .stroke();

    let colX = left;
    columns.forEach((col, colIdx) => {
      const cellText = row[colIdx] ?? '';
      doc
        .font(fonts.regular)
        .fontSize(8.5)
        .fillColor(COLORS.slateText)
        .text(cellText, colX + 6, currentY + 5, {
          width: col.width - 12,
          align: col.align ?? 'left',
          lineBreak: false,
        });
      colX += col.width;
    });

    currentY += rowHeight;
  });

  if (totalRow) {
    if (currentY + rowHeight + 4 > maxBottomY) {
      doc.addPage();
      currentY = drawSectionBanner(
        doc,
        fonts,
        continuationTitle.badge,
        `${continuationTitle.titleTH} (สรุปยอดรวม)`,
        `${continuationTitle.subtitleEN} (Totals)`
      );
    }

    doc.rect(left, currentY, totalWidth, rowHeight + 2).fill(COLORS.tealLight);
    doc
      .moveTo(left, currentY)
      .lineTo(left + totalWidth, currentY)
      .lineWidth(1)
      .strokeColor(COLORS.teal)
      .stroke();
    doc
      .moveTo(left, currentY + rowHeight + 2)
      .lineTo(left + totalWidth, currentY + rowHeight + 2)
      .lineWidth(1.2)
      .strokeColor(COLORS.navy)
      .stroke();

    let colX = left;
    columns.forEach((col, colIdx) => {
      const cellText = totalRow[colIdx] ?? '';
      doc
        .font(fonts.bold)
        .fontSize(9)
        .fillColor(COLORS.navy)
        .text(cellText, colX + 6, currentY + 6, {
          width: col.width - 12,
          align: col.align ?? 'left',
          lineBreak: false,
        });
      colX += col.width;
    });

    currentY += rowHeight + 2;
  }

  return currentY;
}

function sumEventField(events: TaxEvent[], getter: (e: TaxEvent) => string): Decimal {
  return events.reduce((acc, ev) => acc.plus(new Dec(getter(ev))), new Dec(0));
}

/**
 * Generates a complete, submission-ready Thai Tax Report PDF Buffer using `pdfkit`.
 */
export async function generateTaxReportPDFBuffer(
  report: TaxReport,
  options?: TaxReportPDFOptions
): Promise<Buffer> {
  return new Promise<Buffer>((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margins: { top: 48, bottom: 42, left: 48, right: 48 },
        bufferPages: true,
        info: {
          Title: `FIFO Wealth OS - Thai Tax Report ${report.taxYear}`,
          Author: 'FIFO Wealth OS Tax Compliance Engine',
          Subject: `Annual Personal Income Tax Summary (Tax Year ${report.taxYear})`,
        },
      });

      const chunks: Buffer[] = [];
      doc.on('data', (chunk: Buffer) => chunks.push(chunk));
      doc.on('error', reject);
      doc.on('end', () => resolve(Buffer.concat(chunks)));

      const fonts = registerReportFonts(doc);
      const pageWidth = doc.page.width;
      const contentWidth = pageWidth - 96;
      const buddhistYear = report.taxYear + 543;
      const taxpayerName = options?.taxpayerName ?? 'ผู้เสียภาษีเงินได้บุคคลธรรมดา (Individual Taxpayer)';
      const taxpayerTaxId = options?.taxpayerTaxId ?? '-';

      const totalCapGainAmount = sumEventField(report.capitalGains, (e) => e.amountTHB);
      const totalCapGainTaxable = sumEventField(report.capitalGains, (e) => e.taxableIncome);
      const totalCapGainNetTax = sumEventField(report.capitalGains, (e) => e.netTaxPayable);

      const totalDivGross = sumEventField(report.dividends, (e) => e.taxableIncome);
      const totalDivWht = sumEventField(report.dividends, (e) => e.taxWithheld);
      const totalDivNet = sumEventField(report.dividends, (e) => e.amountTHB);
      const totalDivNetTax = sumEventField(report.dividends, (e) => e.netTaxPayable);

      const totalPayableDec = new Dec(report.totalTaxPayable);
      const isRefund = totalPayableDec.lt(0);

      // =========================================================================
      // PAGE 1: COVER PAGE (หน้าปก)
      // =========================================================================
      doc.rect(0, 0, pageWidth, 290).fill(COLORS.navy);
      doc.rect(0, 286, pageWidth, 4).fill(COLORS.gold);

      drawBrandLogo(doc, 48, 52, 46, true);
      doc
        .font(fonts.bold)
        .fontSize(20)
        .fillColor(COLORS.white)
        .text('FIFO WEALTH OS', 108, 54, { lineBreak: false });
      doc
        .font(fonts.regular)
        .fontSize(10.5)
        .fillColor('#94A3B8')
        .text('INSTITUTIONAL MULTI-CURRENCY PORTFOLIO & THAI TAX ENGINE', 108, 79, {
          lineBreak: false,
        });

      doc
        .font(fonts.bold)
        .fontSize(26)
        .fillColor(COLORS.white)
        .text('รายงานสรุปภาษีเงินได้จากการลงทุน', 48, 140, { width: contentWidth });
      doc
        .font(fonts.regular)
        .fontSize(13)
        .fillColor('#CBD5E1')
        .text(
          'Annual Thai Tax Compliance & FIFO Realized Income Report (ภ.ง.ด. 90 / 91)',
          48,
          178,
          { width: contentWidth }
        );

      // Badge pill on cover
      doc.roundedRect(48, 220, 290, 28, 6).fill(COLORS.navyMid);
      doc
        .font(fonts.bold)
        .fontSize(9.5)
        .fillColor('#5EEAD4')
        .text(
          `ปีภาษี พ.ศ. ${buddhistYear} (Tax Year ${report.taxYear}) • สกุลเงิน THB`,
          62,
          228,
          { lineBreak: false }
        );

      // Taxpayer Information Card
      const cardY = 330;
      doc
        .roundedRect(48, cardY, contentWidth, 185, 8)
        .fillAndStroke(COLORS.rowAlt, COLORS.border);

      doc
        .font(fonts.bold)
        .fontSize(12)
        .fillColor(COLORS.navy)
        .text('ข้อมูลผู้มีหน้าที่เสียภาษี (Taxpayer & Report Metadata)', 68, cardY + 18);

      doc
        .moveTo(68, cardY + 40)
        .lineTo(48 + contentWidth - 20, cardY + 40)
        .lineWidth(0.75)
        .strokeColor(COLORS.border)
        .stroke();

      const metaRows: Array<[string, string]> = [
        ['ชื่อผู้เสียภาษี (Taxpayer Name):', taxpayerName],
        ['เลขประจำตัวผู้เสียภาษีอากร (Tax ID):', taxpayerTaxId],
        ['ปีภาษีที่ประเมิน (Assessment Tax Year):', `${report.taxYear} (พ.ศ. ${buddhistYear})`],
        ['วันที่ออกรายงาน (Generated At):', formatShortDate(report.generatedAt)],
        ['หลักการบัญชีและการปัดเศษ (Accounting Basis):', 'FIFO Multi-Currency THB • ROUND_HALF_UP (2 ทศนิยม)'],
      ];

      metaRows.forEach(([label, val], idx) => {
        const ry = cardY + 52 + idx * 24;
        doc
          .font(fonts.bold)
          .fontSize(9.5)
          .fillColor(COLORS.mutedText)
          .text(label, 68, ry, { width: 215, lineBreak: false });
        doc
          .font(fonts.regular)
          .fontSize(9.5)
          .fillColor(COLORS.navy)
          .text(val, 285, ry, { width: contentWidth - 255, lineBreak: false });
      });

      // Cover Quick Snapshot Strip
      const snapY = 550;
      doc
        .roundedRect(48, snapY, contentWidth, 92, 8)
        .fillAndStroke(COLORS.tealLight, COLORS.teal);

      doc
        .font(fonts.bold)
        .fontSize(10.5)
        .fillColor(COLORS.teal)
        .text('สรุปภาพรวมภาระภาษีประจำปี (Executive Tax Highlight)', 68, snapY + 14);

      const colThird = (contentWidth - 40) / 3;
      const highlights: Array<[string, string]> = [
        ['เงินได้พึงประเมินรวม', `${formatDisplayTHB(report.totalTaxableIncome)} THB`],
        ['ภาษีหัก ณ ที่จ่ายรวม (WHT)', `${formatDisplayTHB(report.totalTaxWithheld)} THB`],
        [
          isRefund ? 'เครดิตภาษีขอคืนสุทธิ' : 'ภาษีที่ต้องชำระเพิ่มสุทธิ',
          `${formatDisplayTHB(report.totalTaxPayable)} THB`,
        ],
      ];

      highlights.forEach(([hLabel, hVal], idx) => {
        const hx = 68 + idx * colThird;
        doc
          .font(fonts.regular)
          .fontSize(8.5)
          .fillColor(COLORS.mutedText)
          .text(hLabel, hx, snapY + 38, { width: colThird - 10, lineBreak: false });
        doc
          .font(fonts.bold)
          .fontSize(13)
          .fillColor(idx === 2 ? (isRefund ? COLORS.positive : COLORS.negative) : COLORS.navy)
          .text(hVal, hx, snapY + 56, { width: colThird - 10, lineBreak: false });
      });

      doc
        .font(fonts.regular)
        .fontSize(8.5)
        .fillColor(COLORS.mutedText)
        .text(
          'เอกสารฉบับนี้จัดทำโดยระบบอัตโนมัติ FIFO Wealth OS เพื่อใช้ประกอบการยื่นแบบแสดงรายการภาษีเงินได้บุคคลธรรมดา (ภ.ง.ด. 90/91) ตามประมวลรัษฎากร',
          48,
          685,
          { width: contentWidth, align: 'center' }
        );

      // =========================================================================
      // PAGE 2: EXECUTIVE SUMMARY (หน้าสรุปภาษี)
      // =========================================================================
      doc.addPage();
      let y = drawSectionBanner(
        doc,
        fonts,
        `TAX YEAR ${report.taxYear}`,
        'สรุปผลการคำนวณภาษีเงินได้บุคคลธรรมดา',
        'Executive Tax Calculation Summary & Progressive PIT Breakdown'
      );

      // 3 KPI Cards
      const kpiGap = 12;
      const kpiWidth = (contentWidth - kpiGap * 2) / 3;
      const kpiHeight = 78;

      const kpiCards = [
        {
          titleTH: 'เงินได้พึงประเมินรวม',
          titleEN: 'Total Taxable Income',
          value: `${formatDisplayTHB(report.totalTaxableIncome)} THB`,
          bg: COLORS.rowAlt,
          borderColor: COLORS.border,
          valueColor: COLORS.navy,
        },
        {
          titleTH: 'ภาษีหัก ณ ที่จ่ายรวม',
          titleEN: 'Total Tax Withheld (WHT)',
          value: `${formatDisplayTHB(report.totalTaxWithheld)} THB`,
          bg: COLORS.rowAlt,
          borderColor: COLORS.border,
          valueColor: COLORS.teal,
        },
        {
          titleTH: isRefund ? 'ภาษีชำระไว้เกิน (ขอคืนได้)' : 'ภาษีที่ต้องชำระเพิ่มเติม',
          titleEN: isRefund ? 'Net Tax Refundable' : 'Total Net Tax Payable',
          value: `${formatDisplayTHB(report.totalTaxPayable)} THB`,
          bg: isRefund ? COLORS.refundBg : COLORS.payableBg,
          borderColor: isRefund ? COLORS.positive : COLORS.negative,
          valueColor: isRefund ? COLORS.positive : COLORS.negative,
        },
      ];

      kpiCards.forEach((card, idx) => {
        const kx = 48 + idx * (kpiWidth + kpiGap);
        doc
          .roundedRect(kx, y, kpiWidth, kpiHeight, 6)
          .fillAndStroke(card.bg, card.borderColor);
        doc
          .font(fonts.bold)
          .fontSize(9.5)
          .fillColor(COLORS.navy)
          .text(card.titleTH, kx + 12, y + 12, { width: kpiWidth - 24, lineBreak: false });
        doc
          .font(fonts.regular)
          .fontSize(7.5)
          .fillColor(COLORS.mutedText)
          .text(card.titleEN, kx + 12, y + 27, { width: kpiWidth - 24, lineBreak: false });
        doc
          .font(fonts.bold)
          .fontSize(13)
          .fillColor(card.valueColor)
          .text(card.value, kx + 12, y + 48, { width: kpiWidth - 24, lineBreak: false });
      });

      y += kpiHeight + 24;

      // Income Category Summary Table
      doc
        .font(fonts.bold)
        .fontSize(11)
        .fillColor(COLORS.navy)
        .text('1. สรุปเงินได้แยกตามประเภท (Assessable Income by Category)', 48, y);
      y += 20;

      y = drawStyledTable(
        doc,
        fonts,
        y,
        [
          { header: 'ประเภทเงินได้ (Category)', width: 167, align: 'left' },
          { header: 'รายการ', width: 56, align: 'center' },
          { header: 'เงินได้พึงประเมิน', width: 94, align: 'right' },
          { header: 'ภาษีหัก ณ ที่จ่าย', width: 94, align: 'right' },
          { header: 'ภาษีสุทธิ (THB)', width: 88, align: 'right' },
        ],
        [
          [
            'Capital Gains (ม. 40(4))',
            String(report.capitalGains.length),
            formatDisplayTHB(formatTaxAmount(totalCapGainTaxable)),
            '0.00',
            formatDisplayTHB(formatTaxAmount(totalCapGainNetTax)),
          ],
          [
            'Dividends / เงินปันผล (ม. 40(4)(ข))',
            String(report.dividends.length),
            formatDisplayTHB(formatTaxAmount(totalDivGross)),
            formatDisplayTHB(formatTaxAmount(totalDivWht)),
            formatDisplayTHB(formatTaxAmount(totalDivNetTax)),
          ],
        ],
        [
          'รวมทั้งสิ้น (Grand Total)',
          String(report.capitalGains.length + report.dividends.length),
          formatDisplayTHB(report.totalTaxableIncome),
          formatDisplayTHB(report.totalTaxWithheld),
          formatDisplayTHB(report.totalTaxPayable),
        ],
        {
          badge: `TAX YEAR ${report.taxYear}`,
          titleTH: 'สรุปผลการคำนวณภาษีเงินได้บุคคลธรรมดา',
          subtitleEN: 'Executive Tax Summary',
        }
      );

      y += 22;

      // Progressive Tax Bracket Table
      doc
        .font(fonts.bold)
        .fontSize(11)
        .fillColor(COLORS.navy)
        .text('2. ตารางคำนวณภาษีอัตราก้าวหน้า (Thai Progressive PIT Schedule 0% - 35%)', 48, y);
      y += 20;

      const priorIncome = new Dec(options?.otherNetIncomeTHB ?? '0');
      const combinedAssessable = priorIncome.plus(new Dec(report.totalTaxableIncome));

      const bracketRows: string[][] = THAI_PIT_BRACKETS.map((b) => {
        const lower = new Dec(b.minExclusive);
        const upper = b.maxInclusive !== null ? new Dec(b.maxInclusive) : null;
        const rateDec = new Dec(b.rate);
        const ratePct = `${rateDec.times(100).toFixed(0)}%`;

        let incomeInBracket = new Dec(0);
        if (combinedAssessable.gt(lower)) {
          incomeInBracket =
            upper !== null
              ? Dec.min(combinedAssessable, upper).minus(lower)
              : combinedAssessable.minus(lower);
        }
        const taxInBracket = incomeInBracket.times(rateDec);

        return [
          b.label,
          ratePct,
          formatDisplayTHB(formatTaxAmount(incomeInBracket)),
          formatDisplayTHB(formatTaxAmount(taxInBracket)),
        ];
      });

      drawStyledTable(
        doc,
        fonts,
        y,
        [
          { header: 'ช่วงเงินได้สุทธิ (Net Income Bracket)', width: 225, align: 'left' },
          { header: 'อัตราภาษี', width: 70, align: 'center' },
          { header: 'เงินได้ในขั้นนี้ (THB)', width: 102, align: 'right' },
          { header: 'ภาษีในขั้นนี้ (THB)', width: 102, align: 'right' },
        ],
        bracketRows,
        null,
        {
          badge: `TAX YEAR ${report.taxYear}`,
          titleTH: 'ตารางคำนวณภาษีอัตราก้าวหน้า',
          subtitleEN: 'Progressive PIT Schedule',
        }
      );

      // =========================================================================
      // PAGE 3: CAPITAL GAINS SCHEDULE (หน้ารายละเอียด Capital Gains)
      // =========================================================================
      doc.addPage();
      let cgY = drawSectionBanner(
        doc,
        fonts,
        'SCHEDULE 1 • CAPITAL GAINS',
        'รายละเอียดกำไรจากการขายหลักทรัพย์และสินทรัพย์ดิจิทัล (FIFO)',
        'Schedule of Realized Capital Gains & Assessable Income (Base Currency: THB)'
      );

      const cgRows: string[][] =
        report.capitalGains.length > 0
          ? report.capitalGains.map((ev) => [
              ev.id,
              formatShortDate(ev.date),
              ev.symbol,
              formatDisplayTHB(ev.amountTHB),
              formatDisplayTHB(ev.taxableIncome),
              formatDisplayTHB(ev.netTaxPayable),
            ])
          : [['-', '-', 'ไม่มีรายการขายในปีภาษีนี้', '0.00', '0.00', '0.00']];

      drawStyledTable(
        doc,
        fonts,
        cgY,
        [
          { header: 'รหัสอ้างอิง (Event ID)', width: 105, align: 'left' },
          { header: 'วันที่ (Date)', width: 75, align: 'center' },
          { header: 'หลักทรัพย์', width: 69, align: 'center' },
          { header: 'Realized G/L (THB)', width: 85, align: 'right' },
          { header: 'เงินได้พึงประเมิน', width: 85, align: 'right' },
          { header: 'ภาษีสุทธิ (THB)', width: 80, align: 'right' },
        ],
        cgRows,
        [
          'รวม Capital Gains',
          `${report.capitalGains.length} รายการ`,
          '',
          formatDisplayTHB(formatTaxAmount(totalCapGainAmount)),
          formatDisplayTHB(formatTaxAmount(totalCapGainTaxable)),
          formatDisplayTHB(formatTaxAmount(totalCapGainNetTax)),
        ],
        {
          badge: 'SCHEDULE 1 • CAPITAL GAINS',
          titleTH: 'รายละเอียดกำไรจากการขายหลักทรัพย์ (FIFO)',
          subtitleEN: 'Schedule of Realized Capital Gains',
        }
      );

      // =========================================================================
      // PAGE 4: DIVIDENDS SCHEDULE (หน้ารายละเอียด Dividends)
      // =========================================================================
      doc.addPage();
      let divY = drawSectionBanner(
        doc,
        fonts,
        'SCHEDULE 2 • DIVIDENDS & WHT',
        'รายละเอียดเงินปันผลและภาษีหัก ณ ที่จ่าย (มาตรา 40(4)(ข))',
        'Schedule of Dividend Income, Foreign/Local WHT & Net Tax Credits (THB)'
      );

      const divRows: string[][] =
        report.dividends.length > 0
          ? report.dividends.map((ev) => [
              ev.id,
              formatShortDate(ev.date),
              ev.symbol,
              formatDisplayTHB(ev.taxableIncome),
              formatDisplayTHB(ev.taxWithheld),
              formatDisplayTHB(ev.amountTHB),
              formatDisplayTHB(ev.netTaxPayable),
            ])
          : [['-', '-', 'ไม่มีรายการเงินปันผล', '0.00', '0.00', '0.00', '0.00']];

      drawStyledTable(
        doc,
        fonts,
        divY,
        [
          { header: 'รหัสอ้างอิง', width: 80, align: 'left' },
          { header: 'วันที่รับปันผล', width: 68, align: 'center' },
          { header: 'หลักทรัพย์', width: 54, align: 'center' },
          { header: 'Gross (THB)', width: 73, align: 'right' },
          { header: 'หัก ณ ที่จ่าย (WHT)', width: 86, align: 'right' },
          { header: 'รับสุทธิ (Net)', width: 69, align: 'right' },
          { header: 'ภาษีสุทธิ', width: 69, align: 'right' },
        ],
        divRows,
        [
          'รวม Dividends',
          `${report.dividends.length} รายการ`,
          '',
          formatDisplayTHB(formatTaxAmount(totalDivGross)),
          formatDisplayTHB(formatTaxAmount(totalDivWht)),
          formatDisplayTHB(formatTaxAmount(totalDivNet)),
          formatDisplayTHB(formatTaxAmount(totalDivNetTax)),
        ],
        {
          badge: 'SCHEDULE 2 • DIVIDENDS & WHT',
          titleTH: 'รายละเอียดเงินปันผลและภาษีหัก ณ ที่จ่าย',
          subtitleEN: 'Schedule of Dividend Income & WHT',
        }
      );

      // =========================================================================
      // PAGE 5: TAX FILING GUIDE (หน้าคำแนะนำการยื่นภาษี ภ.ง.ด. 90/91)
      // =========================================================================
      doc.addPage();
      let guideY = drawSectionBanner(
        doc,
        fonts,
        'FILING GUIDE • ภ.ง.ด. 90 / 91',
        'คำแนะนำการนำรายงานไปยื่นภาษีเงินได้บุคคลธรรมดา (ภ.ง.ด. 90/91)',
        'Step-by-Step Revenue Department Filing Instructions & Audit Trail Checklist'
      );

      const guideItems: Array<{ title: string; body: string }> = [
        {
          title: '1. การเลือกแบบแสดงรายการ (ภ.ง.ด. 90 vs ภ.ง.ด. 91)',
          body: 'ผู้มีเงินได้จากการลงทุน (เงินปันผล กำไรจากหุ้นต่างประเทศ หรือสินทรัพย์ดิจิทัล) นอกเหนือจากเงินเดือนตามมาตรา 40(1) ต้องยื่นแบบ ภ.ง.ด. 90 ภายในวันที่ 31 มีนาคมของปีถัดไป (หรือต้นเดือนเมษายนสำหรับการยื่นออนไลน์ผ่านระบบ D-MyTax ที่ efiling.rd.go.th)',
        },
        {
          title: '2. การกรอกรายการเงินปันผลและเครดิตภาษี (มาตรา 40(4)(ข))',
          body: 'นำยอดเงินปันผลก่อนหักภาษี (Gross Dividend THB) ในหน้า Schedule 2 ไปกรอกในหมวดเงินได้มาตรา 40(4)(ข) พร้อมกรอกยอดภาษีหัก ณ ที่จ่าย (WHT) เพื่อใช้เป็นเครดิตภาษีหักออกจากภาษีที่ต้องชำระ หรือหากเป็นหุ้นไทยที่ถูกหัก WHT 10% และฐานภาษีของคุณสูงกว่า 10% สามารถพิจารณาใช้สิทธิ์ Final Tax ตามมาตรา 48(3) ได้',
        },
        {
          title: '3. กำไรจากหลักทรัพย์ต่างประเทศ (คำสั่งกรมสรรพากรที่ ป. 161/2566)',
          body: 'กำไรสุทธิจากการขายหุ้นต่างประเทศจะถือเป็นเงินได้พึงประเมินในปีภาษีที่มีการนำเงินได้กลับเข้ามาในประเทศไทย โดยคำนวณต้นทุนแบบ FIFO แปลงเป็นเงินบาทตามอัตราแลกเปลี่ยน ณ วันซื้อ และรายได้สุทธิแปลงเป็นเงินบาทตามอัตราแลกเปลี่ยน ณ วันขาย',
        },
        {
          title: '4. กำไรจากคริปโทเคอร์เรนซีและโทเคนดิจิทัล (มาตรา 40(4)(ซ))',
          body: 'นำยอดกำไรสุทธิจากการโอนสินทรัพย์ดิจิทัลที่คำนวณด้วยวิธี FIFO ไปกรอกในหมวดมาตรา 40(4)(ซ) ทั้งนี้ธุรกรรมที่กระทำผ่านศูนย์ซื้อขายสินทรัพย์ดิจิทัลที่ได้รับอนุญาตจาก ก.ล.ต. ในประเทศ สามารถนำผลขาดทุนในปีภาษีเดียวกันมาหักกลบกำไรได้',
        },
        {
          title: '5. เอกสารหลักฐานประกอบที่ควรจัดเก็บ (Audit Trail Checklist)',
          body: '• รายงานสรุปภาษีฉบับนี้จาก FIFO Wealth OS พร้อมตาราง Schedule 1 และ Schedule 2\n• ไฟล์ CSV Statement ต้นฉบับจากโบรกเกอร์ / ศูนย์ซื้อขาย (เช่น IBKR, Bitkub, Streaming, Dime)\n• หนังสือรับรองการหักภาษี ณ ที่จ่าย (ใบ 50 ทวิ / Dividend Tax Voucher) และหลักฐานการโอนเงินเข้าประเทศไทย',
        },
      ];

      guideItems.forEach((item) => {
        doc
          .roundedRect(48, guideY, contentWidth, 90, 6)
          .fillAndStroke(COLORS.rowAlt, COLORS.borderLight);

        doc
          .font(fonts.bold)
          .fontSize(10.5)
          .fillColor(COLORS.navy)
          .text(item.title, 62, guideY + 11, { width: contentWidth - 28 });

        doc
          .font(fonts.regular)
          .fontSize(8.8)
          .fillColor(COLORS.slateText)
          .text(item.body, 62, guideY + 30, {
            width: contentWidth - 28,
            lineGap: 2,
          });

        guideY += 102;
      });

      // =========================================================================
      // STAMP FOOTERS ON ALL PAGES (lineBreak: false prevents stray blank pages)
      // =========================================================================
      const pageRange = doc.bufferedPageRange();
      const totalPages = pageRange.count;

      for (let i = 0; i < totalPages; i++) {
        doc.switchToPage(pageRange.start + i);
        const savedBottomMargin = doc.page.margins.bottom;
        doc.page.margins.bottom = 0;

        const footerY = doc.page.height - 30;

        doc
          .moveTo(48, footerY - 6)
          .lineTo(pageWidth - 48, footerY - 6)
          .lineWidth(0.5)
          .strokeColor(COLORS.borderLight)
          .stroke();

        doc
          .font(fonts.regular)
          .fontSize(8)
          .fillColor(COLORS.mutedText)
          .text(
            `FIFO Wealth OS • Thai Tax Compliance Report (Tax Year ${report.taxYear})`,
            48,
            footerY,
            { lineBreak: false }
          );

        doc
          .font(fonts.bold)
          .fontSize(8)
          .fillColor(COLORS.navy)
          .text(`หน้า ${i + 1} / ${totalPages}`, 48, footerY, {
            width: contentWidth,
            align: 'right',
            lineBreak: false,
          });

        doc.page.margins.bottom = savedBottomMargin;
      }

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Generates and writes the Thai Tax Report PDF to `outputPath`, returning file metadata & page count.
 */
export async function generateTaxReportPDF(
  report: TaxReport,
  outputPath: string,
  options?: TaxReportPDFOptions
): Promise<TaxReportPDFResult> {
  const resolvedPath = path.resolve(outputPath);
  await fs.promises.mkdir(path.dirname(resolvedPath), { recursive: true });

  const pdfBuffer = await generateTaxReportPDFBuffer(report, options);
  await fs.promises.writeFile(resolvedPath, pdfBuffer);

  // Count rendered PDF pages accurately from PDF object catalog (/Type /Page excluding /Pages)
  const pdfLatin1 = pdfBuffer.toString('latin1');
  const pageMatches = pdfLatin1.match(/\/Type\s*\/Page\b(?!s)/g);
  const pageCount = pageMatches ? pageMatches.length : 0;

  return {
    filePath: resolvedPath,
    pageCount,
    sizeBytes: pdfBuffer.byteLength,
  };
}
