import {
  MockStripeService,
  normalizeBillingAmountTHB,
  signMockStripePayload,
} from './stripeService';

describe('MockStripeService — Open Beta billing adapter', () => {
  const service = new MockStripeService();

  it('creates a one-time donation Checkout session and Payment Intent without charging', async () => {
    const session = await service.createDonationCheckout({
      userId: 'user-qa',
      donationId: 'donation-qa',
      amountTHB: '12345678901234567890.005',
      message: 'Thank you',
    });

    expect(session.id).toMatch(/^cs_mock_/);
    expect(session.paymentIntentId).toMatch(/^pi_mock_/);
    expect(session.mode).toBe('payment');
    expect(session.amountTHB).toBe('12345678901234567890.01');
    expect(session.currency).toBe('THB');
    expect(session.url).toContain('mock_checkout=ready');
    expect(session.metadata).toMatchObject({ donationId: 'donation-qa', userId: 'user-qa' });
  });

  it('creates a future subscription Checkout session with 40-digit Decimal pricing', async () => {
    const session = await service.createSubscriptionCheckout({
      userId: 'user-qa',
      tier: 'PRO',
      interval: 'month',
      amountTHB: '199.995',
    });

    expect(session.mode).toBe('subscription');
    expect(session.amountTHB).toBe('200.00');
    expect(session.metadata).toMatchObject({ tier: 'PRO', interval: 'month' });
    expect(session.paymentIntentId).toMatch(/^pi_mock_/);
  });

  it('creates a customer portal session for a known or new customer', async () => {
    const existing = await service.createCustomerPortalSession({
      userId: 'user-qa',
      email: 'qa@example.test',
      customerId: 'cus_existing',
    });
    expect(existing.customerId).toBe('cus_existing');
    expect(existing.url).toContain('mock_portal=ready');
  });

  it('canonicalizes billing money with Decimal.js precision 40 and rejects invalid values', () => {
    expect(normalizeBillingAmountTHB('0.005')).toBe('0.01');
    expect(normalizeBillingAmountTHB('999999999999999999.995')).toBe('1000000000000000000.00');
    expect(() => normalizeBillingAmountTHB('not-a-number')).toThrow();
    expect(() => normalizeBillingAmountTHB('-1')).toThrow();
  });

  it('verifies timestamped mock webhook signatures and rejects tampering', () => {
    const now = Math.floor(Date.now() / 1000);
    const payload = JSON.stringify({
      id: 'evt_mock_qa',
      type: 'checkout.session.completed',
      created: now,
      data: { object: { id: 'cs_mock_qa', metadata: { donationId: 'donation-qa' } } },
    });
    const signature = signMockStripePayload(payload, now);

    expect(service.constructWebhookEvent(payload, signature)).toMatchObject({
      id: 'evt_mock_qa',
      type: 'checkout.session.completed',
    });
    expect(() => service.constructWebhookEvent(`${payload} `, signature)).toThrow();
    expect(() => service.constructWebhookEvent(payload, signMockStripePayload(payload, now - 600))).toThrow();
  });
});
