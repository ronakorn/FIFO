import { getPrismaClient } from '../db/prisma';
import {
  getTierLimit,
  type LimitKey,
  type TierId,
} from '../config/pricing';
import { AppError } from '../middleware/errorHandler';

export interface UserEntitlementContext {
  tier: TierId;
  isBetaAllAccess: boolean;
}

export function isOpenBetaEntitlementBypass(): boolean {
  return process.env.OPEN_BETA_MODE === 'true' || process.env.OPEN_BETA_MODE === undefined;
}

function isKnownTier(value: string): value is TierId {
  return value === 'FREE' || value === 'PRO' || value === 'FAMILY' || value === 'ADVISOR';
}

/** Resolve a user's tier after beta override and current paid-period rules. */
export async function getUserEntitlementContext(
  userId: string
): Promise<UserEntitlementContext> {
  const prisma = getPrismaClient();
  const [user, subscription] = await Promise.all([
    prisma.user.findUnique({
      where: { id: userId },
      select: { isBetaAllAccess: true },
    }),
    prisma.subscription.findUnique({ where: { userId } }),
  ]);

  if (!user) {
    throw new AppError(401, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
  }

  const isBetaAllAccess = Boolean(user.isBetaAllAccess || subscription?.isBetaAllAccess);
  if (isBetaAllAccess) return { tier: 'ADVISOR', isBetaAllAccess: true };

  const hasCurrentPaidPeriod = Boolean(
    subscription?.status === 'CANCELED' &&
      subscription.currentPeriodEnd &&
      subscription.currentPeriodEnd.getTime() > Date.now()
  );
  const hasEntitledStatus = subscription?.status === 'ACTIVE' || hasCurrentPaidPeriod;

  if (subscription && hasEntitledStatus && isKnownTier(subscription.tier)) {
    return { tier: subscription.tier, isBetaAllAccess: false };
  }

  return { tier: 'FREE', isBetaAllAccess: false };
}

/**
 * Resolve a numeric plan limit. `-1` means unlimited; beta-wide and account-level
 * all-access overrides return `-1` so beta never enforces a quota.
 */
export async function getUserEntitlementLimit(
  userId: string,
  limit: LimitKey
): Promise<number> {
  if (isOpenBetaEntitlementBypass()) return -1;
  const context = await getUserEntitlementContext(userId);
  if (context.isBetaAllAccess) return -1;
  return getTierLimit(context.tier, limit);
}

/** Check an existing usage count plus the requested increment against a plan limit. */
export async function assertUserUsageWithinLimit(
  userId: string,
  limit: LimitKey,
  currentUsage: number,
  requestedUsage = 1,
  period?: string
): Promise<void> {
  const maxAllowed = await getUserEntitlementLimit(userId, limit);
  if (maxAllowed < 0 || currentUsage + requestedUsage <= maxAllowed) return;

  throw new AppError(
    403,
    'SUBSCRIPTION_LIMIT_REACHED',
    `The current plan allows up to ${maxAllowed} for ${limit}.`,
    {
      tier: (await getUserEntitlementContext(userId)).tier,
      limit,
      maxAllowed,
      currentUsage,
      requestedUsage,
      ...(period ? { period } : {}),
    }
  );
}

function transactionYear(date: string): number {
  const match = /^\s*(\d{4})/.exec(date);
  if (match?.[1]) return Number(match[1]);

  const parsed = new Date(date);
  if (!Number.isFinite(parsed.getTime())) {
    throw new AppError(400, 'INVALID_TRANSACTION_DATE', 'A transaction has an invalid date.');
  }
  return parsed.getUTCFullYear();
}

/**
 * Enforces the annual transaction quota across every portfolio owned by a user.
 * All imported sources share this check so a user cannot bypass it via CSV or sync.
 */
export async function assertTransactionDatesWithinAnnualLimit(
  userId: string,
  proposedDates: string[]
): Promise<void> {
  if (proposedDates.length === 0) return;
  const maxAllowed = await getUserEntitlementLimit(userId, 'maxTransactionsPerYear');
  if (maxAllowed < 0) return;

  const prisma = getPrismaClient();
  const portfolios = await prisma.portfolio.findMany({
    where: { userId },
    select: { id: true },
  });
  const portfolioIds = portfolios.map(({ id }) => id);
  const existingTransactions = portfolioIds.length
    ? await prisma.transaction.findMany({
        where: { portfolioId: { in: portfolioIds } },
        select: { date: true },
      })
    : [];

  const existingByYear = new Map<number, number>();
  const proposedByYear = new Map<number, number>();
  for (const row of existingTransactions) {
    const year = transactionYear(row.date);
    existingByYear.set(year, (existingByYear.get(year) ?? 0) + 1);
  }
  for (const date of proposedDates) {
    const year = transactionYear(date);
    proposedByYear.set(year, (proposedByYear.get(year) ?? 0) + 1);
  }

  for (const [year, requestedUsage] of proposedByYear) {
    const currentUsage = existingByYear.get(year) ?? 0;
    if (currentUsage + requestedUsage > maxAllowed) {
      throw new AppError(
        403,
        'SUBSCRIPTION_LIMIT_REACHED',
        `The current plan allows up to ${maxAllowed} transactions per year.`,
        {
          tier: (await getUserEntitlementContext(userId)).tier,
          limit: 'maxTransactionsPerYear',
          maxAllowed,
          currentUsage,
          requestedUsage,
          period: String(year),
        }
      );
    }
  }
}
