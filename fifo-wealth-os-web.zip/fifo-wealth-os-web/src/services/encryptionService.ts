import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH_BYTES = 12; // NIST SP 800-38D standard 96-bit IV for AES-GCM
const AUTH_TAG_LENGTH_BYTES = 16; // 128-bit authentication tag
const PAYLOAD_VERSION = 'v1';

const DEFAULT_TEST_FALLBACK_KEY =
  'fifo-wealth-os-aes-256-gcm-mock-encryption-key-2026';

export function getDefaultEncryptionKey(): string {
  return process.env['ENCRYPTION_KEY'] || DEFAULT_TEST_FALLBACK_KEY;
}

/**
 * Derives a deterministic 256-bit (32-byte) cryptographic key from `secretKey`.
 * Supports 64-char hex keys, raw 32-byte UTF-8 keys, or arbitrary passphrases via SHA-256.
 * Never logs `secretKey`.
 */
function deriveAes256Key(secretKey: string): Buffer {
  if (!secretKey || !secretKey.trim()) {
    throw new Error('Encryption secretKey must be a non-empty string.');
  }

  const trimmed = secretKey.trim();
  if (/^[0-9a-fA-F]{64}$/.test(trimmed)) {
    return Buffer.from(trimmed, 'hex');
  }

  const utf8Buf = Buffer.from(trimmed, 'utf8');
  if (utf8Buf.length === 32) {
    return utf8Buf;
  }

  return crypto.createHash('sha256').update(trimmed, 'utf8').digest();
}

/**
 * Encrypts sensitive plaintext (such as read-only broker Flex Query tokens)
 * using AES-256-GCM with a unique random 96-bit IV and 128-bit authentication tag.
 *
 * Output format: `v1:<ivHex>:<authTagHex>:<ciphertextHex>`
 * Security Rule: Never logs plaintext `data` or `secretKey`.
 */
export function encryptData(
  data: string,
  secretKey: string = getDefaultEncryptionKey()
): string {
  if (!data) {
    throw new Error('Cannot encrypt empty data.');
  }

  const key = deriveAes256Key(secretKey);
  const iv = crypto.randomBytes(IV_LENGTH_BYTES);

  const cipher = crypto.createCipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH_BYTES,
  });

  const encrypted = Buffer.concat([
    cipher.update(data, 'utf8'),
    cipher.final(),
  ]);
  const authTag = cipher.getAuthTag();

  return [
    PAYLOAD_VERSION,
    iv.toString('hex'),
    authTag.toString('hex'),
    encrypted.toString('hex'),
  ].join(':');
}

/**
 * Decrypts and authenticates an AES-256-GCM payload created by `encryptData`.
 * Throws an error if tampered, malformed, or decrypted with an invalid key.
 * Security Rule: Never logs decrypted credentials or `secretKey`.
 */
export function decryptData(
  encryptedData: string,
  secretKey: string = getDefaultEncryptionKey()
): string {
  if (!encryptedData || typeof encryptedData !== 'string') {
    throw new Error('Invalid encrypted payload.');
  }

  const parts = encryptedData.split(':');
  if (parts.length !== 4 || parts[0] !== PAYLOAD_VERSION) {
    throw new Error('Unsupported or malformed encrypted payload format.');
  }

  const [, ivHex, authTagHex, cipherHex] = parts;
  if (!ivHex || !authTagHex || cipherHex === undefined) {
    throw new Error('Malformed encrypted payload segments.');
  }

  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  const ciphertext = Buffer.from(cipherHex, 'hex');

  if (
    iv.length !== IV_LENGTH_BYTES ||
    authTag.length !== AUTH_TAG_LENGTH_BYTES
  ) {
    throw new Error('Invalid IV or GCM authentication tag length.');
  }

  const key = deriveAes256Key(secretKey);
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH_BYTES,
  });
  decipher.setAuthTag(authTag);

  try {
    const decrypted = Buffer.concat([
      decipher.update(ciphertext),
      decipher.final(),
    ]);
    return decrypted.toString('utf8');
  } catch {
    throw new Error(
      'Failed to authenticate and decrypt broker credentials (AES-256-GCM integrity check failed).'
    );
  }
}
