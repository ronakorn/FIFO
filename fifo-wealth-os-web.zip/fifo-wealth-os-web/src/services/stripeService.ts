import { createHmac, randomUUID, timingSafeEqual } from 'crypto';
import Decimal from 'decimal.js';
import type { TierId } from '../config/pricing';

/** All billing amounts are parsed and rounded with a private 40-digit Decimal context. */
export const BillingDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type SubscriptionTier = TierId;
export type StripeCheckoutMode = 'payment' | 'subscription';
export type SubscriptionInterval = 'month' | 'year';

export interface StripeCheckoutSession {
  id: string;
  url: string;
  mode: StripeCheckoutMode;
  amountTHB: string;
  currency: 'THB';
  customerId: string;
  paymentIntentId: string | null;
  metadata: Record<string, string>;
}

export interface StripeCustomerPortalSession {
  id: string;
  url: string;
  customerId: string;
}

export interface StripeWebhookEvent {
  id: string;
  type: string;
  created: number;
  data: {
    object: Record<string, unknown>;
  };
}

export interface DonationCheckoutInput {
  userId: string;
  donationId: string;
  amountTHB: string;
  customerId?: string;
  message?: string;
}

export interface SubscriptionCheckoutInput {
  userId: string;
  tier: Exclude<SubscriptionTier, 'FREE'>;
  interval: SubscriptionInterval;
  /** Final quoted amount. This mock service never charges it. */
  amountTHB: string;
  /** Catalog snapshot fields for future provider metadata; optional for backwards compatibility. */
  baseAmountTHB?: string;
  stripePriceId?: string;
  discountPercentage?: number;
  earlyBirdValidUntil?: string;
  customerId?: string;
}

export interface CustomerPortalInput {
  userId: string;
  email: string;
  customerId?: string;
}

/**
 * Provider boundary for Stripe Checkout, Customer Portal, and signed webhooks.
 * A real SDK adapter can replace MockStripeService in this file without changing
 * route or UI contracts.
 */
export interface StripeService {
  createDonationCheckout(input: DonationCheckoutInput): Promise<StripeCheckoutSession>;
  createSubscriptionCheckout(
    input: SubscriptionCheckoutInput
  ): Promise<StripeCheckoutSession>;
  createCustomerPortalSession(
    input: CustomerPortalInput
  ): Promise<StripeCustomerPortalSession>;
  constructWebhookEvent(
    payload: Buffer | string,
    signature: string
  ): StripeWebhookEvent;
}

/** Canonical THB amount formatter used by donation and future subscription pricing. */
export function normalizeBillingAmountTHB(amountTHB: string): string {
  let amount: Decimal;
  try {
    amount = new BillingDecimal(amountTHB);
  } catch {
    throw new Error('Billing amount must be a valid decimal string.');
  }

  if (!amount.isFinite() || amount.isNegative()) {
    throw new Error('Billing amount must be a finite, non-negative value.');
  }

  return amount.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
}

function getMockWebhookSecret(): string {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('Mock webhook verification is disabled in production; install the real Stripe adapter.');
  }
  return process.env.STRIPE_WEBHOOK_SECRET ?? 'local-mock-stripe-webhook-secret';
}

/** Test/dev helper that emits the timestamped HMAC format checked by the mock adapter. */
export function signMockStripePayload(
  payload: Buffer | string,
  timestamp = Math.floor(Date.now() / 1000)
): string {
  const rawPayload = Buffer.isBuffer(payload) ? payload : Buffer.from(payload, 'utf8');
  const digest = createHmac('sha256', getMockWebhookSecret())
    .update(`${timestamp}.`)
    .update(rawPayload)
    .digest('hex');
  return `t=${timestamp},v1=${digest}`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Safe, deterministic-contract mock. It never contacts Stripe and never charges a card.
 * The checkout URL is intentionally query-relative so it remains on the active locale.
 */
export class MockStripeService implements StripeService {
  async createDonationCheckout(
    input: DonationCheckoutInput
  ): Promise<StripeCheckoutSession> {
    const amountTHB = normalizeBillingAmountTHB(input.amountTHB);
    const id = `cs_mock_${randomUUID().replace(/-/g, '')}`;
    const customerId =
      input.customerId ?? `cus_mock_${randomUUID().replace(/-/g, '')}`;
    const paymentIntentId = `pi_mock_${randomUUID().replace(/-/g, '')}`;
    const params = new URLSearchParams({ mock_checkout: 'ready', session_id: id });

    return {
      id,
      url: `?${params.toString()}`,
      mode: 'payment',
      amountTHB,
      currency: 'THB',
      customerId,
      paymentIntentId,
      metadata: {
        donationId: input.donationId,
        userId: input.userId,
        amountTHB,
        ...(input.message ? { message: input.message } : {}),
      },
    };
  }

  async createSubscriptionCheckout(
    input: SubscriptionCheckoutInput
  ): Promise<StripeCheckoutSession> {
    const amountTHB = normalizeBillingAmountTHB(input.amountTHB);
    const id = `cs_mock_${randomUUID().replace(/-/g, '')}`;
    const customerId =
      input.customerId ?? `cus_mock_${randomUUID().replace(/-/g, '')}`;
    const paymentIntentId = `pi_mock_${randomUUID().replace(/-/g, '')}`;
    const params = new URLSearchParams({ mock_checkout: 'ready', session_id: id });

    return {
      id,
      url: `?${params.toString()}`,
      mode: 'subscription',
      amountTHB,
      currency: 'THB',
      customerId,
      paymentIntentId,
      metadata: {
        userId: input.userId,
        tier: input.tier,
        interval: input.interval,
        amountTHB,
        ...(input.baseAmountTHB !== undefined
          ? { baseAmountTHB: normalizeBillingAmountTHB(input.baseAmountTHB) }
          : {}),
        ...(input.stripePriceId ? { stripePriceId: input.stripePriceId } : {}),
        ...(input.discountPercentage !== undefined
          ? { discountPercentage: String(input.discountPercentage) }
          : {}),
        ...(input.earlyBirdValidUntil
          ? { earlyBirdValidUntil: input.earlyBirdValidUntil }
          : {}),
      },
    };
  }

  async createCustomerPortalSession(
    input: CustomerPortalInput
  ): Promise<StripeCustomerPortalSession> {
    const id = `bps_mock_${randomUUID().replace(/-/g, '')}`;
    const customerId =
      input.customerId ?? `cus_mock_${randomUUID().replace(/-/g, '')}`;
    const params = new URLSearchParams({ mock_portal: 'ready', session_id: id });

    return {
      id,
      url: `?${params.toString()}`,
      customerId,
    };
  }

  constructWebhookEvent(
    payload: Buffer | string,
    signature: string
  ): StripeWebhookEvent {
    const rawPayload = Buffer.isBuffer(payload) ? payload : Buffer.from(payload, 'utf8');
    const signatureParts = new Map(
      signature
        .split(',')
        .map((part) => part.trim().split('=', 2) as [string, string])
    );
    const timestampText = signatureParts.get('t');
    const providedHex = signatureParts.get('v1');
    const timestamp = Number(timestampText);

    if (
      !timestampText ||
      !providedHex ||
      !Number.isInteger(timestamp) ||
      Math.abs(Math.floor(Date.now() / 1000) - timestamp) > 300
    ) {
      throw new Error('Invalid or expired mock Stripe signature.');
    }

    const expectedHex = createHmac('sha256', getMockWebhookSecret())
      .update(`${timestamp}.`)
      .update(rawPayload)
      .digest('hex');
    const provided = Buffer.from(providedHex, 'hex');
    const expected = Buffer.from(expectedHex, 'hex');

    if (provided.length !== expected.length || !timingSafeEqual(provided, expected)) {
      throw new Error('Stripe webhook signature verification failed.');
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(rawPayload.toString('utf8')) as unknown;
    } catch {
      throw new Error('Stripe webhook payload is not valid JSON.');
    }

    if (
      !isRecord(parsed) ||
      typeof parsed.id !== 'string' ||
      typeof parsed.type !== 'string' ||
      typeof parsed.created !== 'number' ||
      !isRecord(parsed.data) ||
      !isRecord(parsed.data.object)
    ) {
      throw new Error('Stripe webhook payload has an invalid event shape.');
    }

    return {
      id: parsed.id,
      type: parsed.type,
      created: parsed.created,
      data: { object: parsed.data.object },
    };
  }
}

/** Replace this binding with the real SDK adapter when Stripe credentials are approved. */
export const stripeService: StripeService = new MockStripeService();
