import type { GoldTransactionRecord } from '@prisma/client';
import Decimal from 'decimal.js';
import type { MultiAssetTransaction } from '../../types/multiAsset';

const GoldDecimal = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

/**
 * Read-only adapter for Gold Module rows. It lets the new metals dashboard aggregate
 * existing gold positions without rewriting or mutating the legacy Gold ledger.
 */
export function mapLegacyGoldRecordToCommodity(
  record: GoldTransactionRecord,
): MultiAssetTransaction {
  const currency = record.assetSubclass === 'PHYSICAL_GOLD' ? 'THB' : 'USD';
  const fxRate = currency === 'THB' ? '1.00000000' : record.fxRateAtPurchase;
  const transactionValue = record.totalCost;
  const valueTHB = currency === 'THB'
    ? transactionValue
    : new GoldDecimal(transactionValue).times(fxRate).toFixed(2, Decimal.ROUND_HALF_UP);

  return {
    id: `legacy-gold-${record.id}`,
    portfolioId: record.portfolioId,
    date: record.date.slice(0, 10),
    symbol: record.symbol,
    assetClass: 'COMMODITY',
    type: record.type as 'BUY' | 'SELL',
    qty: 1,
    price: record.spotPricePerUnit,
    gross: transactionValue,
    comm: record.commission,
    vat: '0.00',
    net: transactionValue,
    originalCurrency: currency,
    originalNet: transactionValue,
    fxRate,
    netTHB: valueTHB,
    exchange: 'LEGACY_GOLD_MODULE',
    createdAt: record.createdAt,
    commodityExtension: {
      weight: record.weight,
      weightUnit: record.weightUnit as 'THAI_BAHT' | 'GRAM' | 'TROY_OUNCE',
      purity: record.purity,
      storageFee: '0.00',
      premium: record.premiumPerUnit,
      spotPricePerUnit: record.spotPricePerUnit,
    },
  };
}
