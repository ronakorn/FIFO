import Decimal from 'decimal.js';
import { FOREX_RULES } from '../../config/multiAssetRules';
import type { ForexExtension, MultiAssetTransaction } from '../../types/multiAsset';
import { asDecimal, compareTransactions, MultiAssetDecimal, roundMoney, roundQuantity } from './common';

export interface ForexCurrencyBalance {
  currency: string;
  amount: string;
  costBasisTHB: string;
  averageCostRateTHB: string;
  currentRateTHB: string;
  currentValueTHB: string;
  unrealizedFxGainLossTHB: string;
}

export interface RealizedFxEvent {
  transactionId: string;
  currency: string;
  amountDisposed: string;
  proceedsTHB: string;
  costBasisTHB: string;
  averageCostBasisTHB: string;
  realizedFxGainLossTHB: string;
}

interface InternalRealizedFxEvent {
  transactionId: string;
  currency: string;
  amountDisposed: Decimal;
  proceedsTHB: Decimal;
  costBasisTHB: Decimal;
  realizedFxGainLossTHB: Decimal;
}

export interface ForexPortfolioSummary {
  balances: ForexCurrencyBalance[];
  realizedEvents: RealizedFxEvent[];
  totalCashValueTHB: string;
  totalCostBasisTHB: string;
  totalRealizedFxGainLossTHB: string;
  totalUnrealizedFxGainLossTHB: string;
}

interface ForexLot {
  transactionId: string;
  currency: string;
  acquiredAmount: Decimal;
  remainingAmount: Decimal;
  costPerUnitTHB: Decimal;
}

function getForexExtension(transaction: MultiAssetTransaction): ForexExtension {
  if (!transaction.forexExtension) {
    throw new Error(`Forex transaction ${transaction.id} is missing forexExtension.`);
  }
  return transaction.forexExtension;
}

function transactionRateTHB(transaction: MultiAssetTransaction): Decimal {
  if (transaction.fxRate) return asDecimal(transaction.fxRate, 'fxRate');
  const extension = getForexExtension(transaction);
  if (extension.toCurrency.toUpperCase() === 'THB') {
    return asDecimal(extension.fxRateAtTransaction, 'fxRateAtTransaction');
  }
  throw new Error(`A THB conversion rate is required for forex transaction ${transaction.id}.`);
}

function sourceAmount(transaction: MultiAssetTransaction): Decimal {
  return asDecimal(transaction.qty, 'qty');
}

function pushLot(
  lotsByCurrency: Map<string, ForexLot[]>,
  transactionId: string,
  currency: string,
  amount: Decimal,
  costBasisTHB: Decimal,
): void {
  if (!amount.isPositive()) throw new Error(`Forex lot amount must be positive for ${transactionId}.`);
  const normalizedCurrency = currency.toUpperCase();
  const lots = lotsByCurrency.get(normalizedCurrency) ?? [];
  lots.push({
    transactionId,
    currency: normalizedCurrency,
    acquiredAmount: amount,
    remainingAmount: amount,
    costPerUnitTHB: costBasisTHB.dividedBy(amount),
  });
  lotsByCurrency.set(normalizedCurrency, lots);
}

function disposeLots(input: {
  transaction: MultiAssetTransaction;
  currency: string;
  amount: Decimal;
  proceedsTHB: Decimal;
  lotsByCurrency: Map<string, ForexLot[]>;
}): InternalRealizedFxEvent {
  const normalizedCurrency = input.currency.toUpperCase();
  const lots = input.lotsByCurrency.get(normalizedCurrency) ?? [];
  const available = lots.reduce((sum, lot) => sum.plus(lot.remainingAmount), new MultiAssetDecimal(0));
  if (input.amount.gt(available)) {
    throw new Error(
      `Forex ${normalizedCurrency} disposal ${input.transaction.id} exceeds available balance (${roundQuantity(available)}).`,
    );
  }
  let remainingToDispose = input.amount;
  let totalCostBasis = new MultiAssetDecimal(0);

  for (const lot of lots) {
    if (!remainingToDispose.isPositive()) break;
    if (!lot.remainingAmount.isPositive()) continue;
    const disposed = MultiAssetDecimal.min(lot.remainingAmount, remainingToDispose);
    const cost = disposed.times(lot.costPerUnitTHB);
    totalCostBasis = totalCostBasis.plus(cost);
    lot.remainingAmount = lot.remainingAmount.minus(disposed);
    remainingToDispose = remainingToDispose.minus(disposed);
  }

  const gainLoss = input.proceedsTHB.minus(totalCostBasis);
  return {
    transactionId: input.transaction.id,
    currency: normalizedCurrency,
    amountDisposed: input.amount,
    proceedsTHB: input.proceedsTHB,
    costBasisTHB: totalCostBasis,
    realizedFxGainLossTHB: gainLoss,
  };
}

/**
 * Cash ledger conventions for the CDM:
 * - BUY: acquire `qty` units of forexExtension.fromCurrency; netTHB is the THB cost.
 * - SELL: dispose `qty` units of fromCurrency; netTHB is THB proceeds after fees.
 * - CONVERT: dispose `qty` units of fromCurrency; `gross` is units received in toCurrency;
 *   netTHB is the THB value of the source leg at the conversion timestamp.
 */
export function calculateForexCashLedger(
  transactions: readonly MultiAssetTransaction[],
): ForexPortfolioSummary {
  const forexTransactions = transactions
    .filter((transaction) => transaction.assetClass === 'FOREX')
    .sort(compareTransactions);
  const lotsByCurrency = new Map<string, ForexLot[]>();
  const latestRateByCurrency = new Map<string, Decimal>();
  const internalRealizedEvents: InternalRealizedFxEvent[] = [];

  latestRateByCurrency.set('THB', new MultiAssetDecimal(1));

  for (const transaction of forexTransactions) {
    const extension = getForexExtension(transaction);
    const fromCurrency = extension.fromCurrency.toUpperCase();
    const toCurrency = extension.toCurrency.toUpperCase();
    const amount = sourceAmount(transaction);
    if (!amount.isPositive()) throw new Error(`Forex amount must be positive for ${transaction.id}.`);
    const rateTHB = transactionRateTHB(transaction);
    if (!rateTHB.isPositive()) throw new Error(`Forex FX rate must be positive for ${transaction.id}.`);
    const valueTHB = transaction.netTHB !== null
      ? asDecimal(transaction.netTHB, 'netTHB')
      : amount.times(rateTHB);

    latestRateByCurrency.set(fromCurrency, rateTHB);

    if (transaction.type === 'BUY') {
      pushLot(lotsByCurrency, transaction.id, fromCurrency, amount, valueTHB);
      continue;
    }

    if (transaction.type === 'SELL') {
      internalRealizedEvents.push(disposeLots({
        transaction,
        currency: fromCurrency,
        amount,
        proceedsTHB: valueTHB,
        lotsByCurrency,
      }));
      continue;
    }

    if (transaction.type === 'CONVERT') {
      if (fromCurrency === toCurrency) {
        throw new Error(`Forex conversion ${transaction.id} must use two different currencies.`);
      }
      const targetAmount = asDecimal(transaction.gross, 'gross');
      if (!targetAmount.isPositive()) throw new Error(`Converted amount must be positive for ${transaction.id}.`);
      internalRealizedEvents.push(disposeLots({
        transaction,
        currency: fromCurrency,
        amount,
        proceedsTHB: valueTHB,
        lotsByCurrency,
      }));
      pushLot(lotsByCurrency, transaction.id, toCurrency, targetAmount, valueTHB);
      latestRateByCurrency.set(toCurrency, valueTHB.dividedBy(targetAmount));
    }
  }

  const realizedEvents: RealizedFxEvent[] = internalRealizedEvents.map((event) => ({
    transactionId: event.transactionId,
    currency: event.currency,
    amountDisposed: roundQuantity(event.amountDisposed),
    proceedsTHB: roundMoney(event.proceedsTHB),
    costBasisTHB: roundMoney(event.costBasisTHB),
    averageCostBasisTHB: event.costBasisTHB
      .dividedBy(event.amountDisposed)
      .toDecimalPlaces(8, Decimal.ROUND_HALF_UP)
      .toFixed(8),
    realizedFxGainLossTHB: roundMoney(event.realizedFxGainLossTHB),
  }));

  const balances: ForexCurrencyBalance[] = [];
  let totalCashValue = new MultiAssetDecimal(0);
  let totalCostBasis = new MultiAssetDecimal(0);
  let totalUnrealized = new MultiAssetDecimal(0);

  for (const [currency, lots] of lotsByCurrency) {
    const amount = lots.reduce((sum, lot) => sum.plus(lot.remainingAmount), new MultiAssetDecimal(0));
    const costBasis = lots.reduce((sum, lot) => sum.plus(lot.remainingAmount.times(lot.costPerUnitTHB)), new MultiAssetDecimal(0));
    const averageCostRate = amount.isPositive() ? costBasis.dividedBy(amount) : new MultiAssetDecimal(0);
    const currentRate = currency === 'THB'
      ? new MultiAssetDecimal(1)
      : latestRateByCurrency.get(currency) ?? averageCostRate;
    const currentValue = amount.times(currentRate);
    const unrealized = currentValue.minus(costBasis);

    balances.push({
      currency,
      amount: roundQuantity(amount),
      costBasisTHB: roundMoney(costBasis),
      averageCostRateTHB: averageCostRate.toDecimalPlaces(8, Decimal.ROUND_HALF_UP).toFixed(8),
      currentRateTHB: currentRate.toDecimalPlaces(8, Decimal.ROUND_HALF_UP).toFixed(8),
      currentValueTHB: roundMoney(currentValue),
      unrealizedFxGainLossTHB: roundMoney(unrealized),
    });
    totalCashValue = totalCashValue.plus(currentValue);
    totalCostBasis = totalCostBasis.plus(costBasis);
    totalUnrealized = totalUnrealized.plus(unrealized);
  }

  balances.sort((a, b) => a.currency.localeCompare(b.currency));
  const totalRealized = internalRealizedEvents.reduce(
    (sum, event) => sum.plus(event.realizedFxGainLossTHB),
    new MultiAssetDecimal(0),
  );

  return {
    balances,
    realizedEvents,
    totalCashValueTHB: roundMoney(totalCashValue),
    totalCostBasisTHB: roundMoney(totalCostBasis),
    totalRealizedFxGainLossTHB: roundMoney(totalRealized),
    totalUnrealizedFxGainLossTHB: roundMoney(totalUnrealized),
  };
}

export function calculateSimpleRealizedFxGainLoss(
  amount: string,
  fxRateAtPurchase: string,
  fxRateAtTransaction: string,
): string {
  return FOREX_RULES.calculateRealizedFxGainLoss(amount, fxRateAtPurchase, fxRateAtTransaction);
}
