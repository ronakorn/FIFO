import type { GoldTransactionRecord } from '@prisma/client';
import type { MultiAssetTransaction } from '../../types/multiAsset';
import { mapLegacyGoldRecordToCommodity } from './legacyGoldAdapter';
import {
  calculateBondAccruedInterest,
  calculateBondPortfolio,
  calculateBondYieldToMaturity,
  generateBondCouponSchedule,
} from './bondEngine';
import { calculateCommodityPortfolio, convertCommodityWeight } from './commodityEngine';
import { calculateForexCashLedger, calculateSimpleRealizedFxGainLoss } from './forexEngine';
import { calculateFundPortfolio, calculateFundTaxDeductionSummary, validateRMFAgeCondition } from './fundEngine';

function makeTransaction(overrides: Partial<MultiAssetTransaction> = {}): MultiAssetTransaction {
  return {
    id: 'tx-1',
    portfolioId: 'portfolio-1',
    date: '2026-01-01',
    symbol: 'TEST',
    assetClass: 'BOND',
    type: 'BUY',
    qty: 1,
    price: '1000.00',
    gross: '1000.00',
    comm: '0.00',
    vat: '0.00',
    net: '1000.00',
    originalCurrency: 'THB',
    originalNet: '1000.00',
    fxRate: '1.00',
    netTHB: '1000.00',
    createdAt: new Date('2026-01-01T00:00:00.000Z'),
    ...overrides,
  };
}

const bondTerms = {
  couponRate: '0.0500',
  paymentFrequency: 'SEMI_ANNUAL' as const,
  maturityDate: '2028-10-01',
  faceValue: '1000.00',
  accruedInterest: '0.00',
  issuer: 'Government of Thailand',
};

const fundTerms = {
  fundType: 'SSF' as const,
  holdingPeriodDays: 0,
  taxDeductible: true,
  dividendPolicy: 'CASH_PAYOUT' as const,
  navPerUnit: '10.00',
  purchaseDate: '2026-01-01',
};

const commodityTerms = {
  weight: '1.00',
  weightUnit: 'TROY_OUNCE' as const,
  purity: '99.9',
  storageFee: '0.00',
  premium: '0.00',
  spotPricePerUnit: '6000.00',
};

const forexTerms = {
  fromCurrency: 'USD',
  toCurrency: 'THB',
  fxRateAtTransaction: '35.00',
  realizedFxGainLoss: '0.00',
};

describe('Multi-asset Bond engine', () => {
  it('generates coupon dates and applies configured 15% withholding', () => {
    const schedule = generateBondCouponSchedule({
      faceValue: '100000.00',
      couponRate: '0.05',
      paymentFrequency: 'SEMI_ANNUAL',
      maturityDate: '2025-10-01',
      fromDate: '2024-10-02',
    });

    expect(schedule).toHaveLength(2);
    expect(schedule[0]).toEqual({
      date: '2025-04-01',
      grossTHB: '2500.00',
      withholdingTaxTHB: '375.00',
      netTHB: '2125.00',
    });
    expect(schedule[1]?.date).toBe('2025-10-01');
  });

  it('calculates ACT/365 accrued interest from the previous coupon date', () => {
    const result = calculateBondAccruedInterest({
      ...bondTerms,
      faceValue: '100000.00',
    }, '2025-01-01');
    expect(result.previousCouponDate).toBe('2024-10-01');
    expect(result.nextCouponDate).toBe('2025-04-01');
    expect(result.daysSinceLastCoupon).toBe(92);
    expect(result.amountPerBondTHB).toBe('1260.27');
  });

  it('reports realized coupon income and withholding tax in the portfolio summary', () => {
    const coupon = makeTransaction({
      id: 'bond-coupon',
      assetClass: 'BOND',
      type: 'COUPON',
      symbol: 'BOND-TH-2028',
      date: '2026-07-01',
      qty: 1,
      price: '100.00',
      gross: '100.00',
      comm: '2.00',
      net: '83.00',
      originalNet: '83.00',
      netTHB: '83.00',
      bondExtension: bondTerms,
    });
    const summary = calculateBondPortfolio([coupon], '2026-07-02');
    expect(summary.couponIncomeTHB).toBe('83.00');
    expect(summary.couponWithholdingTaxTHB).toBe('15.00');
  });

  it('returns zero accrued interest after bond maturity', () => {
    const result = calculateBondAccruedInterest({
      ...bondTerms,
      maturityDate: '2025-10-01',
    }, '2025-11-01');
    expect(result.amountPerBondTHB).toBe('0.00');
    expect(result.nextCouponDate).toBeNull();
  });

  it('solves par yield-to-maturity close to the coupon rate', () => {
    const ytm = calculateBondYieldToMaturity({
      faceValue: '1000.00',
      couponRate: '0.05',
      paymentFrequency: 'SEMI_ANNUAL',
      maturityDate: '2028-10-01',
      settlementDate: '2026-10-01',
      cleanPrice: '1000.00',
      accruedInterest: '0.00',
    });
    expect(ytm).not.toBeNull();
    expect(Number(ytm)).toBeCloseTo(0.05, 3);
  });

  it('matches secondary-market sells FIFO and reports realized/unrealized G/L', () => {
    const buy = makeTransaction({
      id: 'bond-buy',
      symbol: 'BOND-TH-2028',
      qty: 10,
      price: '1000.00',
      gross: '10000.00',
      net: '10000.00',
      originalNet: '10000.00',
      netTHB: '10000.00',
      bondExtension: bondTerms,
    });
    const sell = makeTransaction({
      id: 'bond-sell',
      date: '2026-01-02',
      symbol: 'BOND-TH-2028',
      type: 'SELL',
      qty: 4,
      price: '1200.00',
      gross: '4800.00',
      net: '4800.00',
      originalNet: '4800.00',
      netTHB: '4800.00',
      bondExtension: bondTerms,
    });
    const summary = calculateBondPortfolio([buy, sell], '2026-01-03');
    expect(summary.totalRealizedGLTHB).toBe('800.00');
    expect(summary.totalCostBasisTHB).toBe('6000.00');
    expect(summary.totalMarketValueTHB).toBe('7200.00');
    expect(summary.totalUnrealizedGLTHB).toBe('1200.00');
    expect(summary.lots[0]?.status).toBe('Partial');
  });
});

describe('Multi-asset Fund engine', () => {
  it('calculates SSF deduction contribution and applies the configured limit', () => {
    const transaction = makeTransaction({
      id: 'ssf-buy',
      assetClass: 'FUND',
      symbol: 'SSF-TH',
      qty: 300,
      price: '1000.00',
      gross: '300000.00',
      net: '300000.00',
      originalNet: '300000.00',
      netTHB: '300000.00',
      fundExtension: { ...fundTerms, navPerUnit: '1000.00' },
    });
    const summary = calculateFundTaxDeductionSummary({ transactions: [transaction], taxYear: 2026 });
    expect(summary.contributionsTHB.SSF).toBe('300000.00');
    expect(summary.eligibleDeductionTHB.SSF).toBe('200000.00');
    expect(summary.remainingLimitTHB.SSF).toBe('0.00');
  });

  it('applies the RMF 30% income cap and reports holding-period status', () => {
    const transaction = makeTransaction({
      id: 'rmf-buy',
      assetClass: 'FUND',
      symbol: 'RMF-TH',
      qty: 400,
      price: '1000.00',
      gross: '400000.00',
      net: '400000.00',
      originalNet: '400000.00',
      netTHB: '400000.00',
      fundExtension: {
        ...fundTerms,
        fundType: 'RMF',
        purchaseDate: '2020-01-01',
        navPerUnit: '1000.00',
      },
    });
    const tax = calculateFundTaxDeductionSummary({
      transactions: [transaction],
      taxYear: 2026,
      annualIncomeTHB: '1000000.00',
    });
    const holding = calculateFundPortfolio([transaction], { asOfDate: '2026-01-01', taxYear: 2026 });
    expect(tax.eligibleDeductionTHB.RMF).toBe('300000.00');
    expect(holding.holdingLots[0]?.holdingPeriodComplete).toBe(true);
    expect(holding.holdingLots[0]?.holdingPeriodDays).toBe(2192);
  });

  it('reinvests DRIP dividends into fractional units', () => {
    const buy = makeTransaction({
      id: 'fund-buy',
      assetClass: 'FUND',
      symbol: 'ETF-TH',
      qty: 10,
      price: '10.00',
      gross: '100.00',
      net: '100.00',
      originalNet: '100.00',
      netTHB: '100.00',
      fundExtension: { ...fundTerms, fundType: 'GENERAL', taxDeductible: false, dividendPolicy: 'DRIP' },
    });
    const dividend = makeTransaction({
      id: 'fund-dividend',
      date: '2026-01-02',
      symbol: 'ETF-TH',
      assetClass: 'FUND',
      type: 'DIVIDEND',
      qty: 10,
      price: '1.00',
      gross: '10.00',
      net: '10.00',
      originalNet: '10.00',
      netTHB: '10.00',
      fundExtension: { ...fundTerms, fundType: 'GENERAL', taxDeductible: false, dividendPolicy: 'DRIP' },
    });
    const summary = calculateFundPortfolio([buy, dividend], { asOfDate: '2026-01-03', taxYear: 2026 });
    expect(summary.positions[0]?.quantity).toBe('11.00000000');
    expect(summary.dripReinvestedUnits).toBe('1.00000000');
    expect(summary.cashDividendsTHB).toBe('0.00');
  });
});

describe('RMF age-55 condition', () => {
  it('fails closed when date of birth is missing', () => {
    expect(validateRMFAgeCondition(null, new Date('2026-10-27T00:00:00.000Z'))).toEqual({
      isEligible: false,
      ageAtSale: 0,
    });
  });

  it('requires age 55 on or before the redemption date', () => {
    const dateOfBirth = new Date('1971-07-12T00:00:00.000Z');
    expect(validateRMFAgeCondition(dateOfBirth, new Date('2026-07-11T00:00:00.000Z'))).toEqual({
      isEligible: false,
      ageAtSale: 54,
    });
    expect(validateRMFAgeCondition(dateOfBirth, new Date('2026-07-12T00:00:00.000Z'))).toEqual({
      isEligible: true,
      ageAtSale: 55,
    });
  });

  it('handles a 29 February birthday as reaching age 55 on 1 March in a non-leap year', () => {
    const dateOfBirth = new Date('2000-02-29T00:00:00.000Z');
    expect(validateRMFAgeCondition(dateOfBirth, new Date('2055-02-28T00:00:00.000Z'))).toEqual({
      isEligible: false,
      ageAtSale: 54,
    });
    expect(validateRMFAgeCondition(dateOfBirth, new Date('2055-03-01T00:00:00.000Z'))).toEqual({
      isEligible: true,
      ageAtSale: 55,
    });
  });

  it('exposes as-of status and checks eligibility on the actual RMF sale date', () => {
    const rmfExtension = {
      ...fundTerms,
      fundType: 'RMF' as const,
      purchaseDate: '2020-01-01',
      navPerUnit: '1000.00',
    };
    const buy = makeTransaction({
      id: 'rmf-age-buy',
      assetClass: 'FUND',
      symbol: 'RMF-AGE',
      qty: 2,
      price: '1000.00',
      gross: '2000.00',
      net: '2000.00',
      originalNet: '2000.00',
      netTHB: '2000.00',
      fundExtension: rmfExtension,
    });
    const sale = makeTransaction({
      id: 'rmf-age-sale',
      date: '2026-07-11',
      assetClass: 'FUND',
      type: 'SELL',
      symbol: 'RMF-AGE',
      qty: 1,
      price: '1100.00',
      gross: '1100.00',
      net: '1100.00',
      originalNet: '1100.00',
      netTHB: '1100.00',
      fundExtension: rmfExtension,
    });
    const summary = calculateFundPortfolio([buy, sale], {
      asOfDate: '2026-07-12',
      taxYear: 2026,
      dateOfBirth: new Date('1971-07-12T00:00:00.000Z'),
    });
    expect(summary.rmfAgeCondition).toEqual({
      ageAtAsOf: 55,
      isEligible: true,
      ageEligibleDate: '2026-07-12',
    });
    expect(summary.redemptionChecks[0]).toMatchObject({
      ageAtSale: 54,
      ageConditionMet: false,
      ageEligibleDate: '2026-07-12',
    });
  });
});

describe('Multi-asset Commodity engine', () => {
  it('converts Troy ounces and grams using decimal-safe constants', () => {
    expect(convertCommodityWeight('1', 'TROY_OUNCE', 'GRAM')).toBe('31.10347680');
    expect(convertCommodityWeight('1', 'KILOGRAM', 'GRAM')).toBe('1000.00000000');
    expect(convertCommodityWeight('2', 'THAI_BAHT', 'GRAM')).toBe('30.48800000');
  });

  it('adapts legacy XAU spot records read-only with Decimal FX conversion', () => {
    const legacyRecord = {
      id: 'legacy-xau-1',
      portfolioId: 'portfolio-1',
      date: '2026-06-12',
      symbol: 'XAUUSD',
      assetSubclass: 'XAU_SPOT',
      weight: '1.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.99',
      spotPricePerUnit: '2000.00',
      premiumPerUnit: '1.50',
      commission: '8.00',
      totalCost: '2009.50',
      fxRateAtPurchase: '34.40',
      type: 'BUY',
      createdAt: new Date('2026-06-12T00:00:00.000Z'),
    } as GoldTransactionRecord;
    const transaction = mapLegacyGoldRecordToCommodity(legacyRecord);
    expect(transaction.id).toBe('legacy-gold-legacy-xau-1');
    expect(transaction.netTHB).toBe('69126.80');
    expect(transaction.commodityExtension?.weightUnit).toBe('TROY_OUNCE');
  });

  it('builds a Silver multi-metal dashboard row and FIFO secondary-sale result', () => {
    const buy = makeTransaction({
      id: 'silver-buy',
      assetClass: 'COMMODITY',
      symbol: 'SILVER-999',
      qty: 2,
      price: '5000.00',
      gross: '10000.00',
      net: '10000.00',
      originalNet: '10000.00',
      netTHB: '10000.00',
      commodityExtension: commodityTerms,
    });
    const sell = makeTransaction({
      id: 'silver-sell',
      date: '2026-01-02',
      assetClass: 'COMMODITY',
      type: 'SELL',
      symbol: 'SILVER-999',
      qty: 1,
      price: '6500.00',
      gross: '6500.00',
      net: '6500.00',
      originalNet: '6500.00',
      netTHB: '6500.00',
      commodityExtension: { ...commodityTerms, spotPricePerUnit: '6000.00' },
    });
    const summary = calculateCommodityPortfolio([buy, sell], '2026-01-03');
    expect(summary.totalRealizedGLTHB).toBe('1500.00');
    expect(summary.totalWeightGrams).toBe('31.10347680');
    expect(summary.multiMetalDashboard[0]?.metal).toBe('SILVER');
    expect(summary.positions[0]?.fineWeightGrams).toBe('31.07237332');
  });
});

describe('Multi-asset Forex cash engine', () => {
  it('tracks multi-currency balances and FIFO realized FX gain/loss', () => {
    const buy = makeTransaction({
      id: 'usd-buy',
      assetClass: 'FOREX',
      type: 'BUY',
      symbol: 'CASH-USD',
      qty: 1000,
      price: '35.00',
      gross: '35000.00',
      net: '35000.00',
      originalCurrency: 'USD',
      originalNet: '1000.00',
      fxRate: '35.00',
      netTHB: '35000.00',
      forexExtension: forexTerms,
    });
    const sell = makeTransaction({
      id: 'usd-sell',
      date: '2026-01-02',
      assetClass: 'FOREX',
      type: 'SELL',
      symbol: 'CASH-USD',
      qty: 400,
      price: '36.00',
      gross: '14400.00',
      net: '14400.00',
      originalCurrency: 'USD',
      originalNet: '400.00',
      fxRate: '36.00',
      netTHB: '14400.00',
      forexExtension: { ...forexTerms, fxRateAtTransaction: '36.00' },
    });
    const summary = calculateForexCashLedger([buy, sell]);
    expect(summary.realizedEvents[0]?.realizedFxGainLossTHB).toBe('400.00');
    expect(summary.realizedEvents[0]?.averageCostBasisTHB).toBe('35.00000000');
    expect(summary.balances[0]?.amount).toBe('600.00000000');
    expect(summary.balances[0]?.costBasisTHB).toBe('21000.00');
    expect(summary.balances[0]?.unrealizedFxGainLossTHB).toBe('600.00');
    expect(calculateSimpleRealizedFxGainLoss('1000', '35', '36')).toBe('1000.00');
  });

  it('aggregates realized FX from unrounded Decimal events before output rounding', () => {
    const buy = makeTransaction({
      id: 'usd-precision-buy', assetClass: 'FOREX', type: 'BUY', symbol: 'CASH-USD-PRECISION', qty: 3,
      price: '0.003333333333333333', gross: '0.01', net: '0.01', originalCurrency: 'USD', originalNet: '3.00',
      fxRate: '0.003333333333333333', netTHB: '0.01', forexExtension: forexTerms,
    });
    const firstSale = makeTransaction({
      id: 'usd-precision-sell-1', date: '2026-01-02', assetClass: 'FOREX', type: 'SELL', symbol: 'CASH-USD-PRECISION', qty: 1,
      price: '0.007333333333333333', gross: '0.01', net: '0.01', originalCurrency: 'USD', originalNet: '1.00',
      fxRate: '0.007333333333333333', netTHB: '0.007333333333333333', forexExtension: forexTerms,
    });
    const secondSale = makeTransaction({
      ...firstSale,
      id: 'usd-precision-sell-2',
      date: '2026-01-03',
    });
    const summary = calculateForexCashLedger([buy, firstSale, secondSale]);
    expect(summary.realizedEvents.map((event) => event.realizedFxGainLossTHB)).toEqual(['0.00', '0.00']);
    expect(summary.totalRealizedFxGainLossTHB).toBe('0.01');
  });

  it('uses conversion legs to dispose source currency and create destination cash', () => {
    const buy = makeTransaction({
      id: 'usd-buy', assetClass: 'FOREX', type: 'BUY', symbol: 'CASH-USD', qty: 100,
      price: '35.00', gross: '3500.00', net: '3500.00', originalCurrency: 'USD', originalNet: '100.00',
      fxRate: '35.00', netTHB: '3500.00', forexExtension: forexTerms,
    });
    const conversion = makeTransaction({
      id: 'usd-thb-convert', date: '2026-01-02', assetClass: 'FOREX', type: 'CONVERT', symbol: 'USD-THB', qty: 100,
      price: '36.00', gross: '3600.00', net: '3600.00', originalCurrency: 'USD', originalNet: '100.00',
      fxRate: '36.00', netTHB: '3600.00', forexExtension: { ...forexTerms, fxRateAtTransaction: '36.00' },
    });
    const summary = calculateForexCashLedger([buy, conversion]);
    expect(summary.realizedEvents[0]?.realizedFxGainLossTHB).toBe('100.00');
    expect(summary.balances.find((row) => row.currency === 'USD')?.amount).toBe('0.00000000');
    expect(summary.balances.find((row) => row.currency === 'THB')?.amount).toBe('3600.00000000');
  });

  it('rejects disposals that exceed the available currency balance', () => {
    const sell = makeTransaction({
      id: 'usd-sell-only', assetClass: 'FOREX', type: 'SELL', symbol: 'CASH-USD', qty: 10,
      price: '35.00', gross: '350.00', net: '350.00', originalCurrency: 'USD', originalNet: '10.00',
      fxRate: '35.00', netTHB: '350.00', forexExtension: forexTerms,
    });
    expect(() => calculateForexCashLedger([sell])).toThrow('exceeds available balance');
  });
});
