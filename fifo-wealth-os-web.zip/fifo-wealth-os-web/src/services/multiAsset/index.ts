import type { MultiAssetPortfolioSummary } from '@fifo/types/multiAssetSummary';
import type { MultiAssetTransaction } from '../../types/multiAsset';
import { calculateBondPortfolio } from './bondEngine';
import { calculateCommodityPortfolio } from './commodityEngine';
import { calculateForexCashLedger } from './forexEngine';
import { calculateFundPortfolio } from './fundEngine';

export type { MultiAssetPortfolioSummary } from '@fifo/types/multiAssetSummary';

export function calculateMultiAssetPortfolioSummary(
  transactions: readonly MultiAssetTransaction[],
  options: {
    asOfDate?: string;
    taxYear?: number;
    annualIncomeTHB?: string | null;
    dateOfBirth?: Date | null;
  } = {},
): MultiAssetPortfolioSummary {
  const asOfDate = options.asOfDate ?? new Date().toISOString().slice(0, 10);
  const taxYear = options.taxYear ?? Number(asOfDate.slice(0, 4));
  return {
    asOfDate,
    taxYear,
    bonds: calculateBondPortfolio(transactions, asOfDate),
    funds: calculateFundPortfolio(transactions, {
      asOfDate,
      taxYear,
      annualIncomeTHB: options.annualIncomeTHB,
      dateOfBirth: options.dateOfBirth,
    }),
    commodities: calculateCommodityPortfolio(transactions, asOfDate),
    forex: calculateForexCashLedger(transactions),
  };
}

export * from './bondEngine';
export * from './commodityEngine';
export * from './forexEngine';
export * from './fundEngine';
export * from './common';
export * from './legacyGoldAdapter';
