import Decimal from 'decimal.js';
import { COMMODITY_RULES } from '../../config/multiAssetRules';
import type { CommodityExtension, MultiAssetLot, MultiAssetTransaction } from '../../types/multiAsset';
import { asDecimal, compareTransactions, daysBetween, MultiAssetDecimal, roundMoney, roundQuantity, valueInTHB } from './common';

const GRAMS_PER_UNIT: Record<CommodityExtension['weightUnit'], Decimal> = {
  TROY_OUNCE: new MultiAssetDecimal(COMMODITY_RULES.standards.SILVER.gramsPerUnit),
  GRAM: new MultiAssetDecimal('1'),
  KILOGRAM: new MultiAssetDecimal('1000'),
  THAI_BAHT: new MultiAssetDecimal(COMMODITY_RULES.standards.GOLD.gramsPerUnit),
};

export type MetalGroup = 'GOLD' | 'SILVER' | 'PLATINUM' | 'OTHER';

export interface CommodityLotSummary {
  transactionId: string;
  symbol: string;
  weightGramsRemaining: string;
  fineWeightGramsRemaining: string;
  costBasisTHB: string;
  costPerGramTHB: string;
  realizedGLTHB: string;
  purity: string | null;
  purchaseDate: string;
}

export interface CommodityPosition {
  symbol: string;
  metal: MetalGroup;
  weightGrams: string;
  fineWeightGrams: string;
  costBasisTHB: string;
  spotPricePerGramTHB: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
  purity: string | null;
}

export interface MultiMetalDashboardRow {
  metal: MetalGroup;
  positionCount: number;
  weightGrams: string;
  fineWeightGrams: string;
  costBasisTHB: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
}

export interface CommodityPortfolioSummary {
  positions: CommodityPosition[];
  lots: MultiAssetLot[];
  multiMetalDashboard: MultiMetalDashboardRow[];
  totalWeightGrams: string;
  totalFineWeightGrams: string;
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
}

interface InternalCommodityLot {
  transaction: MultiAssetTransaction;
  gramsBought: Decimal;
  gramsRemaining: Decimal;
  costPerGramTHB: Decimal;
  realizedGLTHB: Decimal;
  purity: Decimal | null;
}

export function convertCommodityWeight(
  amount: string,
  fromUnit: CommodityExtension['weightUnit'],
  toUnit: CommodityExtension['weightUnit'],
): string {
  const value = asDecimal(amount, 'weight');
  if (value.isNegative()) throw new Error('weight cannot be negative.');
  const grams = value.times(GRAMS_PER_UNIT[fromUnit]);
  return roundQuantity(grams.dividedBy(GRAMS_PER_UNIT[toUnit]), 8);
}

export function classifyMetal(symbol: string): MetalGroup {
  const normalized = symbol.toUpperCase();
  if (normalized.includes('GOLD') || normalized.includes('XAU')) return 'GOLD';
  if (normalized.includes('SILVER') || normalized.includes('XAG')) return 'SILVER';
  if (normalized.includes('PLATINUM') || normalized.includes('PLAT') || normalized.includes('XPT')) return 'PLATINUM';
  return 'OTHER';
}

function transactionWeightGrams(transaction: MultiAssetTransaction): Decimal {
  const extension = transaction.commodityExtension;
  if (!extension) throw new Error(`Commodity transaction ${transaction.id} is missing commodityExtension.`);
  return asDecimal(extension.weight, 'weight')
    .times(asDecimal(transaction.qty, 'qty'))
    .times(GRAMS_PER_UNIT[extension.weightUnit]);
}

function extensionPurity(extension: CommodityExtension): Decimal | null {
  return extension.purity ? asDecimal(extension.purity, 'purity').dividedBy(100) : null;
}

function costForCommodity(transaction: MultiAssetTransaction): Decimal {
  return valueInTHB(transaction);
}

export function calculateCommodityPortfolio(
  transactions: readonly MultiAssetTransaction[],
  asOfDate = new Date().toISOString().slice(0, 10),
): CommodityPortfolioSummary {
  const commodityTransactions = transactions
    .filter((transaction) => transaction.assetClass === 'COMMODITY')
    .sort(compareTransactions);
  const lotsBySymbol = new Map<string, InternalCommodityLot[]>();
  const latestBySymbol = new Map<string, MultiAssetTransaction>();

  for (const transaction of commodityTransactions) {
    const extension = transaction.commodityExtension;
    if (!extension) throw new Error(`Commodity transaction ${transaction.id} is missing commodityExtension.`);
    latestBySymbol.set(transaction.symbol, transaction);
    if (transaction.type !== 'BUY' && transaction.type !== 'SELL') continue;
    const grams = transactionWeightGrams(transaction);
    if (!grams.isPositive()) throw new Error(`Commodity weight must be positive for ${transaction.id}.`);
    const lots = lotsBySymbol.get(transaction.symbol) ?? [];

    if (transaction.type === 'BUY') {
      const totalCostTHB = costForCommodity(transaction);
      lots.push({
        transaction,
        gramsBought: grams,
        gramsRemaining: grams,
        costPerGramTHB: totalCostTHB.dividedBy(grams),
        realizedGLTHB: new MultiAssetDecimal(0),
        purity: extensionPurity(extension),
      });
      lotsBySymbol.set(transaction.symbol, lots);
      continue;
    }

    const available = lots.reduce((sum, lot) => sum.plus(lot.gramsRemaining), new MultiAssetDecimal(0));
    if (grams.gt(available)) {
      throw new Error(`Commodity sale ${transaction.id} exceeds available FIFO weight for ${transaction.symbol}.`);
    }
    const proceedsPerGram = valueInTHB(transaction).dividedBy(grams);
    let remainingToSell = grams;
    for (const lot of lots) {
      if (!remainingToSell.isPositive()) break;
      if (!lot.gramsRemaining.isPositive()) continue;
      const sold = MultiAssetDecimal.min(lot.gramsRemaining, remainingToSell);
      lot.gramsRemaining = lot.gramsRemaining.minus(sold);
      lot.realizedGLTHB = lot.realizedGLTHB.plus(proceedsPerGram.minus(lot.costPerGramTHB).times(sold));
      remainingToSell = remainingToSell.minus(sold);
    }
    lotsBySymbol.set(transaction.symbol, lots);
  }

  const positions: CommodityPosition[] = [];
  const outputLots: MultiAssetLot[] = [];
  const metalAccumulators = new Map<MetalGroup, {
    symbols: Set<string>;
    weight: Decimal;
    fineWeight: Decimal;
    cost: Decimal;
    market: Decimal;
    realized: Decimal;
    unrealized: Decimal;
  }>();
  let totalWeight = new MultiAssetDecimal(0);
  let totalFineWeight = new MultiAssetDecimal(0);
  let totalCost = new MultiAssetDecimal(0);
  let totalMarket = new MultiAssetDecimal(0);
  let totalRealized = new MultiAssetDecimal(0);
  let totalUnrealized = new MultiAssetDecimal(0);

  for (const [symbol, lots] of lotsBySymbol) {
    const latest = latestBySymbol.get(symbol);
    const extension = latest?.commodityExtension;
    if (!latest || !extension) continue;
    const balanceGrams = lots.reduce((sum, lot) => sum.plus(lot.gramsRemaining), new MultiAssetDecimal(0));
    const fineGrams = lots.reduce(
      (sum, lot) => sum.plus(lot.gramsRemaining.times(lot.purity ?? 1)),
      new MultiAssetDecimal(0),
    );
    const costBasis = lots.reduce((sum, lot) => sum.plus(lot.gramsRemaining.times(lot.costPerGramTHB)), new MultiAssetDecimal(0));
    const quotePrice = asDecimal(extension.spotPricePerUnit, 'spotPricePerUnit');
    const pricePerGram = quotePrice.dividedBy(GRAMS_PER_UNIT[extension.weightUnit]);
    const fx = latest.fxRate ? asDecimal(latest.fxRate, 'fxRate') : new MultiAssetDecimal(1);
    const spotPricePerGramTHB = pricePerGram.times(
      latest.originalCurrency.toUpperCase() === 'THB' ? 1 : fx,
    );
    const marketValue = balanceGrams.times(spotPricePerGramTHB);
    const realized = lots.reduce((sum, lot) => sum.plus(lot.realizedGLTHB), new MultiAssetDecimal(0));
    const unrealized = marketValue.minus(costBasis);
    const weightedPurity = balanceGrams.isPositive() ? fineGrams.dividedBy(balanceGrams).times(100) : null;
    const metal = classifyMetal(symbol);

    positions.push({
      symbol,
      metal,
      weightGrams: roundQuantity(balanceGrams),
      fineWeightGrams: roundQuantity(fineGrams),
      costBasisTHB: roundMoney(costBasis),
      spotPricePerGramTHB: roundMoney(spotPricePerGramTHB),
      marketValueTHB: roundMoney(marketValue),
      realizedGLTHB: roundMoney(realized),
      unrealizedGLTHB: roundMoney(unrealized),
      purity: weightedPurity ? weightedPurity.toDecimalPlaces(4).toFixed(4) : null,
    });

    for (const lot of lots) {
      const soldGrams = lot.gramsBought.minus(lot.gramsRemaining);
      const unrealizedLot = spotPricePerGramTHB.minus(lot.costPerGramTHB).times(lot.gramsRemaining);
      outputLots.push({
        id: lot.transaction.id,
        transactionId: lot.transaction.id,
        symbol,
        assetClass: 'COMMODITY',
        buyQty: lot.gramsBought.toNumber(),
        costPerUnit: roundMoney(lot.costPerGramTHB),
        qtySold: soldGrams.toNumber(),
        qtyRemain: lot.gramsRemaining.toNumber(),
        realizedGL: roundMoney(lot.realizedGLTHB),
        unrealizedGL: roundMoney(unrealizedLot),
        status: lot.gramsRemaining.isZero() ? 'Sold' : soldGrams.isZero() ? 'Hold' : 'Partial',
        daysHeld: Math.max(0, daysBetween(lot.transaction.date, asOfDate)),
        commodityLotData: {
          weight: lot.transaction.commodityExtension!.weight,
          weightUnit: lot.transaction.commodityExtension!.weightUnit,
          purity: lot.transaction.commodityExtension!.purity,
        },
      });
    }

    const accumulator = metalAccumulators.get(metal) ?? {
      symbols: new Set<string>(),
      weight: new MultiAssetDecimal(0),
      fineWeight: new MultiAssetDecimal(0),
      cost: new MultiAssetDecimal(0),
      market: new MultiAssetDecimal(0),
      realized: new MultiAssetDecimal(0),
      unrealized: new MultiAssetDecimal(0),
    };
    accumulator.symbols.add(symbol);
    accumulator.weight = accumulator.weight.plus(balanceGrams);
    accumulator.fineWeight = accumulator.fineWeight.plus(fineGrams);
    accumulator.cost = accumulator.cost.plus(costBasis);
    accumulator.market = accumulator.market.plus(marketValue);
    accumulator.realized = accumulator.realized.plus(realized);
    accumulator.unrealized = accumulator.unrealized.plus(unrealized);
    metalAccumulators.set(metal, accumulator);

    totalWeight = totalWeight.plus(balanceGrams);
    totalFineWeight = totalFineWeight.plus(fineGrams);
    totalCost = totalCost.plus(costBasis);
    totalMarket = totalMarket.plus(marketValue);
    totalRealized = totalRealized.plus(realized);
    totalUnrealized = totalUnrealized.plus(unrealized);
  }

  const metalOrder: MetalGroup[] = ['GOLD', 'SILVER', 'PLATINUM', 'OTHER'];
  const multiMetalDashboard = metalOrder
    .filter((metal) => metalAccumulators.has(metal))
    .map((metal) => {
      const item = metalAccumulators.get(metal)!;
      return {
        metal,
        positionCount: item.symbols.size,
        weightGrams: roundQuantity(item.weight),
        fineWeightGrams: roundQuantity(item.fineWeight),
        costBasisTHB: roundMoney(item.cost),
        marketValueTHB: roundMoney(item.market),
        realizedGLTHB: roundMoney(item.realized),
        unrealizedGLTHB: roundMoney(item.unrealized),
      };
    });

  return {
    positions,
    lots: outputLots,
    multiMetalDashboard,
    totalWeightGrams: roundQuantity(totalWeight),
    totalFineWeightGrams: roundQuantity(totalFineWeight),
    totalCostBasisTHB: roundMoney(totalCost),
    totalMarketValueTHB: roundMoney(totalMarket),
    totalRealizedGLTHB: roundMoney(totalRealized),
    totalUnrealizedGLTHB: roundMoney(totalUnrealized),
  };
}
