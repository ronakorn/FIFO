import Decimal from 'decimal.js';
import type { MultiAssetTransaction } from '../../types/multiAsset';

export const MultiAssetDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export function asDecimal(value: string | number, field = 'amount'): Decimal {
  try {
    const decimal = new MultiAssetDecimal(value);
    if (!decimal.isFinite()) throw new Error('not finite');
    return decimal;
  } catch {
    throw new Error(`${field} must be a finite decimal value.`);
  }
}

export function roundMoney(value: Decimal.Value): string {
  return new MultiAssetDecimal(value).toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
}

export function roundQuantity(value: Decimal.Value, places = 8): string {
  return new MultiAssetDecimal(value).toDecimalPlaces(places, Decimal.ROUND_HALF_UP).toFixed(places);
}

export function valueInTHB(transaction: MultiAssetTransaction): Decimal {
  if (transaction.netTHB !== null) {
    return asDecimal(transaction.netTHB, 'netTHB');
  }
  const net = asDecimal(transaction.net, 'net');
  if (transaction.originalCurrency.toUpperCase() === 'THB') return net;
  if (transaction.fxRate) return net.times(asDecimal(transaction.fxRate, 'fxRate'));
  throw new Error(`A THB value or FX rate is required for ${transaction.originalCurrency} transaction ${transaction.id}.`);
}

export function dateOnly(value: string | Date): string {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return value.slice(0, 10);
}

export function utcDate(value: string): Date {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) throw new Error(`Invalid ISO date: ${value}`);
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    throw new Error(`Invalid calendar date: ${value}`);
  }
  return date;
}

export function daysBetween(startDate: string, endDate: string): number {
  return Math.floor((utcDate(endDate).getTime() - utcDate(startDate).getTime()) / 86_400_000);
}

export function compareTransactions(a: MultiAssetTransaction, b: MultiAssetTransaction): number {
  const byDate = a.date.localeCompare(b.date);
  if (byDate !== 0) return byDate;
  return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime() || a.id.localeCompare(b.id);
}

export function ensureNonNegative(value: Decimal, field: string): Decimal {
  if (value.isNegative()) throw new Error(`${field} cannot be negative.`);
  return value;
}
