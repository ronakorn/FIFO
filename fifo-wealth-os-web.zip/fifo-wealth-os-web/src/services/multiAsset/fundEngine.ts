import Decimal from 'decimal.js';
import { FUND_RULES } from '../../config/multiAssetRules';
import type { FundExtension, MultiAssetTransaction } from '../../types/multiAsset';
import { asDecimal, compareTransactions, daysBetween, MultiAssetDecimal, roundMoney, utcDate, valueInTHB } from './common';

export interface FundLotStatus {
  transactionId: string;
  symbol: string;
  fundType: FundExtension['fundType'];
  purchaseDate: string;
  quantityRemaining: string;
  holdingPeriodDays: number;
  requiredHoldingPeriodDays: number;
  holdingPeriodComplete: boolean;
  ageAtAsOf: number | null;
  ageConditionMet: boolean | null;
  ageEligibleDate: string | null;
  taxDeductible: boolean;
  dividendPolicy: FundExtension['dividendPolicy'];
}

export interface FundRedemptionCheck {
  transactionId: string;
  symbol: string;
  fundType: FundExtension['fundType'];
  saleDate: string;
  purchaseDate: string;
  quantitySold: string;
  actualHoldingDays: number;
  requiredHoldingDays: number;
  holdingPeriodMet: boolean;
  ageAtSale: number | null;
  ageConditionMet: boolean | null;
  ageEligibleDate: string | null;
}

export interface FundTaxDeductionSummary {
  taxYear: number;
  annualIncomeTHB: string | null;
  contributionsTHB: Record<'SSF' | 'RMF' | 'THAI_ESG', string>;
  configuredLimitsTHB: Record<'SSF' | 'RMF' | 'THAI_ESG', string>;
  appliedLimitsTHB: Record<'SSF' | 'RMF' | 'THAI_ESG', string>;
  eligibleDeductionTHB: Record<'SSF' | 'RMF' | 'THAI_ESG', string>;
  remainingLimitTHB: Record<'SSF' | 'RMF' | 'THAI_ESG', string>;
  totalEligibleDeductionTHB: string;
  note: string;
}

export interface FundPosition {
  symbol: string;
  fundType: FundExtension['fundType'];
  quantity: string;
  costBasisTHB: string;
  navPerUnit: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
  dividendPolicy: FundExtension['dividendPolicy'];
  reinvestedDividendUnits: string;
}

export interface FundPortfolioSummary {
  positions: FundPosition[];
  holdingLots: FundLotStatus[];
  redemptionChecks: FundRedemptionCheck[];
  rmfAgeCondition: {
    ageAtAsOf: number;
    isEligible: boolean;
    ageEligibleDate: string;
  } | null;
  taxDeduction: FundTaxDeductionSummary;
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
  cashDividendsTHB: string;
  dripReinvestedUnits: string;
}

interface InternalFundLot {
  transactionId: string;
  symbol: string;
  fundType: FundExtension['fundType'];
  purchaseDate: string;
  quantityBought: Decimal;
  quantityRemaining: Decimal;
  costPerUnitTHB: Decimal;
  realizedGLTHB: Decimal;
  taxDeductible: boolean;
  dividendPolicy: FundExtension['dividendPolicy'];
  isDrip: boolean;
}

const TAX_FUND_TYPES = ['SSF', 'RMF', 'THAI_ESG'] as const;
type TaxFundType = (typeof TAX_FUND_TYPES)[number];

function isTaxFundType(value: FundExtension['fundType']): value is TaxFundType {
  return TAX_FUND_TYPES.includes(value as TaxFundType);
}

function requiredHoldingDays(fundType: FundExtension['fundType']): number {
  return isTaxFundType(fundType) ? FUND_RULES.holdingPeriodRequirements[fundType] : 0;
}

function isLeapYear(year: number): boolean {
  return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
}

function birthdayAnniversary(dateOfBirth: Date, year: number): { month: number; day: number } {
  const month = dateOfBirth.getUTCMonth();
  const day = dateOfBirth.getUTCDate();
  // Use 1 March when a 29 February birthday falls in a non-leap year.
  if (month === 1 && day === 29 && !isLeapYear(year)) return { month: 2, day: 1 };
  return { month, day };
}

function birthDateOnAgeThreshold(dateOfBirth: Date): string {
  const targetYear = dateOfBirth.getUTCFullYear() + 55;
  const anniversary = birthdayAnniversary(dateOfBirth, targetYear);
  return `${targetYear}-${String(anniversary.month + 1).padStart(2, '0')}-${String(anniversary.day).padStart(2, '0')}`;
}

/**
 * Tests the statutory age-55 condition on the actual redemption date.
 * When DOB is absent or invalid, eligibility is false and ageAtSale is 0 (unknown).
 */
export function validateRMFAgeCondition(
  dateOfBirth: Date | null,
  saleDate: Date,
): { isEligible: boolean; ageAtSale: number } {
  if (!dateOfBirth || Number.isNaN(dateOfBirth.getTime()) || Number.isNaN(saleDate.getTime())) {
    return { isEligible: false, ageAtSale: 0 };
  }
  const birthYear = dateOfBirth.getUTCFullYear();
  const saleYear = saleDate.getUTCFullYear();
  const anniversary = birthdayAnniversary(dateOfBirth, saleYear);
  const saleMonth = saleDate.getUTCMonth();
  const saleDay = saleDate.getUTCDate();
  let ageAtSale = saleYear - birthYear;
  if (saleMonth < anniversary.month || (saleMonth === anniversary.month && saleDay < anniversary.day)) ageAtSale -= 1;
  ageAtSale = Math.max(0, ageAtSale);
  return { isEligible: ageAtSale >= 55, ageAtSale };
}

function getRMFAgeCondition(dateOfBirth: Date | null, date: Date): {
  age: number | null;
  isEligible: boolean | null;
  eligibleDate: string | null;
} {
  if (!dateOfBirth || Number.isNaN(dateOfBirth.getTime())) {
    return { age: null, isEligible: null, eligibleDate: null };
  }
  const result = validateRMFAgeCondition(dateOfBirth, date);
  return {
    age: result.ageAtSale,
    isEligible: result.isEligible,
    eligibleDate: birthDateOnAgeThreshold(dateOfBirth),
  };
}

function getMoneyForDividend(transaction: MultiAssetTransaction): Decimal {
  return valueInTHB(transaction);
}

export function calculateFundTaxDeductionSummary(input: {
  transactions: readonly MultiAssetTransaction[];
  taxYear: number;
  annualIncomeTHB?: string | null;
}): FundTaxDeductionSummary {
  const contributions: Record<TaxFundType, Decimal> = {
    SSF: new MultiAssetDecimal(0),
    RMF: new MultiAssetDecimal(0),
    THAI_ESG: new MultiAssetDecimal(0),
  };

  for (const transaction of input.transactions) {
    const extension = transaction.fundExtension;
    if (
      transaction.assetClass !== 'FUND' ||
      transaction.type !== 'BUY' ||
      !extension?.taxDeductible ||
      !isTaxFundType(extension.fundType) ||
      Number(transaction.date.slice(0, 4)) !== input.taxYear
    ) {
      continue;
    }
    contributions[extension.fundType] = contributions[extension.fundType].plus(valueInTHB(transaction));
  }

  const annualIncome = input.annualIncomeTHB ? asDecimal(input.annualIncomeTHB, 'annualIncomeTHB') : null;
  const configuredLimits: Record<TaxFundType, Decimal> = {
    SSF: new MultiAssetDecimal(FUND_RULES.taxDeductionLimits.SSF),
    RMF: new MultiAssetDecimal(FUND_RULES.taxDeductionLimits.RMF),
    THAI_ESG: new MultiAssetDecimal(FUND_RULES.taxDeductionLimits.THAI_ESG),
  };
  const appliedLimits: Record<TaxFundType, Decimal> = {
    ...configuredLimits,
    RMF: annualIncome
      ? Decimal.min(configuredLimits.RMF, annualIncome.times('0.30'))
      : configuredLimits.RMF,
  };
  const eligible: Record<TaxFundType, Decimal> = {
    SSF: Decimal.min(contributions.SSF, appliedLimits.SSF),
    RMF: Decimal.min(contributions.RMF, appliedLimits.RMF),
    THAI_ESG: Decimal.min(contributions.THAI_ESG, appliedLimits.THAI_ESG),
  };
  const remaining: Record<TaxFundType, Decimal> = {
    SSF: Decimal.max(new MultiAssetDecimal(0), appliedLimits.SSF.minus(eligible.SSF)),
    RMF: Decimal.max(new MultiAssetDecimal(0), appliedLimits.RMF.minus(eligible.RMF)),
    THAI_ESG: Decimal.max(new MultiAssetDecimal(0), appliedLimits.THAI_ESG.minus(eligible.THAI_ESG)),
  };

  return {
    taxYear: input.taxYear,
    annualIncomeTHB: annualIncome ? roundMoney(annualIncome) : null,
    contributionsTHB: {
      SSF: roundMoney(contributions.SSF),
      RMF: roundMoney(contributions.RMF),
      THAI_ESG: roundMoney(contributions.THAI_ESG),
    },
    configuredLimitsTHB: {
      SSF: roundMoney(configuredLimits.SSF),
      RMF: roundMoney(configuredLimits.RMF),
      THAI_ESG: roundMoney(configuredLimits.THAI_ESG),
    },
    appliedLimitsTHB: {
      SSF: roundMoney(appliedLimits.SSF),
      RMF: roundMoney(appliedLimits.RMF),
      THAI_ESG: roundMoney(appliedLimits.THAI_ESG),
    },
    eligibleDeductionTHB: {
      SSF: roundMoney(eligible.SSF),
      RMF: roundMoney(eligible.RMF),
      THAI_ESG: roundMoney(eligible.THAI_ESG),
    },
    remainingLimitTHB: {
      SSF: roundMoney(remaining.SSF),
      RMF: roundMoney(remaining.RMF),
      THAI_ESG: roundMoney(remaining.THAI_ESG),
    },
    totalEligibleDeductionTHB: roundMoney(eligible.SSF.plus(eligible.RMF).plus(eligible.THAI_ESG)),
    note: annualIncome
      ? 'เป็นเพียงประมาณการตาม rules configuration; สถานะอายุ 55 ปีแสดงแยกในรายการ RMF แต่ยอดลดหย่อนนี้ยังไม่ยืนยันคุณสมบัติผู้ลงทุนหรือเงื่อนไขทางกฎหมายอื่น โปรดยืนยันประกาศล่าสุดก่อนยื่นแบบ'
      : 'วงเงิน RMF ยังไม่หักเพดาน 30% ของรายได้เพราะยังไม่ได้ระบุรายได้; สถานะอายุ 55 ปีแสดงแยกในรายการ RMF ยอดนี้ยังไม่ยืนยันคุณสมบัติหรือเงื่อนไขอื่น และไม่ใช่คำแนะนำภาษี',
  };
}

export function calculateFundPortfolio(
  transactions: readonly MultiAssetTransaction[],
  options: {
    asOfDate?: string;
    taxYear?: number;
    annualIncomeTHB?: string | null;
    dateOfBirth?: Date | null;
  } = {},
): FundPortfolioSummary {
  const asOfDate = options.asOfDate ?? new Date().toISOString().slice(0, 10);
  const taxYear = options.taxYear ?? Number(asOfDate.slice(0, 4));
  const fundTransactions = transactions
    .filter((transaction) => transaction.assetClass === 'FUND')
    .sort(compareTransactions);
  const lotsBySymbol = new Map<string, InternalFundLot[]>();
  const latestBySymbol = new Map<string, MultiAssetTransaction>();
  const redemptionChecks: FundRedemptionCheck[] = [];
  let cashDividends = new MultiAssetDecimal(0);
  let totalDripUnits = new MultiAssetDecimal(0);

  for (const transaction of fundTransactions) {
    const extension = transaction.fundExtension;
    if (!extension) throw new Error(`Fund transaction ${transaction.id} is missing fundExtension.`);
    latestBySymbol.set(transaction.symbol, transaction);
    const lots = lotsBySymbol.get(transaction.symbol) ?? [];

    if (transaction.type === 'BUY') {
      const quantity = asDecimal(transaction.qty, 'qty');
      const costPerUnit = valueInTHB(transaction).dividedBy(quantity);
      lots.push({
        transactionId: transaction.id,
        symbol: transaction.symbol,
        fundType: extension.fundType,
        purchaseDate: extension.purchaseDate ?? transaction.date,
        quantityBought: quantity,
        quantityRemaining: quantity,
        costPerUnitTHB: costPerUnit,
        realizedGLTHB: new MultiAssetDecimal(0),
        taxDeductible: extension.taxDeductible,
        dividendPolicy: extension.dividendPolicy,
        isDrip: false,
      });
      lotsBySymbol.set(transaction.symbol, lots);
      continue;
    }

    if (transaction.type === 'DIVIDEND') {
      const dividend = getMoneyForDividend(transaction);
      if (extension.dividendPolicy === 'DRIP') {
        const fx = transaction.fxRate ? asDecimal(transaction.fxRate, 'fxRate') : new MultiAssetDecimal(1);
        const navTHB = asDecimal(extension.navPerUnit, 'navPerUnit').times(
          transaction.originalCurrency.toUpperCase() === 'THB' ? 1 : fx,
        );
        if (!navTHB.isPositive()) throw new Error(`DRIP NAV must be positive for ${transaction.symbol}.`);
        const units = dividend.dividedBy(navTHB);
        if (units.isPositive()) {
          lots.push({
            transactionId: `${transaction.id}:DRIP`,
            symbol: transaction.symbol,
            fundType: extension.fundType,
            purchaseDate: transaction.date,
            quantityBought: units,
            quantityRemaining: units,
            costPerUnitTHB: navTHB,
            realizedGLTHB: new MultiAssetDecimal(0),
            taxDeductible: false,
            dividendPolicy: 'DRIP',
            isDrip: true,
          });
          totalDripUnits = totalDripUnits.plus(units);
        }
      } else {
        cashDividends = cashDividends.plus(dividend);
      }
      lotsBySymbol.set(transaction.symbol, lots);
      continue;
    }

    if (transaction.type !== 'SELL') continue;
    const quantity = asDecimal(transaction.qty, 'qty');
    const available = lots.reduce((sum, lot) => sum.plus(lot.quantityRemaining), new MultiAssetDecimal(0));
    if (quantity.gt(available)) {
      throw new Error(`Fund redemption ${transaction.id} exceeds available FIFO units for ${transaction.symbol}.`);
    }
    const proceedsPerUnit = valueInTHB(transaction).dividedBy(quantity);
    let remainingToSell = quantity;
    for (const lot of lots) {
      if (!remainingToSell.isPositive()) break;
      if (!lot.quantityRemaining.isPositive()) continue;
      const sold = MultiAssetDecimal.min(lot.quantityRemaining, remainingToSell);
      lot.quantityRemaining = lot.quantityRemaining.minus(sold);
      const realized = proceedsPerUnit.minus(lot.costPerUnitTHB).times(sold);
      lot.realizedGLTHB = lot.realizedGLTHB.plus(realized);
      const actualDays = Math.max(0, daysBetween(lot.purchaseDate, transaction.date));
      const requiredDays = requiredHoldingDays(lot.fundType);
      const holdingPeriodMet = requiredDays === 0 || actualDays >= requiredDays;
      const ageCondition = lot.fundType === 'RMF'
        ? getRMFAgeCondition(options.dateOfBirth ?? null, utcDate(transaction.date))
        : { age: null, isEligible: null, eligibleDate: null };
      redemptionChecks.push({
        transactionId: transaction.id,
        symbol: transaction.symbol,
        fundType: lot.fundType,
        saleDate: transaction.date,
        purchaseDate: lot.purchaseDate,
        quantitySold: sold.toFixed(8),
        actualHoldingDays: actualDays,
        requiredHoldingDays: requiredDays,
        holdingPeriodMet,
        ageAtSale: ageCondition.age,
        ageConditionMet: ageCondition.isEligible,
        ageEligibleDate: ageCondition.eligibleDate,
      });
      remainingToSell = remainingToSell.minus(sold);
    }
    lotsBySymbol.set(transaction.symbol, lots);
  }

  const positions: FundPosition[] = [];
  const holdingLots: FundLotStatus[] = [];
  let totalCost = new MultiAssetDecimal(0);
  let totalMarket = new MultiAssetDecimal(0);
  let totalRealized = new MultiAssetDecimal(0);
  let totalUnrealized = new MultiAssetDecimal(0);

  for (const [symbol, lots] of lotsBySymbol) {
    const latest = latestBySymbol.get(symbol);
    const extension = latest?.fundExtension;
    if (!latest || !extension) continue;
    const quantity = lots.reduce((sum, lot) => sum.plus(lot.quantityRemaining), new MultiAssetDecimal(0));
    const costBasis = lots.reduce((sum, lot) => sum.plus(lot.quantityRemaining.times(lot.costPerUnitTHB)), new MultiAssetDecimal(0));
    const fx = latest.fxRate ? asDecimal(latest.fxRate, 'fxRate') : new MultiAssetDecimal(1);
    const navTHB = asDecimal(extension.navPerUnit, 'navPerUnit').times(
      latest.originalCurrency.toUpperCase() === 'THB' ? 1 : fx,
    );
    const marketValue = navTHB.times(quantity);
    const unrealized = marketValue.minus(costBasis);
    const realized = lots.reduce((sum, lot) => sum.plus(lot.realizedGLTHB), new MultiAssetDecimal(0));
    const reinvested = lots
      .filter((lot) => lot.isDrip)
      .reduce((sum, lot) => sum.plus(lot.quantityBought), new MultiAssetDecimal(0));

    positions.push({
      symbol,
      fundType: extension.fundType,
      quantity: quantity.toFixed(8),
      costBasisTHB: roundMoney(costBasis),
      navPerUnit: roundMoney(navTHB),
      marketValueTHB: roundMoney(marketValue),
      realizedGLTHB: roundMoney(realized),
      unrealizedGLTHB: roundMoney(unrealized),
      dividendPolicy: extension.dividendPolicy,
      reinvestedDividendUnits: reinvested.toFixed(8),
    });

    for (const lot of lots) {
      if (!lot.quantityRemaining.isPositive()) continue;
      const actualDays = Math.max(0, daysBetween(lot.purchaseDate, asOfDate));
      const requiredDays = requiredHoldingDays(lot.fundType);
      const ageCondition = lot.fundType === 'RMF'
        ? getRMFAgeCondition(options.dateOfBirth ?? null, utcDate(asOfDate))
        : { age: null, isEligible: null, eligibleDate: null };
      holdingLots.push({
        transactionId: lot.transactionId,
        symbol,
        fundType: lot.fundType,
        purchaseDate: lot.purchaseDate,
        quantityRemaining: lot.quantityRemaining.toFixed(8),
        holdingPeriodDays: actualDays,
        requiredHoldingPeriodDays: requiredDays,
        holdingPeriodComplete: requiredDays === 0 || actualDays >= requiredDays,
        ageAtAsOf: ageCondition.age,
        ageConditionMet: ageCondition.isEligible,
        ageEligibleDate: ageCondition.eligibleDate,
        taxDeductible: lot.taxDeductible,
        dividendPolicy: lot.dividendPolicy,
      });
    }

    totalCost = totalCost.plus(costBasis);
    totalMarket = totalMarket.plus(marketValue);
    totalRealized = totalRealized.plus(realized);
    totalUnrealized = totalUnrealized.plus(unrealized);
  }

  return {
    positions,
    holdingLots,
    redemptionChecks,
    rmfAgeCondition: options.dateOfBirth
      ? (() => {
          const ageCondition = getRMFAgeCondition(options.dateOfBirth ?? null, utcDate(asOfDate));
          if (ageCondition.age === null || ageCondition.isEligible === null || ageCondition.eligibleDate === null) return null;
          return {
            ageAtAsOf: ageCondition.age,
            isEligible: ageCondition.isEligible,
            ageEligibleDate: ageCondition.eligibleDate,
          };
        })()
      : null,
    taxDeduction: calculateFundTaxDeductionSummary({
      transactions: fundTransactions,
      taxYear,
      annualIncomeTHB: options.annualIncomeTHB,
    }),
    totalCostBasisTHB: roundMoney(totalCost),
    totalMarketValueTHB: roundMoney(totalMarket),
    totalRealizedGLTHB: roundMoney(totalRealized),
    totalUnrealizedGLTHB: roundMoney(totalUnrealized),
    cashDividendsTHB: roundMoney(cashDividends),
    dripReinvestedUnits: totalDripUnits.toFixed(8),
  };
}
