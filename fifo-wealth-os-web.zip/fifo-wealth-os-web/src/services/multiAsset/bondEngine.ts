import Decimal from 'decimal.js';
import { BOND_RULES } from '../../config/multiAssetRules';
import type { BondExtension, MultiAssetLot, MultiAssetTransaction } from '../../types/multiAsset';
import { asDecimal, compareTransactions, dateOnly, daysBetween, MultiAssetDecimal, roundMoney, utcDate, valueInTHB } from './common';

const MONTHS_PER_COUPON: Record<BondExtension['paymentFrequency'], number> = {
  MONTHLY: 1,
  QUARTERLY: 3,
  SEMI_ANNUAL: 6,
  ANNUAL: 12,
};

const PAYMENTS_PER_YEAR: Record<BondExtension['paymentFrequency'], number> = {
  MONTHLY: 12,
  QUARTERLY: 4,
  SEMI_ANNUAL: 2,
  ANNUAL: 1,
};

export interface BondCouponPayment {
  date: string;
  grossTHB: string;
  withholdingTaxTHB: string;
  netTHB: string;
}

export interface BondAccruedInterestResult {
  asOfDate: string;
  previousCouponDate: string;
  nextCouponDate: string | null;
  daysSinceLastCoupon: number;
  amountPerBondTHB: string;
}

export interface BondYtmInput {
  faceValue: string;
  couponRate: string;
  paymentFrequency: BondExtension['paymentFrequency'];
  maturityDate: string;
  settlementDate: string;
  cleanPrice: string;
  accruedInterest?: string;
}

export interface BondPositionSummary {
  symbol: string;
  issuer: string | null;
  creditRating: string | null;
  quantity: string;
  costBasisTHB: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
  accruedInterestPerBondTHB: string;
  accruedInterestTotalTHB: string;
  yieldToMaturity: string | null;
  nextCouponDate: string | null;
  couponSchedule: BondCouponPayment[];
}

export interface BondPortfolioSummary {
  positions: BondPositionSummary[];
  lots: MultiAssetLot[];
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
  totalAccruedInterestTHB: string;
  couponIncomeTHB: string;
  couponWithholdingTaxTHB: string;
  upcomingCoupons: Array<BondCouponPayment & { symbol: string }>;
}

interface InternalBondLot {
  transaction: MultiAssetTransaction;
  quantityBought: Decimal;
  quantityRemaining: Decimal;
  costPerBondTHB: Decimal;
  realizedGLTHB: Decimal;
}

function addMonthsClamped(isoDate: string, monthDelta: number): string {
  const source = utcDate(isoDate);
  const sourceDay = source.getUTCDate();
  const targetMonth = new Date(Date.UTC(source.getUTCFullYear(), source.getUTCMonth() + monthDelta, 1));
  const targetYearValue = targetMonth.getUTCFullYear();
  const targetMonthValue = targetMonth.getUTCMonth();
  const lastDay = new Date(Date.UTC(targetYearValue, targetMonthValue + 1, 0)).getUTCDate();
  const result = new Date(Date.UTC(targetYearValue, targetMonthValue, Math.min(sourceDay, lastDay)));
  return result.toISOString().slice(0, 10);
}

function couponDatesFromMaturity(
  maturityDate: string,
  frequency: BondExtension['paymentFrequency'],
  earliestDate: string,
): string[] {
  const maturity = dateOnly(maturityDate);
  const earliest = dateOnly(earliestDate);
  utcDate(maturity);
  utcDate(earliest);
  const monthStep = MONTHS_PER_COUPON[frequency];
  const dates: string[] = [];

  for (let period = 0; period <= 1200; period += 1) {
    const couponDate = addMonthsClamped(maturity, -monthStep * period);
    if (couponDate < earliest) break;
    dates.push(couponDate);
  }

  return dates.reverse();
}

function couponAmount(faceValue: string, couponRate: string, frequency: BondExtension['paymentFrequency']): Decimal {
  return asDecimal(faceValue, 'faceValue')
    .times(asDecimal(couponRate, 'couponRate'))
    .dividedBy(PAYMENTS_PER_YEAR[frequency]);
}

export function generateBondCouponSchedule(input: {
  faceValue: string;
  couponRate: string;
  paymentFrequency: BondExtension['paymentFrequency'];
  maturityDate: string;
  fromDate?: string;
}): BondCouponPayment[] {
  const fromDate = input.fromDate ? dateOnly(input.fromDate) : '1900-01-01';
  const gross = couponAmount(input.faceValue, input.couponRate, input.paymentFrequency);
  const withholding = gross.times(BOND_RULES.withholdingTaxRate);
  return couponDatesFromMaturity(input.maturityDate, input.paymentFrequency, fromDate).map((date) => ({
    date,
    grossTHB: roundMoney(gross),
    withholdingTaxTHB: roundMoney(withholding),
    netTHB: roundMoney(gross.minus(withholding)),
  }));
}

export function calculateBondAccruedInterest(
  extension: BondExtension,
  asOfDate: string,
): BondAccruedInterestResult {
  const date = dateOnly(asOfDate);
  const maturity = dateOnly(extension.maturityDate);
  utcDate(date);
  utcDate(maturity);
  if (date >= maturity) {
    return {
      asOfDate: date,
      previousCouponDate: maturity,
      nextCouponDate: null,
      daysSinceLastCoupon: 0,
      amountPerBondTHB: '0.00',
    };
  }
  const scheduleDates = couponDatesFromMaturity(maturity, extension.paymentFrequency, '1900-01-01');
  const previous = scheduleDates.filter((couponDate) => couponDate <= date).at(-1)
    ?? addMonthsClamped(extension.maturityDate, -MONTHS_PER_COUPON[extension.paymentFrequency]);
  const next = scheduleDates.find((couponDate) => couponDate > date) ?? null;
  const days = Math.max(0, daysBetween(previous, date));
  const amount = BOND_RULES.calculateAccruedInterest(extension.faceValue, extension.couponRate, days);

  return {
    asOfDate: date,
    previousCouponDate: previous,
    nextCouponDate: next,
    daysSinceLastCoupon: days,
    amountPerBondTHB: amount,
  };
}

export function calculateBondYieldToMaturity(input: BondYtmInput): string | null {
  const settlement = dateOnly(input.settlementDate);
  const maturity = dateOnly(input.maturityDate);
  if (maturity <= settlement) return null;

  const coupons = generateBondCouponSchedule({
    faceValue: input.faceValue,
    couponRate: input.couponRate,
    paymentFrequency: input.paymentFrequency,
    maturityDate: maturity,
    fromDate: addMonthsClamped(settlement, 1 - MONTHS_PER_COUPON[input.paymentFrequency]),
  }).filter((coupon) => coupon.date > settlement);
  if (coupons.length === 0) return null;

  const frequency = PAYMENTS_PER_YEAR[input.paymentFrequency];
  const dirtyPrice = asDecimal(input.cleanPrice, 'cleanPrice').plus(asDecimal(input.accruedInterest ?? '0', 'accruedInterest'));
  if (!dirtyPrice.isPositive()) return null;

  const exactCoupon = couponAmount(input.faceValue, input.couponRate, input.paymentFrequency);
  const cashFlows = coupons.map((coupon) => ({
    date: coupon.date,
    amount: exactCoupon.plus(coupon.date === maturity ? asDecimal(input.faceValue) : 0),
  }));

  const presentValueAt = (annualYield: Decimal): Decimal => {
    const periodicBase = new MultiAssetDecimal(1).plus(annualYield.dividedBy(frequency));
    if (!periodicBase.isPositive()) return new MultiAssetDecimal(Infinity);
    return cashFlows.reduce((sum, cashFlow) => {
      const days = daysBetween(settlement, cashFlow.date);
      const periods = new MultiAssetDecimal(days).dividedBy(365).times(frequency);
      return sum.plus(cashFlow.amount.dividedBy(periodicBase.pow(periods)));
    }, new MultiAssetDecimal(0));
  };

  let low = new MultiAssetDecimal(-frequency).plus('0.00000000000000000001');
  let high = new MultiAssetDecimal(1);
  while (presentValueAt(high).gt(dirtyPrice) && high.lt(1000)) high = high.times(2);
  if (presentValueAt(low).lt(dirtyPrice) || presentValueAt(high).gt(dirtyPrice)) return null;

  for (let iteration = 0; iteration < 180; iteration += 1) {
    const mid = low.plus(high).dividedBy(2);
    const presentValue = presentValueAt(mid);
    if (presentValue.gt(dirtyPrice)) low = mid;
    else high = mid;
    if (high.minus(low).abs().lt('0.00000000000001')) break;
  }

  return low.plus(high).dividedBy(2).toDecimalPlaces(8, Decimal.ROUND_HALF_UP).toFixed(8);
}

export function calculateBondPortfolio(
  transactions: readonly MultiAssetTransaction[],
  asOfDate = new Date().toISOString().slice(0, 10),
): BondPortfolioSummary {
  const bondTransactions = transactions
    .filter((transaction) => transaction.assetClass === 'BOND')
    .sort(compareTransactions);
  const lotsBySymbol = new Map<string, InternalBondLot[]>();
  const latestBySymbol = new Map<string, MultiAssetTransaction>();

  for (const transaction of bondTransactions) {
    if (transaction.type === 'BUY' || transaction.type === 'SELL') {
      latestBySymbol.set(transaction.symbol, transaction);
    }
    if (transaction.type !== 'BUY' && transaction.type !== 'SELL') continue;
    const quantity = asDecimal(transaction.qty, 'qty');
    const lots = lotsBySymbol.get(transaction.symbol) ?? [];

    if (transaction.type === 'BUY') {
      const extension = transaction.bondExtension;
      if (!extension) throw new Error(`Bond transaction ${transaction.id} is missing bondExtension.`);
      const accruedInterestPerBond = asDecimal(extension.accruedInterest, 'accruedInterest');
      const accruedInterestTotal = accruedInterestPerBond.times(quantity);
      const totalCost = valueInTHB(transaction).plus(accruedInterestTotal);
      lots.push({
        transaction,
        quantityBought: quantity,
        quantityRemaining: quantity,
        costPerBondTHB: totalCost.dividedBy(quantity),
        realizedGLTHB: new MultiAssetDecimal(0),
      });
      lotsBySymbol.set(transaction.symbol, lots);
      continue;
    }

    const available = lots.reduce((sum, lot) => sum.plus(lot.quantityRemaining), new MultiAssetDecimal(0));
    if (quantity.gt(available)) {
      throw new Error(`Bond sale ${transaction.id} exceeds available FIFO quantity for ${transaction.symbol}.`);
    }
    const proceedsPerBond = valueInTHB(transaction).dividedBy(quantity);
    let remainingToSell = quantity;
    for (const lot of lots) {
      if (!remainingToSell.isPositive()) break;
      if (lot.quantityRemaining.isZero()) continue;
      const sold = MultiAssetDecimal.min(lot.quantityRemaining, remainingToSell);
      lot.quantityRemaining = lot.quantityRemaining.minus(sold);
      const realized = proceedsPerBond.minus(lot.costPerBondTHB).times(sold);
      lot.realizedGLTHB = lot.realizedGLTHB.plus(realized);
      remainingToSell = remainingToSell.minus(sold);
    }
  }

  const outputLots: MultiAssetLot[] = [];
  const positions: BondPositionSummary[] = [];
  const upcomingCoupons: Array<BondCouponPayment & { symbol: string }> = [];
  let totalCost = new MultiAssetDecimal(0);
  let totalMarket = new MultiAssetDecimal(0);
  let totalRealized = new MultiAssetDecimal(0);
  let totalUnrealized = new MultiAssetDecimal(0);
  let totalAccrued = new MultiAssetDecimal(0);
  let couponIncome = new MultiAssetDecimal(0);
  let couponWithholding = new MultiAssetDecimal(0);

  for (const transaction of bondTransactions) {
    if (transaction.type !== 'COUPON' && transaction.type !== 'INTEREST') continue;
    const netIncome = valueInTHB(transaction);
    const fx = transaction.fxRate ? asDecimal(transaction.fxRate, 'fxRate') : new MultiAssetDecimal(1);
    const fxMultiplier = transaction.originalCurrency.toUpperCase() === 'THB' ? new MultiAssetDecimal(1) : fx;
    const grossIncome = asDecimal(transaction.gross, 'gross').times(fxMultiplier);
    const fees = asDecimal(transaction.comm, 'comm').plus(asDecimal(transaction.vat, 'vat')).times(fxMultiplier);
    couponIncome = couponIncome.plus(netIncome);
    couponWithholding = couponWithholding.plus(
      Decimal.max(new MultiAssetDecimal(0), grossIncome.minus(netIncome).minus(fees)),
    );
  }

  for (const [symbol, lots] of lotsBySymbol) {
    const latest = latestBySymbol.get(symbol);
    if (!latest?.bondExtension) continue;
    const extension = latest.bondExtension;
    const openQuantity = lots.reduce((sum, lot) => sum.plus(lot.quantityRemaining), new MultiAssetDecimal(0));
    const positionCost = lots.reduce((sum, lot) => sum.plus(lot.quantityRemaining.times(lot.costPerBondTHB)), new MultiAssetDecimal(0));
    const lastPriceFx = latest.fxRate ? asDecimal(latest.fxRate, 'fxRate') : new MultiAssetDecimal(1);
    const marketPriceTHB = asDecimal(latest.price, 'price').times(
      latest.originalCurrency.toUpperCase() === 'THB' ? 1 : lastPriceFx,
    );
    const marketValue = marketPriceTHB.times(openQuantity);
    const unrealized = marketValue.minus(positionCost);
    const realized = lots.reduce((sum, lot) => sum.plus(lot.realizedGLTHB), new MultiAssetDecimal(0));
    const accrued = calculateBondAccruedInterest(extension, asOfDate);
    const accruedTotal = asDecimal(accrued.amountPerBondTHB).times(openQuantity);
    const schedule = generateBondCouponSchedule({
      faceValue: extension.faceValue,
      couponRate: extension.couponRate,
      paymentFrequency: extension.paymentFrequency,
      maturityDate: extension.maturityDate,
      fromDate: asOfDate,
    }).filter((coupon) => coupon.date > asOfDate);
    const ytm = openQuantity.isPositive()
      ? calculateBondYieldToMaturity({
          faceValue: extension.faceValue,
          couponRate: extension.couponRate,
          paymentFrequency: extension.paymentFrequency,
          maturityDate: extension.maturityDate,
          settlementDate: asOfDate,
          cleanPrice: latest.price,
          accruedInterest: accrued.amountPerBondTHB,
        })
      : null;

    positions.push({
      symbol,
      issuer: extension.issuer ?? null,
      creditRating: extension.creditRating ?? null,
      quantity: openQuantity.toFixed(8),
      costBasisTHB: roundMoney(positionCost),
      marketValueTHB: roundMoney(marketValue),
      realizedGLTHB: roundMoney(realized),
      unrealizedGLTHB: roundMoney(unrealized),
      accruedInterestPerBondTHB: accrued.amountPerBondTHB,
      accruedInterestTotalTHB: roundMoney(accruedTotal),
      yieldToMaturity: ytm,
      nextCouponDate: schedule[0]?.date ?? null,
      couponSchedule: schedule,
    });
    upcomingCoupons.push(...schedule.slice(0, 4).map((coupon) => ({ ...coupon, symbol })));

    for (const lot of lots) {
      const quantitySold = lot.quantityBought.minus(lot.quantityRemaining);
      const lotMarketGL = marketPriceTHB.minus(lot.costPerBondTHB).times(lot.quantityRemaining);
      const daysHeld = Math.max(0, daysBetween(lot.transaction.date, dateOnly(asOfDate)));
      outputLots.push({
        id: lot.transaction.id,
        transactionId: lot.transaction.id,
        symbol,
        assetClass: 'BOND',
        buyQty: lot.quantityBought.toNumber(),
        costPerUnit: roundMoney(lot.costPerBondTHB),
        qtySold: quantitySold.toNumber(),
        qtyRemain: lot.quantityRemaining.toNumber(),
        realizedGL: roundMoney(lot.realizedGLTHB),
        unrealizedGL: roundMoney(lotMarketGL),
        status: lot.quantityRemaining.isZero() ? 'Sold' : quantitySold.isZero() ? 'Hold' : 'Partial',
        daysHeld,
        bondLotData: {
          faceValue: extension.faceValue,
          couponRate: extension.couponRate,
          maturityDate: extension.maturityDate,
        },
      });
    }

    totalCost = totalCost.plus(positionCost);
    totalMarket = totalMarket.plus(marketValue);
    totalRealized = totalRealized.plus(realized);
    totalUnrealized = totalUnrealized.plus(unrealized);
    totalAccrued = totalAccrued.plus(accruedTotal);
  }

  return {
    positions,
    lots: outputLots,
    totalCostBasisTHB: roundMoney(totalCost),
    totalMarketValueTHB: roundMoney(totalMarket),
    totalRealizedGLTHB: roundMoney(totalRealized),
    totalUnrealizedGLTHB: roundMoney(totalUnrealized),
    totalAccruedInterestTHB: roundMoney(totalAccrued),
    couponIncomeTHB: roundMoney(couponIncome),
    couponWithholdingTaxTHB: roundMoney(couponWithholding),
    upcomingCoupons: upcomingCoupons.sort((a, b) => a.date.localeCompare(b.date)),
  };
}
