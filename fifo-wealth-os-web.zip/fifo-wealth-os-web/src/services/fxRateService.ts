export interface FXRateProvider {
  /**
   * Returns the historical FX conversion rate as an exact decimal string
   * to convert 1 unit of `baseCurrency` (source currency, e.g. 'USD')
   * into `targetCurrency` (destination currency, e.g. 'THB') on `date`.
   */
  getHistoricalRate(
    baseCurrency: string,
    targetCurrency: string,
    date: string
  ): Promise<string>;
}

export type HistoricalRateTable = Record<string, Record<string, string>>;

const DEFAULT_MOCK_FX_RATES: HistoricalRateTable = {
  '2024-10-01': {
    'USD/THB': '36.75',
  },
  '2024-10-02': {
    'USD/THB': '36.80',
  },
  '2024-10-09': {
    'USD/THB': '36.50',
  },
  '2024-10-10': {
    'USD/THB': '36.60',
  },
};

/**
 * Normalizes any ISO or YYYY-MM-DD date string to a 'YYYY-MM-DD' lookup key.
 */
export function normalizeFXDateKey(rawDate: string): string {
  const trimmed = rawDate.trim();
  const isoPrefixMatch = /^(\d{4}-\d{2}-\d{2})/.exec(trimmed);
  if (isoPrefixMatch && isoPrefixMatch[1]) {
    const parsed = Date.parse(isoPrefixMatch[1]);
    if (!Number.isNaN(parsed)) {
      return isoPrefixMatch[1];
    }
  }

  const parsedDate = new Date(trimmed);
  if (Number.isNaN(parsedDate.getTime())) {
    throw new Error(`Invalid date "${rawDate}" supplied to FXRateProvider.`);
  }

  return parsedDate.toISOString().slice(0, 10);
}

/**
 * Deterministic Mock FX Rate Provider for testing and offline simulation.
 */
export class MockFXRateProvider implements FXRateProvider {
  private readonly ratesByDate: HistoricalRateTable;

  constructor(customRates?: HistoricalRateTable) {
    this.ratesByDate = {};

    for (const [dateKey, pairs] of Object.entries(DEFAULT_MOCK_FX_RATES)) {
      this.ratesByDate[dateKey] = { ...pairs };
    }

    if (customRates) {
      for (const [dateKey, pairs] of Object.entries(customRates)) {
        this.ratesByDate[dateKey] = {
          ...(this.ratesByDate[dateKey] ?? {}),
          ...pairs,
        };
      }
    }
  }

  public async getHistoricalRate(
    baseCurrency: string,
    targetCurrency: string,
    date: string
  ): Promise<string> {
    const from = baseCurrency.trim().toUpperCase();
    const to = targetCurrency.trim().toUpperCase();

    if (!from || !to) {
      throw new Error('Currency codes must be non-empty strings.');
    }

    // Validate date format even for identical currency pairs
    const dateKey = normalizeFXDateKey(date);

    // Identical currency pair (e.g. THB/THB) always returns '1.00'
    if (from === to) {
      return '1.00';
    }

    const pairKey = `${from}/${to}`;
    const rate = this.ratesByDate[dateKey]?.[pairKey];

    if (rate === undefined) {
      throw new Error(
        `Historical FX rate not found for pair "${pairKey}" on date "${dateKey}".`
      );
    }

    return rate;
  }
}
