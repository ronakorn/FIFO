import Decimal from 'decimal.js';

export const OptDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

const A_S_P = new OptDecimal('0.2316419');
const A_S_COEFFICIENTS = [
  new OptDecimal('0.319381530'),
  new OptDecimal('-0.356563782'),
  new OptDecimal('1.781477937'),
  new OptDecimal('-1.821255978'),
  new OptDecimal('1.330274429'),
] as const;
const SQRT_TWO_PI = new OptDecimal('6.283185307179586476925286766559005768394').sqrt();
const MIN_VOLATILITY = new OptDecimal('0.000001');
const MAX_VOLATILITY = new OptDecimal('5');

export interface BlackScholesInput {
  underlyingPrice: string;
  strikePrice: string;
  timeToExpiry: string;
  riskFreeRate: string;
  volatility: string;
  optionType: 'CALL' | 'PUT';
}

export interface BlackScholesResult {
  theoreticalPrice: string;
  delta: string;
  gamma: string;
  theta: string;
  vega: string;
  rho: string;
  impliedVolatility?: string;
}

interface InternalBlackScholesResult {
  theoreticalPrice: Decimal;
  delta: Decimal;
  gamma: Decimal;
  theta: Decimal;
  vega: Decimal;
  rho: Decimal;
}

function decimal(value: string, label: string): Decimal {
  try {
    const parsed = new OptDecimal(value);
    if (!parsed.isFinite()) throw new Error();
    return parsed;
  } catch {
    throw new Error(`${label} must be a finite decimal string.`);
  }
}

function positive(value: string, label: string): Decimal {
  const parsed = decimal(value, label);
  if (!parsed.gt(0)) throw new Error(`${label} must be greater than zero.`);
  return parsed;
}

function validateOptionType(optionType: string): asserts optionType is 'CALL' | 'PUT' {
  if (optionType !== 'CALL' && optionType !== 'PUT') throw new Error('optionType must be CALL or PUT.');
}

/** Standard normal probability density function φ(x). */
export function standardNormalPDF(x: Decimal): Decimal {
  const exponent = x.times(x).dividedBy(2).negated().exp();
  return exponent.dividedBy(SQRT_TWO_PI);
}

/**
 * Standard normal CDF using the Abramowitz & Stegun 26.2.17 approximation.
 * The approximation is symmetric and accurate to about 7.5e-8 over the real line.
 */
export function cumulativeNormalCDF(x: Decimal): Decimal {
  const z = x.abs();
  if (z.gte(8)) return x.isNegative() ? new OptDecimal(0) : new OptDecimal(1);
  const t = new OptDecimal(1).dividedBy(new OptDecimal(1).plus(A_S_P.times(z)));
  const polynomial = A_S_COEFFICIENTS.reduce(
    (sum, coefficient, index) => sum.plus(coefficient.times(t.pow(index + 1))),
    new OptDecimal(0),
  );
  const upperTail = standardNormalPDF(z).times(polynomial);
  const positiveCdf = new OptDecimal(1).minus(upperTail);
  return x.isNegative() ? upperTail : positiveCdf;
}

function intrinsicValue(underlying: Decimal, strike: Decimal, optionType: 'CALL' | 'PUT'): Decimal {
  return optionType === 'CALL'
    ? OptDecimal.max(underlying.minus(strike), 0)
    : OptDecimal.max(strike.minus(underlying), 0);
}

function calculateBlackScholes(input: BlackScholesInput): InternalBlackScholesResult {
  validateOptionType(input.optionType);
  const underlying = positive(input.underlyingPrice, 'underlyingPrice');
  const strike = positive(input.strikePrice, 'strikePrice');
  const time = decimal(input.timeToExpiry, 'timeToExpiry');
  const riskFreeRate = decimal(input.riskFreeRate, 'riskFreeRate');
  const volatility = positive(input.volatility, 'volatility');
  if (time.isNegative()) throw new Error('timeToExpiry cannot be negative.');
  if (time.gt(100)) throw new Error('timeToExpiry cannot exceed 100 years.');
  if (volatility.gt(MAX_VOLATILITY)) throw new Error('volatility cannot exceed 5.0 (500%).');

  if (time.isZero()) {
    const cmp = underlying.comparedTo(strike);
    const delta = input.optionType === 'CALL'
      ? cmp > 0 ? new OptDecimal(1) : cmp < 0 ? new OptDecimal(0) : new OptDecimal('0.5')
      : cmp < 0 ? new OptDecimal(-1) : cmp > 0 ? new OptDecimal(0) : new OptDecimal('-0.5');
    return {
      theoreticalPrice: intrinsicValue(underlying, strike, input.optionType),
      delta,
      gamma: new OptDecimal(0),
      theta: new OptDecimal(0),
      vega: new OptDecimal(0),
      rho: new OptDecimal(0),
    };
  }

  const sqrtTime = time.sqrt();
  const discount = riskFreeRate.times(time).negated().exp();
  const sigmaSqrtTime = volatility.times(sqrtTime);
  const d1 = underlying.dividedBy(strike).ln()
    .plus(riskFreeRate.plus(volatility.pow(2).dividedBy(2)).times(time))
    .dividedBy(sigmaSqrtTime);
  const d2 = d1.minus(sigmaSqrtTime);
  const cdfD1 = cumulativeNormalCDF(d1);
  const cdfD2 = cumulativeNormalCDF(d2);
  const cdfMinusD1 = cumulativeNormalCDF(d1.negated());
  const cdfMinusD2 = cumulativeNormalCDF(d2.negated());
  const pdfD1 = standardNormalPDF(d1);

  const theoreticalPrice = input.optionType === 'CALL'
    ? underlying.times(cdfD1).minus(strike.times(discount).times(cdfD2))
    : strike.times(discount).times(cdfMinusD2).minus(underlying.times(cdfMinusD1));
  const delta = input.optionType === 'CALL' ? cdfD1 : cdfD1.minus(1);
  const gamma = pdfD1.dividedBy(underlying.times(sigmaSqrtTime));
  const commonTheta = underlying.times(pdfD1).times(volatility).negated().dividedBy(new OptDecimal(2).times(sqrtTime));
  const theta = input.optionType === 'CALL'
    ? commonTheta.minus(riskFreeRate.times(strike).times(discount).times(cdfD2))
    : commonTheta.plus(riskFreeRate.times(strike).times(discount).times(cdfMinusD2));
  const vega = underlying.times(pdfD1).times(sqrtTime);
  const rho = input.optionType === 'CALL'
    ? strike.times(time).times(discount).times(cdfD2)
    : strike.times(time).times(discount).times(cdfMinusD2).negated();

  return { theoreticalPrice, delta, gamma, theta, vega, rho };
}

function rounded(value: Decimal, decimalPlaces: number): string {
  return value.toDecimalPlaces(decimalPlaces, OptDecimal.ROUND_HALF_UP).toFixed(decimalPlaces);
}

/** Black-Scholes European option price and annualized Greeks. Vega and rho are per 1.00 rate/vol change. */
export function blackScholesPrice(input: BlackScholesInput): BlackScholesResult {
  const result = calculateBlackScholes(input);
  return {
    theoreticalPrice: rounded(result.theoreticalPrice, 4),
    delta: rounded(result.delta, 4),
    gamma: rounded(result.gamma, 6),
    theta: rounded(result.theta, 4),
    vega: rounded(result.vega, 4),
    rho: rounded(result.rho, 4),
  };
}

export interface ImpliedVolatilityInput extends Omit<BlackScholesInput, 'volatility'> {
  marketPrice: string;
}

/** Solve implied volatility with Newton-Raphson, safeguarded by a volatility bracket/bisection fallback. */
export function calculateImpliedVolatility(
  marketPrice: string,
  underlyingPrice: string,
  strikePrice: string,
  timeToExpiry: string,
  riskFreeRate: string,
  optionType: 'CALL' | 'PUT',
): string {
  validateOptionType(optionType);
  const target = decimal(marketPrice, 'marketPrice');
  const underlying = positive(underlyingPrice, 'underlyingPrice');
  const strike = positive(strikePrice, 'strikePrice');
  const time = positive(timeToExpiry, 'timeToExpiry');
  const rate = decimal(riskFreeRate, 'riskFreeRate');
  if (target.isNegative()) throw new Error('marketPrice cannot be negative.');
  if (time.gt(100)) throw new Error('timeToExpiry cannot exceed 100 years.');

  const discountedStrike = strike.times(rate.times(time).negated().exp());
  const lowerBound = intrinsicValue(underlying, discountedStrike, optionType);
  const upperBound = optionType === 'CALL' ? underlying : discountedStrike;
  const tolerance = new OptDecimal('0.00000001');
  if (target.plus(tolerance).lt(lowerBound) || target.minus(tolerance).gt(upperBound)) {
    throw new Error('marketPrice is outside the no-arbitrage bounds for this option.');
  }
  if (target.minus(lowerBound).abs().lte(tolerance)) return rounded(MIN_VOLATILITY, 6);

  let low = MIN_VOLATILITY;
  let high = MAX_VOLATILITY;
  let volatility = new OptDecimal('0.30');
  const maxIterations = 120;

  for (let iteration = 0; iteration < maxIterations; iteration += 1) {
    const model = calculateBlackScholes({
      underlyingPrice,
      strikePrice,
      timeToExpiry,
      riskFreeRate,
      volatility: volatility.toString(),
      optionType,
    });
    const priceDifference = model.theoreticalPrice.minus(target);
    if (priceDifference.abs().lte(tolerance)) return rounded(volatility, 6);

    if (priceDifference.gt(0)) high = OptDecimal.min(high, volatility);
    else low = OptDecimal.max(low, volatility);

    const newtonCandidate = model.vega.gt(0)
      ? volatility.minus(priceDifference.dividedBy(model.vega))
      : new OptDecimal(-1);
    const candidate = newtonCandidate.gt(low) && newtonCandidate.lt(high)
      ? newtonCandidate
      : low.plus(high).dividedBy(2);
    if (candidate.minus(volatility).abs().lte(new OptDecimal('0.000000000001'))) break;
    volatility = candidate;
  }

  const finalModel = calculateBlackScholes({
    underlyingPrice,
    strikePrice,
    timeToExpiry,
    riskFreeRate,
    volatility: volatility.toString(),
    optionType,
  });
  if (finalModel.theoreticalPrice.minus(target).abs().lte(new OptDecimal('0.000001'))) {
    return rounded(volatility, 6);
  }
  throw new Error('Implied volatility did not converge within 120 iterations.');
}

export interface OptionPayoffInput {
  optionType: 'CALL' | 'PUT';
  strikePrice: string;
  underlyingPriceAtExpiry: string;
  premium: string;
  contractSize: number;
}

/** Net expiration payoff in the premium/strike currency, multiplied by the number of underlying units. */
export function calculateOptionPayoff(
  optionType: 'CALL' | 'PUT',
  strikePrice: string,
  underlyingPriceAtExpiry: string,
  premium: string,
  contractSize: number,
): string {
  validateOptionType(optionType);
  const strike = positive(strikePrice, 'strikePrice');
  const underlying = decimal(underlyingPriceAtExpiry, 'underlyingPriceAtExpiry');
  const premiumPerUnit = decimal(premium, 'premium');
  const size = new OptDecimal(String(contractSize));
  if (underlying.isNegative()) throw new Error('underlyingPriceAtExpiry cannot be negative.');
  if (premiumPerUnit.isNegative()) throw new Error('premium cannot be negative.');
  if (!size.isFinite() || !size.gt(0) || !size.isInteger()) {
    throw new Error('contractSize must be a positive whole number.');
  }
  const intrinsic = intrinsicValue(underlying, strike, optionType);
  return rounded(intrinsic.minus(premiumPerUnit).times(size), 2);
}
