import Decimal from 'decimal.js';
import { getPrismaClient } from '../db/prisma';

/** All THB arithmetic for donation rewards and community totals uses precision 40. */
export const DonationDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export const COMMUNITY_FUNDRAISING_BASELINE_THB = '127450.00';
export const COMMUNITY_FUNDRAISING_TARGET_THB = '500000.00';
export const DONOR_PRO_YEAR_THRESHOLD_THB = '2784.00';
export const DONOR_PRO_YEAR_DURATION_MONTHS = 12;

function money(value: Decimal.Value): Decimal {
  return new DonationDecimal(value);
}

function canonicalTHB(value: Decimal): string {
  return value.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
}

export async function getCommunityFundraisingStats() {
  const prisma = getPrismaClient();
  const successfulDonations = await prisma.donation.findMany({
    where: { status: 'SUCCEEDED' },
    select: { amountTHB: true, userId: true },
  });

  const donationsTotal = successfulDonations.reduce(
    (sum, donation) => sum.plus(money(donation.amountTHB)),
    money(0)
  );
  const baseline = money(COMMUNITY_FUNDRAISING_BASELINE_THB);
  const target = money(COMMUNITY_FUNDRAISING_TARGET_THB);
  const totalRaised = baseline.plus(donationsTotal);
  const rawRemaining = target.minus(totalRaised);
  const remaining = rawRemaining.isNegative() ? money(0) : rawRemaining;
  const rawProgress = target.isZero() ? money(0) : totalRaised.dividedBy(target).times(100);
  const progress = rawProgress.isNegative()
    ? money(0)
    : rawProgress.greaterThan(100)
      ? money(100)
      : rawProgress;
  const progressPercentage = progress.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);

  return {
    currency: 'THB' as const,
    baselineTHB: canonicalTHB(baseline),
    successfulDonationsTHB: canonicalTHB(donationsTotal),
    totalRaisedTHB: canonicalTHB(totalRaised),
    targetTHB: canonicalTHB(target),
    remainingTHB: canonicalTHB(remaining),
    progressPercentage,
    successfulDonationCount: successfulDonations.length,
    recordedDonorCount: new Set(successfulDonations.map((donation) => donation.userId)).size,
  };
}

export async function getUserDonationRewardStatus(userId: string) {
  const prisma = getPrismaClient();
  const [successfulDonations, user] = await Promise.all([
    prisma.donation.findMany({
      where: { userId, status: 'SUCCEEDED' },
      select: { amountTHB: true },
    }),
    prisma.user.findUnique({
      where: { id: userId },
      select: { proYearRewardQualifiedAt: true },
    }),
  ]);

  const donated = successfulDonations.reduce(
    (sum, donation) => sum.plus(money(donation.amountTHB)),
    money(0)
  );
  const threshold = money(DONOR_PRO_YEAR_THRESHOLD_THB);
  const eligible = donated.gte(threshold);
  let qualifiedAt = user?.proYearRewardQualifiedAt ?? null;

  // Persist the qualification once, without a claim flow. Activation is deliberately
  // deferred until subscription billing officially opens; this route never charges.
  if (eligible && user && !qualifiedAt) {
    const now = new Date();
    await prisma.user.updateMany({
      where: { id: userId, proYearRewardQualifiedAt: null },
      data: { proYearRewardQualifiedAt: now },
    });
    const refreshed = await prisma.user.findUnique({
      where: { id: userId },
      select: { proYearRewardQualifiedAt: true },
    });
    qualifiedAt = refreshed?.proYearRewardQualifiedAt ?? now;
  }

  const rawRemaining = threshold.minus(donated);
  const remaining = rawRemaining.isNegative() ? money(0) : rawRemaining;

  return {
    currency: 'THB' as const,
    donatedTHB: canonicalTHB(donated),
    thresholdTHB: canonicalTHB(threshold),
    remainingTHB: canonicalTHB(remaining),
    eligible,
    qualifiedAt: qualifiedAt?.toISOString() ?? null,
    durationMonths: DONOR_PRO_YEAR_DURATION_MONTHS,
    status: eligible ? 'QUEUED_FOR_SUBSCRIPTION_LAUNCH' as const : 'IN_PROGRESS' as const,
    startsWhen: 'SUBSCRIPTION_LAUNCH' as const,
    autoGranted: eligible,
  };
}
