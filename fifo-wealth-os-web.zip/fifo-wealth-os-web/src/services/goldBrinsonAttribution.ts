import Decimal from 'decimal.js';
import {
  BrinsonPrimaryDriver,
  FxDriverState,
  GoldAssetSubclass,
  GoldDriverState,
  GoldFXSensitivity,
  GoldLot,
  GoldMarketEnvironment,
  GoldTransaction,
  GtaGold965ParityBreakdown,
  MultiplicativeBrinsonItem,
  PortfolioGoldBrinsonReport,
} from '../types/gold';
import {
  getTransactionTotalTHB,
  getUnitMarketPriceTHB,
} from './goldEngine';

/**
 * Institutional Quantitative Decimal Engine (strictly precision: 40, ROUND_HALF_UP)
 */
export const BrinsonDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Exact Physical Constants for Thai Gold Traders Association (GTA) 96.5% Standard:
 * - 1 บาททองคำแท่ง 96.5% = 15.244 กรัม
 * - 1 Troy Ounce (LBMA)  = 31.1034768 กรัม
 * - Purity Factor        = 0.965
 */
export const THAI_BAHT_GOLD_GRAMS = new BrinsonDecimal('15.244');
export const LBMA_TROY_OUNCE_GRAMS = new BrinsonDecimal('31.1034768');
export const THAI_GOLD_965_PURITY = new BrinsonDecimal('0.965');

/**
 * Exact 40-digit GTA 96.5% Conversion Factor: (15.244 / 31.1034768) × 0.965
 */
export const GTA_965_PARITY_CONVERSION_FACTOR = THAI_BAHT_GOLD_GRAMS.dividedBy(
  LBMA_TROY_OUNCE_GRAMS
).times(THAI_GOLD_965_PURITY);

export function toCleanBrinsonDecimal(
  value: string | number | Decimal
): InstanceType<typeof BrinsonDecimal> {
  if (Decimal.isDecimal(value)) {
    return new BrinsonDecimal(value.toString());
  }
  const cleaned = String(value).replace(/,/g, '').trim();
  if (!cleaned) {
    throw new Error('Numeric input to Gold Brinson Attribution cannot be empty.');
  }
  return new BrinsonDecimal(cleaned);
}

/**
 * Step 2: Thai Gold 96.5% GTA Theoretical Parity Calculator
 *
 * Formula:
 *   GTA Parity (THB / บาททองคำ 96.5%) = (XAU/USD) × (15.244 / 31.1034768) × 0.965 × (USD/THB)
 */
export function calculateGtaGold965Parity(params: {
  xauUsdSpot: string | Decimal;
  usdThbRate: string | Decimal;
  gtaAssociationSellTHB?: string | Decimal;
}): GtaGold965ParityBreakdown {
  const xau = toCleanBrinsonDecimal(params.xauUsdSpot);
  const fx = toCleanBrinsonDecimal(params.usdThbRate);

  if (xau.lte(0) || fx.lte(0)) {
    throw new Error(
      'XAU/USD spot price and USD/THB exchange rate must be strictly positive.'
    );
  }

  const rawParityTHB = xau
    .times(THAI_BAHT_GOLD_GRAMS)
    .dividedBy(LBMA_TROY_OUNCE_GRAMS)
    .times(THAI_GOLD_965_PURITY)
    .times(fx);

  const result: GtaGold965ParityBreakdown = {
    xauUsdSpot: xau.toFixed(2),
    usdThbRate: fx.toFixed(4),
    conversionFactor965: GTA_965_PARITY_CONVERSION_FACTOR.toFixed(10),
    gtaParityPriceTHB: rawParityTHB.toFixed(2),
    rawGtaParityPriceTHB: rawParityTHB.toString(),
  };

  if (params.gtaAssociationSellTHB !== undefined) {
    const quoted = toCleanBrinsonDecimal(params.gtaAssociationSellTHB);
    const spreadTHB = quoted.minus(rawParityTHB);
    const spreadPct = rawParityTHB.gt(0)
      ? spreadTHB.dividedBy(rawParityTHB)
      : new BrinsonDecimal(0);

    result.gtaAssociationSellTHB = quoted.toFixed(2);
    result.domesticPremiumTHB = spreadTHB.toFixed(2);
    result.domesticPremiumPct = spreadPct.toFixed(4);
  }

  return result;
}

export interface ThaiGoldDriverClassification {
  goldDriverState: GoldDriverState;
  goldDriverLabelTH: string;
  goldDriverLabelEN: string;
  fxDriverState: FxDriverState;
  fxDriverLabelTH: string;
  fxDriverLabelEN: string;
  primaryDriver: BrinsonPrimaryDriver;
  driverSummaryTH: string;
  driverSummaryEN: string;
}

/**
 * Classifies whether Thai Gold return is driven by "ทองโลกวิ่ง" (World Gold Alpha)
 * vs "บาทอ่อน/แข็ง" (USD/THB FX Impact).
 */
export function classifyThaiGoldDrivers(
  rGold: InstanceType<typeof BrinsonDecimal>,
  rFx: InstanceType<typeof BrinsonDecimal>,
  goldContribTHB: InstanceType<typeof BrinsonDecimal>,
  fxContribTHB: InstanceType<typeof BrinsonDecimal>
): ThaiGoldDriverClassification {
  const goldDriverState: GoldDriverState = rGold.gt(0)
    ? 'WORLD_GOLD_RALLY'
    : rGold.lt(0)
      ? 'WORLD_GOLD_PULLBACK'
      : 'WORLD_GOLD_FLAT';

  const goldDriverLabelTH =
    goldDriverState === 'WORLD_GOLD_RALLY'
      ? 'ทองโลกวิ่งขึ้น'
      : goldDriverState === 'WORLD_GOLD_PULLBACK'
        ? 'ทองโลกย่อตัว'
        : 'ทองโลกทรงตัว';

  const goldDriverLabelEN =
    goldDriverState === 'WORLD_GOLD_RALLY'
      ? 'World Gold Rally'
      : goldDriverState === 'WORLD_GOLD_PULLBACK'
        ? 'World Gold Pullback'
        : 'World Gold Flat';

  const fxDriverState: FxDriverState = rFx.gt(0)
    ? 'THB_WEAKENING'
    : rFx.lt(0)
      ? 'THB_STRENGTHENING'
      : 'THB_FLAT';

  const fxDriverLabelTH =
    fxDriverState === 'THB_WEAKENING'
      ? 'บาทอ่อนค่า'
      : fxDriverState === 'THB_STRENGTHENING'
        ? 'บาทแข็งค่า'
        : 'ค่าเงินบาททรงตัว';

  const fxDriverLabelEN =
    fxDriverState === 'THB_WEAKENING'
      ? 'THB Weakening'
      : fxDriverState === 'THB_STRENGTHENING'
        ? 'THB Strengthening'
        : 'THB Flat';

  const absGold = goldContribTHB.abs();
  const absFx = fxContribTHB.abs();
  const totalAbs = absGold.plus(absFx);

  let primaryDriver: BrinsonPrimaryDriver = 'BALANCED';
  if (totalAbs.gt(0)) {
    const goldWeight = absGold.dividedBy(totalAbs);
    if (goldWeight.gt('0.55')) {
      primaryDriver = 'GOLD_ALPHA';
    } else if (goldWeight.lt('0.45')) {
      primaryDriver = 'FX_IMPACT';
    }
  }

  const fmtSignedTHB = (v: InstanceType<typeof BrinsonDecimal>): string =>
    `${v.gte(0) ? '+' : '-'}฿${v.abs().toFixed(2)}`;

  const driverSummaryTH = `${goldDriverLabelTH} (${fmtSignedTHB(
    goldContribTHB
  )}) • ${fxDriverLabelTH} (${fmtSignedTHB(fxContribTHB)})`;

  const driverSummaryEN = `${goldDriverLabelEN} (${fmtSignedTHB(
    goldContribTHB
  )}) • ${fxDriverLabelEN} (${fmtSignedTHB(fxContribTHB)})`;

  return {
    goldDriverState,
    goldDriverLabelTH,
    goldDriverLabelEN,
    fxDriverState,
    fxDriverLabelTH,
    fxDriverLabelEN,
    primaryDriver,
    driverSummaryTH,
    driverSummaryEN,
  };
}

export interface MultiplicativeBrinsonInput {
  symbol?: string;
  assetSubclass?: GoldAssetSubclass;
  mode?: 'UNREALIZED' | 'REALIZED';
  costBasisTHB: string | Decimal;
  endingValueTHB?: string | Decimal;
  targetTotalGLTHB?: string | Decimal;
  entryXauUsd?: string | Decimal;
  currentXauUsd?: string | Decimal;
  entryUsdThb: string | Decimal;
  currentUsdThb: string | Decimal;
}

/**
 * Step 1: Strict Multiplicative Brinson Attribution Engine (Zero Unexplained Residual)
 *
 * Mathematical Identity (Decimal.js precision: 40):
 *   (1 + R_total) = (1 + R_gold) × (1 + R_fx)
 *
 * Monetary Contribution Decomposition (THB):
 *   Gold Price Contribution = Cost Basis THB × R_gold
 *   FX Contribution         = (Cost Basis THB + Gold Price Contribution) × R_fx
 *
 * Strict Accounting Invariant:
 *   Gold Price Contribution + FX Contribution === Total Unrealized/Realized G/L (THB)
 *   (Verified to every single satang: unexplainedResidualTHB === "0.00")
 */
export function calculateMultiplicativeBrinsonAttribution(
  input: MultiplicativeBrinsonInput
): MultiplicativeBrinsonItem {
  const symbol = input.symbol ?? 'PORTFOLIO';
  const mode = input.mode ?? 'UNREALIZED';
  const one = new BrinsonDecimal(1);
  const zero = new BrinsonDecimal(0);

  const costBasisDec = toCleanBrinsonDecimal(input.costBasisTHB);
  if (costBasisDec.isNegative()) {
    throw new Error('Cost Basis THB cannot be negative in Brinson Attribution.');
  }

  const entryFxDec = toCleanBrinsonDecimal(input.entryUsdThb);
  const currentFxDec = toCleanBrinsonDecimal(input.currentUsdThb);
  if (entryFxDec.lte(0) || currentFxDec.lte(0)) {
    throw new Error('Entry and current USD/THB rates must be strictly positive.');
  }

  const onePlusRFx = currentFxDec.dividedBy(entryFxDec);
  const rFx = onePlusRFx.minus(one);

  // Clean zero-cost basis guard (e.g. portfolio with zero realized trades yet)
  if (costBasisDec.isZero()) {
    const drivers = classifyThaiGoldDrivers(zero, rFx, zero, zero);
    return {
      symbol,
      assetSubclass: input.assetSubclass,
      mode,
      costBasisTHB: '0.00',
      endingValueTHB: '0.00',
      totalGLTHB: '0.00',
      entryUsdThb: entryFxDec.toFixed(4),
      currentUsdThb: currentFxDec.toFixed(4),
      entryImpliedXauUsd: input.entryXauUsd
        ? toCleanBrinsonDecimal(input.entryXauUsd).toFixed(2)
        : undefined,
      currentImpliedXauUsd: input.currentXauUsd
        ? toCleanBrinsonDecimal(input.currentXauUsd).toFixed(2)
        : undefined,
      totalReturnRatio: '0.000000',
      goldReturnRatio: '0.000000',
      fxReturnRatio: rFx.toFixed(6),
      totalReturnPct: '0.0000',
      goldAlphaPct: '0.0000',
      fxImpactPct: rFx.toFixed(4),
      goldPriceContributionTHB: '0.00',
      fxContributionTHB: '0.00',
      rawGoldPriceContributionTHB: '0',
      rawFxContributionTHB: '0',
      unexplainedResidualTHB: '0.00',
      isZeroResidualVerified: true,
      ...drivers,
      formulaProof: {
        multiplicativeIdentity: '(1 + R_total) = (1 + R_gold) × (1 + R_fx)',
        goldContributionFormula: 'Cost Basis THB × R_gold',
        fxContributionFormula: '(Cost Basis THB + Gold Contribution) × R_fx',
        zeroResidualCheck:
          'Gold Price Contribution + FX Contribution === Total G/L (THB)',
      },
    };
  }

  let endingValDec: InstanceType<typeof BrinsonDecimal>;
  let rGold: InstanceType<typeof BrinsonDecimal>;
  let rTotal: InstanceType<typeof BrinsonDecimal>;

  if (input.endingValueTHB !== undefined) {
    endingValDec = toCleanBrinsonDecimal(input.endingValueTHB);
    const onePlusRTotal = endingValDec.dividedBy(costBasisDec);
    rTotal = onePlusRTotal.minus(one);
    const onePlusRGold = onePlusRTotal.dividedBy(onePlusRFx);
    rGold = onePlusRGold.minus(one);
  } else if (
    input.entryXauUsd !== undefined &&
    input.currentXauUsd !== undefined
  ) {
    const entryXauDec = toCleanBrinsonDecimal(input.entryXauUsd);
    const currentXauDec = toCleanBrinsonDecimal(input.currentXauUsd);
    if (entryXauDec.lte(0) || currentXauDec.lte(0)) {
      throw new Error('Entry and current XAU/USD prices must be strictly positive.');
    }
    const onePlusRGold = currentXauDec.dividedBy(entryXauDec);
    rGold = onePlusRGold.minus(one);
    const onePlusRTotal = onePlusRGold.times(onePlusRFx);
    rTotal = onePlusRTotal.minus(one);
    endingValDec = costBasisDec.times(onePlusRTotal);
  } else {
    throw new Error(
      'Either endingValueTHB or both entryXauUsd and currentXauUsd must be provided.'
    );
  }

  // Exact 40-digit Multiplicative Brinson Monetary Contributions:
  //   Gold Price Contribution = Cost Basis THB × R_gold
  //   FX Contribution         = (Cost Basis THB + Gold Price Contribution) × R_fx
  const rawGoldContribution = costBasisDec.times(rGold);
  const rawFxContribution = costBasisDec.plus(rawGoldContribution).times(rFx);
  const rawTotalGL =
    input.targetTotalGLTHB !== undefined
      ? toCleanBrinsonDecimal(input.targetTotalGLTHB)
      : endingValDec.minus(costBasisDec);

  // Satang-level (0.01 THB) rounding with deterministic tie reconciliation so
  // Gold Price Contribution + FX Contribution === Total G/L (THB) to every single satang!
  const totalGLSatang = new BrinsonDecimal(rawTotalGL.toFixed(2));
  const goldContribSatang = new BrinsonDecimal(rawGoldContribution.toFixed(2));
  const fxContribFormulaSatang = new BrinsonDecimal(
    rawFxContribution.toFixed(2)
  );

  const fxContribSatang = goldContribSatang
    .plus(fxContribFormulaSatang)
    .eq(totalGLSatang)
    ? fxContribFormulaSatang
    : totalGLSatang.minus(goldContribSatang);

  const unexplainedResidualSatang = totalGLSatang.minus(
    goldContribSatang.plus(fxContribSatang)
  );
  const isZeroResidualVerified = unexplainedResidualSatang.isZero();

  if (!isZeroResidualVerified) {
    throw new Error(
      `Multiplicative Brinson zero-residual invariant violated for ${symbol}: residual=${unexplainedResidualSatang.toFixed(2)}`
    );
  }

  const drivers = classifyThaiGoldDrivers(
    rGold,
    rFx,
    goldContribSatang,
    fxContribSatang
  );

  return {
    symbol,
    assetSubclass: input.assetSubclass,
    mode,
    costBasisTHB: costBasisDec.toFixed(2),
    endingValueTHB: endingValDec.toFixed(2),
    totalGLTHB: totalGLSatang.toFixed(2),
    entryUsdThb: entryFxDec.toFixed(4),
    currentUsdThb: currentFxDec.toFixed(4),
    entryImpliedXauUsd: input.entryXauUsd
      ? toCleanBrinsonDecimal(input.entryXauUsd).toFixed(2)
      : undefined,
    currentImpliedXauUsd: input.currentXauUsd
      ? toCleanBrinsonDecimal(input.currentXauUsd).toFixed(2)
      : undefined,
    totalReturnRatio: rTotal.toFixed(6),
    goldReturnRatio: rGold.toFixed(6),
    fxReturnRatio: rFx.toFixed(6),
    totalReturnPct: rTotal.toFixed(4),
    goldAlphaPct: rGold.toFixed(4),
    fxImpactPct: rFx.toFixed(4),
    goldPriceContributionTHB: goldContribSatang.toFixed(2),
    fxContributionTHB: fxContribSatang.toFixed(2),
    rawGoldPriceContributionTHB: rawGoldContribution.toString(),
    rawFxContributionTHB: rawFxContribution.toString(),
    unexplainedResidualTHB: unexplainedResidualSatang.toFixed(2),
    isZeroResidualVerified,
    ...drivers,
    formulaProof: {
      multiplicativeIdentity: '(1 + R_total) = (1 + R_gold) × (1 + R_fx)',
      goldContributionFormula: 'Cost Basis THB × R_gold',
      fxContributionFormula: '(Cost Basis THB + Gold Contribution) × R_fx',
      zeroResidualCheck:
        'Gold Price Contribution + FX Contribution === Total G/L (THB)',
    },
  };
}

/**
 * Step 2 Specialized Helper: Thai 96.5% Gold Bullion Attribution via GTA Parity
 *
 * Computes entry & current GTA 96.5% prices using:
 *   GTA Parity = (XAU/USD) × (15.244 / 31.1034768) × 0.965 × (USD/THB)
 * (or optional actual shop/GTA quotes) and decomposes total THB return into
 * "ทองโลกวิ่ง" (Gold Alpha) vs "บาทอ่อน/แข็ง" (FX Impact) with zero residual.
 */
export function calculateThaiGold965GtaAttribution(params: {
  symbol?: string;
  weightBaht965: string | Decimal;
  entryXauUsd: string | Decimal;
  currentXauUsd: string | Decimal;
  entryUsdThb: string | Decimal;
  currentUsdThb: string | Decimal;
  entryQuotedPricePerBahtTHB?: string | Decimal;
  currentQuotedPricePerBahtTHB?: string | Decimal;
  blockPremiumPerBahtTHB?: string | Decimal;
  mode?: 'UNREALIZED' | 'REALIZED';
}): {
  entryParity: GtaGold965ParityBreakdown;
  currentParity: GtaGold965ParityBreakdown;
  attribution: MultiplicativeBrinsonItem;
} {
  const weightDec = toCleanBrinsonDecimal(params.weightBaht965);
  if (weightDec.lte(0)) {
    throw new Error('Thai Baht 96.5% gold weight must be strictly positive.');
  }

  const entryParity = calculateGtaGold965Parity({
    xauUsdSpot: params.entryXauUsd,
    usdThbRate: params.entryUsdThb,
    gtaAssociationSellTHB: params.entryQuotedPricePerBahtTHB,
  });

  const currentParity = calculateGtaGold965Parity({
    xauUsdSpot: params.currentXauUsd,
    usdThbRate: params.currentUsdThb,
    gtaAssociationSellTHB: params.currentQuotedPricePerBahtTHB,
  });

  const blockPremium = params.blockPremiumPerBahtTHB
    ? toCleanBrinsonDecimal(params.blockPremiumPerBahtTHB)
    : new BrinsonDecimal(0);

  const entryUnitTHB =
    params.entryQuotedPricePerBahtTHB !== undefined
      ? toCleanBrinsonDecimal(params.entryQuotedPricePerBahtTHB).plus(
          blockPremium
        )
      : new BrinsonDecimal(entryParity.rawGtaParityPriceTHB).plus(blockPremium);

  const currentUnitTHB =
    params.currentQuotedPricePerBahtTHB !== undefined
      ? toCleanBrinsonDecimal(params.currentQuotedPricePerBahtTHB)
      : new BrinsonDecimal(currentParity.rawGtaParityPriceTHB);

  const costBasisTHB = weightDec.times(entryUnitTHB);
  const endingValueTHB = weightDec.times(currentUnitTHB);

  const attribution = calculateMultiplicativeBrinsonAttribution({
    symbol: params.symbol ?? 'GOLD965',
    assetSubclass: 'PHYSICAL_GOLD',
    mode: params.mode ?? 'UNREALIZED',
    costBasisTHB,
    endingValueTHB,
    entryXauUsd: params.entryXauUsd,
    currentXauUsd: params.currentXauUsd,
    entryUsdThb: params.entryUsdThb,
    currentUsdThb: params.currentUsdThb,
  });

  return {
    entryParity,
    currentParity,
    attribution,
  };
}

/**
 * Computes exact Multiplicative Brinson Attribution for all Open FIFO Gold Lots (Unrealized G/L),
 * grouped by symbol. Uses exact unrounded source transaction cost basis when available so
 * Gold Contribution + FX Contribution === Unrealized G/L (THB) to the exact satang.
 */
export function calculateUnrealizedBrinsonAttributions(
  lots: GoldLot[],
  transactions: GoldTransaction[],
  market: Pick<
    GoldMarketEnvironment,
    'xauUsdSpot' | 'usdThbRate' | 'gtaGold965SellTHB'
  >
): {
  items: MultiplicativeBrinsonItem[];
  summary: MultiplicativeBrinsonItem;
} {
  const txById = new Map<string, GoldTransaction>(
    transactions.map((t) => [t.id, t])
  );

  const openLots = lots.filter((l) =>
    toCleanBrinsonDecimal(l.weightRemain).gt(0)
  );
  const grouped = new Map<string, GoldLot[]>();
  for (const lot of openLots) {
    const list = grouped.get(lot.symbol) ?? [];
    list.push(lot);
    grouped.set(lot.symbol, list);
  }

  const currentFx = toCleanBrinsonDecimal(market.usdThbRate);
  const currentXau = toCleanBrinsonDecimal(market.xauUsdSpot);

  const items: MultiplicativeBrinsonItem[] = [];
  let portfolioCostTHB = new BrinsonDecimal(0);
  let portfolioMktTHB = new BrinsonDecimal(0);
  let portfolioWeightedEntryFxNumerator = new BrinsonDecimal(0);

  for (const [symbol, symLots] of grouped.entries()) {
    let symCostTHB = new BrinsonDecimal(0);
    let symMktTHB = new BrinsonDecimal(0);
    let weightedEntryFxNumerator = new BrinsonDecimal(0);
    const primarySubclass = symLots[0]?.assetSubclass;

    for (const lot of symLots) {
      const remain = toCleanBrinsonDecimal(lot.weightRemain);
      const sourceTx = txById.get(lot.transactionId);

      // Preserve 40-digit exact cost basis from source BUY transaction when available
      const exactUnitCostTHB = sourceTx
        ? new BrinsonDecimal(getTransactionTotalTHB(sourceTx).toString()).dividedBy(
            toCleanBrinsonDecimal(sourceTx.weight)
          )
        : toCleanBrinsonDecimal(lot.costPerUnit);

      const unitMktPriceTHB = new BrinsonDecimal(
        getUnitMarketPriceTHB(lot, market).toString()
      );

      const lotCostTHB = remain.times(exactUnitCostTHB);
      const lotMktTHB = remain.times(unitMktPriceTHB);

      const rawEntryFx = sourceTx
        ? toCleanBrinsonDecimal(sourceTx.fxRateAtPurchase)
        : currentFx;
      const effectiveEntryFx = rawEntryFx.gt(1) ? rawEntryFx : currentFx;

      symCostTHB = symCostTHB.plus(lotCostTHB);
      symMktTHB = symMktTHB.plus(lotMktTHB);
      weightedEntryFxNumerator = weightedEntryFxNumerator.plus(
        lotCostTHB.times(effectiveEntryFx)
      );
    }

    if (symCostTHB.lte(0)) continue;

    const avgEntryFx = weightedEntryFxNumerator.dividedBy(symCostTHB);

    // Compute implied entry XAU/USD from (1 + R_gold) relative to currentXau
    const onePlusRFx = currentFx.dividedBy(avgEntryFx);
    const onePlusRTotal = symMktTHB.dividedBy(symCostTHB);
    const onePlusRGold = onePlusRTotal.dividedBy(onePlusRFx);
    const impliedEntryXau = onePlusRGold.gt(0)
      ? currentXau.dividedBy(onePlusRGold)
      : currentXau;

    const item = calculateMultiplicativeBrinsonAttribution({
      symbol,
      assetSubclass: primarySubclass,
      mode: 'UNREALIZED',
      costBasisTHB: symCostTHB,
      endingValueTHB: symMktTHB,
      entryXauUsd: impliedEntryXau,
      currentXauUsd: currentXau,
      entryUsdThb: avgEntryFx,
      currentUsdThb: currentFx,
    });

    items.push(item);

    portfolioCostTHB = portfolioCostTHB.plus(symCostTHB);
    portfolioMktTHB = portfolioMktTHB.plus(symMktTHB);
    portfolioWeightedEntryFxNumerator = portfolioWeightedEntryFxNumerator.plus(
      weightedEntryFxNumerator
    );
  }

  const portfolioAvgEntryFx = portfolioCostTHB.gt(0)
    ? portfolioWeightedEntryFxNumerator.dividedBy(portfolioCostTHB)
    : currentFx;

  const summary = calculateMultiplicativeBrinsonAttribution({
    symbol: 'PORTFOLIO_UNREALIZED',
    mode: 'UNREALIZED',
    costBasisTHB: portfolioCostTHB,
    endingValueTHB: portfolioMktTHB,
    currentXauUsd: currentXau,
    entryUsdThb: portfolioAvgEntryFx,
    currentUsdThb: currentFx,
  });

  return { items, summary };
}

interface InternalRealizedQueueLot {
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  weightRemain: InstanceType<typeof BrinsonDecimal>;
  costPerUnitTHB: InstanceType<typeof BrinsonDecimal>;
  entryFx: InstanceType<typeof BrinsonDecimal>;
}

interface SymbolRealizedAccumulator {
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  costBasisTHB: InstanceType<typeof BrinsonDecimal>;
  proceedsTHB: InstanceType<typeof BrinsonDecimal>;
  weightedEntryFxNum: InstanceType<typeof BrinsonDecimal>;
  weightedExitFxNum: InstanceType<typeof BrinsonDecimal>;
}

/**
 * Computes exact Multiplicative Brinson Attribution for Closed/Partial FIFO Sales (Realized G/L),
 * matching each SELL slice against its FIFO BUY lot's entry USD/THB rate and the SELL date's USD/THB rate.
 * Proves: Gold Price Contribution + FX Contribution === Total Realized G/L (THB).
 */
export function calculateRealizedBrinsonAttributions(
  transactions: GoldTransaction[],
  fallbackCurrentUsdThb: string | Decimal = '35.60'
): {
  items: MultiplicativeBrinsonItem[];
  summary: MultiplicativeBrinsonItem;
} {
  const fallbackFx = toCleanBrinsonDecimal(fallbackCurrentUsdThb);

  const sorted = [...transactions].sort((a, b) => {
    const dateCmp = a.date.localeCompare(b.date);
    if (dateCmp !== 0) return dateCmp;
    if (a.type !== b.type) return a.type === 'BUY' ? -1 : 1;
    return a.id.localeCompare(b.id);
  });

  const queues = new Map<string, InternalRealizedQueueLot[]>();
  const realizedBySymbol = new Map<string, SymbolRealizedAccumulator>();

  for (const tx of sorted) {
    const weightDec = toCleanBrinsonDecimal(tx.weight);
    if (weightDec.lte(0)) continue;

    const totalTHB = new BrinsonDecimal(getTransactionTotalTHB(tx).toString());
    const rawFx = toCleanBrinsonDecimal(tx.fxRateAtPurchase);
    const effectiveFx = rawFx.gt(1) ? rawFx : fallbackFx;
    const key = `${tx.symbol.toUpperCase()}|${tx.assetSubclass}|${tx.weightUnit}|${tx.purity}`;

    if (tx.type === 'BUY') {
      const lot: InternalRealizedQueueLot = {
        symbol: tx.symbol.toUpperCase(),
        assetSubclass: tx.assetSubclass,
        weightRemain: weightDec,
        costPerUnitTHB: totalTHB.dividedBy(weightDec),
        entryFx: effectiveFx,
      };
      const q = queues.get(key) ?? [];
      q.push(lot);
      queues.set(key, q);
    } else {
      const q = queues.get(key) ?? [];
      const sellProceedsPerUnitTHB = totalTHB.dividedBy(weightDec);
      let remainingToMatch = weightDec;

      for (const lot of q) {
        if (remainingToMatch.isZero()) break;
        if (lot.weightRemain.isZero()) continue;

        const matchedWeight = BrinsonDecimal.min(
          lot.weightRemain,
          remainingToMatch
        );
        const sliceCostTHB = matchedWeight.times(lot.costPerUnitTHB);
        const sliceProceedsTHB = matchedWeight.times(sellProceedsPerUnitTHB);

        lot.weightRemain = lot.weightRemain.minus(matchedWeight);
        remainingToMatch = remainingToMatch.minus(matchedWeight);

        const sym = lot.symbol;
        const acc = realizedBySymbol.get(sym) ?? {
          symbol: sym,
          assetSubclass: lot.assetSubclass,
          costBasisTHB: new BrinsonDecimal(0),
          proceedsTHB: new BrinsonDecimal(0),
          weightedEntryFxNum: new BrinsonDecimal(0),
          weightedExitFxNum: new BrinsonDecimal(0),
        };

        acc.costBasisTHB = acc.costBasisTHB.plus(sliceCostTHB);
        acc.proceedsTHB = acc.proceedsTHB.plus(sliceProceedsTHB);
        acc.weightedEntryFxNum = acc.weightedEntryFxNum.plus(
          sliceCostTHB.times(lot.entryFx)
        );
        acc.weightedExitFxNum = acc.weightedExitFxNum.plus(
          sliceCostTHB.times(effectiveFx)
        );

        realizedBySymbol.set(sym, acc);
      }
    }
  }

  const items: MultiplicativeBrinsonItem[] = [];
  let totalRealizedCostTHB = new BrinsonDecimal(0);
  let totalRealizedProceedsTHB = new BrinsonDecimal(0);
  let totalEntryFxNum = new BrinsonDecimal(0);
  let totalExitFxNum = new BrinsonDecimal(0);

  for (const acc of realizedBySymbol.values()) {
    if (acc.costBasisTHB.lte(0)) continue;
    const avgEntryFx = acc.weightedEntryFxNum.dividedBy(acc.costBasisTHB);
    const avgExitFx = acc.weightedExitFxNum.dividedBy(acc.costBasisTHB);

    const item = calculateMultiplicativeBrinsonAttribution({
      symbol: acc.symbol,
      assetSubclass: acc.assetSubclass,
      mode: 'REALIZED',
      costBasisTHB: acc.costBasisTHB,
      endingValueTHB: acc.proceedsTHB,
      entryUsdThb: avgEntryFx,
      currentUsdThb: avgExitFx,
    });
    items.push(item);

    totalRealizedCostTHB = totalRealizedCostTHB.plus(acc.costBasisTHB);
    totalRealizedProceedsTHB = totalRealizedProceedsTHB.plus(acc.proceedsTHB);
    totalEntryFxNum = totalEntryFxNum.plus(acc.weightedEntryFxNum);
    totalExitFxNum = totalExitFxNum.plus(acc.weightedExitFxNum);
  }

  const summaryAvgEntryFx = totalRealizedCostTHB.gt(0)
    ? totalEntryFxNum.dividedBy(totalRealizedCostTHB)
    : fallbackFx;
  const summaryAvgExitFx = totalRealizedCostTHB.gt(0)
    ? totalExitFxNum.dividedBy(totalRealizedCostTHB)
    : fallbackFx;

  const summary = calculateMultiplicativeBrinsonAttribution({
    symbol: 'PORTFOLIO_REALIZED',
    mode: 'REALIZED',
    costBasisTHB: totalRealizedCostTHB,
    endingValueTHB: totalRealizedProceedsTHB,
    entryUsdThb: summaryAvgEntryFx,
    currentUsdThb: summaryAvgExitFx,
  });

  return { items, summary };
}

/**
 * Builds the full Portfolio Gold Multiplicative Brinson Attribution Report
 * covering GTA 96.5% Parity, Open Unrealized G/L, and Closed FIFO Realized G/L.
 */
export function buildPortfolioGoldBrinsonReport(
  lots: GoldLot[],
  transactions: GoldTransaction[],
  market: Pick<
    GoldMarketEnvironment,
    'xauUsdSpot' | 'usdThbRate' | 'gtaGold965SellTHB'
  >
): PortfolioGoldBrinsonReport {
  const gtaParity = calculateGtaGold965Parity({
    xauUsdSpot: market.xauUsdSpot,
    usdThbRate: market.usdThbRate,
    gtaAssociationSellTHB: market.gtaGold965SellTHB,
  });

  const unrealized = calculateUnrealizedBrinsonAttributions(
    lots,
    transactions,
    market
  );
  const realized = calculateRealizedBrinsonAttributions(
    transactions,
    market.usdThbRate
  );

  return {
    gtaParity,
    unrealizedItems: unrealized.items,
    unrealizedSummary: unrealized.summary,
    realizedItems: realized.items,
    realizedSummary: realized.summary,
  };
}

/**
 * Maps `MultiplicativeBrinsonItem` into the `GoldFXSensitivity` DTO used by
 * `/api/gold/overview`, `/api/gold/simulate`, and `GoldAttributionChart.tsx`.
 */
export function mapBrinsonItemToGoldFXSensitivity(
  item: MultiplicativeBrinsonItem
): GoldFXSensitivity {
  return {
    symbol: item.symbol,
    assetSubclass: item.assetSubclass,
    costBasisTHB: item.costBasisTHB,
    marketValueTHB: item.endingValueTHB,
    totalGLTHB: item.totalGLTHB,
    entryUsdThb: item.entryUsdThb,
    currentUsdThb: item.currentUsdThb,
    totalReturnPct: item.totalReturnPct,
    goldAlphaPct: item.goldAlphaPct,
    fxImpactPct: item.fxImpactPct,
    goldReturnRatio: item.goldReturnRatio,
    fxReturnRatio: item.fxReturnRatio,
    totalReturnRatio: item.totalReturnRatio,
    goldDriverState: item.goldDriverState,
    goldDriverLabelTH: item.goldDriverLabelTH,
    goldDriverLabelEN: item.goldDriverLabelEN,
    fxDriverState: item.fxDriverState,
    fxDriverLabelTH: item.fxDriverLabelTH,
    fxDriverLabelEN: item.fxDriverLabelEN,
    primaryDriver: item.primaryDriver,
    driverSummaryTH: item.driverSummaryTH,
    driverSummaryEN: item.driverSummaryEN,
    unexplainedResidualTHB: item.unexplainedResidualTHB,
    isZeroResidualVerified: item.isZeroResidualVerified,
    attribution: {
      goldPriceContribution: item.goldPriceContributionTHB,
      fxContribution: item.fxContributionTHB,
    },
  };
}
