import Decimal from 'decimal.js';
import {
  Dividend,
  FIFOResult,
  SymbolTaxProfile,
  TaxEvent,
  TaxReport,
  ThaiTaxOptions,
} from '../types';

/**
 * Isolated IEEE 754-2008 decimal128 configuration (34 significant digits)
 * strictly used for all Thai Tax Compliance calculations (zero Number math).
 */
const Dec = Decimal.clone({
  precision: 34,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface ProgressiveTaxBracket {
  readonly minExclusive: string;
  readonly maxInclusive: string | null;
  readonly rate: string;
  readonly label: string;
}

/**
 * Official Thai Personal Income Tax (ภ.ง.ด. 90/91) Progressive Brackets (0% - 35%).
 * First 150,000 THB of net assessable income is exempt under Royal Decree No. 470.
 */
export const THAI_PIT_BRACKETS: readonly ProgressiveTaxBracket[] = [
  { minExclusive: '0', maxInclusive: '150000', rate: '0.00', label: '0 - 150,000 THB (Exempt 0%)' },
  { minExclusive: '150000', maxInclusive: '300000', rate: '0.05', label: '150,001 - 300,000 THB (5%)' },
  { minExclusive: '300000', maxInclusive: '500000', rate: '0.10', label: '300,001 - 500,000 THB (10%)' },
  { minExclusive: '500000', maxInclusive: '750000', rate: '0.15', label: '500,001 - 750,000 THB (15%)' },
  { minExclusive: '750000', maxInclusive: '1000000', rate: '0.20', label: '750,001 - 1,000,000 THB (20%)' },
  { minExclusive: '1000000', maxInclusive: '2000000', rate: '0.25', label: '1,000,001 - 2,000,000 THB (25%)' },
  { minExclusive: '2000000', maxInclusive: '5000000', rate: '0.30', label: '2,000,001 - 5,000,000 THB (30%)' },
  { minExclusive: '5000000', maxInclusive: null, rate: '0.35', label: 'Over 5,000,000 THB (35%)' },
];

/**
 * Final Tax Rounding helper (2 decimal places, ROUND_HALF_UP) per Thai Revenue Department standard.
 */
export function formatTaxAmount(value: Decimal): string {
  const rounded = value.toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
  const normalized = rounded.isZero() ? new Dec(0) : rounded;
  return normalized.toFixed(2);
}

/**
 * Computes exact Thai Personal Income Tax (before WHT credits) for a given net assessable income
 * strictly using `decimal.js`.
 */
export function calculateProgressivePIT(netAssessableIncome: Decimal): Decimal {
  if (netAssessableIncome.lte(0)) {
    return new Dec(0);
  }

  let totalTax = new Dec(0);

  for (const bracket of THAI_PIT_BRACKETS) {
    const lower = new Dec(bracket.minExclusive);
    if (netAssessableIncome.lte(lower)) {
      break;
    }

    const rate = new Dec(bracket.rate);
    const upper = bracket.maxInclusive !== null ? new Dec(bracket.maxInclusive) : null;
    const taxableInBracket =
      upper !== null
        ? Dec.min(netAssessableIncome, upper).minus(lower)
        : netAssessableIncome.minus(lower);

    if (taxableInBracket.gt(0) && rate.gt(0)) {
      totalTax = totalTax.plus(taxableInBracket.times(rate));
    }
  }

  return totalTax;
}

function isCapitalGainAssessable(symbol: string, options?: ThaiTaxOptions): boolean {
  const defaultCategory = options?.defaultCategory ?? 'FOREIGN_EQUITY';
  const defaultRemitted = options?.defaultRemittedToThailand ?? true;

  const profile: SymbolTaxProfile = options?.symbolProfiles?.[symbol] ?? {
    category: defaultCategory,
    remittedToThailand: defaultRemitted,
  };

  if (profile.category === 'THAI_EQUITY') {
    // Individual SET-listed Thai equity capital gains are exempt (Ministerial Reg. No. 126)
    return false;
  }

  if (profile.category === 'FOREIGN_EQUITY') {
    // Revenue Dept Order Por. 161/2566: assessable when remitted to Thailand in the tax year
    return profile.remittedToThailand ?? defaultRemitted;
  }

  // CRYPTO: assessable under Revenue Code Section 40(4)(h)
  return true;
}

/**
 * Core Thai Tax Compliance Engine for FIFO Wealth OS.
 *
 * Computes assessable Capital Gains (Section 40(4)) and Dividends (Section 40(4)(b)),
 * applies WHT tax credits, and calculates net tax payable/refundable under Thai progressive PIT rates.
 */
export function calculateThaiTax(
  fifoResult: FIFOResult,
  dividends: Dividend[],
  taxYear: number,
  options?: ThaiTaxOptions
): TaxReport {
  if (!Number.isInteger(taxYear) || taxYear < 1900 || taxYear > 3000) {
    throw new Error(`Invalid taxYear (${taxYear}): must be a valid four-digit calendar year.`);
  }

  const priorIncomeDec = options?.otherNetIncomeTHB
    ? new Dec(options.otherNetIncomeTHB.trim())
    : new Dec(0);

  if (!priorIncomeDec.isFinite() || priorIncomeDec.lt(0)) {
    throw new Error('otherNetIncomeTHB must be a non-negative decimal string.');
  }

  let runningCumulativeIncome = priorIncomeDec;

  // ---------------------------------------------------------------------------
  // 1. Capital Gains Processing
  // ---------------------------------------------------------------------------
  interface RawCapGainItem {
    id: string;
    date: string;
    symbol: string;
    realizedGLDec: Decimal;
    assessable: boolean;
  }

  const rawCapGainItems: RawCapGainItem[] = [];
  const soldLots = fifoResult.lots.filter((lot) => new Dec(lot.qtySold).gt(0));

  if (soldLots.length > 0) {
    for (const lot of soldLots) {
      const realizedGLDec = new Dec(lot.realizedGL);
      rawCapGainItems.push({
        id: `TAX-CG-${lot.id}`,
        date: lot.date,
        symbol: lot.symbol,
        realizedGLDec,
        assessable: isCapitalGainAssessable(lot.symbol, options),
      });
    }
  } else {
    const totalRealizedDec = new Dec(fifoResult.totalRealizedGL);
    if (!totalRealizedDec.isZero()) {
      rawCapGainItems.push({
        id: `TAX-CG-${taxYear}-SUMMARY`,
        date: `${taxYear}-12-31T00:00:00.000Z`,
        symbol: 'PORTFOLIO',
        realizedGLDec: totalRealizedDec,
        assessable: isCapitalGainAssessable('PORTFOLIO', options),
      });
    }
  }

  // Net assessable capital gains across eligible disposals cannot be < 0
  // (net capital losses cannot offset Section 40(4)(b) dividend or salary income).
  const rawAssessableCapGainSum = rawCapGainItems
    .filter((item) => item.assessable)
    .reduce((sum, item) => sum.plus(item.realizedGLDec), new Dec(0));

  const positiveAssessableCapGainSum = rawCapGainItems
    .filter((item) => item.assessable && item.realizedGLDec.gt(0))
    .reduce((sum, item) => sum.plus(item.realizedGLDec), new Dec(0));

  const netAssessableCapGainTotal = Dec.max(new Dec(0), rawAssessableCapGainSum);

  let remainingCapGainToAllocate = netAssessableCapGainTotal;
  const positiveItemsCount = rawCapGainItems.filter(
    (item) => item.assessable && item.realizedGLDec.gt(0)
  ).length;
  let seenPositiveIdx = 0;

  const capitalGainEvents: TaxEvent[] = [];
  let totalCapGainTaxableDec = new Dec(0);

  for (const item of rawCapGainItems) {
    let eventTaxableDec = new Dec(0);

    if (item.assessable && item.realizedGLDec.gt(0) && netAssessableCapGainTotal.gt(0)) {
      seenPositiveIdx++;
      if (seenPositiveIdx === positiveItemsCount) {
        eventTaxableDec = remainingCapGainToAllocate;
      } else {
        // Proportionally allocate net assessable gain after any intra-year loss offset
        eventTaxableDec = netAssessableCapGainTotal
          .times(item.realizedGLDec)
          .div(positiveAssessableCapGainSum);
        remainingCapGainToAllocate = remainingCapGainToAllocate.minus(eventTaxableDec);
      }
    }

    const taxBefore = calculateProgressivePIT(runningCumulativeIncome);
    runningCumulativeIncome = runningCumulativeIncome.plus(eventTaxableDec);
    const taxAfter = calculateProgressivePIT(runningCumulativeIncome);
    const marginalTax = taxAfter.minus(taxBefore);

    totalCapGainTaxableDec = totalCapGainTaxableDec.plus(eventTaxableDec);

    capitalGainEvents.push({
      id: item.id,
      type: 'CAPITAL_GAIN',
      date: item.date,
      symbol: item.symbol,
      amountTHB: formatTaxAmount(item.realizedGLDec),
      taxableIncome: formatTaxAmount(eventTaxableDec),
      taxWithheld: '0.00',
      netTaxPayable: formatTaxAmount(marginalTax),
    });
  }

  // ---------------------------------------------------------------------------
  // 2. Dividends Processing (Section 40(4)(b) & WHT Credit)
  // ---------------------------------------------------------------------------
  const electFinalTax = options?.electFinalTaxOnDividends ?? false;
  const dividendEvents: TaxEvent[] = [];
  let totalDividendTaxableDec = new Dec(0);
  let totalTaxWithheldDec = new Dec(0);

  for (const div of dividends) {
    const grossTHBDec = new Dec((div.grossTHB ?? div.gross).trim());
    const whtTHBDec = new Dec((div.whtTHB ?? div.wht).trim());
    const netTHBDec = new Dec((div.netTHB ?? div.net).trim());

    if (electFinalTax && whtTHBDec.gt(0)) {
      // Final Tax Election (Sec. 48(3)): excluded from PIT return
      const divEventId = div.id.startsWith('TAX-')
        ? div.id
        : div.id.startsWith('DIV-')
          ? `TAX-${div.id}`
          : `TAX-DIV-${div.id}`;

      dividendEvents.push({
        id: divEventId,
        type: 'DIVIDEND',
        date: div.date,
        symbol: div.symbol,
        amountTHB: formatTaxAmount(netTHBDec),
        taxableIncome: '0.00',
        taxWithheld: formatTaxAmount(whtTHBDec),
        netTaxPayable: '0.00',
      });
      continue;
    }

    const taxBefore = calculateProgressivePIT(runningCumulativeIncome);
    runningCumulativeIncome = runningCumulativeIncome.plus(grossTHBDec);
    const taxAfter = calculateProgressivePIT(runningCumulativeIncome);
    const marginalTax = taxAfter.minus(taxBefore);

    // Net tax payable for this event = marginal progressive PIT - WHT credit
    const eventNetTaxPayable = marginalTax.minus(whtTHBDec);

    totalDividendTaxableDec = totalDividendTaxableDec.plus(grossTHBDec);
    totalTaxWithheldDec = totalTaxWithheldDec.plus(whtTHBDec);

    const divEventId = div.id.startsWith('TAX-')
      ? div.id
      : div.id.startsWith('DIV-')
        ? `TAX-${div.id}`
        : `TAX-DIV-${div.id}`;

    dividendEvents.push({
      id: divEventId,
      type: 'DIVIDEND',
      date: div.date,
      symbol: div.symbol,
      amountTHB: formatTaxAmount(netTHBDec),
      taxableIncome: formatTaxAmount(grossTHBDec),
      taxWithheld: formatTaxAmount(whtTHBDec),
      netTaxPayable: formatTaxAmount(eventNetTaxPayable),
    });
  }

  // ---------------------------------------------------------------------------
  // 3. Portfolio Tax Summary
  // ---------------------------------------------------------------------------
  const totalTaxableIncomeDec = totalCapGainTaxableDec.plus(totalDividendTaxableDec);
  const pitOnPriorOnly = calculateProgressivePIT(priorIncomeDec);
  const pitOnCombined = calculateProgressivePIT(priorIncomeDec.plus(totalTaxableIncomeDec));
  const incrementalPITLiability = pitOnCombined.minus(pitOnPriorOnly);
  const totalTaxPayableDec = incrementalPITLiability.minus(totalTaxWithheldDec);

  return {
    taxYear,
    capitalGains: capitalGainEvents,
    dividends: dividendEvents,
    totalTaxableIncome: formatTaxAmount(totalTaxableIncomeDec),
    totalTaxWithheld: formatTaxAmount(totalTaxWithheldDec),
    totalTaxPayable: formatTaxAmount(totalTaxPayableDec),
    generatedAt: options?.generatedAt ?? new Date().toISOString(),
  };
}
