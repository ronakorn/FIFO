import request from 'supertest';
import { createApp } from '../api/app';
import { getPrismaClient } from '../db/prisma';
import { getAuditLogsForUser, logAction } from './auditLogger';
import { MockBotFxProvider } from './botFxProvider';
import { GoldDecimal } from './goldEngine';
import { executeRollover } from './goldRolloverManager';

describe('Institutional Gold Suite — BOT Historical FX, Gold Futures Rollover Manager & Immutable Audit Trail', () => {
  const app = createApp();
  const prisma = getPrismaClient();

  describe('1. Automated Historical FX Service (BOT Compliant — botFxProvider.ts)', () => {
    const botProvider = new MockBotFxProvider();

    it('fetches exact Bank of Thailand historical USD/THB rates by date (e.g. 2024-10-01 = 36.75)', async () => {
      const oct2024 = await botProvider.getHistoricalRate('USD', '2024-10-01');
      expect(oct2024).toBe('36.75');

      const todayRate = await botProvider.getHistoricalRate('USD', '2026-10-26');
      expect(todayRate).toBe('35.60');

      const thbIdentity = await botProvider.getHistoricalRate('THB', '2024-10-01');
      expect(thbIdentity).toBe('1.00');
    });

    it('applies BOT preceding business day convention on weekend dates and rejects malformed inputs', async () => {
      // 2024-10-06 (Sunday) falls back to Friday 2024-10-04 = 36.90
      const sundayFallback = await botProvider.getHistoricalRate(
        'USD',
        '2024-10-06'
      );
      expect(sundayFallback).toBe('36.90');

      await expect(
        botProvider.getHistoricalRate('USD', 'invalid-date')
      ).rejects.toThrow(/Invalid date format/i);

      await expect(
        botProvider.getHistoricalRate('XYZ_UNKNOWN', '2024-10-01')
      ).rejects.toThrow(/Unsupported BOT FX currency/i);
    });
  });

  describe('2. Gold Futures Rollover Manager (goldRolloverManager.ts)', () => {
    let userId: string;
    let portfolioId: string;

    beforeAll(async () => {
      const reg = await request(app).post('/api/auth/register').send({
        email: `roll.mgr.${Date.now()}@fifowealth.com`,
        password: 'Password123!',
        name: 'Gold Rollover Manager Tester',
      });
      userId = reg.body.user.id;

      const port = await request(app)
        .post('/api/portfolios')
        .set('Authorization', `Bearer ${reg.body.token}`)
        .send({ name: 'Institutional Futures Desk', baseCurrency: 'THB' });
      portfolioId = port.body.id;
    });

    afterAll(async () => {
      await prisma.user.deleteMany({ where: { id: userId } });
    });

    it('creates linked SELL + BUY transactions with identical rolloverGroupId, separate rolloverFee, and exact Decimal cost basis', async () => {
      // Seed an expiring GOV26 position: 3.0000 Oz @ $2,600.00, FX = 35.00 -> Entry Cost = 273,000.00 THB
      const openingTx = await prisma.goldTransactionRecord.create({
        data: {
          portfolioId,
          date: '2026-09-10',
          symbol: 'GOV26',
          assetSubclass: 'GOLD_ONLINE_FUTURES',
          weight: '3.0000',
          weightUnit: 'TROY_OUNCE',
          purity: '99.5',
          spotPricePerUnit: '2600.00',
          premiumPerUnit: '0.00',
          commission: '0.00',
          totalCost: '7800.00',
          fxRateAtPurchase: '35.0000',
          type: 'BUY',
          derivativesExt: {
            create: {
              contractMonth: 'V26',
              expirationDate: '2026-10-29',
              legAction: 'OPEN_LONG',
              isRollover: false,
            },
          },
        },
      });

      const result = await executeRollover(
        openingTx.id,
        'GOZ26',
        '3.0000',
        '2758.50',
        '12.50',
        {
          closePrice: '2742.00',
          executionDate: '2026-10-26',
          fxRateAtRollover: '35.6000',
        }
      );

      expect(result.rolloverGroupId).toBeTruthy();
      expect(result.closeTransaction.type).toBe('SELL');
      expect(result.closeTransaction.symbol).toBe('GOV26');
      expect(result.openTransaction.type).toBe('BUY');
      expect(result.openTransaction.symbol).toBe('GOZ26');

      // New cost basis native = (2758.50 * 3) + 12.50 = 8275.50 + 12.50 = 8288.00 USD
      expect(result.rolloverFee).toBe('12.50');
      expect(result.newInitialCostBasisNative).toBe('8288.00');
      // THB cost basis = 8288.00 * 35.60 = 295,052.80 THB
      expect(result.newInitialCostBasisTHB).toBe('295052.80');
      expect(result.rolloverFeeTHB).toBe(
        new GoldDecimal('12.50').times('35.60').toFixed(2)
      );

      // Verify DB extension linkage (identical rolloverGroupId + separate rolloverFee)
      const extRows = await prisma.derivativesContractExtension.findMany({
        where: { rolloverGroupId: result.rolloverGroupId },
      });
      expect(extRows).toHaveLength(2);
      expect(extRows.every((r) => r.isRollover === true)).toBe(true);
      expect(extRows.every((r) => r.rolloverFee === '12.50')).toBe(true);
    });

    it('rolls back atomically when rollover quantity exceeds available open weight', async () => {
      const openRow = await prisma.goldTransactionRecord.findFirstOrThrow({
        where: { portfolioId, symbol: 'GOZ26', type: 'BUY' },
      });

      const countBefore = await prisma.goldTransactionRecord.count({
        where: { portfolioId },
      });

      await expect(
        executeRollover(openRow.id, 'GOH27', '99.0000', '2780.00', '10.00')
      ).rejects.toThrow(/Insufficient open position/i);

      const countAfter = await prisma.goldTransactionRecord.count({
        where: { portfolioId },
      });
      expect(countAfter).toBe(countBefore);
    });
  });

  describe('3. Immutable Audit Trail (PDPA/GDPR Ready — auditLogger.ts & Wrapped Gold API)', () => {
    let tokenA: string;
    let userAId: string;
    let portfolioAId: string;
    let tokenB: string;

    beforeAll(async () => {
      const regA = await request(app).post('/api/auth/register').send({
        email: `audit.a.${Date.now()}@fifowealth.com`,
        password: 'Password123!',
        name: 'Audit Owner A',
      });
      tokenA = regA.body.token;
      userAId = regA.body.user.id;

      const portA = await request(app)
        .post('/api/portfolios')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ name: 'Audited Gold Vault', baseCurrency: 'THB' });
      portfolioAId = portA.body.id;

      const regB = await request(app).post('/api/auth/register').send({
        email: `audit.b.${Date.now()}@fifowealth.com`,
        password: 'Password123!',
        name: 'Outsider B',
      });
      tokenB = regB.body.token;
    });

    afterAll(async () => {
      await prisma.auditLog.deleteMany({ where: { userId: userAId } });
      await prisma.user.deleteMany({ where: { id: userAId } });
    });

    it('serializes beforeState and afterState as canonical JSON strings and redacts sensitive fields', async () => {
      const entry = await logAction(
        userAId,
        'UPDATE',
        'PORTFOLIO',
        portfolioAId,
        { name: 'Old Vault', secretKey: 'top-secret-123' },
        { name: 'New Vault', secretKey: 'top-secret-456' },
        '203.0.113.42'
      );

      expect(typeof entry.beforeState).toBe('string');
      expect(typeof entry.afterState).toBe('string');

      const parsedBefore = JSON.parse(entry.beforeState!);
      const parsedAfter = JSON.parse(entry.afterState!);
      expect(parsedBefore.name).toBe('Old Vault');
      expect(parsedBefore.secretKey).toBe('[REDACTED_PDPA]');
      expect(parsedAfter.name).toBe('New Vault');
      expect(parsedAfter.secretKey).toBe('[REDACTED_PDPA]');
      expect(entry.ipAddress).toBe('203.0.113.42');
    });

    it('automatically wraps Gold POST (with BOT FX auto-fetch), PUT, and DELETE endpoints with AuditLog entries and isolates users', async () => {
      // 1. Verify GET /api/gold/fx-rate endpoint
      const fxRes = await request(app)
        .get('/api/gold/fx-rate?currency=USD&date=2024-10-01')
        .set('Authorization', `Bearer ${tokenA}`);
      expect(fxRes.status).toBe(200);
      expect(fxRes.body.rate).toBe('36.75');

      // 2. POST /api/gold/transactions WITHOUT fxRateAtPurchase -> auto-fetches 2024-10-01 BOT rate (36.7500) & logs CREATE
      const createRes = await request(app)
        .post('/api/gold/transactions')
        .set('Authorization', `Bearer ${tokenA}`)
        .set('X-Forwarded-For', '198.51.100.10')
        .send({
          portfolioId: portfolioAId,
          date: '2024-10-01',
          symbol: 'XAUUSD',
          assetSubclass: 'XAU_SPOT',
          weight: '2.0000',
          weightUnit: 'TROY_OUNCE',
          purity: '99.99',
          spotPricePerUnit: '2650.00',
          premiumPerUnit: '0',
          commission: '5.00',
          type: 'BUY',
        });

      expect(createRes.status).toBe(201);
      expect(createRes.body.fxRateAtPurchase).toBe('36.7500');
      const createdTxId = createRes.body.id as string;

      // 3. PUT /api/gold/transactions/:id -> updates spotPricePerUnit & logs UPDATE with beforeState & afterState
      const updateRes = await request(app)
        .put(`/api/gold/transactions/${createdTxId}`)
        .set('Authorization', `Bearer ${tokenA}`)
        .set('X-Forwarded-For', '198.51.100.10')
        .send({
          spotPricePerUnit: '2680.00',
        });
      expect(updateRes.status).toBe(200);
      expect(updateRes.body.spotPricePerUnit).toBe('2680.00');

      // 4. DELETE /api/gold/transactions/:id -> logs DELETE with beforeState & null afterState
      const deleteRes = await request(app)
        .delete(`/api/gold/transactions/${createdTxId}`)
        .set('Authorization', `Bearer ${tokenA}`);
      expect(deleteRes.status).toBe(200);

      // 5. Inspect recorded Audit Logs for User A
      const userLogs = await getAuditLogsForUser(userAId, {
        entityType: 'GOLD_TRANSACTION',
      });
      const txLogs = userLogs.filter((l) => l.entityId === createdTxId);
      expect(txLogs).toHaveLength(3);

      const createLog = txLogs.find((l) => l.action === 'CREATE')!;
      const updateLog = txLogs.find((l) => l.action === 'UPDATE')!;
      const deleteLog = txLogs.find((l) => l.action === 'DELETE')!;

      expect(createLog.beforeState).toBeNull();
      expect(JSON.parse(createLog.afterState!).spotPricePerUnit).toBe('2650.00');

      expect(JSON.parse(updateLog.beforeState!).spotPricePerUnit).toBe('2650.00');
      expect(JSON.parse(updateLog.afterState!).spotPricePerUnit).toBe('2680.00');

      expect(JSON.parse(deleteLog.beforeState!).spotPricePerUnit).toBe('2680.00');
      expect(deleteLog.afterState).toBeNull();

      // 6. Verify User B cannot see User A's audit logs (PDPA/GDPR User Isolation)
      const listResB = await request(app)
        .get('/api/audit-logs')
        .set('Authorization', `Bearer ${tokenB}`);
      expect(listResB.status).toBe(200);
      expect(listResB.body.logs).toHaveLength(0);
    });
  });
});
