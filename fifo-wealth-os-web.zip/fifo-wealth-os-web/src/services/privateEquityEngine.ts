import Decimal from 'decimal.js';
import type { PECashFlow, PEPerformanceMetrics } from '../types/advancedAssets';

export const PeDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface JCurvePoint {
  date: string;
  cashFlow: string;
  cumulativeCashFlow: string;
  irr: string;
}

function parseDecimal(value: string, label: string): Decimal {
  try {
    const result = new PeDecimal(value);
    if (!result.isFinite()) throw new Error();
    return result;
  } catch {
    throw new Error(`${label} must be a finite decimal string.`);
  }
}

function nonNegative(value: string, label: string): Decimal {
  const result = parseDecimal(value, label);
  if (result.isNegative()) throw new Error(`${label} cannot be negative.`);
  return result;
}

function fixed(value: Decimal, places: number): string {
  return value.toDecimalPlaces(places, PeDecimal.ROUND_HALF_UP).toFixed(places);
}

function dateOrdinal(date: string): number {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error(`Invalid cash-flow date: ${date}. Expected YYYY-MM-DD.`);
  const timestamp = Date.parse(`${date}T00:00:00.000Z`);
  if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString().slice(0, 10) !== date) {
    throw new Error(`Invalid calendar date: ${date}.`);
  }
  return Math.trunc(timestamp / 86_400_000);
}

function normalizeCashFlows(cashFlows: readonly PECashFlow[]): Array<PECashFlow & { ordinal: number }> {
  if (cashFlows.length < 2) throw new Error('At least two dated cash flows are required.');
  return cashFlows
    .map((cashFlow) => ({ ...cashFlow, ordinal: dateOrdinal(cashFlow.date) }))
    .sort((left, right) => left.date.localeCompare(right.date));
}

function yearsFromBase(ordinal: number, baseOrdinal: number): Decimal {
  return new PeDecimal(ordinal - baseOrdinal).dividedBy(365);
}

function netPresentValue(rate: Decimal, cashFlows: ReadonlyArray<PECashFlow & { ordinal: number }>): Decimal {
  const firstCashFlow = cashFlows[0];
  if (!firstCashFlow) throw new Error('At least one cash flow is required to evaluate NPV.');
  const baseOrdinal = firstCashFlow.ordinal;
  const base = new PeDecimal(1).plus(rate);
  return cashFlows.reduce((sum, cashFlow) => {
    const years = yearsFromBase(cashFlow.ordinal, baseOrdinal);
    return sum.plus(parseDecimal(cashFlow.amount, 'cash-flow amount').dividedBy(base.pow(years)));
  }, new PeDecimal(0));
}

function npvDerivative(rate: Decimal, cashFlows: ReadonlyArray<PECashFlow & { ordinal: number }>): Decimal {
  const firstCashFlow = cashFlows[0];
  if (!firstCashFlow) throw new Error('At least one cash flow is required to evaluate the XIRR derivative.');
  const baseOrdinal = firstCashFlow.ordinal;
  const base = new PeDecimal(1).plus(rate);
  return cashFlows.reduce((sum, cashFlow) => {
    const years = yearsFromBase(cashFlow.ordinal, baseOrdinal);
    if (years.isZero()) return sum;
    const amount = parseDecimal(cashFlow.amount, 'cash-flow amount');
    const contribution = amount.times(years).negated().dividedBy(base.pow(years.plus(1)));
    return sum.plus(contribution);
  }, new PeDecimal(0));
}

/** Annualized XIRR using Newton-Raphson on dated cash flows (actual/365 day count). */
export function calculateIRR(cashFlows: readonly PECashFlow[], initialGuess = '0.15'): string {
  const normalized = normalizeCashFlows(cashFlows);
  const hasNegative = normalized.some((cashFlow) => parseDecimal(cashFlow.amount, 'cash-flow amount').isNegative());
  const hasPositive = normalized.some((cashFlow) => parseDecimal(cashFlow.amount, 'cash-flow amount').isPositive());
  if (!hasNegative || !hasPositive) throw new Error('IRR requires at least one negative and one positive cash flow.');

  let rate = parseDecimal(initialGuess, 'initialGuess');
  if (rate.lte(-1)) throw new Error('initialGuess must be greater than -1.');
  const tolerance = new PeDecimal('0.0000000001');
  let low = new PeDecimal('-0.999999');
  let high = new PeDecimal(100);
  let lowNpv = netPresentValue(low, normalized);
  const highNpv = netPresentValue(high, normalized);
  const hasBracket = lowNpv.isZero() || highNpv.isZero() || lowNpv.isNegative() !== highNpv.isNegative();
  if (hasBracket && (rate.lte(low) || rate.gte(high))) rate = low.plus(high).dividedBy(2);

  for (let iteration = 0; iteration < 200; iteration += 1) {
    const npv = netPresentValue(rate, normalized);
    if (!npv.isFinite()) break;
    if (npv.abs().lte(tolerance)) return fixed(rate, 6);

    if (hasBracket) {
      if (npv.isNegative() === lowNpv.isNegative()) {
        low = rate;
        lowNpv = npv;
      } else {
        high = rate;
      }
    }

    const derivative = npvDerivative(rate, normalized);
    const newtonCandidate = derivative.isZero()
      ? new PeDecimal('NaN')
      : rate.minus(npv.dividedBy(derivative));
    const candidateIsUsable = newtonCandidate.isFinite()
      && newtonCandidate.gt(new PeDecimal('-0.999999'))
      && newtonCandidate.lt(new PeDecimal(100))
      && (!hasBracket || (newtonCandidate.gt(low) && newtonCandidate.lt(high)));
    const nextRate = candidateIsUsable
      ? newtonCandidate
      : hasBracket
        ? low.plus(high).dividedBy(2)
        : new PeDecimal('NaN');
    if (!nextRate.isFinite()) break;
    if (nextRate.minus(rate).abs().lte(tolerance)) {
      rate = nextRate;
      if (netPresentValue(rate, normalized).abs().lte(new PeDecimal('0.000001'))) return fixed(rate, 6);
      break;
    }
    rate = nextRate;
  }

  throw new Error('XIRR did not converge to a stable root; check cash flows for multiple or ill-conditioned IRRs.');
}

export function calculatePEMetrics(
  committedCapital: string,
  calledCapital: string,
  investedCapital: string,
  distributedCapital: string,
  residualValue: string,
  cashFlows?: readonly PECashFlow[],
): PEPerformanceMetrics {
  const committed = nonNegative(committedCapital, 'committedCapital');
  const called = nonNegative(calledCapital, 'calledCapital');
  const invested = nonNegative(investedCapital, 'investedCapital');
  const distributed = nonNegative(distributedCapital, 'distributedCapital');
  const residual = nonNegative(residualValue, 'residualValue');
  if (called.gt(committed)) throw new Error('calledCapital cannot exceed committedCapital.');
  if (invested.gt(called)) throw new Error('investedCapital cannot exceed calledCapital.');
  const denominator = invested;
  const totalValue = distributed.plus(residual);
  const ratio = (numerator: Decimal): Decimal => denominator.isZero() ? new PeDecimal(0) : numerator.dividedBy(denominator);
  let irr = new PeDecimal(0);
  if (cashFlows !== undefined) irr = new PeDecimal(calculateIRR(cashFlows));

  return {
    tvpi: fixed(ratio(totalValue), 4),
    dpi: fixed(ratio(distributed), 4),
    rvpi: fixed(ratio(residual), 4),
    moic: fixed(ratio(totalValue), 4),
    irr: fixed(irr, 6),
    paidInCapital: fixed(invested, 2),
    totalDistributions: fixed(distributed, 2),
    residualValue: fixed(residual, 2),
    committedCapital: fixed(committed, 2),
    uncalledCapital: fixed(committed.minus(called), 2),
  };
}

/** Create a cumulative, dated cash-flow series suitable for a J-curve chart. */
export function generateJCurveData(cashFlows: readonly PECashFlow[]): JCurvePoint[] {
  const normalized = normalizeCashFlows(cashFlows);
  let cumulative = new PeDecimal(0);
  const prefix: PECashFlow[] = [];
  return normalized.map(({ ordinal: _ordinal, ...cashFlow }) => {
    const amount = parseDecimal(cashFlow.amount, 'cash-flow amount');
    cumulative = cumulative.plus(amount);
    prefix.push(cashFlow);
    const prefixHasNegative = prefix.some((flow) => parseDecimal(flow.amount, 'cash-flow amount').isNegative());
    const prefixHasPositive = prefix.some((flow) => parseDecimal(flow.amount, 'cash-flow amount').isPositive());
    const irr = prefix.length >= 2 && prefixHasNegative && prefixHasPositive
      ? calculateIRR(prefix)
      : '0.000000';
    return {
      date: cashFlow.date,
      cashFlow: fixed(amount, 2),
      cumulativeCashFlow: fixed(cumulative, 2),
      irr,
    };
  });
}
