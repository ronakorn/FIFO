import Decimal from 'decimal.js';
import { FIFOResult, Lot, LotStatus, Transaction } from './types';

/**
 * Isolated IEEE 754-2008 decimal128 configuration (34 significant digits)
 * to eliminate binary floating-point drift during intermediate FIFO accounting.
 */
const Dec = Decimal.clone({
  precision: 34,
  rounding: Decimal.ROUND_HALF_UP,
});

interface InternalLot {
  id: string;
  date: string;
  symbol: string;
  buyQty: Decimal;
  costPerUnit: Decimal;
  qtySold: Decimal;
  qtyRemain: Decimal;
  realizedGL: Decimal;
  costSold: Decimal;
  proceeds: Decimal;
}

/**
 * Converts a Decimal value to a standard JS number while normalizing -0 to 0.
 * Used for quantities and unit costs where full precision must be preserved.
 */
function toNumber(value: Decimal): number {
  const num = value.toNumber();
  return Object.is(num, -0) ? 0 : num;
}

/**
 * Final Tax Rounding (Thai Revenue Department standard):
 * Rounds final monetary outputs (Realized G/L, Unrealized G/L, Totals)
 * to 2 decimal places using ROUND_HALF_UP while normalizing -0 to 0.
 */
function toTaxRoundedNumber(value: Decimal): number {
  const rounded = value.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toNumber();
  return Object.is(rounded, -0) ? 0 : rounded;
}

/**
 * Resolves the effective net amount as an exact Decimal with ZERO intermediate rounding:
 * 1. Uses `tx.netTHB` (exact string) when Multi-Currency FX enrichment has been applied.
 * 2. Falls back to `tx.originalNet` (exact string) when un-enriched.
 * 3. Falls back to `tx.net` otherwise.
 */
function resolveEffectiveNet(tx: Transaction): Decimal {
  if (tx.netTHB !== null && tx.netTHB !== undefined && tx.netTHB.trim().length > 0) {
    const netTHBDec = new Dec(tx.netTHB.trim());
    if (!netTHBDec.isFinite() || netTHBDec.lt(0)) {
      throw new Error(
        `Invalid netTHB ("${tx.netTHB}") for transaction ID "${tx.id}": must be a non-negative decimal string.`
      );
    }
    return netTHBDec;
  }

  if (tx.originalNet && tx.originalNet.trim().length > 0) {
    const origNetDec = new Dec(tx.originalNet.trim());
    if (!origNetDec.isFinite() || origNetDec.lt(0)) {
      throw new Error(
        `Invalid originalNet ("${tx.originalNet}") for transaction ID "${tx.id}": must be a non-negative decimal string.`
      );
    }
    return origNetDec;
  }

  return new Dec(tx.net);
}

/**
 * Validates common transaction fields and ensures strict FinTech domain invariants.
 */
function validateTransaction(tx: Transaction, expectedType: 'BUY' | 'SELL'): void {
  if (tx.type !== expectedType) {
    throw new Error(
      `Invalid transaction type for ID "${tx.id}": expected "${expectedType}", received "${tx.type}".`
    );
  }

  if (!tx.symbol || tx.symbol.trim().length === 0) {
    throw new Error(`Invalid symbol for transaction ID "${tx.id}": symbol must be non-empty.`);
  }

  const parsedDate = Date.parse(tx.date);
  if (Number.isNaN(parsedDate)) {
    throw new Error(`Invalid date "${tx.date}" for transaction ID "${tx.id}".`);
  }

  if (!Number.isFinite(tx.qty) || tx.qty <= 0) {
    throw new Error(
      `Invalid quantity (${tx.qty}) for transaction ID "${tx.id}": qty must be a positive finite number.`
    );
  }

  if (!Number.isFinite(tx.net) || tx.net < 0) {
    throw new Error(
      `Invalid net amount (${tx.net}) for transaction ID "${tx.id}": net must be a non-negative finite number.`
    );
  }
}

/**
 * Chronologically sorts transactions ascending by date while preserving original
 * ledger order on same-date ties (deterministic stable sort without mutating input).
 */
function sortChronologically(transactions: readonly Transaction[]): Transaction[] {
  return transactions
    .map((tx, index) => ({ tx, index, timestamp: Date.parse(tx.date) }))
    .sort((a, b) => {
      if (a.timestamp !== b.timestamp) {
        return a.timestamp - b.timestamp;
      }
      return a.index - b.index;
    })
    .map((entry) => entry.tx);
}

/**
 * Core FIFO Engine for FIFO Wealth OS.
 *
 * Matches SELL transactions against BUY lots per symbol in strict First-In, First-Out
 * chronological order. Automatically computes in Base Currency (THB) using exact `netTHB`
 * strings when enriched, with Zero Intermediate Rounding and Final Tax Rounding (2dp, ROUND_HALF_UP).
 */
export function calculateFIFO(
  buyTransactions: Transaction[],
  sellTransactions: Transaction[],
  currentPrices: Record<string, number>
): FIFOResult {
  for (const tx of buyTransactions) {
    validateTransaction(tx, 'BUY');
  }

  for (const tx of sellTransactions) {
    validateTransaction(tx, 'SELL');
  }

  const sortedBuys = sortChronologically(buyTransactions);
  const sortedSells = sortChronologically(sellTransactions);

  const allInternalLots: InternalLot[] = [];
  const lotsBySymbol = new Map<string, InternalLot[]>();
  const lotCursorBySymbol = new Map<string, number>();

  // 1. Initialize BUY lots in FIFO order (Zero Intermediate Rounding)
  for (const buyTx of sortedBuys) {
    const buyQty = new Dec(buyTx.qty);
    const netAmount = resolveEffectiveNet(buyTx);
    const costPerUnit = netAmount.div(buyQty);

    const internalLot: InternalLot = {
      id: buyTx.id,
      date: buyTx.date,
      symbol: buyTx.symbol,
      buyQty,
      costPerUnit,
      qtySold: new Dec(0),
      qtyRemain: buyQty,
      realizedGL: new Dec(0),
      costSold: new Dec(0),
      proceeds: new Dec(0),
    };

    allInternalLots.push(internalLot);

    const symbolQueue = lotsBySymbol.get(buyTx.symbol);
    if (symbolQueue) {
      symbolQueue.push(internalLot);
    } else {
      lotsBySymbol.set(buyTx.symbol, [internalLot]);
      lotCursorBySymbol.set(buyTx.symbol, 0);
    }
  }

  // 2. Match SELL transactions against each symbol's FIFO BUY lot queue
  for (const sellTx of sortedSells) {
    const symbolLots = lotsBySymbol.get(sellTx.symbol);
    if (!symbolLots || symbolLots.length === 0) {
      throw new Error(
        `Insufficient holdings for symbol "${sellTx.symbol}": no BUY lots available to match SELL "${sellTx.id}".`
      );
    }

    const sellQty = new Dec(sellTx.qty);
    const sellNetProceeds = resolveEffectiveNet(sellTx);
    const sellProceedsPerUnit = sellNetProceeds.div(sellQty);

    let remainingToSell = sellQty;
    let cursor = lotCursorBySymbol.get(sellTx.symbol) ?? 0;

    while (remainingToSell.gt(0) && cursor < symbolLots.length) {
      const lot = symbolLots[cursor];
      if (!lot || lot.qtyRemain.lte(0)) {
        cursor++;
        continue;
      }

      const matchedQty = Dec.min(lot.qtyRemain, remainingToSell);

      // Realized G/L = ((net proceeds / sell qty) - costPerUnit) * matchedQty
      const matchRealizedGL = sellProceedsPerUnit.minus(lot.costPerUnit).times(matchedQty);
      const matchCostSold = lot.costPerUnit.times(matchedQty);
      const matchProceeds = sellProceedsPerUnit.times(matchedQty);

      lot.qtySold = lot.qtySold.plus(matchedQty);
      lot.qtyRemain = lot.qtyRemain.minus(matchedQty);
      lot.realizedGL = lot.realizedGL.plus(matchRealizedGL);
      lot.costSold = lot.costSold.plus(matchCostSold);
      lot.proceeds = lot.proceeds.plus(matchProceeds);

      remainingToSell = remainingToSell.minus(matchedQty);

      if (lot.qtyRemain.isZero()) {
        cursor++;
      }
    }

    lotCursorBySymbol.set(sellTx.symbol, cursor);

    if (remainingToSell.gt(0)) {
      throw new Error(
        `Insufficient holdings for symbol "${sellTx.symbol}" on SELL "${sellTx.id}": attempted to sell ${sellTx.qty}, short by ${remainingToSell.toString()}.`
      );
    }
  }

  // 3. Compute Lot Status, Unrealized G/L, and Portfolio Totals (Final Tax Rounding at boundary)
  let totalRealizedGL = new Dec(0);
  let totalUnrealizedGL = new Dec(0);
  let totalCostSold = new Dec(0);
  let totalProceeds = new Dec(0);

  const lots: Lot[] = allInternalLots.map((internalLot) => {
    let status: LotStatus;
    if (internalLot.qtyRemain.isZero()) {
      status = 'Sold';
    } else if (internalLot.qtySold.isZero()) {
      status = 'Hold';
    } else {
      status = 'Partial';
    }

    let unrealizedGL = new Dec(0);
    const currentPrice = currentPrices[internalLot.symbol];
    if (internalLot.qtyRemain.gt(0)) {
      if (currentPrice === undefined || !Number.isFinite(currentPrice) || currentPrice < 0) {
        throw new Error(
          `Missing or invalid current price for symbol "${internalLot.symbol}" with remaining quantity ${internalLot.qtyRemain.toString()}.`
        );
      }
      // Unrealized G/L = (currentPrice - costPerUnit) * qtyRemain
      unrealizedGL = new Dec(currentPrice)
        .minus(internalLot.costPerUnit)
        .times(internalLot.qtyRemain);
    } else if (currentPrice !== undefined) {
      if (!Number.isFinite(currentPrice) || currentPrice < 0) {
        throw new Error(`Invalid current price for symbol "${internalLot.symbol}".`);
      }
    }

    totalRealizedGL = totalRealizedGL.plus(internalLot.realizedGL);
    totalUnrealizedGL = totalUnrealizedGL.plus(unrealizedGL);
    totalCostSold = totalCostSold.plus(internalLot.costSold);
    totalProceeds = totalProceeds.plus(internalLot.proceeds);

    return {
      id: internalLot.id,
      date: internalLot.date,
      symbol: internalLot.symbol,
      buyQty: toNumber(internalLot.buyQty),
      costPerUnit: toNumber(internalLot.costPerUnit),
      qtySold: toNumber(internalLot.qtySold),
      qtyRemain: toNumber(internalLot.qtyRemain),
      realizedGL: toTaxRoundedNumber(internalLot.realizedGL),
      unrealizedGL: toTaxRoundedNumber(unrealizedGL),
      status,
    };
  });

  return {
    lots,
    totalRealizedGL: toTaxRoundedNumber(totalRealizedGL),
    totalUnrealizedGL: toTaxRoundedNumber(totalUnrealizedGL),
    totalCostSold: toTaxRoundedNumber(totalCostSold),
    totalProceeds: toTaxRoundedNumber(totalProceeds),
  };
}
