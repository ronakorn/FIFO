import { strToU8, zipSync } from 'fflate';
import {
  getBloombergCDMMapping,
  mapBloombergAssetTypeToCDM,
  parseBloombergCorporateActions,
  parseBloombergCorporateActionsFile,
  parseBloombergTicker,
  parseBloombergTrades,
  parseBloombergTradesFile,
} from './bloombergAdapter';
import type { BloombergAssetType } from '../types/bloomberg';

const TRADE_HEADER = [
  'Trade ID',
  'Ticker',
  'Trade Date',
  'Settlement Date',
  'Side',
  'Quantity',
  'Price',
  'Gross Amount',
  'Commission',
  'Taxes',
  'Net Amount',
  'Currency',
  'Exchange',
  'FX Rate to THB',
].join(',');

function makeXlsx(rows: string[][]): Uint8Array {
  const sharedStrings: string[] = [];
  const indexes = new Map<string, number>();
  const intern = (value: string) => {
    const existing = indexes.get(value);
    if (existing !== undefined) return existing;
    const index = sharedStrings.length;
    sharedStrings.push(value);
    indexes.set(value, index);
    return index;
  };
  const cellColumn = (index: number): string => {
    let number = index + 1;
    let column = '';
    while (number > 0) {
      const remainder = (number - 1) % 26;
      column = String.fromCharCode(65 + remainder) + column;
      number = Math.floor((number - 1) / 26);
    }
    return column;
  };
  const worksheetRows = rows.map((row, rowIndex) => {
    const cells = row.map((value, columnIndex) => {
      const reference = `${cellColumn(columnIndex)}${rowIndex + 1}`;
      if (rowIndex === 1 && ['Trade Date', 'Settlement Date'].includes(rows[0]?.[columnIndex] ?? '')) {
        return `<c r="${reference}"><v>${value}</v></c>`;
      }
      return `<c r="${reference}" t="s"><v>${intern(value)}</v></c>`;
    }).join('');
    return `<row r="${rowIndex + 1}">${cells}</row>`;
  }).join('');
  const sharedXml = `<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${sharedStrings.length}" uniqueCount="${sharedStrings.length}">${sharedStrings.map((value) => `<si><t>${value}</t></si>`).join('')}</sst>`;
  return zipSync({
    'xl/workbook.xml': strToU8('<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Trades" sheetId="1" r:id="rId1"/></sheets></workbook>'),
    'xl/_rels/workbook.xml.rels': strToU8('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"/></Relationships>'),
    'xl/sharedStrings.xml': strToU8(sharedXml),
    'xl/worksheets/sheet1.xml': strToU8(`<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${worksheetRows}</sheetData></worksheet>`),
  });
}

describe('Bloomberg adapter', () => {
  describe('ticker parsing', () => {
    it.each([
      ['AAPL US Equity', 'AAPL', 'US', 'Equity'],
      ['US000361AQ64 Corp', 'US000361AQ64', '', 'Corp'],
      ['XAU Curncy', 'XAU', '', 'Curncy'],
      ['eurusd curncy', 'eurusd', '', 'Curncy'],
    ])('parses %s', (raw, symbol, market, assetType) => {
      expect(parseBloombergTicker(raw)).toMatchObject({ symbol, market, assetType });
    });

    it('preserves optional security identifiers', () => {
      expect(parseBloombergTicker('AAPL US Equity', { isin: 'US0378331005', cusip: '037833100' })).toMatchObject({
        isin: 'US0378331005',
        cusip: '037833100',
      });
    });

    it('rejects malformed and unknown suffixes', () => {
      expect(() => parseBloombergTicker('AAPL')).toThrow(/Expected/);
      expect(() => parseBloombergTicker('AAPL US Unknown')).toThrow(/Unsupported/);
    });
  });

  describe('Bloomberg asset type mappings', () => {
    const expected: Record<BloombergAssetType, string> = {
      Equity: 'EQUITY',
      Corp: 'BOND',
      Govt: 'BOND',
      Curncy: 'FOREX',
      Comdty: 'COMMODITY',
      Index: 'EQUITY',
      Option: 'OPTION',
      Future: 'OPTION',
      Mortgage: 'BOND',
      Muni: 'BOND',
      Pfd: 'EQUITY',
      Warrant: 'OPTION',
    };

    it.each(Object.entries(expected) as [BloombergAssetType, string][])(
      'maps Bloomberg %s to %s',
      (assetType, assetClass) => {
        expect(mapBloombergAssetTypeToCDM(assetType)).toBe(assetClass);
      },
    );

    it('flags futures as not importable instead of silently treating them as options', () => {
      expect(getBloombergCDMMapping('Future')).toMatchObject({
        assetClass: 'OPTION',
        supportedByCurrentCDM: false,
      });
      expect(getBloombergCDMMapping('Option').supportedByCurrentCDM).toBe(true);
    });
  });

  describe('trade file parsing and CDM mapping', () => {
    it('maps equity trades with exact decimal strings and deterministic IDs', () => {
      const content = [
        TRADE_HEADER,
        'B-100,AAPL US Equity,2026-10-20,2026-10-22,BUY,10,150.50,1505.00,1.00,0.07,1506.07,USD,NASDAQ,33.12',
      ].join('\n');
      const [transaction] = parseBloombergTrades(content, { portfolioId: 'portfolio-1', createdAt: new Date('2026-10-27T00:00:00Z') });
      expect(transaction).toMatchObject({
        id: expect.stringMatching(/^bbg-[a-f0-9]{40}$/),
        portfolioId: 'portfolio-1',
        date: '2026-10-20',
        symbol: 'AAPL',
        assetClass: 'EQUITY',
        type: 'BUY',
        qty: 10,
        price: '150.50000000',
        gross: '1505.00',
        comm: '1.00',
        vat: '0.07',
        net: '1506.07',
        originalCurrency: 'USD',
        originalNet: '1506.07',
        fxRate: '33.12000000',
        netTHB: '49881.04',
        exchange: 'NASDAQ',
      });
      expect(parseBloombergTrades(content, { portfolioId: 'portfolio-1', createdAt: new Date('2026-10-27T00:00:00Z') })[0]?.id).toBe(transaction?.id);
    });

    it('handles quoted CSV values, signed quantities, and signed fee exports', () => {
      const content = [
        TRADE_HEADER,
        'B-101,"MSFT US Equity",2026-10-20,2026-10-22,SELL,-2,150.00,-300.00,-1.00,0.00,299.00,USD,NASDAQ,33.12',
      ].join('\n');
      const [transaction] = parseBloombergTrades(content);
      expect(transaction).toMatchObject({ type: 'SELL', qty: 2, gross: '300.00', comm: '1.00', net: '299.00' });
    });

    it('uses Decimal.js to derive buy net amount when the export does not contain one', () => {
      const content = [
        'Trade ID,Ticker,Trade Date,Side,Quantity,Price,Gross Amount,Commission,Taxes,Currency',
        'B-102,MSFT US Equity,2026-10-20,BUY,3,10.10,30.30,0.20,0.03,USD',
      ].join('\n');
      const [transaction] = parseBloombergTrades(content);
      expect(transaction?.net).toBe('30.53');
    });

    it('maps fixed-income fields into the existing BondExtension without editing the Core CDM', () => {
      const content = [
        `${TRADE_HEADER},Coupon Rate,Coupon Frequency,Maturity Date,Face Value,Accrued Interest,YTM,Credit Rating,Issuer`,
        'BOND-1,US000361AQ64 Corp,2026-10-20,2026-10-22,BUY,2,99.50,199.00,0.00,0.00,199.00,THB,OTC,,5.25%,Semi-Annual,2028-10-20,100.00,0.45,4.75%,AA,Example Issuer',
      ].join('\n');
      const [transaction] = parseBloombergTrades(content);
      expect(transaction?.assetClass).toBe('BOND');
      expect(transaction?.bondExtension).toMatchObject({
        couponRate: '0.05250000',
        paymentFrequency: 'SEMI_ANNUAL',
        maturityDate: '2028-10-20',
        faceValue: '100.00',
        accruedInterest: '0.45',
        yieldToMaturity: '0.04750000',
        creditRating: 'AA',
        issuer: 'Example Issuer',
      });
    });

    it('maps commodity metadata and converts FX pairs to the CDM source-to-target convention', () => {
      const commodity = [
        `${TRADE_HEADER},Weight Per Unit,Weight Unit,Purity,Spot Price Per Unit,Storage Fee THB,Premium THB`,
        'C-1,XAU Comdty,2026-10-20,2026-10-22,BUY,1,2650.00,2650.00,0.00,0.00,2650.00,USD,OTC,33.00,1,Troy Ounce,99.9,2650.00,2.00,1.00',
      ].join('\n');
      const [metal] = parseBloombergTrades(commodity);
      expect(metal?.commodityExtension).toMatchObject({
        weight: '1.00000000',
        weightUnit: 'TROY_OUNCE',
        purity: '99.90000000',
        spotPricePerUnit: '2650.00000000',
        storageFee: '2.00',
        premium: '1.00',
      });

      const forex = [
        TRADE_HEADER,
        'FX-1,EURUSD Curncy,2026-10-20,2026-10-22,BUY,1000,1.08,1080,0,0,1080,USD,FX,33.50',
      ].join('\n');
      const [conversion] = parseBloombergTrades(forex);
      expect(conversion).toMatchObject({
        assetClass: 'FOREX',
        type: 'CONVERT',
        qty: 1080,
        originalCurrency: 'USD',
        originalNet: '1080.00',
        gross: '1000.00',
        price: '0.92592593',
        fxRate: '33.50000000',
        netTHB: '36180.00',
        forexExtension: {
          fromCurrency: 'USD',
          toCurrency: 'EUR',
          fxRateAtTransaction: '0.92592593',
          realizedFxGainLoss: '0.00',
        },
      });
    });

    it('requires complete option terms and rejects Futures because they are not represented by the protected CDM', () => {
      const option = [
        `${TRADE_HEADER},Option Type,Strike Price,Expiration Date,Underlying Asset,Contract Size,Option Premium`,
        'O-1,AAPL 2027C Option,2026-10-20,2026-10-22,BUY,1,12.50,12.50,0,0,12.50,USD,CBOE,33.00,CALL,250,2027-01-15,AAPL,100,12.50',
      ].join('\n');
      expect(parseBloombergTrades(option)[0]?.optionExtension).toMatchObject({
        optionType: 'CALL',
        strikePrice: '250.00000000',
        expirationDate: '2027-01-15',
        underlyingAsset: 'AAPL',
        contractSize: 100,
        premium: '12.50000000',
      });

      const future = `${TRADE_HEADER}\nF-1,ESZ6 CME Future,2026-10-20,2026-10-22,BUY,1,6000,6000,0,0,6000,USD,CME,33.00`;
      expect(() => parseBloombergTrades(future)).toThrow(/no Futures type|cannot be represented safely/i);
    });

    it('parses .xlsx shared strings and Excel date serials', () => {
      const buffer = makeXlsx([
        ['Trade ID', 'Ticker', 'Trade Date', 'Settlement Date', 'Side', 'Quantity', 'Price', 'Gross Amount', 'Commission', 'Taxes', 'Net Amount', 'Currency', 'Exchange', 'FX Rate to THB'],
        ['XLSX-1', 'AAPL US Equity', '46322', '46317', 'BUY', '1', '100.25', '100.25', '0', '0', '100.25', 'THB', 'NASDAQ', ''],
      ]);
      const [transaction] = parseBloombergTradesFile(buffer, 'terminal-export.xlsx');
      expect(transaction).toMatchObject({ date: '2026-10-27', symbol: 'AAPL', originalCurrency: 'THB', netTHB: '100.25' });
    });

    it('rejects legacy binary .xls explicitly', () => {
      expect(() => parseBloombergTradesFile(new Uint8Array([1, 2, 3]), 'export.xls')).toThrow(/Legacy .xls/);
    });
  });

  describe('corporate action parsing', () => {
    it('parses splits, dividends, dates, and currency values for review', () => {
      const content = [
        'Action ID,Ticker,Action Type,Effective Date,Announcement Date,Ratio,Cash Amount,Currency,Description',
        'CA-1,AAPL US Equity,Stock Split,2026-10-20,2026-10-01,2:1,,,Two-for-one split',
        'CA-2,MSFT US Equity,Cash Dividend,2026-10-22,2026-10-05,,0.83,USD,Quarterly cash dividend',
      ].join('\n');
      const actions = parseBloombergCorporateActions(content);
      expect(actions).toHaveLength(2);
      expect(actions[0]).toMatchObject({ actionType: 'STOCK_SPLIT', ratio: '2:1', effectiveDate: '2026-10-20' });
      expect(actions[1]).toMatchObject({ actionType: 'DIVIDEND', cashAmount: '0.83', currency: 'USD', description: 'Quarterly cash dividend' });
    });

    it('rejects unsupported corporate action types instead of defaulting them to dividends', () => {
      const content = [
        'Ticker,Action Type,Effective Date',
        'AAPL US Equity,Unknown Event,2026-10-20',
      ].join('\n');
      expect(() => parseBloombergCorporateActions(content)).toThrow(/Unsupported Bloomberg corporate action type/);
    });

    it('supports corporate action .xlsx previews', () => {
      const buffer = makeXlsx([
        ['Ticker', 'Action Type', 'Effective Date', 'Announcement Date', 'Ratio'],
        ['AAPL US Equity', 'Stock Split', '46322', '46300', '2:1'],
      ]);
      const [action] = parseBloombergCorporateActionsFile(buffer, 'actions.xlsx');
      expect(action).toMatchObject({ effectiveDate: '2026-10-27', announcementDate: '2026-10-05', ratio: '2:1' });
    });
  });
});
