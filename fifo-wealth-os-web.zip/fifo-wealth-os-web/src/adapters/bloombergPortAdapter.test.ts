import { BloombergPortAdapter } from './bloombergPortAdapter';
import type { BloombergPortTransport } from '../types/bloomberg';

describe('Bloomberg Port adapter boundary', () => {
  it('exposes an explicit empty sandbox mock and never claims it is connected', async () => {
    const adapter = new BloombergPortAdapter({ portfolioId: 'portfolio-1', environment: 'SANDBOX' });
    expect(adapter.getStatus()).toMatchObject({
      environment: 'SANDBOX',
      mode: 'SANDBOX_MOCK',
      connected: false,
      liveEnabled: false,
    });
    await expect(adapter.fetchPositions()).resolves.toEqual([]);
    await expect(adapter.fetchTradeHistory('2026-01-01', '2026-12-31')).resolves.toEqual([]);
    await expect(adapter.fetchCorporateActions('2026-01-01', '2026-12-31')).resolves.toEqual([]);
  });

  it('fails closed for LIVE until a reviewed transport is injected', async () => {
    const adapter = new BloombergPortAdapter({ portfolioId: 'portfolio-1', environment: 'LIVE' });
    expect(adapter.getStatus()).toMatchObject({
      mode: 'LIVE_TRANSPORT_NOT_CONFIGURED',
      connected: false,
      liveEnabled: false,
    });
    await expect(adapter.fetchPositions()).rejects.toThrow(/no verified API transport/);
  });

  it('uses only an injected transport and does not represent it as authenticated', async () => {
    const transport: BloombergPortTransport = {
      fetchPositions: jest.fn().mockResolvedValue([]),
      fetchTradeHistory: jest.fn().mockResolvedValue([]),
      fetchCorporateActions: jest.fn().mockResolvedValue([]),
    };
    const adapter = new BloombergPortAdapter({ portfolioId: 'portfolio-1', environment: 'LIVE' }, transport);
    expect(adapter.getStatus()).toMatchObject({ mode: 'LIVE_TRANSPORT_INJECTED', connected: false, liveEnabled: true });
    await adapter.fetchTradeHistory('2026-01-01', '2026-12-31');
    expect(transport.fetchTradeHistory).toHaveBeenCalledWith('portfolio-1', '2026-01-01', '2026-12-31');
  });

  it('validates Port date ranges before invoking a live transport', async () => {
    const transport: BloombergPortTransport = {
      fetchPositions: jest.fn().mockResolvedValue([]),
      fetchTradeHistory: jest.fn().mockResolvedValue([]),
      fetchCorporateActions: jest.fn().mockResolvedValue([]),
    };
    const adapter = new BloombergPortAdapter({ portfolioId: 'portfolio-1', environment: 'LIVE' }, transport);
    await expect(adapter.fetchTradeHistory('2026-12-31', '2026-01-01')).rejects.toThrow(/start date must not be after/);
    expect(transport.fetchTradeHistory).not.toHaveBeenCalled();
  });
});
