import fs from 'fs';
import os from 'os';
import path from 'path';
import Decimal from 'decimal.js';
import request from 'supertest';
import {
  assertPublicAddressOnly,
  detectChainFromAddress,
  hashWalletAddress,
  mapOnChainActivitiesToCDM,
  mapSwapToCDM,
  MockCryptoIndexer,
  PrivateKeySecurityError,
} from './cryptoIndexerAdapter';
import { createApp } from '../api/app';
import { getPrismaClient, setPrismaClient } from '../db/prisma';
import { calculateFIFO } from '../fifoEngine';
import { Transaction } from '../types';
import { OnChainSwapActivity } from '../types/crypto';

const ProofDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

describe('Crypto Cross-Chain Wallet Sync — Security, Privacy & On-Chain Swap -> CDM Mapping Suite', () => {
  test('1. Swap Mapping Proof (Decimal precision: 40): converts USDT -> ETH On-chain Swap into SELL USDT (deducting Gas Fee), BUY ETH, and FEE transaction cleanly into Core FIFO', () => {
    const uniswapSwap: OnChainSwapActivity = {
      kind: 'SWAP',
      txHash:
        '0x9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9988',
      blockNumber: 20985300,
      timestamp: '2026-10-18T11:42:15.000Z',
      chain: 'EVM',
      protocol: 'Uniswap V3',
      tokenIn: {
        symbol: 'USDT',
        standard: 'ERC20',
        contractAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
        amount: '3000.00',
        unitPriceUSD: '1.00',
      },
      tokenOut: {
        symbol: 'ETH',
        standard: 'NATIVE',
        contractAddress: null,
        amount: '1.20',
        unitPriceUSD: '2500.00',
      },
      gasFee: {
        tokenSymbol: 'ETH',
        amount: '0.0045',
        unitPriceUSD: '2500.00', // 0.0045 * 2500.00 = 11.25 USD Gas Fee
      },
    };

    const cdmRecords = mapSwapToCDM(uniswapSwap);
    expect(cdmRecords).toHaveLength(3);

    const sellLeg = cdmRecords.find((r) => r.type === 'SELL')!;
    const buyLeg = cdmRecords.find((r) => r.type === 'BUY')!;
    const feeLeg = cdmRecords.find((r) => r.type === 'FEE')!;

    // 1) SELL USDT leg: Gross = $3,000.00, Gas Fee deducted = $11.25 -> Net Proceeds = $2,988.75
    expect(sellLeg.symbol).toBe('USDT');
    expect(sellLeg.qty).toBe(3000);
    expect(sellLeg.price).toBe(1);
    expect(sellLeg.exactGrossDecimal).toBe('3000.00');
    expect(sellLeg.exactCommDecimal).toBe('11.25');
    expect(sellLeg.exactNetDecimal).toBe('2988.75');
    expect(sellLeg.originalNet).toBe('2988.75');

    // 2) BUY ETH leg: Acquires 1.20 ETH @ $2,500.00 -> Cost Basis = $3,000.00
    expect(buyLeg.symbol).toBe('ETH');
    expect(buyLeg.qty).toBe(1.2);
    expect(buyLeg.price).toBe(2500);
    expect(buyLeg.exactGrossDecimal).toBe('3000.00');
    expect(buyLeg.exactCommDecimal).toBe('0.00');
    expect(buyLeg.originalNet).toBe('3000.00');

    // 3) FEE ETH leg: Explicit standalone 'FEE' CDM transaction for 0.0045 ETH ($11.25)
    expect(feeLeg.symbol).toBe('ETH');
    expect(feeLeg.type).toBe('FEE');
    expect(feeLeg.legRole).toBe('GAS_FEE');
    expect(feeLeg.qty).toBe(0.0045);
    expect(feeLeg.price).toBe(2500);
    expect(feeLeg.originalNet).toBe('11.25');

    // Verify exact 40-digit Decimal conservation: SELL Net + FEE Net === SELL Gross
    const conservedSum = new ProofDecimal(sellLeg.originalNet).plus(
      new ProofDecimal(feeLeg.originalNet)
    );
    expect(conservedSum.toFixed(2)).toBe(sellLeg.exactGrossDecimal);

    // Pipe initial USDT funding + Swap BUY/SELL legs into untouched Core `calculateFIFO`
    const initialUsdtDeposit: Transaction = {
      id: 'INIT-USDT',
      date: '2026-10-08',
      symbol: 'USDT',
      qty: 5000,
      price: 1,
      gross: 5000,
      comm: 0,
      vat: 0,
      net: 5000,
      type: 'BUY',
      exchange: 'BINANCE',
      originalCurrency: 'USD',
      originalNet: '5000.00',
      fxRate: '1.00',
      netTHB: '5000.00',
    };

    const fifoBuys: Transaction[] = [
      initialUsdtDeposit,
      { ...(buyLeg as unknown as Transaction), fxRate: '1.00', netTHB: buyLeg.originalNet },
    ];
    const fifoSells: Transaction[] = [
      { ...(sellLeg as unknown as Transaction), fxRate: '1.00', netTHB: sellLeg.originalNet },
    ];

    const fifoResult = calculateFIFO(fifoBuys, fifoSells, {
      USDT: 1.0,
      ETH: 2600.0,
    });

    // Disposing 3,000 USDT ($3,000 cost basis) for $2,988.75 net proceeds realizes exact -$11.25 Gas loss!
    expect(fifoResult.totalRealizedGL).toBe(-11.25);
    // Open ETH lot holds 1.20 ETH @ $2,500 cost/unit -> +$120.00 Unrealized G/L at $2,600 spot
    const ethLot = fifoResult.lots.find((l) => l.symbol === 'ETH')!;
    expect(ethLot.qtyRemain).toBe(1.2);
    expect(ethLot.costPerUnit).toBe(2500);
    expect(ethLot.unrealizedGL).toBe(120);
  });

  test('2. High-Precision Solana SPL Swap & MockCryptoIndexer Cross-Chain Simulation (EVM, SOLANA, BTC)', async () => {
    const indexer = new MockCryptoIndexer();

    const evmAddr = '0x71C7656EC7ab88b098defB751B7401B5f6d8976F';
    const solAddr = '9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin';
    const btcAddr = 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh';

    expect(detectChainFromAddress(evmAddr)).toBe('EVM');
    expect(detectChainFromAddress(solAddr)).toBe('SOLANA');
    expect(detectChainFromAddress(btcAddr)).toBe('BTC');

    const [evmBal, solHistory, btcHistory] = await Promise.all([
      indexer.getTokenBalances('EVM', evmAddr),
      indexer.getTransactionHistory('SOLANA', solAddr),
      indexer.getTransactionHistory('BTC', btcAddr),
    ]);

    expect(evmBal.map((b) => b.symbol)).toEqual(['ETH', 'USDT', 'WBTC']);

    const solCdm = mapOnChainActivitiesToCDM(solHistory);
    // 2 TRANSFER_IN (BUY) + 1 Jupiter SWAP (SELL USDC + BUY SOL + FEE SOL) = 5 CDM records
    expect(solCdm).toHaveLength(5);
    const jupSell = solCdm.find(
      (r) => r.legRole === 'SWAP_SELL' && r.symbol === 'USDC'
    )!;
    const jupFee = solCdm.find(
      (r) => r.legRole === 'GAS_FEE' && r.symbol === 'SOL'
    )!;
    // 1500.00 - (0.00025 * 150.00 = 0.0375) = 1499.9625 exact 4-decimal preservation!
    expect(jupFee.originalNet).toBe('0.0375');
    expect(jupSell.originalNet).toBe('1499.9625');

    const btcCdm = mapOnChainActivitiesToCDM(btcHistory);
    // 1 TRANSFER_IN (BUY) + 1 TRANSFER_OUT (SELL + FEE) = 3 CDM records
    expect(btcCdm).toHaveLength(3);
  });

  test('3. Hard Security Guardrail (NO PRIVATE KEYS): immediately blocks Seed Phrases, EVM Hex PrivKeys, BTC WIF/xprv, and Solana Secret Keys', () => {
    // 12-word BIP-39 Seed Phrase
    expect(() =>
      assertPublicAddressOnly(
        'abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about'
      )
    ).toThrow(PrivateKeySecurityError);

    // 64-hex EVM Private Key (with and without 0x)
    expect(() =>
      assertPublicAddressOnly(
        '0x4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318'
      )
    ).toThrow(PrivateKeySecurityError);
    expect(() =>
      assertPublicAddressOnly(
        '4c0883a69102937d6231471b5dbb6204fe5129617082792ae468d01a3f362318'
      )
    ).toThrow(PrivateKeySecurityError);

    // Bitcoin WIF & xprv
    expect(() =>
      assertPublicAddressOnly(
        '5HueCGU8rMjxEXxiPuD5BDku4MkFqeZyd4dZ1jvhTVqvbTLvyTJ'
      )
    ).toThrow(PrivateKeySecurityError);
    expect(() =>
      assertPublicAddressOnly(
        'xprv9s21ZrQH143K3QTDL4LXw2F7HEK3wJUD2nW2nRk4stbPy6cq3jPPqjiChkVvvNKmPGJxWUtg6LnF5kejMRNNU3TGtRBeJgk33yuGBxrMPHi'
      )
    ).toThrow(PrivateKeySecurityError);

    // Solana JSON secret key array
    expect(() =>
      assertPublicAddressOnly(
        '[12,34,56,78,90,12,34,56,78,90,12,34,56,78,90,12,34,56,78,90,12,34,56,78,90,12,34,56,78,90,12,34]'
      )
    ).toThrow(PrivateKeySecurityError);
  });

  test('4. Full REST API & DB Privacy Verification: AES-256-GCM + SHA-256 storage, Zero plaintext leak, Idempotent On-Chain Sync & Multi-User Isolation', async () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fifo-crypto-api-'));
    const tmpDbPath = path.join(tmpDir, 'crypto-sync.db');
    fs.copyFileSync(path.resolve(__dirname, '../../prisma/dev.db'), tmpDbPath);

    const prevDbUrl = process.env['DATABASE_URL'];
    process.env['DATABASE_URL'] = `file:${tmpDbPath}`;
    process.env['JWT_SECRET'] = 'crypto-sync-jwt-secret';
    process.env['ENCRYPTION_KEY'] =
      'crypto-wallet-aes-256-gcm-privacy-key-2026';
    setPrismaClient(null);

    const PUBLIC_EVM_ADDR = '0x71C7656EC7ab88b098defB751B7401B5f6d8976F';

    try {
      const app = createApp();
      const regA = await request(app).post('/api/auth/register').send({
        email: 'blockchain-auditor@wealthos.th',
        password: 'Password123!',
        name: 'OnChain Security Auditor',
      });
      const tokenA = regA.body.token as string;

      const regB = await request(app).post('/api/auth/register').send({
        email: 'outsider-crypto@wealthos.th',
        password: 'Password123!',
        name: 'Outsider User',
      });
      const tokenB = regB.body.token as string;

      // Attempt to submit a Seed Phrase via API -> must reject with 400 SECURITY_PRIVATE_KEY_REJECTED
      const seedRes = await request(app)
        .post('/api/crypto/wallets')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({
          address:
            'witch collapse practice feed shame open despair creek road again ice least',
        });
      expect(seedRes.status).toBe(400);
      expect(seedRes.body.error.code).toBe('SECURITY_PRIVATE_KEY_REJECTED');

      // Register valid public EVM address WITHOUT passing `chain` -> auto-detects 'EVM'
      const createRes = await request(app)
        .post('/api/crypto/wallets')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({
          address: PUBLIC_EVM_ADDR,
          label: 'Ledger Hardware Vault',
        })
        .expect(201);

      const wallet = createRes.body.wallet;
      expect(wallet.chain).toBe('EVM');
      expect(wallet.addressMasked).toBe('0x71C7...976F');
      expect(wallet.addressHash).toBe(
        hashWalletAddress('EVM', PUBLIC_EVM_ADDR)
      );
      // API response must NEVER contain plaintext or encrypted `address` field
      expect(JSON.stringify(createRes.body)).not.toContain(PUBLIC_EVM_ADDR);
      expect(JSON.stringify(createRes.body)).not.toContain(
        PUBLIC_EVM_ADDR.toLowerCase()
      );

      // Inspect raw SQLite row -> `address` column must be AES-256-GCM ciphertext (`v1:...`), never plaintext!
      const prisma = getPrismaClient();
      const rawDbRow = await prisma.cryptoWallet.findUnique({
        where: { id: wallet.id },
      });
      expect(rawDbRow?.address.startsWith('v1:')).toBe(true);
      expect(rawDbRow?.address).not.toContain('71c7656e');

      // First Sync On-chain Data -> 3 On-Chain activities -> 5 CDM records (2 BUY transfers + 1 Swap SELL + 1 Swap BUY + 1 Gas FEE)
      const sync1 = await request(app)
        .post(`/api/crypto/wallets/${wallet.id}/sync`)
        .set('Authorization', `Bearer ${tokenA}`)
        .send({})
        .expect(200);

      expect(sync1.body.discoveredOnChainCount).toBe(3);
      expect(sync1.body.generatedCdmCount).toBe(5);
      expect(sync1.body.addedTransactions).toBe(5);
      expect(sync1.body.skippedTransactions).toBe(0);
      expect(sync1.body.breakdown).toEqual({
        swaps: 1,
        transfers: 2,
        buyLegs: 3,
        sellLegs: 1,
        feeLegs: 1,
      });

      // Second Sync On-chain Data -> 100% Idempotent (0 duplicates added, 5 skipped!)
      const sync2 = await request(app)
        .post(`/api/crypto/wallets/${wallet.id}/sync`)
        .set('Authorization', `Bearer ${tokenA}`)
        .send({})
        .expect(200);
      expect(sync2.body.addedTransactions).toBe(0);
      expect(sync2.body.skippedTransactions).toBe(5);

      // User B attempting to sync or delete User A's wallet -> strictly 403 Forbidden
      await request(app)
        .post(`/api/crypto/wallets/${wallet.id}/sync`)
        .set('Authorization', `Bearer ${tokenB}`)
        .send({})
        .expect(403);
    } finally {
      await getPrismaClient().$disconnect();
      setPrismaClient(null);
      if (prevDbUrl) {
        process.env['DATABASE_URL'] = prevDbUrl;
      } else {
        delete process.env['DATABASE_URL'];
      }
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });
});
