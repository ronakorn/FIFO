import crypto from 'crypto';
import Decimal from 'decimal.js';
import { formatExactDecimalString, toNumber } from '../parsers/csvUtils';
import { encryptData } from '../services/encryptionService';
import { Exchange } from '../types';
import {
  CDMOnChainTransaction,
  CDMOnChainTransactionType,
  ChainIndexerProvider,
  OnChainActivity,
  OnChainLegRole,
  OnChainSwapActivity,
  OnChainTokenBalance,
  OnChainTransferActivity,
  SUPPORTED_CHAINS,
  SupportedChain,
} from '../types/crypto';

/**
 * Institutional Blockchain & Crypto Accounting Decimal Engine (strictly precision: 40)
 */
export const CryptoDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

const EVM_ADDRESS_REGEX = /^0x[a-fA-F0-9]{40}$/;
const BTC_ADDRESS_REGEX =
  /^(bc1[ac-hj-np-z02-9]{25,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/;
const SOLANA_ADDRESS_REGEX = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

// Patterns indicating Private Keys or Mnemonic Seed Phrases — strictly forbidden!
const EVM_HEX_PRIVATE_KEY_REGEX = /^(0x)?[a-fA-F0-9]{64}$/;
const BTC_WIF_PRIVATE_KEY_REGEX = /^[5KL][1-9A-HJ-NP-Za-km-z]{50,51}$/;
const EXTENDED_PRIVKEY_REGEX = /^(xprv|yprv|zprv|tprv)[a-zA-Z0-9]{90,120}$/;
const SOLANA_SECRET_KEY_BASE58_REGEX = /^[1-9A-HJ-NP-Za-km-z]{80,96}$/;
const SOLANA_SECRET_JSON_ARRAY_REGEX = /^\[\s*\d+(?:\s*,\s*\d+){31,64}\s*\]$/;

export class PrivateKeySecurityError extends Error {
  public readonly code = 'SECURITY_PRIVATE_KEY_REJECTED';

  constructor(message: string) {
    super(message);
    this.name = 'PrivateKeySecurityError';
  }
}

/**
 * Hard Security Guardrail (NO PRIVATE KEYS):
 * Inspects user input and immediately rejects BIP-39 Seed Phrases, 64-hex EVM private keys,
 * BTC WIF / xprv extended private keys, and Solana 64-byte secret keys before touching memory/DB.
 * Never echoes the rejected secret back in error messages or logs.
 */
export function assertPublicAddressOnly(rawInput: string): void {
  const trimmed = String(rawInput ?? '').trim();
  if (!trimmed) {
    throw new Error('Wallet address is required.');
  }

  // 1. Detect multi-word BIP-39 Mnemonic Seed Phrases (e.g. 12, 15, 18, 21, 24 words)
  const words = trimmed.split(/\s+/).filter(Boolean);
  if (words.length >= 3 && words.every((w) => /^[a-zA-Z]+$/.test(w))) {
    throw new PrivateKeySecurityError(
      'SECURITY BLOCK: Mnemonic Seed Phrases are strictly forbidden. FIFO Wealth OS is 100% Read-Only — enter a public wallet address only.'
    );
  }

  // 2. Detect raw 32-byte (64 hex chars) EVM / Bitcoin hex private keys
  if (EVM_HEX_PRIVATE_KEY_REGEX.test(trimmed)) {
    throw new PrivateKeySecurityError(
      'SECURITY BLOCK: Raw 64-character hex private keys are strictly forbidden. Provide a 42-character public 0x address only.'
    );
  }

  // 3. Detect Bitcoin WIF or HD extended private keys (xprv/yprv/zprv)
  if (
    BTC_WIF_PRIVATE_KEY_REGEX.test(trimmed) ||
    EXTENDED_PRIVKEY_REGEX.test(trimmed)
  ) {
    throw new PrivateKeySecurityError(
      'SECURITY BLOCK: Bitcoin WIF / extended private keys (xprv) are strictly forbidden. Provide a public BTC address (bc1..., 1..., 3...) only.'
    );
  }

  // 4. Detect Solana Base58 64-byte keypair or JSON secret array
  if (
    SOLANA_SECRET_KEY_BASE58_REGEX.test(trimmed) ||
    SOLANA_SECRET_JSON_ARRAY_REGEX.test(trimmed)
  ) {
    throw new PrivateKeySecurityError(
      'SECURITY BLOCK: Solana secret keypairs are strictly forbidden. Provide a public Base58 wallet address (32–44 chars) only.'
    );
  }
}

/**
 * Automatically detects the blockchain family (`'EVM' | 'SOLANA' | 'BTC'`) from public address format.
 * Runs `assertPublicAddressOnly` first to block any private key material.
 */
export function detectChainFromAddress(
  rawAddress: string
): SupportedChain | null {
  assertPublicAddressOnly(rawAddress);
  const trimmed = rawAddress.trim();

  if (EVM_ADDRESS_REGEX.test(trimmed)) {
    return 'EVM';
  }
  if (BTC_ADDRESS_REGEX.test(trimmed)) {
    return 'BTC';
  }
  if (SOLANA_ADDRESS_REGEX.test(trimmed)) {
    return 'SOLANA';
  }
  return null;
}

/**
 * Validates and normalizes a public wallet address for a specific chain.
 * - EVM addresses are lowercased (`0x...`) for canonical hashing while preserving hex validity.
 * - BTC Bech32 (`bc1...`) addresses are lowercased; Base58 (`1...`, `3...`) and Solana SPL preserve case.
 */
export function normalizeWalletAddress(
  chain: SupportedChain,
  rawAddress: string
): string {
  assertPublicAddressOnly(rawAddress);
  const trimmed = rawAddress.trim();
  const detected = detectChainFromAddress(trimmed);

  if (!detected) {
    throw new Error('Invalid public wallet address format.');
  }
  if (detected !== chain) {
    throw new Error(
      `Address format matches ${detected}, which does not match selected chain ${chain}.`
    );
  }

  if (chain === 'EVM') {
    return trimmed.toLowerCase();
  }
  if (chain === 'BTC' && trimmed.toLowerCase().startsWith('bc1')) {
    return trimmed.toLowerCase();
  }
  return trimmed;
}

/**
 * Privacy-First SHA-256 Address Hash (`SHA256(chain + ":" + canonicalAddress)`).
 * Enables O(1) uniqueness checks in DB without storing plaintext addresses in indexes.
 */
export function hashWalletAddress(
  chain: SupportedChain,
  rawAddress: string
): string {
  const canonical = normalizeWalletAddress(chain, rawAddress);
  return crypto
    .createHash('sha256')
    .update(`${chain}:${canonical}`, 'utf8')
    .digest('hex');
}

/**
 * Privacy-First AES-256-GCM Address Encryption before DB storage.
 */
export function encryptWalletAddress(
  chain: SupportedChain,
  rawAddress: string
): string {
  const canonical = normalizeWalletAddress(chain, rawAddress);
  return encryptData(canonical);
}

/**
 * Masks a public wallet address for UI display (`0x71C7...976F`) so full addresses
 * never leak across API payloads or screen shares.
 */
export function maskWalletAddress(
  chain: SupportedChain,
  rawAddress: string
): string {
  const trimmed = rawAddress.trim();
  void chain;
  if (trimmed.length <= 12) return trimmed;
  return `${trimmed.slice(0, 6)}...${trimmed.slice(-4)}`;
}

/**
 * Computes deterministic SHA-256 Idempotency Hash for an On-chain CDM leg
 * so repeated wallet syncs never duplicate `BUY`, `SELL`, or `FEE` records.
 */
export function computeOnChainCdmHash(input: {
  chain: SupportedChain;
  txHash: string;
  legRole: OnChainLegRole;
  type: CDMOnChainTransactionType;
  symbol: string;
  qty: Decimal.Value;
}): string {
  const canonicalQty = new CryptoDecimal(String(input.qty)).abs().toFixed(8);
  const payload = [
    'ONCHAIN',
    input.chain,
    input.txHash.trim().toLowerCase(),
    input.legRole,
    input.type,
    input.symbol.trim().toUpperCase(),
    canonicalQty,
  ].join('|');

  return crypto.createHash('sha256').update(payload, 'utf8').digest('hex');
}

function normalizeIsoDateOnly(timestamp: string): string {
  const trimmed = timestamp.trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) {
    return trimmed.slice(0, 10);
  }
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error(`Invalid on-chain timestamp: "${timestamp}".`);
  }
  return parsed.toISOString().slice(0, 10);
}

function resolveExchangeTagForChain(chain: SupportedChain): Exchange {
  // Maps cross-chain decentralized sync onto CDM `Exchange` union without modifying `src/types.ts`
  switch (chain) {
    case 'EVM':
    case 'SOLANA':
    case 'BTC':
      return 'BINANCE';
  }
}

/**
 * Maps a single On-Chain DEX Swap (e.g. `3,000 USDT -> 1.20 ETH` with `0.0045 ETH` Gas)
 * into Canonical Data Model (CDM) transactions using `Decimal.js (precision: 40)`:
 *
 *   1. `'SELL'` (`tokenIn`, e.g. `USDT`):
 *      - `gross = amountIn * unitPriceInUSD`
 *      - `comm  = gasFeeUSD` (`gasFee.amount * gasFee.unitPriceUSD`)
 *      - `net   = max(0, gross - gasFeeUSD)` (deducts On-chain Gas Fee from disposal proceeds!)
 *   2. `'BUY'` (`tokenOut`, e.g. `ETH`):
 *      - `gross = amountOut * unitPriceOutUSD`
 *      - `comm  = 0` (prevents double-counting gas deduction already applied on `SELL` leg)
 *      - `net   = gross`
 *   3. `'FEE'` (`gasFee.tokenSymbol`, e.g. `ETH`) — emitted whenever `gasAmount > 0`:
 *      - Explicit standalone `'FEE'` CDM transaction recording the exact native gas token spent
 *        (`qty = gasFee.amount`, `price = gasFee.unitPriceUSD`, `net = gasFeeUSD`).
 */
export function mapSwapToCDM(
  swap: OnChainSwapActivity
): CDMOnChainTransaction[] {
  const isoDate = normalizeIsoDateOnly(swap.timestamp);
  const exchange = resolveExchangeTagForChain(swap.chain);

  const amountInDec = new CryptoDecimal(swap.tokenIn.amount);
  const priceInDec = new CryptoDecimal(swap.tokenIn.unitPriceUSD);
  const amountOutDec = new CryptoDecimal(swap.tokenOut.amount);
  const priceOutDec = new CryptoDecimal(swap.tokenOut.unitPriceUSD);

  const gasQtyDec = new CryptoDecimal(swap.gasFee.amount);
  const gasPriceDec = new CryptoDecimal(swap.gasFee.unitPriceUSD);

  if (amountInDec.lte(0) || amountOutDec.lte(0)) {
    throw new Error(
      `Invalid Swap quantities in tx "${swap.txHash}": amounts must be strictly positive.`
    );
  }
  if (priceInDec.lt(0) || priceOutDec.lt(0) || gasQtyDec.lt(0) || gasPriceDec.lt(0)) {
    throw new Error(
      `Negative price or gas fee detected in Swap tx "${swap.txHash}".`
    );
  }

  const sellGrossDec = amountInDec.times(priceInDec);
  const gasFeeUsdDec = gasQtyDec.times(gasPriceDec);
  const sellNetDec = CryptoDecimal.max(
    new CryptoDecimal(0),
    sellGrossDec.minus(gasFeeUsdDec)
  );

  const buyGrossDec = amountOutDec.times(priceOutDec);
  const buyNetDec = buyGrossDec;

  const tokenInSym = swap.tokenIn.symbol.trim().toUpperCase();
  const tokenOutSym = swap.tokenOut.symbol.trim().toUpperCase();
  const gasSym = swap.gasFee.tokenSymbol.trim().toUpperCase();

  const sellHash = computeOnChainCdmHash({
    chain: swap.chain,
    txHash: swap.txHash,
    legRole: 'SWAP_SELL',
    type: 'SELL',
    symbol: tokenInSym,
    qty: amountInDec,
  });

  const buyHash = computeOnChainCdmHash({
    chain: swap.chain,
    txHash: swap.txHash,
    legRole: 'SWAP_BUY',
    type: 'BUY',
    symbol: tokenOutSym,
    qty: amountOutDec,
  });

  const records: CDMOnChainTransaction[] = [
    {
      id: `ONCHAIN-${swap.chain}-${swap.txHash.slice(0, 10)}-SELL`,
      date: isoDate,
      symbol: tokenInSym,
      qty: toNumber(amountInDec),
      price: toNumber(priceInDec),
      gross: toNumber(sellGrossDec),
      comm: toNumber(gasFeeUsdDec),
      vat: 0,
      net: toNumber(sellNetDec),
      type: 'SELL',
      exchange,
      currency: 'USD',
      originalCurrency: 'USD',
      originalNet: formatExactDecimalString(sellNetDec),
      fxRate: null,
      netTHB: null,
      txHash: swap.txHash,
      chain: swap.chain,
      legRole: 'SWAP_SELL',
      protocol: swap.protocol,
      exactGrossDecimal: formatExactDecimalString(sellGrossDec),
      exactCommDecimal: formatExactDecimalString(gasFeeUsdDec),
      exactNetDecimal: formatExactDecimalString(sellNetDec),
      idempotencyHash: sellHash,
    },
    {
      id: `ONCHAIN-${swap.chain}-${swap.txHash.slice(0, 10)}-BUY`,
      date: isoDate,
      symbol: tokenOutSym,
      qty: toNumber(amountOutDec),
      price: toNumber(priceOutDec),
      gross: toNumber(buyGrossDec),
      comm: 0,
      vat: 0,
      net: toNumber(buyNetDec),
      type: 'BUY',
      exchange,
      currency: 'USD',
      originalCurrency: 'USD',
      originalNet: formatExactDecimalString(buyNetDec),
      fxRate: null,
      netTHB: null,
      txHash: swap.txHash,
      chain: swap.chain,
      legRole: 'SWAP_BUY',
      protocol: swap.protocol,
      exactGrossDecimal: formatExactDecimalString(buyGrossDec),
      exactCommDecimal: '0.00',
      exactNetDecimal: formatExactDecimalString(buyNetDec),
      idempotencyHash: buyHash,
    },
  ];

  if (gasQtyDec.gt(0)) {
    const feeHash = computeOnChainCdmHash({
      chain: swap.chain,
      txHash: swap.txHash,
      legRole: 'GAS_FEE',
      type: 'FEE',
      symbol: gasSym,
      qty: gasQtyDec,
    });

    records.push({
      id: `ONCHAIN-${swap.chain}-${swap.txHash.slice(0, 10)}-FEE`,
      date: isoDate,
      symbol: gasSym,
      qty: toNumber(gasQtyDec),
      price: toNumber(gasPriceDec),
      gross: toNumber(gasFeeUsdDec),
      comm: toNumber(gasFeeUsdDec),
      vat: 0,
      net: toNumber(gasFeeUsdDec),
      type: 'FEE',
      exchange,
      currency: 'USD',
      originalCurrency: 'USD',
      originalNet: formatExactDecimalString(gasFeeUsdDec),
      fxRate: null,
      netTHB: null,
      txHash: swap.txHash,
      chain: swap.chain,
      legRole: 'GAS_FEE',
      protocol: swap.protocol,
      exactGrossDecimal: formatExactDecimalString(gasFeeUsdDec),
      exactCommDecimal: formatExactDecimalString(gasFeeUsdDec),
      exactNetDecimal: formatExactDecimalString(gasFeeUsdDec),
      idempotencyHash: feeHash,
    });
  }

  return records;
}

/**
 * Maps an On-Chain Transfer (`IN` or `OUT`) into CDM transactions (`BUY` / `SELL` + optional `'FEE'`).
 */
export function mapTransferToCDM(
  transfer: OnChainTransferActivity
): CDMOnChainTransaction[] {
  const isoDate = normalizeIsoDateOnly(transfer.timestamp);
  const exchange = resolveExchangeTagForChain(transfer.chain);

  const qtyDec = new CryptoDecimal(transfer.token.amount);
  const priceDec = new CryptoDecimal(transfer.token.unitPriceUSD);
  if (qtyDec.lte(0) || priceDec.lt(0)) {
    throw new Error(
      `Invalid Transfer amount or price in tx "${transfer.txHash}".`
    );
  }

  const grossDec = qtyDec.times(priceDec);
  const gasQtyDec = transfer.gasFee
    ? new CryptoDecimal(transfer.gasFee.amount)
    : new CryptoDecimal(0);
  const gasPriceDec = transfer.gasFee
    ? new CryptoDecimal(transfer.gasFee.unitPriceUSD)
    : new CryptoDecimal(0);
  const gasFeeUsdDec = gasQtyDec.times(gasPriceDec);

  const isInflow = transfer.direction === 'IN';
  const netDec = isInflow
    ? grossDec.plus(gasFeeUsdDec)
    : CryptoDecimal.max(new CryptoDecimal(0), grossDec.minus(gasFeeUsdDec));

  const sym = transfer.token.symbol.trim().toUpperCase();
  const legRole: OnChainLegRole = isInflow ? 'TRANSFER_IN' : 'TRANSFER_OUT';
  const txType: CDMOnChainTransactionType = isInflow ? 'BUY' : 'SELL';

  const mainHash = computeOnChainCdmHash({
    chain: transfer.chain,
    txHash: transfer.txHash,
    legRole,
    type: txType,
    symbol: sym,
    qty: qtyDec,
  });

  const out: CDMOnChainTransaction[] = [
    {
      id: `ONCHAIN-${transfer.chain}-${transfer.txHash.slice(0, 10)}-${legRole}`,
      date: isoDate,
      symbol: sym,
      qty: toNumber(qtyDec),
      price: toNumber(priceDec),
      gross: toNumber(grossDec),
      comm: toNumber(gasFeeUsdDec),
      vat: 0,
      net: toNumber(netDec),
      type: txType,
      exchange,
      currency: 'USD',
      originalCurrency: 'USD',
      originalNet: formatExactDecimalString(netDec),
      fxRate: null,
      netTHB: null,
      txHash: transfer.txHash,
      chain: transfer.chain,
      legRole,
      exactGrossDecimal: formatExactDecimalString(grossDec),
      exactCommDecimal: formatExactDecimalString(gasFeeUsdDec),
      exactNetDecimal: formatExactDecimalString(netDec),
      idempotencyHash: mainHash,
    },
  ];

  if (transfer.gasFee && gasQtyDec.gt(0)) {
    const gasSym = transfer.gasFee.tokenSymbol.trim().toUpperCase();
    const feeHash = computeOnChainCdmHash({
      chain: transfer.chain,
      txHash: transfer.txHash,
      legRole: 'GAS_FEE',
      type: 'FEE',
      symbol: gasSym,
      qty: gasQtyDec,
    });

    out.push({
      id: `ONCHAIN-${transfer.chain}-${transfer.txHash.slice(0, 10)}-FEE`,
      date: isoDate,
      symbol: gasSym,
      qty: toNumber(gasQtyDec),
      price: toNumber(gasPriceDec),
      gross: toNumber(gasFeeUsdDec),
      comm: toNumber(gasFeeUsdDec),
      vat: 0,
      net: toNumber(gasFeeUsdDec),
      type: 'FEE',
      exchange,
      currency: 'USD',
      originalCurrency: 'USD',
      originalNet: formatExactDecimalString(gasFeeUsdDec),
      fxRate: null,
      netTHB: null,
      txHash: transfer.txHash,
      chain: transfer.chain,
      legRole: 'GAS_FEE',
      exactGrossDecimal: formatExactDecimalString(gasFeeUsdDec),
      exactCommDecimal: formatExactDecimalString(gasFeeUsdDec),
      exactNetDecimal: formatExactDecimalString(gasFeeUsdDec),
      idempotencyHash: feeHash,
    });
  }

  return out;
}

/**
 * Maps an array of On-Chain activities (`Swaps` & `Transfers`) into deduplicated CDM transactions,
 * ordered chronologically so FIFO cost basis lots are acquired before disposals.
 */
export function mapOnChainActivitiesToCDM(
  activities: readonly OnChainActivity[]
): CDMOnChainTransaction[] {
  const sorted = [...activities].sort((a, b) =>
    a.timestamp.localeCompare(b.timestamp)
  );

  const cdmList: CDMOnChainTransaction[] = [];
  const seenHashes = new Set<string>();

  for (const act of sorted) {
    const mapped =
      act.kind === 'SWAP' ? mapSwapToCDM(act) : mapTransferToCDM(act);
    for (const item of mapped) {
      if (!seenHashes.has(item.idempotencyHash)) {
        seenHashes.add(item.idempotencyHash);
        cdmList.push(item);
      }
    }
  }

  return cdmList;
}

/**
 * Deterministic Read-Only Cross-Chain Indexer Simulator (`MockCryptoIndexer`)
 * implementing `ChainIndexerProvider` (drop-in compatible with Alchemy, Moralis, or Covalent).
 */
export class MockCryptoIndexer implements ChainIndexerProvider {
  public readonly providerName = 'MOCK_CROSSCHAIN_INDEXER_V1';
  public readonly supportedChains = SUPPORTED_CHAINS;

  public async getTokenBalances(
    chain: SupportedChain,
    walletAddress: string
  ): Promise<OnChainTokenBalance[]> {
    const normalized = normalizeWalletAddress(chain, walletAddress);
    // Deterministic minor seed from address hash so different addresses stay consistent
    const addrDigest = crypto
      .createHash('sha256')
      .update(`${chain}:${normalized}`, 'utf8')
      .digest();
    const bonusBps = addrDigest[0]! % 5; // 0..4 deterministic variation if desired (kept 0-drift exact)
    void bonusBps;

    if (chain === 'EVM') {
      const balances: Array<{
        symbol: string;
        name: string;
        standard: 'NATIVE' | 'ERC20';
        contractAddress: string | null;
        decimals: number;
        balance: string;
        priceUSD: string;
      }> = [
        {
          symbol: 'ETH',
          name: 'Ethereum',
          standard: 'NATIVE',
          contractAddress: null,
          decimals: 18,
          balance: '1.6955',
          priceUSD: '2580.00',
        },
        {
          symbol: 'USDT',
          name: 'Tether USD (ERC-20)',
          standard: 'ERC20',
          contractAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
          decimals: 6,
          balance: '2000.00',
          priceUSD: '1.00',
        },
        {
          symbol: 'WBTC',
          name: 'Wrapped BTC (ERC-20)',
          standard: 'ERC20',
          contractAddress: '0x2260fac5e5542a773aa44fbcfedf7c193bc2c599',
          decimals: 8,
          balance: '0.1500',
          priceUSD: '68500.00',
        },
      ];

      return balances.map((b) => ({
        chain,
        ...b,
        valueUSD: new CryptoDecimal(b.balance)
          .times(new CryptoDecimal(b.priceUSD))
          .toFixed(2),
      }));
    }

    if (chain === 'SOLANA') {
      const balances: Array<{
        symbol: string;
        name: string;
        standard: 'NATIVE' | 'SPL';
        contractAddress: string | null;
        decimals: number;
        balance: string;
        priceUSD: string;
      }> = [
        {
          symbol: 'SOL',
          name: 'Solana',
          standard: 'NATIVE',
          contractAddress: null,
          decimals: 9,
          balance: '19.99975',
          priceUSD: '162.00',
        },
        {
          symbol: 'USDC',
          name: 'USD Coin (SPL)',
          standard: 'SPL',
          contractAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
          decimals: 6,
          balance: '500.00',
          priceUSD: '1.00',
        },
        {
          symbol: 'JUP',
          name: 'Jupiter (SPL)',
          standard: 'SPL',
          contractAddress: 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN',
          decimals: 6,
          balance: '850.00',
          priceUSD: '1.05',
        },
      ];

      return balances.map((b) => ({
        chain,
        ...b,
        valueUSD: new CryptoDecimal(b.balance)
          .times(new CryptoDecimal(b.priceUSD))
          .toFixed(2),
      }));
    }

    // BTC (Native UTXO)
    const btcBalance = '0.2000';
    const btcPrice = '69500.00';
    return [
      {
        chain: 'BTC',
        symbol: 'BTC',
        name: 'Bitcoin (Native SegWit)',
        standard: 'UTXO',
        contractAddress: null,
        decimals: 8,
        balance: btcBalance,
        priceUSD: btcPrice,
        valueUSD: new CryptoDecimal(btcBalance)
          .times(new CryptoDecimal(btcPrice))
          .toFixed(2),
      },
    ];
  }

  public async getTransactionHistory(
    chain: SupportedChain,
    walletAddress: string,
    options?: { fromDate?: string; toDate?: string }
  ): Promise<OnChainActivity[]> {
    const normalized = normalizeWalletAddress(chain, walletAddress);
    const shortDigest = crypto
      .createHash('sha256')
      .update(`${chain}:${normalized}`, 'utf8')
      .digest('hex')
      .slice(0, 16);

    let events: OnChainActivity[];

    if (chain === 'EVM') {
      events = [
        {
          kind: 'TRANSFER',
          direction: 'IN',
          txHash: `0x${shortDigest}a10001`,
          blockNumber: 20910110,
          timestamp: '2026-10-08T09:15:00.000Z',
          chain: 'EVM',
          counterpartyMasked: '0x28C6...1d60',
          token: {
            symbol: 'USDT',
            standard: 'ERC20',
            contractAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
            amount: '5000.00',
            unitPriceUSD: '1.00',
          },
        },
        {
          kind: 'TRANSFER',
          direction: 'IN',
          txHash: `0x${shortDigest}a10002`,
          blockNumber: 20912450,
          timestamp: '2026-10-10T14:20:00.000Z',
          chain: 'EVM',
          counterpartyMasked: '0x3f5C...f0bE',
          token: {
            symbol: 'ETH',
            standard: 'NATIVE',
            contractAddress: null,
            amount: '0.50',
            unitPriceUSD: '2420.00',
          },
        },
        {
          kind: 'SWAP',
          txHash: `0x${shortDigest}b20003`,
          blockNumber: 20985300,
          timestamp: '2026-10-18T11:42:15.000Z',
          chain: 'EVM',
          protocol: 'Uniswap V3',
          tokenIn: {
            symbol: 'USDT',
            standard: 'ERC20',
            contractAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
            amount: '3000.00',
            unitPriceUSD: '1.00',
          },
          tokenOut: {
            symbol: 'ETH',
            standard: 'NATIVE',
            contractAddress: null,
            amount: '1.20',
            unitPriceUSD: '2500.00',
          },
          gasFee: {
            tokenSymbol: 'ETH',
            amount: '0.0045',
            unitPriceUSD: '2500.00',
          },
        },
      ];
    } else if (chain === 'SOLANA') {
      events = [
        {
          kind: 'TRANSFER',
          direction: 'IN',
          txHash: `5Sol${shortDigest}Tx1`,
          blockNumber: 295100200,
          timestamp: '2026-10-09T08:00:00.000Z',
          chain: 'SOLANA',
          counterpartyMasked: 'H8sM...9pQa',
          token: {
            symbol: 'USDC',
            standard: 'SPL',
            contractAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
            amount: '2000.00',
            unitPriceUSD: '1.00',
          },
        },
        {
          kind: 'TRANSFER',
          direction: 'IN',
          txHash: `5Sol${shortDigest}Tx2`,
          blockNumber: 295110800,
          timestamp: '2026-10-11T10:30:00.000Z',
          chain: 'SOLANA',
          counterpartyMasked: '7Ytt...4kLm',
          token: {
            symbol: 'SOL',
            standard: 'NATIVE',
            contractAddress: null,
            amount: '10.00',
            unitPriceUSD: '145.00',
          },
        },
        {
          kind: 'SWAP',
          txHash: `5Sol${shortDigest}Swap3`,
          blockNumber: 295890400,
          timestamp: '2026-10-19T16:05:00.000Z',
          chain: 'SOLANA',
          protocol: 'Jupiter V6',
          tokenIn: {
            symbol: 'USDC',
            standard: 'SPL',
            contractAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
            amount: '1500.00',
            unitPriceUSD: '1.00',
          },
          tokenOut: {
            symbol: 'SOL',
            standard: 'NATIVE',
            contractAddress: null,
            amount: '10.00',
            unitPriceUSD: '150.00',
          },
          gasFee: {
            tokenSymbol: 'SOL',
            amount: '0.00025',
            unitPriceUSD: '150.00',
          },
        },
      ];
    } else {
      events = [
        {
          kind: 'TRANSFER',
          direction: 'IN',
          txHash: `btc_${shortDigest}_utxo1`,
          blockNumber: 865200,
          timestamp: '2026-10-05T07:20:00.000Z',
          chain: 'BTC',
          counterpartyMasked: 'bc1q8c...4x9p',
          token: {
            symbol: 'BTC',
            standard: 'UTXO',
            contractAddress: null,
            amount: '0.25',
            unitPriceUSD: '66000.00',
          },
        },
        {
          kind: 'TRANSFER',
          direction: 'OUT',
          txHash: `btc_${shortDigest}_utxo2`,
          blockNumber: 866410,
          timestamp: '2026-10-20T13:10:00.000Z',
          chain: 'BTC',
          counterpartyMasked: 'bc1q9v...2m7k',
          token: {
            symbol: 'BTC',
            standard: 'UTXO',
            contractAddress: null,
            amount: '0.05',
            unitPriceUSD: '69500.00',
          },
          gasFee: {
            tokenSymbol: 'BTC',
            amount: '0.00012',
            unitPriceUSD: '69500.00',
          },
        },
      ];
    }

    if (options?.fromDate) {
      const fromIso = normalizeIsoDateOnly(options.fromDate);
      events = events.filter(
        (e) => normalizeIsoDateOnly(e.timestamp) >= fromIso
      );
    }
    if (options?.toDate) {
      const toIso = normalizeIsoDateOnly(options.toDate);
      events = events.filter((e) => normalizeIsoDateOnly(e.timestamp) <= toIso);
    }

    return events;
  }
}

export const defaultCryptoIndexer: ChainIndexerProvider =
  new MockCryptoIndexer();
