import crypto from 'crypto';
import Decimal from 'decimal.js';
import { unzipSync } from 'fflate';
import { XMLParser } from 'fast-xml-parser';
import type { MultiAssetTransaction, OptionExtension } from '../types/multiAsset';
import type {
  BloombergAssetType,
  BloombergCDMMapping,
  BloombergCorporateAction,
  BloombergCorporateActionType,
  BloombergTicker,
} from '../types/bloomberg';

/** All Bloomberg financial arithmetic in this adapter uses 40-digit Decimal.js precision. */
export const BloombergDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
const MAX_XLSX_UNCOMPRESSED_BYTES = 50 * 1024 * 1024;
const MAX_TABLE_ROWS = 50_000;
const MAX_TABLE_COLUMNS = 500;

const ASSET_TYPE_BY_SUFFIX: Record<string, BloombergAssetType> = {
  equity: 'Equity',
  corp: 'Corp',
  govt: 'Govt',
  curncy: 'Curncy',
  comdty: 'Comdty',
  index: 'Index',
  option: 'Option',
  future: 'Future',
  mortgage: 'Mortgage',
  muni: 'Muni',
  pfd: 'Pfd',
  warrant: 'Warrant',
};

const ASSET_CLASS_MAPPING: Record<BloombergAssetType, BloombergCDMMapping> = {
  Equity: { assetClass: 'EQUITY', supportedByCurrentCDM: true },
  Corp: { assetClass: 'BOND', supportedByCurrentCDM: true },
  Govt: { assetClass: 'BOND', supportedByCurrentCDM: true },
  Curncy: { assetClass: 'FOREX', supportedByCurrentCDM: true },
  Comdty: { assetClass: 'COMMODITY', supportedByCurrentCDM: true },
  Index: { assetClass: 'EQUITY', supportedByCurrentCDM: true, note: 'Imported as an equity-like security record; index valuation is not calculated by the current CDM.' },
  Option: { assetClass: 'OPTION', supportedByCurrentCDM: true },
  Future: {
    assetClass: 'OPTION',
    supportedByCurrentCDM: false,
    note: 'The protected CDM has no Futures type. The nearest derivative family is shown for identification only; Futures rows are rejected rather than stored as options.',
  },
  Mortgage: { assetClass: 'BOND', supportedByCurrentCDM: true },
  Muni: { assetClass: 'BOND', supportedByCurrentCDM: true },
  Pfd: { assetClass: 'EQUITY', supportedByCurrentCDM: true, note: 'Imported as an equity security.' },
  Warrant: { assetClass: 'OPTION', supportedByCurrentCDM: true },
};

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  parseAttributeValue: false,
  parseTagValue: false,
  trimValues: true,
});

export interface BloombergMappingOptions {
  portfolioId?: string;
  createdAt?: Date;
}

export interface BloombergTickerIdentifiers {
  isin?: string;
  cusip?: string;
  sedol?: string;
}

interface RawBloombergTrade {
  vendorTradeId: string;
  idempotencyKey: string;
  ticker: BloombergTicker;
  tradeDate: string;
  settleDate: string;
  settleDateAssumed: boolean;
  side: 'BUY' | 'SELL';
  quantity: string;
  price: string;
  grossAmount: string;
  commission: string;
  taxes: string;
  netAmount: string;
  currency: string;
  exchange: string;
  fxRateToTHB: string | null;
  accountNumber?: string;
  broker?: string;
  optionType?: OptionExtension['optionType'];
  strikePrice?: string;
  expirationDate?: string;
  underlyingAsset?: string;
  contractSize?: number;
}

/** Parse common Bloomberg yellow-key ticker formats such as `AAPL US Equity`, `US000361AQ64 Corp`, and `XAU Curncy`. */
export function parseBloombergTicker(
  rawTicker: string,
  identifiers: BloombergTickerIdentifiers = {},
): BloombergTicker {
  const fullTicker = String(rawTicker ?? '').replace(/\uFEFF/g, '').trim().replace(/\s+/g, ' ');
  const parts = fullTicker.split(' ');
  if (parts.length < 2) {
    throw new Error(`Invalid Bloomberg ticker "${rawTicker}". Expected "SYMBOL [MARKET] ASSET_TYPE".`);
  }

  const suffix = parts[parts.length - 1]!.toLowerCase();
  const assetType = ASSET_TYPE_BY_SUFFIX[suffix];
  if (!assetType) {
    throw new Error(`Unsupported Bloomberg ticker suffix "${parts[parts.length - 1]}".`);
  }

  const symbolParts = parts.slice(0, -2);
  const symbol = (symbolParts.length > 0 ? symbolParts.join(' ') : parts[0] ?? '').trim();
  const market = parts.length > 2 ? parts[parts.length - 2]!.trim() : '';
  if (!symbol) throw new Error(`Bloomberg ticker "${rawTicker}" has no security identifier.`);

  return {
    symbol,
    market,
    assetType,
    fullTicker,
    ...(cleanOptionalIdentifier(identifiers.isin) ? { isin: cleanOptionalIdentifier(identifiers.isin) } : {}),
    ...(cleanOptionalIdentifier(identifiers.cusip) ? { cusip: cleanOptionalIdentifier(identifiers.cusip) } : {}),
    ...(cleanOptionalIdentifier(identifiers.sedol) ? { sedol: cleanOptionalIdentifier(identifiers.sedol) } : {}),
  };
}

function cleanOptionalIdentifier(value: string | undefined): string | undefined {
  const cleaned = value?.trim();
  return cleaned ? cleaned : undefined;
}

export function getBloombergCDMMapping(assetType: BloombergAssetType): BloombergCDMMapping {
  return ASSET_CLASS_MAPPING[assetType];
}

/** Returns the current CDM family for each Bloomberg yellow-key suffix. Futures are identified as OPTION-like but are not safely importable. */
export function mapBloombergAssetTypeToCDM(assetType: BloombergAssetType): BloombergCDMMapping['assetClass'] {
  return ASSET_CLASS_MAPPING[assetType].assetClass;
}

function normalizeHeader(value: string): string {
  return value.replace(/^\uFEFF/, '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
}

function detectDelimiter(content: string): string {
  const candidates = [',', '\t', ';', '|'];
  let firstLine = '';
  let quoted = false;
  for (let i = 0; i < content.length; i += 1) {
    const char = content[i]!;
    if (char === '"') {
      if (quoted && content[i + 1] === '"') {
        i += 1;
      } else {
        quoted = !quoted;
      }
    } else if ((char === '\n' || char === '\r') && !quoted) {
      break;
    } else {
      firstLine += char;
    }
  }
  return candidates
    .map((delimiter) => ({ delimiter, count: firstLine.split(delimiter).length - 1 }))
    .sort((a, b) => b.count - a.count)[0]?.delimiter ?? ',';
}

function parseDelimitedRows(content: string): string[][] {
  if (Buffer.byteLength(content, 'utf8') > MAX_UPLOAD_BYTES) {
    throw new Error('Bloomberg file exceeds the 10 MB upload limit.');
  }
  const input = content.replace(/^\uFEFF/, '');
  const delimiter = detectDelimiter(input);
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index]!;
    if (char === '"') {
      if (quoted && input[index + 1] === '"') {
        field += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (char === delimiter && !quoted) {
      row.push(field);
      field = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && input[index + 1] === '\n') index += 1;
      row.push(field);
      if (row.some((cell) => cell.trim() !== '')) rows.push(row);
      row = [];
      field = '';
      if (rows.length > MAX_TABLE_ROWS + 20) throw new Error('Bloomberg file has too many rows.');
    } else {
      field += char;
    }
  }

  if (quoted) throw new Error('Bloomberg CSV contains an unterminated quoted field.');
  if (field !== '' || row.length > 0) {
    row.push(field);
    if (row.some((cell) => cell.trim() !== '')) rows.push(row);
  }
  if (!rows.length) throw new Error('Bloomberg file is empty.');
  return rows;
}

function recordsFromRows(
  rows: string[][],
  requiredHeaderGroups: string[][],
  options: { excelDates?: boolean } = {},
): Record<string, string>[] {
  const headerIndex = rows.findIndex((row) => {
    const normalized = new Set(row.map(normalizeHeader));
    return requiredHeaderGroups.every((group) => group.some((header) => normalized.has(normalizeHeader(header))));
  });
  if (headerIndex < 0) {
    throw new Error('Could not find a Bloomberg header row with the required ticker and date columns.');
  }

  const headers = rows[headerIndex]!.map((value) => normalizeHeader(value));
  if (headers.length > MAX_TABLE_COLUMNS) throw new Error('Bloomberg file has too many columns.');
  const records: Record<string, string>[] = [];

  for (const row of rows.slice(headerIndex + 1)) {
    if (records.length >= MAX_TABLE_ROWS) throw new Error('Bloomberg file has more than 50,000 data rows.');
    if (row.every((value) => value.trim() === '')) continue;
    const record: Record<string, string> = {};
    headers.forEach((header, index) => {
      if (header) record[header] = String(row[index] ?? '').trim();
    });
    if (options.excelDates) {
      for (const [key, value] of Object.entries(record)) {
        if (key.includes('date') && /^\d+(?:\.\d+)?$/.test(value)) {
          record[key] = excelSerialToISO(value);
        }
      }
    }
    records.push(record);
  }
  return records;
}

function getValue(record: Record<string, string>, aliases: readonly string[]): string | undefined {
  for (const alias of aliases) {
    const value = record[normalizeHeader(alias)];
    if (value !== undefined && value.trim() !== '') return value.trim();
  }
  return undefined;
}

function requireValue(record: Record<string, string>, aliases: readonly string[], label: string): string {
  const value = getValue(record, aliases);
  if (!value) throw new Error(`Bloomberg row is missing required field "${label}".`);
  return value;
}

function parseDecimal(raw: string, label: string, options: { allowNegative?: boolean } = {}): InstanceType<typeof BloombergDecimal> {
  const input = String(raw)
    .trim()
    .replace(/[\u00A0\s]/g, '')
    .replace(/^\((.*)\)$/, '-$1')
    .replace(/^[A-Z]{3}/i, '')
    .replace(/[A-Z]{3}$/i, '')
    .replace(/[,$€£฿¥]/g, '');
  if (!input || !/^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(input)) {
    throw new Error(`Invalid Bloomberg ${label} value "${raw}".`);
  }
  let value: InstanceType<typeof BloombergDecimal>;
  try {
    value = new BloombergDecimal(input);
  } catch {
    throw new Error(`Invalid Bloomberg ${label} value "${raw}".`);
  }
  if (!value.isFinite()) throw new Error(`Invalid Bloomberg ${label} value "${raw}".`);
  if (!options.allowNegative && value.isNegative()) {
    throw new Error(`Bloomberg ${label} cannot be negative.`);
  }
  return value;
}

function positiveDecimal(
  raw: string,
  label: string,
  options: { allowSignedInput?: boolean } = {},
): InstanceType<typeof BloombergDecimal> {
  const parsed = parseDecimal(raw, label, { allowNegative: true });
  const value = options.allowSignedInput ? parsed.abs() : parsed;
  if (!value.isPositive()) throw new Error(`Bloomberg ${label} must be greater than zero.`);
  return value;
}

function normalizeBloombergDate(rawDate: string, label: string): string {
  const value = rawDate.trim();
  let date: string | undefined;
  if (/^\d{8}$/.test(value)) {
    date = `${value.slice(0, 4)}-${value.slice(4, 6)}-${value.slice(6, 8)}`;
  } else if (/^\d{4}-\d{2}-\d{2}(?:$|[T\s])/.test(value)) {
    date = value.slice(0, 10);
  } else if (/^\d{1,2}[/-]\d{1,2}[/-]\d{4}$/.test(value)) {
    const [first, second, year] = value.split(/[/-]/).map(Number);
    const month = first! > 12 ? second! : first!;
    const day = first! > 12 ? first! : second!;
    date = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  } else {
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) date = parsed.toISOString().slice(0, 10);
  }
  if (!date) throw new Error(`Invalid Bloomberg ${label} date "${rawDate}".`);
  const parsed = new Date(`${date}T00:00:00.000Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== date) {
    throw new Error(`Invalid Bloomberg ${label} date "${rawDate}".`);
  }
  return date;
}

function formatMoney(value: InstanceType<typeof BloombergDecimal>): string {
  return value.toDecimalPlaces(2, BloombergDecimal.ROUND_HALF_UP).toFixed(2);
}

function formatPrecision(value: InstanceType<typeof BloombergDecimal>): string {
  return value.toDecimalPlaces(8, BloombergDecimal.ROUND_HALF_UP).toFixed(8);
}

function formatCurrency(raw: string, label = 'currency'): string {
  const currency = raw.trim().toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error(`Invalid Bloomberg ${label} "${raw}".`);
  return currency;
}

function normalizeSide(raw: string): 'BUY' | 'SELL' {
  const side = raw.trim().toUpperCase().replace(/[^A-Z]/g, '');
  if (['BUY', 'B', 'BOT', 'BOUGHT', 'PURCHASE'].includes(side)) return 'BUY';
  if (['SELL', 'S', 'SLD', 'SOLD', 'SALE'].includes(side)) return 'SELL';
  throw new Error(`Unsupported Bloomberg trade side "${raw}"; expected BUY or SELL.`);
}

function parseFxPair(ticker: BloombergTicker, record?: Record<string, string>): { base: string; quote: string } | null {
  const base = getValue(record ?? {}, ['Base Currency', 'From Currency'])?.toUpperCase();
  const quote = getValue(record ?? {}, ['Quote Currency', 'To Currency'])?.toUpperCase();
  if (base && quote && /^[A-Z]{3}$/.test(base) && /^[A-Z]{3}$/.test(quote) && base !== quote) {
    return { base, quote };
  }
  const compact = ticker.symbol.toUpperCase().replace(/[\/_-]/g, '');
  const match = /^([A-Z]{3})([A-Z]{3})$/.exec(compact);
  if (!match || match[1] === match[2]) return null;
  return { base: match[1]!, quote: match[2]! };
}

function parseOptionTerms(record: Record<string, string>, ticker: BloombergTicker): Pick<RawBloombergTrade,
  'optionType' | 'strikePrice' | 'expirationDate' | 'underlyingAsset' | 'contractSize'> {
  const optionTypeRaw = requireValue(record, ['Option Type', 'Call Put', 'Put Call', 'Call/Put'], 'Option Type').toUpperCase();
  const optionType = optionTypeRaw.includes('PUT') || optionTypeRaw === 'P' ? 'PUT' : optionTypeRaw.includes('CALL') || optionTypeRaw === 'C' ? 'CALL' : null;
  if (!optionType) throw new Error(`Unsupported option type "${optionTypeRaw}" for ${ticker.fullTicker}.`);
  const strikePrice = formatPrecision(positiveDecimal(requireValue(record, ['Strike Price', 'Strike'], 'Strike Price'), 'strike price'));
  const expirationDate = normalizeBloombergDate(
    requireValue(record, ['Expiration Date', 'Expiry Date', 'Maturity Date'], 'Expiration Date'),
    'expiration',
  );
  const underlyingAsset = requireValue(record, ['Underlying Asset', 'Underlying Symbol', 'Underlying'], 'Underlying Asset').trim();
  const contractSizeRaw = getValue(record, ['Contract Size', 'Multiplier']);
  const contractSize = contractSizeRaw ? positiveDecimal(contractSizeRaw, 'contract size').toNumber() : undefined;
  return { optionType, strikePrice, expirationDate, underlyingAsset, ...(contractSize ? { contractSize } : {}) };
}

function parseCouponRate(record: Record<string, string>): string {
  const raw = requireValue(record, ['Coupon Rate', 'Coupon Rate (%)', 'Coupon'], 'Coupon Rate');
  const includesPercent = raw.includes('%') || Boolean(getValue(record, ['Coupon Rate (%)']));
  let rate = parseDecimal(raw.replace(/%/g, ''), 'coupon rate');
  if (includesPercent || rate.gt(1)) rate = rate.dividedBy(100);
  if (rate.gt(1)) throw new Error('Bloomberg coupon rate must be between 0 and 100 percent.');
  return formatPrecision(rate);
}

function parsePaymentFrequency(record: Record<string, string>): 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL' {
  const raw = requireValue(record, ['Payment Frequency', 'Coupon Frequency', 'Frequency'], 'Payment Frequency')
    .trim()
    .toUpperCase()
    .replace(/[\s-]/g, '_');
  const aliases: Record<string, 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL'> = {
    MONTHLY: 'MONTHLY',
    MONTH: 'MONTHLY',
    QUARTERLY: 'QUARTERLY',
    QUARTER: 'QUARTERLY',
    SEMIANNUAL: 'SEMI_ANNUAL',
    SEMI_ANNUAL: 'SEMI_ANNUAL',
    SEMIYEARLY: 'SEMI_ANNUAL',
    SEMI_ANNUALLY: 'SEMI_ANNUAL',
    TWICEYEARLY: 'SEMI_ANNUAL',
    ANNUAL: 'ANNUAL',
    YEARLY: 'ANNUAL',
    ANNUALLY: 'ANNUAL',
  };
  const frequency = aliases[raw] ?? aliases[raw.replace(/_/g, '')];
  if (!frequency) throw new Error(`Unsupported Bloomberg bond payment frequency "${raw}".`);
  return frequency;
}

function parseWeightUnit(raw: string): 'TROY_OUNCE' | 'GRAM' | 'KILOGRAM' | 'THAI_BAHT' {
  const normalized = raw.toUpperCase().replace(/[^A-Z]/g, '');
  const units: Record<string, 'TROY_OUNCE' | 'GRAM' | 'KILOGRAM' | 'THAI_BAHT'> = {
    TROYOUNCE: 'TROY_OUNCE',
    OUNCE: 'TROY_OUNCE',
    OZ: 'TROY_OUNCE',
    GRAM: 'GRAM',
    GRAMS: 'GRAM',
    G: 'GRAM',
    KILOGRAM: 'KILOGRAM',
    KILOGRAMS: 'KILOGRAM',
    KG: 'KILOGRAM',
    THAIBAHT: 'THAI_BAHT',
    BAHT: 'THAI_BAHT',
  };
  const unit = units[normalized];
  if (!unit) throw new Error(`Unsupported Bloomberg commodity weight unit "${raw}".`);
  return unit;
}

function makeDeterministicId(vendorTradeId: string, fallback: string): string {
  const basis = vendorTradeId.trim() ? `vendor:${vendorTradeId.trim()}` : `row:${fallback}`;
  return `bbg-${crypto.createHash('sha256').update(basis, 'utf8').digest('hex').slice(0, 40)}`;
}

function parseTradeRecord(record: Record<string, string>, rowIndex: number): RawBloombergTrade {
  const tickerRaw = requireValue(record, ['Bloomberg Ticker', 'Ticker', 'Security', 'Security Ticker'], 'Ticker');
  const ticker = parseBloombergTicker(tickerRaw, {
    isin: getValue(record, ['ISIN']),
    cusip: getValue(record, ['CUSIP']),
    sedol: getValue(record, ['SEDOL']),
  });
  const tradeDate = normalizeBloombergDate(requireValue(record, ['Trade Date', 'Transaction Date', 'Date'], 'Trade Date'), 'trade');
  const settleDateRaw = getValue(record, ['Settlement Date', 'Settle Date', 'Value Date']);
  const settleDateAssumed = !settleDateRaw;
  const settleDate = settleDateRaw ? normalizeBloombergDate(settleDateRaw, 'settlement') : tradeDate;
  const side = normalizeSide(requireValue(record, ['Side', 'Buy/Sell', 'Buy Sell', 'Action'], 'Side'));
  const quantity = positiveDecimal(requireValue(record, ['Quantity', 'Qty', 'Units', 'Shares'], 'Quantity'), 'quantity', { allowSignedInput: true });
  const price = positiveDecimal(requireValue(record, ['Price', 'Trade Price', 'Execution Price'], 'Price'), 'price');
  const tickerPair = ticker.assetType === 'Curncy' ? parseFxPair(ticker, record) : null;

  const grossRaw = getValue(record, ['Gross Amount', 'Gross Value', 'Trade Value', 'Amount']);
  const grossAmount = grossRaw
    ? positiveDecimal(grossRaw, 'gross amount', { allowSignedInput: true })
    : quantity.times(price);
  const commission = getValue(record, ['Commission', 'Broker Commission', 'Fees', 'Fee'])
    ? parseDecimal(getValue(record, ['Commission', 'Broker Commission', 'Fees', 'Fee'])!, 'commission', { allowNegative: true }).abs()
    : new BloombergDecimal(0);
  const taxes = getValue(record, ['Taxes', 'Tax', 'VAT', 'Transaction Tax'])
    ? parseDecimal(getValue(record, ['Taxes', 'Tax', 'VAT', 'Transaction Tax'])!, 'taxes', { allowNegative: true }).abs()
    : new BloombergDecimal(0);
  const netRaw = getValue(record, ['Net Amount', 'Net Value', 'Net Cash']);
  const netAmount = netRaw
    ? parseDecimal(netRaw, 'net amount', { allowNegative: true }).abs()
    : side === 'BUY'
      ? grossAmount.plus(commission).plus(taxes)
      : BloombergDecimal.max(grossAmount.minus(commission).minus(taxes), 0);

  let currencyRaw = getValue(record, ['Currency', 'Settlement Currency', 'Trade Currency']);
  if (tickerPair) currencyRaw = side === 'BUY' ? tickerPair.quote : tickerPair.base;
  if (!currencyRaw) throw new Error(`Bloomberg row ${rowIndex} is missing a currency for ${ticker.fullTicker}.`);
  const currency = formatCurrency(currencyRaw);
  const fxRateRaw = getValue(record, ['FX Rate to THB', 'FX Rate To Base', 'FX Rate', 'THB FX Rate']);
  const fxRateToTHB = fxRateRaw ? formatPrecision(positiveDecimal(fxRateRaw, 'FX rate to THB')) : null;
  const tradeId = getValue(record, ['Trade ID', 'Transaction ID', 'Execution ID', 'Order ID']) ?? '';
  const fallbackId = `${tradeDate}|${ticker.fullTicker}|${side}|${quantity.toFixed(8)}|${price.toFixed(8)}|${grossAmount.toFixed(8)}|${rowIndex}`;

  const optionTerms = ticker.assetType === 'Option' || ticker.assetType === 'Warrant'
    ? parseOptionTerms(record, ticker)
    : {};

  return {
    vendorTradeId: tradeId,
    idempotencyKey: fallbackId,
    ticker,
    tradeDate,
    settleDate,
    settleDateAssumed,
    side,
    quantity: formatPrecision(quantity),
    price: formatPrecision(price),
    grossAmount: formatMoney(grossAmount),
    commission: formatMoney(commission),
    taxes: formatMoney(taxes),
    netAmount: formatMoney(netAmount),
    currency,
    exchange: getValue(record, ['Exchange', 'Market']) ?? ticker.market,
    fxRateToTHB,
    accountNumber: getValue(record, ['Account Number', 'Account ID']),
    broker: getValue(record, ['Broker', 'Counterparty']),
    ...optionTerms,
  };
}

function parseTradeRows(rows: string[][], options: BloombergMappingOptions & { excelDates?: boolean } = {}): MultiAssetTransaction[] {
  const records = recordsFromRows(rows, [
    ['Ticker', 'Bloomberg Ticker', 'Security', 'Security Ticker'],
    ['Trade Date', 'Transaction Date', 'Date'],
  ], { excelDates: options.excelDates });
  if (!records.length) throw new Error('Bloomberg trade file contains no trade rows.');
  const transactions: MultiAssetTransaction[] = [];
  const createdAt = options.createdAt ?? new Date();
  const portfolioId = options.portfolioId ?? 'bloomberg-import';

  records.forEach((record, index) => {
    const trade = parseTradeRecord(record, index + 1);
    const mapping = getBloombergCDMMapping(trade.ticker.assetType);
    if (!mapping.supportedByCurrentCDM) {
      throw new Error(`Bloomberg ${trade.ticker.assetType} "${trade.ticker.fullTicker}" cannot be represented safely by the existing Core CDM. ${mapping.note ?? ''}`.trim());
    }
    const transaction = mapBloombergTradeToCDM(trade, {
      portfolioId,
      createdAt,
      record,
    });
    transactions.push(transaction);
  });
  return transactions;
}

/** Parse a Bloomberg-exported CSV/TSV/semicolon-delimited trade file into CDM transactions. */
export function parseBloombergTrades(
  content: string,
  options: BloombergMappingOptions = {},
): MultiAssetTransaction[] {
  return parseTradeRows(parseDelimitedRows(content), options);
}

/** Parse Bloomberg CSV or .xlsx trade files. Legacy binary .xls is deliberately not accepted. */
export function parseBloombergTradesFile(
  buffer: Uint8Array,
  fileName: string,
  options: BloombergMappingOptions = {},
): MultiAssetTransaction[] {
  validateUploadBuffer(buffer);
  const extension = getFileExtension(fileName);
  if (extension === '.csv' || extension === '.tsv' || extension === '.txt') {
    const content = new TextDecoder('utf-8', { fatal: true }).decode(buffer);
    return parseBloombergTrades(content, options);
  }
  if (extension === '.xlsx') {
    return parseTradeRows(readXlsxRows(buffer), { ...options, excelDates: true });
  }
  if (extension === '.xls') {
    throw new Error('Legacy .xls workbooks are not supported. Save the Bloomberg export as .xlsx or CSV and upload again.');
  }
  throw new Error('Unsupported Bloomberg trade file. Upload CSV, TSV, or Excel .xlsx.');
}

function mapBloombergTradeToCDM(
  trade: RawBloombergTrade,
  options: BloombergMappingOptions & { record: Record<string, string> },
): MultiAssetTransaction {
  const mapping = getBloombergCDMMapping(trade.ticker.assetType);
  if (!mapping.supportedByCurrentCDM) {
    throw new Error(mapping.note ?? `Bloomberg ${trade.ticker.assetType} is not supported by the current Core CDM.`);
  }
  const assetClass = mapping.assetClass;
  const portfolioId = options.portfolioId ?? 'bloomberg-import';
  const record = options.record;
  const id = makeDeterministicId(trade.vendorTradeId, trade.idempotencyKey);
  const fxRate = trade.currency === 'THB' ? '1.00000000' : trade.fxRateToTHB;
  const rawGross = new BloombergDecimal(trade.grossAmount);
  const rawCommission = new BloombergDecimal(trade.commission);
  const rawTaxes = new BloombergDecimal(trade.taxes);
  const rawNet = new BloombergDecimal(trade.netAmount);
  const notes = [
    `Bloomberg terminal file import: ${trade.ticker.fullTicker}.`,
    trade.settleDateAssumed ? 'Settlement date was not supplied; trade date is used for the import preview.' : '',
  ].filter(Boolean).join(' ');

  const base: MultiAssetTransaction = {
    id,
    portfolioId,
    date: trade.tradeDate,
    symbol: trade.ticker.symbol,
    assetClass,
    type: trade.side,
    qty: new BloombergDecimal(trade.quantity).toNumber(),
    price: trade.price,
    gross: formatMoney(rawGross),
    comm: formatMoney(rawCommission),
    vat: formatMoney(rawTaxes),
    net: formatMoney(rawNet),
    originalCurrency: trade.currency,
    originalNet: formatMoney(rawNet),
    fxRate,
    netTHB: fxRate ? formatMoney(rawNet.times(fxRate)) : null,
    exchange: trade.exchange || undefined,
    notes,
    createdAt: options.createdAt ?? new Date(),
  };

  if (assetClass === 'FOREX') {
    const pair = parseFxPair(trade.ticker, record);
    if (!pair) throw new Error(`Bloomberg currency ticker "${trade.ticker.fullTicker}" must contain a six-letter currency pair or Base/Quote Currency columns.`);
    const pairRate = new BloombergDecimal(trade.price);
    const baseQuantity = new BloombergDecimal(trade.quantity);
    const quoteAmount = rawGross.isPositive() ? rawGross : baseQuantity.times(pairRate);
    const fromCurrency = trade.side === 'BUY' ? pair.quote : pair.base;
    const toCurrency = trade.side === 'BUY' ? pair.base : pair.quote;
    const sourceAmount = trade.side === 'BUY' ? quoteAmount : baseQuantity;
    const targetAmount = trade.side === 'BUY' ? baseQuantity : quoteAmount;
    const sourceFxRate = fromCurrency === 'THB' ? '1.00000000' : trade.fxRateToTHB;
    const commission = rawCommission;
    const taxes = rawTaxes;
    const sourceCashFlow = trade.side === 'BUY'
      ? sourceAmount.plus(commission).plus(taxes)
      : sourceAmount.minus(commission).minus(taxes);
    if (!sourceCashFlow.isPositive()) throw new Error(`Bloomberg FX ${trade.ticker.fullTicker} has a non-positive source cash flow.`);
    const fxPrice = targetAmount.dividedBy(sourceAmount);
    const fxGross = targetAmount;
    const fxNetTHB = sourceFxRate ? sourceCashFlow.times(sourceFxRate) : null;
    base.type = 'CONVERT';
    base.qty = sourceAmount.toNumber();
    base.price = formatPrecision(fxPrice);
    base.gross = formatMoney(fxGross);
    base.comm = formatMoney(commission);
    base.vat = formatMoney(taxes);
    base.net = formatMoney(sourceCashFlow);
    base.originalCurrency = fromCurrency;
    base.originalNet = formatMoney(sourceCashFlow);
    base.fxRate = sourceFxRate;
    base.netTHB = fxNetTHB ? formatMoney(fxNetTHB) : null;
    base.forexExtension = {
      fromCurrency,
      toCurrency,
      fxRateAtTransaction: formatPrecision(fxPrice),
      realizedFxGainLoss: '0.00',
    };
    base.notes = `${notes} Bloomberg pair side ${trade.side}; mapped to a CDM source-to-target currency conversion.`;
  }

  if (assetClass === 'BOND') {
    const couponRate = parseCouponRate(record);
    const paymentFrequency = parsePaymentFrequency(record);
    const maturityDate = normalizeBloombergDate(
      requireValue(record, ['Maturity Date', 'Redemption Date'], 'Maturity Date'),
      'maturity',
    );
    const faceValue = positiveDecimal(requireValue(record, ['Face Value', 'Face Value Per Unit', 'Face Value (Currency)'], 'Face Value'), 'face value');
    const accruedInterestRaw = getValue(record, ['Accrued Interest', 'Accrued Interest Amount']) ?? '0';
    const accruedInterest = parseDecimal(accruedInterestRaw, 'accrued interest').abs();
    const fx = fxRate ? new BloombergDecimal(fxRate) : null;
    const faceValueTHB = trade.currency === 'THB' ? faceValue : fx ? faceValue.times(fx) : null;
    const accruedInterestTHB = trade.currency === 'THB' ? accruedInterest : fx ? accruedInterest.times(fx) : null;
    if (!faceValueTHB || !accruedInterestTHB) {
      throw new Error(`Bloomberg bond ${trade.ticker.fullTicker} is denominated in ${trade.currency}; provide an "FX Rate to THB" value to populate its THB face value and accrued interest.`);
    }
    const ytmRaw = getValue(record, ['Yield To Maturity', 'YTM']);
    const ytm = ytmRaw ? normalizeRate(ytmRaw, 'yield to maturity') : undefined;
    base.bondExtension = {
      couponRate,
      paymentFrequency,
      maturityDate,
      faceValue: formatMoney(faceValueTHB),
      accruedInterest: formatMoney(accruedInterestTHB),
      ...(ytm ? { yieldToMaturity: ytm } : {}),
      ...(getValue(record, ['Credit Rating', 'Rating']) ? { creditRating: getValue(record, ['Credit Rating', 'Rating']) } : {}),
      ...(getValue(record, ['Issuer', 'Issuer Name']) ? { issuer: getValue(record, ['Issuer', 'Issuer Name']) } : {}),
    };
  }

  if (assetClass === 'COMMODITY') {
    const weight = positiveDecimal(requireValue(record, ['Weight Per Unit', 'Weight', 'Unit Weight'], 'Weight Per Unit'), 'commodity weight');
    const weightUnit = parseWeightUnit(requireValue(record, ['Weight Unit', 'Unit Of Measure', 'UOM'], 'Weight Unit'));
    const spotPriceRaw = getValue(record, ['Spot Price Per Unit', 'Spot Price', 'Price']);
    const spotPricePerUnit = spotPriceRaw ? positiveDecimal(spotPriceRaw, 'spot price per unit') : new BloombergDecimal(trade.price);
    const storageFee = getValue(record, ['Storage Fee THB', 'Storage Fee'])
      ? parseDecimal(getValue(record, ['Storage Fee THB', 'Storage Fee'])!, 'storage fee').abs()
      : new BloombergDecimal(0);
    const premium = getValue(record, ['Premium THB', 'Premium'])
      ? parseDecimal(getValue(record, ['Premium THB', 'Premium'])!, 'commodity premium').abs()
      : new BloombergDecimal(0);
    const purityRaw = getValue(record, ['Purity', 'Fineness']);
    const purity = purityRaw ? parseDecimal(purityRaw.replace(/%/g, ''), 'commodity purity') : null;
    base.commodityExtension = {
      weight: formatPrecision(weight),
      weightUnit,
      ...(purity ? { purity: formatPrecision(purity) } : {}),
      storageFee: formatMoney(storageFee),
      premium: formatMoney(premium),
      spotPricePerUnit: formatPrecision(spotPricePerUnit),
    };
  }

  if (assetClass === 'OPTION') {
    const optionTerms = parseOptionTerms(record, trade.ticker);
    base.optionExtension = {
      optionType: optionTerms.optionType!,
      strikePrice: optionTerms.strikePrice!,
      expirationDate: optionTerms.expirationDate!,
      underlyingAsset: optionTerms.underlyingAsset!,
      premium: getValue(record, ['Option Premium', 'Premium'])
        ? formatPrecision(positiveDecimal(getValue(record, ['Option Premium', 'Premium'])!, 'option premium'))
        : trade.price,
      ...(optionTerms.contractSize ? { contractSize: optionTerms.contractSize } : {}),
    };
  }

  return base;
}

function normalizeRate(raw: string, label: string): string {
  const containsPercent = raw.includes('%');
  let value = parseDecimal(raw.replace(/%/g, ''), label);
  if (containsPercent || value.gt(1)) value = value.dividedBy(100);
  if (value.gt(1)) throw new Error(`Bloomberg ${label} must be between 0 and 100 percent.`);
  return formatPrecision(value);
}

function validateUploadBuffer(buffer: Uint8Array): void {
  if (!buffer.length) throw new Error('Bloomberg upload file is empty.');
  if (buffer.byteLength > MAX_UPLOAD_BYTES) throw new Error('Bloomberg file exceeds the 10 MB upload limit.');
}

function getFileExtension(fileName: string): string {
  const extension = fileName.toLowerCase().match(/\.[a-z0-9]+$/)?.[0];
  return extension ?? '';
}

function toArray<T>(value: T | T[] | null | undefined): T[] {
  if (value === undefined || value === null) return [];
  return Array.isArray(value) ? value : [value];
}

function objectValue(value: unknown): Record<string, unknown> {
  return typeof value === 'object' && value !== null ? value as Record<string, unknown> : {};
}

function xmlText(value: unknown): string {
  if (typeof value === 'string' || typeof value === 'number') return String(value);
  if (Array.isArray(value)) return value.map(xmlText).join('');
  const object = objectValue(value);
  return Object.entries(object)
    .filter(([key]) => !key.startsWith('@_'))
    .map(([, child]) => xmlText(child))
    .join('');
}

function columnIndex(cellReference: string): number {
  const letters = cellReference.match(/^[A-Z]+/i)?.[0]?.toUpperCase();
  if (!letters) return -1;
  let result = 0;
  for (const letter of letters) result = result * 26 + letter.charCodeAt(0) - 64;
  return result - 1;
}

function excelSerialToISO(rawSerial: string): string {
  const serial = new BloombergDecimal(rawSerial);
  if (!serial.isFinite() || serial.isNegative() || serial.gt(2_958_465)) {
    throw new Error(`Invalid Excel date serial "${rawSerial}" in Bloomberg workbook.`);
  }
  const wholeDays = serial.floor().toNumber();
  // Excel's 1900 date system includes the fictitious 1900-02-29; modern dates use the 1899-12-30 epoch.
  const utc = new Date(Date.UTC(1899, 11, 30));
  utc.setUTCDate(utc.getUTCDate() + wholeDays);
  return utc.toISOString().slice(0, 10);
}

function verifyZipExpansionLimit(bytes: Uint8Array): void {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const minSearch = Math.max(0, bytes.byteLength - 65_557);
  let eocdOffset = -1;
  for (let offset = bytes.byteLength - 22; offset >= minSearch; offset -= 1) {
    if (view.getUint32(offset, true) === 0x06054b50) {
      eocdOffset = offset;
      break;
    }
  }
  if (eocdOffset < 0) throw new Error('Invalid .xlsx file: ZIP directory was not found.');
  const entryCount = view.getUint16(eocdOffset + 10, true);
  const directoryOffset = view.getUint32(eocdOffset + 16, true);
  if (entryCount === 0xffff || directoryOffset === 0xffffffff) {
    throw new Error('Excel ZIP64 workbooks are not supported by the Bloomberg importer.');
  }
  let totalUncompressed = 0;
  let offset = directoryOffset;
  for (let entry = 0; entry < entryCount; entry += 1) {
    if (offset + 46 > bytes.byteLength || view.getUint32(offset, true) !== 0x02014b50) {
      throw new Error('Invalid .xlsx file: malformed ZIP directory.');
    }
    const flags = view.getUint16(offset + 8, true);
    const uncompressedSize = view.getUint32(offset + 24, true);
    const fileNameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    if ((flags & 0x0001) !== 0) throw new Error('Encrypted .xlsx files are not supported.');
    if (uncompressedSize === 0xffffffff) throw new Error('Excel ZIP64 workbooks are not supported by the Bloomberg importer.');
    totalUncompressed += uncompressedSize;
    if (totalUncompressed > MAX_XLSX_UNCOMPRESSED_BYTES) {
      throw new Error('Expanded Excel workbook exceeds the 50 MB processing limit.');
    }
    offset += 46 + fileNameLength + extraLength + commentLength;
  }
}

function normalizeWorkbookPath(target: string): string {
  const cleaned = target.replace(/\\/g, '/').replace(/^\//, '');
  if (cleaned.startsWith('xl/')) return cleaned;
  return `xl/${cleaned}`;
}

function readXlsxRows(buffer: Uint8Array): string[][] {
  verifyZipExpansionLimit(buffer);
  let files: Record<string, Uint8Array>;
  try {
    files = unzipSync(buffer);
  } catch {
    throw new Error('Could not read Bloomberg Excel workbook. Ensure the file is a valid, unencrypted .xlsx export.');
  }

  const workbookBytes = files['xl/workbook.xml'];
  if (!workbookBytes) throw new Error('Invalid Bloomberg Excel workbook: xl/workbook.xml is missing.');
  const workbook = objectValue(xmlParser.parse(new TextDecoder().decode(workbookBytes))).workbook;
  const sheets = toArray(objectValue(objectValue(workbook).sheets).sheet).map(objectValue);
  if (!sheets.length) throw new Error('Bloomberg Excel workbook contains no worksheets.');
  const firstSheet = sheets[0]!;
  const relationId = String(firstSheet['@_r:id'] ?? firstSheet['@_id'] ?? '');
  let sheetPath = 'xl/worksheets/sheet1.xml';

  const relsBytes = files['xl/_rels/workbook.xml.rels'];
  if (relsBytes && relationId) {
    const rels = objectValue(xmlParser.parse(new TextDecoder().decode(relsBytes)));
    const relationships = toArray(objectValue(rels.Relationships).Relationship).map(objectValue);
    const relation = relationships.find((item) => String(item['@_Id'] ?? '') === relationId);
    const target = relation ? String(relation['@_Target'] ?? '') : '';
    if (target) sheetPath = normalizeWorkbookPath(target);
  }
  const sheetBytes = files[sheetPath];
  if (!sheetBytes) throw new Error('Could not locate the first worksheet in the Bloomberg Excel workbook.');

  const sharedStrings: string[] = [];
  const sharedBytes = files['xl/sharedStrings.xml'];
  if (sharedBytes) {
    const shared = objectValue(xmlParser.parse(new TextDecoder().decode(sharedBytes)));
    sharedStrings.push(...toArray(objectValue(shared.sst).si).map(xmlText));
  }

  const parsedSheet = objectValue(xmlParser.parse(new TextDecoder().decode(sheetBytes)));
  const sheetData = objectValue(objectValue(parsedSheet.worksheet).sheetData);
  const xmlRows = toArray(sheetData.row).map(objectValue);
  const output: string[][] = [];
  for (const xmlRow of xmlRows) {
    const cells = toArray(xmlRow.c).map(objectValue);
    const row: string[] = [];
    for (const cell of cells) {
      const reference = String(cell['@_r'] ?? '');
      const index = columnIndex(reference);
      if (index < 0 || index >= MAX_TABLE_COLUMNS) continue;
      const type = String(cell['@_t'] ?? '');
      let value = '';
      if (type === 's') {
        const sharedIndex = Number(xmlText(cell.v));
        value = Number.isInteger(sharedIndex) ? sharedStrings[sharedIndex] ?? '' : '';
      } else if (type === 'inlineStr') {
        value = xmlText(cell.is);
      } else {
        value = xmlText(cell.v);
      }
      row[index] = value;
    }
    if (row.some((cell) => String(cell ?? '').trim() !== '')) output.push(row.map((cell) => String(cell ?? '')));
    if (output.length > MAX_TABLE_ROWS + 20) throw new Error('Bloomberg Excel workbook has too many rows.');
  }
  if (!output.length) throw new Error('Bloomberg Excel workbook contains no tabular rows.');
  return output;
}

function mapCorporateActionType(raw: string): BloombergCorporateActionType {
  const normalized = raw.toLowerCase().replace(/[^a-z]/g, '');
  const actionTypes: Record<string, BloombergCorporateActionType> = {
    stocksplit: 'STOCK_SPLIT',
    forwardstocksplit: 'STOCK_SPLIT',
    reversesplit: 'REVERSE_SPLIT',
    reversestocksplit: 'REVERSE_SPLIT',
    cashdividend: 'DIVIDEND',
    dividend: 'DIVIDEND',
    spinoff: 'SPIN_OFF',
    merger: 'MERGER',
    tender: 'TENDER',
    tenderoffer: 'TENDER',
  };
  const actionType = actionTypes[normalized];
  if (!actionType) throw new Error(`Unsupported Bloomberg corporate action type "${raw}".`);
  return actionType;
}

function normalizeRatio(raw: string): string {
  const ratio = raw.trim();
  if (/^\d+(?:\.\d+)?\s*(?::|\/)\s*\d+(?:\.\d+)?$/.test(ratio)) {
    const [left, right] = ratio.split(/\s*[:/]\s*/);
    if (!new BloombergDecimal(left!).isPositive() || !new BloombergDecimal(right!).isPositive()) {
      throw new Error(`Invalid Bloomberg corporate-action ratio "${raw}".`);
    }
    return `${new BloombergDecimal(left!).toString()}:${new BloombergDecimal(right!).toString()}`;
  }
  const forMatch = /^([\d.]+)\s+for\s+([\d.]+)$/i.exec(ratio);
  if (forMatch) return normalizeRatio(`${forMatch[1]}:${forMatch[2]}`);
  const single = parseDecimal(ratio, 'corporate-action ratio');
  if (!single.isPositive()) throw new Error(`Invalid Bloomberg corporate-action ratio "${raw}".`);
  return single.toString();
}

function makeActionId(vendorId: string, fallback: string): string {
  const basis = vendorId.trim() ? `action:${vendorId.trim()}` : `row:${fallback}`;
  return `bbg-ca-${crypto.createHash('sha256').update(basis, 'utf8').digest('hex').slice(0, 36)}`;
}

function parseCorporateActionRows(rows: string[][], options: { excelDates?: boolean } = {}): BloombergCorporateAction[] {
  const records = recordsFromRows(rows, [
    ['Ticker', 'Bloomberg Ticker', 'Security', 'Security Ticker'],
    ['Effective Date', 'Ex-Date', 'Ex Date', 'Action Date'],
  ], { excelDates: options.excelDates });
  if (!records.length) throw new Error('Bloomberg corporate-action file contains no action rows.');

  return records.map((record, index) => {
    const ticker = parseBloombergTicker(requireValue(record, ['Bloomberg Ticker', 'Ticker', 'Security', 'Security Ticker'], 'Ticker'), {
      isin: getValue(record, ['ISIN']),
      cusip: getValue(record, ['CUSIP']),
      sedol: getValue(record, ['SEDOL']),
    });
    const effectiveDate = normalizeBloombergDate(requireValue(record, ['Effective Date', 'Ex-Date', 'Ex Date', 'Action Date'], 'Effective Date'), 'effective');
    const announcementDateRaw = getValue(record, ['Announcement Date', 'Announced Date', 'Record Date']);
    const announcementDate = announcementDateRaw
      ? normalizeBloombergDate(announcementDateRaw, 'announcement')
      : effectiveDate;
    const actionType = mapCorporateActionType(requireValue(record, ['Action Type', 'Corporate Action Type', 'Event Type'], 'Action Type'));
    const ratioRaw = getValue(record, ['Ratio', 'Split Ratio', 'Exchange Ratio']);
    const cashRaw = getValue(record, ['Cash Amount', 'Dividend Amount', 'Cash Consideration']);
    const cashAmount = cashRaw ? formatMoney(parseDecimal(cashRaw, 'corporate-action cash amount').abs()) : undefined;
    const cashCurrencyRaw = getValue(record, ['Currency', 'Cash Currency']);
    const description = getValue(record, ['Description', 'Action Description', 'Notes']) ?? actionType.replace(/_/g, ' ');
    const vendorId = getValue(record, ['Action ID', 'Corporate Action ID', 'Event ID']) ?? '';
    const fallback = `${effectiveDate}|${ticker.fullTicker}|${actionType}|${ratioRaw ?? ''}|${cashAmount ?? ''}|${index}`;
    return {
      actionId: makeActionId(vendorId, fallback),
      ticker,
      effectiveDate,
      announcementDate,
      actionType,
      ...(ratioRaw ? { ratio: normalizeRatio(ratioRaw) } : {}),
      ...(cashAmount ? { cashAmount } : {}),
      ...(cashCurrencyRaw ? { currency: formatCurrency(cashCurrencyRaw, 'corporate-action currency') } : {}),
      description,
    };
  });
}

/** Parse Bloomberg corporate-action CSV. Corporate actions are returned for review; they are not auto-applied to the protected CDM. */
export function parseBloombergCorporateActions(content: string): BloombergCorporateAction[] {
  return parseCorporateActionRows(parseDelimitedRows(content));
}

/** Parse Bloomberg corporate-action CSV or .xlsx. Legacy .xls is deliberately not accepted. */
export function parseBloombergCorporateActionsFile(buffer: Uint8Array, fileName: string): BloombergCorporateAction[] {
  validateUploadBuffer(buffer);
  const extension = getFileExtension(fileName);
  if (extension === '.csv' || extension === '.tsv' || extension === '.txt') {
    return parseBloombergCorporateActions(new TextDecoder('utf-8', { fatal: true }).decode(buffer));
  }
  if (extension === '.xlsx') return parseCorporateActionRows(readXlsxRows(buffer), { excelDates: true });
  if (extension === '.xls') {
    throw new Error('Legacy .xls workbooks are not supported. Save the Bloomberg export as .xlsx or CSV and upload again.');
  }
  throw new Error('Unsupported Bloomberg corporate-action file. Upload CSV, TSV, or Excel .xlsx.');
}

/** Safe FX pair parser shared by CSV parsing and user-facing ticker previews. */
export function parseBloombergFxPair(ticker: BloombergTicker): { base: string; quote: string } | null {
  return parseFxPair(ticker);
}
