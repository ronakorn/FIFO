import crypto from 'crypto';
import Decimal from 'decimal.js';
import {
  computeDividendHash,
  computeTransactionHash,
} from './ibkrFlexAdapter';
import { formatExactDecimalString, toNumber } from '../parsers/csvUtils';
import {
  defaultBotFxProvider,
  FXRateProvider as BotFXRateProvider,
} from '../services/botFxProvider';
import { Dividend, Transaction, TransactionType } from '../types';
import {
  BitkubApiOrderHistoryResponse,
  BitkubReadOnlyCredentials,
  DimeCredentials,
  DimeRawDividendItem,
  DimeRawTradeItem,
  StreamingConfirmationRow,
  StreamingCredentials,
  StreamingDividendRow,
  ThaiBrokerConnectionMode,
  ThaiBrokerId,
  ThaiBrokerParseResult,
} from '../types/thaiBrokers';

/** Institutional quantitative decimal engine: 40 significant digits, ROUND_HALF_UP. */
export const ThaiBrokerDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export const STREAMING_SET_OPEN_API_ROADMAP_TEXT =
  'รองรับการเชื่อมต่ออัตโนมัติในอนาคตเมื่อตลาดหลักทรัพย์ฯ เปิด Open API' as const;

export const THAI_BROKER_CATALOG: Record<
  ThaiBrokerId,
  {
    displayName: string;
    regulatoryBadge: string;
    defaultMode: ThaiBrokerConnectionMode;
    futureRoadmapNote: string | null;
  }
> = {
  BITKUB: {
    displayName: 'Bitkub Exchange (บิทคับ ออนไลน์)',
    regulatoryBadge:
      'สถานะใบอนุญาตและ API Scope ต้องยืนยันกับ Bitkub ในขั้นตอน Partner Onboarding',
    defaultMode: 'READ_ONLY_API',
    futureRoadmapNote: null,
  },
  DIME: {
    displayName: 'Dime! (KKP Dime — บล. เคเคพี ไดม์)',
    regulatoryBadge:
      'ตรวจสอบสถานะใบอนุญาต/ขอบเขตบริการกับ Dime! และคู่ค้าก่อนเปิดใช้งานจริง',
    defaultMode: 'OPEN_API_HYBRID',
    futureRoadmapNote:
      'รองรับทั้ง Dime! Partner Open API (OAuth 2.0 Read-Only) และ Secure Statement Automation',
  },
  STREAMING: {
    displayName: 'Settrade Streaming (ตลาดหลักทรัพย์ฯ SET)',
    regulatoryBadge:
      'รูปแบบเอกสารและสิทธิ์เข้าถึงต้องรับรองโดยบริษัทสมาชิก/Settrade ก่อนใช้งานจริง',
    defaultMode: 'SECURE_STATEMENT_AUTOMATION',
    futureRoadmapNote: STREAMING_SET_OPEN_API_ROADMAP_TEXT,
  },
};

function normalizeTimestampToIsoDate(ts: number | string): string {
  if (typeof ts === 'number' || /^\d+$/.test(String(ts).trim())) {
    const num = Number(ts);
    const ms = num < 10_000_000_000 ? num * 1000 : num;
    const d = new Date(ms);
    if (Number.isNaN(d.getTime())) {
      throw new Error(`Invalid Unix timestamp: "${ts}".`);
    }
    return d.toISOString().slice(0, 10);
  }

  const trimmed = String(ts).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) return trimmed.slice(0, 10);
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error(`Invalid date string: "${ts}".`);
  }
  return parsed.toISOString().slice(0, 10);
}

/** Bitkub epoch timestamps are normalized to the Thai tax calendar (Asia/Bangkok). */
function normalizeBitkubTimestampToThaiDate(ts: number | string): string {
  const raw = String(ts).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;

  let date: Date;
  if (typeof ts === 'number' || /^\d+$/.test(raw)) {
    const value = Number(raw);
    date = new Date(value < 10_000_000_000 ? value * 1000 : value);
  } else {
    date = new Date(raw);
  }
  if (Number.isNaN(date.getTime())) {
    throw new Error(`Invalid Bitkub trade timestamp: "${ts}".`);
  }

  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Bangkok',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);
  const part = (type: string) => parts.find((item) => item.type === type)?.value;
  const year = part('year');
  const month = part('month');
  const day = part('day');
  if (!year || !month || !day) {
    throw new Error(`Unable to normalize Bitkub timestamp: "${ts}".`);
  }
  return `${year}-${month}-${day}`;
}

function parseBitkubTradingPair(rawSym: string): { base: string; quote: string } {
  const parts = rawSym
    .trim()
    .toUpperCase()
    .split('_')
    .filter(Boolean);
  if (parts.length !== 2) {
    throw new Error(`Unsupported Bitkub trading pair format: "${rawSym}".`);
  }
  // Official symbols are BASE_QUOTE (BTC_THB); tolerate legacy THB_BTC.
  if (parts[0] === 'THB') return { base: parts[1]!, quote: 'THB' };
  return { base: parts[0]!, quote: parts[1]! };
}

export function maskCredentialIdentifier(prefix: string, raw: string): string {
  const cleaned = raw.trim();
  if (cleaned.length <= 4) return `${prefix}-****`;
  return `${prefix}-****${cleaned.slice(-4).toUpperCase()}`;
}

// ============================================================================
// 1. BitkubReadOnlyAdapter — official v3 matched-order history, read endpoints only
// ============================================================================

export class BitkubReadOnlyAdapter {
  public readonly broker: ThaiBrokerId = 'BITKUB';
  public readonly connectionMode: ThaiBrokerConnectionMode = 'READ_ONLY_API';

  /**
   * Requires an explicit READ_ONLY onboarding choice. This adapter exposes only
   * history/catalog GET calls and has no order/withdraw methods. Exchange-side
   * API permissions must be verified with Bitkub during production onboarding.
   */
  public validateCredentials(creds: BitkubReadOnlyCredentials): void {
    if (!creds.apiKey || creds.apiKey.trim().length < 6) {
      throw new Error('Bitkub Read-Only API Key must be at least 6 characters.');
    }
    if (!creds.apiSecret || creds.apiSecret.trim().length < 8) {
      throw new Error('Bitkub Read-Only API Secret must be at least 8 characters.');
    }
    if (creds.permissionsScope !== 'READ_ONLY') {
      throw new Error(
        'SECURITY_SCOPE_REJECTED: Explicit Read-Only scope selection is required. Create a Bitkub API Key with only account/transaction-history read permission; Trade and Withdraw scopes are forbidden.'
      );
    }
  }

  /** Bitkub v3 HMAC-SHA256: timestamp + method + path/query + body. */
  public signReadOnlyRequest(
    timestampMs: number,
    method: 'GET' | 'POST',
    requestPath: string,
    bodyJson: string,
    apiSecret: string
  ): string {
    return crypto
      .createHmac('sha256', apiSecret)
      .update(`${timestampMs}${method}${requestPath}${bodyJson}`, 'utf8')
      .digest('hex');
  }

  /** Deterministic, clearly-marked sandbox history payload for offline sponsor demos. */
  public buildMockBitkubOrderHistory(): BitkubApiOrderHistoryResponse {
    return {
      error: 0,
      result: [
        {
          txn_id: 'BTK-TXN-20261005-01',
          order_id: 'ORD-90011',
          hash: '0xbkhash0001',
          sym: 'BTC_THB',
          side: 'buy',
          type: 'limit',
          rate: '2250000.00',
          amount: '112500.00', // API v3 BUY amount is quote THB, not BTC quantity.
          fee: '281.25',
          credit: '0.00',
          ts: '2026-10-05T10:15:00.000Z',
        },
        {
          txn_id: 'BTK-TXN-20261014-02',
          order_id: 'ORD-90045',
          hash: '0xbkhash0002',
          sym: 'ETH_THB',
          side: 'buy',
          type: 'limit',
          rate: '88000.00',
          amount: '132000.00', // Quote amount in THB.
          fee: '330.00',
          credit: '30.00',
          ts: '2026-10-14T14:30:00.000Z',
        },
        {
          txn_id: 'BTK-TXN-20261022-03',
          order_id: 'ORD-90089',
          hash: '0xbkhash0003',
          sym: 'BTC_THB',
          side: 'sell',
          type: 'limit',
          rate: '2410000.00',
          amount: '0.02000000', // API v3 SELL amount is base-asset quantity.
          fee: '120.50',
          credit: '0.00',
          ts: '2026-10-22T09:45:00.000Z',
        },
      ],
    };
  }

  /**
   * Maps official v3 matched trades into CDM with Decimal precision 40.
   * BUY amount = quote THB; SELL amount = base quantity. API gives THB fee and
   * fee-credit fields, but no per-fill VAT split; do not fabricate one.
   */
  public parseApiResponseToCDM(
    apiResponse: BitkubApiOrderHistoryResponse,
    options: { requestSymbol?: string } = {}
  ): ThaiBrokerParseResult {
    if (apiResponse.error !== 0) {
      throw new Error(
        `Bitkub Trade History API returned error code ${apiResponse.error}.`
      );
    }

    const transactions: Transaction[] = [];
    const transactionHashes: Record<string, string> = {};
    const seenHashes = new Set<string>();

    for (const item of apiResponse.result) {
      const pair = item.sym ?? options.requestSymbol;
      if (!pair) {
        throw new Error(
          `Bitkub history row "${item.txn_id}" has no symbol; provide the requested trading pair.`
        );
      }
      const { base, quote } = parseBitkubTradingPair(pair);
      if (quote !== 'THB') {
        throw new Error(
          `Bitkub pair "${pair}" uses ${quote} as quote currency; only THB-quoted trades are enabled until a partner-approved FX mapping is configured.`
        );
      }

      const symbol = base;
      const isoDate = normalizeBitkubTimestampToThaiDate(
        item.order_closed_at ?? item.ts
      );
      const type: TransactionType =
        item.side.toUpperCase() === 'BUY' ? 'BUY' : 'SELL';
      const amountDec = new ThaiBrokerDecimal(String(item.amount)).abs();
      const priceDec = new ThaiBrokerDecimal(String(item.rate));
      const rawFeeDec = new ThaiBrokerDecimal(String(item.fee ?? '0')).abs();
      const creditDec = new ThaiBrokerDecimal(String(item.credit ?? '0')).abs();

      if (amountDec.lte(0) || priceDec.lte(0)) {
        throw new Error(
          `Invalid Bitkub trade amount or rate on txn_id "${item.txn_id}".`
        );
      }

      const qtyDec =
        type === 'BUY' ? amountDec.dividedBy(priceDec) : amountDec;
      const grossDec = type === 'BUY' ? amountDec : qtyDec.times(priceDec);
      const effectiveFeeDec = ThaiBrokerDecimal.max(
        new ThaiBrokerDecimal(0),
        rawFeeDec.minus(creditDec)
      );
      const commDec = effectiveFeeDec;
      const vatDec = new ThaiBrokerDecimal(0);
      const netDec =
        type === 'BUY'
          ? grossDec.plus(effectiveFeeDec)
          : ThaiBrokerDecimal.max(
              new ThaiBrokerDecimal(0),
              grossDec.minus(effectiveFeeDec)
            );

      const hash = computeTransactionHash({
        date: isoDate,
        symbol,
        qty: formatExactDecimalString(qtyDec),
        price: formatExactDecimalString(priceDec),
        type,
      });
      if (seenHashes.has(hash)) continue;
      seenHashes.add(hash);

      const id = `BTK-${item.txn_id}`;
      const exactNet = formatExactDecimalString(netDec);
      transactions.push({
        id,
        date: isoDate,
        symbol,
        qty: toNumber(qtyDec),
        price: toNumber(priceDec),
        gross: toNumber(grossDec),
        comm: toNumber(commDec),
        vat: toNumber(vatDec),
        net: toNumber(netDec),
        type,
        exchange: 'BITKUB',
        currency: 'THB',
        originalCurrency: 'THB',
        originalNet: exactNet,
        fxRate: '1.00',
        netTHB: exactNet,
      });
      transactionHashes[id] = hash;
    }

    return {
      broker: 'BITKUB',
      connectionMode: this.connectionMode,
      transactions,
      dividends: [],
      transactionHashes,
      dividendHashes: {},
    };
  }

  public async syncReadOnly(
    creds: BitkubReadOnlyCredentials,
    options?: {
      baseUrl?: string;
      mockResponseOverride?: BitkubApiOrderHistoryResponse;
      symbols?: string[];
    }
  ): Promise<ThaiBrokerParseResult> {
    this.validateCredentials(creds);
    if (options?.mockResponseOverride) {
      return this.parseApiResponseToCDM(options.mockResponseOverride, {
        requestSymbol: options.symbols?.[0] ?? 'BTC_THB',
      });
    }

    const configuredBaseUrl =
      options?.baseUrl ?? process.env['BITKUB_PARTNER_API_URL'];
    if (!configuredBaseUrl) {
      return this.parseApiResponseToCDM(this.buildMockBitkubOrderHistory());
    }

    const baseUrl = configuredBaseUrl.replace(/\/+$/, '');
    const apiUrl = new URL(baseUrl);
    const testLoopback =
      process.env['NODE_ENV'] === 'test' &&
      ['localhost', '127.0.0.1'].includes(apiUrl.hostname);
    if (apiUrl.protocol !== 'https:' && !testLoopback) {
      throw new Error('Bitkub partner API must use HTTPS outside local tests.');
    }

    let symbols = options?.symbols?.map((s) => s.trim().toUpperCase());
    if (!symbols?.length) {
      symbols = process.env['BITKUB_TRADE_HISTORY_SYMBOLS']
        ?.split(',')
        .map((s) => s.trim().toUpperCase())
        .filter(Boolean);
    }

    if (!symbols?.length) {
      const catalogResponse = await fetch(
        `${baseUrl}/api/v3/market/symbols`,
        { method: 'GET', headers: { Accept: 'application/json' } }
      );
      if (!catalogResponse.ok) {
        throw new Error(
          `Bitkub symbol catalog responded with HTTP ${catalogResponse.status}.`
        );
      }
      const catalog = (await catalogResponse.json()) as {
        error: number;
        result: Array<{
          symbol: string;
          quote_asset?: string;
          status?: string;
          source?: string;
        }>;
      };
      if (catalog.error !== 0 || !Array.isArray(catalog.result)) {
        throw new Error('Bitkub symbol catalog returned an invalid response.');
      }
      symbols = catalog.result
        .filter(
          (s) =>
            s.quote_asset?.toUpperCase() === 'THB' &&
            (!s.status || s.status.toLowerCase() === 'active') &&
            (!s.source || s.source.toLowerCase() === 'exchange')
        )
        .map((s) => s.symbol.toUpperCase());
    }

    const rows: NonNullable<BitkubApiOrderHistoryResponse['result']> = [];
    for (const symbol of symbols) {
      for (let page = 1; page <= 1000; page += 1) {
        const timeResponse = await fetch(`${baseUrl}/api/v3/servertime`, {
          method: 'GET',
          headers: { Accept: 'application/json' },
        });
        if (!timeResponse.ok) {
          throw new Error(
            `Bitkub server-time endpoint responded with HTTP ${timeResponse.status}.`
          );
        }
        const timestampMs = Number(await timeResponse.json());
        if (!Number.isFinite(timestampMs) || timestampMs <= 0) {
          throw new Error('Bitkub server-time endpoint returned an invalid timestamp.');
        }

        const query = new URLSearchParams({
          sym: symbol,
          p: String(page),
          lmt: '100',
          pagination_type: 'page',
        }).toString();
        const requestPath = `/api/v3/market/my-order-history?${query}`;
        const signature = this.signReadOnlyRequest(
          timestampMs,
          'GET',
          requestPath,
          '',
          creds.apiSecret
        );
        const response = await fetch(`${baseUrl}${requestPath}`, {
          method: 'GET',
          headers: {
            Accept: 'application/json',
            'X-BTK-APIKEY': creds.apiKey,
            'X-BTK-TIMESTAMP': String(timestampMs),
            'X-BTK-SIGN': signature,
          },
        });
        if (!response.ok) {
          throw new Error(
            `Bitkub Trade History API responded with HTTP ${response.status}.`
          );
        }
        const history =
          (await response.json()) as BitkubApiOrderHistoryResponse;
        if (history.error !== 0) {
          throw new Error(
            `Bitkub Trade History API returned error code ${history.error} for ${symbol}.`
          );
        }
        rows.push(...history.result.map((item) => ({ ...item, sym: item.sym ?? symbol })));

        const totalPages = Number(history.pagination?.last ?? page);
        const hasMore =
          history.pagination?.has_next === true ||
          history.pagination?.next != null ||
          page < totalPages ||
          (!history.pagination && history.result.length >= 100);
        if (!hasMore || history.result.length === 0) break;
      }
    }

    return this.parseApiResponseToCDM({ error: 0, result: rows });
  }
}

// ============================================================================
// 2. DimeOpenApiAdapter — partner Open API contract + secure statement fallback
// ============================================================================

export class DimeOpenApiAdapter {
  public readonly broker: ThaiBrokerId = 'DIME';
  public readonly connectionMode: ThaiBrokerConnectionMode = 'OPEN_API_HYBRID';

  public validateCredentials(creds: DimeCredentials): void {
    if (!creds.dimeAccountRef || creds.dimeAccountRef.trim().length < 4) {
      throw new Error('Dime! Account Reference is required.');
    }
  }

  /** Deterministic sandbox feed; production OAuth/API mapping requires partner access. */
  public buildMockDimeFeed(): {
    trades: DimeRawTradeItem[];
    dividends: DimeRawDividendItem[];
  } {
    return {
      trades: [
        {
          tradeId: 'DIME-US-8001',
          executedAt: '2026-10-08',
          symbol: 'NVDA',
          market: 'US',
          side: 'BUY',
          shares: '0.50000000',
          price: '132.40',
          commission: '0.15',
          vat: '0.01',
          currency: 'USD',
        },
        {
          tradeId: 'DIME-US-8002',
          executedAt: '2026-10-15',
          symbol: 'AAPL',
          market: 'US',
          side: 'BUY',
          shares: '1.25000000',
          price: '231.20',
          commission: '0.20',
          vat: '0.01',
          currency: 'USD',
        },
        {
          tradeId: 'DIME-TH-8003',
          executedAt: '2026-10-19',
          symbol: 'SCB',
          market: 'TH',
          side: 'BUY',
          shares: '200',
          price: '112.50',
          commission: '33.75',
          vat: '2.36',
          currency: 'THB',
        },
      ],
      dividends: [
        {
          dividendId: 'DIME-DIV-301',
          payDate: '2026-10-20',
          symbol: 'NVDA',
          shares: '0.50000000',
          divPerShare: '0.10',
          grossAmount: '0.05',
          withholdingTax: '0.01',
          currency: 'USD',
        },
      ],
    };
  }

  public async parseDimeFeedToCDM(
    feed: { trades: DimeRawTradeItem[]; dividends: DimeRawDividendItem[] },
    fxProvider: BotFXRateProvider = defaultBotFxProvider
  ): Promise<ThaiBrokerParseResult> {
    const transactions: Transaction[] = [];
    const dividends: Dividend[] = [];
    const transactionHashes: Record<string, string> = {};
    const dividendHashes: Record<string, string> = {};

    for (const row of feed.trades) {
      const date = normalizeTimestampToIsoDate(row.executedAt);
      const symbol = row.symbol.trim().toUpperCase();
      const qty = new ThaiBrokerDecimal(row.shares);
      const price = new ThaiBrokerDecimal(row.price);
      const commission = new ThaiBrokerDecimal(row.commission ?? '0');
      const vat = new ThaiBrokerDecimal(row.vat ?? '0');
      const gross = qty.times(price);
      const totalFees = commission.plus(vat);
      const net =
        row.side === 'BUY'
          ? gross.plus(totalFees)
          : ThaiBrokerDecimal.max(new ThaiBrokerDecimal(0), gross.minus(totalFees));
      const fxRate =
        row.currency === 'THB'
          ? '1.00'
          : await fxProvider.getHistoricalRate('USD', date);
      const netTHB = net.times(new ThaiBrokerDecimal(fxRate));
      const id = `DIME-${row.tradeId}`;
      const hash = computeTransactionHash({
        date,
        symbol,
        qty: formatExactDecimalString(qty),
        price: formatExactDecimalString(price),
        type: row.side,
      });

      transactions.push({
        id,
        date,
        symbol,
        qty: toNumber(qty),
        price: toNumber(price),
        gross: toNumber(gross),
        comm: toNumber(commission),
        vat: toNumber(vat),
        net: toNumber(net),
        type: row.side,
        exchange: 'DIME',
        currency: row.currency,
        originalCurrency: row.currency,
        originalNet: formatExactDecimalString(net),
        fxRate,
        netTHB: formatExactDecimalString(netTHB),
      });
      transactionHashes[id] = hash;
    }

    for (const row of feed.dividends) {
      const date = normalizeTimestampToIsoDate(row.payDate);
      const symbol = row.symbol.trim().toUpperCase();
      const qty = new ThaiBrokerDecimal(row.shares);
      const divPerShare = new ThaiBrokerDecimal(row.divPerShare);
      const gross = new ThaiBrokerDecimal(row.grossAmount);
      const wht = new ThaiBrokerDecimal(row.withholdingTax);
      const net = ThaiBrokerDecimal.max(new ThaiBrokerDecimal(0), gross.minus(wht));
      const fxRate =
        row.currency === 'THB'
          ? '1.00'
          : await fxProvider.getHistoricalRate('USD', date);
      const fx = new ThaiBrokerDecimal(fxRate);
      const id = `DIME-${row.dividendId}`;
      const hash = computeDividendHash({
        date,
        symbol,
        qty: formatExactDecimalString(qty),
        gross: formatExactDecimalString(gross),
      });

      dividends.push({
        id,
        date,
        symbol,
        qty: toNumber(qty),
        divPerShare: formatExactDecimalString(divPerShare),
        gross: formatExactDecimalString(gross),
        whtRate: gross.gt(0) ? toNumber(wht.dividedBy(gross).toDecimalPlaces(4)) : 0,
        wht: formatExactDecimalString(wht),
        net: formatExactDecimalString(net),
        originalCurrency: row.currency,
        fxRate,
        grossTHB: gross.times(fx).toFixed(2),
        whtTHB: wht.times(fx).toFixed(2),
        netTHB: net.times(fx).toFixed(2),
      });
      dividendHashes[id] = hash;
    }

    return {
      broker: 'DIME',
      connectionMode: this.connectionMode,
      transactions,
      dividends,
      transactionHashes,
      dividendHashes,
    };
  }

  public async syncReadOnly(
    creds: DimeCredentials,
    fxProvider: BotFXRateProvider = defaultBotFxProvider
  ): Promise<ThaiBrokerParseResult> {
    this.validateCredentials(creds);
    const parsed = await this.parseDimeFeedToCDM(this.buildMockDimeFeed(), fxProvider);
    return { ...parsed, connectionMode: creds.mode ?? this.connectionMode };
  }
}

// ============================================================================
// 3. StreamingPartnerModule — SET/Settrade Secure Statement Automation scaffold
// ============================================================================

export class StreamingPartnerModule {
  public readonly broker: ThaiBrokerId = 'STREAMING';
  public readonly connectionMode: ThaiBrokerConnectionMode =
    'SECURE_STATEMENT_AUTOMATION';
  public readonly futureOpenApiNotice = STREAMING_SET_OPEN_API_ROADMAP_TEXT;

  public validateCredentials(creds: StreamingCredentials): void {
    if (!creds.memberBrokerCode || creds.memberBrokerCode.trim().length < 2) {
      throw new Error('SET Member Broker code (e.g., BLS, INVX, KS) is required.');
    }
    if (!creds.accountRef || creds.accountRef.trim().length < 4) {
      throw new Error('Streaming Equity Account Reference is required.');
    }
    if (!creds.statementSyncToken || creds.statementSyncToken.trim().length < 4) {
      throw new Error('Secure Statement Automation token is required.');
    }
  }

  /** Deterministic demo statement rows; an approved statement parser can replace this provider. */
  public buildMockStreamingStatement(): {
    confirmations: StreamingConfirmationRow[];
    dividends: StreamingDividendRow[];
  } {
    return {
      confirmations: [
        {
          confirmNo: 'SET-20261007-101',
          tradeDate: '2026-10-07',
          symbol: 'ADVANC',
          side: 'BUY',
          volume: '500',
          priceTHB: '278.00',
          commissionRate: '0.00157',
        },
        {
          confirmNo: 'SET-20261012-102',
          tradeDate: '2026-10-12',
          symbol: 'PTT',
          side: 'BUY',
          volume: '2000',
          priceTHB: '34.25',
          commissionRate: '0.00157',
        },
        {
          confirmNo: 'SET-20261021-103',
          tradeDate: '2026-10-21',
          symbol: 'ADVANC',
          side: 'SELL',
          volume: '200',
          priceTHB: '291.00',
          commissionRate: '0.00157',
        },
      ],
      dividends: [
        {
          refNo: 'TSD-EDIV-2026-991',
          payDate: '2026-10-18',
          symbol: 'ADVANC',
          shares: '500',
          dpsTHB: '4.87',
          whtRate: '0.10',
        },
      ],
    };
  }

  public parseStatementToCDM(statement: {
    confirmations: StreamingConfirmationRow[];
    dividends: StreamingDividendRow[];
  }): ThaiBrokerParseResult {
    const transactions: Transaction[] = [];
    const dividends: Dividend[] = [];
    const transactionHashes: Record<string, string> = {};
    const dividendHashes: Record<string, string> = {};
    const vatRate = new ThaiBrokerDecimal('0.07');

    for (const row of statement.confirmations) {
      const date = normalizeTimestampToIsoDate(row.tradeDate);
      const symbol = row.symbol.trim().toUpperCase();
      const qty = new ThaiBrokerDecimal(row.volume);
      const price = new ThaiBrokerDecimal(row.priceTHB);
      const commissionRate = new ThaiBrokerDecimal(row.commissionRate ?? '0.00157');
      const gross = qty.times(price);
      const commission = gross.times(commissionRate).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
      const vat = commission.times(vatRate).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
      const fees = commission.plus(vat);
      const net =
        row.side === 'BUY'
          ? gross.plus(fees)
          : ThaiBrokerDecimal.max(new ThaiBrokerDecimal(0), gross.minus(fees));
      const id = `STRM-${row.confirmNo}`;
      const hash = computeTransactionHash({
        date,
        symbol,
        qty: formatExactDecimalString(qty),
        price: formatExactDecimalString(price),
        type: row.side,
      });

      transactions.push({
        id,
        date,
        symbol,
        qty: toNumber(qty),
        price: toNumber(price),
        gross: toNumber(gross),
        comm: toNumber(commission),
        vat: toNumber(vat),
        net: toNumber(net),
        type: row.side,
        exchange: 'STREAMING',
        currency: 'THB',
        originalCurrency: 'THB',
        originalNet: formatExactDecimalString(net),
        fxRate: '1.00',
        netTHB: formatExactDecimalString(net),
      });
      transactionHashes[id] = hash;
    }

    for (const row of statement.dividends) {
      const date = normalizeTimestampToIsoDate(row.payDate);
      const symbol = row.symbol.trim().toUpperCase();
      const qty = new ThaiBrokerDecimal(row.shares);
      const dps = new ThaiBrokerDecimal(row.dpsTHB);
      const whtRate = new ThaiBrokerDecimal(row.whtRate ?? '0.10');
      const gross = qty.times(dps);
      const wht = gross.times(whtRate).toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
      const net = gross.minus(wht);
      const id = `STRM-${row.refNo}`;
      const hash = computeDividendHash({
        date,
        symbol,
        qty: formatExactDecimalString(qty),
        gross: formatExactDecimalString(gross),
      });
      const grossStr = gross.toFixed(2);
      const whtStr = wht.toFixed(2);
      const netStr = net.toFixed(2);

      dividends.push({
        id,
        date,
        symbol,
        qty: toNumber(qty),
        divPerShare: formatExactDecimalString(dps),
        gross: grossStr,
        whtRate: toNumber(whtRate),
        wht: whtStr,
        net: netStr,
        originalCurrency: 'THB',
        fxRate: '1.00',
        grossTHB: grossStr,
        whtTHB: whtStr,
        netTHB: netStr,
      });
      dividendHashes[id] = hash;
    }

    return {
      broker: 'STREAMING',
      connectionMode: this.connectionMode,
      transactions,
      dividends,
      transactionHashes,
      dividendHashes,
    };
  }

  public async syncReadOnly(
    creds: StreamingCredentials
  ): Promise<ThaiBrokerParseResult> {
    this.validateCredentials(creds);
    return this.parseStatementToCDM(this.buildMockStreamingStatement());
  }
}

export const defaultBitkubAdapter = new BitkubReadOnlyAdapter();
export const defaultDimeAdapter = new DimeOpenApiAdapter();
export const defaultStreamingModule = new StreamingPartnerModule();
