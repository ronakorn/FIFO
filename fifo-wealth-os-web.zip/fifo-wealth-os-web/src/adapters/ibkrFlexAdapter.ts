import crypto from 'crypto';
import Decimal from 'decimal.js';
import { XMLParser } from 'fast-xml-parser';
import { formatExactDecimalString, toNumber } from '../parsers/csvUtils';
import {
  defaultBotFxProvider,
  FXRateProvider as BotFXRateProvider,
} from '../services/botFxProvider';
import { Transaction, TransactionType } from '../types';
import { IBKRFlexParseResult, IBKRParsedDividend } from '../types/sync';
import { CorporateAction, CorporateActionType } from '../types/wave1';

/**
 * Institutional Quantitative & Financial Data Mapping Decimal Engine (precision: 40)
 */
export const FlexDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

// Strict Rule: parseAttributeValue: false & parseTagValue: false keep all XML numbers as exact strings!
const flexXmlParser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '',
  parseAttributeValue: false,
  parseTagValue: false,
  trimValues: true,
});

function toArray<T>(val: T | T[] | undefined | null): T[] {
  if (val === undefined || val === null) return [];
  return Array.isArray(val) ? val : [val];
}

function cleanNumericStr(raw: unknown, fallback = '0'): string {
  const s = String(raw ?? '')
    .replace(/,/g, '')
    .trim();
  return s === '' ? fallback : s;
}

/**
 * Normalizes IBKR Flex dates (`YYYYMMDD`, `YYYYMMDD;HHMMSS`, or `YYYY-MM-DD`) to `YYYY-MM-DD`.
 */
export function normalizeIBKRFlexDate(rawDate: string): string {
  const cleaned = String(rawDate).trim().split(';')[0]?.trim() ?? '';
  if (/^\d{8}$/.test(cleaned)) {
    return `${cleaned.slice(0, 4)}-${cleaned.slice(4, 6)}-${cleaned.slice(6, 8)}`;
  }
  if (/^\d{4}-\d{2}-\d{2}/.test(cleaned)) {
    return cleaned.slice(0, 10);
  }
  const parsed = new Date(cleaned);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error(`Invalid IBKR Flex date: "${rawDate}".`);
  }
  return parsed.toISOString().slice(0, 10);
}

/**
 * Computes a deterministic SHA-256 Idempotency Hash from `date + symbol + qty + price + type`
 * using canonical 8-decimal `Decimal.js` formatting so repeated syncs never duplicate trades.
 */
export function computeTransactionHash(input: {
  date: string;
  symbol: string;
  qty: Decimal.Value;
  price: Decimal.Value;
  type: string;
}): string {
  const canonicalDate = normalizeIBKRFlexDate(input.date);
  const canonicalSymbol = input.symbol.trim().toUpperCase();
  const canonicalQty = new FlexDecimal(String(input.qty)).abs().toFixed(8);
  const canonicalPrice = new FlexDecimal(String(input.price)).abs().toFixed(8);
  const canonicalType = input.type.trim().toUpperCase();

  const payload = `${canonicalDate}|${canonicalSymbol}|${canonicalQty}|${canonicalPrice}|${canonicalType}`;
  return crypto.createHash('sha256').update(payload, 'utf8').digest('hex');
}

/**
 * Computes a deterministic SHA-256 Idempotency Hash for IBKR Cash Dividends (`payDate + symbol + gross`).
 * Note: Uses `payDate + symbol + gross` (with optional `qty` fallback compatibility) so identical
 * payouts appearing in both `<Dividends>` and `<CashTransactions>` deduplicate cleanly.
 */
export function computeDividendHash(input: {
  date: string;
  symbol: string;
  qty?: Decimal.Value;
  gross: Decimal.Value;
}): string {
  const canonicalDate = normalizeIBKRFlexDate(input.date);
  const canonicalSymbol = input.symbol.trim().toUpperCase();
  const canonicalGross = new FlexDecimal(String(input.gross)).abs().toFixed(8);

  const payload = `DIV|${canonicalDate}|${canonicalSymbol}|${canonicalGross}`;
  return crypto.createHash('sha256').update(payload, 'utf8').digest('hex');
}

/**
 * Computes a deterministic SHA-256 Idempotency Hash for IBKR Corporate Actions
 * (`effectiveDate + symbol + type + ratio`).
 */
export function computeCorporateActionHash(input: {
  effectiveDate: string;
  symbol: string;
  type: CorporateActionType;
  ratio: Decimal.Value;
}): string {
  const canonicalDate = normalizeIBKRFlexDate(input.effectiveDate);
  const canonicalSymbol = input.symbol.trim().toUpperCase();
  const canonicalRatio = new FlexDecimal(String(input.ratio)).abs().toFixed(8);

  const payload = `CA|${canonicalDate}|${canonicalSymbol}|${input.type}|${canonicalRatio}`;
  return crypto.createHash('sha256').update(payload, 'utf8').digest('hex');
}

/**
 * Generates realistic Mock IBKR Flex Web Service v3 XML response for Read-Only simulation.
 * Security Rule: Never embeds or logs the Flex token inside returned data.
 */
export function buildMockIBKRFlexStatementXml(
  queryId: string,
  fromDate: string,
  toDate: string
): string {
  const safeFrom = normalizeIBKRFlexDate(fromDate).replace(/-/g, '');
  const safeTo = normalizeIBKRFlexDate(toDate).replace(/-/g, '');

  return `<?xml version="1.0" encoding="UTF-8"?>
<FlexQueryResponse queryName="WealthOS_ReadOnly_${queryId}" type="AF">
  <FlexStatements count="1">
    <FlexStatement accountId="U9988776" fromDate="${safeFrom}" toDate="${safeTo}" period="Last30CalendarDays" whenGenerated="20261026;090000">
      <Trades>
        <Trade tradeID="IBFLEX-9001" symbol="MSFT" currency="USD" tradeDate="20261012" buySell="BUY" quantity="12.0000" tradePrice="415.50" ibCommission="-1.25" netCash="-4987.25" />
        <Trade tradeID="IBFLEX-9002" symbol="MSFT" currency="USD" tradeDate="20261019" buySell="SELL" quantity="-4.0000" tradePrice="438.00" ibCommission="-1.00" netCash="1751.00" />
        <Trade tradeID="IBFLEX-9003" symbol="GOOGL" currency="USD" tradeDate="20261021" buySell="BUY" quantity="20.0000" tradePrice="172.25" ibCommission="-1.50" netCash="-3446.50" />
      </Trades>
      <CashTransactions>
        <CashTransaction transactionID="IBDIV-5001" type="Dividends" symbol="MSFT" currency="USD" exDate="20261001" payDate="20261015" dateTime="20261015" quantity="12.0000" divPerShare="0.75" amount="9.00" withholdingTax="-1.35" description="MSFT(US5949181045) CASH DIVIDEND USD 0.75 PER SHARE" />
      </CashTransactions>
      <CorporateActions>
        <CorporateAction actionID="IBCA-7001" symbol="GOOGL" type="Stock Split" ratio="2" effectiveDate="20261023" reportDate="20261023" description="GOOGL(US02079K3059) SPLIT 2 FOR 1 (Alphabet Inc. Class A)" />
      </CorporateActions>
    </FlexStatement>
  </FlexStatements>
</FlexQueryResponse>`;
}

interface RawFlexTradeNode {
  tradeID?: string;
  transactionID?: string;
  symbol?: string;
  currency?: string;
  tradeDate?: string;
  dateTime?: string;
  buySell?: string;
  quantity?: string;
  tradePrice?: string;
  ibCommission?: string;
  netCash?: string;
}

interface RawFlexDividendOrCashNode {
  actionID?: string;
  transactionID?: string;
  type?: string;
  symbol?: string;
  currency?: string;
  exDate?: string;
  payDate?: string;
  date?: string;
  dateTime?: string;
  reportDate?: string;
  quantity?: string;
  grossRate?: string;
  divPerShare?: string;
  grossAmount?: string;
  amount?: string;
  withholdingTax?: string;
  tax?: string;
  netAmount?: string;
  description?: string;
}

interface RawFlexCorporateActionNode {
  actionID?: string;
  transactionID?: string;
  symbol?: string;
  type?: string;
  actionType?: string;
  ratio?: string;
  splitRatio?: string;
  effectiveDate?: string;
  reportDate?: string;
  dateTime?: string;
  date?: string;
  announcementDate?: string;
  description?: string;
  actionDescription?: string;
}

function extractFlexStatements(xmlData: string): Record<string, unknown>[] {
  if (!xmlData || !xmlData.trim()) {
    throw new Error('IBKR Flex XML response is empty.');
  }

  const parsed = flexXmlParser.parse(xmlData) as Record<string, unknown>;
  const root = parsed['FlexQueryResponse'] as
    | Record<string, unknown>
    | undefined;

  if (root) {
    const flexStatementsWrapper = root['FlexStatements'] as
      | Record<string, unknown>
      | undefined;
    return toArray(
      flexStatementsWrapper?.['FlexStatement'] as
        | Record<string, unknown>
        | Record<string, unknown>[]
        | undefined
    );
  }

  // Also support standalone <FlexStatement> snippets for granular XML unit tests
  if (parsed['FlexStatement']) {
    return toArray(
      parsed['FlexStatement'] as
        | Record<string, unknown>
        | Record<string, unknown>[]
    );
  }

  throw new Error(
    'Invalid IBKR Flex XML: missing <FlexQueryResponse> or <FlexStatement> root node.'
  );
}

/**
 * Internal synchronous extractor for IBKR Dividends from `<Dividends>`,
 * `<ChangeInDividendAccruals>`, and `<CashTransactions type="Dividends">`
 * (with automatic pairing of sibling `type="Withholding Tax"` entries).
 */
function extractRawIBKRDividendsSync(xmlData: string): IBKRParsedDividend[] {
  const statements = extractFlexStatements(xmlData);
  const results: IBKRParsedDividend[] = [];
  const seenHashes = new Set<string>();
  let divSeq = 0;

  for (const stmt of statements) {
    const candidateNodes: RawFlexDividendOrCashNode[] = [];

    // 1. Explicit <Dividends><Dividend ... /></Dividends>
    const divContainer = stmt['Dividends'] as
      | Record<string, unknown>
      | undefined;
    const explicitDivs = toArray(
      divContainer?.['Dividend'] as
        | RawFlexDividendOrCashNode
        | RawFlexDividendOrCashNode[]
        | undefined
    );
    candidateNodes.push(...explicitDivs);

    // 2. <ChangeInDividendAccruals><ChangeInDividendAccrual ... /></ChangeInDividendAccruals>
    const accrualContainer = stmt['ChangeInDividendAccruals'] as
      | Record<string, unknown>
      | undefined;
    const accrualDivs = toArray(
      accrualContainer?.['ChangeInDividendAccrual'] as
        | RawFlexDividendOrCashNode
        | RawFlexDividendOrCashNode[]
        | undefined
    );
    candidateNodes.push(...accrualDivs);

    // 3. <CashTransactions><CashTransaction type="Dividends" ... /></CashTransactions>
    const cashContainer = stmt['CashTransactions'] as
      | Record<string, unknown>
      | undefined;
    const rawCashItems = toArray(
      cashContainer?.['CashTransaction'] as
        | RawFlexDividendOrCashNode
        | RawFlexDividendOrCashNode[]
        | undefined
    );

    // Collect sibling Withholding Tax rows keyed by SYMBOL|PAYDATE|CURRENCY
    const whtByKey = new Map<string, InstanceType<typeof FlexDecimal>>();
    for (const cashItem of rawCashItems) {
      const cashType = String(cashItem.type ?? '').trim().toLowerCase();
      if (cashType.includes('withholding tax') || cashType === 'whtax') {
        const sym = String(cashItem.symbol ?? '').trim().toUpperCase();
        const cur = String(cashItem.currency ?? 'USD').trim().toUpperCase();
        const rawDt = String(
          cashItem.payDate ??
            cashItem.dateTime ??
            cashItem.reportDate ??
            cashItem.date ??
            ''
        ).trim();
        if (!sym || !rawDt) continue;
        const payIso = normalizeIBKRFlexDate(rawDt);
        const taxAmt = new FlexDecimal(
          cleanNumericStr(cashItem.amount ?? cashItem.withholdingTax ?? cashItem.tax)
        ).abs();
        const key = `${sym}|${payIso}|${cur}`;
        whtByKey.set(
          key,
          (whtByKey.get(key) ?? new FlexDecimal(0)).plus(taxAmt)
        );
      }
    }

    for (const cashItem of rawCashItems) {
      const cashType = String(cashItem.type ?? '').trim().toLowerCase();
      if (!cashType.includes('dividend')) continue;
      candidateNodes.push(cashItem);
    }

    for (const node of candidateNodes) {
      const symbol = String(node.symbol ?? '').trim().toUpperCase();
      const currency = String(node.currency ?? 'USD').trim().toUpperCase();
      const rawPayDate = String(
        node.payDate ?? node.date ?? node.dateTime ?? node.reportDate ?? ''
      ).trim();
      if (!symbol || !rawPayDate) continue;

      const payDate = normalizeIBKRFlexDate(rawPayDate);
      const rawExDate = String(node.exDate ?? '').trim();
      const exDate = rawExDate ? normalizeIBKRFlexDate(rawExDate) : payDate;

      const grossDec = new FlexDecimal(
        cleanNumericStr(node.grossAmount ?? node.amount)
      ).abs();
      if (grossDec.lte(0)) continue;

      const inlineWhtStr = cleanNumericStr(node.withholdingTax ?? node.tax, '');
      const siblingKey = `${symbol}|${payDate}|${currency}`;
      const whtDec =
        inlineWhtStr !== ''
          ? new FlexDecimal(inlineWhtStr).abs()
          : (whtByKey.get(siblingKey) ?? new FlexDecimal(0));

      const netDec =
        node.netAmount !== undefined && String(node.netAmount).trim() !== ''
          ? new FlexDecimal(cleanNumericStr(node.netAmount)).abs()
          : FlexDecimal.max(new FlexDecimal(0), grossDec.minus(whtDec));

      const rawQtyDec = new FlexDecimal(cleanNumericStr(node.quantity, '0')).abs();
      const rawRateDec = new FlexDecimal(
        cleanNumericStr(node.divPerShare ?? node.grossRate, '0')
      ).abs();

      const qtyDec = rawQtyDec.gt(0)
        ? rawQtyDec
        : rawRateDec.gt(0)
          ? grossDec.dividedBy(rawRateDec)
          : new FlexDecimal(1);

      const divPerShareDec = rawRateDec.gt(0)
        ? rawRateDec
        : grossDec.dividedBy(qtyDec);

      const whtRateNum = grossDec.gt(0)
        ? toNumber(whtDec.dividedBy(grossDec).toDecimalPlaces(6))
        : 0;

      const hash = computeDividendHash({
        date: payDate,
        symbol,
        qty: formatExactDecimalString(qtyDec),
        gross: formatExactDecimalString(grossDec),
      });

      if (seenHashes.has(hash)) {
        continue;
      }
      seenHashes.add(hash);

      divSeq += 1;
      const rawId = node.transactionID ?? node.actionID;
      const divId = rawId
        ? `IBKR-DIV-${String(rawId).trim()}`
        : `IBKR-DIV-${divSeq}`;

      const grossStr = formatExactDecimalString(grossDec);
      const whtStr = formatExactDecimalString(whtDec);
      const netStr = formatExactDecimalString(netDec);

      results.push({
        id: divId,
        date: payDate,
        exDate,
        payDate,
        symbol,
        qty: toNumber(qtyDec),
        divPerShare: formatExactDecimalString(divPerShareDec),
        gross: grossStr,
        grossAmount: grossStr,
        whtRate: whtRateNum,
        wht: whtStr,
        withholdingTax: whtStr,
        net: netStr,
        currency,
        originalCurrency: currency,
        fxRate: null,
        grossTHB: null,
        whtTHB: null,
        netTHB: null,
        idempotencyHash: hash,
      });
    }
  }

  return results;
}

/**
 * Step 1A: Parses `<Dividends>` and `<CashTransactions type="Dividends">` from IBKR Flex XML,
 * maps to Canonical `Dividend` (`IBKRParsedDividend` with `symbol`, `exDate`, `payDate`,
 * `grossAmount`, `withholdingTax`, `currency`), and converts to THB using `botFxProvider`
 * on the exact `payDate` with `Decimal.js (precision: 40)`.
 */
export async function parseIBKRDividends(
  xmlData: string,
  fxProvider: BotFXRateProvider = defaultBotFxProvider
): Promise<IBKRParsedDividend[]> {
  const rawDividends = extractRawIBKRDividendsSync(xmlData);
  const enriched: IBKRParsedDividend[] = [];

  for (const div of rawDividends) {
    const rateStr = await fxProvider.getHistoricalRate(
      div.currency,
      div.payDate
    );
    const fxDec = new FlexDecimal(cleanNumericStr(rateStr));
    if (!fxDec.isFinite() || fxDec.lte(0)) {
      throw new Error(
        `Invalid BOT FX rate "${rateStr}" for ${div.currency} on payDate ${div.payDate}.`
      );
    }

    const grossDec = new FlexDecimal(div.grossAmount);
    const whtDec = new FlexDecimal(div.withholdingTax);
    const netDec = new FlexDecimal(div.net);

    const grossTHB = grossDec.times(fxDec).toFixed(2);
    const whtTHB = whtDec.times(fxDec).toFixed(2);
    const netTHB = netDec.times(fxDec).toFixed(2);

    enriched.push({
      ...div,
      fxRate: rateStr,
      grossTHB,
      whtTHB,
      netTHB,
    });
  }

  return enriched;
}

function parseSplitRatioAndType(
  rawTypeAttr: string,
  rawRatioAttr: string,
  rawDesc: string
): { type: CorporateActionType; ratioDec: InstanceType<typeof FlexDecimal> } | null {
  const typeLower = rawTypeAttr.toLowerCase();
  const descLower = rawDesc.toLowerCase();

  const isExplicitReverse =
    typeLower === 'rs' ||
    typeLower.includes('reverse') ||
    descLower.includes('reverse split') ||
    descLower.includes('reverse stock split');

  const isExplicitForward =
    typeLower === 'fs' ||
    (typeLower.includes('split') && !isExplicitReverse) ||
    (descLower.includes('split') && !isExplicitReverse);

  if (!isExplicitForward && !isExplicitReverse) {
    return null;
  }

  // Case 1: Ratio attribute in "X:Y" or "X/Y" or "X FOR Y" notation
  const ratioPairMatch = rawRatioAttr.match(
    /^(\d+(?:\.\d+)?)\s*(?::|\/|for)\s*(\d+(?:\.\d+)?)$/i
  );
  if (ratioPairMatch?.[1] && ratioPairMatch[2]) {
    const num = new FlexDecimal(ratioPairMatch[1]);
    const den = new FlexDecimal(ratioPairMatch[2]);
    if (num.lte(0) || den.lte(0)) return null;

    if (num.lt(den) || isExplicitReverse) {
      const revDivisor = den.gt(num) ? den.dividedBy(num) : num.dividedBy(den);
      return { type: 'REVERSE_SPLIT', ratioDec: revDivisor };
    }
    return { type: 'STOCK_SPLIT', ratioDec: num.dividedBy(den) };
  }

  // Case 2: Plain numeric ratio attribute (e.g. "4", "10", "0.1")
  if (rawRatioAttr !== '') {
    const numeric = new FlexDecimal(cleanNumericStr(rawRatioAttr));
    if (numeric.lte(0)) return null;
    if (isExplicitReverse) {
      const normalizedDivisor = numeric.lt(1)
        ? new FlexDecimal(1).dividedBy(numeric)
        : numeric;
      return { type: 'REVERSE_SPLIT', ratioDec: normalizedDivisor };
    }
    if (numeric.lt(1)) {
      return {
        type: 'REVERSE_SPLIT',
        ratioDec: new FlexDecimal(1).dividedBy(numeric),
      };
    }
    return { type: 'STOCK_SPLIT', ratioDec: numeric };
  }

  // Case 3: Parse IBKR Flex description "SPLIT 10 FOR 1" or "SPLIT 1 FOR 10" or "4:1"
  const descMatch = rawDesc.match(
    /split\s+(\d+(?:\.\d+)?)\s*(?:for|:|\/|-for-)\s*(\d+(?:\.\d+)?)/i
  );
  if (descMatch?.[1] && descMatch[2]) {
    const num = new FlexDecimal(descMatch[1]);
    const den = new FlexDecimal(descMatch[2]);
    if (num.lte(0) || den.lte(0)) return null;
    if (num.lt(den) || isExplicitReverse) {
      const revDivisor = den.gt(num) ? den.dividedBy(num) : num.dividedBy(den);
      return { type: 'REVERSE_SPLIT', ratioDec: revDivisor };
    }
    return { type: 'STOCK_SPLIT', ratioDec: num.dividedBy(den) };
  }

  return null;
}

/**
 * Step 1B: Parses `<CorporateActions>` from IBKR Flex Query XML,
 * detects `'Stock Split'` (`STOCK_SPLIT`) and `'Reverse Split'` (`REVERSE_SPLIT`),
 * and maps to canonical `CorporateAction` objects (`symbol`, `ratio`, `effectiveDate`)
 * with deterministic SHA-256 idempotency.
 */
export function parseIBKRCorporateActions(xmlData: string): CorporateAction[] {
  const statements = extractFlexStatements(xmlData);
  const actions: CorporateAction[] = [];
  const seenHashes = new Set<string>();
  let caSeq = 0;

  for (const stmt of statements) {
    const caContainer = stmt['CorporateActions'] as
      | Record<string, unknown>
      | undefined;
    const rawNodes = toArray(
      caContainer?.['CorporateAction'] as
        | RawFlexCorporateActionNode
        | RawFlexCorporateActionNode[]
        | undefined
    );

    for (const rawNode of rawNodes) {
      const symbol = String(rawNode.symbol ?? '').trim().toUpperCase();
      const rawDate = String(
        rawNode.effectiveDate ??
          rawNode.reportDate ??
          rawNode.dateTime ??
          rawNode.date ??
          ''
      ).trim();
      if (!symbol || !rawDate) continue;

      const effectiveDate = normalizeIBKRFlexDate(rawDate);
      const rawTypeAttr = String(
        rawNode.type ?? rawNode.actionType ?? ''
      ).trim();
      const rawRatioAttr = String(
        rawNode.ratio ?? rawNode.splitRatio ?? ''
      ).trim();
      const rawDesc = String(
        rawNode.description ?? rawNode.actionDescription ?? ''
      ).trim();

      const parsedSplit = parseSplitRatioAndType(
        rawTypeAttr,
        rawRatioAttr,
        rawDesc
      );
      if (!parsedSplit) continue;

      const { type, ratioDec } = parsedSplit;
      if (ratioDec.eq(1)) continue;

      const hash = computeCorporateActionHash({
        effectiveDate,
        symbol,
        type,
        ratio: ratioDec,
      });

      if (seenHashes.has(hash)) {
        continue;
      }
      seenHashes.add(hash);

      caSeq += 1;
      const rawActionId = rawNode.actionID ?? rawNode.transactionID;
      const id = rawActionId
        ? `IBKR-CA-${String(rawActionId).trim()}`
        : `IBKR-CA-${symbol}-${effectiveDate}-${caSeq}`;

      const ratioNum = toNumber(ratioDec.toDecimalPlaces(8));
      const adjustmentFactor =
        type === 'STOCK_SPLIT'
          ? new FlexDecimal(1).dividedBy(ratioDec).toFixed(6)
          : ratioDec.toFixed(6);

      const ratioLabel =
        type === 'STOCK_SPLIT' ? `${ratioNum}:1` : `1:${ratioNum}`;
      const defaultTitle =
        type === 'STOCK_SPLIT'
          ? `${symbol} — ${ratioLabel} Forward Stock Split (IBKR Flex)`
          : `${symbol} — ${ratioLabel} Reverse Stock Split (IBKR Flex)`;

      const announcementDate = rawNode.announcementDate
        ? normalizeIBKRFlexDate(String(rawNode.announcementDate))
        : undefined;

      actions.push({
        id,
        symbol,
        type,
        ratio: ratioNum,
        effectiveDate,
        announcementDate,
        adjustmentFactor,
        description: rawDesc || defaultTitle,
        title: defaultTitle,
        applied: false,
        source: 'IBKR_FLEX',
        idempotencyHash: hash,
      });
    }
  }

  return actions;
}

/**
 * Parses an IBKR Flex Query XML document into FIFO Wealth OS Canonical Data Model
 * (`Transaction[]`, `IBKRParsedDividend[]`, and `CorporateAction[]`) + Idempotency Hashes.
 */
export function parseIBKRFlexXml(xmlContent: string): IBKRFlexParseResult {
  const statements = extractFlexStatements(xmlContent);

  const transactions: Transaction[] = [];
  const transactionHashes: Record<string, string> = {};

  let txSeq = 0;

  for (const stmt of statements) {
    const tradesContainer = stmt['Trades'] as
      | Record<string, unknown>
      | undefined;
    const rawTrades = toArray(
      tradesContainer?.['Trade'] as
        | RawFlexTradeNode
        | RawFlexTradeNode[]
        | undefined
    );

    for (const rawTrade of rawTrades) {
      txSeq += 1;
      const symbol = String(rawTrade.symbol ?? '').trim().toUpperCase();
      const currency = String(rawTrade.currency ?? 'USD').trim().toUpperCase();
      const rawDate = String(
        rawTrade.tradeDate ?? rawTrade.dateTime ?? ''
      ).trim();
      if (!symbol || !rawDate) continue;

      const isoDate = normalizeIBKRFlexDate(rawDate);

      const rawQtyStr = cleanNumericStr(rawTrade.quantity, '0');
      const rawPriceStr = cleanNumericStr(rawTrade.tradePrice, '0');
      const rawCommStr = cleanNumericStr(rawTrade.ibCommission, '0');

      const qtyDec = new FlexDecimal(rawQtyStr).abs();
      const priceDec = new FlexDecimal(rawPriceStr);
      const commDec = new FlexDecimal(rawCommStr).abs();

      if (qtyDec.isZero()) {
        throw new Error(`IBKR Flex Trade "${symbol}" has zero quantity.`);
      }
      if (priceDec.lt(0)) {
        throw new Error(`IBKR Flex Trade "${symbol}" has negative tradePrice.`);
      }

      const rawSide = String(rawTrade.buySell ?? '').trim().toUpperCase();
      const type: TransactionType =
        rawSide === 'BUY'
          ? 'BUY'
          : rawSide === 'SELL'
            ? 'SELL'
            : new FlexDecimal(rawQtyStr).gt(0)
              ? 'BUY'
              : 'SELL';

      const grossDec = qtyDec.times(priceDec);
      const vatDec = new FlexDecimal(0);
      const netDec =
        rawTrade.netCash !== undefined && String(rawTrade.netCash).trim() !== ''
          ? new FlexDecimal(cleanNumericStr(rawTrade.netCash)).abs()
          : type === 'BUY'
            ? grossDec.plus(commDec)
            : FlexDecimal.max(new FlexDecimal(0), grossDec.minus(commDec));

      const hash = computeTransactionHash({
        date: isoDate,
        symbol,
        qty: formatExactDecimalString(qtyDec),
        price: formatExactDecimalString(priceDec),
        type,
      });

      const txId = rawTrade.tradeID
        ? `IBKR-FLEX-${String(rawTrade.tradeID).trim()}`
        : `IBKR-FLEX-${txSeq}`;

      const tx: Transaction = {
        id: txId,
        date: isoDate,
        symbol,
        qty: toNumber(qtyDec),
        price: toNumber(priceDec),
        gross: toNumber(grossDec),
        comm: toNumber(commDec),
        vat: toNumber(vatDec),
        net: toNumber(netDec),
        type,
        exchange: 'IBKR',
        currency,
        originalCurrency: currency,
        originalNet: formatExactDecimalString(netDec),
        fxRate: null,
        netTHB: null,
      };

      transactions.push(tx);
      transactionHashes[tx.id] = hash;
    }
  }

  const dividends = extractRawIBKRDividendsSync(xmlContent);
  const dividendHashes: Record<string, string> = {};
  for (const div of dividends) {
    dividendHashes[div.id] = div.idempotencyHash;
  }

  const corporateActions = parseIBKRCorporateActions(xmlContent);
  const corporateActionHashes: Record<string, string> = {};
  for (const ca of corporateActions) {
    if (ca.idempotencyHash) {
      corporateActionHashes[ca.id] = ca.idempotencyHash;
    }
  }

  return {
    transactions,
    dividends,
    corporateActions,
    transactionHashes,
    dividendHashes,
    corporateActionHashes,
  };
}

export interface FetchIBKRFlexOptions {
  baseUrl?: string;
  xmlOverride?: string;
  botFxProvider?: BotFXRateProvider;
}

/**
 * Connects (Read-Only) to IBKR Flex Web Service (`SendRequest` -> `GetStatement`)
 * or uses the deterministic offline Flex XML simulator when no external endpoint is configured.
 * Enriches parsed Dividends into THB on Pay Date via `botFxProvider` (`Decimal.js` precision: 40).
 *
 * Security Rule: Never logs `token` under any circumstances.
 */
export async function fetchAndParseIBKRFlexData(
  token: string,
  queryId: string,
  fromDate: string,
  toDate: string,
  options?: FetchIBKRFlexOptions
): Promise<IBKRFlexParseResult> {
  if (!token || !token.trim()) {
    throw new Error('IBKR Flex token is required.');
  }
  if (!queryId || !queryId.trim()) {
    throw new Error('IBKR Flex queryId is required.');
  }

  let rawStatementXml: string;

  if (options?.xmlOverride) {
    rawStatementXml = options.xmlOverride;
  } else {
    const configuredBaseUrl =
      options?.baseUrl ?? process.env['IBKR_FLEX_BASE_URL'];

    if (configuredBaseUrl) {
      const cleanBase = configuredBaseUrl.replace(/\/+$/, '');
      const sendRes = await fetch(
        `${cleanBase}/SendRequest?q=${encodeURIComponent(queryId)}&v=3`,
        {
          method: 'GET',
          headers: {
            Accept: 'application/xml',
            'X-IBKR-Flex-Token': token,
          },
        }
      );

      if (!sendRes.ok) {
        throw new Error(
          `IBKR Flex SendRequest failed with HTTP ${sendRes.status}.`
        );
      }

      const sendXml = await sendRes.text();
      const sendParsed = flexXmlParser.parse(sendXml) as Record<string, unknown>;
      const sendRoot = sendParsed['FlexStatementResponse'] as
        | Record<string, unknown>
        | undefined;

      if (!sendRoot && sendParsed['FlexQueryResponse']) {
        rawStatementXml = sendXml;
      } else {
        const status = String(sendRoot?.['Status'] ?? '');
        const refCode = String(sendRoot?.['ReferenceCode'] ?? '');
        if (status !== 'Success' || !refCode) {
          throw new Error(
            'IBKR Flex SendRequest did not return a valid ReferenceCode.'
          );
        }

        const stmtRes = await fetch(
          `${cleanBase}/GetStatement?q=${encodeURIComponent(refCode)}&from=${encodeURIComponent(fromDate)}&to=${encodeURIComponent(toDate)}&v=3`,
          {
            method: 'GET',
            headers: {
              Accept: 'application/xml',
              'X-IBKR-Flex-Token': token,
            },
          }
        );

        if (!stmtRes.ok) {
          throw new Error(
            `IBKR Flex GetStatement failed with HTTP ${stmtRes.status}.`
          );
        }

        rawStatementXml = await stmtRes.text();
      }
    } else {
      rawStatementXml = buildMockIBKRFlexStatementXml(
        queryId,
        fromDate,
        toDate
      );
    }
  }

  const baseParsed = parseIBKRFlexXml(rawStatementXml);
  const botEnrichedDividends = await parseIBKRDividends(
    rawStatementXml,
    options?.botFxProvider ?? defaultBotFxProvider
  );

  const dividendHashes: Record<string, string> = {};
  for (const div of botEnrichedDividends) {
    dividendHashes[div.id] = div.idempotencyHash;
  }

  return {
    ...baseParsed,
    dividends: botEnrichedDividends,
    dividendHashes,
  };
}
