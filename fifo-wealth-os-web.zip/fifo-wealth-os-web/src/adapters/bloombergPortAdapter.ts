import type {
  BloombergCorporateAction,
  BloombergPortConfig,
  BloombergPortTransport,
  BloombergPosition,
  BloombergTrade,
} from '../types/bloomberg';

export interface BloombergPortAdapterStatus {
  environment: 'LIVE' | 'SANDBOX';
  mode: 'SANDBOX_MOCK' | 'LIVE_TRANSPORT_NOT_CONFIGURED' | 'LIVE_TRANSPORT_INJECTED';
  connected: false;
  liveEnabled: boolean;
  message: string;
}

/**
 * Adapter boundary for Bloomberg Port.
 *
 * The repository contains no verified Bloomberg Port API contract or credentials, so SANDBOX is an
 * explicit empty mock and LIVE calls fail closed unless a separately reviewed transport is injected.
 * This class never accepts or stores Bloomberg credentials.
 */
export class BloombergPortAdapter {
  constructor(
    private readonly config: BloombergPortConfig,
    private readonly transport?: BloombergPortTransport,
  ) {
    if (!config.portfolioId.trim()) throw new Error('A portfolio ID is required for the Bloomberg Port adapter.');
    if (config.environment !== 'LIVE' && config.environment !== 'SANDBOX') {
      throw new Error('Bloomberg Port environment must be LIVE or SANDBOX.');
    }
  }

  getStatus(): BloombergPortAdapterStatus {
    if (this.config.environment === 'SANDBOX') {
      return {
        environment: 'SANDBOX',
        mode: 'SANDBOX_MOCK',
        connected: false,
        liveEnabled: false,
        message: 'Sandbox mock only: no Bloomberg network call, credentials, or live positions are used.',
      };
    }
    if (this.transport) {
      return {
        environment: 'LIVE',
        mode: 'LIVE_TRANSPORT_INJECTED',
        connected: false,
        liveEnabled: true,
        message: 'A transport was injected by the host application; this status does not verify Bloomberg authentication.',
      };
    }
    return {
      environment: 'LIVE',
      mode: 'LIVE_TRANSPORT_NOT_CONFIGURED',
      connected: false,
      liveEnabled: false,
      message: 'Live Bloomberg Port integration is not configured. No connection has been made.',
    };
  }

  async fetchPositions(): Promise<BloombergPosition[]> {
    if (this.config.environment === 'SANDBOX') return [];
    return this.liveTransport().fetchPositions(this.config.portfolioId);
  }

  async fetchTradeHistory(startDate: string, endDate: string): Promise<BloombergTrade[]> {
    if (this.config.environment === 'SANDBOX') return [];
    validateISODate(startDate, 'start date');
    validateISODate(endDate, 'end date');
    if (startDate > endDate) throw new Error('Bloomberg Port start date must not be after the end date.');
    return this.liveTransport().fetchTradeHistory(this.config.portfolioId, startDate, endDate);
  }

  async fetchCorporateActions(effectiveDateFrom: string, effectiveDateTo: string): Promise<BloombergCorporateAction[]> {
    if (this.config.environment === 'SANDBOX') return [];
    validateISODate(effectiveDateFrom, 'effective-date start');
    validateISODate(effectiveDateTo, 'effective-date end');
    if (effectiveDateFrom > effectiveDateTo) throw new Error('Bloomberg Port date range is invalid.');
    return this.liveTransport().fetchCorporateActions(effectiveDateFrom, effectiveDateTo);
  }

  private liveTransport(): BloombergPortTransport {
    if (!this.transport) {
      throw new Error('Live Bloomberg Port is not available: no verified API transport is configured.');
    }
    return this.transport;
  }
}

function validateISODate(value: string, label: string): void {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error(`Bloomberg Port ${label} must use YYYY-MM-DD format.`);
  const parsed = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) {
    throw new Error(`Bloomberg Port ${label} is not a valid date.`);
  }
}
