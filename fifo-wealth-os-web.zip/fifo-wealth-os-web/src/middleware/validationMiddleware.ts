import { NextFunction, Request, RequestHandler, Response } from 'express';
import { ZodType } from 'zod';

export interface RequestValidationSchemas {
  body?: ZodType;
  params?: ZodType;
  query?: ZodType;
}

/**
 * Zod Validation Middleware enforcing strict runtime validation across
 * request `body`, `params`, and `query` on every API endpoint.
 */
export function validateRequest(schemas: RequestValidationSchemas): RequestHandler {
  return (req: Request, res: Response, next: NextFunction): void => {
    try {
      const validated: {
        body?: unknown;
        params?: unknown;
        query?: unknown;
      } = {};

      if (schemas.body) {
        const parsedBody = schemas.body.parse(req.body ?? {});
        req.body = parsedBody;
        validated.body = parsedBody;
      }

      if (schemas.params) {
        const parsedParams = schemas.params.parse(req.params ?? {});
        validated.params = parsedParams;
      }

      if (schemas.query) {
        const parsedQuery = schemas.query.parse(req.query ?? {});
        validated.query = parsedQuery;
      }

      res.locals['validated'] = validated;
      next();
    } catch (err) {
      next(err);
    }
  };
}
