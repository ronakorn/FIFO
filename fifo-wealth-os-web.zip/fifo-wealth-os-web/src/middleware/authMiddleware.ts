import { NextFunction, Request, Response } from 'express';
import jwt, { JwtPayload } from 'jsonwebtoken';
import { AppError } from './errorHandler';

export interface AuthenticatedUser {
  id: string;
  email: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

function getJwtSecret(): string {
  return process.env['JWT_SECRET'] ?? 'fifo-wealth-os-super-secret-jwt-key-2026';
}

export function signAccessToken(user: AuthenticatedUser): string {
  return jwt.sign({ email: user.email }, getJwtSecret(), {
    subject: user.id,
    expiresIn: '7d',
  });
}

export function verifyAccessToken(token: string): AuthenticatedUser {
  const decoded = jwt.verify(token, getJwtSecret());
  if (typeof decoded === 'string') {
    throw new AppError(401, 'INVALID_TOKEN', 'Malformed JWT payload.');
  }

  const payload = decoded as JwtPayload & { email?: unknown };
  if (typeof payload.sub !== 'string' || typeof payload.email !== 'string') {
    throw new AppError(401, 'INVALID_TOKEN', 'Token payload missing required claims.');
  }

  return {
    id: payload.sub,
    email: payload.email,
  };
}

/**
 * JWT Authentication Middleware protecting private API routes.
 */
export function authMiddleware(req: Request, _res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    next(
      new AppError(
        401,
        'UNAUTHORIZED',
        'Missing or invalid Authorization header. Expected "Bearer <token>".'
      )
    );
    return;
  }

  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) {
    next(new AppError(401, 'UNAUTHORIZED', 'Empty Bearer token.'));
    return;
  }

  try {
    req.user = verifyAccessToken(token);
    next();
  } catch (err) {
    if (err instanceof AppError) {
      next(err);
      return;
    }
    next(new AppError(401, 'INVALID_TOKEN', 'Invalid or expired JWT token.'));
  }
}
