import type { NextFunction, Request, Response } from 'express';
import { checkFeatureEntitlement, checkSubscriptionTier } from './subscriptionGuard';

describe('checkSubscriptionTier — Open Beta access gate', () => {
  const previousMode = process.env.OPEN_BETA_MODE;

  afterEach(() => {
    if (previousMode === undefined) delete process.env.OPEN_BETA_MODE;
    else process.env.OPEN_BETA_MODE = previousMode;
  });

  it('always calls next for any tier when OPEN_BETA_MODE=true', async () => {
    process.env.OPEN_BETA_MODE = 'true';
    const next = jest.fn() as unknown as NextFunction;

    await checkSubscriptionTier('ADVISOR')({} as Request, {} as Response, next);

    expect(next).toHaveBeenCalledTimes(1);
    expect(next).toHaveBeenCalledWith();
  });

  it('bypasses an explicit feature mapping during Open Beta', async () => {
    process.env.OPEN_BETA_MODE = 'true';
    const next = jest.fn() as unknown as NextFunction;

    await checkFeatureEntitlement('whiteLabel')({} as Request, {} as Response, next);

    expect(next).toHaveBeenCalledTimes(1);
    expect(next).toHaveBeenCalledWith();
  });

  it('fails open when OPEN_BETA_MODE is unset to protect an unconfigured beta launch', async () => {
    delete process.env.OPEN_BETA_MODE;
    const next = jest.fn() as unknown as NextFunction;

    await checkSubscriptionTier('PRO')({} as Request, {} as Response, next);

    expect(next).toHaveBeenCalledTimes(1);
    expect(next).toHaveBeenCalledWith();
  });
});
