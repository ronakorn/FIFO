import { NextFunction, Request, Response } from 'express';
import {
  checkFeatureAccess as checkConfiguredFeatureAccess,
  getRequiredTierForFeature,
  isTierAtLeast,
  type FeatureKey,
} from '../config/pricing';
import type { SubscriptionTier } from '../services/stripeService';
import {
  getUserEntitlementContext,
  isOpenBetaEntitlementBypass,
} from '../services/entitlementService';
import { AppError } from './errorHandler';

/**
 * Enforces tier access using the configured subscription matrix.
 * Open Beta intentionally bypasses every tier check and avoids database lookups.
 */
export function checkSubscriptionTier(requiredTier: SubscriptionTier) {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    if (isOpenBetaEntitlementBypass()) return next();

    const userId = req.user?.id;
    if (!userId) {
      next(new AppError(401, 'UNAUTHORIZED', 'Sign in to access this feature.'));
      return;
    }

    try {
      const { tier } = await getUserEntitlementContext(userId);
      if (!isTierAtLeast(tier, requiredTier)) {
        next(
          new AppError(
            403,
            'SUBSCRIPTION_REQUIRED',
            `The ${requiredTier} plan is required to access this feature.`,
            { requiredTier, currentTier: tier }
          )
        );
        return;
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

/** Feature guard backed by the pricing catalog's explicit entitlement values. */
export function checkFeatureEntitlement(feature: FeatureKey) {
  const requiredTier = getRequiredTierForFeature(feature);
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    if (isOpenBetaEntitlementBypass()) return next();

    const userId = req.user?.id;
    if (!userId) {
      next(new AppError(401, 'UNAUTHORIZED', 'Sign in to access this feature.'));
      return;
    }

    try {
      const { tier } = await getUserEntitlementContext(userId);
      if (!checkConfiguredFeatureAccess(tier, feature)) {
        next(
          new AppError(
            403,
            'SUBSCRIPTION_REQUIRED',
            `The ${requiredTier} plan is required to access this feature.`,
            { requiredTier, currentTier: tier, feature }
          )
        );
        return;
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}
