// Backward-compatible backend import path; shared types are maintained in @fifo/types.
export * from '@fifo/types/advancedAssets';
