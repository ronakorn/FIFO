import { Lot } from '../types';

export type HarvestingOpportunityStatus = 'AVAILABLE' | 'WASH_SALE_RISK';

export interface HarvestingInput {
  symbol: string;
  avgCost: string;
  currentPrice: string;
  qty: number;
  daysHeld: number;
  marginalTaxRate?: string;
  lotId?: string;
}

export interface TaxLossHarvestingOpportunity {
  lotId: string;
  symbol: string;
  qtyRemain?: string;
  currentPrice: string;        // Decimal string (THB)
  avgCost: string;             // Decimal string (THB)
  unrealizedLoss: string;      // Positive magnitude Decimal string (THB), e.g. "10000.00"
  daysHeld: number;
  taxSavingPotential: string;  // Decimal string (THB), e.g. "2000.00"
  marginalTaxRate: string;     // Decimal string, e.g. "0.20"
  washSaleRisk: boolean;       // True if held < 30 days (US Wash Sale Rule)
  status: HarvestingOpportunityStatus;
  washSaleNote?: string | null;
}

export interface HarvestingSimulation {
  totalTaxSaving: string;
  newTaxLiability: string;
  harvestedLots: string[];
  washSaleWarnings: string[];
  totalHarvestedLoss: string;
  currentTaxLiability?: string;
  selectedCount?: number;
}

export type HarvestingSimulationResult = HarvestingSimulation;

export type CorporateActionType = 'STOCK_SPLIT' | 'REVERSE_SPLIT';

export interface CorporateActionLot {
  id: string;
  symbol: string;
  qty: number;
  costPerUnit: string;
  date: string;
}

export interface LotBeforeAfterPreview {
  lotId: string;
  symbol: string;
  date: string;
  daysHeldBefore: number;
  daysHeldAfter: number;
  qtyBefore: string;
  qtyAfter: string;
  costPerUnitBefore: string;
  costPerUnitAfter: string;
  totalCostBasisBefore: string;
  totalCostBasisAfter: string;
  affected: boolean;
}

export interface SplitAdjustmentPreview {
  actionId: string;
  symbol: string;
  type: CorporateActionType;
  ratio: number;
  effectiveDate: string;
  affectedLotCount: number;
  totalCostBeforeTHB: string;
  totalCostAfterTHB: string;
  isCostBasisPreserved: boolean;
  isDaysHeldPreserved: boolean;
  lotPreviews: LotBeforeAfterPreview[];
}

export interface CorporateAction {
  id: string;
  symbol: string;
  type: CorporateActionType;
  ratio: number;               // e.g. 2 for 2:1 Stock Split, 10 for 1:10 Reverse Split
  effectiveDate: string;       // ISO YYYY-MM-DD
  announcementDate?: string;   // ISO YYYY-MM-DD
  adjustmentFactor: number | string; // e.g. 0.25 or "2.0000"
  description?: string;
  title?: string;
  applied?: boolean;
  source?: 'IBKR_FLEX' | 'MARKET_FEED';
  idempotencyHash?: string;
  preview?: SplitAdjustmentPreview;
}

export interface ApplyCorporateActionResult {
  action: CorporateAction;
  beforeLots: Lot[];
  adjustedLots: Lot[];
  totalCostBeforeTHB: string;
  totalCostAfterTHB: string;
}

export interface DividendForecast {
  symbol: string;
  exDate: string;
  payDate: string;
  amountPerShare: string;      // Decimal string in original currency
  sharesHeld: number | string;
  currency: string;
  fxRate?: string;             // Decimal string to THB (default "1.00" for THB, "35.50" for USD)
}

export type DividendFrequency =
  | 'MONTHLY'
  | 'QUARTERLY'
  | 'SEMI_ANNUAL'
  | 'ANNUAL';

export interface DividendEvent {
  id?: string;
  symbol: string;
  exDate: string;
  payDate: string;
  amountPerShare: string;
  currency: string;
  estimatedTHB: string;        // Exact Decimal string (THB)
  frequency?: DividendFrequency;
  isForecast?: boolean;
  sharesHeld?: string;
}

export interface MonthlyDividendSummary {
  month: number;               // 1 - 12
  year: number;
  totalDividends: string;      // Decimal string (THB, 2dp)
  dividendCount: number;
  averageMonthlyIncome: string; // Decimal string (yearlyTotal / 12, 2dp)
}

export interface MonthlyDividendBucket {
  month: number;               // 1 - 12
  monthKey: string;            // 'Jan' .. 'Dec'
  monthNameTH: string;
  actualTHB: string;
  forecastTHB: string;
  totalTHB: string;
  eventCount: number;
  events: DividendEvent[];
}

export interface DividendCalendarReport {
  year: number;
  events: DividendEvent[];
  monthlyIncome: MonthlyDividendBucket[];
  yearlyDividendTHB: string;
  averageMonthlyTHB: string;
  upcomingDividends: DividendEvent[];
}
