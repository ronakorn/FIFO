import { Exchange, TransactionType } from '../types';

export const SUPPORTED_CHAINS = ['EVM', 'SOLANA', 'BTC'] as const;
export type SupportedChain = (typeof SUPPORTED_CHAINS)[number];

export type TokenStandard = 'NATIVE' | 'ERC20' | 'SPL' | 'UTXO';

export interface OnChainTokenBalance {
  chain: SupportedChain;
  symbol: string;
  name: string;
  standard: TokenStandard;
  contractAddress: string | null;
  decimals: number;
  balance: string;     // Exact Decimal string (human-readable units)
  priceUSD: string;    // Exact Decimal string
  valueUSD: string;    // Exact Decimal string (balance * priceUSD)
}

export interface OnChainGasFee {
  tokenSymbol: string;   // e.g. 'ETH', 'SOL', 'BTC'
  amount: string;        // Exact Decimal string in native gas token (e.g. '0.0045')
  unitPriceUSD: string;  // Exact Decimal string (e.g. '2500.00')
}

export interface OnChainSwapActivity {
  kind: 'SWAP';
  txHash: string;
  blockNumber: number;
  timestamp: string;     // ISO 8601 ('YYYY-MM-DD' or full ISO)
  chain: SupportedChain;
  protocol: string;      // e.g. 'Uniswap V3', 'Jupiter V6'
  tokenIn: {
    symbol: string;
    standard: TokenStandard;
    contractAddress: string | null;
    amount: string;      // Exact Decimal string (e.g. '3000.00')
    unitPriceUSD: string;
  };
  tokenOut: {
    symbol: string;
    standard: TokenStandard;
    contractAddress: string | null;
    amount: string;      // Exact Decimal string (e.g. '1.20')
    unitPriceUSD: string;
  };
  gasFee: OnChainGasFee;
}

export interface OnChainTransferActivity {
  kind: 'TRANSFER';
  direction: 'IN' | 'OUT';
  txHash: string;
  blockNumber: number;
  timestamp: string;
  chain: SupportedChain;
  counterpartyMasked: string;
  token: {
    symbol: string;
    standard: TokenStandard;
    contractAddress: string | null;
    amount: string;
    unitPriceUSD: string;
  };
  gasFee?: OnChainGasFee; // Present when wallet owner paid gas (e.g. TRANSFER OUT)
}

export type OnChainActivity = OnChainSwapActivity | OnChainTransferActivity;

export type CDMOnChainTransactionType = TransactionType | 'FEE';

export type OnChainLegRole =
  | 'SWAP_SELL'
  | 'SWAP_BUY'
  | 'GAS_FEE'
  | 'TRANSFER_IN'
  | 'TRANSFER_OUT';

/**
 * Canonical Data Model (CDM) representation for On-Chain transactions.
 * 100% structurally compatible with `Transaction` (`src/types.ts`) for `BUY` and `SELL`,
 * while extending `type` with `'FEE'` for explicit On-Chain Gas Fee accounting.
 */
export interface CDMOnChainTransaction {
  id: string;
  date: string;
  symbol: string;
  qty: number;
  price: number;
  gross: number;
  comm: number;
  vat: number;
  net: number;
  type: CDMOnChainTransactionType;
  exchange: Exchange;
  currency?: string;
  originalCurrency: string;
  originalNet: string;
  fxRate: string | null;
  netTHB: string | null;
  // Audit & Idempotency metadata (not persisted in core Transaction columns)
  txHash: string;
  chain: SupportedChain;
  legRole: OnChainLegRole;
  protocol?: string;
  exactGrossDecimal: string;
  exactCommDecimal: string;
  exactNetDecimal: string;
  idempotencyHash: string;
}

/**
 * Vendor-agnostic Blockchain Indexer interface ready for Alchemy, Moralis, or Covalent.
 * Strictly Read-Only: accepts ONLY public wallet addresses, NEVER private keys.
 */
export interface ChainIndexerProvider {
  readonly providerName: string;
  readonly supportedChains: readonly SupportedChain[];

  getTokenBalances(
    chain: SupportedChain,
    walletAddress: string
  ): Promise<OnChainTokenBalance[]>;

  getTransactionHistory(
    chain: SupportedChain,
    walletAddress: string,
    options?: {
      fromDate?: string;
      toDate?: string;
    }
  ): Promise<OnChainActivity[]>;
}

export interface CryptoWalletPublic {
  id: string;
  portfolioId: string | null;
  chain: SupportedChain;
  addressMasked: string;
  addressHash: string;
  label: string | null;
  isActive: boolean;
  lastSyncedAt: string | null;
  createdAt: string;
  readOnly: true;
  privacyProtection: 'AES-256-GCM + SHA-256';
}

export interface CryptoWalletSyncResult {
  wallet: CryptoWalletPublic;
  providerName: string;
  portfolioId: string;
  tokenBalances: OnChainTokenBalance[];
  discoveredOnChainCount: number;
  generatedCdmCount: number;
  addedTransactions: number;
  skippedTransactions: number;
  breakdown: {
    swaps: number;
    transfers: number;
    buyLegs: number;
    sellLegs: number;
    feeLegs: number;
  };
  syncedAt: string;
}
