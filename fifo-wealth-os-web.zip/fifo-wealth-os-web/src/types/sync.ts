import { Dividend, Transaction } from '../types';
import { CorporateAction } from './wave1';

export type BrokerSyncStatus =
  | 'CONNECTED'
  | 'SYNCING'
  | 'ERROR'
  | 'DISCONNECTED';

export interface BrokerConnectionPublic {
  id: string | null;
  brokerName: 'IBKR';
  flexQueryId: string | null;
  portfolioId: string | null;
  status: BrokerSyncStatus;
  connected: boolean;
  lastSyncedAt: string | null;
  createdAt: string | null;
  readOnly: true;
  encryption: 'AES-256-GCM';
}

/**
 * Extended IBKR Dividend DTO compatible 100% with Canonical `Dividend` (`src/types.ts`)
 * while exposing explicit IBKR Flex `exDate`, `payDate`, `grossAmount`, `withholdingTax`,
 * `currency`, and BOT Pay-Date THB FX conversion fields.
 */
export interface IBKRParsedDividend extends Dividend {
  exDate: string;          // ISO YYYY-MM-DD
  payDate: string;         // ISO YYYY-MM-DD (matches `date`)
  grossAmount: string;     // Decimal string in native currency (matches `gross`)
  withholdingTax: string;  // Decimal string in native currency (matches `wht`)
  currency: string;        // ISO currency code (matches `originalCurrency`)
  idempotencyHash: string; // Deterministic SHA-256 hash
}

export interface IBKRFlexParseResult {
  transactions: Transaction[];
  dividends: IBKRParsedDividend[];
  corporateActions: CorporateAction[];
  transactionHashes: Record<string, string>;
  dividendHashes: Record<string, string>;
  corporateActionHashes: Record<string, string>;
}

export interface ManualSyncResult {
  addedTransactions: number;
  addedDividends: number;
  skippedTransactions: number;
  skippedDividends: number;
  detectedCorporateActions?: number;
  corporateActions?: CorporateAction[];
  portfolioId: string;
  status: BrokerSyncStatus;
  lastSyncedAt: string;
}
