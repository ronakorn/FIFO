import { GoldPurity, GoldTransaction, GoldWeightUnit } from './gold';

export type RolloverLegAction =
  | 'OPEN_LONG'
  | 'CLOSE_LONG'
  | 'OPEN_SHORT'
  | 'CLOSE_SHORT';

export type ExpiryAlertSeverity =
  | 'EXPIRED'
  | 'CRITICAL_1D'
  | 'URGENT_3D'
  | 'WARNING_7D'
  | 'UPCOMING_30D'
  | 'SAFE';

export type MarketStructureRegime = 'CONTANGO' | 'BACKWARDATION' | 'FLAT';

export interface FuturesContractSpec {
  symbol: string; // e.g., 'GOV26', 'GOZ26', 'GOH27', 'GOM27'
  exchange: 'TFEX' | 'COMEX';
  contractMonth: string; // e.g., 'V26', 'Z26', 'H27', 'M27'
  expirationDate: string; // ISO YYYY-MM-DD (Last Trading Day)
  noticeDate: string; // ISO YYYY-MM-DD (First Notice / Settlement Day)
  suggestedNextSymbol: string; // e.g., 'GOZ26' -> 'GOH27'
  suggestedNextMonth: string; // e.g., 'H27'
  suggestedNextExpirationDate: string; // ISO YYYY-MM-DD
  currentMarketPriceUSD: string; // Decimal string (USD per Troy Oz)
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
}

export interface DerivativesContractExtensionDTO {
  id: string;
  transactionId: string;
  contractMonth: string;
  expirationDate: string;
  legAction: RolloverLegAction;
  isRollover: boolean;
  rolloverGroupId: string | null;
  rolloverSpread: string | null;
}

export interface ExpiringContractAlert {
  lotId: string;
  transactionId: string;
  symbol: string;
  contractMonth: string;
  expirationDate: string;
  daysToExpiry: number;
  severity: ExpiryAlertSeverity;
  shouldPlayAudioAlert: boolean; // true when daysToExpiry <= 7 (7d, 3d, 1d alerts)
  openWeight: string;
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
  entryCostPerUnitTHB: string;
  currentFrontPriceUSD: string;
  suggestedBackSymbol: string;
  suggestedBackMonth: string;
  suggestedBackExpirationDate: string;
  suggestedBackPriceUSD: string;
  estimatedSpreadPerUnitUSD: string;
  regime: MarketStructureRegime;
  alertMessageTH: string;
  alertMessageEN: string;
}

export interface RolloverSpreadAnalytics {
  frontSymbol: string;
  backSymbol: string;
  weight: string;
  weightUnit: GoldWeightUnit;
  frontClosePriceUSD: string;
  backOpenPriceUSD: string;
  fxRateUSDTHB: string;
  spreadPerUnitUSD: string; // backOpenPriceUSD - frontClosePriceUSD
  spreadPerUnitTHB: string;
  regime: MarketStructureRegime; // CONTANGO (>0), BACKWARDATION (<0), FLAT (=0)
  totalSpreadCostUSD: string; // spreadPerUnitUSD * weight
  totalSpreadCostTHB: string; // Positive = Contango Cost Drag, Negative = Backwardation Yield Benefit
  totalCommissionTHB: string; // (closeComm + openComm) * fxRate
  netRolloverFrictionTHB: string; // totalSpreadCostTHB + totalCommissionTHB
  estimatedCloseRealizedGLTHB: string; // FIFO Realized PnL from closing front-month contract
  newBackContractCostBasisTHB: string; // Initial cost basis of new back-month contract
}

export interface RolloverHistoryItem {
  rolloverGroupId: string;
  executedDate: string;
  frontSymbol: string;
  frontContractMonth: string;
  backSymbol: string;
  backContractMonth: string;
  rolledWeight: string;
  weightUnit: GoldWeightUnit;
  frontClosePriceUSD: string;
  backOpenPriceUSD: string;
  rolloverSpreadUSD: string;
  regime: MarketStructureRegime;
  spreadCostTHB: string;
  realizedGLClosedLegTHB: string;
  newOpenCostBasisTHB: string;
}

export interface ExecuteRolloverInput {
  portfolioId: string;
  date: string; // ISO YYYY-MM-DD
  frontSymbol: string;
  frontContractMonth: string;
  frontExpirationDate: string;
  frontClosePriceUSD: string;
  closeCommissionUSD: string;
  backSymbol: string;
  backContractMonth: string;
  backExpirationDate: string;
  backOpenPriceUSD: string;
  openCommissionUSD: string;
  weight: string;
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
  fxRateUSDTHB: string;
}

export interface ExecuteRolloverResult {
  rolloverGroupId: string;
  closeTransaction: GoldTransaction;
  openTransaction: GoldTransaction;
  closeExtension: DerivativesContractExtensionDTO;
  openExtension: DerivativesContractExtensionDTO;
  analytics: RolloverSpreadAnalytics;
}

export interface ContractRolloverOverview {
  portfolioId: string;
  asOfDate: string;
  usdThbRate: string;
  contractCatalog: FuturesContractSpec[];
  activeAlerts: ExpiringContractAlert[];
  rolloverHistory: RolloverHistoryItem[];
  summary: {
    activeFuturesContractsCount: number;
    urgentExpiringCount: number; // <= 7 days
    totalRolloversExecuted: number;
    cumulativeSpreadCostTHB: string; // Net Contango (+) / Backwardation (-) cost
    cumulativeRealizedOnRolloversTHB: string;
    netRolloverImpactPct: string; // Cumulative spread & fee drag vs total gold portfolio value
  };
}
