import { Dividend, Transaction } from '../types';
import { BrokerSyncStatus } from './sync';

export const THAI_BROKER_IDS = ['BITKUB', 'DIME', 'STREAMING'] as const;
export type ThaiBrokerId = (typeof THAI_BROKER_IDS)[number];

export type ThaiBrokerConnectionMode =
  | 'READ_ONLY_API'
  | 'OPEN_API_HYBRID'
  | 'SECURE_STATEMENT_AUTOMATION';

export type ThaiBrokerDataSource =
  | 'NOT_TESTED'
  | 'SANDBOX_MOCK'
  | 'LIVE_PARTNER_API';

export const CURRENT_PDPA_CONSENT_VERSION = 'PDPA-SEC-TH-2026.1' as const;

export interface PdpaConsentInput {
  accepted: boolean;
  consentVersion?: string;
  purposes?: string[];
}

/**
 * Mirrors Bitkub Official Market API v3 (`/api/v3/market/my-order-history`) item structure.
 * All monetary/quantity fields accepted as string or number and parsed strictly via Decimal(40).
 */
export interface BitkubRawTradeItem {
  txn_id: string;
  order_id?: string;
  hash?: string;
  sym?: string; // API result omits pair; adapter fills from request, e.g. 'BTC_THB'
  side: 'buy' | 'sell' | 'BUY' | 'SELL';
  type?: 'limit' | 'market';
  rate: string | number;   // Execution price in THB per 1 base-asset unit
  amount: string | number; // Buy = quote THB amount; Sell = base-asset quantity (Bitkub API v3 contract)
  fee: string | number;    // Actual trading fee paid in THB
  credit?: string | number; // Fee-credit discount applied in THB
  ts: number | string;     // Unix timestamp (milliseconds in current API) or ISO date
  order_closed_at?: number | string;
}

export interface BitkubApiOrderHistoryResponse {
  error: number;
  result: BitkubRawTradeItem[];
  pagination?: {
    page?: number;
    last?: number;
    next?: number | null;
    prev?: number | null;
    cursor?: string;
    has_next?: boolean;
  };
}

export interface BitkubReadOnlyCredentials {
  broker: 'BITKUB';
  apiKey: string;
  apiSecret: string;
  permissionsScope?: 'READ_ONLY' | 'TRADE' | 'WITHDRAW';
}

export interface DimeRawTradeItem {
  tradeId: string;
  executedAt: string; // ISO date or timestamp
  symbol: string;     // e.g., 'NVDA', 'AAPL', 'SCB'
  market: 'US' | 'TH';
  side: 'BUY' | 'SELL';
  shares: string;     // Supports fractional shares up to 8 decimals (e.g., '0.50000000')
  price: string;      // Price in native currency ('USD' or 'THB')
  commission: string; // Commission in native currency
  vat?: string;       // VAT in native currency
  currency: 'USD' | 'THB';
}

export interface DimeRawDividendItem {
  dividendId: string;
  payDate: string;
  symbol: string;
  shares: string;
  divPerShare: string;
  grossAmount: string;
  withholdingTax: string;
  currency: 'USD' | 'THB';
}

export interface DimeCredentials {
  broker: 'DIME';
  partnerAccessToken?: string;
  dimeAccountRef: string;
  mode?: 'OPEN_API_HYBRID' | 'SECURE_STATEMENT_AUTOMATION';
}

export interface StreamingConfirmationRow {
  confirmNo: string;
  tradeDate: string;   // ISO YYYY-MM-DD
  symbol: string;      // SET ticker e.g., 'ADVANC', 'PTT', 'AOT'
  side: 'BUY' | 'SELL';
  volume: string;      // Shares
  priceTHB: string;    // Execution price per share in THB
  commissionRate?: string; // Default SET electronic rate '0.00157' (0.157%)
}

export interface StreamingDividendRow {
  refNo: string;
  payDate: string;
  symbol: string;
  shares: string;
  dpsTHB: string;
  whtRate?: string; // Default Thai TSD e-Dividend WHT '0.10' (10%)
}

export interface StreamingCredentials {
  broker: 'STREAMING';
  memberBrokerCode: string; // e.g., 'BLS', 'INVX', 'KS', 'KKPS'
  accountRef: string;
  statementSyncToken: string;
}

export type ThaiBrokerCredentials =
  | BitkubReadOnlyCredentials
  | DimeCredentials
  | StreamingCredentials;

export interface ThaiBrokerParseResult {
  broker: ThaiBrokerId;
  connectionMode: ThaiBrokerConnectionMode;
  transactions: Transaction[];
  dividends: Dividend[];
  transactionHashes: Record<string, string>;
  dividendHashes: Record<string, string>;
}

export interface ThaiBrokerConnectionPublic {
  id: string | null;
  broker: ThaiBrokerId;
  displayName: string;
  regulatoryBadge: string;
  partnerBadge: 'Official Partner Integration Ready';
  connectionMode: ThaiBrokerConnectionMode;
  dataSource: ThaiBrokerDataSource;
  maskedAccountRef: string | null;
  portfolioId: string | null;
  status: BrokerSyncStatus;
  connected: boolean;
  readOnly: true;
  encryption: 'AES-256-GCM';
  pdpaConsented: boolean;
  pdpaConsentedAt: string | null;
  pdpaConsentVersion: string | null;
  lastSyncedAt: string | null;
  futureRoadmapNote: string | null;
}

export interface ThaiBrokerSyncResult {
  broker: ThaiBrokerId;
  connectionMode: ThaiBrokerConnectionMode;
  dataSource: ThaiBrokerDataSource;
  portfolioId: string;
  addedTransactions: number;
  addedDividends: number;
  skippedTransactions: number;
  skippedDividends: number;
  status: BrokerSyncStatus;
  lastSyncedAt: string;
}

export interface ThaiBrokerDisconnectResult {
  broker: ThaiBrokerId;
  disconnected: true;
  credentialsPurged: true;
  pdpaConsentRevoked: true;
  purgedTransactionsCount: number;
  purgedDividendsCount: number;
  connection: ThaiBrokerConnectionPublic;
}
