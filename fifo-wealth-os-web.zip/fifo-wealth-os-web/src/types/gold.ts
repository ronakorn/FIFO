// src/types/gold.ts
import { Decimal } from 'decimal.js';

export type GoldDecimalInstance = Decimal;

export type GoldAssetSubclass =
  | 'PHYSICAL_GOLD'
  | 'GOLD_ONLINE_FUTURES'
  | 'XAU_SPOT';
export type GoldWeightUnit = 'THAI_BAHT' | 'GRAM' | 'TROY_OUNCE';
export type GoldPurity = '96.5' | '99.99' | '99.9' | '99.5';

export interface GoldTransaction {
  id: string;
  portfolioId: string;
  date: string; // ISO 8601
  symbol: string; // e.g., 'XAUUSD', 'GOLD965', 'GOLD9999'
  assetSubclass: GoldAssetSubclass;

  // Gold-Specific Fields
  weight: string; // Decimal string (e.g., "5.00" บาททองคำ หรือ "76.22" กรัม)
  weightUnit: GoldWeightUnit;
  purity: GoldPurity; // e.g., "96.5"

  // Pricing
  spotPricePerUnit: string; // Decimal string (THB per บาททองคำ หรือ USD per Troy Ounce)
  premiumPerUnit: string; // Decimal string (ค่าบล็อก/พรีเมียมต่อหน่วย)
  commission: string; // Decimal string (ค่าธรรมเนียม)

  // Calculated
  totalCost: string; // Decimal string = (spotPrice + premiumPerUnit) × weight + commission
  fxRateAtPurchase: string; // Decimal string (USD/THB ณ วันซื้อ สำหรับ XAU_SPOT)

  type: 'BUY' | 'SELL';
  createdAt: Date;
}

export interface GoldLot {
  id: string;
  transactionId: string;
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  weight: string; // Decimal string
  weightUnit: GoldWeightUnit;
  purity: GoldPurity;
  costPerUnit: string; // Decimal string (รวม Premium แล้ว)
  weightSold: string;
  weightRemain: string;
  realizedGL: string;
  unrealizedGL: string;
  status: 'Hold' | 'Partial' | 'Sold';
  isTaxExempt?: boolean;
}

/**
 * Tax Engine Handoff Payload produced by Gold Engine.
 * Under Thai Revenue Code Sec. 42(9), domestic physical gold bullion matching
 * Thai standards (e.g., 'GOLD965', 'GOLD9999') carries `isTaxExempt: true`
 * so Capital Gains Tax calculation is bypassed without modifying core `thaiTaxEngine.ts`.
 */
export interface GoldTaxHandoffRecord {
  lotId: string;
  transactionId: string;
  symbol: string;
  assetSubclass: GoldAssetSubclass;
  purity: GoldPurity;
  realizedGLTHB: string;
  isTaxExempt: boolean;
  taxableCapitalGainTHB: string;
  exemptionCode: 'TH_RD_SEC_42_9_PHYSICAL_GOLD' | null;
}

export type GoldDriverState =
  | 'WORLD_GOLD_RALLY'
  | 'WORLD_GOLD_PULLBACK'
  | 'WORLD_GOLD_FLAT';

export type FxDriverState =
  | 'THB_WEAKENING'
  | 'THB_STRENGTHENING'
  | 'THB_FLAT';

export type BrinsonPrimaryDriver = 'GOLD_ALPHA' | 'FX_IMPACT' | 'BALANCED';

export interface GtaGold965ParityBreakdown {
  xauUsdSpot: string; // Decimal string (USD / Troy Oz)
  usdThbRate: string; // Decimal string (THB / USD)
  conversionFactor965: string; // (15.244 / 31.1034768) * 0.965
  gtaParityPriceTHB: string; // Theoretical 96.5% Baht bar price (2 dp)
  rawGtaParityPriceTHB: string; // 40-digit Decimal string
  gtaAssociationSellTHB?: string; // Quoted GTA 96.5% sell price (THB)
  domesticPremiumTHB?: string; // Quoted - Theoretical (THB)
  domesticPremiumPct?: string; // Quoted spread ratio
}

export interface MultiplicativeBrinsonItem {
  symbol: string;
  assetSubclass?: GoldAssetSubclass;
  mode: 'UNREALIZED' | 'REALIZED';
  costBasisTHB: string; // 2 dp THB
  endingValueTHB: string; // Market Value THB (Unrealized) or Sale Proceeds THB (Realized)
  totalGLTHB: string; // endingValueTHB - costBasisTHB (2 dp)
  entryUsdThb: string; // 4 dp FX
  currentUsdThb: string; // 4 dp FX
  entryImpliedXauUsd?: string; // Implied/Entry Gold USD per Oz
  currentImpliedXauUsd?: string; // Implied/Current Gold USD per Oz
  totalReturnRatio: string; // R_total (6 dp, e.g. "0.155000")
  goldReturnRatio: string; // R_gold (6 dp, e.g. "0.100000")
  fxReturnRatio: string; // R_fx (6 dp, e.g. "0.050000")
  totalReturnPct: string; // 4 dp ratio for backward compatibility (e.g. "0.1550")
  goldAlphaPct: string; // 4 dp ratio (e.g. "0.1000")
  fxImpactPct: string; // 4 dp ratio (e.g. "0.0500")
  goldPriceContributionTHB: string; // Cost Basis THB * R_gold (2 dp)
  fxContributionTHB: string; // (Cost Basis THB + Gold Contrib) * R_fx (2 dp)
  rawGoldPriceContributionTHB: string; // Full precision string
  rawFxContributionTHB: string; // Full precision string
  unexplainedResidualTHB: string; // Guaranteed "0.00"
  isZeroResidualVerified: boolean;
  goldDriverState: GoldDriverState;
  goldDriverLabelTH: string; // "ทองโลกวิ่งขึ้น" | "ทองโลกย่อตัว" | "ทองโลกทรงตัว"
  goldDriverLabelEN: string;
  fxDriverState: FxDriverState;
  fxDriverLabelTH: string; // "บาทอ่อนค่า" | "บาทแข็งค่า" | "ค่าเงินบาททรงตัว"
  fxDriverLabelEN: string;
  primaryDriver: BrinsonPrimaryDriver;
  driverSummaryTH: string;
  driverSummaryEN: string;
  formulaProof: {
    multiplicativeIdentity: string; // "(1 + R_total) = (1 + R_gold) × (1 + R_fx)"
    goldContributionFormula: string; // "Cost Basis THB × R_gold"
    fxContributionFormula: string; // "(Cost Basis THB + Gold Contribution) × R_fx"
    zeroResidualCheck: string; // "Gold Contribution + FX Contribution === Total G/L"
  };
}

export interface PortfolioGoldBrinsonReport {
  gtaParity: GtaGold965ParityBreakdown;
  unrealizedItems: MultiplicativeBrinsonItem[];
  unrealizedSummary: MultiplicativeBrinsonItem;
  realizedItems: MultiplicativeBrinsonItem[];
  realizedSummary: MultiplicativeBrinsonItem;
}

export interface GoldFXSensitivity {
  symbol: string;
  assetSubclass?: GoldAssetSubclass;
  costBasisTHB?: string;
  marketValueTHB?: string;
  totalGLTHB?: string;
  entryUsdThb?: string;
  currentUsdThb?: string;
  totalReturnPct: string; // Decimal string (e.g., "0.0500" = 5%)
  goldAlphaPct: string; // Decimal string (กำไรจากราคาทองโลก)
  fxImpactPct: string; // Decimal string (กำไร/ขาดทุนจากอัตราแลกเปลี่ยน)
  goldReturnRatio?: string; // 6 dp R_gold
  fxReturnRatio?: string; // 6 dp R_fx
  totalReturnRatio?: string; // 6 dp R_total
  goldDriverState?: GoldDriverState;
  goldDriverLabelTH?: string;
  goldDriverLabelEN?: string;
  fxDriverState?: FxDriverState;
  fxDriverLabelTH?: string;
  fxDriverLabelEN?: string;
  primaryDriver?: BrinsonPrimaryDriver;
  driverSummaryTH?: string;
  driverSummaryEN?: string;
  unexplainedResidualTHB?: string;
  isZeroResidualVerified?: boolean;
  attribution: {
    goldPriceContribution: string; // Decimal string (THB)
    fxContribution: string; // Decimal string (THB)
  };
}

export interface GoldPortfolioBreakdown {
  physicalGold: {
    totalWeight: string; // Decimal string (บาททองคำ)
    totalValueTHB: string;
    percentage: string;
  };
  paperGold: {
    totalWeight: string;
    totalValueTHB: string;
    percentage: string;
    marginRequirement?: string; // สำหรับ Futures
  };
}

/**
 * Extended Quantitative Analytics Interfaces for Gold Premium & FX Sensitivity Engine
 */
export interface GoldMarketEnvironment {
  xauUsdSpot: string; // USD per Troy Ounce (e.g. "2740.00")
  usdThbRate: string; // THB per 1 USD (e.g. "35.80")
  gtaGold965SellTHB: string; // Domestic Thai Gold Association 96.5% Baht bar price (e.g. "43850.00")
  theoreticalGold965THB: string; // World parity price = XAUUSD * (15.244 / 31.1034768) * 0.965 * USDTHB
  domesticPremiumTHB: string; // gtaGold965SellTHB - theoreticalGold965THB
  domesticPremiumPct: string; // Decimal string (e.g. "0.0068" = +0.68%)
}

export interface GoldSensitivityMatrixCell {
  goldShockPct: string; // e.g., "-0.10", "0.00", "0.10"
  fxShockPct: string; // e.g., "-0.05", "0.00", "0.05"
  projectedXauUsd: string;
  projectedUsdThb: string;
  projectedGold965THB: string;
  projectedPortfolioValueTHB: string;
  projectedNetGLTHB: string;
  projectedReturnPct: string;
}

export interface GoldOverviewSummary {
  portfolioId: string;
  market: GoldMarketEnvironment;
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  taxExemptRealizedGLTHB?: string;
  taxableRealizedGLTHB?: string;
  totalUnrealizedGLTHB: string;
  totalPremiumPaidTHB: string;
  premiumDragPct: string;
  totalEquivalentBaht965: string;
  totalFineGoldGrams: string;
  lots: GoldLot[];
  taxHandoffRecords?: GoldTaxHandoffRecord[];
  transactions: GoldTransaction[];
  fxSensitivities: GoldFXSensitivity[];
  brinsonAttribution?: PortfolioGoldBrinsonReport;
  breakdown: GoldPortfolioBreakdown;
  sensitivityMatrix: GoldSensitivityMatrixCell[];
}
