// Backward-compatible backend import path; the canonical CDM lives in @fifo/types.
export * from '@fifo/types/multiAsset';
