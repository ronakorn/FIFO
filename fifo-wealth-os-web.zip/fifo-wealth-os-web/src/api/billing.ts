import { NextFunction, Request, Response, Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  EARLY_BIRD_DISCOUNT,
  getPublicPricingCatalog,
  getTierEntitlements,
  isEarlyBirdWindowOpen,
  type TierId,
} from '../config/pricing';
import {
  DONOR_PRO_YEAR_DURATION_MONTHS,
  DONOR_PRO_YEAR_THRESHOLD_THB,
  getCommunityFundraisingStats,
  getUserDonationRewardStatus,
} from '../services/billingRewards';
import { BillingDecimal, stripeService } from '../services/stripeService';

interface RequestWithRawBody extends Request {
  rawBody?: Buffer;
}

export const billingRouter = Router();

function isOpenBetaMode(): boolean {
  // Open Beta is the safe default; setting the environment variable to "false" turns gating on.
  return process.env.OPEN_BETA_MODE === 'true' || process.env.OPEN_BETA_MODE === undefined;
}

function optionalAuthMiddleware(req: Request, res: Response, next: NextFunction): void {
  if (!req.header('authorization')) {
    next();
    return;
  }
  authMiddleware(req, res, next);
}

const donationBodySchema = z.object({
  amountTHB: z
    .string()
    .trim()
    .regex(/^\d+(?:\.\d{1,2})?$/, 'Enter a THB amount with up to two decimal places.')
    .refine((value) => {
      const amount = new BillingDecimal(value);
      return amount.isFinite() && amount.gte(10) && amount.lte(1_000_000);
    }, 'Donation amount must be between ฿10 and ฿1,000,000.'),
  message: z.string().trim().max(280, 'Message must be 280 characters or fewer.').optional(),
});

type DonationBody = z.infer<typeof donationBodySchema>;

function asRecord(value: unknown): Record<string, unknown> | null {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function stringValue(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function isKnownTier(value: unknown): value is TierId {
  return value === 'FREE' || value === 'PRO' || value === 'FAMILY' || value === 'ADVISOR';
}

function readMetadata(object: Record<string, unknown>): Record<string, unknown> {
  return asRecord(object['metadata']) ?? {};
}

function readEpochDate(value: unknown): Date | undefined {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) return undefined;
  return new Date(value * 1000);
}

async function applyStripeEvent(
  event: ReturnType<typeof stripeService.constructWebhookEvent>
): Promise<boolean> {
  const prisma = getPrismaClient();
  const object = event.data.object;
  const metadata = readMetadata(object);
  const donationId = stringValue(metadata['donationId']);
  const paymentIntentId = stringValue(object['payment_intent']) ?? stringValue(object['id']);

  if (event.type === 'checkout.session.completed' || event.type === 'payment_intent.succeeded') {
    if (donationId) {
      const donation = await prisma.donation.findUnique({ where: { id: donationId } });
      if (donation) {
        const settledDonation = await prisma.donation.update({
          where: { id: donationId },
          data: {
            status: 'SUCCEEDED',
            ...(paymentIntentId ? { stripePaymentId: paymentIntentId } : {}),
          },
        });
        // Qualification is automatic, idempotent, and only counts succeeded donations.
        await getUserDonationRewardStatus(settledDonation.userId);
      }
    }

    const userId = stringValue(metadata['userId']);
    const tier = stringValue(metadata['tier']);
    if (
      event.type === 'checkout.session.completed' &&
      userId &&
      (tier === 'PRO' || tier === 'FAMILY' || tier === 'ADVISOR')
    ) {
      const customerId = stringValue(object['customer']);
      const periodEnd = readEpochDate(object['current_period_end']);
      await prisma.subscription.upsert({
        where: { userId },
        create: {
          userId,
          tier,
          status: 'ACTIVE',
          ...(customerId ? { stripeCustomerId: customerId } : {}),
          ...(periodEnd ? { currentPeriodEnd: periodEnd } : {}),
          isBetaAllAccess: false,
        },
        update: {
          tier,
          status: 'ACTIVE',
          ...(customerId ? { stripeCustomerId: customerId } : {}),
          ...(periodEnd ? { currentPeriodEnd: periodEnd } : {}),
          isBetaAllAccess: false,
        },
      });
    }

    return true;
  }

  if (event.type === 'checkout.session.expired' || event.type === 'payment_intent.payment_failed') {
    if (donationId) {
      await prisma.donation.updateMany({
        where: { id: donationId, status: 'PENDING' },
        data: { status: 'FAILED' },
      });
    }
    return true;
  }

  if (
    event.type === 'customer.subscription.deleted' ||
    event.type === 'customer.subscription.updated'
  ) {
    const userId = stringValue(metadata['userId']);
    const tier = stringValue(metadata['tier']);
    if (!userId) return true;

    const active = event.type === 'customer.subscription.updated' && object['status'] === 'active';
    const periodEnd = readEpochDate(object['current_period_end']);
    await prisma.subscription.updateMany({
      where: { userId },
      data: {
        status: active ? 'ACTIVE' : 'CANCELED',
        ...(tier === 'PRO' || tier === 'FAMILY' || tier === 'ADVISOR' ? { tier } : {}),
        ...(periodEnd ? { currentPeriodEnd: periodEnd } : {}),
      },
    });
    if (!active) {
      // Early-Bird is a lifetime discount only while its associated subscription remains active.
      await prisma.user.updateMany({
        where: { id: userId, earlyBirdClaimedAt: { not: null }, earlyBirdCanceledAt: null },
        data: { earlyBirdCanceledAt: new Date() },
      });
    }
    return true;
  }

  return false;
}

/** POST /api/donate/create — creates a pending donation and a mock checkout session. */
billingRouter.post(
  '/donate/create',
  authMiddleware,
  validateRequest({ body: donationBodySchema }),
  async (req, res, next) => {
    const prisma = getPrismaClient();
    const userId = req.user!.id;
    const { amountTHB: rawAmount, message } = req.body as DonationBody;
    const amountTHB = new BillingDecimal(rawAmount)
      .toDecimalPlaces(2, BillingDecimal.ROUND_HALF_UP)
      .toFixed(2);

    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { id: true, email: true, isBetaAllAccess: true },
      });
      if (!user) {
        throw new AppError(404, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
      }

      const existingSubscription = await prisma.subscription.findUnique({
        where: { userId },
      });
      const donation = await prisma.donation.create({
        data: {
          userId,
          amountTHB,
          currency: 'THB',
          status: 'PENDING',
          ...(message ? { message } : {}),
        },
      });

      let checkout: Awaited<ReturnType<typeof stripeService.createDonationCheckout>>;
      try {
        checkout = await stripeService.createDonationCheckout({
          userId,
          donationId: donation.id,
          amountTHB,
          customerId: existingSubscription?.stripeCustomerId ?? undefined,
          ...(message ? { message } : {}),
        });
      } catch (error) {
        await prisma.donation.update({
          where: { id: donation.id },
          data: { status: 'FAILED' },
        });
        throw error;
      }

      const updatedDonation = await prisma.donation.update({
        where: { id: donation.id },
        data: { stripePaymentId: checkout.paymentIntentId },
      });

      await prisma.subscription.upsert({
        where: { userId },
        create: {
          userId,
          tier: 'FREE',
          status: isOpenBetaMode() ? 'BETA_ALL_ACCESS' : 'CANCELED',
          stripeCustomerId: checkout.customerId,
          isBetaAllAccess: isOpenBetaMode() || user.isBetaAllAccess,
        },
        update: existingSubscription?.stripeCustomerId
          ? {}
          : { stripeCustomerId: checkout.customerId },
      });

      res.status(201).json({
        donation: {
          id: updatedDonation.id,
          userId: updatedDonation.userId,
          amountTHB: updatedDonation.amountTHB,
          currency: updatedDonation.currency,
          stripePaymentId: updatedDonation.stripePaymentId,
          status: updatedDonation.status,
          message: updatedDonation.message,
          createdAt: updatedDonation.createdAt.toISOString(),
        },
        checkout,
      });
    } catch (error) {
      next(error);
    }
  }
);

/** POST /api/billing/portal — creates a mock Stripe customer portal session. */
billingRouter.post('/billing/portal', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const userId = req.user!.id;
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true, isBetaAllAccess: true },
    });
    if (!user) {
      throw new AppError(404, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
    }

    const existingSubscription = await prisma.subscription.findUnique({
      where: { userId },
    });
    const portal = await stripeService.createCustomerPortalSession({
      userId,
      email: user.email,
      customerId: existingSubscription?.stripeCustomerId ?? undefined,
    });

    await prisma.subscription.upsert({
      where: { userId },
      create: {
        userId,
        tier: 'FREE',
        status: isOpenBetaMode() ? 'BETA_ALL_ACCESS' : 'CANCELED',
        stripeCustomerId: portal.customerId,
        isBetaAllAccess: isOpenBetaMode() || user.isBetaAllAccess,
      },
      update: existingSubscription?.stripeCustomerId
        ? {}
        : { stripeCustomerId: portal.customerId },
    });

    res.status(200).json({ portal });
  } catch (error) {
    next(error);
  }
});

/** GET /api/billing/pricing — public, non-transactional pricing catalog; authenticated users get personalized Early-Bird state. */
billingRouter.get('/billing/pricing', optionalAuthMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    let isBetaUser = isOpenBetaMode();
    let earlyBirdClaimed = false;
    let earlyBirdCanceled = false;

    if (req.user) {
      const [user, subscription] = await Promise.all([
        prisma.user.findUnique({
          where: { id: req.user.id },
          select: {
            isBetaAllAccess: true,
            earlyBirdClaimedAt: true,
            earlyBirdCanceledAt: true,
          },
        }),
        prisma.subscription.findUnique({
          where: { userId: req.user.id },
          select: { isBetaAllAccess: true },
        }),
      ]);

      if (!user) {
        throw new AppError(404, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
      }
      isBetaUser = Boolean(isOpenBetaMode() || user.isBetaAllAccess || subscription?.isBetaAllAccess);
      earlyBirdClaimed = Boolean(user.earlyBirdClaimedAt);
      earlyBirdCanceled = Boolean(user.earlyBirdCanceledAt);
    }

    res.status(200).json({
      openBeta: isOpenBetaMode(),
      chargesEnabled: false,
      pricing: getPublicPricingCatalog(isBetaUser, new Date(), {
        earlyBirdClaimed,
        earlyBirdCanceled,
      }),
    });
  } catch (error) {
    next(error);
  }
});

/** GET /api/billing/community — baseline plus successful database donations only. */
billingRouter.get('/billing/community', async (_req, res, next) => {
  try {
    res.status(200).json(await getCommunityFundraisingStats());
  } catch (error) {
    next(error);
  }
});

/** GET /api/billing/early-bird/status — personalized claim, donor reward, and deferred trial state. */
billingRouter.get('/billing/early-bird/status', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const userId = req.user!.id;
    const [user, subscription] = await Promise.all([
      prisma.user.findUnique({
        where: { id: userId },
        select: {
          isBetaAllAccess: true,
          earlyBirdClaimedAt: true,
          earlyBirdDiscountPercent: true,
          earlyBirdCanceledAt: true,
          proTrialRequestedAt: true,
          proTrialDurationDays: true,
        },
      }),
      prisma.subscription.findUnique({
        where: { userId },
        select: { isBetaAllAccess: true },
      }),
    ]);

    if (!user) {
      throw new AppError(404, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
    }

    const now = new Date();
    const isBetaUser = Boolean(isOpenBetaMode() || user.isBetaAllAccess || subscription?.isBetaAllAccess);
    const claimed = Boolean(user.earlyBirdClaimedAt);
    const canceled = Boolean(user.earlyBirdCanceledAt);
    const canClaim = Boolean(isBetaUser && isEarlyBirdWindowOpen(now) && !claimed && !canceled);
    const earlyBirdEligible = Boolean((claimed && !canceled) || canClaim);
    const donorProYear = await getUserDonationRewardStatus(userId);
    const trialReserved = Boolean(user.proTrialRequestedAt);

    res.status(200).json({
      earlyBird: {
        eligible: earlyBirdEligible,
        canClaim,
        claimed,
        canceled,
        discountActive: earlyBirdEligible,
        discountPercentage: user.earlyBirdDiscountPercent ?? EARLY_BIRD_DISCOUNT.discountPercentage,
        validUntil: EARLY_BIRD_DISCOUNT.validUntil,
        lifetimeDiscount: EARLY_BIRD_DISCOUNT.lifetimeDiscount,
        endsOnCancellation: EARLY_BIRD_DISCOUNT.endsOnCancellation,
        claimedAt: user.earlyBirdClaimedAt?.toISOString() ?? null,
        canceledAt: user.earlyBirdCanceledAt?.toISOString() ?? null,
      },
      donorProYear: {
        ...donorProYear,
        thresholdTHB: DONOR_PRO_YEAR_THRESHOLD_THB,
        durationMonths: DONOR_PRO_YEAR_DURATION_MONTHS,
      },
      trial: {
        reserved: trialReserved,
        status: trialReserved ? 'RESERVED_FOR_SUBSCRIPTION_LAUNCH' : 'NOT_REQUESTED',
        durationDays: user.proTrialDurationDays ?? 14,
        requestedAt: user.proTrialRequestedAt?.toISOString() ?? null,
        startsWhen: 'SUBSCRIPTION_LAUNCH',
        chargesEnabled: false,
      },
    });
  } catch (error) {
    next(error);
  }
});

/** POST /api/billing/early-bird/claim — records one eligible Beta User claim; never starts checkout. */
billingRouter.post('/billing/early-bird/claim', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const userId = req.user!.id;
    const [user, subscription] = await Promise.all([
      prisma.user.findUnique({
        where: { id: userId },
        select: {
          isBetaAllAccess: true,
          earlyBirdClaimedAt: true,
          earlyBirdDiscountPercent: true,
          earlyBirdCanceledAt: true,
        },
      }),
      prisma.subscription.findUnique({
        where: { userId },
        select: { isBetaAllAccess: true },
      }),
    ]);

    if (!user) {
      throw new AppError(404, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
    }

    const hasClaimed = Boolean(user.earlyBirdClaimedAt);
    const canceled = Boolean(user.earlyBirdCanceledAt);
    if (hasClaimed) {
      res.status(200).json({
        earlyBird: {
          claimed: true,
          alreadyClaimed: true,
          discountActive: !canceled,
          canceled,
          discountPercentage: user.earlyBirdDiscountPercent ?? EARLY_BIRD_DISCOUNT.discountPercentage,
          validUntil: EARLY_BIRD_DISCOUNT.validUntil,
          lifetimeDiscount: EARLY_BIRD_DISCOUNT.lifetimeDiscount,
          endsOnCancellation: EARLY_BIRD_DISCOUNT.endsOnCancellation,
          claimedAt: user.earlyBirdClaimedAt?.toISOString() ?? null,
        },
        chargesEnabled: false,
      });
      return;
    }

    const isBetaUser = Boolean(isOpenBetaMode() || user.isBetaAllAccess || subscription?.isBetaAllAccess);
    if (!isBetaUser) {
      throw new AppError(403, 'EARLY_BIRD_BETA_USERS_ONLY', 'The Early-Bird offer is available to Beta Users only.');
    }
    if (!isEarlyBirdWindowOpen()) {
      throw new AppError(410, 'EARLY_BIRD_EXPIRED', 'The Early-Bird claim period has ended.');
    }

    const claimedAt = new Date();
    await prisma.user.updateMany({
      where: { id: userId, earlyBirdClaimedAt: null },
      data: {
        earlyBirdClaimedAt: claimedAt,
        earlyBirdDiscountPercent: EARLY_BIRD_DISCOUNT.discountPercentage,
      },
    });
    const refreshed = await prisma.user.findUnique({
      where: { id: userId },
      select: { earlyBirdClaimedAt: true, earlyBirdDiscountPercent: true },
    });

    res.status(201).json({
      earlyBird: {
        claimed: true,
        alreadyClaimed: false,
        discountActive: true,
        canceled: false,
        discountPercentage: refreshed?.earlyBirdDiscountPercent ?? EARLY_BIRD_DISCOUNT.discountPercentage,
        validUntil: EARLY_BIRD_DISCOUNT.validUntil,
        lifetimeDiscount: EARLY_BIRD_DISCOUNT.lifetimeDiscount,
        endsOnCancellation: EARLY_BIRD_DISCOUNT.endsOnCancellation,
        claimedAt: refreshed?.earlyBirdClaimedAt?.toISOString() ?? claimedAt.toISOString(),
      },
      chargesEnabled: false,
    });
  } catch (error) {
    next(error);
  }
});

/** POST /api/billing/trial/reserve — stores a no-charge 14-day trial reservation for launch. */
billingRouter.post('/billing/trial/reserve', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const userId = req.user!.id;
    const [user, subscription] = await Promise.all([
      prisma.user.findUnique({
        where: { id: userId },
        select: { proTrialRequestedAt: true, proTrialDurationDays: true },
      }),
      prisma.subscription.findUnique({
        where: { userId },
        select: { tier: true, status: true },
      }),
    ]);

    if (!user) {
      throw new AppError(404, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
    }
    if (
      subscription?.status === 'ACTIVE' &&
      subscription.tier !== 'FREE'
    ) {
      throw new AppError(409, 'TRIAL_NOT_AVAILABLE', 'An active paid subscription already exists.');
    }

    if (user.proTrialRequestedAt) {
      res.status(200).json({
        trial: {
          reserved: true,
          status: 'RESERVED_FOR_SUBSCRIPTION_LAUNCH',
          durationDays: user.proTrialDurationDays ?? 14,
          requestedAt: user.proTrialRequestedAt.toISOString(),
          startsWhen: 'SUBSCRIPTION_LAUNCH',
          chargesEnabled: false,
        },
      });
      return;
    }

    const requestedAt = new Date();
    await prisma.user.updateMany({
      where: { id: userId, proTrialRequestedAt: null },
      data: { proTrialRequestedAt: requestedAt, proTrialDurationDays: 14 },
    });
    const refreshed = await prisma.user.findUnique({
      where: { id: userId },
      select: { proTrialRequestedAt: true, proTrialDurationDays: true },
    });

    res.status(201).json({
      trial: {
        reserved: true,
        status: 'RESERVED_FOR_SUBSCRIPTION_LAUNCH',
        durationDays: refreshed?.proTrialDurationDays ?? 14,
        requestedAt: refreshed?.proTrialRequestedAt?.toISOString() ?? requestedAt.toISOString(),
        startsWhen: 'SUBSCRIPTION_LAUNCH',
        chargesEnabled: false,
      },
    });
  } catch (error) {
    next(error);
  }
});

/** GET /api/billing/status — publicly reports the beta-wide entitlement while beta is enabled. */
billingRouter.get(
  '/billing/status',
  (req, res, next) => {
    if (isOpenBetaMode()) {
      next();
      return;
    }
    authMiddleware(req, res, next);
  },
  async (req, res, next) => {
    if (isOpenBetaMode()) {
      res.status(200).json({
        planName: 'Open Beta (All Access)',
        tier: 'FREE',
        status: 'BETA_ALL_ACCESS',
        isBetaAllAccess: true,
        currentPeriodEnd: null,
        access: 'ALL_FEATURES',
        entitlements: getTierEntitlements('ADVISOR'),
        pricing: getPublicPricingCatalog(true),
        chargesEnabled: false,
      });
      return;
    }

    try {
      const prisma = getPrismaClient();
      const userId = req.user!.id;
      const [user, subscription] = await Promise.all([
        prisma.user.findUnique({
          where: { id: userId },
          select: {
            isBetaAllAccess: true,
            earlyBirdClaimedAt: true,
            earlyBirdCanceledAt: true,
          },
        }),
        prisma.subscription.findUnique({ where: { userId } }),
      ]);

      if (!user) {
        throw new AppError(404, 'USER_NOT_FOUND', 'The authenticated account no longer exists.');
      }

      const isBetaAllAccess = Boolean(user.isBetaAllAccess || subscription?.isBetaAllAccess);
      const hasCurrentPaidPeriod = Boolean(
        subscription?.status === 'CANCELED' &&
          subscription.currentPeriodEnd &&
          subscription.currentPeriodEnd.getTime() > Date.now()
      );
      const tierForEntitlements: TierId = isBetaAllAccess
        ? 'ADVISOR'
        : subscription &&
            (subscription.status === 'ACTIVE' || hasCurrentPaidPeriod) &&
            isKnownTier(subscription.tier)
          ? subscription.tier
          : 'FREE';
      res.status(200).json({
        planName: isBetaAllAccess
          ? 'Open Beta (All Access)'
          : tierForEntitlements === 'FREE'
            ? 'Free Plan'
            : `${tierForEntitlements} Plan`,
        tier: subscription?.tier ?? 'FREE',
        status: isBetaAllAccess
          ? 'BETA_ALL_ACCESS'
          : (subscription?.status ?? 'FREE'),
        isBetaAllAccess,
        currentPeriodEnd: subscription?.currentPeriodEnd?.toISOString() ?? null,
        access: isBetaAllAccess
          ? 'ALL_FEATURES'
          : tierForEntitlements === 'FREE'
            ? 'FREE_FEATURES'
            : 'PLAN_FEATURES',
        entitlements: getTierEntitlements(tierForEntitlements),
        pricing: getPublicPricingCatalog(isBetaAllAccess, new Date(), {
          earlyBirdClaimed: Boolean(user.earlyBirdClaimedAt),
          earlyBirdCanceled: Boolean(user.earlyBirdCanceledAt),
        }),
        chargesEnabled: false,
      });
    } catch (error) {
      next(error);
    }
  }
);

/** POST /api/webhooks/stripe — verifies the raw request signature before applying events. */
billingRouter.post('/webhooks/stripe', async (req, res, next) => {
  const rawBody = (req as RequestWithRawBody).rawBody;
  const signature = req.get('stripe-signature') ?? '';
  if (!rawBody) {
    next(new AppError(400, 'MISSING_RAW_WEBHOOK_BODY', 'Stripe webhook requires its raw request body.'));
    return;
  }

  try {
    const event = stripeService.constructWebhookEvent(rawBody, signature);
    const handled = await applyStripeEvent(event);
    res.status(200).json({ received: true, eventId: event.id, handled });
  } catch {
    next(new AppError(400, 'INVALID_STRIPE_WEBHOOK', 'Stripe webhook signature or payload is invalid.'));
  }
});
