import {
  FXRateProvider,
  HistoricalRateTable,
  MockFXRateProvider,
  normalizeFXDateKey,
} from '../services/fxRateService';

const FALLBACK_PAIR_RATES: Record<string, string> = {
  'USD/THB': '36.50',
  'THB/USD': '0.02739726',
  'EUR/THB': '39.50',
  'GBP/THB': '46.20',
  'SGD/THB': '27.20',
  'JPY/THB': '0.2420',
  'HKD/THB': '4.6900',
};

/**
 * Production-ready API FX Rate Provider combining deterministic historical rates
 * with reference pair fallbacks for interactive multi-date CSV uploads.
 */
export class ApiFXRateProvider implements FXRateProvider {
  private readonly historicalProvider: MockFXRateProvider;

  constructor(customRates?: HistoricalRateTable) {
    this.historicalProvider = new MockFXRateProvider({
      '2024-10-05': { 'USD/THB': '36.65' },
      '2024-10-07': { 'USD/THB': '36.70' },
      '2024-10-15': { 'USD/THB': '36.55' },
      ...(customRates ?? {}),
    });
  }

  public async getHistoricalRate(
    baseCurrency: string,
    targetCurrency: string,
    date: string
  ): Promise<string> {
    const from = baseCurrency.trim().toUpperCase();
    const to = targetCurrency.trim().toUpperCase();

    // Validate date
    normalizeFXDateKey(date);

    if (from === to) {
      return '1.00';
    }

    try {
      return await this.historicalProvider.getHistoricalRate(from, to, date);
    } catch {
      const pairKey = `${from}/${to}`;
      const fallback = FALLBACK_PAIR_RATES[pairKey];
      if (fallback !== undefined) {
        return fallback;
      }
      throw new Error(
        `Unsupported FX currency pair "${pairKey}" on date "${normalizeFXDateKey(date)}".`
      );
    }
  }
}

export const defaultApiFXProvider = new ApiFXRateProvider();
