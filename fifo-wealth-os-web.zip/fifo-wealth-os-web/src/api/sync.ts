import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { validateRequest } from '../middleware/validationMiddleware';
import { encryptData } from '../services/encryptionService';
import { triggerManualSync } from '../services/manualSyncEngine';
import { BrokerConnectionPublic, BrokerSyncStatus } from '../types/sync';
import { requireOwnedPortfolio } from './routes/portfolioRoutes';

export const syncRouter = Router();

const connectIbkrBodySchema = z.object({
  flexQueryToken: z
    .string()
    .trim()
    .min(6, 'Flex Query Token must be at least 6 characters.'),
  flexQueryId: z
    .string()
    .trim()
    .min(3, 'Flex Query ID must be at least 3 characters.'),
  portfolioId: z.string().uuid().optional(),
});

const triggerSyncBodySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  delayMs: z.coerce.number().int().min(0).max(5000).optional(),
});

function toPublicConnection(
  row: {
    id: string;
    portfolioId: string | null;
    flexQueryId: string;
    status: string;
    lastSyncedAt: Date | null;
    createdAt: Date;
  } | null
): BrokerConnectionPublic {
  if (!row || row.status === 'DISCONNECTED') {
    return {
      id: null,
      brokerName: 'IBKR',
      flexQueryId: null,
      portfolioId: null,
      status: 'DISCONNECTED',
      connected: false,
      lastSyncedAt: null,
      createdAt: null,
      readOnly: true,
      encryption: 'AES-256-GCM',
    };
  }

  return {
    id: row.id,
    brokerName: 'IBKR',
    flexQueryId: row.flexQueryId,
    portfolioId: row.portfolioId,
    status: row.status as BrokerSyncStatus,
    connected: row.status === 'CONNECTED' || row.status === 'SYNCING',
    lastSyncedAt: row.lastSyncedAt ? row.lastSyncedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    readOnly: true,
    encryption: 'AES-256-GCM',
  };
}

/**
 * POST /api/sync/ibkr/connect
 * Encrypts Read-Only IBKR Flex credentials via AES-256-GCM before storing in DB.
 * Security Rule: Never logs or returns `flexQueryToken` or `flexQueryTokenEncrypted`.
 */
syncRouter.post(
  '/ibkr/connect',
  authMiddleware,
  validateRequest({ body: connectIbkrBodySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof connectIbkrBodySchema>;
      }).body;

      if (body.portfolioId) {
        await requireOwnedPortfolio(body.portfolioId, req.user!.id);
      }

      const encryptedToken = encryptData(body.flexQueryToken);

      const saved = await prisma.brokerConnection.upsert({
        where: {
          userId_brokerName: {
            userId: req.user!.id,
            brokerName: 'IBKR',
          },
        },
        create: {
          userId: req.user!.id,
          portfolioId: body.portfolioId ?? null,
          brokerName: 'IBKR',
          flexQueryTokenEncrypted: encryptedToken,
          flexQueryId: body.flexQueryId,
          status: 'CONNECTED',
        },
        update: {
          portfolioId: body.portfolioId ?? undefined,
          flexQueryTokenEncrypted: encryptedToken,
          flexQueryId: body.flexQueryId,
          status: 'CONNECTED',
        },
      });

      res.status(201).json({
        connection: toPublicConnection(saved),
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/sync/ibkr/trigger
 * Triggers Manual On-Demand Read-Only Sync from IBKR Flex Web Service.
 */
syncRouter.post(
  '/ibkr/trigger',
  authMiddleware,
  validateRequest({ body: triggerSyncBodySchema }),
  async (req, res, next) => {
    try {
      const body = (res.locals['validated'] as {
        body: z.infer<typeof triggerSyncBodySchema>;
      }).body;

      const result = await triggerManualSync(req.user!.id, {
        portfolioId: body.portfolioId,
        artificialDelayMs: body.delayMs,
      });

      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/sync/status
 * Returns sanitized Read-Only connection status & `lastSyncedAt` timestamp.
 */
syncRouter.get('/status', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const row = await prisma.brokerConnection.findUnique({
      where: {
        userId_brokerName: {
          userId: req.user!.id,
          brokerName: 'IBKR',
        },
      },
    });

    res.status(200).json(toPublicConnection(row));
  } catch (err) {
    next(err);
  }
});

/**
 * DELETE /api/sync/ibkr/disconnect
 * Permanently deletes BrokerConnection & encrypted credentials (PDPA / GDPR Right to be Forgotten).
 */
syncRouter.delete('/ibkr/disconnect', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    await prisma.brokerConnection.deleteMany({
      where: {
        userId: req.user!.id,
        brokerName: 'IBKR',
      },
    });

    res.status(200).json({
      disconnected: true,
      credentialsDeleted: true,
      connection: toPublicConnection(null),
    });
  } catch (err) {
    next(err);
  }
});

export default syncRouter;
