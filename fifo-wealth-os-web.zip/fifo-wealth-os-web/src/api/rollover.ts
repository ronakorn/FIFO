import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  buildRolloverHistory,
  calculateRolloverSpreadAnalytics,
  executeAtomicContractRollover,
  FUTURES_CONTRACT_CATALOG,
  scanExpiringFuturesContracts,
} from '../services/contractRolloverEngine';
import {
  calculateGoldFIFO,
  GoldDecimal,
  toCleanGoldDecimal,
} from '../services/goldEngine';
import { GoldPurity, GoldTransaction, GoldWeightUnit } from '../types/gold';
import {
  ContractRolloverOverview,
  DerivativesContractExtensionDTO,
  RolloverLegAction,
} from '../types/rollover';
import { requireOwnedPortfolio } from './routes/portfolioRoutes';

export const rolloverRouter = Router();

const DEFAULT_AS_OF_DATE = '2026-10-26'; // Current local date in Asia/Bangkok
const DEFAULT_XAU_USD_SPOT = '2740.00';
const DEFAULT_USD_THB_RATE = '35.60';
const DEFAULT_GTA_965_SELL_THB = '46450.00';

const weightUnitEnum = z.enum(['THAI_BAHT', 'GRAM', 'TROY_OUNCE']);
const purityEnum = z.enum(['96.5', '99.99', '99.9', '99.5']);

const overviewQuerySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  asOfDate: z.string().optional(),
  usdThbRate: z.string().optional(),
  seedIfEmpty: z.enum(['true', 'false']).optional(),
});

const rolloverPayloadSchema = z.object({
  portfolioId: z.string().uuid(),
  date: z.string().trim().min(8).default(DEFAULT_AS_OF_DATE),
  frontSymbol: z.string().trim().min(2).max(24),
  frontContractMonth: z.string().trim().min(2).max(12),
  frontExpirationDate: z.string().trim().min(8),
  frontClosePriceUSD: z.string().trim().min(1),
  closeCommissionUSD: z.string().trim().default('4.00'),
  backSymbol: z.string().trim().min(2).max(24),
  backContractMonth: z.string().trim().min(2).max(12),
  backExpirationDate: z.string().trim().min(8),
  backOpenPriceUSD: z.string().trim().min(1),
  openCommissionUSD: z.string().trim().default('4.00'),
  weight: z.string().trim().min(1),
  weightUnit: weightUnitEnum.default('TROY_OUNCE'),
  purity: purityEnum.default('99.5'),
  fxRateUSDTHB: z.string().trim().default(DEFAULT_USD_THB_RATE),
  allowAutoSeedWhenEmpty: z.boolean().optional(),
});

function buildDefaultSeedFuturesLedger(portfolioId: string): {
  transactions: GoldTransaction[];
  extensions: Map<string, DerivativesContractExtensionDTO>;
} {
  const createdAt = new Date('2026-09-25T09:00:00.000Z');
  const histRollGroupId = 'seed-roll-group-u26-to-v26';

  const txs: GoldTransaction[] = [
    // Historical original open on September contract GOU26
    {
      id: 'seed-fut-gou26-open',
      portfolioId,
      date: '2026-07-15',
      symbol: 'GOU26',
      assetSubclass: 'GOLD_ONLINE_FUTURES',
      weight: '3.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.5',
      spotPricePerUnit: '2490.00',
      premiumPerUnit: '0.00',
      commission: '4.50',
      totalCost: '7474.50',
      fxRateAtPurchase: '34.40',
      type: 'BUY',
      createdAt,
    },
    // Historical Rollover Close Leg (GOU26 closed on 2026-09-25)
    {
      id: 'seed-fut-gou26-roll-close',
      portfolioId,
      date: '2026-09-25',
      symbol: 'GOU26',
      assetSubclass: 'GOLD_ONLINE_FUTURES',
      weight: '3.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.5',
      spotPricePerUnit: '2612.00',
      premiumPerUnit: '0.00',
      commission: '4.50',
      totalCost: '7831.50',
      fxRateAtPurchase: '34.80',
      type: 'SELL',
      createdAt,
    },
    // Historical Rollover Open Leg -> GOV26 (Expiring 2026-10-29 -> 3 days from 2026-10-26!)
    {
      id: 'seed-fut-gov26-roll-open',
      portfolioId,
      date: '2026-09-25',
      symbol: 'GOV26',
      assetSubclass: 'GOLD_ONLINE_FUTURES',
      weight: '3.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.5',
      spotPricePerUnit: '2626.00', // +14.00 USD Contango spread
      premiumPerUnit: '0.00',
      commission: '4.50',
      totalCost: '7882.50',
      fxRateAtPurchase: '34.80',
      type: 'BUY',
      createdAt,
    },
    // Second active position: GCX26 (Expiring 2026-11-02 -> 7 days from 2026-10-26!)
    {
      id: 'seed-fut-gcx26-open',
      portfolioId,
      date: '2026-10-02',
      symbol: 'GCX26',
      assetSubclass: 'GOLD_ONLINE_FUTURES',
      weight: '2.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.5',
      spotPricePerUnit: '2665.00',
      premiumPerUnit: '0.00',
      commission: '4.00',
      totalCost: '5334.00',
      fxRateAtPurchase: '35.10',
      type: 'BUY',
      createdAt,
    },
  ];

  const extensions = new Map<string, DerivativesContractExtensionDTO>([
    [
      'seed-fut-gou26-roll-close',
      {
        id: 'ext-seed-close-1',
        transactionId: 'seed-fut-gou26-roll-close',
        contractMonth: 'U26',
        expirationDate: '2026-09-29',
        legAction: 'CLOSE_LONG',
        isRollover: true,
        rolloverGroupId: histRollGroupId,
        rolloverSpread: '14.00',
      },
    ],
    [
      'seed-fut-gov26-roll-open',
      {
        id: 'ext-seed-open-1',
        transactionId: 'seed-fut-gov26-roll-open',
        contractMonth: 'V26',
        expirationDate: '2026-10-29',
        legAction: 'OPEN_LONG',
        isRollover: true,
        rolloverGroupId: histRollGroupId,
        rolloverSpread: '14.00',
      },
    ],
    [
      'seed-fut-gcx26-open',
      {
        id: 'ext-seed-open-2',
        transactionId: 'seed-fut-gcx26-open',
        contractMonth: 'X26',
        expirationDate: '2026-11-02',
        legAction: 'OPEN_LONG',
        isRollover: false,
        rolloverGroupId: null,
        rolloverSpread: null,
      },
    ],
  ]);

  return { transactions: txs, extensions };
}

async function resolveOwnedPortfolioId(
  userId: string,
  requestedPortfolioId?: string
): Promise<string> {
  const prisma = getPrismaClient();
  if (requestedPortfolioId) {
    await requireOwnedPortfolio(requestedPortfolioId, userId);
    return requestedPortfolioId;
  }

  const first = await prisma.portfolio.findFirst({
    where: { userId },
    orderBy: { createdAt: 'asc' },
  });
  if (first) return first.id;

  const created = await prisma.portfolio.create({
    data: {
      userId,
      name: 'Multi-Asset & Gold Derivatives Portfolio',
      baseCurrency: 'THB',
    },
  });
  return created.id;
}

async function loadPortfolioGoldAndExtensions(
  portfolioId: string,
  seedIfEmpty: boolean
): Promise<{
  transactions: GoldTransaction[];
  extensions: Map<string, DerivativesContractExtensionDTO>;
}> {
  const prisma = getPrismaClient();
  const rows = await prisma.goldTransactionRecord.findMany({
    where: { portfolioId },
    include: { derivativesExt: true },
    orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
  });

  if (rows.length === 0 && seedIfEmpty) {
    return buildDefaultSeedFuturesLedger(portfolioId);
  }

  const transactions: GoldTransaction[] = [];
  const extensions = new Map<string, DerivativesContractExtensionDTO>();

  for (const r of rows) {
    transactions.push({
      id: r.id,
      portfolioId: r.portfolioId,
      date: r.date,
      symbol: r.symbol,
      assetSubclass: r.assetSubclass as GoldTransaction['assetSubclass'],
      weight: r.weight,
      weightUnit: r.weightUnit as GoldWeightUnit,
      purity: r.purity as GoldPurity,
      spotPricePerUnit: r.spotPricePerUnit,
      premiumPerUnit: r.premiumPerUnit,
      commission: r.commission,
      totalCost: r.totalCost,
      fxRateAtPurchase: r.fxRateAtPurchase,
      type: r.type as 'BUY' | 'SELL',
      createdAt: r.createdAt,
    });

    if (r.derivativesExt) {
      extensions.set(r.id, {
        id: r.derivativesExt.id,
        transactionId: r.derivativesExt.transactionId,
        contractMonth: r.derivativesExt.contractMonth,
        expirationDate: r.derivativesExt.expirationDate,
        legAction: r.derivativesExt.legAction as RolloverLegAction,
        isRollover: r.derivativesExt.isRollover,
        rolloverGroupId: r.derivativesExt.rolloverGroupId,
        rolloverSpread: r.derivativesExt.rolloverSpread,
      });
    }
  }

  return { transactions, extensions };
}

/**
 * GET /api/gold/rollover/overview
 * Returns Contract Expiry Schedule, Proactive 7d/3d/1d Alerts, Rollover History,
 * and Cumulative Contango/Backwardation Net Rollover Impact.
 */
rolloverRouter.get(
  '/overview',
  authMiddleware,
  validateRequest({ query: overviewQuerySchema }),
  async (req, res, next) => {
    try {
      const q = (res.locals['validated'] as {
        query: z.infer<typeof overviewQuerySchema>;
      }).query;

      const portfolioId = await resolveOwnedPortfolioId(
        req.user!.id,
        q.portfolioId
      );
      const asOfDate = q.asOfDate ?? DEFAULT_AS_OF_DATE;
      const usdThbRate = q.usdThbRate ?? DEFAULT_USD_THB_RATE;
      const seedIfEmpty = q.seedIfEmpty !== 'false';

      const { transactions, extensions } = await loadPortfolioGoldAndExtensions(
        portfolioId,
        seedIfEmpty
      );

      const activeAlerts = scanExpiringFuturesContracts({
        transactions,
        extensionsByTxId: extensions,
        asOfDate,
        xauUsdSpot: DEFAULT_XAU_USD_SPOT,
        usdThbRate,
        gtaGold965SellTHB: DEFAULT_GTA_965_SELL_THB,
      });

      const rolloverHistory = buildRolloverHistory({
        transactions,
        extensionsByTxId: extensions,
        xauUsdSpot: DEFAULT_XAU_USD_SPOT,
        usdThbRate,
        gtaGold965SellTHB: DEFAULT_GTA_965_SELL_THB,
      });

      const fifo = calculateGoldFIFO(transactions, {
        xauUsdSpot: DEFAULT_XAU_USD_SPOT,
        usdThbRate,
        gtaGold965SellTHB: DEFAULT_GTA_965_SELL_THB,
      });

      const cumulativeSpreadTHB = rolloverHistory.reduce(
        (acc, h) => acc.plus(toCleanGoldDecimal(h.spreadCostTHB)),
        new GoldDecimal(0)
      );
      const cumulativeRealizedTHB = rolloverHistory.reduce(
        (acc, h) => acc.plus(toCleanGoldDecimal(h.realizedGLClosedLegTHB)),
        new GoldDecimal(0)
      );

      const mktValTHB = toCleanGoldDecimal(fifo.totalMarketValueTHB);
      const netImpactPct = mktValTHB.gt(0)
        ? cumulativeSpreadTHB.negated().dividedBy(mktValTHB)
        : new GoldDecimal(0);

      const response: ContractRolloverOverview = {
        portfolioId,
        asOfDate,
        usdThbRate: toCleanGoldDecimal(usdThbRate).toFixed(4),
        contractCatalog: FUTURES_CONTRACT_CATALOG,
        activeAlerts,
        rolloverHistory,
        summary: {
          activeFuturesContractsCount: activeAlerts.length,
          urgentExpiringCount: activeAlerts.filter((a) => a.daysToExpiry <= 7)
            .length,
          totalRolloversExecuted: rolloverHistory.length,
          cumulativeSpreadCostTHB: cumulativeSpreadTHB.toFixed(2),
          cumulativeRealizedOnRolloversTHB: cumulativeRealizedTHB.toFixed(2),
          netRolloverImpactPct: netImpactPct.toFixed(4),
        },
      };

      res.status(200).json(response);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/gold/rollover/preview
 * Dry-run calculator before executing an atomic rollover: computes Contango/Backwardation
 * spread cost, commissions, exact FIFO Realized PnL on Close Leg, and Open Leg Cost Basis.
 */
rolloverRouter.post(
  '/preview',
  authMiddleware,
  validateRequest({ body: rolloverPayloadSchema }),
  async (req, res, next) => {
    try {
      const body = (res.locals['validated'] as {
        body: z.infer<typeof rolloverPayloadSchema>;
      }).body;

      await requireOwnedPortfolio(body.portfolioId, req.user!.id);

      const { transactions } = await loadPortfolioGoldAndExtensions(
        body.portfolioId,
        Boolean(body.allowAutoSeedWhenEmpty)
      );

      try {
        const analytics = calculateRolloverSpreadAnalytics({
          existingTransactions: transactions,
          portfolioId: body.portfolioId,
          date: body.date,
          frontSymbol: body.frontSymbol,
          backSymbol: body.backSymbol,
          weight: body.weight,
          weightUnit: body.weightUnit,
          purity: body.purity,
          frontClosePriceUSD: body.frontClosePriceUSD,
          backOpenPriceUSD: body.backOpenPriceUSD,
          closeCommissionUSD: body.closeCommissionUSD,
          openCommissionUSD: body.openCommissionUSD,
          fxRateUSDTHB: body.fxRateUSDTHB,
        });
        res.status(200).json(analytics);
      } catch (err) {
        throw new AppError(
          400,
          'ROLLOVER_PREVIEW_ERROR',
          err instanceof Error ? err.message : 'Unable to preview rollover.'
        );
      }
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/gold/rollover/execute
 * Atomically executes CLOSE_LONG (Front-Month) + OPEN_LONG (Back-Month) + paired
 * `DerivativesContractExtension` records linked by `rolloverGroupId`.
 */
rolloverRouter.post(
  '/execute',
  authMiddleware,
  validateRequest({ body: rolloverPayloadSchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof rolloverPayloadSchema>;
      }).body;

      await requireOwnedPortfolio(body.portfolioId, req.user!.id);

      // Optional UI convenience: materialize seed futures ledger on first interactive rollover
      if (body.allowAutoSeedWhenEmpty) {
        const existingCount = await prisma.goldTransactionRecord.count({
          where: { portfolioId: body.portfolioId },
        });
        if (existingCount === 0) {
          const seed = buildDefaultSeedFuturesLedger(body.portfolioId);
          await prisma.$transaction(async (tx) => {
            for (const sTx of seed.transactions) {
              const created = await tx.goldTransactionRecord.create({
                data: {
                  portfolioId: body.portfolioId,
                  date: sTx.date,
                  symbol: sTx.symbol,
                  assetSubclass: sTx.assetSubclass,
                  weight: sTx.weight,
                  weightUnit: sTx.weightUnit,
                  purity: sTx.purity,
                  spotPricePerUnit: sTx.spotPricePerUnit,
                  premiumPerUnit: sTx.premiumPerUnit,
                  commission: sTx.commission,
                  totalCost: sTx.totalCost,
                  fxRateAtPurchase: sTx.fxRateAtPurchase,
                  type: sTx.type,
                },
              });
              const seedExt = seed.extensions.get(sTx.id);
              if (seedExt) {
                await tx.derivativesContractExtension.create({
                  data: {
                    transactionId: created.id,
                    contractMonth: seedExt.contractMonth,
                    expirationDate: seedExt.expirationDate,
                    legAction: seedExt.legAction,
                    isRollover: seedExt.isRollover,
                    rolloverGroupId: seedExt.rolloverGroupId,
                    rolloverSpread: seedExt.rolloverSpread,
                  },
                });
              }
            }
          });
        }
      }

      const result = await executeAtomicContractRollover({
        portfolioId: body.portfolioId,
        date: body.date,
        frontSymbol: body.frontSymbol,
        frontContractMonth: body.frontContractMonth,
        frontExpirationDate: body.frontExpirationDate,
        frontClosePriceUSD: body.frontClosePriceUSD,
        closeCommissionUSD: body.closeCommissionUSD,
        backSymbol: body.backSymbol,
        backContractMonth: body.backContractMonth,
        backExpirationDate: body.backExpirationDate,
        backOpenPriceUSD: body.backOpenPriceUSD,
        openCommissionUSD: body.openCommissionUSD,
        weight: body.weight,
        weightUnit: body.weightUnit,
        purity: body.purity,
        fxRateUSDTHB: body.fxRateUSDTHB,
      });

      res.status(201).json(result);
    } catch (err) {
      next(err);
    }
  }
);

export default rolloverRouter;
