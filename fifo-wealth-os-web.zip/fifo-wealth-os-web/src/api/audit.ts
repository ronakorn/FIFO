import { Router } from 'express';
import { z } from 'zod';
import { authMiddleware } from '../middleware/authMiddleware';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  AuditAction,
  AuditEntityType,
  getAuditLogsForUser,
} from '../services/auditLogger';

export const auditRouter = Router();

const listAuditQuerySchema = z.object({
  action: z.enum(['CREATE', 'UPDATE', 'DELETE']).optional(),
  entityType: z.enum(['GOLD_TRANSACTION', 'PORTFOLIO']).optional(),
  limit: z.coerce.number().int().min(1).max(500).optional(),
});

/**
 * GET /api/audit-logs
 * Returns the authenticated user's own Immutable Audit Trail (PDPA / GDPR Data Subject Access).
 */
auditRouter.get(
  '/',
  authMiddleware,
  validateRequest({ query: listAuditQuerySchema }),
  async (req, res, next) => {
    try {
      const q = (res.locals['validated'] as {
        query: z.infer<typeof listAuditQuerySchema>;
      }).query;

      const logs = await getAuditLogsForUser(req.user!.id, {
        action: q.action as AuditAction | undefined,
        entityType: q.entityType as AuditEntityType | undefined,
        limit: q.limit,
      });

      res.status(200).json({
        userId: req.user!.id,
        count: logs.length,
        immutable: true,
        complianceStandard: 'PDPA_TH_GDPR_READY',
        logs,
      });
    } catch (err) {
      next(err);
    }
  }
);

export default auditRouter;
