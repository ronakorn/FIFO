import Decimal from 'decimal.js';
import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import { mapPrismaTransactionToShared } from './mappers';
import { hydratePortfolioMetrics, requireOwnedPortfolio } from './routes/portfolioRoutes';

export const mobileRouter = Router();

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

const mobileTransactionsParamsSchema = z.object({
  portfolioId: z.string().trim().min(1).max(120),
});

const mobileTransactionsQuerySchema = z.object({
  cursor: z.string().trim().min(1).max(120).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(30),
  type: z.enum(['BUY', 'SELL', 'FEE']).optional(),
  symbol: z.string().trim().min(1).max(64).transform((value) => value.toUpperCase()).optional(),
});

/**
 * GET /api/mobile/dashboard-summary
 * Read-only mobile aggregate. Portfolio FIFO values are produced by the existing
 * portfolio hydration service; this endpoint only aggregates those server results.
 */
mobileRouter.get('/dashboard-summary', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const portfolioRows = await prisma.portfolio.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: 'desc' },
    });
    const portfolios = await Promise.all(portfolioRows.map(hydratePortfolioMetrics));
    const portfolioIds = portfolioRows.map((portfolio) => portfolio.id);

    const totals = portfolios.reduce(
      (accumulator, portfolio) => {
        const summary = portfolio.fifoSummary;
        return {
          marketValue: accumulator.marketValue.plus(new Dec(summary?.marketValueTHB ?? 0)),
          openCostBasis: accumulator.openCostBasis.plus(new Dec(summary?.openCostBasisTHB ?? 0)),
          realizedGL: accumulator.realizedGL.plus(new Dec(summary?.totalRealizedGL ?? 0)),
          unrealizedGL: accumulator.unrealizedGL.plus(new Dec(summary?.totalUnrealizedGL ?? 0)),
          transactionCount: accumulator.transactionCount + (portfolio.transactionCount ?? 0),
          dividendCount: accumulator.dividendCount + (portfolio.dividendCount ?? 0),
        };
      },
      {
        marketValue: new Dec(0),
        openCostBasis: new Dec(0),
        realizedGL: new Dec(0),
        unrealizedGL: new Dec(0),
        transactionCount: 0,
        dividendCount: 0,
      },
    );

    const allocationBySymbol = new Map<
      string,
      { marketValue: Decimal; openCostBasis: Decimal }
    >();
    for (const portfolio of portfolios) {
      for (const lot of portfolio.fifoSummary?.lots ?? []) {
        if (lot.qtyRemain <= 0) continue;
        const openCostBasis = new Dec(lot.costPerUnit).times(new Dec(lot.qtyRemain));
        const marketValue = openCostBasis.plus(new Dec(lot.unrealizedGL));
        const existing = allocationBySymbol.get(lot.symbol);
        if (existing) {
          existing.marketValue = existing.marketValue.plus(marketValue);
          existing.openCostBasis = existing.openCostBasis.plus(openCostBasis);
        } else {
          allocationBySymbol.set(lot.symbol, { marketValue, openCostBasis });
        }
      }
    }

    const allocationTotal = Array.from(allocationBySymbol.values()).reduce(
      (total, allocation) => total.plus(allocation.marketValue),
      new Dec(0),
    );
    const allocation = Array.from(allocationBySymbol.entries())
      .map(([symbol, values]) => ({
        symbol,
        valueTHB: values.marketValue.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
        openCostBasisTHB: values.openCostBasis
          .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
          .toFixed(2),
        weightPct: allocationTotal.gt(0)
          ? values.marketValue.times(100).div(allocationTotal).toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2)
          : '0.00',
      }))
      .sort((left, right) => new Dec(right.valueTHB).cmp(left.valueTHB));

    const recentRows = portfolioIds.length > 0
      ? await prisma.transaction.findMany({
          where: { portfolioId: { in: portfolioIds } },
          orderBy: [{ date: 'desc' }, { id: 'desc' }],
          take: 8,
        })
      : [];

    res.status(200).json({
      asOf: new Date().toISOString(),
      currency: 'THB',
      valuationBasis: 'LATEST_RECORDED_TRANSACTION_PRICE',
      summary: {
        portfolioCount: portfolios.length,
        transactionCount: totals.transactionCount,
        dividendCount: totals.dividendCount,
        marketValueTHB: totals.marketValue.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
        openCostBasisTHB: totals.openCostBasis.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
        realizedGLTHB: totals.realizedGL.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
        unrealizedGLTHB: totals.unrealizedGL.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2),
      },
      allocation,
      portfolios,
      recentTransactions: recentRows.map(mapPrismaTransactionToShared),
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/mobile/transactions/:portfolioId
 * Stable newest-first cursor page for the mobile ledger. The endpoint preserves
 * portfolio ownership checks and never changes the existing web transaction contract.
 */
mobileRouter.get(
  '/transactions/:portfolioId',
  authMiddleware,
  validateRequest({
    params: mobileTransactionsParamsSchema,
    query: mobileTransactionsQuerySchema,
  }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as {
        params: z.infer<typeof mobileTransactionsParamsSchema>;
        query: z.infer<typeof mobileTransactionsQuerySchema>;
      };
      const { portfolioId } = validated.params;
      const { cursor, limit, type, symbol } = validated.query;

      await requireOwnedPortfolio(portfolioId, req.user!.id);
      const prisma = getPrismaClient();

      if (cursor) {
        const cursorRow = await prisma.transaction.findFirst({
          where: { id: cursor, portfolioId },
          select: { id: true },
        });
        if (!cursorRow) {
          throw new AppError(400, 'INVALID_CURSOR', 'The transaction cursor is invalid for this portfolio.');
        }
      }

      const rows = await prisma.transaction.findMany({
        where: {
          portfolioId,
          ...(type ? { type } : {}),
          ...(symbol ? { symbol } : {}),
        },
        orderBy: [{ date: 'desc' }, { id: 'desc' }],
        take: limit + 1,
        ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      });
      const hasMore = rows.length > limit;
      const pageRows = hasMore ? rows.slice(0, limit) : rows;
      const lastRow = pageRows.at(-1);

      res.status(200).json({
        items: pageRows.map(mapPrismaTransactionToShared),
        limit,
        hasMore,
        nextCursor: hasMore && lastRow ? lastRow.id : null,
      });
    } catch (error) {
      next(error);
    }
  },
);
