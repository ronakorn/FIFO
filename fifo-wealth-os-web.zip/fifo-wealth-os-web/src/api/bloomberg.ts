import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { parseBloombergCorporateActions, parseBloombergCorporateActionsFile, parseBloombergTicker, parseBloombergTrades, parseBloombergTradesFile, BloombergDecimal } from '../adapters/bloombergAdapter';
import { BloombergPortAdapter } from '../adapters/bloombergPortAdapter';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import { calculateMultiAssetPortfolioSummary } from '../services/multiAsset';
import { validateMultiAssetTransaction, type MultiAssetTransaction } from '../types/multiAsset';
import { requireOwnedPortfolio } from './routes/portfolioRoutes';

export const bloombergRouter = Router();

const bloombergMemoryUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024,
    files: 1,
  },
});

const tradeUploadBodySchema = z.object({
  portfolioId: z.string().trim().min(1),
  csvContent: z.string().max(5 * 1024 * 1024).optional(),
}).strict();

const corporateActionUploadBodySchema = z.object({
  csvContent: z.string().max(5 * 1024 * 1024).optional(),
}).strict();

const tickerPreviewBodySchema = z.object({
  ticker: z.string().trim().min(1).max(200),
}).strict();

const portConnectionBodySchema = z.object({
  portfolioId: z.string().trim().min(1),
  environment: z.enum(['LIVE', 'SANDBOX']).default('SANDBOX'),
}).strict();

function parseTradesOrThrow(input: { buffer?: Buffer; fileName: string; csvContent?: string; portfolioId: string }): MultiAssetTransaction[] {
  try {
    if (input.buffer) return parseBloombergTradesFile(input.buffer, input.fileName, { portfolioId: input.portfolioId });
    if (input.csvContent !== undefined) return parseBloombergTrades(input.csvContent, { portfolioId: input.portfolioId });
    throw new AppError(400, 'MISSING_BLOOMBERG_FILE', 'Upload a Bloomberg CSV/.xlsx file in the "file" field, or provide csvContent.');
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError(400, 'BLOOMBERG_TRADE_PARSE_ERROR', error instanceof Error ? error.message : 'Could not parse Bloomberg trades.');
  }
}

function parseActionsOrThrow(input: { buffer?: Buffer; fileName: string; csvContent?: string }) {
  try {
    if (input.buffer) return parseBloombergCorporateActionsFile(input.buffer, input.fileName);
    if (input.csvContent !== undefined) return parseBloombergCorporateActions(input.csvContent);
    throw new AppError(400, 'MISSING_BLOOMBERG_FILE', 'Upload a Bloomberg CSV/.xlsx file in the "file" field, or provide csvContent.');
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError(400, 'BLOOMBERG_ACTION_PARSE_ERROR', error instanceof Error ? error.message : 'Could not parse Bloomberg corporate actions.');
  }
}

function deserializeMultiAssetPayload(payload: string): MultiAssetTransaction {
  const parsed = JSON.parse(payload) as Omit<MultiAssetTransaction, 'createdAt'> & { createdAt: string | Date };
  return { ...parsed, createdAt: new Date(parsed.createdAt) };
}

function attachTHBValues(transaction: MultiAssetTransaction, portfolioBaseCurrency: string): MultiAssetTransaction {
  if (portfolioBaseCurrency.toUpperCase() !== 'THB') {
    throw new AppError(
      400,
      'BLOOMBERG_BASE_CURRENCY_UNSUPPORTED',
      'Bloomberg multi-asset imports currently require a THB-base portfolio because the existing CDM valuation engines report in THB.',
    );
  }
  if (transaction.originalCurrency.toUpperCase() === 'THB') {
    const netTHB = new BloombergDecimal(transaction.originalNet).toDecimalPlaces(2, BloombergDecimal.ROUND_HALF_UP).toFixed(2);
    return { ...transaction, fxRate: '1.00000000', netTHB };
  }
  if (!transaction.fxRate) {
    throw new AppError(
      400,
      'BLOOMBERG_FX_RATE_REQUIRED',
      `Bloomberg row ${transaction.symbol} (${transaction.originalCurrency}) is missing "FX Rate to THB". Include a rate in the export; no synthetic rate is applied during import.`,
    );
  }
  const rate = new BloombergDecimal(transaction.fxRate);
  if (!rate.isFinite() || !rate.isPositive()) {
    throw new AppError(400, 'BLOOMBERG_FX_RATE_INVALID', `Bloomberg row ${transaction.symbol} has an invalid FX rate.`);
  }
  const netTHB = new BloombergDecimal(transaction.originalNet)
    .times(rate)
    .toDecimalPlaces(2, BloombergDecimal.ROUND_HALF_UP)
    .toFixed(2);
  return { ...transaction, netTHB };
}

bloombergRouter.post(
  '/upload/bloomberg-trades',
  authMiddleware,
  bloombergMemoryUpload.single('file'),
  validateRequest({ body: tradeUploadBodySchema }),
  async (req, res, next) => {
    try {
      const body = res.locals['validated'] as { body: z.infer<typeof tradeUploadBodySchema> };
      const portfolio = await requireOwnedPortfolio(body.body.portfolioId, req.user!.id);
      const parsedTransactions = parseTradesOrThrow({
        buffer: req.file?.buffer,
        fileName: req.file?.originalname ?? 'bloomberg.csv',
        csvContent: body.body.csvContent,
        portfolioId: portfolio.id,
      });
      if (!parsedTransactions.length) {
        throw new AppError(400, 'EMPTY_BLOOMBERG_TRADES', 'Bloomberg file contains no trade rows.');
      }

      const enrichedTransactions = parsedTransactions.map((transaction) => attachTHBValues(transaction, portfolio.baseCurrency));
      for (const transaction of enrichedTransactions) {
        const validation = validateMultiAssetTransaction(transaction);
        if (!validation.isValid) {
          throw new AppError(400, 'INVALID_BLOOMBERG_CDM_TRANSACTION', `Bloomberg trade ${transaction.symbol} does not satisfy the existing Core CDM.`, validation.errors);
        }
      }

      const prisma = getPrismaClient();
      const existingRows = await prisma.multiAssetTransactionRecord.findMany({
        where: { portfolioId: portfolio.id },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      });
      const seenIds = new Set(existingRows.map((row) => row.id));
      const candidates = enrichedTransactions.filter((transaction) => {
        if (seenIds.has(transaction.id)) return false;
        seenIds.add(transaction.id);
        return true;
      });
      const duplicateCount = enrichedTransactions.length - candidates.length;

      if (candidates.length) {
        const existingTransactions = existingRows.map((row) => deserializeMultiAssetPayload(row.payload));
        // Re-run the existing asset engines before writing, so an invalid bond/commodity/FX sale cannot enter the ledger.
        calculateMultiAssetPortfolioSummary([...existingTransactions, ...candidates]);
        await prisma.$transaction(async (database) => {
          for (const transaction of candidates) {
            await database.multiAssetTransactionRecord.create({
              data: {
                id: transaction.id,
                portfolioId: portfolio.id,
                date: transaction.date,
                assetClass: transaction.assetClass,
                type: transaction.type,
                symbol: transaction.symbol,
                payload: JSON.stringify(transaction),
              },
            });
          }
        });
      }

      res.status(candidates.length ? 201 : 200).json({
        success: true,
        importedCount: candidates.length,
        duplicateCount,
        totalParsed: enrichedTransactions.length,
        transactions: candidates,
        warnings: [
          'Bloomberg-exported data is imported as a file mapping; this is not a direct or official Bloomberg Terminal connection.',
          'Corporate actions are not auto-applied. Futures are rejected because the protected Core CDM has no Futures instrument type.',
          'Foreign-currency rows require an explicit FX Rate to THB column; synthetic fallback rates are not used.',
        ],
      });
    } catch (error) {
      next(error);
    }
  },
);

bloombergRouter.post(
  '/upload/bloomberg-corporate-actions',
  authMiddleware,
  bloombergMemoryUpload.single('file'),
  validateRequest({ body: corporateActionUploadBodySchema }),
  (req, res, next) => {
    try {
      const body = res.locals['validated'] as { body: z.infer<typeof corporateActionUploadBodySchema> };
      const corporateActions = parseActionsOrThrow({
        buffer: req.file?.buffer,
        fileName: req.file?.originalname ?? 'bloomberg-corporate-actions.csv',
        csvContent: body.body.csvContent,
      });
      res.status(200).json({
        success: true,
        previewOnly: true,
        count: corporateActions.length,
        corporateActions,
        notice: 'Corporate actions are parsed for review only and are not persisted or applied to portfolio lots.',
      });
    } catch (error) {
      next(error);
    }
  },
);

bloombergRouter.post(
  '/bloomberg/tickers/parse',
  authMiddleware,
  validateRequest({ body: tickerPreviewBodySchema }),
  (_req, res, next) => {
    try {
      const body = res.locals['validated'] as { body: z.infer<typeof tickerPreviewBodySchema> };
      const ticker = parseBloombergTicker(body.body.ticker);
      res.status(200).json({ ticker });
    } catch (error) {
      next(new AppError(400, 'BLOOMBERG_TICKER_PARSE_ERROR', error instanceof Error ? error.message : 'Invalid Bloomberg ticker.'));
    }
  },
);

bloombergRouter.post(
  '/connect/bloomberg-port',
  authMiddleware,
  validateRequest({ body: portConnectionBodySchema }),
  async (req, res, next) => {
    try {
      const body = res.locals['validated'] as { body: z.infer<typeof portConnectionBodySchema> };
      await requireOwnedPortfolio(body.body.portfolioId, req.user!.id);
      if (body.body.environment === 'LIVE') {
        throw new AppError(
          501,
          'BLOOMBERG_PORT_LIVE_NOT_CONFIGURED',
          'Live Bloomberg Port is not configured. The repository has no verified Port API contract or credentials; no live request was sent.',
        );
      }
      const adapter = new BloombergPortAdapter({
        portfolioId: body.body.portfolioId,
        environment: 'SANDBOX',
      });
      const [positions, trades, corporateActions] = await Promise.all([
        adapter.fetchPositions(),
        adapter.fetchTradeHistory('2026-01-01', '2026-12-31'),
        adapter.fetchCorporateActions('2026-01-01', '2026-12-31'),
      ]);
      res.status(200).json({
        success: true,
        ...adapter.getStatus(),
        positions,
        trades,
        corporateActions,
      });
    } catch (error) {
      next(error);
    }
  },
);
