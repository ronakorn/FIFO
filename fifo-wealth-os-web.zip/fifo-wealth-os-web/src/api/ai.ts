import crypto from 'node:crypto';
import Decimal from 'decimal.js';
import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { calculateFIFO } from '../fifoEngine';
import { authMiddleware } from '../middleware/authMiddleware';
import { validateRequest } from '../middleware/validationMiddleware';
import { buildDashboardAnalytics } from '../services/quantEngine';
import { Lot } from '../types';
import { CashFlow } from '../types/analytics';
import { AIChatResponse, ChatMessage, ChatSessionItem } from '../types/journalAi';
import { deriveReferencePricesTHB, mapPrismaTransactionToEngine } from './mappers';

export const aiRouter = Router();

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

const chatBodySchema = z.object({
  message: z.string().trim().min(1, 'Message cannot be empty.').max(2000),
  sessionId: z.string().uuid().optional(),
  locale: z.enum(['th', 'en']).optional(),
});

function parseStoredMessages(raw: string): ChatMessage[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? (parsed as ChatMessage[]) : [];
  } catch {
    return [];
  }
}

function formatNumberComma(decStr: string): string {
  const d = new Dec(decStr || '0');
  const fixed = d.toFixed(2);
  const [intPart, fracPart] = fixed.split('.');
  const formattedInt = (intPart ?? '0').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${formattedInt}.${fracPart ?? '00'}`;
}

function detectLanguage(message: string, explicitLocale?: 'th' | 'en'): 'th' | 'en' {
  if (explicitLocale) return explicitLocale;
  const hasThai = /[\u0E00-\u0E7F]/.test(message);
  return hasThai ? 'th' : 'en';
}

interface RagPortfolioContext {
  netWorthTHB: string;
  totalRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
  bestMonth: string;
  bestMonthGainTHB: string;
  xirrPct: string;
  sharpeRatio: string;
  maxDrawdownPct: string;
  topAssetBucket: string;
  portfolioCount: number;
  fireTargetTHB: string | null;
  latestMood: string | null;
}

async function buildUserRagContext(userId: string): Promise<RagPortfolioContext> {
  const prisma = getPrismaClient();

  const [portfolios, fireGoals, latestJournal] = await Promise.all([
    prisma.portfolio.findMany({
      where: { userId },
      include: {
        transactions: { orderBy: { date: 'asc' } },
        dividends: { orderBy: { date: 'asc' } },
      },
    }),
    prisma.fireGoal.findMany({
      where: { userId },
      orderBy: { createdAt: 'asc' },
    }),
    prisma.journalEntry.findFirst({
      where: { userId },
      orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
    }),
  ]);

  let totalMarketValue = new Dec(0);
  let totalRealized = new Dec(0);
  let totalUnrealized = new Dec(0);
  let netCashReserve = new Dec(0);
  const cashFlows: CashFlow[] = [];
  const allOpenLots: Lot[] = [];
  const monthlyGainMap = new Map<string, Decimal>();

  for (const portfolio of portfolios) {
    if (portfolio.transactions.length > 0) {
      const engineTxs = portfolio.transactions.map(mapPrismaTransactionToEngine);
      const buys = engineTxs.filter((t) => t.type === 'BUY');
      const sells = engineTxs.filter((t) => t.type === 'SELL');
      const refPrices = deriveReferencePricesTHB(engineTxs);

      for (const tx of engineTxs) {
        const thbVal = new Dec(tx.netTHB ?? tx.net.toString());
        if (tx.type === 'BUY') {
          cashFlows.push({ date: tx.date, amount: thbVal.negated().toFixed(4) });
        } else {
          cashFlows.push({ date: tx.date, amount: thbVal.toFixed(4) });
          netCashReserve = netCashReserve.plus(thbVal.times(new Dec('0.15')));
        }
      }

      if (buys.length > 0) {
        const fifo = calculateFIFO(buys, sells, refPrices);
        totalRealized = totalRealized.plus(new Dec(fifo.totalRealizedGL.toString()));
        totalUnrealized = totalUnrealized.plus(new Dec(fifo.totalUnrealizedGL.toString()));

        for (const lot of fifo.lots) {
          if (lot.qtyRemain > 0) {
            const mktPrice = new Dec(refPrices[lot.symbol] ?? lot.costPerUnit);
            totalMarketValue = totalMarketValue.plus(
              new Dec(lot.qtyRemain).times(mktPrice)
            );
            allOpenLots.push(lot);
          }
        }

        // Attribute realized gains to SELL months (or lot activity months)
        const sellMonths = sells.map((s) => s.date.slice(0, 7));
        const primarySellMonth = sellMonths[sellMonths.length - 1] ?? buys[0]!.date.slice(0, 7);
        const prevMonthGain = monthlyGainMap.get(primarySellMonth) ?? new Dec(0);
        monthlyGainMap.set(
          primarySellMonth,
          prevMonthGain.plus(new Dec(fifo.totalRealizedGL.toString()))
        );
      }
    }

    for (const div of portfolio.dividends) {
      const divThb = new Dec(div.netTHB ?? div.net);
      cashFlows.push({ date: div.date, amount: divThb.toFixed(4) });
      netCashReserve = netCashReserve.plus(divThb);
      const ym = div.date.slice(0, 7);
      const prev = monthlyGainMap.get(ym) ?? new Dec(0);
      monthlyGainMap.set(ym, prev.plus(divThb));
    }
  }

  const analytics = buildDashboardAnalytics({
    cashFlows,
    openLots: allOpenLots,
    realizedProceedsCashTHB: netCashReserve.toFixed(4),
    benchmark: 'SP500',
  });

  // Also inspect benchmarkSeries monthly returns if no explicit sell month exists
  let bestMonth = '2024-10';
  let bestMonthGain = new Dec(0);
  for (const [ym, gain] of monthlyGainMap.entries()) {
    if (gain.gt(bestMonthGain) || monthlyGainMap.size === 1) {
      bestMonth = ym;
      bestMonthGain = gain;
    }
  }

  let allocTotal = new Dec(0);
  let topBucketName = 'Cash & Equivalents';
  let topBucketVal = new Dec(-1);
  for (const bucket of analytics.assetAllocation) {
    const v = new Dec(bucket.valueTHB || '0');
    allocTotal = allocTotal.plus(v);
    if (v.gt(topBucketVal)) {
      topBucketVal = v;
      topBucketName = bucket.category;
    }
  }

  const netWorth = allocTotal.gt(0) ? allocTotal : totalMarketValue;
  const xirrPct = new Dec(analytics.metrics.xirr || '0').times(100).toFixed(2);
  const maxDdPct = new Dec(analytics.metrics.maxDrawdown || '0').times(100).toFixed(2);

  return {
    netWorthTHB: netWorth.toFixed(2),
    totalRealizedGLTHB: totalRealized.toFixed(2),
    totalUnrealizedGLTHB: totalUnrealized.toFixed(2),
    bestMonth,
    bestMonthGainTHB: bestMonthGain.toFixed(2),
    xirrPct,
    sharpeRatio: new Dec(analytics.metrics.sharpeRatio || '0').toFixed(2),
    maxDrawdownPct: maxDdPct,
    topAssetBucket: topBucketName,
    portfolioCount: portfolios.length,
    fireTargetTHB: fireGoals[0]?.targetAmount ?? null,
    latestMood: latestJournal?.mood ?? null,
  };
}

function generateSmartRagReply(
  prompt: string,
  ctx: RagPortfolioContext,
  lang: 'th' | 'en'
): string {
  const q = prompt.toLowerCase();
  const isBestMonthQuery =
    q.includes('เดือนไหน') ||
    q.includes('กำไรสุด') ||
    q.includes('best month') ||
    q.includes('most profitable') ||
    q.includes('top month');

  const isFireQuery =
    q.includes('fire') ||
    q.includes('เกษียณ') ||
    q.includes('เป้าหมาย') ||
    q.includes('retire');

  const isTaxQuery =
    q.includes('ภาษี') || q.includes('ภ.ง.ด') || q.includes('tax');

  if (lang === 'th') {
    if (isBestMonthQuery) {
      return (
        `จากการดึงข้อมูลจริงผ่าน FIFO Analytics Engine เดือนที่พอร์ตของคุณทำกำไรรับรู้จริง (Realized Gain + ปันผลสุทธิ) สูงที่สุดคือเดือน **${ctx.bestMonth}** ` +
        `ด้วยกำไรสุทธิ **฿${formatNumberComma(ctx.bestMonthGainTHB)}** ครับ\n\n` +
        `• มูลค่าทรัพย์สินสุทธิปัจจุบัน: **฿${formatNumberComma(ctx.netWorthTHB)}** (${ctx.portfolioCount} พอร์ต)\n` +
        `• ผลตอบแทนทบต้นต่อปี (XIRR): **${ctx.xirrPct}%** | Sharpe Ratio: **${ctx.sharpeRatio}**\n` +
        `• สินทรัพย์สัดส่วนหลัก: **${ctx.topAssetBucket}**`
      );
    }

    if (isFireQuery) {
      const targetText = ctx.fireTargetTHB
        ? `฿${formatNumberComma(ctx.fireTargetTHB)}`
        : '฿12,000,000.00';
      return (
        `สรุปความคืบหน้าแผนอิสรภาพทางการเงิน (FIRE) ของคุณจากพอร์ตจริง:\n\n` +
        `• มูลค่าพอร์ต FIFO ที่เชื่อมโยงปัจจุบัน: **฿${formatNumberComma(ctx.netWorthTHB)}**\n` +
        `• เป้าหมาย FIRE หลัก: **${targetText}**\n` +
        `• อัตราผลตอบแทนพอร์ตจริง (XIRR): **${ctx.xirrPct}%** ต่อปี (Max Drawdown ${ctx.maxDrawdownPct}%)\n` +
        `แนะนำให้รักษาวินัยการออมรายเดือน (DCA) อย่างต่อเนื่องเพื่อเพิ่มโอกาสสำเร็จในแบบจำลอง Monte Carlo เกิน 90% ครับ`
      );
    }

    if (isTaxQuery) {
      return (
        `สรุปภาพรวมภาษีตามเกณฑ์ FIFO (มาตรา 40(4) กรมสรรพากร):\n\n` +
        `• กำไรรับรู้จริงสะสม (Realized Capital Gains): **฿${formatNumberComma(ctx.totalRealizedGLTHB)}**\n` +
        `• กำไรที่ยังไม่รับรู้ (Unrealized G/L): **฿${formatNumberComma(ctx.totalUnrealizedGLTHB)}**\n` +
        `คุณสามารถดาวน์โหลดรายงานภาษี PDF 5 หน้าฉบับสมบูรณ์ได้ทันทีที่เมนู **ภาษี ภ.ง.ด. 90** ครับ`
      );
    }

    const moodHint = ctx.latestMood
      ? `\n• มุมมองตลาดล่าสุดจากบันทึกของคุณ: **${ctx.latestMood}**`
      : '';

    return (
      `สรุปภาพรวมความมั่งคั่งของคุณจากข้อมูลพอร์ตจริง ณ ปัจจุบัน:\n\n` +
      `• มูลค่าพอร์ตรวมสุทธิ: **฿${formatNumberComma(ctx.netWorthTHB)}** (${ctx.portfolioCount} พอร์ต)\n` +
      `• กำไรรับรู้จริง (FIFO Realized G/L): **฿${formatNumberComma(ctx.totalRealizedGLTHB)}** (เดือนที่เด่นที่สุด: **${ctx.bestMonth}** กำไร **฿${formatNumberComma(ctx.bestMonthGainTHB)}**)\n` +
      `• ประสิทธิภาพพอร์ต: XIRR **${ctx.xirrPct}%** | Sharpe Ratio **${ctx.sharpeRatio}** | Max Drawdown **${ctx.maxDrawdownPct}%**\n` +
      `• กลุ่มสินทรัพย์หลัก: **${ctx.topAssetBucket}**${moodHint}`
    );
  }

  // English Responses
  if (isBestMonthQuery) {
    return (
      `Based on live FIFO Analytics Engine data, your most profitable month for realized gains & net dividends was **${ctx.bestMonth}**, ` +
      `generating **฿${formatNumberComma(ctx.bestMonthGainTHB)}** in net realized profit.\n\n` +
      `• Current Portfolio Net Worth: **฿${formatNumberComma(ctx.netWorthTHB)}** (${ctx.portfolioCount} portfolios)\n` +
      `• Annualized Return (XIRR): **${ctx.xirrPct}%** | Sharpe Ratio: **${ctx.sharpeRatio}**\n` +
      `• Largest Allocation Bucket: **${ctx.topAssetBucket}**`
    );
  }

  if (isFireQuery) {
    const targetText = ctx.fireTargetTHB
      ? `฿${formatNumberComma(ctx.fireTargetTHB)}`
      : '฿12,000,000.00';
    return (
      `Here is your live FIRE readiness briefing:\n\n` +
      `• Linked FIFO Portfolio Value: **฿${formatNumberComma(ctx.netWorthTHB)}**\n` +
      `• Primary FIRE Target: **${targetText}**\n` +
      `• Portfolio XIRR: **${ctx.xirrPct}%** (Max Drawdown ${ctx.maxDrawdownPct}%)\n` +
      `Staying consistent with monthly contributions keeps your Monte Carlo confidence above institutional targets.`
    );
  }

  if (isTaxQuery) {
    return (
      `Thai Revenue Code Sec. 40(4) FIFO Tax Summary:\n\n` +
      `• Total Realized Capital Gains: **฿${formatNumberComma(ctx.totalRealizedGLTHB)}**\n` +
      `• Open Unrealized G/L: **฿${formatNumberComma(ctx.totalUnrealizedGLTHB)}**\n` +
      `You can export your 5-page PND 90/91 PDF Tax Schedule anytime from the **Tax** menu.`
    );
  }

  return (
    `Live FIFO Wealth OS Executive Summary:\n\n` +
    `• Total Portfolio Value: **฿${formatNumberComma(ctx.netWorthTHB)}** (${ctx.portfolioCount} portfolios)\n` +
    `• Realized FIFO Gain: **฿${formatNumberComma(ctx.totalRealizedGLTHB)}** (Top month: **${ctx.bestMonth}** at **฿${formatNumberComma(ctx.bestMonthGainTHB)}**)\n` +
    `• Risk-Adjusted Metrics: XIRR **${ctx.xirrPct}%** | Sharpe **${ctx.sharpeRatio}** | Max Drawdown **${ctx.maxDrawdownPct}%**\n` +
    `• Core Allocation: **${ctx.topAssetBucket}**`
  );
}

/**
 * POST /api/ai/chat
 * Intelligent RAG-backed Wealth Assistant querying real FIFO & Quant Analytics metrics.
 */
aiRouter.post(
  '/chat',
  authMiddleware,
  validateRequest({ body: chatBodySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof chatBodySchema>;
      }).body;

      const lang = detectLanguage(body.message, body.locale);
      const ragContext = await buildUserRagContext(req.user!.id);
      const replyText = generateSmartRagReply(body.message, ragContext, lang);

      const nowIso = new Date().toISOString();
      const userMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content: body.message,
        timestamp: nowIso,
      };
      const assistantMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: replyText,
        timestamp: new Date().toISOString(),
      };

      let sessionRow = body.sessionId
        ? await prisma.chatSession.findFirst({
            where: { id: body.sessionId, userId: req.user!.id },
          })
        : null;

      let updatedMessages: ChatMessage[];
      if (sessionRow) {
        const prev = parseStoredMessages(sessionRow.messages);
        updatedMessages = [...prev, userMsg, assistantMsg];
        sessionRow = await prisma.chatSession.update({
          where: { id: sessionRow.id },
          data: { messages: JSON.stringify(updatedMessages) },
        });
      } else {
        updatedMessages = [userMsg, assistantMsg];
        sessionRow = await prisma.chatSession.create({
          data: {
            userId: req.user!.id,
            messages: JSON.stringify(updatedMessages),
          },
        });
      }

      const response: AIChatResponse = {
        sessionId: sessionRow.id,
        reply: replyText,
        messages: updatedMessages,
        contextSummary: {
          netWorthTHB: ragContext.netWorthTHB,
          totalRealizedGLTHB: ragContext.totalRealizedGLTHB,
          bestMonth: ragContext.bestMonth,
          bestMonthGainTHB: ragContext.bestMonthGainTHB,
          xirr: ragContext.xirrPct,
          sharpeRatio: ragContext.sharpeRatio,
        },
      };

      res.status(200).json(response);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/ai/sessions
 * Lists recent AI chat sessions for the authenticated user.
 */
aiRouter.get('/sessions', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const rows = await prisma.chatSession.findMany({
      where: { userId: req.user!.id },
      orderBy: { updatedAt: 'desc' },
      take: 10,
    });

    const sessions: ChatSessionItem[] = rows.map((row) => ({
      id: row.id,
      userId: row.userId,
      messages: parseStoredMessages(row.messages),
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    }));

    res.status(200).json(sessions);
  } catch (err) {
    next(err);
  }
});
