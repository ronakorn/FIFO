import {
  Dividend as PrismaDividend,
  Portfolio as PrismaPortfolio,
  Transaction as PrismaTransaction,
  UploadedFile as PrismaUploadedFile,
  User as PrismaUser,
} from '@prisma/client';
import { Dec, formatExactDecimalString, toNumber } from '../parsers/csvUtils';
import {
  Dividend as EngineDividend,
  Exchange,
  Transaction as EngineTransaction,
  TransactionType,
} from '../types';
import {
  DividendRecord,
  Portfolio as SharedPortfolio,
  Transaction as SharedTransaction,
  UploadedFileRecord,
  User as SharedUser,
} from '../types/shared';

export function mapPrismaUserToShared(user: PrismaUser): SharedUser {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    createdAt: user.createdAt.toISOString(),
  };
}

export function mapPrismaPortfolioToShared(portfolio: PrismaPortfolio): SharedPortfolio {
  return {
    id: portfolio.id,
    userId: portfolio.userId,
    name: portfolio.name,
    baseCurrency: portfolio.baseCurrency,
    createdAt: portfolio.createdAt.toISOString(),
  };
}

export function mapPrismaTransactionToShared(tx: PrismaTransaction): SharedTransaction {
  return {
    id: tx.id,
    portfolioId: tx.portfolioId,
    date: tx.date,
    symbol: tx.symbol,
    type: tx.type as TransactionType,
    qty: tx.qty,
    price: tx.price,
    gross: tx.gross,
    comm: tx.comm,
    vat: tx.vat,
    net: tx.net,
    originalCurrency: tx.originalCurrency,
    fxRate: tx.fxRate,
    netTHB: tx.netTHB,
  };
}

export function mapPrismaTransactionToEngine(tx: PrismaTransaction): EngineTransaction {
  return {
    id: tx.id,
    date: tx.date,
    symbol: tx.symbol,
    qty: tx.qty,
    price: tx.price,
    gross: toNumber(new Dec(tx.gross)),
    comm: toNumber(new Dec(tx.comm)),
    vat: toNumber(new Dec(tx.vat)),
    net: toNumber(new Dec(tx.net)),
    type: tx.type as TransactionType,
    exchange: (tx.exchange || 'BITKUB') as Exchange,
    currency: tx.originalCurrency,
    originalCurrency: tx.originalCurrency,
    originalNet: tx.net,
    fxRate: tx.fxRate,
    netTHB: tx.netTHB,
  };
}

export function mapEngineTransactionToPrismaCreate(
  tx: EngineTransaction,
  portfolioId: string
): {
  portfolioId: string;
  date: string;
  symbol: string;
  type: string;
  exchange: string;
  qty: number;
  price: number;
  gross: string;
  comm: string;
  vat: string;
  net: string;
  originalCurrency: string;
  fxRate: string | null;
  netTHB: string | null;
} {
  return {
    portfolioId,
    date: tx.date,
    symbol: tx.symbol,
    type: tx.type,
    exchange: tx.exchange,
    qty: tx.qty,
    price: tx.price,
    gross: formatExactDecimalString(new Dec(tx.gross)),
    comm: formatExactDecimalString(new Dec(tx.comm)),
    vat: formatExactDecimalString(new Dec(tx.vat)),
    net: tx.originalNet,
    originalCurrency: tx.originalCurrency,
    fxRate: tx.fxRate,
    netTHB: tx.netTHB,
  };
}

export function mapPrismaDividendToShared(div: PrismaDividend): DividendRecord {
  return {
    id: div.id,
    portfolioId: div.portfolioId,
    date: div.date,
    symbol: div.symbol,
    qty: div.qty,
    divPerShare: div.divPerShare,
    gross: div.gross,
    whtRate: div.whtRate,
    wht: div.wht,
    net: div.net,
    originalCurrency: div.originalCurrency,
    fxRate: div.fxRate,
    grossTHB: div.grossTHB,
    whtTHB: div.whtTHB,
    netTHB: div.netTHB,
  };
}

export function mapPrismaDividendToEngine(div: PrismaDividend): EngineDividend {
  return {
    id: div.id,
    date: div.date,
    symbol: div.symbol,
    qty: div.qty,
    divPerShare: div.divPerShare,
    gross: div.gross,
    whtRate: div.whtRate,
    wht: div.wht,
    net: div.net,
    originalCurrency: div.originalCurrency,
    fxRate: div.fxRate,
    grossTHB: div.grossTHB,
    whtTHB: div.whtTHB,
    netTHB: div.netTHB,
  };
}

export function mapPrismaUploadedFileToShared(file: PrismaUploadedFile): UploadedFileRecord {
  return {
    id: file.id,
    userId: file.userId,
    portfolioId: file.portfolioId,
    filename: file.filename,
    type: file.type as 'CSV' | 'PDF',
    path: file.path,
    createdAt: file.createdAt.toISOString(),
  };
}

/**
 * Derives latest observed Base Currency unit price per symbol from transaction history
 * so open FIFO lots always have a deterministic reference mark-to-market price.
 */
export function deriveReferencePricesTHB(
  transactions: readonly EngineTransaction[]
): Record<string, number> {
  const latestBySymbol = new Map<string, { timestamp: number; priceTHB: number }>();

  for (const tx of transactions) {
    if (tx.price <= 0) continue;
    const ts = Date.parse(tx.date);
    const fx = new Dec(tx.fxRate ?? '1.00');
    const unitPriceTHB = toNumber(new Dec(tx.price).times(fx));

    const prev = latestBySymbol.get(tx.symbol);
    if (!prev || ts >= prev.timestamp) {
      latestBySymbol.set(tx.symbol, { timestamp: ts, priceTHB: unitPriceTHB });
    }
  }

  const prices: Record<string, number> = {};
  for (const [symbol, entry] of latestBySymbol.entries()) {
    prices[symbol] = entry.priceTHB;
  }
  return prices;
}
