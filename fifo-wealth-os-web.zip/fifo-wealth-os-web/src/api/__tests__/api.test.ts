import fs from 'fs';
import os from 'os';
import path from 'path';
import { PrismaClient } from '@prisma/client';
import Decimal from 'decimal.js';
import request from 'supertest';
import { setPrismaClient } from '../../db/prisma';
import { signMockStripePayload } from '../../services/stripeService';
import { assertTransactionDatesWithinAnnualLimit } from '../../services/entitlementService';
import { createApp } from '../app';

// This integration suite replays every SQL migration against a fresh SQLite database before tests begin.
jest.setTimeout(120_000);

describe('FIFO Wealth OS - Phase 5 Backend REST API (Multi-User, Multi-Portfolio)', () => {
  const app = createApp();
  let testPrisma: PrismaClient;
  let tmpStorageDir: string;

  let userAToken = '';
  let userBToken = '';
  let portfolioId = '';

  beforeAll(async () => {
    tmpStorageDir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'fifo-api-test-'));
    process.env['STORAGE_DIR'] = path.join(tmpStorageDir, 'uploads');
    process.env['REPORTS_STORAGE_DIR'] = path.join(tmpStorageDir, 'reports');
    process.env['JWT_SECRET'] = 'test-jwt-secret-fifo-wealth-os';

    // Initialize isolated temporary SQLite database via Prisma
    testPrisma = new PrismaClient({
      datasources: {
        db: {
          url: `file:${path.join(tmpStorageDir, 'test.db')}?connection_limit=1`,
        },
      },
    });

    await testPrisma.$connect();
    await testPrisma.$executeRawUnsafe('PRAGMA foreign_keys = ON;');

    // Apply Prisma migration SQL directly onto the in-memory SQLite database
    const migrationsRoot = path.resolve(__dirname, '../../../prisma/migrations');
    const migrationDirs = (await fs.promises.readdir(migrationsRoot))
      .filter((entry) => !entry.endsWith('.toml'))
      .sort();

    for (const dir of migrationDirs) {
      const sqlPath = path.join(migrationsRoot, dir, 'migration.sql');
      if (fs.existsSync(sqlPath)) {
        const rawSql = await fs.promises.readFile(sqlPath, 'utf8');
        const statements = rawSql
          .split(';')
          .map((s) => s.trim())
          .filter((s) => s.length > 0);

        for (const stmt of statements) {
          await testPrisma.$executeRawUnsafe(`${stmt};`);
        }
      }
    }

    setPrismaClient(testPrisma);
  });

  afterAll(async () => {
    setPrismaClient(null);
    await testPrisma.$disconnect();
    await fs.promises.rm(tmpStorageDir, { recursive: true, force: true });
  });

  describe('Health & API Documentation Contract', () => {
    it('serves /api/health, /api/openapi.json, and /api/postman.json', async () => {
      const healthRes = await request(app).get('/api/health').expect(200);
      expect(healthRes.body.status).toBe('ok');

      const openApiRes = await request(app).get('/api/openapi.json').expect(200);
      expect(openApiRes.body.openapi).toBe('3.0.3');
      expect(openApiRes.body.paths['/api/auth/register']).toBeDefined();
      expect(openApiRes.body.paths['/api/multi-assets/portfolios/{portfolioId}']).toBeDefined();
      expect(openApiRes.body.paths['/api/upload/bloomberg-trades']).toBeDefined();
      expect(openApiRes.body.paths['/api/advanced-assets/options/pricing']).toBeDefined();
      expect(openApiRes.body.paths['/api/advanced-assets/options/chain']).toBeDefined();
      expect(openApiRes.body.paths['/api/advanced-assets/futures/margin-health']).toBeDefined();
      expect(openApiRes.body.paths['/api/mobile/dashboard-summary']).toBeDefined();
      expect(openApiRes.body.paths['/api/mobile/transactions/{portfolioId}']).toBeDefined();

      const postmanRes = await request(app).get('/api/postman.json').expect(200);
      expect(postmanRes.body.info.name).toContain('FIFO Wealth OS');
      expect(postmanRes.body.item.some((folder: { name: string }) => folder.name === '3. Multi-Asset Foundation')).toBe(true);
      expect(postmanRes.body.item.some((folder: { name: string }) => folder.name === '7. Advanced Assets')).toBe(true);
    });
  });

  describe('Authentication & Zod Validation (/api/auth)', () => {
    it('validates registration payload with Zod and rejects invalid inputs (400)', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({ email: 'not-an-email', password: '123', name: '' })
        .expect(400);

      expect(res.body.error.code).toBe('VALIDATION_ERROR');
      expect(Array.isArray(res.body.error.details)).toBe(true);
    });

    it('registers User A, hashes password, and issues JWT (201)', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          email: 'InvestorA@WealthOS.th',
          password: 'StrongPassword123!',
          name: 'คุณสมชาย นักลงทุน',
        })
        .expect(201);

      expect(res.body.user).toMatchObject({
        email: 'investora@wealthos.th',
        name: 'คุณสมชาย นักลงทุน',
      });
      expect(res.body.user.passwordHash).toBeUndefined();
      expect(typeof res.body.token).toBe('string');

      userAToken = res.body.token;
    });

    it('rejects duplicate email registration with 409 Conflict', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          email: 'investora@wealthos.th',
          password: 'StrongPassword123!',
          name: 'Duplicate User',
        })
        .expect(409);

      expect(res.body.error.code).toBe('EMAIL_ALREADY_EXISTS');
    });

    it('authenticates User A via POST /api/auth/login and rejects wrong password', async () => {
      await request(app)
        .post('/api/auth/login')
        .send({ email: 'investora@wealthos.th', password: 'WrongPassword!' })
        .expect(401);

      const loginRes = await request(app)
        .post('/api/auth/login')
        .send({ email: 'investora@wealthos.th', password: 'StrongPassword123!' })
        .expect(200);

      expect(loginRes.body.user.email).toBe('investora@wealthos.th');
      expect(typeof loginRes.body.token).toBe('string');
    });

    it('protects GET /api/auth/me with JWT middleware', async () => {
      await request(app).get('/api/auth/me').expect(401);

      const meRes = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(meRes.body.user.email).toBe('investora@wealthos.th');
      expect(meRes.body.user.dateOfBirth).toBeNull();
    });

    it('saves and clears the optional date of birth for the RMF age check', async () => {
      const saved = await request(app)
        .patch('/api/auth/me')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ dateOfBirth: '1971-07-12' })
        .expect(200);
      expect(saved.body.user.dateOfBirth).toBe('1971-07-12');

      await request(app)
        .patch('/api/auth/me')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ dateOfBirth: '9999-01-01' })
        .expect(400);

      const cleared = await request(app)
        .patch('/api/auth/me')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ dateOfBirth: null })
        .expect(200);
      expect(cleared.body.user.dateOfBirth).toBeNull();
    });
  });

  describe('Open Beta Billing & Donation (/api/billing, /api/donate)', () => {
    it('returns BETA_ALL_ACCESS without authentication while Open Beta is enabled', async () => {
      const previousMode = process.env['OPEN_BETA_MODE'];
      process.env['OPEN_BETA_MODE'] = 'true';
      try {
        const response = await request(app).get('/api/billing/status').expect(200);
        expect(response.body).toMatchObject({
          tier: 'FREE',
          status: 'BETA_ALL_ACCESS',
          isBetaAllAccess: true,
          access: 'ALL_FEATURES',
        });
      } finally {
        if (previousMode === undefined) delete process.env['OPEN_BETA_MODE'];
        else process.env['OPEN_BETA_MODE'] = previousMode;
      }
    });

    it('returns the approved pricing and Early-Bird catalog without enabling charges', async () => {
      const previousMode = process.env['OPEN_BETA_MODE'];
      process.env['OPEN_BETA_MODE'] = 'true';
      try {
        const response = await request(app)
          .get('/api/billing/pricing')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(200);

        expect(response.body).toMatchObject({ openBeta: true, chargesEnabled: false });
        expect(response.body.pricing.earlyBird).toMatchObject({
          discountPercentage: 30,
          validUntil: '2027-06-30',
          lifetimeDiscount: true,
          endsOnCancellation: true,
        });
        expect(response.body.pricing.tiers).toEqual(
          expect.arrayContaining([
            expect.objectContaining({ tier: 'FREE', monthlyPriceTHB: '0.00', yearlyPriceTHB: '0.00' }),
            expect.objectContaining({ tier: 'PRO', monthlyPriceTHB: '290.00', yearlyPriceTHB: '2784.00', earlyBirdMonthlyPriceTHB: '203.00' }),
            expect.objectContaining({ tier: 'FAMILY', monthlyPriceTHB: '590.00', yearlyPriceTHB: '5664.00' }),
            expect.objectContaining({ tier: 'ADVISOR', monthlyPriceTHB: '1990.00', yearlyPriceTHB: '19104.00' }),
          ])
        );
        // Exact approved arithmetic: ฿290 × 0.7 = ฿203.
        expect(response.body.pricing.tiers.find((tier: { tier: string }) => tier.tier === 'PRO')?.earlyBirdMonthlyPriceTHB).toBe('203.00');
      } finally {
        if (previousMode === undefined) delete process.env['OPEN_BETA_MODE'];
        else process.env['OPEN_BETA_MODE'] = previousMode;
      }
    });

    it('enforces tier entitlements after beta but preserves all-access bypass while Open Beta is on', async () => {
      const previousMode = process.env['OPEN_BETA_MODE'];
      await testPrisma.user.update({
        where: { email: 'investora@wealthos.th' },
        data: { isBetaAllAccess: false },
      });
      process.env['OPEN_BETA_MODE'] = 'false';
      try {
        const gatedResponse = await request(app)
          .get('/api/family/dashboard')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(403);
        expect(gatedResponse.body.error.code).toBe('SUBSCRIPTION_REQUIRED');

        process.env['OPEN_BETA_MODE'] = 'true';
        await request(app)
          .get('/api/family/dashboard')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(200);
      } finally {
        await testPrisma.user.update({
          where: { email: 'investora@wealthos.th' },
          data: { isBetaAllAccess: true },
        });
        if (previousMode === undefined) delete process.env['OPEN_BETA_MODE'];
        else process.env['OPEN_BETA_MODE'] = previousMode;
      }
    });

    it('creates an exact-decimal pending donation and mock Checkout session', async () => {
      const response = await request(app)
        .post('/api/donate/create')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ amountTHB: '1000.00', message: 'Keep building thoughtful tools.' })
        .expect(201);

      expect(response.body.donation).toMatchObject({
        userId: expect.any(String),
        amountTHB: '1000.00',
        currency: 'THB',
        status: 'PENDING',
        message: 'Keep building thoughtful tools.',
      });
      expect(response.body.checkout).toMatchObject({
        mode: 'payment',
        amountTHB: '1000.00',
        currency: 'THB',
      });
      expect(response.body.checkout.id).toMatch(/^cs_mock_/);
      expect(response.body.checkout.paymentIntentId).toMatch(/^pi_mock_/);
      expect(response.body.checkout.url).toContain('mock_checkout=ready');

      const stored = await testPrisma.donation.findUnique({
        where: { id: response.body.donation.id },
      });
      expect(stored?.stripePaymentId).toBe(response.body.checkout.paymentIntentId);
    });

    it('rejects invalid donation amounts and requires account ownership', async () => {
      await request(app)
        .post('/api/donate/create')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ amountTHB: '-25.00' })
        .expect(400);
      await request(app)
        .post('/api/donate/create')
        .send({ amountTHB: '100.00' })
        .expect(401);
    });

    it('creates a mock customer portal session for the authenticated account', async () => {
      const response = await request(app)
        .post('/api/billing/portal')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({})
        .expect(200);
      expect(response.body.portal.id).toMatch(/^bps_mock_/);
      expect(response.body.portal.customerId).toMatch(/^cus_mock_/);
    });

    it('verifies signed raw Stripe webhook payloads and settles a donation idempotently', async () => {
      const pendingDonation = await testPrisma.donation.findFirstOrThrow({
        orderBy: { createdAt: 'desc' },
      });

      const payload = JSON.stringify({
        id: 'evt_mock_donation_succeeded',
        type: 'checkout.session.completed',
        created: Math.floor(Date.now() / 1000),
        data: {
          object: {
            id: 'cs_mock_completed',
            payment_intent: pendingDonation.stripePaymentId,
            metadata: { donationId: pendingDonation.id, userId: pendingDonation.userId },
          },
        },
      });
      const signature = signMockStripePayload(payload);
      const response = await request(app)
        .post('/api/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', signature)
        .send(payload)
        .expect(200);

      expect(response.body).toMatchObject({ received: true, handled: true });
      await request(app)
        .post('/api/webhooks/stripe')
        .set('Content-Type', 'application/json')
        .set('Stripe-Signature', signature)
        .send(payload)
        .expect(200);
      const settled = await testPrisma.donation.findUniqueOrThrow({
        where: { id: pendingDonation.id },
      });
      expect(settled.status).toBe('SUCCEEDED');
    });

    it('uses Decimal.js totals for the community goal and automatically queues the Pro-year donor reward', async () => {
      const user = await testPrisma.user.findUniqueOrThrow({ where: { email: 'investora@wealthos.th' } });
      await testPrisma.donation.create({
        data: { userId: user.id, amountTHB: '1784.00', status: 'SUCCEEDED', currency: 'THB' },
      });
      await testPrisma.donation.create({
        data: { userId: user.id, amountTHB: '9999.99', status: 'PENDING', currency: 'THB' },
      });

      const community = await request(app).get('/api/billing/community').expect(200);
      expect(community.body).toMatchObject({
        baselineTHB: '127450.00',
        successfulDonationsTHB: '2784.00',
        totalRaisedTHB: '130234.00',
        targetTHB: '500000.00',
        successfulDonationCount: 2,
      });

      const reward = await request(app)
        .get('/api/billing/early-bird/status')
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      expect(reward.body.donorProYear).toMatchObject({
        donatedTHB: '2784.00',
        thresholdTHB: '2784.00',
        eligible: true,
        durationMonths: 12,
        status: 'QUEUED_FOR_SUBSCRIPTION_LAUNCH',
        startsWhen: 'SUBSCRIPTION_LAUNCH',
        autoGranted: true,
      });
      const persistedQualification = await testPrisma.user.findUniqueOrThrow({ where: { id: user.id } });
      expect(persistedQualification.proYearRewardQualifiedAt).toBeInstanceOf(Date);
    });

    it('reserves a no-charge trial and claims Early-Bird once, ending the discount on cancellation', async () => {
      const previousMode = process.env['OPEN_BETA_MODE'];
      process.env['OPEN_BETA_MODE'] = 'true';
      const user = await testPrisma.user.findUniqueOrThrow({ where: { email: 'investora@wealthos.th' } });
      try {
        const trial = await request(app)
          .post('/api/billing/trial/reserve')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(201);
        expect(trial.body.trial).toMatchObject({
          reserved: true,
          status: 'RESERVED_FOR_SUBSCRIPTION_LAUNCH',
          durationDays: 14,
          startsWhen: 'SUBSCRIPTION_LAUNCH',
          chargesEnabled: false,
        });
        await request(app)
          .post('/api/billing/trial/reserve')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(200);

        const claim = await request(app)
          .post('/api/billing/early-bird/claim')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(201);
        expect(claim.body.earlyBird).toMatchObject({
          claimed: true,
          discountActive: true,
          discountPercentage: 30,
          lifetimeDiscount: true,
          endsOnCancellation: true,
        });
        await request(app)
          .post('/api/billing/early-bird/claim')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(200);

        const claimedPricing = await request(app)
          .get('/api/billing/pricing')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(200);
        expect(claimedPricing.body.pricing.earlyBird).toMatchObject({ claimed: true, discountActive: true });
        expect(claimedPricing.body.pricing.tiers.find((tier: { tier: string }) => tier.tier === 'PRO')?.earlyBirdMonthlyPriceTHB).toBe('203.00');

        const cancelPayload = JSON.stringify({
          id: 'evt_mock_early_bird_subscription_canceled',
          type: 'customer.subscription.deleted',
          created: Math.floor(Date.now() / 1000),
          data: {
            object: {
              id: 'sub_mock_early_bird',
              metadata: { userId: user.id, tier: 'PRO' },
            },
          },
        });
        await request(app)
          .post('/api/webhooks/stripe')
          .set('Content-Type', 'application/json')
          .set('Stripe-Signature', signMockStripePayload(cancelPayload))
          .send(cancelPayload)
          .expect(200);

        const canceledPricing = await request(app)
          .get('/api/billing/pricing')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(200);
        expect(canceledPricing.body.pricing.earlyBird).toMatchObject({
          claimed: true,
          canceled: true,
          discountActive: false,
        });
        expect(canceledPricing.body.pricing.tiers.find((tier: { tier: string }) => tier.tier === 'PRO')?.earlyBirdMonthlyPriceTHB).toBe('290.00');
        const status = await request(app)
          .get('/api/billing/early-bird/status')
          .set('Authorization', `Bearer ${userAToken}`)
          .expect(200);
        expect(status.body.trial).toMatchObject({ reserved: true, durationDays: 14, chargesEnabled: false });
      } finally {
        if (previousMode === undefined) delete process.env['OPEN_BETA_MODE'];
        else process.env['OPEN_BETA_MODE'] = previousMode;
      }
    });
  });

  describe('Multi-User Portfolio Isolation (/api/portfolios)', () => {
    it('creates and lists portfolios for User A, while blocking User B (403)', async () => {
      const createRes = await request(app)
        .post('/api/portfolios')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ name: 'Global Equity & Crypto THB', baseCurrency: 'THB' })
        .expect(201);

      expect(createRes.body).toMatchObject({
        name: 'Global Equity & Crypto THB',
        baseCurrency: 'THB',
      });
      portfolioId = createRes.body.id;

      const listRes = await request(app)
        .get('/api/portfolios')
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(listRes.body).toHaveLength(1);
      expect(listRes.body[0].id).toBe(portfolioId);

      // Register User B and verify strict multi-tenant isolation
      const userBReg = await request(app)
        .post('/api/auth/register')
        .send({
          email: 'userb@wealthos.th',
          password: 'StrongPassword123!',
          name: 'User B',
        })
        .expect(201);

      userBToken = userBReg.body.token;

      await request(app)
        .get(`/api/portfolios/${portfolioId}`)
        .set('Authorization', `Bearer ${userBToken}`)
        .expect(403);
    });
  });

  describe('Phase 1 Multi-Asset Foundation API', () => {
    const bondExtension = {
      couponRate: '0.05',
      paymentFrequency: 'SEMI_ANNUAL',
      maturityDate: '2028-10-01',
      faceValue: '1000.00',
      accruedInterest: '0.00',
      issuer: 'API Test Bond',
    };

    it('validates dates, enforces portfolio ownership and prevents over-selling before persistence', async () => {
      await request(app).get(`/api/multi-assets/portfolios/${portfolioId}`).expect(401);
      await request(app)
        .get(`/api/multi-assets/portfolios/${portfolioId}`)
        .set('Authorization', `Bearer ${userBToken}`)
        .expect(403);

      const invalidDate = await request(app)
        .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          date: '2026-02-30', symbol: 'BOND-API', assetClass: 'BOND', type: 'BUY', qty: 1,
          price: '1000.00', gross: '1000.00', comm: '0.00', vat: '0.00', net: '1000.00',
          originalCurrency: 'THB', originalNet: '1000.00', fxRate: '1.00', netTHB: '1000.00',
          bondExtension,
        })
        .expect(400);
      expect(invalidDate.body.error.code).toBe('VALIDATION_ERROR');

      const buy = await request(app)
        .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          date: '2026-01-01', symbol: 'BOND-API', assetClass: 'BOND', type: 'BUY', qty: 2,
          price: '1000.00', gross: '2000.00', comm: '0.00', vat: '0.00', net: '2000.00',
          originalCurrency: 'THB', originalNet: '2000.00', fxRate: '1.00', netTHB: '2000.00',
          bondExtension,
        })
        .expect(201);
      expect(buy.body.transaction.assetClass).toBe('BOND');

      const overSell = await request(app)
        .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          date: '2026-01-02', symbol: 'BOND-API', assetClass: 'BOND', type: 'SELL', qty: 3,
          price: '1100.00', gross: '3300.00', comm: '0.00', vat: '0.00', net: '3300.00',
          originalCurrency: 'THB', originalNet: '3300.00', fxRate: '1.00', netTHB: '3300.00',
          bondExtension,
        })
        .expect(400);
      expect(overSell.body.error.message).toContain('exceeds available FIFO quantity');
      expect(await testPrisma.multiAssetTransactionRecord.count({ where: { portfolioId, symbol: 'BOND-API' } })).toBe(1);

      await request(app)
        .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          date: '2026-01-03', symbol: 'BOND-API', assetClass: 'BOND', type: 'SELL', qty: 1,
          price: '1100.00', gross: '1100.00', comm: '0.00', vat: '0.00', net: '1100.00',
          originalCurrency: 'THB', originalNet: '1100.00', fxRate: '1.00', netTHB: '1100.00',
          bondExtension,
        })
        .expect(201);

      await request(app)
        .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          date: '2026-07-01', symbol: 'BOND-API', assetClass: 'BOND', type: 'COUPON', qty: 1,
          price: '50.00', gross: '50.00', comm: '0.00', vat: '0.00', net: '42.50',
          originalCurrency: 'THB', originalNet: '42.50', fxRate: '1.00', netTHB: '42.50',
          bondExtension,
        })
        .expect(201);

      const response = await request(app)
        .get(`/api/multi-assets/portfolios/${portfolioId}?asOfDate=2026-10-27`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      expect(response.body.summary.bonds.totalRealizedGLTHB).toBe('100.00');
      expect(response.body.summary.bonds.couponIncomeTHB).toBe('42.50');
      expect(response.body.summary.bonds.couponWithholdingTaxTHB).toBe('7.50');
      expect(response.body.summary.bonds.positions[0].yieldToMaturity).not.toBeNull();
      expect(response.body.dateOfBirth).toBeNull();
      expect(response.body.lastUpdatedAt.bonds).toEqual(expect.any(String));
      expect(response.body.lastUpdatedAt.funds).toBeNull();
      expect(response.body.lastUpdatedAt.metals).toBeNull();
      expect(response.body.lastUpdatedAt.forex).toBeNull();
    });

    it('blocks deletion that would break FIFO integrity, then allows delete in reverse order', async () => {
      const create = async (type: 'BUY' | 'SELL', date: string, qty: number, gross: string) => {
        const response = await request(app)
          .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
          .set('Authorization', `Bearer ${userAToken}`)
          .send({
            date, symbol: 'DELETE-BOND-API', assetClass: 'BOND', type, qty,
            price: '1000.00', gross, comm: '0.00', vat: '0.00', net: gross,
            originalCurrency: 'THB', originalNet: gross, fxRate: '1.00', netTHB: gross,
            bondExtension,
          })
          .expect(201);
        return response.body.transaction.id as string;
      };
      const buyId = await create('BUY', '2026-03-01', 1, '1000.00');
      const sellId = await create('SELL', '2026-03-02', 1, '1100.00');

      const blockedDelete = await request(app)
        .delete(`/api/multi-assets/portfolios/${portfolioId}/transactions/${buyId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(400);
      expect(blockedDelete.body.error.message).toContain('exceeds available FIFO quantity');
      expect(await testPrisma.multiAssetTransactionRecord.count({ where: { portfolioId, symbol: 'DELETE-BOND-API' } })).toBe(2);

      await request(app)
        .delete(`/api/multi-assets/portfolios/${portfolioId}/transactions/${sellId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      await request(app)
        .delete(`/api/multi-assets/portfolios/${portfolioId}/transactions/${buyId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      expect(await testPrisma.multiAssetTransactionRecord.count({ where: { portfolioId, symbol: 'DELETE-BOND-API' } })).toBe(0);
    });

    it('persists derived FX FIFO gain/loss and per-transaction average cost basis', async () => {
      const buy = await request(app)
        .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          date: '2026-02-01', symbol: 'CASH-USD-API', assetClass: 'FOREX', type: 'BUY', qty: 1000,
          price: '35.00', gross: '35000.00', comm: '0.00', vat: '0.00', net: '35000.00',
          originalCurrency: 'USD', originalNet: '1000.00', fxRate: '35.00', netTHB: '35000.00',
          forexExtension: { fromCurrency: 'USD', toCurrency: 'THB', fxRateAtTransaction: '35.00', realizedFxGainLoss: '0.00' },
        })
        .expect(201);
      expect(buy.body.transaction.forexExtension.avgCostBasisTHB).toBe('35.00000000');

      const sell = await request(app)
        .post(`/api/multi-assets/portfolios/${portfolioId}/transactions`)
        .set('Authorization', `Bearer ${userAToken}`)
        .send({
          date: '2026-02-02', symbol: 'CASH-USD-API', assetClass: 'FOREX', type: 'SELL', qty: 400,
          price: '36.00', gross: '14400.00', comm: '0.00', vat: '0.00', net: '14400.00',
          originalCurrency: 'USD', originalNet: '400.00', fxRate: '36.00', netTHB: '14400.00',
          forexExtension: { fromCurrency: 'USD', toCurrency: 'THB', fxRateAtTransaction: '36.00', realizedFxGainLoss: '0.00' },
        })
        .expect(201);
      expect(sell.body.transaction.forexExtension.realizedFxGainLoss).toBe('400.00');
      expect(sell.body.transaction.forexExtension.avgCostBasisTHB).toBe('35.00000000');

      const response = await request(app)
        .get(`/api/multi-assets/portfolios/${portfolioId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      expect(response.body.summary.forex.totalRealizedFxGainLossTHB).toBe('400.00');
      expect(response.body.summary.forex.balances.find((balance: { currency: string }) => balance.currency === 'USD').amount).toBe('600.00000000');
    });

    it('aggregates physical legacy Gold read-only and excludes Gold futures from the Phase 1 metals dashboard', async () => {
      await testPrisma.goldTransactionRecord.createMany({
        data: [
          {
            portfolioId, date: '2026-05-01', symbol: 'GOLD965-API', assetSubclass: 'PHYSICAL_GOLD',
            weight: '1.0000', weightUnit: 'THAI_BAHT', purity: '96.5', spotPricePerUnit: '40000.00',
            premiumPerUnit: '0.00', commission: '0.00', totalCost: '40000.00', fxRateAtPurchase: '35.00', type: 'BUY',
          },
          {
            portfolioId, date: '2026-05-02', symbol: 'GOZ26-API', assetSubclass: 'GOLD_ONLINE_FUTURES',
            weight: '1.0000', weightUnit: 'TROY_OUNCE', purity: '99.5', spotPricePerUnit: '2600.00',
            premiumPerUnit: '0.00', commission: '0.00', totalCost: '2600.00', fxRateAtPurchase: '35.00', type: 'BUY',
          },
        ],
      });

      const response = await request(app)
        .get(`/api/multi-assets/portfolios/${portfolioId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      expect(response.body.summary.commodities.positions.find((position: { symbol: string }) => position.symbol === 'GOLD965-API')).toBeDefined();
      expect(response.body.summary.commodities.positions.find((position: { symbol: string }) => position.symbol === 'GOZ26-API')).toBeUndefined();
      expect(response.body.transactions.some((transaction: { id: string }) => transaction.id.startsWith('legacy-gold-'))).toBe(false);
    });
  });

  describe('Bloomberg Terminal file adapter & Port sandbox API', () => {
    const tickerCsv = [
      'Trade ID,Ticker,Trade Date,Settlement Date,Side,Quantity,Price,Gross Amount,Commission,Taxes,Net Amount,Currency,Exchange,FX Rate to THB',
      'API-BBG-001,"AAPL US Equity",2026-10-18,2026-10-20,BUY,5,200.00,1000.00,1.00,0.07,1001.07,USD,NASDAQ,33.00',
    ].join('\n');

    it('requires authentication and enforces portfolio ownership', async () => {
      await request(app)
        .post('/api/upload/bloomberg-trades')
        .field('portfolioId', portfolioId)
        .attach('file', Buffer.from(tickerCsv), 'trades.csv')
        .expect(401);

      await request(app)
        .post('/api/upload/bloomberg-trades')
        .set('Authorization', `Bearer ${userBToken}`)
        .field('portfolioId', portfolioId)
        .attach('file', Buffer.from(tickerCsv), 'trades.csv')
        .expect(403);
    });

    it('imports, deduplicates, and exposes Bloomberg CDM trades without touching the protected core engines', async () => {
      const first = await request(app)
        .post('/api/upload/bloomberg-trades')
        .set('Authorization', `Bearer ${userAToken}`)
        .field('portfolioId', portfolioId)
        .attach('file', Buffer.from(tickerCsv), 'bloomberg-terminal.csv')
        .expect(201);
      expect(first.body).toMatchObject({ success: true, importedCount: 1, duplicateCount: 0, totalParsed: 1 });
      expect(first.body.transactions[0]).toMatchObject({
        symbol: 'AAPL', assetClass: 'EQUITY', type: 'BUY', originalCurrency: 'USD',
        fxRate: '33.00000000', netTHB: '33035.31',
      });
      expect(first.body.warnings.join(' ')).toContain('not a direct or official Bloomberg');

      const duplicate = await request(app)
        .post('/api/upload/bloomberg-trades')
        .set('Authorization', `Bearer ${userAToken}`)
        .field('portfolioId', portfolioId)
        .attach('file', Buffer.from(tickerCsv), 'bloomberg-terminal.csv')
        .expect(200);
      expect(duplicate.body).toMatchObject({ importedCount: 0, duplicateCount: 1, totalParsed: 1 });
      expect(await testPrisma.multiAssetTransactionRecord.count({ where: { portfolioId, symbol: 'AAPL' } })).toBe(1);

      const portfolioResponse = await request(app)
        .get(`/api/multi-assets/portfolios/${portfolioId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      expect(portfolioResponse.body.transactions.some((transaction: { symbol: string }) => transaction.symbol === 'AAPL')).toBe(true);
    });

    it('requires explicit FX rather than applying synthetic rates to foreign Bloomberg rows', async () => {
      const csvWithoutFx = [
        'Trade ID,Ticker,Trade Date,Side,Quantity,Price,Gross Amount,Currency',
        'API-BBG-NO-FX,"MSFT US Equity",2026-10-18,BUY,1,10.00,10.00,USD',
      ].join('\n');
      const response = await request(app)
        .post('/api/upload/bloomberg-trades')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ portfolioId, csvContent: csvWithoutFx })
        .expect(400);
      expect(response.body.error.code).toBe('BLOOMBERG_FX_RATE_REQUIRED');
      expect(await testPrisma.multiAssetTransactionRecord.count({ where: { portfolioId, symbol: 'MSFT' } })).toBe(0);
    });

    it('parses corporate actions for preview only and provides the explicit empty Port mock status', async () => {
      const actionRes = await request(app)
        .post('/api/upload/bloomberg-corporate-actions')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ csvContent: 'Ticker,Action Type,Effective Date,Announcement Date,Ratio\nAAPL US Equity,Stock Split,2026-10-20,2026-10-01,2:1' })
        .expect(200);
      expect(actionRes.body).toMatchObject({ success: true, previewOnly: true, count: 1 });
      expect(actionRes.body.corporateActions[0].ratio).toBe('2:1');

      const tickerRes = await request(app)
        .post('/api/bloomberg/tickers/parse')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ ticker: 'US000361AQ64 Corp' })
        .expect(200);
      expect(tickerRes.body.ticker).toMatchObject({ symbol: 'US000361AQ64', market: '', assetType: 'Corp' });

      const portRes = await request(app)
        .post('/api/connect/bloomberg-port')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ portfolioId, environment: 'SANDBOX' })
        .expect(200);
      expect(portRes.body).toMatchObject({
        environment: 'SANDBOX', mode: 'SANDBOX_MOCK', connected: false, liveEnabled: false,
        positions: [], trades: [], corporateActions: [],
      });

      const liveRes = await request(app)
        .post('/api/connect/bloomberg-port')
        .set('Authorization', `Bearer ${userAToken}`)
        .send({ portfolioId, environment: 'LIVE' })
        .expect(501);
      expect(liveRes.body.error.code).toBe('BLOOMBERG_PORT_LIVE_NOT_CONFIGURED');
    });
  });

  describe('Advanced asset quant APIs', () => {
    const auth = () => ({ Authorization: `Bearer ${userAToken}` });

    it('requires authentication for every advanced-asset calculator', async () => {
      await request(app)
        .post('/api/advanced-assets/options/pricing')
        .send({})
        .expect(401);
      await request(app)
        .post('/api/advanced-assets/options/chain')
        .send({ symbol: 'AAPL' })
        .expect(401);
    });

    it('prices options and solves implied volatility using decimal-string inputs', async () => {
      const pricing = await request(app)
        .post('/api/advanced-assets/options/pricing')
        .set(auth())
        .send({
          underlyingPrice: '100', strikePrice: '100', timeToExpiry: '0.25',
          riskFreeRate: '0.05', volatility: '0.20', optionType: 'CALL',
        })
        .expect(200);
      expect(pricing.body.result).toMatchObject({
        theoreticalPrice: '4.6150', delta: '0.5695',
      });
      expect(pricing.body.result.gamma).toBeDefined();
      expect(pricing.body.result.theta).toBeDefined();
      expect(pricing.body.result.vega).toBeDefined();
      expect(pricing.body.result.rho).toBeDefined();

      const impliedVolatility = await request(app)
        .post('/api/advanced-assets/options/implied-volatility')
        .set(auth())
        .send({
          marketPrice: '4.6150', underlyingPrice: '100', strikePrice: '100',
          timeToExpiry: '0.25', riskFreeRate: '0.05', optionType: 'CALL',
        })
        .expect(200);
      expect(new Decimal(impliedVolatility.body.result.impliedVolatility).minus('0.2').abs().lte('0.00001')).toBe(true);
    });

    it('calculates option expiry payoff and rejects unknown request fields', async () => {
      const payoff = await request(app)
        .post('/api/advanced-assets/options/payoff')
        .set(auth())
        .send({ optionType: 'CALL', strikePrice: '100', underlyingPriceAtExpiry: '120', premium: '5', contractSize: 100 })
        .expect(200);
      expect(payoff.body.result.payoff).toBe('1500.00');

      await request(app)
        .post('/api/advanced-assets/options/pricing')
        .set(auth())
        .send({ underlyingPrice: '100', strikePrice: '100', timeToExpiry: '0.25', riskFreeRate: '0.05', volatility: '0.20', optionType: 'CALL', unsafe: true })
        .expect(400);
    });

    it('builds AAPL and SPY sample chains with five strikes across three expiries', async () => {
      const aapl = await request(app)
        .post('/api/advanced-assets/options/chain')
        .set(auth())
        .send({ symbol: 'AAPL', asOfDate: '2026-10-27' })
        .expect(200);

      expect(aapl.body.result).toMatchObject({
        symbol: 'AAPL', underlyingPrice: '238.00', currency: 'USD', source: 'ILLUSTRATIVE_MODEL',
      });
      expect(aapl.body.result.expiries.map((expiry: { expiryDate: string }) => expiry.expiryDate)).toEqual([
        '2026-12-18', '2027-01-15', '2027-03-19',
      ]);
      for (const expiry of aapl.body.result.expiries as Array<{ quotes: Array<Record<string, string>> }>) {
        expect(expiry.quotes).toHaveLength(5);
        for (const quote of expiry.quotes) {
          expect(new Decimal(quote.callBid ?? '0').lte(quote.callAsk ?? '0')).toBe(true);
          expect(new Decimal(quote.putBid ?? '0').lte(quote.putAsk ?? '0')).toBe(true);
          expect(quote.callDelta).toMatch(/^-?\d+\.\d{4}$/);
          expect(quote.putDelta).toMatch(/^-?\d+\.\d{4}$/);
        }
      }
      expect(aapl.body.result.expiries[0].quotes.find((quote: { strike: string }) => quote.strike === '240.00')?.callMoneyness).toBe('ATM');

      const spy = await request(app)
        .post('/api/advanced-assets/options/chain')
        .set(auth())
        .send({ symbol: 'SPY', asOfDate: '2026-10-27' })
        .expect(200);
      expect(spy.body.result.expiries[0].quotes.find((quote: { strike: string }) => quote.strike === '610.00')?.putMoneyness).toBe('ATM');
    });

    it('rejects malformed, expired, and unknown-field options-chain requests', async () => {
      await request(app)
        .post('/api/advanced-assets/options/chain')
        .set(auth())
        .send({ symbol: 'MSFT', asOfDate: '2026-10-27' })
        .expect(400);
      await request(app)
        .post('/api/advanced-assets/options/chain')
        .set(auth())
        .send({ symbol: 'AAPL', asOfDate: '2027-04-01' })
        .expect(400);
      await request(app)
        .post('/api/advanced-assets/options/chain')
        .set(auth())
        .send({ symbol: 'AAPL', asOfDate: '2026-10-27', staleData: false })
        .expect(400);
    });

    it('calculates REIT valuation and distribution schedule', async () => {
      const valuation = await request(app)
        .post('/api/advanced-assets/reits/valuation')
        .set(auth())
        .send({ navPerUnit: '12', marketPrice: '10', annualDistributionPerUnit: '0.6', ffoPerUnit: '1', maintenanceCapexPerUnit: '0.1' })
        .expect(200);
      expect(valuation.body.result).toMatchObject({
        premiumDiscount: '-0.1667', distributionYield: '0.0600', capRate: '0.0500', affoPerUnit: '0.9000', capRateIsProxy: true,
      });

      const schedule = await request(app)
        .post('/api/advanced-assets/reits/distribution-schedule')
        .set(auth())
        .send({ annualDistributionPerUnit: '0.65', frequency: 'QUARTERLY', unitsHeld: '30000' })
        .expect(200);
      expect(schedule.body.result).toMatchObject({ periodAmount: '4875.00', annualTotal: '19500.00', periodsPerYear: 4, paymentDates: [] });
    });

    it('calculates PE XIRR, fund multiples and J-curve points', async () => {
      const cashFlows = [
        { date: '2020-01-01', amount: '-100', type: 'CALL' },
        { date: '2020-12-31', amount: '110', type: 'DISTRIBUTION' },
      ];
      const irr = await request(app)
        .post('/api/advanced-assets/private-equity/irr')
        .set(auth())
        .send({ cashFlows })
        .expect(200);
      expect(irr.body.result.irr).toBe('0.100000');

      const metrics = await request(app)
        .post('/api/advanced-assets/private-equity/metrics')
        .set(auth())
        .send({ committedCapital: '150', calledCapital: '110', investedCapital: '100', distributedCapital: '20', residualValue: '100', cashFlows })
        .expect(200);
      expect(metrics.body.result).toMatchObject({ tvpi: '1.2000', dpi: '0.2000', rvpi: '1.0000', moic: '1.2000', irr: '0.100000' });

      const jCurve = await request(app)
        .post('/api/advanced-assets/private-equity/j-curve')
        .set(auth())
        .send({ cashFlows })
        .expect(200);
      expect(jCurve.body.result.points).toHaveLength(2);
      expect(jCurve.body.result.points[1].cumulativeCashFlow).toBe('10.00');
    });

    it('calculates Futures margin health, MTM and liquidation price', async () => {
      const position = {
        id: 's50-risk-test', symbol: 'S50Z26', side: 'LONG', qty: '8',
        entryPrice: '870', markPrice: '886', contractSize: '200', multiplier: '1',
        initialMargin: '150000', maintenanceMargin: '120000',
      };
      const health = await request(app)
        .post('/api/advanced-assets/futures/margin-health')
        .set(auth())
        .send({ positions: [position], accountBalance: '1080000' })
        .expect(200);
      expect(health.body.result).toMatchObject({ status: 'DANGER', marginLevel: '115.17', availableMargin: '-94400.00' });

      const markToMarket = await request(app)
        .post('/api/advanced-assets/futures/mark-to-market')
        .set(auth())
        .send({ side: 'LONG', qty: '8', entryPrice: '870', markPrice: '886', contractSize: '200', multiplier: '1' })
        .expect(200);
      expect(markToMarket.body.result.unrealizedPnL).toBe('25600.00');

      const liquidation = await request(app)
        .post('/api/advanced-assets/futures/liquidation-price')
        .set(auth())
        .send({ side: 'LONG', entryPrice: '870', initialMarginPerContract: '150000', maintenanceMarginPerContract: '120000', multiplier: '1', qty: '8', contractSize: '200' })
        .expect(200);
      expect(liquidation.body.result.liquidationPrice).toBe('720.0000');
    });
  });

  describe('Plan limits outside Open Beta', () => {
    it('enforces one FREE portfolio and 50 transactions per calendar year', async () => {
      const previousMode = process.env['OPEN_BETA_MODE'];
      const registration = await request(app)
        .post('/api/auth/register')
        .send({ email: 'free-limit-user@wealthos.th', password: 'StrongPassword123!', name: 'Free Plan User' })
        .expect(201);
      const freeUser = await testPrisma.user.findUniqueOrThrow({
        where: { email: 'free-limit-user@wealthos.th' },
      });
      await testPrisma.user.update({
        where: { id: freeUser.id },
        data: { isBetaAllAccess: false },
      });
      process.env['OPEN_BETA_MODE'] = 'false';

      try {
        const firstPortfolio = await request(app)
          .post('/api/portfolios')
          .set('Authorization', `Bearer ${registration.body.token}`)
          .send({ name: 'Free plan portfolio', baseCurrency: 'THB' })
          .expect(201);

        const limitedPortfolio = await request(app)
          .post('/api/portfolios')
          .set('Authorization', `Bearer ${registration.body.token}`)
          .send({ name: 'Second free plan portfolio', baseCurrency: 'THB' })
          .expect(403);
        expect(limitedPortfolio.body.error.code).toBe('SUBSCRIPTION_LIMIT_REACHED');

        await testPrisma.transaction.createMany({
          data: Array.from({ length: 50 }, (_, index) => ({
            portfolioId: firstPortfolio.body.id,
            date: `2026-${String((index % 12) + 1).padStart(2, '0')}-01`,
            symbol: `TEST${index}`,
            type: 'BUY',
            exchange: 'TEST',
            qty: 1,
            price: 1,
            gross: '1.00',
            comm: '0.00',
            vat: '0.00',
            net: '1.00',
            originalCurrency: 'THB',
          })),
        });

        await expect(
          assertTransactionDatesWithinAnnualLimit(freeUser.id, ['2026-12-31'])
        ).rejects.toMatchObject({ code: 'SUBSCRIPTION_LIMIT_REACHED' });
        await expect(
          assertTransactionDatesWithinAnnualLimit(freeUser.id, ['2025-12-31'])
        ).resolves.toBeUndefined();
      } finally {
        await testPrisma.user.delete({ where: { id: freeUser.id } });
        if (previousMode === undefined) delete process.env['OPEN_BETA_MODE'];
        else process.env['OPEN_BETA_MODE'] = previousMode;
      }
    });
  });

  describe('CSV Upload, FX Enrichment & Transactions (/api/upload & /api/transactions)', () => {
    it('uploads IBKR & Bitkub CSVs, enriches FX to THB, and returns FIFO summary', async () => {
      const ibkrCSV = [
        'TradeDate,Symbol,Quantity,TradePrice,Commission,NetAmount,Currency',
        '20241001,AAPL,10,150.50,1.00,-1506.00,USD',
        '20241010,AAPL,-5,160.00,1.00,799.00,USD',
      ].join('\n');

      const ibkrRes = await request(app)
        .post('/api/upload/csv')
        .set('Authorization', `Bearer ${userAToken}`)
        .field('portfolioId', portfolioId)
        .field('exchange', 'IBKR')
        .attach('file', Buffer.from(ibkrCSV, 'utf8'), 'ibkr_trades.csv')
        .expect(201);

      expect(ibkrRes.body.transactions).toHaveLength(2);
      expect(ibkrRes.body.transactions[0]).toMatchObject({
        symbol: 'AAPL',
        type: 'BUY',
        originalCurrency: 'USD',
        fxRate: '36.75',
        netTHB: '55345.50',
      });
      expect(ibkrRes.body.summary.totalRealizedGL).toBe(1570.65);
      expect(ibkrRes.body.uploadedFile.type).toBe('CSV');

      const bitkubCSV = [
        'วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม',
        '2024-10-01 10:00:00,ซื้อ,BTC/THB,2000000,0.001,2000,10',
        '2024-10-05 14:30:00,ขาย,BTC/THB,2100000,0.0005,1050,5.25',
      ].join('\n');

      const bitkubRes = await request(app)
        .post('/api/upload/csv')
        .set('Authorization', `Bearer ${userAToken}`)
        .field('portfolioId', portfolioId)
        .field('exchange', 'BITKUB')
        .attach('file', Buffer.from(bitkubCSV, 'utf8'), 'bitkub_trades.csv')
        .expect(201);

      // Combined portfolio Realized G/L = 1,570.65 (AAPL) + 39.75 (BTC) = 1,610.40 THB
      expect(bitkubRes.body.summary.totalRealizedGL).toBe(1610.4);
    });

    it('retrieves portfolio transactions with optional query filters', async () => {
      const allTxRes = await request(app)
        .get(`/api/transactions/${portfolioId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(allTxRes.body).toHaveLength(4);

      const filteredRes = await request(app)
        .get(`/api/transactions/${portfolioId}?symbol=AAPL&type=BUY`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(filteredRes.body).toHaveLength(1);
      expect(filteredRes.body[0].symbol).toBe('AAPL');
    });

    it('returns an authenticated mobile dashboard summary using existing FIFO summaries', async () => {
      await request(app).get('/api/mobile/dashboard-summary').expect(401);

      const response = await request(app)
        .get('/api/mobile/dashboard-summary')
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(response.body).toMatchObject({
        currency: 'THB',
        valuationBasis: 'LATEST_RECORDED_TRANSACTION_PRICE',
      });
      expect(response.body.summary.portfolioCount).toBeGreaterThanOrEqual(1);
      expect(Array.isArray(response.body.portfolios)).toBe(true);
      expect(Array.isArray(response.body.allocation)).toBe(true);
      expect(Array.isArray(response.body.recentTransactions)).toBe(true);
    });

    it('paginates mobile transactions with stable cursors and enforces portfolio ownership', async () => {
      const firstPage = await request(app)
        .get(`/api/mobile/transactions/${portfolioId}?limit=2`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(firstPage.body.items).toHaveLength(2);
      expect(firstPage.body.hasMore).toBe(true);
      expect(typeof firstPage.body.nextCursor).toBe('string');

      const secondPage = await request(app)
        .get(`/api/mobile/transactions/${portfolioId}?limit=2&cursor=${encodeURIComponent(firstPage.body.nextCursor as string)}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);
      const firstIds = (firstPage.body.items as Array<{ id: string }>).map((item) => item.id);
      const secondIds = (secondPage.body.items as Array<{ id: string }>).map((item) => item.id);
      expect(secondIds).toHaveLength(2);
      expect(secondIds.some((id) => firstIds.includes(id))).toBe(false);

      await request(app)
        .get(`/api/mobile/transactions/${portfolioId}?limit=2`)
        .set('Authorization', `Bearer ${userBToken}`)
        .expect(403);
    });

    it('uploads Dividend CSV and enriches to THB', async () => {
      const divCSV = [
        'Date,Symbol,Qty,Div/Share,Gross,Tax,Net',
        '2024-10-15,A,3,1.02,3.06,0.93,2.13',
      ].join('\n');

      const divRes = await request(app)
        .post('/api/upload/dividends')
        .set('Authorization', `Bearer ${userAToken}`)
        .field('portfolioId', portfolioId)
        .attach('file', Buffer.from(divCSV, 'utf8'), 'dividends_2024.csv')
        .expect(201);

      expect(divRes.body.count).toBe(1);
      expect(divRes.body.dividends[0]).toMatchObject({
        symbol: 'A',
        grossTHB: '3.06',
        whtTHB: '0.93',
        netTHB: '2.13',
      });
    });
  });

  describe('Thai Tax Summary & 5-Page PDF Tax Report (/api/tax)', () => {
    it('computes annual Thai Tax Summary JSON via GET /api/tax/summary/:portfolioId/:year', async () => {
      const summaryRes = await request(app)
        .get(`/api/tax/summary/${portfolioId}/2024`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      // Total Taxable Income = 1,610.40 (Capital Gains) + 3.06 (Gross Dividend) = 1,613.46 THB
      // Total WHT = 0.93 THB; <= 150,000 THB exempt bracket => Net Tax Payable = -0.93 THB
      expect(summaryRes.body).toMatchObject({
        taxYear: 2024,
        totalTaxableIncome: '1613.46',
        totalTaxWithheld: '0.93',
        totalTaxPayable: '-0.93',
      });
    });

    it('streams a valid 5-page PDF Tax Report via GET /api/tax/report/:portfolioId/:year', async () => {
      const pdfRes = await request(app)
        .get(`/api/tax/report/${portfolioId}/2024`)
        .set('Authorization', `Bearer ${userAToken}`)
        .buffer(true)
        .parse((res, callback) => {
          const chunks: Buffer[] = [];
          res.on('data', (chunk: Buffer) => chunks.push(chunk));
          res.on('end', () => callback(null, Buffer.concat(chunks)));
        })
        .expect(200);

      expect(pdfRes.headers['content-type']).toContain('application/pdf');
      expect(pdfRes.headers['content-disposition']).toContain(
        'FIFO_Wealth_OS_Tax_Report_2024.pdf'
      );

      const pdfBuffer = pdfRes.body as Buffer;
      expect(Buffer.isBuffer(pdfBuffer)).toBe(true);
      expect(pdfBuffer.subarray(0, 5).toString('ascii')).toBe('%PDF-');

      const pageMatches = pdfBuffer.toString('latin1').match(/\/Type\s*\/Page\b(?!s)/g);
      expect(pageMatches?.length).toBe(5);

      // Verify UploadedFile ('PDF') audit record was stored in DB
      const pdfAuditRecords = await testPrisma.uploadedFile.findMany({
        where: { portfolioId, type: 'PDF' },
      });
      expect(pdfAuditRecords).toHaveLength(1);
    }, 20000);

    it('computes quantitative portfolio metrics & benchmark series via GET /api/analytics/dashboard', async () => {
      const spRes = await request(app)
        .get('/api/analytics/dashboard?benchmark=SP500')
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(spRes.body.benchmark).toBe('SP500');
      expect(spRes.body.metrics).toEqual(
        expect.objectContaining({
          xirr: expect.any(String),
          twr: expect.any(String),
          sharpeRatio: expect.any(String),
          sortinoRatio: expect.any(String),
          maxDrawdown: expect.any(String),
          totalReturn: expect.any(String),
        })
      );
      expect(spRes.body.benchmarkSeries).toHaveLength(6);
      expect(spRes.body.assetAllocation).toHaveLength(5);

      const set50Res = await request(app)
        .get(`/api/analytics/dashboard?benchmark=SET50&portfolioId=${portfolioId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      expect(set50Res.body.benchmark).toBe('SET50');
      expect(set50Res.body.scope).toBe(portfolioId);
    });

    it('deletes portfolio and cascades child records via DELETE /api/portfolios/:id', async () => {
      await request(app)
        .delete(`/api/portfolios/${portfolioId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(200);

      await request(app)
        .get(`/api/portfolios/${portfolioId}`)
        .set('Authorization', `Bearer ${userAToken}`)
        .expect(404);
    });
  });
});
