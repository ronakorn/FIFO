import request from 'supertest';
import { createApp } from '../app';
import { getPrismaClient } from '../../db/prisma';

describe('FIFO Wealth OS - AI Wealth Assistant, Wealth Journal & Family Wealth Module', () => {
  const app = createApp();
  const prisma = getPrismaClient();

  let ownerToken = '';
  let ownerId = '';
  let ownerPortfolioId = '';

  let viewerToken = '';
  let viewerId = '';
  let viewerPortfolioId = '';

  let outsiderToken = '';
  let outsiderId = '';

  let inviteCode = '';
  let familyGroupId = '';

  beforeAll(async () => {
    const suffix = Date.now();

    // 1. Register Owner (Somchai - 600,000 THB BTC holding -> 60.00%)
    const regOwner = await request(app)
      .post('/api/auth/register')
      .send({
        email: `somchai.${suffix}@wealthos.th`,
        password: 'Password123!',
        name: 'สมชาย มั่งคั่ง',
      });
    expect(regOwner.status).toBe(201);
    ownerToken = regOwner.body.token;
    ownerId = regOwner.body.user.id;

    const ownerPortRes = await request(app)
      .post('/api/portfolios')
      .set('Authorization', `Bearer ${ownerToken}`)
      .send({ name: 'Somchai Core Portfolio', baseCurrency: 'THB' });
    expect(ownerPortRes.status).toBe(201);
    ownerPortfolioId = ownerPortRes.body.id;

    // Upload trades: Buy 0.4 BTC @ 2,000,000, Sell 0.1 BTC @ 2,000,000 in 2024-10 => Remaining 0.3 BTC @ 2,000,000 = 600,000.00 THB
    // Also add profitable sell in 2024-10 so AI Assistant identifies 2024-10 as best month!
    const ownerCsv = [
      'วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม',
      '2024-10-01 10:00:00,ซื้อ,BTC/THB,1800000,0.4,720000,0',
      '2024-10-15 14:00:00,ขาย,BTC/THB,2000000,0.1,200000,0',
    ].join('\n');

    const upOwner = await request(app)
      .post('/api/upload/csv')
      .set('Authorization', `Bearer ${ownerToken}`)
      .field('portfolioId', ownerPortfolioId)
      .field('exchange', 'BITKUB')
      .attach('file', Buffer.from(ownerCsv, 'utf8'), 'somchai.csv');
    expect(upOwner.status).toBe(201);

    // 2. Register Viewer Spouse (Somying - 400,000 THB BTC holding -> 40.00%)
    const regViewer = await request(app)
      .post('/api/auth/register')
      .send({
        email: `somying.${suffix}@wealthos.th`,
        password: 'Password123!',
        name: 'สมหญิง มั่งคั่ง',
      });
    expect(regViewer.status).toBe(201);
    viewerToken = regViewer.body.token;
    viewerId = regViewer.body.user.id;

    const viewerPortRes = await request(app)
      .post('/api/portfolios')
      .set('Authorization', `Bearer ${viewerToken}`)
      .send({ name: 'Somying Core Portfolio', baseCurrency: 'THB' });
    expect(viewerPortRes.status).toBe(201);
    viewerPortfolioId = viewerPortRes.body.id;

    const viewerCsv = [
      'วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม',
      '2024-10-02 11:00:00,ซื้อ,BTC/THB,2000000,0.2,400000,0',
    ].join('\n');

    const upViewer = await request(app)
      .post('/api/upload/csv')
      .set('Authorization', `Bearer ${viewerToken}`)
      .field('portfolioId', viewerPortfolioId)
      .field('exchange', 'BITKUB')
      .attach('file', Buffer.from(viewerCsv, 'utf8'), 'somying.csv');
    expect(upViewer.status).toBe(201);

    // 3. Register Outsider
    const regOutsider = await request(app)
      .post('/api/auth/register')
      .send({
        email: `outsider.${suffix}@wealthos.th`,
        password: 'Password123!',
        name: 'บุคคลภายนอก',
      });
    expect(regOutsider.status).toBe(201);
    outsiderToken = regOutsider.body.token;
    outsiderId = regOutsider.body.user.id;
  });

  afterAll(async () => {
    await prisma.user.deleteMany({
      where: { id: { in: [ownerId, viewerId, outsiderId].filter(Boolean) } },
    });
  });

  describe('1. Wealth Journal API (/api/journal)', () => {
    let createdEntryId = '';

    it('creates journal entries with mood & portfolio link via POST /api/journal', async () => {
      const resOct = await request(app)
        .post('/api/journal')
        .set('Authorization', `Bearer ${ownerToken}`)
        .send({
          portfolioId: ownerPortfolioId,
          date: '2026-10-26',
          title: 'ทำกำไรบางส่วน BTC ตามเป้า',
          content: 'แบ่งขาย 0.1 BTC ที่ 2,000,000 บาท ล็อกกำไร 20,000 บาทเข้าแผน FIRE',
          mood: 'BULLISH',
        })
        .expect(201);

      expect(resOct.body).toMatchObject({
        userId: ownerId,
        portfolioId: ownerPortfolioId,
        portfolioName: 'Somchai Core Portfolio',
        date: '2026-10-26',
        mood: 'BULLISH',
      });
      createdEntryId = resOct.body.id;

      await request(app)
        .post('/api/journal')
        .set('Authorization', `Bearer ${ownerToken}`)
        .send({
          date: '2026-09-12',
          title: 'ตลาดพักฐานเดือนกันยายน',
          content: 'ถือเงินสดรอดูท่าทีดอกเบี้ย',
          mood: 'BEARISH',
        })
        .expect(201);
    });

    it('queries journal entries accurately by month (YYYY-MM and MM) via GET /api/journal', async () => {
      const octByYearMonth = await request(app)
        .get('/api/journal?month=2026-10')
        .set('Authorization', `Bearer ${ownerToken}`)
        .expect(200);

      expect(octByYearMonth.body).toHaveLength(1);
      expect(octByYearMonth.body[0].id).toBe(createdEntryId);
      expect(octByYearMonth.body[0].mood).toBe('BULLISH');

      const sepByShortMonth = await request(app)
        .get('/api/journal?month=09')
        .set('Authorization', `Bearer ${ownerToken}`)
        .expect(200);

      expect(sepByShortMonth.body).toHaveLength(1);
      expect(sepByShortMonth.body[0].mood).toBe('BEARISH');

      // Viewer must not see Owner's journal entries
      const viewerJournal = await request(app)
        .get('/api/journal?month=2026-10')
        .set('Authorization', `Bearer ${viewerToken}`)
        .expect(200);

      expect(viewerJournal.body).toHaveLength(0);
    });
  });

  describe('2. AI Wealth Assistant RAG API (/api/ai/chat)', () => {
    it('answers "เดือนไหนกำไรสุด" using live FIFO analytics & persists ChatSession', async () => {
      const thRes = await request(app)
        .post('/api/ai/chat')
        .set('Authorization', `Bearer ${ownerToken}`)
        .send({
          message: 'เดือนไหนกำไรสุด สรุปให้หน่อย',
          locale: 'th',
        })
        .expect(200);

      expect(thRes.body.sessionId).toBeDefined();
      expect(thRes.body.contextSummary.bestMonth).toBe('2024-10');
      expect(thRes.body.contextSummary.bestMonthGainTHB).toBe('20000.00');
      expect(thRes.body.reply).toContain('2024-10');
      expect(thRes.body.reply).toContain('20,000.00');
      expect(thRes.body.messages).toHaveLength(2);

      // Follow-up in English within the same ChatSession
      const enRes = await request(app)
        .post('/api/ai/chat')
        .set('Authorization', `Bearer ${ownerToken}`)
        .send({
          sessionId: thRes.body.sessionId,
          message: 'Summarize my portfolio in English',
          locale: 'en',
        })
        .expect(200);

      expect(enRes.body.sessionId).toBe(thRes.body.sessionId);
      expect(enRes.body.messages).toHaveLength(4);
      expect(enRes.body.reply).toContain('630,000.00');
      expect(enRes.body.reply).toContain('20,000.00');
    });
  });

  describe('3. Family Wealth Module & Privacy-First Multi-User Aggregation (/api/family)', () => {
    it('creates a Family Group (OWNER) and allows spouse to join via Invite Code (VIEWER)', async () => {
      const createRes = await request(app)
        .post('/api/family/create')
        .set('Authorization', `Bearer ${ownerToken}`)
        .send({ name: 'ครอบครัวมั่งคั่ง' })
        .expect(201);

      expect(createRes.body.inviteCode).toMatch(/^FAM-[A-Z0-9]{4}-[A-Z0-9]{4}$/);
      expect(createRes.body.role).toBe('OWNER');
      inviteCode = createRes.body.inviteCode;
      familyGroupId = createRes.body.id;

      const joinRes = await request(app)
        .post('/api/family/join')
        .set('Authorization', `Bearer ${viewerToken}`)
        .send({ inviteCode })
        .expect(201);

      expect(joinRes.body.familyGroupId).toBe(familyGroupId);
      expect(joinRes.body.role).toBe('VIEWER');
      expect(joinRes.body.permissions).toEqual({
        canSeeTransactions: false,
        canSeeTotalNetWorth: true,
      });
    });

    it('aggregates Household Net Worth across 2+ Users with exact Decimal.js (60% / 40%) without exposing transactions', async () => {
      const dashRes = await request(app)
        .get('/api/family/dashboard')
        .set('Authorization', `Bearer ${viewerToken}`)
        .expect(200);

      // Somchai (600,000.00 THB) + Somying (400,000.00 THB) = 1,000,000.00 THB exact!
      expect(dashRes.body.hasGroup).toBe(true);
      expect(dashRes.body.householdNetWorthTHB).toBe('1000000.00');
      expect(dashRes.body.memberCount).toBe(2);
      expect(dashRes.body.privacyGuarantee).toEqual({
        transactionsExposed: false,
        aggregationEngine: 'Decimal.js-40',
      });

      const somchai = dashRes.body.members.find(
        (m: { userId: string }) => m.userId === ownerId
      );
      const somying = dashRes.body.members.find(
        (m: { userId: string }) => m.userId === viewerId
      );

      expect(somchai).toMatchObject({
        role: 'OWNER',
        netWorthTHB: '600000.00',
        sharePercent: '60.00',
      });
      expect(somying).toMatchObject({
        role: 'VIEWER',
        netWorthTHB: '400000.00',
        sharePercent: '40.00',
      });

      // Verify raw JSON string does NOT contain any transaction array or trade fields
      expect(somchai.transactions).toBeUndefined();
      expect(JSON.stringify(dashRes.body)).not.toContain('"qty":');
    });

    it('enforces strict Privacy Rules: VIEWER cannot read OWNER transactions (403) and Outsider cannot view family dashboard (403)', async () => {
      // Viewer tries to fetch Owner's raw transactions directly -> MUST return 403 Forbidden
      await request(app)
        .get(`/api/transactions/${ownerPortfolioId}`)
        .set('Authorization', `Bearer ${viewerToken}`)
        .expect(403);

      // Outsider tries to query this familyGroupId -> MUST return 403 Forbidden
      await request(app)
        .get(`/api/family/dashboard?familyGroupId=${familyGroupId}`)
        .set('Authorization', `Bearer ${outsiderToken}`)
        .expect(403);

      // Viewer updates Privacy Toggle via PATCH /api/family/privacy
      const privRes = await request(app)
        .patch('/api/family/privacy')
        .set('Authorization', `Bearer ${viewerToken}`)
        .send({ hideTransactions: true, canSeeTotalNetWorth: true })
        .expect(200);

      expect(privRes.body.permissions).toEqual({
        canSeeTransactions: false,
        canSeeTotalNetWorth: true,
      });
    });
  });
});
