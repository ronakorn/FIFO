import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  buildGoldMarketEnvironment,
  calculateFineGoldGrams,
  calculateGoldFIFO,
  calculateGoldTransactionTotalCost,
  convertGoldWeight,
  convertToEquivalentThaiBaht965,
  GoldDecimal,
  isUsdQuotedSubclass,
  toCleanGoldDecimal,
} from '../services/goldEngine';
import {
  extractClientIp,
  getAuditLogsForUser,
  logAction,
} from '../services/auditLogger';
import { defaultBotFxProvider } from '../services/botFxProvider';
import { executeRollover } from '../services/goldRolloverManager';
import {
  buildPortfolioGoldBrinsonReport,
  calculateGoldPortfolioBreakdown,
  generateGoldFXSensitivityMatrix,
  mapBrinsonItemToGoldFXSensitivity,
} from '../services/goldFxSensitivityEngine';
import {
  GoldAssetSubclass,
  GoldOverviewSummary,
  GoldPurity,
  GoldTransaction,
  GoldWeightUnit,
} from '../types/gold';
import { requireOwnedPortfolio } from './routes/portfolioRoutes';

export const goldRouter = Router();

const DEFAULT_XAU_USD_SPOT = '2740.00';
const DEFAULT_USD_THB_RATE = '35.60';
const DEFAULT_GTA_965_SELL_THB = '46450.00';

const assetSubclassEnum = z.enum([
  'PHYSICAL_GOLD',
  'GOLD_ONLINE_FUTURES',
  'XAU_SPOT',
]);
const weightUnitEnum = z.enum(['THAI_BAHT', 'GRAM', 'TROY_OUNCE']);
const purityEnum = z.enum(['96.5', '99.99', '99.9', '99.5']);

const overviewQuerySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  xauUsdSpot: z.string().optional(),
  usdThbRate: z.string().optional(),
  gtaGold965SellTHB: z.string().optional(),
  goldShockPct: z.string().optional(),
  fxShockPct: z.string().optional(),
  seedIfEmpty: z.enum(['true', 'false']).optional(),
});

const createGoldTxBodySchema = z.object({
  portfolioId: z.string().uuid(),
  date: z.string().trim().min(8),
  symbol: z.string().trim().min(2).max(24),
  assetSubclass: assetSubclassEnum,
  weight: z.string().trim().min(1),
  weightUnit: weightUnitEnum,
  purity: purityEnum,
  spotPricePerUnit: z.string().trim().min(1),
  premiumPerUnit: z.string().trim().default('0'),
  commission: z.string().trim().default('0'),
  fxRateAtPurchase: z.string().trim().optional(),
  type: z.enum(['BUY', 'SELL']),
});

const updateGoldTxBodySchema = z.object({
  date: z.string().trim().min(8).optional(),
  symbol: z.string().trim().min(2).max(24).optional(),
  assetSubclass: assetSubclassEnum.optional(),
  weight: z.string().trim().min(1).optional(),
  weightUnit: weightUnitEnum.optional(),
  purity: purityEnum.optional(),
  spotPricePerUnit: z.string().trim().min(1).optional(),
  premiumPerUnit: z.string().trim().optional(),
  commission: z.string().trim().optional(),
  fxRateAtPurchase: z.string().trim().optional(),
  type: z.enum(['BUY', 'SELL']).optional(),
});

const rolloverPositionBodySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  newContractSymbol: z.string().trim().min(2).max(24),
  newQty: z.string().trim().min(1),
  newPrice: z.string().trim().min(1),
  rolloverFee: z.string().trim().default('0'),
  closePrice: z.string().trim().optional(),
  executionDate: z.string().trim().optional(),
  fxRateAtRollover: z.string().trim().optional(),
});

const botFxQuerySchema = z.object({
  currency: z.string().trim().min(3).max(6).default('USD'),
  date: z.string().trim().min(10),
});

const simulateGoldBodySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  goldShockPct: z.string().default('0'),
  fxShockPct: z.string().default('0'),
  xauUsdSpot: z.string().optional(),
  usdThbRate: z.string().optional(),
  gtaGold965SellTHB: z.string().optional(),
});

const convertWeightQuerySchema = z.object({
  weight: z.string().trim().min(1),
  fromUnit: weightUnitEnum,
  toUnit: weightUnitEnum,
});

function buildDefaultSeedGoldTransactions(portfolioId: string): GoldTransaction[] {
  const createdAt = new Date('2026-10-01T09:00:00.000Z');
  return [
    {
      id: 'seed-gold-965-buy-1',
      portfolioId,
      date: '2026-03-15',
      symbol: 'GOLD965',
      assetSubclass: 'PHYSICAL_GOLD',
      weight: '10.0000',
      weightUnit: 'THAI_BAHT',
      purity: '96.5',
      spotPricePerUnit: '40200.00',
      premiumPerUnit: '250.00',
      commission: '0.00',
      totalCost: '404500.00',
      fxRateAtPurchase: '34.20',
      type: 'BUY',
      createdAt,
    },
    {
      id: 'seed-gold-965-sell-1',
      portfolioId,
      date: '2026-07-20',
      symbol: 'GOLD965',
      assetSubclass: 'PHYSICAL_GOLD',
      weight: '2.0000',
      weightUnit: 'THAI_BAHT',
      purity: '96.5',
      spotPricePerUnit: '43500.00',
      premiumPerUnit: '0.00',
      commission: '0.00',
      totalCost: '87000.00',
      fxRateAtPurchase: '35.10',
      type: 'SELL',
      createdAt,
    },
    {
      id: 'seed-gold-9999-buy-1',
      portfolioId,
      date: '2026-05-10',
      symbol: 'GOLD9999',
      assetSubclass: 'PHYSICAL_GOLD',
      weight: '76.2200', // 5.00 บาททองคำ equivalent in grams (99.99% bullion)
      weightUnit: 'GRAM',
      purity: '99.99',
      spotPricePerUnit: '2760.00',
      premiumPerUnit: '18.00',
      commission: '150.00',
      totalCost: '211829.16',
      fxRateAtPurchase: '34.50',
      type: 'BUY',
      createdAt,
    },
    {
      id: 'seed-xauusd-spot-1',
      portfolioId,
      date: '2026-06-12',
      symbol: 'XAUUSD',
      assetSubclass: 'XAU_SPOT',
      weight: '4.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.99',
      spotPricePerUnit: '2460.00',
      premiumPerUnit: '1.50',
      commission: '8.00',
      totalCost: '9854.00', // USD native -> enriched via fxRateAtPurchase 34.40
      fxRateAtPurchase: '34.40',
      type: 'BUY',
      createdAt,
    },
    {
      id: 'seed-tfex-goz26-1',
      portfolioId,
      date: '2026-08-18',
      symbol: 'GOZ26',
      assetSubclass: 'GOLD_ONLINE_FUTURES',
      weight: '3.0000',
      weightUnit: 'TROY_OUNCE',
      purity: '99.5',
      spotPricePerUnit: '2580.00',
      premiumPerUnit: '2.00',
      commission: '6.00',
      totalCost: '7752.00', // USD notional -> enriched via fxRateAtPurchase 34.75
      fxRateAtPurchase: '34.75',
      type: 'BUY',
      createdAt,
    },
  ];
}

function mapDbRecordToGoldTx(row: {
  id: string;
  portfolioId: string;
  date: string;
  symbol: string;
  assetSubclass: string;
  weight: string;
  weightUnit: string;
  purity: string;
  spotPricePerUnit: string;
  premiumPerUnit: string;
  commission: string;
  totalCost: string;
  fxRateAtPurchase: string;
  type: string;
  createdAt: Date;
}): GoldTransaction {
  return {
    id: row.id,
    portfolioId: row.portfolioId,
    date: row.date,
    symbol: row.symbol,
    assetSubclass: row.assetSubclass as GoldAssetSubclass,
    weight: row.weight,
    weightUnit: row.weightUnit as GoldWeightUnit,
    purity: row.purity as GoldPurity,
    spotPricePerUnit: row.spotPricePerUnit,
    premiumPerUnit: row.premiumPerUnit,
    commission: row.commission,
    totalCost: row.totalCost,
    fxRateAtPurchase: row.fxRateAtPurchase,
    type: row.type as 'BUY' | 'SELL',
    createdAt: row.createdAt,
  };
}

async function resolveUserPortfolioId(
  userId: string,
  requestedPortfolioId?: string
): Promise<string> {
  const prisma = getPrismaClient();
  if (requestedPortfolioId) {
    await requireOwnedPortfolio(requestedPortfolioId, userId);
    return requestedPortfolioId;
  }

  const first = await prisma.portfolio.findFirst({
    where: { userId },
    orderBy: { createdAt: 'asc' },
  });
  if (first) {
    return first.id;
  }

  const created = await prisma.portfolio.create({
    data: {
      userId,
      name: 'Multi-Asset & Gold Bullion Portfolio',
      baseCurrency: 'THB',
    },
  });
  return created.id;
}

function buildOverviewFromTransactions(params: {
  portfolioId: string;
  transactions: GoldTransaction[];
  xauUsdSpot: string;
  usdThbRate: string;
  gtaGold965SellTHB: string;
  goldShockPct: string;
  fxShockPct: string;
}): GoldOverviewSummary {
  const one = new GoldDecimal(1);
  const gShock = toCleanGoldDecimal(params.goldShockPct);
  const fShock = toCleanGoldDecimal(params.fxShockPct);

  const baseXau = toCleanGoldDecimal(params.xauUsdSpot);
  const baseFx = toCleanGoldDecimal(params.usdThbRate);
  const baseGta965 = toCleanGoldDecimal(params.gtaGold965SellTHB);

  const shockedXau = baseXau.times(one.plus(gShock));
  const shockedFx = baseFx.times(one.plus(fShock));
  const shockedGta965 = baseGta965
    .times(one.plus(gShock))
    .times(one.plus(fShock));

  const activeMarket = buildGoldMarketEnvironment({
    xauUsdSpot: shockedXau.toFixed(4),
    usdThbRate: shockedFx.toFixed(6),
    gtaGold965SellTHB: shockedGta965.toFixed(4),
  });

  const baseMarket = buildGoldMarketEnvironment({
    xauUsdSpot: baseXau.toFixed(4),
    usdThbRate: baseFx.toFixed(6),
    gtaGold965SellTHB: baseGta965.toFixed(4),
  });

  const fifo = calculateGoldFIFO(params.transactions, activeMarket);
  const brinsonAttribution = buildPortfolioGoldBrinsonReport(
    fifo.lots,
    params.transactions,
    activeMarket
  );
  const fxSensitivities = brinsonAttribution.unrealizedItems.map(
    mapBrinsonItemToGoldFXSensitivity
  );
  const breakdown = calculateGoldPortfolioBreakdown(fifo.lots, activeMarket);
  const sensitivityMatrix = generateGoldFXSensitivityMatrix(
    params.transactions,
    baseMarket
  );

  let totalEquivBaht965 = new GoldDecimal(0);
  let totalFineGrams = new GoldDecimal(0);
  for (const lot of fifo.lots) {
    if (toCleanGoldDecimal(lot.weightRemain).gt(0)) {
      totalEquivBaht965 = totalEquivBaht965.plus(
        convertToEquivalentThaiBaht965(
          lot.weightRemain,
          lot.weightUnit,
          lot.purity
        )
      );
      totalFineGrams = totalFineGrams.plus(
        calculateFineGoldGrams(lot.weightRemain, lot.weightUnit, lot.purity)
      );
    }
  }

  return {
    portfolioId: params.portfolioId,
    market: activeMarket,
    totalCostBasisTHB: fifo.totalCostBasisTHB,
    totalMarketValueTHB: fifo.totalMarketValueTHB,
    totalRealizedGLTHB: fifo.totalRealizedGLTHB,
    taxExemptRealizedGLTHB: fifo.taxExemptRealizedGLTHB,
    taxableRealizedGLTHB: fifo.taxableRealizedGLTHB,
    totalUnrealizedGLTHB: fifo.totalUnrealizedGLTHB,
    totalPremiumPaidTHB: fifo.totalPremiumPaidTHB,
    premiumDragPct: fifo.premiumDragPct,
    totalEquivalentBaht965: totalEquivBaht965.toFixed(4),
    totalFineGoldGrams: totalFineGrams.toFixed(4),
    lots: fifo.lots,
    taxHandoffRecords: fifo.taxHandoffRecords,
    transactions: params.transactions,
    fxSensitivities,
    brinsonAttribution,
    breakdown,
    sensitivityMatrix,
  };
}

/**
 * GET /api/gold/convert-weight
 * Utility endpoint for converting THAI_BAHT (15.244g) <-> GRAM <-> TROY_OUNCE.
 */
goldRouter.get(
  '/convert-weight',
  authMiddleware,
  validateRequest({ query: convertWeightQuerySchema }),
  (_req, res, next) => {
    try {
      const q = (res.locals['validated'] as {
        query: z.infer<typeof convertWeightQuerySchema>;
      }).query;
      const converted = convertGoldWeight(q.weight, q.fromUnit, q.toUnit, 4);
      res.status(200).json({
        inputWeight: q.weight,
        fromUnit: q.fromUnit,
        toUnit: q.toUnit,
        convertedWeight: converted,
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/gold/fx-rate
 * Automated Bank of Thailand (BOT Compliant) Historical FX Lookup by date.
 */
goldRouter.get(
  '/fx-rate',
  authMiddleware,
  validateRequest({ query: botFxQuerySchema }),
  async (_req, res, next) => {
    try {
      const q = (res.locals['validated'] as {
        query: z.infer<typeof botFxQuerySchema>;
      }).query;
      const isoDate = q.date.slice(0, 10);
      const currency = q.currency.toUpperCase();
      const rate = await defaultBotFxProvider.getHistoricalRate(
        currency,
        isoDate
      );
      res.status(200).json({
        currency,
        date: isoDate,
        rate,
        provider: 'BOT_HISTORICAL_FX',
      });
    } catch (err) {
      next(
        new AppError(
          400,
          'BOT_FX_LOOKUP_ERROR',
          err instanceof Error ? err.message : 'Unable to fetch BOT FX rate.'
        )
      );
    }
  }
);

/**
 * GET /api/gold/audit-logs
 * Convenience alias returning the user's own Immutable Audit Trail for Gold & Portfolio actions.
 */
goldRouter.get('/audit-logs', authMiddleware, async (req, res, next) => {
  try {
    const logs = await getAuditLogsForUser(req.user!.id);
    res.status(200).json({
      userId: req.user!.id,
      count: logs.length,
      immutable: true,
      logs,
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/gold/overview
 * Full Gold FIFO Valuation, GTA Parity, Physical vs Paper Breakdown,
 * Gold Alpha vs USD/THB FX Attribution, and 5x5 Sensitivity Matrix.
 */
goldRouter.get(
  '/overview',
  authMiddleware,
  validateRequest({ query: overviewQuerySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const q = (res.locals['validated'] as {
        query: z.infer<typeof overviewQuerySchema>;
      }).query;

      const portfolioId = await resolveUserPortfolioId(
        req.user!.id,
        q.portfolioId
      );

      const dbRows = await prisma.goldTransactionRecord.findMany({
        where: { portfolioId },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      });

      const useSeed = q.seedIfEmpty !== 'false';
      const transactions =
        dbRows.length > 0
          ? dbRows.map(mapDbRecordToGoldTx)
          : useSeed
            ? buildDefaultSeedGoldTransactions(portfolioId)
            : [];

      const overview = buildOverviewFromTransactions({
        portfolioId,
        transactions,
        xauUsdSpot: q.xauUsdSpot ?? DEFAULT_XAU_USD_SPOT,
        usdThbRate: q.usdThbRate ?? DEFAULT_USD_THB_RATE,
        gtaGold965SellTHB: q.gtaGold965SellTHB ?? DEFAULT_GTA_965_SELL_THB,
        goldShockPct: q.goldShockPct ?? '0',
        fxShockPct: q.fxShockPct ?? '0',
      });

      res.status(200).json(overview);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/gold/transactions
 * Creates a Physical Gold / Gold Online Futures / XAU Spot transaction with exact Decimal totalCost.
 */
goldRouter.post(
  '/transactions',
  authMiddleware,
  validateRequest({ body: createGoldTxBodySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof createGoldTxBodySchema>;
      }).body;

      await requireOwnedPortfolio(body.portfolioId, req.user!.id);

      const cleanDate = body.date.slice(0, 10);
      const resolvedFxStr =
        body.fxRateAtPurchase && body.fxRateAtPurchase !== 'AUTO'
          ? toCleanGoldDecimal(body.fxRateAtPurchase).toFixed(4)
          : isUsdQuotedSubclass(body.assetSubclass)
            ? toCleanGoldDecimal(
                await defaultBotFxProvider.getHistoricalRate('USD', cleanDate)
              ).toFixed(4)
            : toCleanGoldDecimal(
                await defaultBotFxProvider.getHistoricalRate('USD', cleanDate)
              ).toFixed(4);

      let totalCost: string;
      try {
        totalCost = calculateGoldTransactionTotalCost({
          weight: body.weight,
          spotPricePerUnit: body.spotPricePerUnit,
          premiumPerUnit: body.premiumPerUnit,
          commission: body.commission,
          type: body.type,
        });
      } catch (calcErr) {
        throw new AppError(
          400,
          'INVALID_GOLD_TRANSACTION',
          calcErr instanceof Error ? calcErr.message : 'Invalid gold values'
        );
      }

      // Pre-validate FIFO integrity before persisting SELL transactions
      if (body.type === 'SELL') {
        const existingRows = await prisma.goldTransactionRecord.findMany({
          where: { portfolioId: body.portfolioId },
          orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
        });
        const candidateTx: GoldTransaction = {
          id: 'pending-sell-validation',
          portfolioId: body.portfolioId,
          date: cleanDate,
          symbol: body.symbol.toUpperCase(),
          assetSubclass: body.assetSubclass,
          weight: toCleanGoldDecimal(body.weight).toFixed(4),
          weightUnit: body.weightUnit,
          purity: body.purity,
          spotPricePerUnit: toCleanGoldDecimal(body.spotPricePerUnit).toFixed(2),
          premiumPerUnit: toCleanGoldDecimal(body.premiumPerUnit).toFixed(2),
          commission: toCleanGoldDecimal(body.commission).toFixed(2),
          totalCost,
          fxRateAtPurchase: resolvedFxStr,
          type: 'SELL',
          createdAt: new Date(),
        };

        try {
          calculateGoldFIFO(
            [...existingRows.map(mapDbRecordToGoldTx), candidateTx],
            {
              xauUsdSpot: DEFAULT_XAU_USD_SPOT,
              usdThbRate: DEFAULT_USD_THB_RATE,
              gtaGold965SellTHB: DEFAULT_GTA_965_SELL_THB,
            }
          );
        } catch (fifoErr) {
          throw new AppError(
            400,
            'GOLD_OVERSELL_ERROR',
            fifoErr instanceof Error
              ? fifoErr.message
              : 'Insufficient open gold weight for SELL order.'
          );
        }
      }

      const created = await prisma.goldTransactionRecord.create({
        data: {
          portfolioId: body.portfolioId,
          date: cleanDate,
          symbol: body.symbol.toUpperCase(),
          assetSubclass: body.assetSubclass,
          weight: toCleanGoldDecimal(body.weight).toFixed(4),
          weightUnit: body.weightUnit,
          purity: body.purity,
          spotPricePerUnit: toCleanGoldDecimal(body.spotPricePerUnit).toFixed(2),
          premiumPerUnit: toCleanGoldDecimal(body.premiumPerUnit).toFixed(2),
          commission: toCleanGoldDecimal(body.commission).toFixed(2),
          totalCost,
          fxRateAtPurchase: resolvedFxStr,
          type: body.type,
        },
      });

      const createdDto = mapDbRecordToGoldTx(created);

      // Step 3: Immutable Audit Log (CREATE)
      await logAction(
        req.user!.id,
        'CREATE',
        'GOLD_TRANSACTION',
        created.id,
        null,
        createdDto,
        extractClientIp(req)
      );

      res.status(201).json(createdDto);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * PUT /api/gold/transactions/:id
 * Updates an owned gold transaction record with FIFO validation & Immutable Audit Log (UPDATE).
 */
goldRouter.put(
  '/transactions/:id',
  authMiddleware,
  validateRequest({ body: updateGoldTxBodySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const txId = req.params['id'];
      if (!txId) {
        throw new AppError(400, 'INVALID_ID', 'Transaction ID is required.');
      }

      const existing = await prisma.goldTransactionRecord.findUnique({
        where: { id: txId },
      });
      if (!existing) {
        throw new AppError(
          404,
          'GOLD_TRANSACTION_NOT_FOUND',
          'Gold transaction not found.'
        );
      }

      await requireOwnedPortfolio(existing.portfolioId, req.user!.id);

      const body = (res.locals['validated'] as {
        body: z.infer<typeof updateGoldTxBodySchema>;
      }).body;

      const beforeDto = mapDbRecordToGoldTx(existing);
      const nextDate = body.date ? body.date.slice(0, 10) : existing.date;
      const nextSymbol = body.symbol
        ? body.symbol.toUpperCase()
        : existing.symbol;
      const nextSubclass = (body.assetSubclass ??
        existing.assetSubclass) as GoldAssetSubclass;
      const nextWeight = body.weight
        ? toCleanGoldDecimal(body.weight).toFixed(4)
        : existing.weight;
      const nextUnit = (body.weightUnit ??
        existing.weightUnit) as GoldWeightUnit;
      const nextPurity = (body.purity ?? existing.purity) as GoldPurity;
      const nextSpot = body.spotPricePerUnit
        ? toCleanGoldDecimal(body.spotPricePerUnit).toFixed(2)
        : existing.spotPricePerUnit;
      const nextPrem = body.premiumPerUnit
        ? toCleanGoldDecimal(body.premiumPerUnit).toFixed(2)
        : existing.premiumPerUnit;
      const nextComm = body.commission
        ? toCleanGoldDecimal(body.commission).toFixed(2)
        : existing.commission;
      const nextType = (body.type ?? existing.type) as 'BUY' | 'SELL';
      const nextFx = body.fxRateAtPurchase
        ? toCleanGoldDecimal(body.fxRateAtPurchase).toFixed(4)
        : body.date
          ? toCleanGoldDecimal(
              await defaultBotFxProvider.getHistoricalRate('USD', nextDate)
            ).toFixed(4)
          : existing.fxRateAtPurchase;

      const nextTotalCost = calculateGoldTransactionTotalCost({
        weight: nextWeight,
        spotPricePerUnit: nextSpot,
        premiumPerUnit: nextPrem,
        commission: nextComm,
        type: nextType,
      });

      const allPortfolioRows = await prisma.goldTransactionRecord.findMany({
        where: { portfolioId: existing.portfolioId },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      });

      const simulatedLedger: GoldTransaction[] = allPortfolioRows.map((row) =>
        row.id === txId
          ? {
              id: txId,
              portfolioId: existing.portfolioId,
              date: nextDate,
              symbol: nextSymbol,
              assetSubclass: nextSubclass,
              weight: nextWeight,
              weightUnit: nextUnit,
              purity: nextPurity,
              spotPricePerUnit: nextSpot,
              premiumPerUnit: nextPrem,
              commission: nextComm,
              totalCost: nextTotalCost,
              fxRateAtPurchase: nextFx,
              type: nextType,
              createdAt: existing.createdAt,
            }
          : mapDbRecordToGoldTx(row)
      );

      try {
        calculateGoldFIFO(simulatedLedger, {
          xauUsdSpot: DEFAULT_XAU_USD_SPOT,
          usdThbRate: DEFAULT_USD_THB_RATE,
          gtaGold965SellTHB: DEFAULT_GTA_965_SELL_THB,
        });
      } catch (fifoErr) {
        throw new AppError(
          400,
          'GOLD_FIFO_INTEGRITY_ERROR',
          fifoErr instanceof Error
            ? fifoErr.message
            : 'Updated values violate FIFO lot integrity.'
        );
      }

      const updated = await prisma.goldTransactionRecord.update({
        where: { id: txId },
        data: {
          date: nextDate,
          symbol: nextSymbol,
          assetSubclass: nextSubclass,
          weight: nextWeight,
          weightUnit: nextUnit,
          purity: nextPurity,
          spotPricePerUnit: nextSpot,
          premiumPerUnit: nextPrem,
          commission: nextComm,
          totalCost: nextTotalCost,
          fxRateAtPurchase: nextFx,
          type: nextType,
        },
      });

      const afterDto = mapDbRecordToGoldTx(updated);

      await logAction(
        req.user!.id,
        'UPDATE',
        'GOLD_TRANSACTION',
        txId,
        beforeDto,
        afterDto,
        extractClientIp(req)
      );

      res.status(200).json(afterDto);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/gold/transactions/:id/rollover
 * Executes an atomic Gold Futures Rollover (`SELL` old contract + `BUY` new contract)
 * linked by `rolloverGroupId`, recording `rolloverFee` & Immutable Audit Trail.
 */
goldRouter.post(
  '/transactions/:id/rollover',
  authMiddleware,
  validateRequest({ body: rolloverPositionBodySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      let targetTxId = req.params['id'];
      if (!targetTxId) {
        throw new AppError(400, 'INVALID_ID', 'Transaction ID is required.');
      }

      const body = (res.locals['validated'] as {
        body: z.infer<typeof rolloverPositionBodySchema>;
      }).body;

      let existing = await prisma.goldTransactionRecord.findUnique({
        where: { id: targetTxId },
      });

      // If rolling a seeded UI demo transaction on an empty portfolio, materialize seed rows first
      if (!existing && targetTxId.startsWith('seed-') && body.portfolioId) {
        await requireOwnedPortfolio(body.portfolioId, req.user!.id);
        const existingCount = await prisma.goldTransactionRecord.count({
          where: { portfolioId: body.portfolioId },
        });
        if (existingCount === 0) {
          const seeds = buildDefaultSeedGoldTransactions(body.portfolioId);
          for (const s of seeds) {
            const createdSeed = await prisma.goldTransactionRecord.create({
              data: {
                portfolioId: body.portfolioId,
                date: s.date,
                symbol: s.symbol,
                assetSubclass: s.assetSubclass,
                weight: s.weight,
                weightUnit: s.weightUnit,
                purity: s.purity,
                spotPricePerUnit: s.spotPricePerUnit,
                premiumPerUnit: s.premiumPerUnit,
                commission: s.commission,
                totalCost: s.totalCost,
                fxRateAtPurchase: s.fxRateAtPurchase,
                type: s.type,
              },
            });
            if (s.id === targetTxId) {
              existing = createdSeed;
              targetTxId = createdSeed.id;
            }
          }
        }
      }

      if (!existing) {
        throw new AppError(
          404,
          'GOLD_TRANSACTION_NOT_FOUND',
          'Original gold transaction not found for rollover.'
        );
      }

      await requireOwnedPortfolio(existing.portfolioId, req.user!.id);

      const rolloverResult = await executeRollover(
        targetTxId,
        body.newContractSymbol,
        body.newQty,
        body.newPrice,
        body.rolloverFee,
        {
          closePrice: body.closePrice,
          executionDate: body.executionDate,
          fxRateAtRollover: body.fxRateAtRollover,
          auditContext: {
            userId: req.user!.id,
            ipAddress: extractClientIp(req),
          },
        }
      );

      res.status(201).json(rolloverResult);
    } catch (err) {
      if (err instanceof AppError) {
        next(err);
        return;
      }
      next(
        new AppError(
          400,
          'GOLD_ROLLOVER_FAILED',
          err instanceof Error ? err.message : 'Gold rollover execution failed.'
        )
      );
    }
  }
);

/**
 * DELETE /api/gold/transactions/:id
 * Deletes an owned gold transaction record and writes Immutable Audit Log (DELETE).
 */
goldRouter.delete(
  '/transactions/:id',
  authMiddleware,
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const txId = req.params['id'];
      if (!txId) {
        throw new AppError(400, 'INVALID_ID', 'Transaction ID is required.');
      }

      const record = await prisma.goldTransactionRecord.findUnique({
        where: { id: txId },
      });
      if (!record) {
        throw new AppError(
          404,
          'GOLD_TRANSACTION_NOT_FOUND',
          'Gold transaction not found.'
        );
      }

      await requireOwnedPortfolio(record.portfolioId, req.user!.id);
      const beforeDto = mapDbRecordToGoldTx(record);

      await prisma.goldTransactionRecord.delete({ where: { id: txId } });

      // Step 3: Immutable Audit Log (DELETE)
      await logAction(
        req.user!.id,
        'DELETE',
        'GOLD_TRANSACTION',
        txId,
        beforeDto,
        null,
        extractClientIp(req)
      );

      res.status(200).json({ deleted: true, id: txId });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/gold/simulate
 * Runs interactive Gold Spot + USD/THB FX shock simulation on user's gold holdings.
 */
goldRouter.post(
  '/simulate',
  authMiddleware,
  validateRequest({ body: simulateGoldBodySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof simulateGoldBodySchema>;
      }).body;

      const portfolioId = await resolveUserPortfolioId(
        req.user!.id,
        body.portfolioId
      );

      const dbRows = await prisma.goldTransactionRecord.findMany({
        where: { portfolioId },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      });

      const transactions =
        dbRows.length > 0
          ? dbRows.map(mapDbRecordToGoldTx)
          : buildDefaultSeedGoldTransactions(portfolioId);

      const overview = buildOverviewFromTransactions({
        portfolioId,
        transactions,
        xauUsdSpot: body.xauUsdSpot ?? DEFAULT_XAU_USD_SPOT,
        usdThbRate: body.usdThbRate ?? DEFAULT_USD_THB_RATE,
        gtaGold965SellTHB: body.gtaGold965SellTHB ?? DEFAULT_GTA_965_SELL_THB,
        goldShockPct: body.goldShockPct,
        fxShockPct: body.fxShockPct,
      });

      res.status(200).json(overview);
    } catch (err) {
      next(err);
    }
  }
);

export default goldRouter;
