import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import { JournalEntryItem, JournalMood } from '../types/journalAi';
import { requireOwnedPortfolio } from './routes/portfolioRoutes';

export const journalRouter = Router();

const createJournalSchema = z.object({
  portfolioId: z.string().uuid().optional().nullable(),
  date: z
    .string()
    .trim()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be in YYYY-MM-DD format.')
    .optional(),
  title: z.string().trim().min(1, 'Title is required.').max(160),
  content: z.string().trim().min(1, 'Content is required.').max(4000),
  mood: z.enum(['BULLISH', 'BEARISH', 'NEUTRAL']).default('NEUTRAL'),
});

const listJournalQuerySchema = z.object({
  month: z.string().trim().optional(),
  portfolioId: z.string().uuid().optional(),
});

const idParamSchema = z.object({
  id: z.string().uuid('Invalid journal entry UUID.'),
});

function formatTodayISO(): string {
  return '2026-10-26';
}

/**
 * POST /api/journal
 * Creates a new Wealth Journal memo attached to a date and optional portfolio.
 */
journalRouter.post(
  '/',
  authMiddleware,
  validateRequest({ body: createJournalSchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof createJournalSchema>;
      }).body;

      let portfolioName: string | null = null;
      if (body.portfolioId) {
        const owned = await requireOwnedPortfolio(body.portfolioId, req.user!.id);
        portfolioName = owned.name;
      }

      const created = await prisma.journalEntry.create({
        data: {
          userId: req.user!.id,
          portfolioId: body.portfolioId ?? null,
          date: body.date ?? formatTodayISO(),
          title: body.title,
          content: body.content,
          mood: body.mood,
        },
        include: {
          portfolio: { select: { name: true } },
        },
      });

      const payload: JournalEntryItem = {
        id: created.id,
        userId: created.userId,
        portfolioId: created.portfolioId,
        portfolioName: created.portfolio?.name ?? portfolioName,
        date: created.date,
        title: created.title,
        content: created.content,
        mood: created.mood as JournalMood,
        createdAt: created.createdAt.toISOString(),
      };

      res.status(201).json(payload);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/journal?month=XX
 * Lists journal entries filtered by month ('YYYY-MM' or 'MM' / '1'-'12') and optional portfolioId.
 */
journalRouter.get(
  '/',
  authMiddleware,
  validateRequest({ query: listJournalQuerySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const query = (res.locals['validated'] as {
        query: z.infer<typeof listJournalQuerySchema>;
      }).query;

      let dateFilter: { startsWith?: string; contains?: string } | undefined;
      if (query.month) {
        const raw = query.month.trim();
        if (/^\d{4}-\d{2}$/.test(raw)) {
          dateFilter = { startsWith: `${raw}-` };
        } else if (/^\d{1,2}$/.test(raw)) {
          const mm = raw.padStart(2, '0');
          dateFilter = { contains: `-${mm}-` };
        } else {
          throw new AppError(
            400,
            'INVALID_MONTH',
            'Query parameter month must be MM (01-12) or YYYY-MM.'
          );
        }
      }

      const rows = await prisma.journalEntry.findMany({
        where: {
          userId: req.user!.id,
          ...(query.portfolioId ? { portfolioId: query.portfolioId } : {}),
          ...(dateFilter ? { date: dateFilter } : {}),
        },
        include: {
          portfolio: { select: { name: true } },
        },
        orderBy: [{ date: 'desc' }, { createdAt: 'desc' }],
      });

      const items: JournalEntryItem[] = rows.map((row) => ({
        id: row.id,
        userId: row.userId,
        portfolioId: row.portfolioId,
        portfolioName: row.portfolio?.name ?? null,
        date: row.date,
        title: row.title,
        content: row.content,
        mood: row.mood as JournalMood,
        createdAt: row.createdAt.toISOString(),
      }));

      res.status(200).json(items);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * DELETE /api/journal/:id
 * Deletes an owned Wealth Journal memo.
 */
journalRouter.delete(
  '/:id',
  authMiddleware,
  validateRequest({ params: idParamSchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const { id } = (res.locals['validated'] as { params: { id: string } }).params;

      const existing = await prisma.journalEntry.findUnique({ where: { id } });
      if (!existing) {
        throw new AppError(404, 'JOURNAL_NOT_FOUND', 'Journal entry not found.');
      }
      if (existing.userId !== req.user!.id) {
        throw new AppError(403, 'FORBIDDEN', 'You do not own this journal entry.');
      }

      await prisma.journalEntry.delete({ where: { id } });
      res.status(200).json({ deleted: true, id });
    } catch (err) {
      next(err);
    }
  }
);
