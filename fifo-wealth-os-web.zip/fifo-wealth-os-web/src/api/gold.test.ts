import fs from 'fs';
import os from 'os';
import path from 'path';
import { execSync } from 'child_process';
import request from 'supertest';
import { createApp } from './app';
import { getPrismaClient, setPrismaClient } from '../db/prisma';

describe('Gold Premium & FX Sensitivity REST API (/api/gold)', () => {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'fifo-gold-api-'));
  const testDbPath = path.join(tmpDir, 'gold-api.db');

  let tokenA = '';
  let tokenB = '';
  let portfolioA = '';
  let createdTxId = '';

  beforeAll(async () => {
    process.env['DATABASE_URL'] = `file:${testDbPath}`;
    process.env['JWT_SECRET'] = 'gold-api-test-jwt-secret';
    setPrismaClient(null);

    execSync('npx prisma db push --skip-generate --accept-data-loss', {
      cwd: path.resolve(__dirname, '../..'),
      env: { ...process.env, DATABASE_URL: `file:${testDbPath}` },
      stdio: 'pipe',
    });

    const app = createApp();

    const regA = await request(app).post('/api/auth/register').send({
      email: 'gold.a@wealthos.th',
      password: 'Password123!',
      name: 'Gold Trader A',
    });
    tokenA = regA.body.token as string;

    const regB = await request(app).post('/api/auth/register').send({
      email: 'gold.b@wealthos.th',
      password: 'Password123!',
      name: 'Gold Trader B',
    });
    tokenB = regB.body.token as string;

    const portRes = await request(app)
      .post('/api/portfolios')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({ name: 'Thai Bullion & XAU Portfolio', baseCurrency: 'THB' });
    portfolioA = portRes.body.id as string;
  });

  afterAll(async () => {
    await getPrismaClient().$disconnect();
    setPrismaClient(null);
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('GET /api/gold/convert-weight converts 5.00 THAI_BAHT <-> 76.2200 GRAM', async () => {
    const app = createApp();
    const res = await request(app)
      .get('/api/gold/convert-weight')
      .query({ weight: '5.00', fromUnit: 'THAI_BAHT', toUnit: 'GRAM' })
      .set('Authorization', `Bearer ${tokenA}`);

    expect(res.status).toBe(200);
    expect(res.body.convertedWeight).toBe('76.2200');
  });

  it('POST /api/gold/transactions persists BUY & SELL trades, computes exact totalCost, and blocks oversells (400)', async () => {
    const app = createApp();

    // 1. BUY 5.00 บาททองคำ @ 41,200 + ค่าบล็อก 250 + comm 0 => totalCost = 207,250.00
    const buyRes = await request(app)
      .post('/api/gold/transactions')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId: portfolioA,
        date: '2026-05-12',
        symbol: 'GOLD965',
        assetSubclass: 'PHYSICAL_GOLD',
        weight: '5.00',
        weightUnit: 'THAI_BAHT',
        purity: '96.5',
        spotPricePerUnit: '41200.00',
        premiumPerUnit: '250.00',
        commission: '0.00',
        fxRateAtPurchase: '34.50',
        type: 'BUY',
      });

    expect(buyRes.status).toBe(201);
    expect(buyRes.body.totalCost).toBe('207250.00');
    createdTxId = buyRes.body.id as string;

    // 2. BUY 2.00 Troy Oz XAUUSD @ $2,500 USD, FX 34.40
    const xauRes = await request(app)
      .post('/api/gold/transactions')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId: portfolioA,
        date: '2026-06-01',
        symbol: 'XAUUSD',
        assetSubclass: 'XAU_SPOT',
        weight: '2.00',
        weightUnit: 'TROY_OUNCE',
        purity: '99.99',
        spotPricePerUnit: '2500.00',
        premiumPerUnit: '1.00',
        commission: '4.00',
        fxRateAtPurchase: '34.40',
        type: 'BUY',
      });
    expect(xauRes.status).toBe(201);
    expect(xauRes.body.totalCost).toBe('5006.00');

    // 3. Attempt oversell of 10.00 บาททองคำ -> must reject with 400 GOLD_OVERSELL_ERROR
    const oversellRes = await request(app)
      .post('/api/gold/transactions')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId: portfolioA,
        date: '2026-07-01',
        symbol: 'GOLD965',
        assetSubclass: 'PHYSICAL_GOLD',
        weight: '10.00',
        weightUnit: 'THAI_BAHT',
        purity: '96.5',
        spotPricePerUnit: '44000.00',
        premiumPerUnit: '0',
        commission: '0',
        fxRateAtPurchase: '35.00',
        type: 'SELL',
      });
    expect(oversellRes.status).toBe(400);
    expect(oversellRes.body.error.code).toBe('GOLD_OVERSELL_ERROR');
  });

  it('GET /api/gold/overview & POST /api/gold/simulate return FIFO lots, FX Attribution, Breakdown & 25-cell Matrix', async () => {
    const app = createApp();

    const overviewRes = await request(app)
      .get('/api/gold/overview')
      .query({ portfolioId: portfolioA })
      .set('Authorization', `Bearer ${tokenA}`);

    expect(overviewRes.status).toBe(200);
    expect(overviewRes.body.lots).toHaveLength(2);
    expect(overviewRes.body.fxSensitivities).toHaveLength(2);
    expect(overviewRes.body.sensitivityMatrix).toHaveLength(25);
    expect(overviewRes.body.breakdown.physicalGold.totalWeight).toBe('5.0000');

    const simRes = await request(app)
      .post('/api/gold/simulate')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        portfolioId: portfolioA,
        goldShockPct: '0.10',
        fxShockPct: '0.05',
      });
    expect(simRes.status).toBe(200);
    expect(Number(simRes.body.totalMarketValueTHB)).toBeGreaterThan(
      Number(overviewRes.body.totalMarketValueTHB)
    );
  });

  it('enforces multi-user isolation (403) and supports DELETE /api/gold/transactions/:id', async () => {
    const app = createApp();

    const forbiddenDelete = await request(app)
      .delete(`/api/gold/transactions/${createdTxId}`)
      .set('Authorization', `Bearer ${tokenB}`);
    expect(forbiddenDelete.status).toBe(403);

    const allowedDelete = await request(app)
      .delete(`/api/gold/transactions/${createdTxId}`)
      .set('Authorization', `Bearer ${tokenA}`);
    expect(allowedDelete.status).toBe(200);
    expect(allowedDelete.body.deleted).toBe(true);
  });
});
