import fs from 'fs';
import path from 'path';
import { createApp } from './app';
import { openApiSpec, postmanCollection } from './openapi';

const PORT = Number(process.env['PORT'] ?? 3000);
const HOST = '0.0.0.0';

async function syncContractDocs(): Promise<void> {
  const docsDir = path.resolve(__dirname, '../../docs');
  await fs.promises.mkdir(docsDir, { recursive: true });
  await Promise.all([
    fs.promises.writeFile(
      path.join(docsDir, 'openapi.json'),
      JSON.stringify(openApiSpec, null, 2),
      'utf8'
    ),
    fs.promises.writeFile(
      path.join(docsDir, 'FIFO_Wealth_OS.postman_collection.json'),
      JSON.stringify(postmanCollection, null, 2),
      'utf8'
    ),
  ]);
}

async function bootstrap(): Promise<void> {
  await syncContractDocs();
  const app = createApp();

  app.listen(PORT, HOST, () => {
    // eslint-disable-next-line no-console
    console.log(
      `FIFO Wealth OS Backend API listening on http://${HOST}:${PORT} (Docs: /api-docs)`
    );
  });
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('Failed to start FIFO Wealth OS API server:', err);
  process.exit(1);
});
