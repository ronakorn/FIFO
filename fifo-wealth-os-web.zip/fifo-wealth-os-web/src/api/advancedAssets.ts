import { Router } from 'express';
import { z } from 'zod';
import { authMiddleware } from '../middleware/authMiddleware';
import { validateRequest } from '../middleware/validationMiddleware';
import { blackScholesPrice, calculateImpliedVolatility, calculateOptionPayoff } from '../services/optionsEngine';
import { buildSampleOptionsChain } from '../services/advancedAssetPolish';
import { calculateREITDistributionSchedule, calculateREITValuation } from '../services/reitsEngine';
import { calculateIRR, calculatePEMetrics, generateJCurveData } from '../services/privateEquityEngine';
import { calculateLiquidationPrice, calculateMarginHealth, calculateMarkToMarket, FutDecimal } from '../services/futuresRiskEngine';

export const advancedAssetsRouter = Router();
advancedAssetsRouter.use(authMiddleware);

function decimalIs(value: string | number, predicate: (parsed: typeof FutDecimal.prototype) => boolean): boolean {
  try {
    const parsed = new FutDecimal(String(value));
    return parsed.isFinite() && predicate(parsed);
  } catch {
    return false;
  }
}

const decimalString = z.string().trim().min(1).max(80).regex(/^-?\d+(?:\.\d+)?$/, 'Use a plain decimal string.');
const positiveDecimalString = decimalString.refine((value) => decimalIs(value, (parsed) => parsed.gt(0)), 'Must be greater than zero.');
const nonNegativeDecimalString = decimalString.refine((value) => decimalIs(value, (parsed) => !parsed.isNegative()), 'Cannot be negative.');
const numericOrDecimalString = z.union([z.number().finite(), decimalString]);
const positiveNumericOrDecimalString = numericOrDecimalString.refine((value) => decimalIs(value, (parsed) => parsed.gt(0)), 'Must be greater than zero.');
const optionType = z.enum(['CALL', 'PUT']);
const side = z.enum(['LONG', 'SHORT']);
const cashFlowSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  amount: decimalString,
  type: z.enum(['CALL', 'DISTRIBUTION', 'FEE', 'WRITE_OFF']),
}).strict();
const optionPricingSchema = z.object({
  underlyingPrice: positiveDecimalString,
  strikePrice: positiveDecimalString,
  timeToExpiry: nonNegativeDecimalString,
  riskFreeRate: decimalString,
  volatility: positiveDecimalString,
  optionType,
}).strict();
const optionImpliedVolatilitySchema = z.object({
  marketPrice: nonNegativeDecimalString,
  underlyingPrice: positiveDecimalString,
  strikePrice: positiveDecimalString,
  timeToExpiry: positiveDecimalString,
  riskFreeRate: decimalString,
  optionType,
}).strict();
const optionPayoffSchema = z.object({
  optionType,
  strikePrice: positiveDecimalString,
  underlyingPriceAtExpiry: nonNegativeDecimalString,
  premium: nonNegativeDecimalString,
  contractSize: z.number().finite().int().positive(),
}).strict();
const optionChainSchema = z.object({
  symbol: z.enum(['AAPL', 'SPY']),
  asOfDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
}).strict();
const reitValuationSchema = z.object({
  navPerUnit: positiveDecimalString,
  marketPrice: positiveDecimalString,
  annualDistributionPerUnit: nonNegativeDecimalString,
  ffoPerUnit: nonNegativeDecimalString,
  maintenanceCapexPerUnit: nonNegativeDecimalString.optional(),
}).strict();
const reitDistributionSchema = z.object({
  annualDistributionPerUnit: nonNegativeDecimalString,
  frequency: z.enum(['MONTHLY', 'QUARTERLY', 'SEMI_ANNUAL', 'ANNUAL']),
  unitsHeld: positiveNumericOrDecimalString,
}).strict();
const peIrrSchema = z.object({ cashFlows: z.array(cashFlowSchema).min(2).max(500) }).strict();
const peMetricsSchema = z.object({
  committedCapital: nonNegativeDecimalString,
  calledCapital: nonNegativeDecimalString,
  investedCapital: nonNegativeDecimalString,
  distributedCapital: nonNegativeDecimalString,
  residualValue: nonNegativeDecimalString,
  cashFlows: z.array(cashFlowSchema).min(2).max(500).optional(),
}).strict();
const peJCurveSchema = z.object({ cashFlows: z.array(cashFlowSchema).min(2).max(500) }).strict();
const futuresPositionSchema = z.object({
  id: z.string().trim().min(1).max(100),
  symbol: z.string().trim().min(1).max(100),
  side,
  qty: positiveNumericOrDecimalString,
  entryPrice: decimalString,
  markPrice: decimalString,
  contractSize: positiveNumericOrDecimalString,
  multiplier: positiveDecimalString,
  initialMargin: nonNegativeDecimalString,
  maintenanceMargin: nonNegativeDecimalString,
}).strict();
const futuresMarginHealthSchema = z.object({
  positions: z.array(futuresPositionSchema).max(500),
  accountBalance: decimalString,
}).strict();
const futuresMarkToMarketSchema = z.object({
  side,
  qty: positiveNumericOrDecimalString,
  entryPrice: decimalString,
  markPrice: decimalString,
  contractSize: positiveNumericOrDecimalString,
  multiplier: positiveDecimalString,
}).strict();
const futuresLiquidationSchema = z.object({
  side,
  entryPrice: decimalString,
  initialMarginPerContract: nonNegativeDecimalString,
  maintenanceMarginPerContract: nonNegativeDecimalString,
  multiplier: positiveDecimalString,
  qty: positiveNumericOrDecimalString,
  contractSize: positiveNumericOrDecimalString.default(1),
}).strict();

advancedAssetsRouter.post(
  '/options/pricing',
  validateRequest({ body: optionPricingSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof optionPricingSchema> };
      res.status(200).json({ result: blackScholesPrice(body) });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/options/implied-volatility',
  validateRequest({ body: optionImpliedVolatilitySchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof optionImpliedVolatilitySchema> };
      const impliedVolatility = calculateImpliedVolatility(
        body.marketPrice,
        body.underlyingPrice,
        body.strikePrice,
        body.timeToExpiry,
        body.riskFreeRate,
        body.optionType,
      );
      res.status(200).json({ result: { impliedVolatility } });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/options/payoff',
  validateRequest({ body: optionPayoffSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof optionPayoffSchema> };
      const payoff = calculateOptionPayoff(
        body.optionType,
        body.strikePrice,
        body.underlyingPriceAtExpiry,
        body.premium,
        body.contractSize,
      );
      res.status(200).json({ result: { payoff } });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/options/chain',
  validateRequest({ body: optionChainSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof optionChainSchema> };
      res.status(200).json({ result: buildSampleOptionsChain(body.symbol, body.asOfDate) });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/reits/valuation',
  validateRequest({ body: reitValuationSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof reitValuationSchema> };
      res.status(200).json({ result: calculateREITValuation(
        body.navPerUnit,
        body.marketPrice,
        body.annualDistributionPerUnit,
        body.ffoPerUnit,
        body.maintenanceCapexPerUnit,
      ) });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/reits/distribution-schedule',
  validateRequest({ body: reitDistributionSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof reitDistributionSchema> };
      res.status(200).json({ result: calculateREITDistributionSchedule(
        body.annualDistributionPerUnit,
        body.frequency,
        body.unitsHeld,
      ) });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/private-equity/irr',
  validateRequest({ body: peIrrSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof peIrrSchema> };
      res.status(200).json({ result: { irr: calculateIRR(body.cashFlows) } });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/private-equity/metrics',
  validateRequest({ body: peMetricsSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof peMetricsSchema> };
      res.status(200).json({ result: calculatePEMetrics(
        body.committedCapital,
        body.calledCapital,
        body.investedCapital,
        body.distributedCapital,
        body.residualValue,
        body.cashFlows,
      ) });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/private-equity/j-curve',
  validateRequest({ body: peJCurveSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof peJCurveSchema> };
      res.status(200).json({ result: { points: generateJCurveData(body.cashFlows) } });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/futures/margin-health',
  validateRequest({ body: futuresMarginHealthSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof futuresMarginHealthSchema> };
      res.status(200).json({ result: calculateMarginHealth(body.positions, body.accountBalance) });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/futures/mark-to-market',
  validateRequest({ body: futuresMarkToMarketSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof futuresMarkToMarketSchema> };
      res.status(200).json({ result: { unrealizedPnL: calculateMarkToMarket(body) } });
    } catch (error) {
      next(error);
    }
  },
);

advancedAssetsRouter.post(
  '/futures/liquidation-price',
  validateRequest({ body: futuresLiquidationSchema }),
  (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as { body: z.infer<typeof futuresLiquidationSchema> };
      res.status(200).json({ result: { liquidationPrice: calculateLiquidationPrice(
        body.side,
        body.entryPrice,
        body.initialMarginPerContract,
        body.maintenanceMarginPerContract,
        body.multiplier,
        body.qty,
        body.contractSize,
      ) } });
    } catch (error) {
      next(error);
    }
  },
);
