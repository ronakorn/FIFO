import { z } from 'zod';

export const EXCHANGE_VALUES = [
  'BITKUB',
  'IBKR',
  'STREAMING',
  'DIME',
  'BINANCE',
] as const;

export const registerBodySchema = z.object({
  email: z.string().trim().email('Invalid email address').transform((v) => v.toLowerCase()),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters long')
    .max(128, 'Password is too long'),
  name: z.string().trim().min(1, 'Name is required').max(120, 'Name is too long'),
});

export const loginBodySchema = z.object({
  email: z.string().trim().email('Invalid email address').transform((v) => v.toLowerCase()),
  password: z.string().min(1, 'Password is required'),
});

export const emptyQuerySchema = z.object({}).passthrough();

export const createPortfolioBodySchema = z.object({
  name: z.string().trim().min(1, 'Portfolio name is required').max(120),
  baseCurrency: z
    .string()
    .trim()
    .min(3, 'Currency code must be at least 3 characters')
    .max(5, 'Currency code must be at most 5 characters')
    .default('THB')
    .transform((v) => v.toUpperCase()),
});

export const portfolioIdParamsSchema = z.object({
  id: z.string().trim().min(1, 'Portfolio ID is required'),
});

export const uploadCsvBodySchema = z.object({
  portfolioId: z.string().trim().min(1, 'portfolioId is required'),
  exchange: z
    .string()
    .trim()
    .transform((v) => v.toUpperCase())
    .pipe(z.enum(EXCHANGE_VALUES)),
  vatRate: z.coerce.number().min(0).max(1).optional(),
});

export const uploadDividendsBodySchema = z.object({
  portfolioId: z.string().trim().min(1, 'portfolioId is required'),
  defaultCurrency: z
    .string()
    .trim()
    .min(3)
    .max(5)
    .optional()
    .transform((v) => (v ? v.toUpperCase() : undefined)),
});

export const transactionsParamsSchema = z.object({
  portfolioId: z.string().trim().min(1, 'portfolioId is required'),
});

export const transactionsQuerySchema = z.object({
  type: z.enum(['BUY', 'SELL', 'FEE']).optional(),
  symbol: z
    .string()
    .trim()
    .optional()
    .transform((v) => (v && v.length > 0 ? v.toUpperCase() : undefined)),
});

export const taxRouteParamsSchema = z.object({
  portfolioId: z.string().trim().min(1, 'portfolioId is required'),
  year: z.coerce
    .number()
    .int('Tax year must be an integer')
    .min(1900, 'Tax year must be >= 1900')
    .max(3000, 'Tax year must be <= 3000'),
});

export const taxQuerySchema = z.object({
  electFinalTaxOnDividends: z
    .enum(['true', 'false'])
    .optional()
    .transform((v) => v === 'true'),
  otherNetIncomeTHB: z.string().trim().optional(),
});

export type RegisterBody = z.infer<typeof registerBodySchema>;
export type LoginBody = z.infer<typeof loginBodySchema>;
export type CreatePortfolioBody = z.infer<typeof createPortfolioBodySchema>;
export type UploadCsvBody = z.infer<typeof uploadCsvBodySchema>;
export type UploadDividendsBody = z.infer<typeof uploadDividendsBodySchema>;
export type TransactionsQuery = z.infer<typeof transactionsQuerySchema>;
export type TaxRouteParams = z.infer<typeof taxRouteParamsSchema>;
export type TaxQuery = z.infer<typeof taxQuerySchema>;
