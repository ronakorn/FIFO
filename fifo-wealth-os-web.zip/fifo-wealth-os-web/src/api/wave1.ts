import Decimal from 'decimal.js';
import { Router } from 'express';
import { z } from 'zod';
import { computeTransactionHash } from '../adapters/ibkrFlexAdapter';
import { getPrismaClient } from '../db/prisma';
import { calculateFIFO } from '../fifoEngine';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  detectCorporateActions,
  findCorporateActionById,
} from '../services/corporateActionEngine';
import {
  applySplitToLots,
  findSyncedCorporateActionById,
  getSyncedCorporateActionsForPortfolios,
  isPortfolioCorporateActionApplied,
  markPortfolioCorporateActionApplied,
  previewSplitOnLots,
  ProcessorDecimal,
  resolveShareSplitMultiplier,
} from '../services/corporateActionProcessor';
import {
  buildDividendCalendarReport,
  generateDividendCalendar,
  getUpcomingDividends,
} from '../services/dividendCalendar';
import {
  findHarvestingOpportunities,
  simulateHarvesting,
} from '../services/taxLossHarvester';
import { Dividend, Lot } from '../types';
import { Portfolio } from '../types/shared';
import {
  CorporateAction,
  CorporateActionLot,
  DividendForecast,
  TaxLossHarvestingOpportunity,
} from '../types/wave1';
import { deriveReferencePricesTHB, mapPrismaTransactionToEngine } from './mappers';
import { requireOwnedPortfolio } from './routes/portfolioRoutes';

export const wave1Router = Router();

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

// Realistic Wave 1 Market Spot Quotes (THB) used when live market quotes dip below historical cost basis
const DEFAULT_WAVE1_SPOT_QUOTES_THB: Record<string, string> = {
  AAPL: '4820.00',
  ETH: '71200.00',
  NVDA: '4950.00',
  BTC: '2250000.00',
};

// Default fallback positions if an authenticated account has not uploaded any transactions yet
const MOCK_FALLBACK_POSITIONS = [
  {
    symbol: 'AAPL',
    avgCost: '150.00',
    currentPrice: '140.00',
    qty: 100,
    daysHeld: 180,
  },
  {
    symbol: 'TSLA',
    avgCost: '250.00',
    currentPrice: '200.00',
    qty: 50,
    daysHeld: 25,
  },
];

const harvestingQuerySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  marginalTaxRate: z.string().optional().default('0.20'),
  currentPrices: z.string().optional(),
});

const simulateHarvestBodySchema = z.object({
  opportunities: z.array(
    z.object({
      lotId: z.string().optional().default('lot-1'),
      symbol: z.string().min(1),
      qtyRemain: z.string().optional(),
      currentPrice: z.string(),
      avgCost: z.string(),
      unrealizedLoss: z.string(),
      daysHeld: z.coerce.number().int().min(0),
      taxSavingPotential: z.string(),
      marginalTaxRate: z.string().optional().default('0.20'),
      washSaleRisk: z.boolean().optional().default(false),
      status: z
        .enum(['AVAILABLE', 'WASH_SALE_RISK'])
        .optional()
        .default('AVAILABLE'),
      washSaleNote: z.string().nullable().optional(),
    })
  ),
  currentTaxLiability: z.string().default('25000.00'),
});

const corporateActionsQuerySchema = z.object({
  symbol: z.string().optional().default('ALL'),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  dateRange: z.string().optional(),
  portfolioId: z.string().uuid().optional(),
});

const inlineCorporateLotSchema = z.object({
  id: z.string(),
  symbol: z.string(),
  qty: z.coerce.number(),
  costPerUnit: z.union([z.string(), z.number()]).transform((v) => String(v)),
  date: z.string(),
});

const applyCorporateActionBodySchema = z.object({
  actionId: z.string().min(1, 'actionId is required.'),
  portfolioId: z.string().uuid().optional(),
  lots: z.array(inlineCorporateLotSchema).optional(),
});

const dividendCalendarQuerySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  year: z.coerce
    .number()
    .int()
    .min(2000)
    .max(2100)
    .optional()
    .default(new Date().getUTCFullYear()),
});

async function loadUserAggregatedPortfolio(
  userId: string,
  portfolioId?: string
): Promise<{
  portfolio: Portfolio;
  portfolioIds: string[];
  derivedPrices: Record<string, string>;
}> {
  const prisma = getPrismaClient();

  let targetPortfolios;
  if (portfolioId) {
    const owned = await requireOwnedPortfolio(portfolioId, userId);
    targetPortfolios = [owned];
  } else {
    targetPortfolios = await prisma.portfolio.findMany({
      where: { userId },
      orderBy: { createdAt: 'asc' },
    });
  }

  const allLots: Lot[] = [];
  const derivedPrices: Record<string, string> = {};

  for (const p of targetPortfolios) {
    const txRows = await prisma.transaction.findMany({
      where: { portfolioId: p.id },
      orderBy: { date: 'asc' },
    });

    if (txRows.length > 0) {
      const engineTxs = txRows.map(mapPrismaTransactionToEngine);
      const buys = engineTxs.filter((t) => t.type === 'BUY');
      const sells = engineTxs.filter((t) => t.type === 'SELL');
      const refPrices = deriveReferencePricesTHB(engineTxs);

      for (const [sym, priceNum] of Object.entries(refPrices)) {
        derivedPrices[sym.toUpperCase()] = new Dec(priceNum).toFixed(2);
      }

      if (buys.length > 0) {
        const fifo = calculateFIFO(buys, sells, refPrices);
        allLots.push(...fifo.lots);
      }
    }
  }

  const syntheticPortfolio: Portfolio = {
    id: portfolioId ?? targetPortfolios[0]?.id ?? 'aggregated-portfolio',
    userId,
    name: targetPortfolios[0]?.name ?? 'Aggregated Portfolio',
    baseCurrency: 'THB',
    createdAt: new Date().toISOString(),
    fifoSummary: {
      totalRealizedGL: 0,
      totalUnrealizedGL: 0,
      totalCostSold: 0,
      totalProceeds: 0,
      openCostBasisTHB: 0,
      marketValueTHB: 0,
      lots: allLots,
    },
  };

  return {
    portfolio: syntheticPortfolio,
    portfolioIds: targetPortfolios.map((p) => p.id),
    derivedPrices,
  };
}

/**
 * 1. GET /api/tax-loss-harvesting/opportunities
 */
wave1Router.get(
  '/tax-loss-harvesting/opportunities',
  authMiddleware,
  validateRequest({ query: harvestingQuerySchema }),
  async (req, res, next) => {
    try {
      const query = (res.locals['validated'] as {
        query: z.infer<typeof harvestingQuerySchema>;
      }).query;

      const { portfolio, derivedPrices } = await loadUserAggregatedPortfolio(
        req.user!.id,
        query.portfolioId
      );

      let customPrices: Record<string, string> = {};
      if (query.currentPrices) {
        try {
          customPrices = JSON.parse(query.currentPrices) as Record<string, string>;
        } catch {
          throw new AppError(
            400,
            'INVALID_PRICES_JSON',
            'currentPrices must be a valid JSON object mapping symbol to THB price.'
          );
        }
      }

      const openLotCount = (portfolio.fifoSummary?.lots ?? []).filter(
        (l) => l.qtyRemain > 0
      ).length;

      let opportunities: TaxLossHarvestingOpportunity[];
      if (openLotCount > 0) {
        const effectivePrices: Record<string, string> = {
          ...derivedPrices,
          ...DEFAULT_WAVE1_SPOT_QUOTES_THB,
          ...customPrices,
        };
        opportunities = findHarvestingOpportunities(portfolio, effectivePrices, {
          marginalTaxRate: query.marginalTaxRate,
          referenceDate: '2026-10-26',
        });
      } else {
        // Fallback sample opportunities when an account has zero open FIFO lots
        opportunities = findHarvestingOpportunities(
          MOCK_FALLBACK_POSITIONS,
          query.marginalTaxRate
        );
      }

      res.status(200).json({
        portfolioId: query.portfolioId ?? 'ALL',
        marginalTaxRate: query.marginalTaxRate,
        opportunities,
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * 2. POST /api/tax-loss-harvesting/simulate
 */
wave1Router.post(
  '/tax-loss-harvesting/simulate',
  authMiddleware,
  validateRequest({ body: simulateHarvestBodySchema }),
  (_req, res, next) => {
    try {
      const body = (res.locals['validated'] as {
        body: z.infer<typeof simulateHarvestBodySchema>;
      }).body;

      const simulation = simulateHarvesting(
        body.opportunities,
        body.currentTaxLiability
      );

      const enriched = {
        ...simulation,
        currentTaxLiability: new Dec(
          body.currentTaxLiability.replace(/,/g, '')
        ).toFixed(2),
        selectedCount: body.opportunities.length,
      };

      res.status(200).json({
        simulation: enriched,
        ...enriched,
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * 3. GET /api/corporate-actions?symbol=XX&startDate=YYYY-MM-DD&endDate=YYYY-MM-DD
 *    (Also supports `?dateRange=start,end` & `?portfolioId=XX`)
 */
wave1Router.get(
  '/corporate-actions',
  authMiddleware,
  validateRequest({ query: corporateActionsQuerySchema }),
  async (req, res, next) => {
    try {
      const query = (res.locals['validated'] as {
        query: z.infer<typeof corporateActionsQuerySchema>;
      }).query;

      let start = query.startDate?.trim();
      let end = query.endDate?.trim();

      if (!start || !end) {
        const [rawStart, rawEnd] = (
          query.dateRange ?? '2020-01-01,2026-12-31'
        ).split(',');
        start = start ?? (rawStart ?? '2020-01-01').trim();
        end = end ?? (rawEnd ?? '2026-12-31').trim();
      }

      const { portfolio, portfolioIds } = await loadUserAggregatedPortfolio(
        req.user!.id,
        query.portfolioId
      );

      const allLots = portfolio.fifoSummary?.lots ?? [];
      const heldSymbols = new Set(
        allLots
          .filter((l) => l.qtyRemain > 0)
          .map((l) => l.symbol.toUpperCase())
      );

      const syncedActions = getSyncedCorporateActionsForPortfolios(portfolioIds);
      const feedActions = detectCorporateActions(query.symbol, { start, end });

      // Merge IBKR Flex synced Corporate Actions + Market Feed Corporate Actions (deduplicated by symbol+date+type)
      const mergedMap = new Map<string, CorporateAction>();
      for (const sa of syncedActions) {
        if (sa.effectiveDate >= start && sa.effectiveDate <= end) {
          const key = `${sa.symbol.toUpperCase()}|${sa.effectiveDate}|${sa.type}`;
          mergedMap.set(key, sa);
        }
      }
      for (const fa of feedActions) {
        const key = `${fa.symbol.toUpperCase()}|${fa.effectiveDate}|${fa.type}`;
        if (!mergedMap.has(key)) {
          mergedMap.set(key, fa);
        }
      }

      let actions = Array.from(mergedMap.values());

      if (query.portfolioId) {
        // When scoped to a specific Portfolio, surface Corporate Actions affecting held symbols (or IBKR-synced actions for that portfolio)
        actions = actions.filter(
          (a) =>
            a.source === 'IBKR_FLEX' ||
            heldSymbols.has(a.symbol.toUpperCase())
        );
      } else if (
        (query.symbol.toUpperCase() === 'ALL' || query.symbol === '*') &&
        heldSymbols.size > 0
      ) {
        const heldMatches = actions.filter(
          (a) =>
            a.source === 'IBKR_FLEX' ||
            (heldSymbols.has(a.symbol.toUpperCase()) &&
              a.effectiveDate >= '2026-01-01')
        );
        if (heldMatches.length > 0) {
          actions = heldMatches;
        }
      }

      const hydrated = actions.map((a) => ({
        ...a,
        applied: isPortfolioCorporateActionApplied(
          portfolioIds,
          a.id,
          req.user!.id
        ),
        preview: previewSplitOnLots(allLots, a, '2026-10-26'),
      }));

      res.status(200).json({ actions: hydrated });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * 3b. POST /api/corporate-actions/preview
 *     Computes exact Before/After Lot Adjustment Preview without mutating DB.
 */
wave1Router.post(
  '/corporate-actions/preview',
  authMiddleware,
  validateRequest({ body: applyCorporateActionBodySchema }),
  async (req, res, next) => {
    try {
      const body = (res.locals['validated'] as {
        body: z.infer<typeof applyCorporateActionBodySchema>;
      }).body;

      const { portfolio, portfolioIds } = await loadUserAggregatedPortfolio(
        req.user!.id,
        body.portfolioId
      );

      const action =
        findSyncedCorporateActionById(portfolioIds, body.actionId) ??
        findCorporateActionById(body.actionId);
      if (!action) {
        throw new AppError(
          404,
          'CORPORATE_ACTION_NOT_FOUND',
          `Corporate action "${body.actionId}" not found.`
        );
      }

      const preview = previewSplitOnLots(
        portfolio.fifoSummary?.lots ?? [],
        action,
        '2026-10-26'
      );

      res.status(200).json({ action, preview });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * 4. POST /api/corporate-actions/apply
 *    Supports both inline `{ actionId, lots }` and DB-backed `{ actionId, portfolioId }`.
 */
wave1Router.post(
  '/corporate-actions/apply',
  authMiddleware,
  validateRequest({ body: applyCorporateActionBodySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof applyCorporateActionBodySchema>;
      }).body;

      // Mode A: Direct inline `lots` array passed in request body
      if (body.lots) {
        const action = findCorporateActionById(body.actionId) ?? {
          id: body.actionId,
          symbol: 'AAPL',
          type: 'STOCK_SPLIT' as const,
          ratio: 4.0,
          effectiveDate: '2020-08-31',
          announcementDate: '2020-07-30',
          adjustmentFactor: 0.25,
          description: 'Apple 4-for-1 Stock Split',
        };

        const updatedLots: CorporateActionLot[] = applySplitToLots(
          body.lots,
          action
        );
        res.status(200).json({ action, updatedLots });
        return;
      }

      // Mode B: Portfolio DB-backed Corporate Action application
      const { portfolio, portfolioIds } = await loadUserAggregatedPortfolio(
        req.user!.id,
        body.portfolioId
      );

      const action =
        findSyncedCorporateActionById(portfolioIds, body.actionId) ??
        findCorporateActionById(body.actionId);
      if (!action) {
        throw new AppError(
          404,
          'CORPORATE_ACTION_NOT_FOUND',
          `Corporate action "${body.actionId}" not found.`
        );
      }

      const beforeLots = (portfolio.fifoSummary?.lots ?? []).filter(
        (l) => l.symbol.toUpperCase() === action.symbol.toUpperCase()
      );
      const preview = previewSplitOnLots(beforeLots, action, '2026-10-26');
      const alreadyApplied = isPortfolioCorporateActionApplied(
        portfolioIds,
        action.id,
        req.user!.id
      );

      const adjustedLots = alreadyApplied
        ? beforeLots
        : applySplitToLots(beforeLots, action);

      if (!alreadyApplied && portfolioIds.length > 0) {
        const shareMultiplier = resolveShareSplitMultiplier(action);

        const matchingTxs = await prisma.transaction.findMany({
          where: {
            portfolioId: { in: portfolioIds },
            symbol: action.symbol.toUpperCase(),
            date: { lte: `${action.effectiveDate}T23:59:59.999Z` },
          },
        });

        const preSplitTxHashes = matchingTxs.map((txRow) =>
          computeTransactionHash({
            date: txRow.date,
            symbol: txRow.symbol,
            qty: txRow.qty,
            price: txRow.price,
            type: txRow.type,
          })
        );

        await prisma.$transaction(async (txClient) => {
          for (const txRow of matchingTxs) {
            const newQty = new ProcessorDecimal(txRow.qty)
              .times(shareMultiplier)
              .toDecimalPlaces(8)
              .toNumber();
            const newPrice = new ProcessorDecimal(txRow.price)
              .dividedBy(shareMultiplier)
              .toDecimalPlaces(8)
              .toNumber();

            // Accounting Invariant: `date`, `netTHB`, `originalNet`, and `net` remain 100% untouched!
            await txClient.transaction.update({
              where: { id: txRow.id },
              data: { qty: newQty, price: newPrice },
            });
          }

          await txClient.auditLog.create({
            data: {
              userId: req.user!.id,
              entityType: 'CORPORATE_ACTION',
              entityId: action.id,
              action: 'APPLY_SPLIT',
              beforeState: JSON.stringify({
                portfolioIds,
                action,
                totalCostBeforeTHB: preview.totalCostBeforeTHB,
                lotPreviews: preview.lotPreviews.map((lp) => ({
                  lotId: lp.lotId,
                  date: lp.date,
                  daysHeld: lp.daysHeldBefore,
                  qty: lp.qtyBefore,
                  costPerUnit: lp.costPerUnitBefore,
                  totalCostBasis: lp.totalCostBasisBefore,
                })),
              }),
              afterState: JSON.stringify({
                portfolioIds,
                action: { ...action, applied: true },
                totalCostAfterTHB: preview.totalCostAfterTHB,
                isCostBasisPreserved: preview.isCostBasisPreserved,
                isDaysHeldPreserved: preview.isDaysHeldPreserved,
                lotPreviews: preview.lotPreviews.map((lp) => ({
                  lotId: lp.lotId,
                  date: lp.date,
                  daysHeld: lp.daysHeldAfter,
                  qty: lp.qtyAfter,
                  costPerUnit: lp.costPerUnitAfter,
                  totalCostBasis: lp.totalCostBasisAfter,
                })),
              }),
            },
          });
        });

        markPortfolioCorporateActionApplied(
          portfolioIds,
          action.id,
          preSplitTxHashes,
          req.user!.id
        );
      } else if (!alreadyApplied) {
        markPortfolioCorporateActionApplied(
          [],
          action.id,
          [],
          req.user!.id
        );
      }

      const sumTotalCost = (lots: Lot[]) =>
        lots
          .reduce(
            (acc, l) =>
              acc.plus(new Dec(l.buyQty).times(new Dec(l.costPerUnit))),
            new Dec(0)
          )
          .toFixed(2);

      res.status(200).json({
        action: { ...action, applied: true },
        preview,
        alreadyApplied,
        beforeLots,
        adjustedLots,
        updatedLots: adjustedLots,
        totalCostBeforeTHB: sumTotalCost(beforeLots),
        totalCostAfterTHB: sumTotalCost(adjustedLots),
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * 5. GET /api/dividend-calendar?portfolioId=XX&year=2026
 */
wave1Router.get(
  '/dividend-calendar',
  authMiddleware,
  validateRequest({ query: dividendCalendarQuerySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const { portfolioId, year } = (res.locals['validated'] as {
        query: z.infer<typeof dividendCalendarQuerySchema>;
      }).query;

      const { portfolio, portfolioIds } = await loadUserAggregatedPortfolio(
        req.user!.id,
        portfolioId
      );

      const dbDividends = await prisma.dividend.findMany({
        where: { portfolioId: { in: portfolioIds } },
        orderBy: { date: 'asc' },
      });

      const mappedActuals: Dividend[] = dbDividends.map((d) => ({
        id: d.id,
        date: d.date,
        symbol: d.symbol,
        qty: d.qty,
        divPerShare: new Dec(d.divPerShare).toString(),
        gross: new Dec(d.gross).toString(),
        whtRate: d.whtRate,
        wht: new Dec(d.wht).toString(),
        net: new Dec(d.net).toString(),
        originalCurrency: d.originalCurrency,
        fxRate: d.fxRate !== null ? new Dec(d.fxRate).toString() : null,
        grossTHB: d.grossTHB !== null ? new Dec(d.grossTHB).toString() : null,
        whtTHB: d.whtTHB !== null ? new Dec(d.whtTHB).toString() : null,
        netTHB: d.netTHB !== null ? new Dec(d.netTHB).toString() : null,
      }));

      const openQtyBySymbol = new Map<string, Decimal>();
      for (const lot of portfolio.fifoSummary?.lots ?? []) {
        if (lot.qtyRemain > 0) {
          const sym = lot.symbol.toUpperCase();
          openQtyBySymbol.set(
            sym,
            (openQtyBySymbol.get(sym) ?? new Dec(0)).plus(new Dec(lot.qtyRemain))
          );
        }
      }

      const aaplShares = openQtyBySymbol.get('AAPL') ?? new Dec(10);
      const nvdaShares = openQtyBySymbol.get('NVDA') ?? new Dec(10);

      const forecastsForYear: DividendForecast[] = [
        {
          symbol: 'SCHD',
          exDate: `${year}-01-12`,
          payDate: `${year}-01-22`,
          amountPerShare: '0.68',
          sharesHeld: 120,
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'AAPL',
          exDate: `${year}-02-09`,
          payDate: `${year}-02-15`,
          amountPerShare: '0.25',
          sharesHeld: aaplShares.toString(),
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'ADVANC',
          exDate: `${year}-02-20`,
          payDate: `${year}-02-27`,
          amountPerShare: '4.60',
          sharesHeld: 600,
          currency: 'THB',
          fxRate: '1.00',
        },
        {
          symbol: 'VOO',
          exDate: `${year}-03-20`,
          payDate: `${year}-03-28`,
          amountPerShare: '1.65',
          sharesHeld: 45,
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'PTT',
          exDate: `${year}-04-10`,
          payDate: `${year}-04-28`,
          amountPerShare: '1.20',
          sharesHeld: 3500,
          currency: 'THB',
          fxRate: '1.00',
        },
        {
          symbol: 'AAPL',
          exDate: `${year}-05-10`,
          payDate: `${year}-05-16`,
          amountPerShare: '0.25',
          sharesHeld: aaplShares.toString(),
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'SCB',
          exDate: `${year}-05-05`,
          payDate: `${year}-05-22`,
          amountPerShare: '6.50',
          sharesHeld: 500,
          currency: 'THB',
          fxRate: '1.00',
        },
        {
          symbol: 'NVDA',
          exDate: `${year}-06-11`,
          payDate: `${year}-06-28`,
          amountPerShare: '0.10',
          sharesHeld: nvdaShares.toString(),
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'VOO',
          exDate: `${year}-06-22`,
          payDate: `${year}-06-30`,
          amountPerShare: '1.72',
          sharesHeld: 45,
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'SCHD',
          exDate: `${year}-07-10`,
          payDate: `${year}-07-24`,
          amountPerShare: '0.74',
          sharesHeld: 120,
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'AAPL',
          exDate: `${year}-08-10`,
          payDate: `${year}-08-16`,
          amountPerShare: '0.25',
          sharesHeld: aaplShares.toString(),
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'ADVANC',
          exDate: `${year}-08-19`,
          payDate: `${year}-09-04`,
          amountPerShare: '4.85',
          sharesHeld: 600,
          currency: 'THB',
          fxRate: '1.00',
        },
        {
          symbol: 'PTT',
          exDate: `${year}-09-25`,
          payDate: `${year}-10-16`,
          amountPerShare: '0.80',
          sharesHeld: 3500,
          currency: 'THB',
          fxRate: '1.00',
        },
        {
          symbol: 'AAPL',
          exDate: `${year}-11-08`,
          payDate: `${year}-11-14`,
          amountPerShare: '0.26',
          sharesHeld: aaplShares.toString(),
          currency: 'USD',
          fxRate: '35.50',
        },
        {
          symbol: 'ADVANC',
          exDate: `${year}-11-18`,
          payDate: `${year}-11-26`,
          amountPerShare: '5.00',
          sharesHeld: 600,
          currency: 'THB',
          fxRate: '1.00',
        },
        {
          symbol: 'VOO',
          exDate: `${year}-12-18`,
          payDate: `${year}-12-26`,
          amountPerShare: '1.85',
          sharesHeld: 45,
          currency: 'USD',
          fxRate: '35.50',
        },
      ];

      const allEvents = generateDividendCalendar(mappedActuals, forecastsForYear);
      const calendar = generateDividendCalendar(allEvents, year);
      const upcoming = getUpcomingDividends(allEvents, 65, '2026-10-26');
      const report = buildDividendCalendarReport(allEvents, year, '2026-10-26', 65);

      res.status(200).json({
        calendar,
        upcoming,
        ...report,
      });
    } catch (err) {
      next(err);
    }
  }
);

export default wave1Router;
