import crypto from 'node:crypto';
import Decimal from 'decimal.js';
import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { calculateFIFO } from '../fifoEngine';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import { assertUserUsageWithinLimit } from '../services/entitlementService';
import {
  FamilyDashboardResponse,
  FamilyMemberSummary,
  FamilyPermissions,
  FamilyRole,
} from '../types/family';
import { deriveReferencePricesTHB, mapPrismaTransactionToEngine } from './mappers';

export const familyRouter = Router();

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

const DEFAULT_PERMISSIONS: FamilyPermissions = {
  canSeeTransactions: false,
  canSeeTotalNetWorth: true,
};

const createFamilySchema = z.object({
  name: z.string().trim().min(1, 'Family group name is required.').max(100),
});

const joinFamilySchema = z.object({
  inviteCode: z.string().trim().min(4, 'Invite code is required.').max(32),
});

const updatePrivacySchema = z.object({
  hideTransactions: z.boolean().optional(),
  canSeeTransactions: z.boolean().optional(),
  canSeeTotalNetWorth: z.boolean().optional(),
  familyGroupId: z.string().uuid().optional(),
});

const dashboardQuerySchema = z.object({
  familyGroupId: z.string().uuid().optional(),
});

function parsePermissions(raw: string): FamilyPermissions {
  try {
    const parsed = JSON.parse(raw) as Partial<FamilyPermissions>;
    return {
      canSeeTransactions: Boolean(parsed.canSeeTransactions ?? false),
      canSeeTotalNetWorth:
        parsed.canSeeTotalNetWorth !== undefined
          ? Boolean(parsed.canSeeTotalNetWorth)
          : true,
    };
  } catch {
    return { ...DEFAULT_PERMISSIONS };
  }
}

function generateInviteCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const pick = (len: number) =>
    Array.from({ length: len }, () => {
      const idx = crypto.randomInt(0, alphabet.length);
      return alphabet[idx];
    }).join('');
  return `FAM-${pick(4)}-${pick(4)}`;
}

/**
 * Computes exact user Net Worth in THB using pure Decimal.js (precision: 40)
 * WITHOUT returning or exposing any raw Transaction rows.
 */
async function computeUserNetWorthTHB(
  userId: string,
  familyGroupId: string
): Promise<{ netWorthTHB: Decimal; portfolioCount: number }> {
  const prisma = getPrismaClient();

  // Include portfolios linked to this familyGroupId OR all user portfolios if none explicitly scoped
  const allUserPortfolios = await prisma.portfolio.findMany({
    where: { userId },
    include: {
      transactions: { orderBy: { date: 'asc' } },
      dividends: { orderBy: { date: 'asc' } },
    },
  });

  const scopedPortfolios = allUserPortfolios.some(
    (p) => p.familyGroupId === familyGroupId
  )
    ? allUserPortfolios.filter(
        (p) => p.familyGroupId === familyGroupId || p.familyGroupId === null
      )
    : allUserPortfolios;

  let totalNetWorth = new Dec(0);

  for (const portfolio of scopedPortfolios) {
    if (portfolio.transactions.length > 0) {
      const engineTxs = portfolio.transactions.map(mapPrismaTransactionToEngine);
      const buys = engineTxs.filter((t) => t.type === 'BUY');
      const sells = engineTxs.filter((t) => t.type === 'SELL');
      const refPrices = deriveReferencePricesTHB(engineTxs);

      if (buys.length > 0) {
        const fifo = calculateFIFO(buys, sells, refPrices);
        for (const lot of fifo.lots) {
          if (lot.qtyRemain > 0) {
            const refPrice = new Dec(refPrices[lot.symbol] ?? lot.costPerUnit);
            totalNetWorth = totalNetWorth.plus(
              new Dec(lot.qtyRemain).times(refPrice)
            );
          }
        }
      }
    }

    for (const div of portfolio.dividends) {
      totalNetWorth = totalNetWorth.plus(new Dec(div.netTHB ?? div.net));
    }
  }

  return {
    netWorthTHB: totalNetWorth,
    portfolioCount: scopedPortfolios.length,
  };
}

/**
 * POST /api/family/create
 * Creates a new Family Wealth group and registers creator as OWNER.
 */
familyRouter.post(
  '/create',
  authMiddleware,
  validateRequest({ body: createFamilySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const { name } = (res.locals['validated'] as {
        body: z.infer<typeof createFamilySchema>;
      }).body;

      let inviteCode = generateInviteCode();
      for (let attempt = 0; attempt < 5; attempt++) {
        const collision = await prisma.familyGroup.findUnique({
          where: { inviteCode },
        });
        if (!collision) break;
        inviteCode = generateInviteCode();
      }

      const group = await prisma.$transaction(async (tx) => {
        const createdGroup = await tx.familyGroup.create({
          data: {
            name,
            createdByUserId: req.user!.id,
            inviteCode,
          },
        });

        await tx.familyMember.create({
          data: {
            familyGroupId: createdGroup.id,
            userId: req.user!.id,
            role: 'OWNER',
            permissions: JSON.stringify(DEFAULT_PERMISSIONS),
          },
        });

        await tx.portfolio.updateMany({
          where: { userId: req.user!.id, familyGroupId: null },
          data: { familyGroupId: createdGroup.id },
        });

        return createdGroup;
      });

      res.status(201).json({
        id: group.id,
        name: group.name,
        inviteCode: group.inviteCode,
        createdByUserId: group.createdByUserId,
        role: 'OWNER' as FamilyRole,
        permissions: DEFAULT_PERMISSIONS,
        createdAt: group.createdAt.toISOString(),
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/family/join
 * Joins an existing Family Wealth group via Invite Code as VIEWER (Privacy-First defaults).
 */
familyRouter.post(
  '/join',
  authMiddleware,
  validateRequest({ body: joinFamilySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const rawCode = (res.locals['validated'] as {
        body: z.infer<typeof joinFamilySchema>;
      }).body.inviteCode
        .trim()
        .toUpperCase();

      const group = await prisma.familyGroup.findUnique({
        where: { inviteCode: rawCode },
      });
      if (!group) {
        throw new AppError(
          404,
          'INVITE_CODE_NOT_FOUND',
          'ไม่พบรหัสเชิญครอบครัวนี้ กรุณาตรวจสอบรหัสอีกครั้ง'
        );
      }

      const existingMember = await prisma.familyMember.findUnique({
        where: {
          familyGroupId_userId: {
            familyGroupId: group.id,
            userId: req.user!.id,
          },
        },
      });

      if (existingMember) {
        res.status(200).json({
          alreadyMember: true,
          familyGroupId: group.id,
          name: group.name,
          inviteCode: group.inviteCode,
          role: existingMember.role as FamilyRole,
          permissions: parsePermissions(existingMember.permissions),
        });
        return;
      }

      const memberCount = await prisma.familyMember.count({
        where: { familyGroupId: group.id },
      });
      await assertUserUsageWithinLimit(
        req.user!.id,
        'maxFamilyMembers',
        memberCount,
        1
      );

      const member = await prisma.$transaction(async (tx) => {
        const createdMember = await tx.familyMember.create({
          data: {
            familyGroupId: group.id,
            userId: req.user!.id,
            role: 'VIEWER',
            permissions: JSON.stringify(DEFAULT_PERMISSIONS),
          },
        });

        await tx.portfolio.updateMany({
          where: { userId: req.user!.id, familyGroupId: null },
          data: { familyGroupId: group.id },
        });

        return createdMember;
      });

      res.status(201).json({
        alreadyMember: false,
        familyGroupId: group.id,
        name: group.name,
        inviteCode: group.inviteCode,
        role: member.role as FamilyRole,
        permissions: parsePermissions(member.permissions),
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * PATCH /api/family/privacy
 * Updates the current user's privacy sharing rules (e.g. hiding transaction details).
 */
familyRouter.patch(
  '/privacy',
  authMiddleware,
  validateRequest({ body: updatePrivacySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const body = (res.locals['validated'] as {
        body: z.infer<typeof updatePrivacySchema>;
      }).body;

      const memberships = await prisma.familyMember.findMany({
        where: {
          userId: req.user!.id,
          ...(body.familyGroupId ? { familyGroupId: body.familyGroupId } : {}),
        },
      });

      const resolvedPermissions: FamilyPermissions = {
        canSeeTransactions:
          body.hideTransactions !== undefined
            ? !body.hideTransactions
            : Boolean(body.canSeeTransactions ?? false),
        canSeeTotalNetWorth:
          body.canSeeTotalNetWorth !== undefined ? body.canSeeTotalNetWorth : true,
      };

      for (const m of memberships) {
        const current = parsePermissions(m.permissions);
        const merged: FamilyPermissions = {
          canSeeTransactions:
            body.hideTransactions !== undefined
              ? !body.hideTransactions
              : body.canSeeTransactions !== undefined
                ? body.canSeeTransactions
                : current.canSeeTransactions,
          canSeeTotalNetWorth:
            body.canSeeTotalNetWorth !== undefined
              ? body.canSeeTotalNetWorth
              : current.canSeeTotalNetWorth,
        };
        await prisma.familyMember.update({
          where: { id: m.id },
          data: { permissions: JSON.stringify(merged) },
        });
      }

      res.status(200).json({
        updatedCount: memberships.length,
        permissions: resolvedPermissions,
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/family/dashboard
 * Privacy-Preserving Household Net Worth Aggregation using pure Decimal.js (precision: 40).
 * Strictly returns ONLY aggregated member Net Worth & percentages — NEVER individual transactions.
 */
familyRouter.get(
  '/dashboard',
  authMiddleware,
  validateRequest({ query: dashboardQuerySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const { familyGroupId } = (res.locals['validated'] as {
        query: z.infer<typeof dashboardQuerySchema>;
      }).query;

      const callerMembership = familyGroupId
        ? await prisma.familyMember.findUnique({
            where: {
              familyGroupId_userId: {
                familyGroupId,
                userId: req.user!.id,
              },
            },
            include: { familyGroup: true },
          })
        : await prisma.familyMember.findFirst({
            where: { userId: req.user!.id },
            orderBy: { createdAt: 'desc' },
            include: { familyGroup: true },
          });

      if (!callerMembership) {
        if (familyGroupId) {
          throw new AppError(
            403,
            'FORBIDDEN',
            'You are not a member of this family group.'
          );
        }
        const emptyPayload: FamilyDashboardResponse = {
          hasGroup: false,
          group: null,
          householdNetWorthTHB: '0.00',
          memberCount: 0,
          members: [],
          privacyGuarantee: {
            transactionsExposed: false,
            aggregationEngine: 'Decimal.js-40',
          },
        };
        res.status(200).json(emptyPayload);
        return;
      }

      const group = callerMembership.familyGroup;
      const allMembers = await prisma.familyMember.findMany({
        where: { familyGroupId: group.id },
        include: {
          user: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'asc' },
      });

      // Compute each member's Net Worth via Decimal.js without exposing transactions
      const rawBalances: {
        member: (typeof allMembers)[number];
        perms: FamilyPermissions;
        netWorth: Decimal;
        portfolioCount: number;
      }[] = [];

      let householdSum = new Dec(0);

      for (const m of allMembers) {
        const perms = parsePermissions(m.permissions);
        const { netWorthTHB, portfolioCount } = await computeUserNetWorthTHB(
          m.userId,
          group.id
        );

        const visibleNetWorth =
          perms.canSeeTotalNetWorth || m.userId === req.user!.id
            ? netWorthTHB
            : new Dec(0);

        householdSum = householdSum.plus(visibleNetWorth);
        rawBalances.push({
          member: m,
          perms,
          netWorth: visibleNetWorth,
          portfolioCount,
        });
      }

      const membersSummary: FamilyMemberSummary[] = rawBalances.map((item) => {
        const sharePct = householdSum.gt(0)
          ? item.netWorth
              .dividedBy(householdSum)
              .times(100)
              .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
              .toFixed(2)
          : '0.00';

        return {
          memberId: item.member.id,
          userId: item.member.user.id,
          name: item.member.user.name,
          role: item.member.role as FamilyRole,
          netWorthTHB: item.netWorth.toFixed(2),
          sharePercent: sharePct,
          portfolioCount: item.portfolioCount,
          permissions: item.perms,
          isCurrentUser: item.member.user.id === req.user!.id,
        };
      });

      const response: FamilyDashboardResponse = {
        hasGroup: true,
        group: {
          id: group.id,
          name: group.name,
          inviteCode: group.inviteCode,
          createdByUserId: group.createdByUserId,
          currentUserRole: callerMembership.role as FamilyRole,
          currentUserPermissions: parsePermissions(callerMembership.permissions),
          createdAt: group.createdAt.toISOString(),
        },
        householdNetWorthTHB: householdSum.toFixed(2),
        memberCount: membersSummary.length,
        members: membersSummary,
        privacyGuarantee: {
          transactionsExposed: false,
          aggregationEngine: 'Decimal.js-40',
        },
      };

      res.status(200).json(response);
    } catch (err) {
      next(err);
    }
  }
);
