import bcrypt from 'bcryptjs';
import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../../db/prisma';
import { authMiddleware, signAccessToken } from '../../middleware/authMiddleware';
import { AppError } from '../../middleware/errorHandler';
import { validateRequest } from '../../middleware/validationMiddleware';
import { mapPrismaUserToShared } from '../mappers';
import {
  emptyQuerySchema,
  LoginBody,
  loginBodySchema,
  RegisterBody,
  registerBodySchema,
} from '../schemas';

export const authRouter = Router();

const dateOfBirthBodySchema = z.object({
  dateOfBirth: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date of birth must use YYYY-MM-DD.')
    .refine((value) => {
      const date = new Date(`${value}T00:00:00.000Z`);
      return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
    }, 'Date of birth must be a real calendar date.')
    .refine((value) => value <= new Date().toISOString().slice(0, 10), 'Date of birth cannot be in the future.')
    .nullable(),
}).strict();

/**
 * POST /api/auth/register
 * Registers a new user and issues a signed JWT access token.
 */
authRouter.post(
  '/register',
  validateRequest({ body: registerBodySchema }),
  async (req, res, next) => {
    try {
      const { email, password, name } = req.body as RegisterBody;
      const prisma = getPrismaClient();

      const existing = await prisma.user.findUnique({ where: { email } });
      if (existing) {
        throw new AppError(409, 'EMAIL_ALREADY_EXISTS', `Email "${email}" is already registered.`);
      }

      const passwordHash = await bcrypt.hash(password, 10);
      const createdUser = await prisma.user.create({
        data: {
          email,
          passwordHash,
          name,
        },
      });

      const sharedUser = mapPrismaUserToShared(createdUser);
      const token = signAccessToken({ id: createdUser.id, email: createdUser.email });

      res.status(201).json({
        user: sharedUser,
        token,
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/auth/login
 * Authenticates user credentials and returns a signed JWT access token.
 */
authRouter.post(
  '/login',
  validateRequest({ body: loginBodySchema }),
  async (req, res, next) => {
    try {
      const { email, password } = req.body as LoginBody;
      const prisma = getPrismaClient();

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        throw new AppError(401, 'INVALID_CREDENTIALS', 'Invalid email or password.');
      }

      const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
      if (!isPasswordValid) {
        throw new AppError(401, 'INVALID_CREDENTIALS', 'Invalid email or password.');
      }

      const sharedUser = mapPrismaUserToShared(user);
      const token = signAccessToken({ id: user.id, email: user.email });

      res.status(200).json({
        user: sharedUser,
        token,
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/auth/me
 * Returns the currently authenticated user's profile.
 */
authRouter.get(
  '/me',
  authMiddleware,
  validateRequest({ query: emptyQuerySchema }),
  async (req, res, next) => {
    try {
      const prisma = getPrismaClient();
      const userId = req.user!.id;

      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!user) {
        throw new AppError(404, 'USER_NOT_FOUND', 'Authenticated user no longer exists.');
      }

      res.status(200).json({
        user: {
          ...mapPrismaUserToShared(user),
          dateOfBirth: user.dateOfBirth?.toISOString().slice(0, 10) ?? null,
        },
      });
    } catch (err) {
      next(err);
    }
  }
);

authRouter.patch(
  '/me',
  authMiddleware,
  validateRequest({ body: dateOfBirthBodySchema }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as { body: { dateOfBirth: string | null } };
      const dateOfBirth = validated.body.dateOfBirth
        ? new Date(`${validated.body.dateOfBirth}T00:00:00.000Z`)
        : null;
      const prisma = getPrismaClient();
      const user = await prisma.user.update({
        where: { id: req.user!.id },
        data: { dateOfBirth },
      });
      res.status(200).json({
        user: {
          ...mapPrismaUserToShared(user),
          dateOfBirth: user.dateOfBirth?.toISOString().slice(0, 10) ?? null,
        },
      });
    } catch (err) {
      next(err);
    }
  },
);
