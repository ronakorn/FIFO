import fs from 'fs';
import path from 'path';
import { Router } from 'express';
import { getPrismaClient } from '../../db/prisma';
import { calculateFIFO } from '../../fifoEngine';
import { authMiddleware } from '../../middleware/authMiddleware';
import { checkFeatureEntitlement } from '../../middleware/subscriptionGuard';
import { validateRequest } from '../../middleware/validationMiddleware';
import { generateTaxReportPDF } from '../../services/taxReportGenerator';
import { calculateThaiTax } from '../../services/thaiTaxEngine';
import { FIFOResult, TaxReport } from '../../types';
import {
  deriveReferencePricesTHB,
  mapPrismaDividendToEngine,
  mapPrismaTransactionToEngine,
} from '../mappers';
import {
  TaxQuery,
  TaxRouteParams,
  taxQuerySchema,
  taxRouteParamsSchema,
} from '../schemas';
import { requireOwnedPortfolio } from './portfolioRoutes';

export const taxRouter = Router();

function getStorageReportsDir(): string {
  return process.env['REPORTS_STORAGE_DIR'] ?? path.resolve(__dirname, '../../../storage/reports');
}

function extractUTCYear(dateStr: string): number {
  const prefixMatch = /^(\d{4})/.exec(dateStr.trim());
  if (prefixMatch && prefixMatch[1]) {
    return Number(prefixMatch[1]);
  }
  return new Date(dateStr).getUTCFullYear();
}

async function buildPortfolioTaxReport(
  portfolioId: string,
  userId: string,
  year: number,
  query: TaxQuery
): Promise<{ report: TaxReport; taxpayerName: string }> {
  const portfolio = await requireOwnedPortfolio(portfolioId, userId);
  void portfolio;

  const prisma = getPrismaClient();
  const [user, txRows, divRows] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId } }),
    prisma.transaction.findMany({
      where: { portfolioId },
      orderBy: { date: 'asc' },
    }),
    prisma.dividend.findMany({
      where: { portfolioId },
      orderBy: { date: 'asc' },
    }),
  ]);

  // Include BUY/SELL transactions up to the target taxYear
  const eligibleEngineTxs = txRows
    .filter((tx) => extractUTCYear(tx.date) <= year)
    .map(mapPrismaTransactionToEngine);

  let fifoResult: FIFOResult;
  if (eligibleEngineTxs.length === 0) {
    fifoResult = {
      lots: [],
      totalRealizedGL: 0,
      totalUnrealizedGL: 0,
      totalCostSold: 0,
      totalProceeds: 0,
    };
  } else {
    const buys = eligibleEngineTxs.filter((t) => t.type === 'BUY');
    const sells = eligibleEngineTxs.filter((t) => t.type === 'SELL');
    const refPrices = deriveReferencePricesTHB(eligibleEngineTxs);
    fifoResult = calculateFIFO(buys, sells, refPrices);
  }

  // Filter dividends received within the target taxYear
  const yearDividends = divRows
    .filter((d) => extractUTCYear(d.date) === year)
    .map(mapPrismaDividendToEngine);

  const report = calculateThaiTax(fifoResult, yearDividends, year, {
    electFinalTaxOnDividends: query.electFinalTaxOnDividends,
    otherNetIncomeTHB: query.otherNetIncomeTHB,
  });

  return {
    report,
    taxpayerName: user?.name ?? 'ผู้เสียภาษีเงินได้บุคคลธรรมดา',
  };
}

/**
 * GET /api/tax/summary/:portfolioId/:year
 * Computes and returns the annual Thai Tax Report JSON summary for a portfolio.
 */
taxRouter.get(
  '/summary/:portfolioId/:year',
  authMiddleware,
  validateRequest({
    params: taxRouteParamsSchema,
    query: taxQuerySchema,
  }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as {
        params: TaxRouteParams;
        query: TaxQuery;
      };

      const { report } = await buildPortfolioTaxReport(
        validated.params.portfolioId,
        req.user!.id,
        validated.params.year,
        validated.query
      );

      res.status(200).json(report);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/tax/report/:portfolioId/:year
 * Generates a submission-ready 5-page Thai Tax Compliance PDF report,
 * stores a copy in local filesystem + `UploadedFile` audit log, and streams the PDF.
 */
taxRouter.get(
  '/report/:portfolioId/:year',
  authMiddleware,
  checkFeatureEntitlement('taxReportPDF'),
  validateRequest({
    params: taxRouteParamsSchema,
    query: taxQuerySchema,
  }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as {
        params: TaxRouteParams;
        query: TaxQuery;
      };
      const { portfolioId, year } = validated.params;
      const userId = req.user!.id;

      const { report, taxpayerName } = await buildPortfolioTaxReport(
        portfolioId,
        userId,
        year,
        validated.query
      );

      const reportsDir = getStorageReportsDir();
      await fs.promises.mkdir(reportsDir, { recursive: true });

      const filename = `FIFO_Wealth_OS_Tax_Report_${year}.pdf`;
      const diskFilename = `${Date.now()}_${portfolioId}_${filename}`;
      const outputPath = path.join(reportsDir, diskFilename);

      await generateTaxReportPDF(report, outputPath, {
        taxpayerName,
      });

      const prisma = getPrismaClient();
      await prisma.uploadedFile.create({
        data: {
          userId,
          portfolioId,
          filename,
          type: 'PDF',
          path: outputPath,
        },
      });

      const pdfBuffer = await fs.promises.readFile(outputPath);

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Length', String(pdfBuffer.byteLength));
      res.status(200).send(pdfBuffer);
    } catch (err) {
      next(err);
    }
  }
);
