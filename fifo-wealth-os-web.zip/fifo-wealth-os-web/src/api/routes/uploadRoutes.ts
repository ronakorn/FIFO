import fs from 'fs';
import path from 'path';
import { Router } from 'express';
import multer from 'multer';
import { getPrismaClient } from '../../db/prisma';
import { calculateFIFO } from '../../fifoEngine';
import { authMiddleware } from '../../middleware/authMiddleware';
import { AppError } from '../../middleware/errorHandler';
import { validateRequest } from '../../middleware/validationMiddleware';
import { parseBitkubCSV } from '../../parsers/bitkubParser';
import { parseDividends } from '../../parsers/dividendParser';
import { parseIBKRCsv } from '../../parsers/ibkrParser';
import { enrichDividendsWithFX } from '../../services/dividendEnricher';
import { enrichTransactionsWithFX } from '../../services/transactionEnricher';
import { defaultApiFXProvider } from '../fxProvider';
import { assertTransactionDatesWithinAnnualLimit } from '../../services/entitlementService';
import {
  deriveReferencePricesTHB,
  mapEngineTransactionToPrismaCreate,
  mapPrismaDividendToShared,
  mapPrismaTransactionToEngine,
  mapPrismaTransactionToShared,
  mapPrismaUploadedFileToShared,
} from '../mappers';
import {
  UploadCsvBody,
  uploadCsvBodySchema,
  UploadDividendsBody,
  uploadDividendsBodySchema,
} from '../schemas';
import { requireOwnedPortfolio } from './portfolioRoutes';

export const uploadRouter = Router();

const csvMemoryUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10 MB max CSV upload
  },
});

function getStorageUploadsDir(): string {
  return (
    process.env['STORAGE_DIR'] ?? path.resolve(__dirname, '../../../storage/uploads/csv')
  );
}

function sanitizeFilename(rawName: string): string {
  return rawName.replace(/[^a-zA-Z0-9._-]/g, '_');
}

/**
 * POST /api/upload/csv
 * Accepts multipart/form-data (`file`, `portfolioId`, `exchange`), parses CSV via Bitkub/IBKR adapter,
 * enriches multi-currency FX into portfolio baseCurrency, persists to DB + filesystem,
 * and returns `{ transactions, summary, uploadedFile }`.
 */
uploadRouter.post(
  '/csv',
  authMiddleware,
  csvMemoryUpload.single('file'),
  validateRequest({ body: uploadCsvBodySchema }),
  async (req, res, next) => {
    try {
      if (!req.file) {
        throw new AppError(400, 'MISSING_CSV_FILE', 'CSV file is required under field "file".');
      }

      const { portfolioId, exchange, vatRate } = req.body as UploadCsvBody;
      const userId = req.user!.id;
      const portfolio = await requireOwnedPortfolio(portfolioId, userId);

      const csvContent = req.file.buffer.toString('utf8');

      const parsedTransactions =
        exchange === 'BITKUB'
          ? parseBitkubCSV(csvContent, vatRate !== undefined ? { vatRate } : undefined)
          : exchange === 'IBKR'
            ? parseIBKRCsv(csvContent)
            : (() => {
                throw new AppError(
                  400,
                  'UNSUPPORTED_EXCHANGE_ADAPTER',
                  `CSV parser adapter for "${exchange}" is not yet enabled. Supported: BITKUB, IBKR.`
                );
              })();

      if (parsedTransactions.length === 0) {
        throw new AppError(400, 'EMPTY_CSV_TRANSACTIONS', 'Uploaded CSV contains no transaction rows.');
      }

      const enrichedTransactions = await enrichTransactionsWithFX(
        parsedTransactions,
        defaultApiFXProvider,
        portfolio.baseCurrency
      );
      await assertTransactionDatesWithinAnnualLimit(
        userId,
        enrichedTransactions.map((transaction) => transaction.date)
      );

      // Persist raw CSV file to local filesystem storage
      const uploadsDir = getStorageUploadsDir();
      await fs.promises.mkdir(uploadsDir, { recursive: true });
      const safeFilename = `${Date.now()}_${sanitizeFilename(req.file.originalname || 'trades.csv')}`;
      const storedPath = path.join(uploadsDir, safeFilename);
      await fs.promises.writeFile(storedPath, req.file.buffer);

      const prisma = getPrismaClient();

      const { uploadedFileRow, createdTxRows } = await prisma.$transaction(async (txClient) => {
        const fileRecord = await txClient.uploadedFile.create({
          data: {
            userId,
            portfolioId,
            filename: req.file!.originalname || safeFilename,
            type: 'CSV',
            path: storedPath,
          },
        });

        const createdRows = [];
        for (const engineTx of enrichedTransactions) {
          const row = await txClient.transaction.create({
            data: mapEngineTransactionToPrismaCreate(engineTx, portfolioId),
          });
          createdRows.push(row);
        }

        return { uploadedFileRow: fileRecord, createdTxRows: createdRows };
      });

      // Compute updated FIFO summary across all transactions in this portfolio
      const allPortfolioTxRows = await prisma.transaction.findMany({
        where: { portfolioId },
        orderBy: { date: 'asc' },
      });

      const allEngineTxs = allPortfolioTxRows.map(mapPrismaTransactionToEngine);
      const buys = allEngineTxs.filter((t) => t.type === 'BUY');
      const sells = allEngineTxs.filter((t) => t.type === 'SELL');
      const referencePrices = deriveReferencePricesTHB(allEngineTxs);

      const fifoResult = calculateFIFO(buys, sells, referencePrices);

      res.status(201).json({
        transactions: createdTxRows.map(mapPrismaTransactionToShared),
        summary: {
          count: createdTxRows.length,
          totalRealizedGL: fifoResult.totalRealizedGL,
          totalUnrealizedGL: fifoResult.totalUnrealizedGL,
          totalCostSold: fifoResult.totalCostSold,
          totalProceeds: fifoResult.totalProceeds,
        },
        uploadedFile: mapPrismaUploadedFileToShared(uploadedFileRow),
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/upload/dividends
 * Accepts multipart/form-data (`file`, `portfolioId`[, `defaultCurrency`]),
 * parses Dividend CSV, enriches FX to portfolio baseCurrency, and persists records.
 */
uploadRouter.post(
  '/dividends',
  authMiddleware,
  csvMemoryUpload.single('file'),
  validateRequest({ body: uploadDividendsBodySchema }),
  async (req, res, next) => {
    try {
      if (!req.file) {
        throw new AppError(
          400,
          'MISSING_DIVIDEND_CSV_FILE',
          'Dividend CSV file is required under field "file".'
        );
      }

      const { portfolioId, defaultCurrency } = req.body as UploadDividendsBody;
      const userId = req.user!.id;
      const portfolio = await requireOwnedPortfolio(portfolioId, userId);

      const csvContent = req.file.buffer.toString('utf8');
      const parsedDividends = parseDividends(csvContent, {
        defaultCurrency: defaultCurrency ?? portfolio.baseCurrency,
      });

      if (parsedDividends.length === 0) {
        throw new AppError(400, 'EMPTY_DIVIDEND_CSV', 'Uploaded Dividend CSV contains no rows.');
      }

      const enrichedDividends = await enrichDividendsWithFX(
        parsedDividends,
        defaultApiFXProvider,
        portfolio.baseCurrency
      );

      const uploadsDir = getStorageUploadsDir();
      await fs.promises.mkdir(uploadsDir, { recursive: true });
      const safeFilename = `${Date.now()}_${sanitizeFilename(req.file.originalname || 'dividends.csv')}`;
      const storedPath = path.join(uploadsDir, safeFilename);
      await fs.promises.writeFile(storedPath, req.file.buffer);

      const prisma = getPrismaClient();

      const { uploadedFileRow, createdDividends } = await prisma.$transaction(async (txClient) => {
        const fileRecord = await txClient.uploadedFile.create({
          data: {
            userId,
            portfolioId,
            filename: req.file!.originalname || safeFilename,
            type: 'CSV',
            path: storedPath,
          },
        });

        const rows = [];
        for (const div of enrichedDividends) {
          const row = await txClient.dividend.create({
            data: {
              portfolioId,
              date: div.date,
              symbol: div.symbol,
              qty: div.qty,
              divPerShare: div.divPerShare,
              gross: div.gross,
              whtRate: div.whtRate,
              wht: div.wht,
              net: div.net,
              originalCurrency: div.originalCurrency,
              fxRate: div.fxRate,
              grossTHB: div.grossTHB,
              whtTHB: div.whtTHB,
              netTHB: div.netTHB,
            },
          });
          rows.push(row);
        }

        return { uploadedFileRow: fileRecord, createdDividends: rows };
      });

      res.status(201).json({
        dividends: createdDividends.map(mapPrismaDividendToShared),
        count: createdDividends.length,
        uploadedFile: mapPrismaUploadedFileToShared(uploadedFileRow),
      });
    } catch (err) {
      next(err);
    }
  }
);
