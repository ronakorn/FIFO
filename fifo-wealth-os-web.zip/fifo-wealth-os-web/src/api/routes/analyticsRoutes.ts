import Decimal from 'decimal.js';
import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../../db/prisma';
import { calculateFIFO } from '../../fifoEngine';
import { authMiddleware } from '../../middleware/authMiddleware';
import { validateRequest } from '../../middleware/validationMiddleware';
import { buildDashboardAnalytics } from '../../services/quantEngine';
import { Lot } from '../../types';
import { BenchmarkSymbol, CashFlow } from '../../types/analytics';
import {
  deriveReferencePricesTHB,
  mapPrismaTransactionToEngine,
} from '../mappers';
import { requireOwnedPortfolio } from './portfolioRoutes';

export const analyticsRouter = Router();

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

const analyticsQuerySchema = z.object({
  benchmark: z.enum(['SP500', 'SET50']).optional().default('SP500'),
  portfolioId: z.string().uuid().optional(),
});

type AnalyticsQuery = z.infer<typeof analyticsQuerySchema>;

/**
 * GET /api/analytics/dashboard
 * Computes institutional Quant Metrics (XIRR, TWR, Sharpe, Sortino, Max Drawdown, Total Return),
 * Benchmark Comparison (SP500 / SET50), and 5-Bucket THB Asset Allocation using Decimal.js.
 */
analyticsRouter.get(
  '/dashboard',
  authMiddleware,
  validateRequest({ query: analyticsQuerySchema }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as { query: AnalyticsQuery };
      const benchmark: BenchmarkSymbol = validated.query.benchmark;
      const requestedPortfolioId = validated.query.portfolioId;

      const prisma = getPrismaClient();
      let portfolioIds: string[] = [];

      if (requestedPortfolioId) {
        const owned = await requireOwnedPortfolio(requestedPortfolioId, req.user!.id);
        portfolioIds = [owned.id];
      } else {
        const ownedPortfolios = await prisma.portfolio.findMany({
          where: { userId: req.user!.id },
          select: { id: true },
        });
        portfolioIds = ownedPortfolios.map((p) => p.id);
      }

      const cashFlows: CashFlow[] = [];
      const allOpenLots: Lot[] = [];
      let netCashReserveTHB = new Dec(0);

      for (const pid of portfolioIds) {
        const [txRows, divRows] = await Promise.all([
          prisma.transaction.findMany({
            where: { portfolioId: pid },
            orderBy: { date: 'asc' },
          }),
          prisma.dividend.findMany({
            where: { portfolioId: pid },
            orderBy: { date: 'asc' },
          }),
        ]);

        if (txRows.length > 0) {
          const engineTxs = txRows.map(mapPrismaTransactionToEngine);
          const buys = engineTxs.filter((t) => t.type === 'BUY');
          const sells = engineTxs.filter((t) => t.type === 'SELL');
          const refPrices = deriveReferencePricesTHB(engineTxs);

          for (const tx of engineTxs) {
            const thbVal = new Dec(tx.netTHB ?? tx.net.toString());
            if (tx.type === 'BUY') {
              cashFlows.push({
                date: tx.date,
                amount: thbVal.negated().toFixed(4),
              });
            } else if (tx.type === 'SELL') {
              cashFlows.push({
                date: tx.date,
                amount: thbVal.toFixed(4),
              });
              // Retain 15% of realized proceeds as modeled THB liquidity reserve
              netCashReserveTHB = netCashReserveTHB.plus(thbVal.times(new Dec('0.15')));
            }
          }

          if (buys.length > 0) {
            const fifo = calculateFIFO(buys, sells, refPrices);
            for (const lot of fifo.lots) {
              if (lot.qtyRemain > 0) {
                allOpenLots.push(lot);
              }
            }
          }
        }

        for (const div of divRows) {
          const divThb = new Dec(div.netTHB ?? div.net);
          cashFlows.push({
            date: div.date,
            amount: divThb.toFixed(4),
          });
          netCashReserveTHB = netCashReserveTHB.plus(divThb);
        }
      }

      const payload = buildDashboardAnalytics({
        cashFlows,
        openLots: allOpenLots,
        realizedProceedsCashTHB: netCashReserveTHB.toFixed(4),
        benchmark,
        scope: requestedPortfolioId ?? 'ALL_PORTFOLIOS',
      });

      res.status(200).json(payload);
    } catch (err) {
      next(err);
    }
  }
);
