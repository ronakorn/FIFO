import { Router } from 'express';
import { getPrismaClient } from '../../db/prisma';
import { authMiddleware } from '../../middleware/authMiddleware';
import { validateRequest } from '../../middleware/validationMiddleware';
import { mapPrismaTransactionToShared } from '../mappers';
import {
  TransactionsQuery,
  transactionsParamsSchema,
  transactionsQuerySchema,
} from '../schemas';
import { requireOwnedPortfolio } from './portfolioRoutes';

export const transactionRouter = Router();

/**
 * GET /api/transactions/:portfolioId
 * Lists all transactions for an owned portfolio, supporting optional `?type=BUY|SELL&symbol=BTC` filters.
 */
transactionRouter.get(
  '/:portfolioId',
  authMiddleware,
  validateRequest({
    params: transactionsParamsSchema,
    query: transactionsQuerySchema,
  }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as {
        params: { portfolioId: string };
        query: TransactionsQuery;
      };
      const { portfolioId } = validated.params;
      const { type, symbol } = validated.query;

      await requireOwnedPortfolio(portfolioId, req.user!.id);

      const prisma = getPrismaClient();
      const rows = await prisma.transaction.findMany({
        where: {
          portfolioId,
          ...(type ? { type } : {}),
          ...(symbol ? { symbol } : {}),
        },
        orderBy: { date: 'asc' },
      });

      res.status(200).json(rows.map(mapPrismaTransactionToShared));
    } catch (err) {
      next(err);
    }
  }
);
