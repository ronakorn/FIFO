import { Router } from 'express';
import { z } from 'zod';
import { authMiddleware } from '../middleware/authMiddleware';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  deleteCryptoWallet,
  listUserCryptoWallets,
  registerCryptoWallet,
  setCryptoWalletActiveState,
  syncCryptoWalletOnChain,
} from '../services/cryptoWalletService';
import { SUPPORTED_CHAINS } from '../types/crypto';

export const cryptoRouter = Router();

const walletIdParamsSchema = z.object({
  id: z.string().uuid('Invalid wallet ID.'),
});

const createWalletBodySchema = z.object({
  address: z.string().trim().min(10, 'Public wallet address is required.'),
  chain: z.enum(SUPPORTED_CHAINS).optional(),
  label: z.string().trim().max(80).optional(),
  portfolioId: z.string().uuid().optional(),
});

const toggleWalletBodySchema = z.object({
  isActive: z.boolean(),
});

const syncWalletBodySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  delayMs: z.coerce.number().int().min(0).max(5000).optional(),
});

/**
 * GET /api/crypto/wallets
 * Lists authenticated user's Read-Only cross-chain wallets (masked address + SHA-256 hash only).
 */
cryptoRouter.get('/wallets', authMiddleware, async (req, res, next) => {
  try {
    const wallets = await listUserCryptoWallets(req.user!.id);
    res.status(200).json({
      privacyPolicy: 'NO_PRIVATE_KEYS_AES256_GCM_SHA256',
      wallets,
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/crypto/wallets
 * Registers a Read-Only public wallet address (auto-detects EVM / SOLANA / BTC),
 * blocks any Private Key / Seed Phrase, and stores encrypted + SHA-256 hashed address.
 */
cryptoRouter.post(
  '/wallets',
  authMiddleware,
  validateRequest({ body: createWalletBodySchema }),
  async (req, res, next) => {
    try {
      const body = (res.locals['validated'] as {
        body: z.infer<typeof createWalletBodySchema>;
      }).body;

      const wallet = await registerCryptoWallet({
        userId: req.user!.id,
        address: body.address,
        chain: body.chain,
        label: body.label,
        portfolioId: body.portfolioId,
      });

      res.status(201).json({ wallet });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/crypto/wallets/:id/sync
 * Syncs On-Chain Token Balances, Swaps (SELL + BUY + FEE), and Transfers into CDM idempotently.
 */
cryptoRouter.post(
  '/wallets/:id/sync',
  authMiddleware,
  validateRequest({
    params: walletIdParamsSchema,
    body: syncWalletBodySchema,
  }),
  async (req, res, next) => {
    try {
      const { params, body } = res.locals['validated'] as {
        params: z.infer<typeof walletIdParamsSchema>;
        body: z.infer<typeof syncWalletBodySchema>;
      };

      if (body.delayMs && body.delayMs > 0) {
        await new Promise((resolve) =>
          setTimeout(resolve, Math.min(body.delayMs!, 5000))
        );
      }

      const result = await syncCryptoWalletOnChain(req.user!.id, params.id, {
        portfolioId: body.portfolioId,
      });

      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * PATCH /api/crypto/wallets/:id
 * Toggles `isActive` state for an owned wallet.
 */
cryptoRouter.patch(
  '/wallets/:id',
  authMiddleware,
  validateRequest({
    params: walletIdParamsSchema,
    body: toggleWalletBodySchema,
  }),
  async (req, res, next) => {
    try {
      const { params, body } = res.locals['validated'] as {
        params: z.infer<typeof walletIdParamsSchema>;
        body: z.infer<typeof toggleWalletBodySchema>;
      };

      const wallet = await setCryptoWalletActiveState(
        req.user!.id,
        params.id,
        body.isActive
      );

      res.status(200).json({ wallet });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * DELETE /api/crypto/wallets/:id
 * Permanently removes encrypted wallet record (PDPA Right to be Forgotten).
 */
cryptoRouter.delete(
  '/wallets/:id',
  authMiddleware,
  validateRequest({ params: walletIdParamsSchema }),
  async (req, res, next) => {
    try {
      const { params } = res.locals['validated'] as {
        params: z.infer<typeof walletIdParamsSchema>;
      };

      const result = await deleteCryptoWallet(req.user!.id, params.id);
      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
);

export default cryptoRouter;
