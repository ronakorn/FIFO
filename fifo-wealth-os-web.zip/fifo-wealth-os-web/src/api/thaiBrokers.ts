import { Router } from 'express';
import { z } from 'zod';
import { STREAMING_SET_OPEN_API_ROADMAP_TEXT } from '../adapters/thaiBrokerAdapters';
import { authMiddleware } from '../middleware/authMiddleware';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  connectThaiBroker,
  disconnectAndPurgeThaiBroker,
  listThaiBrokerConnections,
  triggerThaiBrokerSync,
} from '../services/thaiBrokerSyncService';
import {
  CURRENT_PDPA_CONSENT_VERSION,
  THAI_BROKER_IDS,
  ThaiBrokerCredentials,
} from '../types/thaiBrokers';

export const thaiBrokerRouter = Router();

const brokerParamSchema = z.object({
  broker: z
    .string()
    .trim()
    .transform((v) => v.toUpperCase())
    .pipe(z.enum(THAI_BROKER_IDS)),
});

const pdpaConsentSchema = z.object({
  accepted: z.boolean(),
  consentVersion: z.string().trim().optional(),
  purposes: z.array(z.string()).optional(),
});

const connectThaiBrokerBodySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  pdpaConsent: pdpaConsentSchema,
  // Bitkub fields
  apiKey: z.string().trim().optional(),
  apiSecret: z.string().trim().optional(),
  permissionsScope: z.enum(['READ_ONLY', 'TRADE', 'WITHDRAW']).optional(),
  // Dime! fields
  dimeAccountRef: z.string().trim().optional(),
  partnerAccessToken: z.string().trim().optional(),
  mode: z
    .enum(['OPEN_API_HYBRID', 'SECURE_STATEMENT_AUTOMATION'])
    .optional(),
  // Streaming fields
  memberBrokerCode: z.string().trim().optional(),
  accountRef: z.string().trim().optional(),
  statementSyncToken: z.string().trim().optional(),
});

const syncBodySchema = z.object({
  portfolioId: z.string().uuid().optional(),
  delayMs: z.coerce.number().int().min(0).max(5000).optional(),
});

const disconnectQuerySchema = z.object({
  purgeData: z
    .enum(['true', 'false'])
    .optional()
    .default('true')
    .transform((v) => v !== 'false'),
});

/**
 * GET /api/thai-brokers/status
 * Lists Read-Only connection status for Bitkub, Dime!, and Settrade Streaming.
 */
thaiBrokerRouter.get('/status', authMiddleware, async (req, res, next) => {
  try {
    const connections = await listThaiBrokerConnections(req.user!.id);
    res.status(200).json({
      hubBadge: 'Official Partner Integration Ready',
      regulatoryFramework: 'Designed for Thai SEC Partner Review & PDPA B.E. 2562 Controls',
      currentConsentVersion: CURRENT_PDPA_CONSENT_VERSION,
      streamingRoadmapNotice: STREAMING_SET_OPEN_API_ROADMAP_TEXT,
      connections,
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/thai-brokers/:broker/connect
 * Requires PDPA Data Privacy Consent (`pdpaConsent.accepted === true`) and encrypts
 * Read-Only API credentials via AES-256-GCM before storing in DB.
 */
thaiBrokerRouter.post(
  '/:broker/connect',
  authMiddleware,
  validateRequest({
    params: brokerParamSchema,
    body: connectThaiBrokerBodySchema,
  }),
  async (req, res, next) => {
    try {
      const { params, body } = res.locals['validated'] as {
        params: z.infer<typeof brokerParamSchema>;
        body: z.infer<typeof connectThaiBrokerBodySchema>;
      };

      let credentials: ThaiBrokerCredentials;
      if (params.broker === 'BITKUB') {
        credentials = {
          broker: 'BITKUB',
          apiKey: body.apiKey ?? '',
          apiSecret: body.apiSecret ?? '',
          permissionsScope: body.permissionsScope,
        };
      } else if (params.broker === 'DIME') {
        credentials = {
          broker: 'DIME',
          dimeAccountRef: body.dimeAccountRef ?? '',
          partnerAccessToken: body.partnerAccessToken,
          mode: body.mode,
        };
      } else {
        credentials = {
          broker: 'STREAMING',
          memberBrokerCode: body.memberBrokerCode ?? 'INVX',
          accountRef: body.accountRef ?? '',
          statementSyncToken: body.statementSyncToken ?? '',
        };
      }

      const connection = await connectThaiBroker({
        userId: req.user!.id,
        credentials,
        pdpaConsent: body.pdpaConsent,
        portfolioId: body.portfolioId,
      });

      res.status(201).json({ connection });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/thai-brokers/:broker/sync
 * Triggers On-Demand Read-Only Sync for Bitkub, Dime!, or Settrade Streaming.
 */
thaiBrokerRouter.post(
  '/:broker/sync',
  authMiddleware,
  validateRequest({
    params: brokerParamSchema,
    body: syncBodySchema,
  }),
  async (req, res, next) => {
    try {
      const { params, body } = res.locals['validated'] as {
        params: z.infer<typeof brokerParamSchema>;
        body: z.infer<typeof syncBodySchema>;
      };

      const result = await triggerThaiBrokerSync(req.user!.id, params.broker, {
        portfolioId: body.portfolioId,
        delayMs: body.delayMs,
      });

      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * DELETE /api/thai-brokers/:broker/disconnect
 * Executes immediate "Disconnect & Purge Data" (PDPA Right to be Forgotten).
 */
thaiBrokerRouter.delete(
  '/:broker/disconnect',
  authMiddleware,
  validateRequest({
    params: brokerParamSchema,
    query: disconnectQuerySchema,
  }),
  async (req, res, next) => {
    try {
      const { params, query } = res.locals['validated'] as {
        params: z.infer<typeof brokerParamSchema>;
        query: z.infer<typeof disconnectQuerySchema>;
      };

      const result = await disconnectAndPurgeThaiBroker(
        req.user!.id,
        params.broker,
        { purgeSyncedData: query.purgeData }
      );

      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
);

export default thaiBrokerRouter;
