import Decimal from 'decimal.js';
import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { calculateFIFO } from '../fifoEngine';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import {
  calculateFIRENumber,
  calculateGoalProgress,
  calculateYearsToFIRE,
  runMonteCarloSimulation,
} from '../services/fireEngine';
import { FIREGoal, FIRESummaryResponse } from '../types/fire';
import { deriveReferencePricesTHB, mapPrismaTransactionToEngine } from './mappers';

export const fireRouter = Router();

const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });

const numericDecimalStr = z
  .string()
  .trim()
  .refine((val) => {
    try {
      const d = new Dec(val);
      return d.isFinite();
    } catch {
      return false;
    }
  }, 'Must be a valid decimal string.');

const nonNegativeDecimalStr = numericDecimalStr.refine(
  (val) => new Dec(val).gte(0),
  'Must be a non-negative decimal string.'
);

const positiveDecimalStr = numericDecimalStr.refine(
  (val) => new Dec(val).gt(0),
  'Must be a strictly positive decimal string.'
);

const createGoalSchema = z.object({
  name: z.string().trim().min(1, 'Goal name is required.').max(120),
  targetAmount: positiveDecimalStr,
  currentAmount: nonNegativeDecimalStr.optional().default('0'),
  monthlyContribution: nonNegativeDecimalStr,
  expectedReturn: numericDecimalStr,
  inflationRate: numericDecimalStr.optional().default('0.03'),
  targetYear: z.coerce.number().int().min(2024).max(2120),
  currentAge: z.coerce.number().int().min(15).max(100),
  retirementAge: z.coerce.number().int().min(20).max(110),
});

const updateGoalSchema = createGoalSchema.partial();

const goalIdParamSchema = z.object({
  id: z.string().uuid('Invalid goal UUID.'),
});

const monteCarloBodySchema = z.object({
  currentAmount: nonNegativeDecimalStr,
  monthlyContribution: nonNegativeDecimalStr,
  expectedReturn: numericDecimalStr,
  volatility: nonNegativeDecimalStr.optional().default('0.15'),
  years: z.coerce.number().int().min(1).max(70).optional().default(25),
  numSimulations: z.coerce.number().int().min(10).max(2000).optional().default(150),
  seed: z.string().max(120).optional(),
  targetAmount: positiveDecimalStr.optional(),
});

const summaryQuerySchema = z.object({
  annualExpenses: nonNegativeDecimalStr.optional().default('480000'),
  withdrawalRate: positiveDecimalStr.optional().default('0.04'),
  monthlyContribution: nonNegativeDecimalStr.optional().default('25000'),
  expectedReturn: numericDecimalStr.optional().default('0.08'),
  inflationRate: numericDecimalStr.optional().default('0.03'),
  volatility: nonNegativeDecimalStr.optional().default('0.15'),
  years: z.coerce.number().int().min(1).max(70).optional().default(25),
  numSimulations: z.coerce.number().int().min(10).max(1000).optional().default(120),
  seed: z.string().max(120).optional().default('wealthos-fire-summary-2026'),
});

function mapPrismaGoalToDTO(row: {
  id: string;
  userId: string;
  name: string;
  targetAmount: string;
  currentAmount: string;
  monthlyContribution: string;
  expectedReturn: string;
  inflationRate: string;
  targetYear: number;
  currentAge: number;
  retirementAge: number;
  createdAt: Date;
  updatedAt: Date;
}): FIREGoal {
  return {
    id: row.id,
    userId: row.userId,
    name: row.name,
    targetAmount: new Dec(row.targetAmount)
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2),
    currentAmount: new Dec(row.currentAmount)
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2),
    monthlyContribution: new Dec(row.monthlyContribution)
      .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
      .toFixed(2),
    expectedReturn: row.expectedReturn,
    inflationRate: row.inflationRate,
    targetYear: row.targetYear,
    currentAge: row.currentAge,
    retirementAge: row.retirementAge,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/**
 * Computes the user's live aggregated THB portfolio value across all owned portfolios
 * using the FIFO engine + liquidity reserves (100% Decimal.js precision 40).
 */
export async function computeUserLivePortfolioValueTHB(userId: string): Promise<string> {
  const prisma = getPrismaClient();
  const portfolios = await prisma.portfolio.findMany({
    where: { userId },
    select: { id: true },
  });

  let totalValue = new Dec(0);

  for (const p of portfolios) {
    const [txRows, divRows] = await Promise.all([
      prisma.transaction.findMany({
        where: { portfolioId: p.id },
        orderBy: { date: 'asc' },
      }),
      prisma.dividend.findMany({
        where: { portfolioId: p.id },
        orderBy: { date: 'asc' },
      }),
    ]);

    if (txRows.length > 0) {
      const engineTxs = txRows.map(mapPrismaTransactionToEngine);
      const buys = engineTxs.filter((t) => t.type === 'BUY');
      const sells = engineTxs.filter((t) => t.type === 'SELL');
      const refPrices = deriveReferencePricesTHB(engineTxs);

      for (const tx of sells) {
        const thbVal = new Dec(tx.netTHB ?? tx.net.toString());
        totalValue = totalValue.plus(thbVal.times(new Dec('0.15')));
      }

      if (buys.length > 0) {
        const fifo = calculateFIFO(buys, sells, refPrices);
        for (const lot of fifo.lots) {
          if (lot.qtyRemain > 0) {
            const symPrice = new Dec(
              (refPrices[lot.symbol] ?? lot.costPerUnit).toString()
            );
            const qtyDec = new Dec(lot.qtyRemain.toString());
            totalValue = totalValue.plus(symPrice.times(qtyDec));
          }
        }
      }
    }

    for (const div of divRows) {
      totalValue = totalValue.plus(new Dec(div.netTHB ?? div.net));
    }
  }

  return totalValue.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
}

async function requireOwnedGoal(goalId: string, userId: string) {
  const prisma = getPrismaClient();
  const goal = await prisma.fireGoal.findUnique({ where: { id: goalId } });
  if (!goal) {
    throw new AppError(404, 'FIRE_GOAL_NOT_FOUND', 'FIRE Goal not found.');
  }
  if (goal.userId !== userId) {
    throw new AppError(
      403,
      'FORBIDDEN_FIRE_GOAL',
      'You do not have permission to access this FIRE Goal.'
    );
  }
  return goal;
}

/**
 * POST /api/fire/goals
 * Creates a new financial independence or retirement goal for the authenticated user.
 */
fireRouter.post(
  '/goals',
  authMiddleware,
  validateRequest({ body: createGoalSchema }),
  async (req, res, next) => {
    try {
      const { body } = res.locals['validated'] as {
        body: z.infer<typeof createGoalSchema>;
      };
      const prisma = getPrismaClient();

      const created = await prisma.fireGoal.create({
        data: {
          userId: req.user!.id,
          name: body.name,
          targetAmount: new Dec(body.targetAmount).toFixed(2),
          currentAmount: new Dec(body.currentAmount).toFixed(2),
          monthlyContribution: new Dec(body.monthlyContribution).toFixed(2),
          expectedReturn: body.expectedReturn,
          inflationRate: body.inflationRate,
          targetYear: body.targetYear,
          currentAge: body.currentAge,
          retirementAge: body.retirementAge,
        },
      });

      res.status(201).json(mapPrismaGoalToDTO(created));
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/fire/goals
 * Lists all FIRE goals owned by the authenticated user.
 */
fireRouter.get('/goals', authMiddleware, async (req, res, next) => {
  try {
    const prisma = getPrismaClient();
    const rows = await prisma.fireGoal.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: 'asc' },
    });

    res.status(200).json(rows.map(mapPrismaGoalToDTO));
  } catch (err) {
    next(err);
  }
});

/**
 * PUT /api/fire/goals/:id
 * Updates an existing owned FIRE goal.
 */
fireRouter.put(
  '/goals/:id',
  authMiddleware,
  validateRequest({ params: goalIdParamSchema, body: updateGoalSchema }),
  async (req, res, next) => {
    try {
      const { params, body } = res.locals['validated'] as {
        params: z.infer<typeof goalIdParamSchema>;
        body: z.infer<typeof updateGoalSchema>;
      };

      await requireOwnedGoal(params.id, req.user!.id);
      const prisma = getPrismaClient();

      const updated = await prisma.fireGoal.update({
        where: { id: params.id },
        data: {
          ...(body.name !== undefined ? { name: body.name } : {}),
          ...(body.targetAmount !== undefined
            ? { targetAmount: new Dec(body.targetAmount).toFixed(2) }
            : {}),
          ...(body.currentAmount !== undefined
            ? { currentAmount: new Dec(body.currentAmount).toFixed(2) }
            : {}),
          ...(body.monthlyContribution !== undefined
            ? { monthlyContribution: new Dec(body.monthlyContribution).toFixed(2) }
            : {}),
          ...(body.expectedReturn !== undefined
            ? { expectedReturn: body.expectedReturn }
            : {}),
          ...(body.inflationRate !== undefined
            ? { inflationRate: body.inflationRate }
            : {}),
          ...(body.targetYear !== undefined ? { targetYear: body.targetYear } : {}),
          ...(body.currentAge !== undefined ? { currentAge: body.currentAge } : {}),
          ...(body.retirementAge !== undefined
            ? { retirementAge: body.retirementAge }
            : {}),
        },
      });

      res.status(200).json(mapPrismaGoalToDTO(updated));
    } catch (err) {
      next(err);
    }
  }
);

/**
 * DELETE /api/fire/goals/:id
 * Deletes an owned FIRE goal.
 */
fireRouter.delete(
  '/goals/:id',
  authMiddleware,
  validateRequest({ params: goalIdParamSchema }),
  async (req, res, next) => {
    try {
      const { params } = res.locals['validated'] as {
        params: z.infer<typeof goalIdParamSchema>;
      };
      await requireOwnedGoal(params.id, req.user!.id);
      const prisma = getPrismaClient();
      await prisma.fireGoal.delete({ where: { id: params.id } });

      res.status(200).json({
        id: params.id,
        message: 'FIRE Goal deleted successfully.',
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/fire/goals/:id/progress
 * Computes real-time goal progress by combining live FIFO Portfolio Value (THB)
 * with any additional capital allocated in goal.currentAmount.
 */
fireRouter.get(
  '/goals/:id/progress',
  authMiddleware,
  validateRequest({ params: goalIdParamSchema }),
  async (req, res, next) => {
    try {
      const { params } = res.locals['validated'] as {
        params: z.infer<typeof goalIdParamSchema>;
      };
      const row = await requireOwnedGoal(params.id, req.user!.id);
      const goalDTO = mapPrismaGoalToDTO(row);

      const livePortfolioTHB = await computeUserLivePortfolioValueTHB(req.user!.id);
      const combinedWealth = new Dec(livePortfolioTHB)
        .plus(new Dec(goalDTO.currentAmount))
        .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
        .toFixed(2);

      const progress = calculateGoalProgress(goalDTO, combinedWealth);

      res.status(200).json({
        ...progress,
        livePortfolioValueTHB: livePortfolioTHB,
      });
    } catch (err) {
      next(err);
    }
  }
);

/**
 * POST /api/fire/monte-carlo
 * Runs deterministic Geometric Brownian Motion (GBM) Monte Carlo simulations.
 */
fireRouter.post(
  '/monte-carlo',
  authMiddleware,
  validateRequest({ body: monteCarloBodySchema }),
  async (_req, res, next) => {
    try {
      const { body } = res.locals['validated'] as {
        body: z.infer<typeof monteCarloBodySchema>;
      };

      const result = runMonteCarloSimulation(
        body.currentAmount,
        body.monthlyContribution,
        body.expectedReturn,
        body.volatility,
        body.years,
        body.numSimulations,
        body.seed,
        body.targetAmount ? { targetAmount: body.targetAmount } : undefined
      );

      res.status(200).json(result);
    } catch (err) {
      next(err);
    }
  }
);

/**
 * GET /api/fire/summary
 * Aggregates overall FIRE Number, Years to FIRE, Monte Carlo Success Rate,
 * live portfolio capital, and progress across all user FIRE Goals.
 */
fireRouter.get(
  '/summary',
  authMiddleware,
  validateRequest({ query: summaryQuerySchema }),
  async (req, res, next) => {
    try {
      const { query } = res.locals['validated'] as {
        query: z.infer<typeof summaryQuerySchema>;
      };

      const prisma = getPrismaClient();
      const [livePortfolioTHB, goalRows] = await Promise.all([
        computeUserLivePortfolioValueTHB(req.user!.id),
        prisma.fireGoal.findMany({
          where: { userId: req.user!.id },
          orderBy: { createdAt: 'asc' },
        }),
      ]);

      const goalsWithProgress = goalRows.map((row) => {
        const goal = mapPrismaGoalToDTO(row);
        const combinedWealth = new Dec(livePortfolioTHB)
          .plus(new Dec(goal.currentAmount))
          .toDecimalPlaces(2, Decimal.ROUND_HALF_UP)
          .toFixed(2);
        const progress = calculateGoalProgress(goal, combinedWealth);
        return { goal, progress };
      });

      const primaryGoal = goalsWithProgress[0]?.goal;
      const fireNumber = primaryGoal
        ? primaryGoal.targetAmount
        : calculateFIRENumber(query.annualExpenses, query.withdrawalRate);

      const effectiveMonthly = primaryGoal
        ? primaryGoal.monthlyContribution
        : query.monthlyContribution;
      const effectiveReturn = primaryGoal
        ? primaryGoal.expectedReturn
        : query.expectedReturn;
      const effectiveInflation = primaryGoal
        ? primaryGoal.inflationRate
        : query.inflationRate;

      const startingWealth = primaryGoal
        ? new Dec(livePortfolioTHB).plus(new Dec(primaryGoal.currentAmount)).toFixed(2)
        : livePortfolioTHB;

      let yearsToFIRE = '0.00';
      try {
        yearsToFIRE = calculateYearsToFIRE(
          startingWealth,
          effectiveMonthly,
          fireNumber,
          effectiveReturn,
          effectiveInflation
        );
      } catch {
        yearsToFIRE = '99.00';
      }

      const horizonYears = primaryGoal
        ? Math.max(5, Math.min(60, primaryGoal.targetYear - new Date().getFullYear()))
        : query.years;

      const monteCarlo = runMonteCarloSimulation(
        startingWealth,
        effectiveMonthly,
        effectiveReturn,
        query.volatility,
        horizonYears,
        query.numSimulations,
        query.seed,
        { targetAmount: fireNumber }
      );

      const payload: FIRESummaryResponse = {
        fireNumber,
        yearsToFIRE,
        successRate: monteCarlo.successRate,
        currentPortfolioValueTHB: livePortfolioTHB,
        monthlyContributionTHB: effectiveMonthly,
        annualExpensesTHB: query.annualExpenses,
        withdrawalRate: query.withdrawalRate,
        expectedReturn: effectiveReturn,
        inflationRate: effectiveInflation,
        volatility: query.volatility,
        goalsCount: goalsWithProgress.length,
        onTrackCount: goalsWithProgress.filter((g) => g.progress.onTrack).length,
        goals: goalsWithProgress,
        monteCarlo,
      };

      res.status(200).json(payload);
    } catch (err) {
      next(err);
    }
  }
);
