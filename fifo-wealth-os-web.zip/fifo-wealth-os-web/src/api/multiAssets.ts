import { randomUUID } from 'node:crypto';
import { Router } from 'express';
import { z } from 'zod';
import { getPrismaClient } from '../db/prisma';
import { authMiddleware } from '../middleware/authMiddleware';
import { AppError } from '../middleware/errorHandler';
import { validateRequest } from '../middleware/validationMiddleware';
import { validateMultiAssetTransaction, type MultiAssetTransaction } from '../types/multiAsset';
import { calculateMultiAssetPortfolioSummary, mapLegacyGoldRecordToCommodity, MultiAssetDecimal } from '../services/multiAsset';
import { requireOwnedPortfolio } from './routes/portfolioRoutes';

const decimalText = z.string().trim().regex(/^-?(?:\d+\.?\d*|\.\d+)$/, 'Must be a decimal string.');
function isFiniteDecimal(value: string): boolean {
  try {
    return new MultiAssetDecimal(value).isFinite();
  } catch {
    return false;
  }
}
const nonNegativeDecimalText = decimalText.refine((value) => {
  if (!isFiniteDecimal(value)) return false;
  return new MultiAssetDecimal(value).gte(0);
}, 'Must be a finite decimal >= 0.');
const positiveDecimalText = decimalText.refine((value) => {
  if (!isFiniteDecimal(value)) return false;
  return new MultiAssetDecimal(value).gt(0);
}, 'Must be a finite decimal > 0.');
const dateText = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must use YYYY-MM-DD.').refine((value) => {
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}, 'Date must be a real calendar date.');
const currencyText = z.string().trim().regex(/^[A-Za-z]{3,5}$/, 'Currency must be a 3–5 letter code.').transform((value) => value.toUpperCase());

const bondExtensionSchema = z.object({
  couponRate: nonNegativeDecimalText,
  paymentFrequency: z.enum(['MONTHLY', 'QUARTERLY', 'SEMI_ANNUAL', 'ANNUAL']),
  maturityDate: dateText,
  faceValue: positiveDecimalText,
  accruedInterest: nonNegativeDecimalText,
  yieldToMaturity: nonNegativeDecimalText.optional(),
  creditRating: z.string().trim().max(16).optional(),
  issuer: z.string().trim().max(120).optional(),
}).strict();

const fundExtensionSchema = z.object({
  fundType: z.enum(['SSF', 'RMF', 'THAI_ESG', 'GENERAL', 'GLOBAL_ETF']),
  holdingPeriodDays: z.number().int().nonnegative(),
  taxDeductible: z.boolean(),
  dividendPolicy: z.enum(['DRIP', 'CASH_PAYOUT']),
  navPerUnit: positiveDecimalText,
  managementFee: nonNegativeDecimalText.optional(),
  purchaseDate: dateText.optional(),
}).strict();

const commodityExtensionSchema = z.object({
  weight: positiveDecimalText,
  weightUnit: z.enum(['TROY_OUNCE', 'GRAM', 'KILOGRAM', 'THAI_BAHT']),
  purity: positiveDecimalText.refine((value) => new MultiAssetDecimal(value).lte(100), 'Purity must be <= 100%.').optional(),
  storageFee: nonNegativeDecimalText,
  premium: nonNegativeDecimalText,
  spotPricePerUnit: positiveDecimalText,
}).strict();

const forexExtensionSchema = z.object({
  fromCurrency: currencyText,
  toCurrency: currencyText,
  fxRateAtTransaction: positiveDecimalText,
  realizedFxGainLoss: decimalText,
  avgCostBasisTHB: nonNegativeDecimalText.optional(),
}).strict();

const createMultiAssetTransactionSchema = z.object({
  date: dateText,
  symbol: z.string().trim().min(1).max(64).transform((value) => value.toUpperCase()),
  assetClass: z.enum(['BOND', 'FUND', 'COMMODITY', 'FOREX']),
  type: z.enum(['BUY', 'SELL', 'DIVIDEND', 'COUPON', 'INTEREST', 'FEE', 'CONVERT']),
  qty: z.number().finite().positive(),
  price: nonNegativeDecimalText,
  gross: nonNegativeDecimalText,
  comm: nonNegativeDecimalText,
  vat: nonNegativeDecimalText,
  net: nonNegativeDecimalText,
  originalCurrency: currencyText,
  originalNet: nonNegativeDecimalText,
  fxRate: positiveDecimalText.nullable(),
  netTHB: nonNegativeDecimalText.nullable(),
  exchange: z.string().trim().max(40).optional(),
  notes: z.string().trim().max(500).optional(),
  bondExtension: bondExtensionSchema.optional(),
  fundExtension: fundExtensionSchema.optional(),
  commodityExtension: commodityExtensionSchema.optional(),
  forexExtension: forexExtensionSchema.optional(),
}).strict().superRefine((transaction, context) => {
  const extensionKeyByAsset = {
    BOND: 'bondExtension',
    FUND: 'fundExtension',
    COMMODITY: 'commodityExtension',
    FOREX: 'forexExtension',
  } as const;
  const requiredKey = extensionKeyByAsset[transaction.assetClass];
  const keys = ['bondExtension', 'fundExtension', 'commodityExtension', 'forexExtension'] as const;
  for (const key of keys) {
    if (key === requiredKey && !transaction[key]) {
      context.addIssue({ code: 'custom', path: [key], message: `${key} is required for ${transaction.assetClass}.` });
    }
    if (key !== requiredKey && transaction[key]) {
      context.addIssue({ code: 'custom', path: [key], message: `${key} is not valid for ${transaction.assetClass}.` });
    }
  }

  if (transaction.assetClass === 'BOND' && !['BUY', 'SELL', 'COUPON', 'INTEREST'].includes(transaction.type)) {
    context.addIssue({ code: 'custom', path: ['type'], message: 'Bond transactions support BUY, SELL, COUPON, or INTEREST.' });
  }
  if (transaction.assetClass === 'BOND' && transaction.bondExtension && transaction.bondExtension.maturityDate <= transaction.date) {
    context.addIssue({ code: 'custom', path: ['bondExtension', 'maturityDate'], message: 'Maturity date must follow transaction date.' });
  }
  if (transaction.assetClass === 'FUND' && !['BUY', 'SELL', 'DIVIDEND'].includes(transaction.type)) {
    context.addIssue({ code: 'custom', path: ['type'], message: 'Fund transactions support BUY, SELL, or DIVIDEND.' });
  }
  if (transaction.assetClass === 'COMMODITY' && !['BUY', 'SELL'].includes(transaction.type)) {
    context.addIssue({ code: 'custom', path: ['type'], message: 'Commodity transactions support BUY or SELL.' });
  }
  if (transaction.assetClass === 'FOREX' && !['BUY', 'SELL', 'CONVERT'].includes(transaction.type)) {
    context.addIssue({ code: 'custom', path: ['type'], message: 'Forex transactions support BUY, SELL, or CONVERT.' });
  }

  if (transaction.assetClass === 'FOREX' && transaction.forexExtension) {
    const extension = transaction.forexExtension;
    if (transaction.type === 'CONVERT' && extension.fromCurrency === extension.toCurrency) {
      context.addIssue({ code: 'custom', path: ['forexExtension', 'toCurrency'], message: 'A conversion must use two different currencies.' });
    }
    if (transaction.type === 'CONVERT' && new MultiAssetDecimal(transaction.gross).lte(0)) {
      context.addIssue({ code: 'custom', path: ['gross'], message: 'gross must be the positive amount received in toCurrency for CONVERT.' });
    }
    if (transaction.originalCurrency !== extension.fromCurrency) {
      context.addIssue({ code: 'custom', path: ['originalCurrency'], message: 'originalCurrency must match forexExtension.fromCurrency.' });
    }
  }

  if (transaction.assetClass === 'FUND' && transaction.fundExtension?.taxDeductible && !['SSF', 'RMF', 'THAI_ESG'].includes(transaction.fundExtension.fundType)) {
    context.addIssue({ code: 'custom', path: ['fundExtension', 'taxDeductible'], message: 'Only SSF, RMF, or THAI_ESG can be marked tax deductible.' });
  }
});

const portfolioParamsSchema = z.object({
  portfolioId: z.string().trim().min(1),
});
const transactionParamsSchema = portfolioParamsSchema.extend({
  transactionId: z.string().trim().min(1),
});
const summaryQuerySchema = z.object({
  asOfDate: dateText.optional(),
  taxYear: z.coerce.number().int().min(1900).max(3000).optional(),
  annualIncomeTHB: nonNegativeDecimalText.optional(),
}).passthrough();

interface SerializedTransaction extends Omit<MultiAssetTransaction, 'createdAt'> {
  createdAt: string | Date;
}

function parseTransaction(payload: string): MultiAssetTransaction {
  const parsed = JSON.parse(payload) as SerializedTransaction;
  return { ...parsed, createdAt: new Date(parsed.createdAt) } as MultiAssetTransaction;
}

function latestTimestamp(values: Array<Date | string>): string | null {
  if (values.length === 0) return null;
  const latest = values.reduce<Date>((current, value) => {
    const candidate = value instanceof Date ? value : new Date(value);
    return candidate.getTime() > current.getTime() ? candidate : current;
  }, new Date(0));
  return latest.getTime() > 0 ? latest.toISOString() : null;
}

function buildTransaction(
  portfolioId: string,
  input: z.infer<typeof createMultiAssetTransactionSchema>,
): MultiAssetTransaction {
  const transaction: MultiAssetTransaction = {
    id: randomUUID(),
    portfolioId,
    createdAt: new Date(),
    ...input,
    originalCurrency: input.originalCurrency.toUpperCase(),
    ...(input.assetClass === 'BOND' && input.bondExtension ? { bondExtension: input.bondExtension } : {}),
    ...(input.assetClass === 'FUND' && input.fundExtension ? { fundExtension: input.fundExtension } : {}),
    ...(input.assetClass === 'COMMODITY' && input.commodityExtension ? { commodityExtension: input.commodityExtension } : {}),
    ...(input.assetClass === 'FOREX' && input.forexExtension ? { forexExtension: input.forexExtension } : {}),
  };
  const validation = validateMultiAssetTransaction(transaction);
  if (!validation.isValid) {
    throw new AppError(400, 'INVALID_MULTI_ASSET_TRANSACTION', 'Transaction does not satisfy the Unified CDM.', validation.errors);
  }
  return transaction;
}

function applyDerivedForexValues(
  transactions: readonly MultiAssetTransaction[],
  realizedEvents: ReturnType<typeof calculateMultiAssetPortfolioSummary>['forex']['realizedEvents'],
): MultiAssetTransaction[] {
  const eventsById = new Map(realizedEvents.map((event) => [event.transactionId, event]));
  return transactions.map((transaction) => {
    if (transaction.assetClass !== 'FOREX' || !transaction.forexExtension) return transaction;
    const event = eventsById.get(transaction.id);
    const averageCostBasis = transaction.type === 'CONVERT' && transaction.netTHB !== null
      ? new MultiAssetDecimal(transaction.netTHB).dividedBy(transaction.gross).toDecimalPlaces(8).toFixed(8)
      : event
        ? event.averageCostBasisTHB
        : transaction.type === 'BUY' && transaction.netTHB !== null
          ? new MultiAssetDecimal(transaction.netTHB).dividedBy(transaction.qty).toDecimalPlaces(8).toFixed(8)
          : transaction.forexExtension.avgCostBasisTHB;
    return {
      ...transaction,
      forexExtension: {
        ...transaction.forexExtension,
        realizedFxGainLoss: event?.realizedFxGainLossTHB ?? '0.00',
        ...(averageCostBasis ? { avgCostBasisTHB: averageCostBasis } : {}),
      },
    };
  });
}

export const multiAssetRouter = Router();

multiAssetRouter.get(
  '/portfolios/:portfolioId',
  authMiddleware,
  validateRequest({ params: portfolioParamsSchema, query: summaryQuerySchema }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as {
        params: { portfolioId: string };
        query: z.infer<typeof summaryQuerySchema>;
      };
      const { portfolioId } = validated.params;
      await requireOwnedPortfolio(portfolioId, req.user!.id);
      const prisma = getPrismaClient();
      const rows = await prisma.multiAssetTransactionRecord.findMany({
        where: { portfolioId },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      });
      const transactions = rows.map((row) => parseTransaction(row.payload));
      const legacyGoldRows = await prisma.goldTransactionRecord.findMany({
        where: { portfolioId, assetSubclass: { not: 'GOLD_ONLINE_FUTURES' } },
        orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
      });
      const profile = await prisma.user.findUnique({
        where: { id: req.user!.id },
        select: { dateOfBirth: true },
      });
      const asOfDate = validated.query.asOfDate ?? new Date().toISOString().slice(0, 10);
      const summaryTransactions = [
        ...transactions,
        ...legacyGoldRows.map(mapLegacyGoldRecordToCommodity),
      ];
      const summary = calculateMultiAssetPortfolioSummary(summaryTransactions, {
        asOfDate,
        taxYear: validated.query.taxYear ?? Number(asOfDate.slice(0, 4)),
        annualIncomeTHB: validated.query.annualIncomeTHB ?? null,
        dateOfBirth: profile?.dateOfBirth ?? null,
      });
      const normalizedTransactions = applyDerivedForexValues(transactions, summary.forex.realizedEvents);
      const lastUpdatedAt = {
        bonds: latestTimestamp(rows.filter((row) => row.assetClass === 'BOND').map((row) => row.createdAt)),
        funds: latestTimestamp(rows.filter((row) => row.assetClass === 'FUND').map((row) => row.createdAt)),
        metals: latestTimestamp([
          ...rows.filter((row) => row.assetClass === 'COMMODITY').map((row) => row.createdAt),
          ...legacyGoldRows.map((row) => row.createdAt),
        ]),
        forex: latestTimestamp(rows.filter((row) => row.assetClass === 'FOREX').map((row) => row.createdAt)),
      };
      res.status(200).json({
        transactions: normalizedTransactions,
        summary,
        dateOfBirth: profile?.dateOfBirth?.toISOString().slice(0, 10) ?? null,
        lastUpdatedAt,
      });
    } catch (error) {
      next(error);
    }
  },
);

multiAssetRouter.post(
  '/portfolios/:portfolioId/transactions',
  authMiddleware,
  validateRequest({ params: portfolioParamsSchema, body: createMultiAssetTransactionSchema }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as {
        params: { portfolioId: string };
        body: z.infer<typeof createMultiAssetTransactionSchema>;
      };
      const { portfolioId } = validated.params;
      await requireOwnedPortfolio(portfolioId, req.user!.id);
      const transaction = buildTransaction(portfolioId, validated.body);
      const prisma = getPrismaClient();

      const persistedTransaction = await prisma.$transaction(async (database) => {
        const existingRows = await database.multiAssetTransactionRecord.findMany({
          where: { portfolioId },
          orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
        });
        const legacyGoldRows = await database.goldTransactionRecord.findMany({
          where: { portfolioId, assetSubclass: { not: 'GOLD_ONLINE_FUTURES' } },
          orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
        });
        const candidates = [
          ...existingRows.map((row) => parseTransaction(row.payload)),
          ...legacyGoldRows.map(mapLegacyGoldRecordToCommodity),
          transaction,
        ];
        // Re-run asset engines before persistence so an over-sale or invalid cash conversion cannot create a bad ledger.
        const summary = calculateMultiAssetPortfolioSummary(candidates);
        const normalized = applyDerivedForexValues(candidates, summary.forex.realizedEvents);
        const normalizedById = new Map(normalized.map((item) => [item.id, item]));
        await Promise.all(existingRows.map((row) => {
          const updated = normalizedById.get(row.id);
          return updated && updated.assetClass === 'FOREX'
            ? database.multiAssetTransactionRecord.update({ where: { id: row.id }, data: { payload: JSON.stringify(updated) } })
            : Promise.resolve(row);
        }));
        const createdTransaction = normalizedById.get(transaction.id)!;
        await database.multiAssetTransactionRecord.create({
          data: {
            id: createdTransaction.id,
            portfolioId,
            date: createdTransaction.date,
            assetClass: createdTransaction.assetClass,
            type: createdTransaction.type,
            symbol: createdTransaction.symbol,
            payload: JSON.stringify(createdTransaction),
          },
        });
        return createdTransaction;
      });

      res.status(201).json({ transaction: persistedTransaction, recordId: persistedTransaction.id });
    } catch (error) {
      next(error);
    }
  },
);

multiAssetRouter.delete(
  '/portfolios/:portfolioId/transactions/:transactionId',
  authMiddleware,
  validateRequest({ params: transactionParamsSchema }),
  async (req, res, next) => {
    try {
      const validated = res.locals['validated'] as { params: { portfolioId: string; transactionId: string } };
      const { portfolioId, transactionId } = validated.params;
      await requireOwnedPortfolio(portfolioId, req.user!.id);
      const prisma = getPrismaClient();
      const existing = await prisma.multiAssetTransactionRecord.findFirst({
        where: { id: transactionId, portfolioId },
      });
      if (!existing) throw new AppError(404, 'MULTI_ASSET_TRANSACTION_NOT_FOUND', 'Multi-asset transaction not found.');
      await prisma.$transaction(async (database) => {
        const remainingRows = await database.multiAssetTransactionRecord.findMany({
          where: { portfolioId, id: { not: transactionId } },
          orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
        });
        const legacyGoldRows = await database.goldTransactionRecord.findMany({
          where: { portfolioId, assetSubclass: { not: 'GOLD_ONLINE_FUTURES' } },
          orderBy: [{ date: 'asc' }, { createdAt: 'asc' }],
        });
        const remaining = [
          ...remainingRows.map((row) => parseTransaction(row.payload)),
          ...legacyGoldRows.map(mapLegacyGoldRecordToCommodity),
        ];
        const summary = calculateMultiAssetPortfolioSummary(remaining);
        const normalized = applyDerivedForexValues(remaining, summary.forex.realizedEvents);
        const normalizedById = new Map(normalized.map((item) => [item.id, item]));
        await Promise.all(remainingRows.map((row) => {
          const updated = normalizedById.get(row.id);
          return updated && updated.assetClass === 'FOREX'
            ? database.multiAssetTransactionRecord.update({ where: { id: row.id }, data: { payload: JSON.stringify(updated) } })
            : Promise.resolve(row);
        }));
        await database.multiAssetTransactionRecord.delete({ where: { id: transactionId } });
      });
      res.status(200).json({ id: transactionId, deleted: true });
    } catch (error) {
      next(error);
    }
  },
);
