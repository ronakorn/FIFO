import { calculateFIFO } from './fifoEngine';
import { Transaction } from './types';

function makeTx(
  partial: Omit<Transaction, 'originalCurrency' | 'originalNet' | 'fxRate' | 'netTHB'> &
    Partial<Pick<Transaction, 'originalCurrency' | 'originalNet' | 'fxRate' | 'netTHB'>>
): Transaction {
  return {
    originalCurrency: 'THB',
    originalNet: partial.net.toFixed(2),
    fxRate: '1.00',
    netTHB: partial.net.toFixed(2),
    ...partial,
  };
}

describe('FIFO Wealth OS - Core FIFO Engine', () => {
  describe('Excel Baseline Verification (Symbol A)', () => {
    const buyTransactions: Transaction[] = [
      makeTx({
        id: 'LOT-1',
        date: '2024-10-01',
        symbol: 'A',
        qty: 1.0,
        price: 100.0,
        gross: 100.0,
        comm: 0.0,
        vat: 0.0,
        net: 100.0,
        type: 'BUY',
        exchange: 'STREAMING',
      }),
      makeTx({
        id: 'LOT-7',
        date: '2024-10-07',
        symbol: 'A',
        qty: 1.0,
        price: 100.0,
        gross: 100.0,
        comm: 0.3271,
        vat: 0.0229,
        net: 100.35,
        type: 'BUY',
        exchange: 'STREAMING',
      }),
      makeTx({
        id: 'LOT-9',
        date: '2024-10-09',
        symbol: 'A',
        qty: 1.0,
        price: 100.0,
        gross: 100.0,
        comm: 0.3271,
        vat: 0.0229,
        net: 100.35,
        type: 'BUY',
        exchange: 'STREAMING',
      }),
    ];

    const sellTransactions: Transaction[] = [
      makeTx({
        id: 'SELL-1',
        date: '2024-10-01',
        symbol: 'A',
        qty: 3.0,
        price: 109.0,
        gross: 327.0,
        comm: 1.2056,
        vat: 0.0844,
        net: 325.71, // Price/Unit = 325.71 / 3.00 = 108.5700
        type: 'SELL',
        exchange: 'STREAMING',
      }),
    ];

    const currentPrices: Record<string, number> = {
      A: 20.0,
    };

    it('1. Lot 1 (Buy 1.00 @ 100.00): Qty Sold = 1.00, Realized G/L = 8.57, Status = Sold', () => {
      const result = calculateFIFO(buyTransactions, sellTransactions, currentPrices);
      const lot1 = result.lots.find((l) => l.id === 'LOT-1');

      expect(lot1).toBeDefined();
      expect(lot1!.costPerUnit).toBeCloseTo(100.0, 4);
      expect(lot1!.qtySold).toBe(1.0);
      expect(lot1!.qtyRemain).toBe(0.0);
      expect(lot1!.realizedGL).toBeCloseTo(8.57, 2);
      expect(lot1!.realizedGL).toBe(8.57);
      expect(lot1!.status).toBe('Sold');
    });

    it('2. Lot 7 (Buy 1.00 @ 100.35): Qty Sold = 1.00, Realized G/L = 8.22, Status = Sold', () => {
      const result = calculateFIFO(buyTransactions, sellTransactions, currentPrices);
      const lot7 = result.lots.find((l) => l.id === 'LOT-7');

      expect(lot7).toBeDefined();
      expect(lot7!.costPerUnit).toBeCloseTo(100.35, 4);
      expect(lot7!.qtySold).toBe(1.0);
      expect(lot7!.qtyRemain).toBe(0.0);
      expect(lot7!.realizedGL).toBeCloseTo(8.22, 2);
      expect(lot7!.realizedGL).toBe(8.22);
      expect(lot7!.status).toBe('Sold');
    });

    it('3. Lot 9 (Buy 1.00 @ 100.35): Qty Sold = 1.00, Realized G/L = 8.22, Status = Sold', () => {
      const result = calculateFIFO(buyTransactions, sellTransactions, currentPrices);
      const lot9 = result.lots.find((l) => l.id === 'LOT-9');

      expect(lot9).toBeDefined();
      expect(lot9!.costPerUnit).toBeCloseTo(100.35, 4);
      expect(lot9!.qtySold).toBe(1.0);
      expect(lot9!.qtyRemain).toBe(0.0);
      expect(lot9!.realizedGL).toBeCloseTo(8.22, 2);
      expect(lot9!.realizedGL).toBe(8.22);
      expect(lot9!.status).toBe('Sold');
    });

    it('4. Total Realized G/L for Symbol A equals 25.01 (± 0.01)', () => {
      const result = calculateFIFO(buyTransactions, sellTransactions, currentPrices);

      const symbolARealizedGL = result.lots
        .filter((l) => l.symbol === 'A')
        .reduce((acc, l) => acc + l.realizedGL, 0);

      expect(Math.abs(symbolARealizedGL - 25.01)).toBeLessThanOrEqual(0.01);
      expect(Math.abs(result.totalRealizedGL - 25.01)).toBeLessThanOrEqual(0.01);
      expect(result.totalRealizedGL).toBe(25.01);
      expect(result.totalCostSold).toBe(300.7);
      expect(result.totalProceeds).toBe(325.71);
    });

    it('5. Total Qty Remain for Symbol A equals 0.00 (and Unrealized G/L = 0.00)', () => {
      const result = calculateFIFO(buyTransactions, sellTransactions, currentPrices);

      const totalQtyRemainA = result.lots
        .filter((l) => l.symbol === 'A')
        .reduce((acc, l) => acc + l.qtyRemain, 0);

      expect(totalQtyRemainA).toBe(0.0);
      expect(result.totalUnrealizedGL).toBe(0.0);
    });
  });

  describe('Production FinTech Scenarios & Edge Cases', () => {
    it('handles Sold, Partial, and Hold statuses with accurate Unrealized G/L', () => {
      const buys: Transaction[] = [
        makeTx({
          id: 'B1',
          date: '2024-01-10',
          symbol: 'PTT',
          qty: 100,
          price: 30,
          gross: 3000,
          comm: 0,
          vat: 0,
          net: 3000,
          type: 'BUY',
          exchange: 'STREAMING',
        }),
        makeTx({
          id: 'B2',
          date: '2024-02-10',
          symbol: 'PTT',
          qty: 100,
          price: 32,
          gross: 3200,
          comm: 0,
          vat: 0,
          net: 3200,
          type: 'BUY',
          exchange: 'STREAMING',
        }),
        makeTx({
          id: 'B3',
          date: '2024-03-10',
          symbol: 'PTT',
          qty: 50,
          price: 35,
          gross: 1750,
          comm: 0,
          vat: 0,
          net: 1750,
          type: 'BUY',
          exchange: 'STREAMING',
        }),
      ];

      const sells: Transaction[] = [
        makeTx({
          id: 'S1',
          date: '2024-04-01',
          symbol: 'PTT',
          qty: 140,
          price: 36,
          gross: 5040,
          comm: 0,
          vat: 0,
          net: 5040,
          type: 'SELL',
          exchange: 'STREAMING',
        }),
      ];

      const result = calculateFIFO(buys, sells, { PTT: 34 });

      expect(result.lots[0]).toMatchObject({
        id: 'B1',
        qtySold: 100,
        qtyRemain: 0,
        realizedGL: 600,
        unrealizedGL: 0,
        status: 'Sold',
      });

      expect(result.lots[1]).toMatchObject({
        id: 'B2',
        qtySold: 40,
        qtyRemain: 60,
        realizedGL: 160,
        unrealizedGL: 120,
        status: 'Partial',
      });

      expect(result.lots[2]).toMatchObject({
        id: 'B3',
        qtySold: 0,
        qtyRemain: 50,
        realizedGL: 0,
        unrealizedGL: -50,
        status: 'Hold',
      });

      expect(result.totalRealizedGL).toBe(760);
      expect(result.totalUnrealizedGL).toBe(70);
      expect(result.totalCostSold).toBe(4280);
      expect(result.totalProceeds).toBe(5040);
    });

    it('sorts unsorted BUY and SELL transactions chronologically without mutating inputs', () => {
      const buys: Transaction[] = [
        makeTx({
          id: 'LATE-BUY',
          date: '2024-05-01',
          symbol: 'AOT',
          qty: 10,
          price: 65,
          gross: 650,
          comm: 0,
          vat: 0,
          net: 650,
          type: 'BUY',
          exchange: 'STREAMING',
        }),
        makeTx({
          id: 'EARLY-BUY',
          date: '2024-01-01',
          symbol: 'AOT',
          qty: 10,
          price: 60,
          gross: 600,
          comm: 0,
          vat: 0,
          net: 600,
          type: 'BUY',
          exchange: 'STREAMING',
        }),
      ];

      const sells: Transaction[] = [
        makeTx({
          id: 'SELL-AOT',
          date: '2024-06-01',
          symbol: 'AOT',
          qty: 10,
          price: 70,
          gross: 700,
          comm: 0,
          vat: 0,
          net: 700,
          type: 'SELL',
          exchange: 'STREAMING',
        }),
      ];

      const result = calculateFIFO(buys, sells, { AOT: 68 });

      expect(buys[0]!.id).toBe('LATE-BUY');

      expect(result.lots[0]!.id).toBe('EARLY-BUY');
      expect(result.lots[0]!.status).toBe('Sold');
      expect(result.lots[0]!.realizedGL).toBe(100);

      expect(result.lots[1]!.id).toBe('LATE-BUY');
      expect(result.lots[1]!.status).toBe('Hold');
      expect(result.lots[1]!.unrealizedGL).toBe(30);
    });

    it('prevents IEEE-754 floating-point drift on fractional quantities (0.1 + 0.2 = 0.3)', () => {
      const buys: Transaction[] = [
        makeTx({
          id: 'BTC-1',
          date: '2024-01-01',
          symbol: 'BTC',
          qty: 0.1,
          price: 50000,
          gross: 5000,
          comm: 0,
          vat: 0,
          net: 5000,
          type: 'BUY',
          exchange: 'BINANCE',
        }),
        makeTx({
          id: 'BTC-2',
          date: '2024-01-02',
          symbol: 'BTC',
          qty: 0.2,
          price: 50000,
          gross: 10000,
          comm: 0,
          vat: 0,
          net: 10000,
          type: 'BUY',
          exchange: 'BINANCE',
        }),
      ];

      const sells: Transaction[] = [
        makeTx({
          id: 'BTC-SELL',
          date: '2024-01-03',
          symbol: 'BTC',
          qty: 0.3,
          price: 55000,
          gross: 16500,
          comm: 0,
          vat: 0,
          net: 16500,
          type: 'SELL',
          exchange: 'BINANCE',
        }),
      ];

      const result = calculateFIFO(buys, sells, { BTC: 60000 });

      expect(result.lots[0]!.status).toBe('Sold');
      expect(result.lots[1]!.status).toBe('Sold');
      expect(result.lots[1]!.qtyRemain).toBe(0);
      expect(result.totalRealizedGL).toBe(1500);
      expect(result.totalUnrealizedGL).toBe(0);
    });

    it('isolates FIFO queues across multiple symbols', () => {
      const buys: Transaction[] = [
        makeTx({
          id: 'SYM-A-1',
          date: '2024-01-01',
          symbol: 'A',
          qty: 2,
          price: 100,
          gross: 200,
          comm: 0,
          vat: 0,
          net: 200,
          type: 'BUY',
          exchange: 'STREAMING',
        }),
        makeTx({
          id: 'SYM-B-1',
          date: '2024-01-01',
          symbol: 'B',
          qty: 5,
          price: 50,
          gross: 250,
          comm: 0,
          vat: 0,
          net: 250,
          type: 'BUY',
          exchange: 'IBKR',
        }),
      ];

      const sells: Transaction[] = [
        makeTx({
          id: 'SYM-B-SELL',
          date: '2024-02-01',
          symbol: 'B',
          qty: 3,
          price: 60,
          gross: 180,
          comm: 0,
          vat: 0,
          net: 180,
          type: 'SELL',
          exchange: 'IBKR',
        }),
      ];

      const result = calculateFIFO(buys, sells, { A: 110, B: 55 });

      const lotA = result.lots.find((l) => l.symbol === 'A')!;
      const lotB = result.lots.find((l) => l.symbol === 'B')!;

      expect(lotA.status).toBe('Hold');
      expect(lotA.unrealizedGL).toBe(20);
      expect(lotB.status).toBe('Partial');
      expect(lotB.realizedGL).toBe(30);
      expect(lotB.unrealizedGL).toBe(10);
      expect(result.totalRealizedGL).toBe(30);
      expect(result.totalUnrealizedGL).toBe(30);
    });

    it('throws descriptive error when selling more shares than owned (overselling)', () => {
      const buys: Transaction[] = [
        makeTx({
          id: 'B1',
          date: '2024-01-01',
          symbol: 'A',
          qty: 2,
          price: 100,
          gross: 200,
          comm: 0,
          vat: 0,
          net: 200,
          type: 'BUY',
          exchange: 'STREAMING',
        }),
      ];

      const sells: Transaction[] = [
        makeTx({
          id: 'S1',
          date: '2024-01-02',
          symbol: 'A',
          qty: 3,
          price: 110,
          gross: 330,
          comm: 0,
          vat: 0,
          net: 330,
          type: 'SELL',
          exchange: 'STREAMING',
        }),
      ];

      expect(() => calculateFIFO(buys, sells, { A: 100 })).toThrow(/Insufficient holdings/);
    });

    it('throws descriptive error if currentPrice is missing for an open position', () => {
      const buys: Transaction[] = [
        makeTx({
          id: 'B1',
          date: '2024-01-01',
          symbol: 'UNPRICED',
          qty: 1,
          price: 100,
          gross: 100,
          comm: 0,
          vat: 0,
          net: 100,
          type: 'BUY',
          exchange: 'DIME',
        }),
      ];

      expect(() => calculateFIFO(buys, [], {})).toThrow(/Missing or invalid current price/);
    });
  });
});
