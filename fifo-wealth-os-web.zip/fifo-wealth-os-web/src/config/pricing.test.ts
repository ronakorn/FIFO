import {
  EARLY_BIRD_DISCOUNT,
  SUBSCRIPTION_TIERS,
  checkFeatureAccess,
  getTierUpgradePath,
  getPriceQuote,
  getTierLimit,
  getYearlySavingsPercentage,
  hasFeatureEntitlement,
  isEarlyBirdWindowOpen,
} from './pricing';

describe('subscription pricing and entitlement catalog', () => {
  it('contains the approved monthly and annual THB prices and price ID placeholders', () => {
    expect(SUBSCRIPTION_TIERS).toMatchObject({
      FREE: { monthlyPriceTHB: 0, yearlyPriceTHB: 0 },
      PRO: {
        monthlyPriceTHB: 290,
        yearlyPriceTHB: 2784,
        stripePriceIdMonthly: 'price_pro_monthly',
        stripePriceIdYearly: 'price_pro_yearly',
      },
      FAMILY: {
        monthlyPriceTHB: 590,
        yearlyPriceTHB: 5664,
        stripePriceIdMonthly: 'price_family_monthly',
        stripePriceIdYearly: 'price_family_yearly',
      },
      ADVISOR: {
        monthlyPriceTHB: 1990,
        yearlyPriceTHB: 19104,
        stripePriceIdMonthly: 'price_advisor_monthly',
        stripePriceIdYearly: 'price_advisor_yearly',
      },
    });
    expect(getYearlySavingsPercentage('PRO')).toBe('20.00');
    expect(getYearlySavingsPercentage('FAMILY')).toBe('20.00');
    expect(getYearlySavingsPercentage('ADVISOR')).toBe('20.00');
  });

  it('applies the 30% Early-Bird discount with precision-40 decimal arithmetic only to eligible beta users', () => {
    const beforeDeadline = new Date('2027-06-30T16:59:59.000Z');
    const afterDeadline = new Date('2027-06-30T17:00:00.000Z');

    expect(getPriceQuote('PRO', 'month', { isBetaUser: true, asOf: beforeDeadline })).toMatchObject({
      baseAmountTHB: '290.00',
      amountTHB: '203.00',
      discountAmountTHB: '87.00',
      discountPercentage: 30,
      stripePriceId: 'price_pro_monthly',
      earlyBirdApplied: true,
    });
    expect(getPriceQuote('FAMILY', 'year', { isBetaUser: true, asOf: beforeDeadline })).toMatchObject({
      baseAmountTHB: '5664.00',
      amountTHB: '3964.80',
      discountAmountTHB: '1699.20',
      earlyBirdApplied: true,
    });
    expect(getPriceQuote('ADVISOR', 'year', { isBetaUser: true, asOf: beforeDeadline }).amountTHB)
      .toBe('13372.80');
    expect(getPriceQuote('PRO', 'month', { isBetaUser: false, asOf: beforeDeadline }).amountTHB)
      .toBe('290.00');
    expect(getPriceQuote('PRO', 'month', { isBetaUser: true, asOf: afterDeadline }).amountTHB)
      .toBe('290.00');
    expect(getPriceQuote('PRO', 'month', { earlyBirdClaimed: true, asOf: afterDeadline }).amountTHB)
      .toBe('203.00');
    expect(getPriceQuote('PRO', 'month', { earlyBirdClaimed: true, earlyBirdCanceled: true, asOf: beforeDeadline }).amountTHB)
      .toBe('290.00');
    expect(getPriceQuote('FREE', 'year', { isBetaUser: true, asOf: beforeDeadline })).toMatchObject({
      amountTHB: '0.00',
      discountPercentage: 0,
      earlyBirdApplied: false,
    });
  });

  it('uses the Bangkok calendar date for the Early-Bird cutoff and records its lifetime policy', () => {
    expect(isEarlyBirdWindowOpen(new Date('2027-06-30T16:59:59.000Z'))).toBe(true);
    expect(isEarlyBirdWindowOpen(new Date('2027-06-30T17:00:00.000Z'))).toBe(false);
    expect(EARLY_BIRD_DISCOUNT).toEqual({
      discountPercentage: 30,
      validUntil: '2027-06-30',
      lifetimeDiscount: true,
      endsOnCancellation: true,
    });
  });

  it('maps boolean features and plan limits to the intended tiers', () => {
    expect(hasFeatureEntitlement('FREE', 'basicNetWorth')).toBe(true);
    expect(hasFeatureEntitlement('FREE', 'advancedAnalytics')).toBe(false);
    expect(hasFeatureEntitlement('PRO', 'advancedAnalytics')).toBe(true);
    expect(hasFeatureEntitlement('PRO', 'familyWealth')).toBe(false);
    expect(hasFeatureEntitlement('FAMILY', 'familyWealth')).toBe(true);
    expect(hasFeatureEntitlement('ADVISOR', 'whiteLabel')).toBe(true);
    expect(hasFeatureEntitlement('ADVISOR', 'clientManagement')).toBe(true);
    expect(getTierLimit('FREE', 'maxPortfolios')).toBe(1);
    expect(getTierLimit('FREE', 'maxTransactionsPerYear')).toBe(50);
    expect(getTierLimit('PRO', 'maxPortfolios')).toBe(-1);
    expect(getTierLimit('FAMILY', 'maxFamilyMembers')).toBe(3);
    expect(getTierLimit('ADVISOR', 'maxFamilyMembers')).toBe(3);
    expect(getTierLimit('ADVISOR', 'maxClients')).toBe(30);
  });

  it('checks boolean/numeric access from the tier config when Open Beta is explicitly off', () => {
    const previousMode = process.env.OPEN_BETA_MODE;
    process.env.OPEN_BETA_MODE = 'false';
    try {
      expect(checkFeatureAccess('FREE', 'csvUpload')).toBe(true);
      expect(checkFeatureAccess('FREE', 'aiAssistant')).toBe(false);
      expect(checkFeatureAccess('PRO', 'advancedAnalytics')).toBe(true);
      expect(checkFeatureAccess('FAMILY', 'maxFamilyMembers')).toBe(true);
      expect(checkFeatureAccess('FREE', 'maxPortfolios')).toBe(true);
      expect(checkFeatureAccess('PRO', 'maxFamilyMembers')).toBe(false);
    } finally {
      if (previousMode === undefined) delete process.env.OPEN_BETA_MODE;
      else process.env.OPEN_BETA_MODE = previousMode;
    }
  });

  it('exposes all higher tiers as the upgrade path and preserves all-access default during beta', () => {
    const previousMode = process.env.OPEN_BETA_MODE;
    try {
      expect(getTierUpgradePath('FREE')).toEqual(['PRO', 'FAMILY', 'ADVISOR']);
      expect(getTierUpgradePath('PRO')).toEqual(['FAMILY', 'ADVISOR']);
      expect(getTierUpgradePath('ADVISOR')).toEqual([]);

      delete process.env.OPEN_BETA_MODE;
      expect(checkFeatureAccess('FREE', 'whiteLabel')).toBe(true);
      process.env.OPEN_BETA_MODE = 'true';
      expect(checkFeatureAccess('FREE', 'whiteLabel')).toBe(true);
    } finally {
      if (previousMode === undefined) delete process.env.OPEN_BETA_MODE;
      else process.env.OPEN_BETA_MODE = previousMode;
    }
  });
});
