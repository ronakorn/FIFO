import Decimal from 'decimal.js';

/** Decimal.js context used for every billing quote and discount calculation. */
export const PricingDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Public plan configuration. THB amounts are integer literals from the approved
 * pricing schedule; all calculations convert them to Decimal strings first.
 */
export const SUBSCRIPTION_TIERS = {
  FREE: {
    id: 'free',
    nameTH: 'ฟรี',
    nameEN: 'Free',
    monthlyPriceTHB: 0,
    yearlyPriceTHB: 0,
    stripePriceIdMonthly: null,
    stripePriceIdYearly: null,
    features: {
      maxPortfolios: 1,
      maxTransactionsPerYear: 50,
      csvUpload: true,
      basicNetWorth: true,
      taxReportPDF: false,
      advancedAnalytics: false,
      firePlanner: false,
      aiAssistant: false,
      familyWealth: false,
      auditTrail: false,
      prioritySupport: false,
    },
  },
  PRO: {
    id: 'pro',
    nameTH: 'โปร',
    nameEN: 'Pro',
    monthlyPriceTHB: 290,
    yearlyPriceTHB: 2784,
    stripePriceIdMonthly: 'price_pro_monthly', // TODO: Replace with real Stripe Price ID
    stripePriceIdYearly: 'price_pro_yearly',
    features: {
      maxPortfolios: -1,
      maxTransactionsPerYear: -1,
      csvUpload: true,
      basicNetWorth: true,
      taxReportPDF: true,
      advancedAnalytics: true,
      firePlanner: true,
      aiAssistant: true,
      familyWealth: false,
      auditTrail: true,
      prioritySupport: true,
    },
  },
  FAMILY: {
    id: 'family',
    nameTH: 'ครอบครัว',
    nameEN: 'Family',
    monthlyPriceTHB: 590,
    yearlyPriceTHB: 5664,
    stripePriceIdMonthly: 'price_family_monthly',
    stripePriceIdYearly: 'price_family_yearly',
    features: {
      maxPortfolios: -1,
      maxTransactionsPerYear: -1,
      csvUpload: true,
      basicNetWorth: true,
      taxReportPDF: true,
      advancedAnalytics: true,
      firePlanner: true,
      aiAssistant: true,
      familyWealth: true,
      auditTrail: true,
      prioritySupport: true,
      maxFamilyMembers: 3,
    },
  },
  ADVISOR: {
    id: 'advisor',
    nameTH: 'ที่ปรึกษา',
    nameEN: 'Advisor',
    monthlyPriceTHB: 1990,
    yearlyPriceTHB: 19104,
    stripePriceIdMonthly: 'price_advisor_monthly',
    stripePriceIdYearly: 'price_advisor_yearly',
    features: {
      maxPortfolios: -1,
      maxTransactionsPerYear: -1,
      csvUpload: true,
      basicNetWorth: true,
      taxReportPDF: true,
      advancedAnalytics: true,
      firePlanner: true,
      aiAssistant: true,
      familyWealth: true,
      auditTrail: true,
      prioritySupport: true,
      whiteLabel: true,
      clientManagement: true,
      maxFamilyMembers: 3,
      maxClients: 30,
    },
  },
} as const;

export type TierId = keyof typeof SUBSCRIPTION_TIERS;
export type PaidTierId = Exclude<TierId, 'FREE'>;
export type BillingInterval = 'month' | 'year';

export type FeatureKey =
  | 'csvUpload'
  | 'basicNetWorth'
  | 'taxReportPDF'
  | 'advancedAnalytics'
  | 'firePlanner'
  | 'aiAssistant'
  | 'familyWealth'
  | 'auditTrail'
  | 'prioritySupport'
  | 'whiteLabel'
  | 'clientManagement';

export type LimitKey =
  | 'maxPortfolios'
  | 'maxTransactionsPerYear'
  | 'maxFamilyMembers'
  | 'maxClients';

export type EntitlementKey = FeatureKey | LimitKey;

/** The first tier that includes each boolean feature. */
export const FEATURE_REQUIRED_TIER = {
  csvUpload: 'FREE',
  basicNetWorth: 'FREE',
  taxReportPDF: 'PRO',
  advancedAnalytics: 'PRO',
  firePlanner: 'PRO',
  aiAssistant: 'PRO',
  familyWealth: 'FAMILY',
  auditTrail: 'PRO',
  prioritySupport: 'PRO',
  whiteLabel: 'ADVISOR',
  clientManagement: 'ADVISOR',
} as const satisfies Record<FeatureKey, TierId>;

export const TIER_RANK: Record<TierId, number> = {
  FREE: 0,
  PRO: 1,
  FAMILY: 2,
  ADVISOR: 3,
};

export const EARLY_BIRD_DISCOUNT = {
  discountPercentage: 30,
  validUntil: '2027-06-30',
  lifetimeDiscount: true,
  endsOnCancellation: true,
} as const;

export interface PriceQuote {
  tier: TierId;
  interval: BillingInterval;
  baseAmountTHB: string;
  amountTHB: string;
  discountAmountTHB: string;
  discountPercentage: number;
  stripePriceId: string | null;
  earlyBirdApplied: boolean;
}

function money(value: Decimal.Value): Decimal {
  return new PricingDecimal(value);
}

function canonicalTHB(value: Decimal): string {
  return value.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
}

export function isEarlyBirdWindowOpen(asOf = new Date()): boolean {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Bangkok',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(asOf);
  const value = Object.fromEntries(parts.map(({ type, value: part }) => [type, part]));
  const dateInBangkok = `${value['year']}-${value['month']}-${value['day']}`;
  return dateInBangkok <= EARLY_BIRD_DISCOUNT.validUntil;
}

export function isTierAtLeast(currentTier: TierId, requiredTier: TierId): boolean {
  return TIER_RANK[currentTier] >= TIER_RANK[requiredTier];
}

/** Open Beta is the safe default unless the deployment explicitly sets it false. */
function isOpenBetaAccessEnabled(): boolean {
  return process.env.OPEN_BETA_MODE === 'true' || process.env.OPEN_BETA_MODE === undefined;
}

/**
 * Checks whether a tier includes a boolean feature or has a non-zero numeric
 * entitlement. Numeric quota enforcement still needs the current usage count.
 */
export function checkFeatureAccess(
  userTier: TierId,
  requiredFeature: EntitlementKey
): boolean {
  if (isOpenBetaAccessEnabled()) return true;

  const tierConfig = SUBSCRIPTION_TIERS[userTier];
  if (!tierConfig) return false;
  const features = tierConfig.features as Partial<Record<EntitlementKey, boolean | number>>;
  const featureValue = features[requiredFeature];

  if (typeof featureValue === 'boolean') return featureValue;
  if (typeof featureValue === 'number') return featureValue === -1 || featureValue > 0;
  return false;
}

export function getTierUpgradePath(currentTier: TierId): TierId[] {
  const tierOrder: TierId[] = ['FREE', 'PRO', 'FAMILY', 'ADVISOR'];
  const currentIndex = tierOrder.indexOf(currentTier);
  return currentIndex < 0 ? [] : tierOrder.slice(currentIndex + 1);
}

export function getRequiredTierForFeature(feature: FeatureKey): TierId {
  return FEATURE_REQUIRED_TIER[feature];
}

export function hasFeatureEntitlement(tier: TierId, feature: FeatureKey): boolean {
  if (!isTierAtLeast(tier, FEATURE_REQUIRED_TIER[feature])) return false;
  const features = SUBSCRIPTION_TIERS[tier].features as Record<string, unknown>;
  return features[feature] === true;
}

export function getTierEntitlements(tier: TierId): Record<string, boolean | number> {
  return { ...SUBSCRIPTION_TIERS[tier].features };
}

export function getTierLimit(tier: TierId, limit: LimitKey): number {
  const features = SUBSCRIPTION_TIERS[tier].features as Record<string, unknown>;
  const value = features[limit];
  return typeof value === 'number' ? value : 0;
}

export function getYearlySavingsPercentage(tier: TierId): string {
  const monthly = money(String(SUBSCRIPTION_TIERS[tier].monthlyPriceTHB));
  const yearly = money(String(SUBSCRIPTION_TIERS[tier].yearlyPriceTHB));
  const annualMonthlyEquivalent = monthly.times(12);
  if (annualMonthlyEquivalent.isZero()) return '0.00';
  return canonicalTHB(
    annualMonthlyEquivalent.minus(yearly).dividedBy(annualMonthlyEquivalent).times(100)
  );
}

export function getPriceQuote(
  tier: TierId,
  interval: BillingInterval,
  options: {
    isBetaUser?: boolean;
    earlyBirdClaimed?: boolean;
    earlyBirdCanceled?: boolean;
    asOf?: Date;
  } = {}
): PriceQuote {
  const tierConfig = SUBSCRIPTION_TIERS[tier];
  const isPaidTier = tier !== 'FREE';
  const claimIsActive = Boolean(options.earlyBirdClaimed && !options.earlyBirdCanceled);
  const betaWindowIsOpen = Boolean(
    options.isBetaUser && !options.earlyBirdClaimed && !options.earlyBirdCanceled &&
    isEarlyBirdWindowOpen(options.asOf)
  );
  const earlyBirdApplied = Boolean(isPaidTier && (claimIsActive || betaWindowIsOpen));
  const baseAmount = money(
    String(interval === 'month' ? tierConfig.monthlyPriceTHB : tierConfig.yearlyPriceTHB)
  );
  const discountPercentage = earlyBirdApplied ? EARLY_BIRD_DISCOUNT.discountPercentage : 0;
  const amount = baseAmount
    .times(money(100).minus(discountPercentage))
    .dividedBy(100);

  return {
    tier,
    interval,
    baseAmountTHB: canonicalTHB(baseAmount),
    amountTHB: canonicalTHB(amount),
    discountAmountTHB: canonicalTHB(baseAmount.minus(amount)),
    discountPercentage,
    stripePriceId:
      interval === 'month' ? tierConfig.stripePriceIdMonthly : tierConfig.stripePriceIdYearly,
    earlyBirdApplied,
  };
}

export function getPublicPricingCatalog(
  isBetaUser: boolean,
  asOf = new Date(),
  options: { earlyBirdClaimed?: boolean; earlyBirdCanceled?: boolean } = {}
) {
  const earlyBirdClaimed = Boolean(options.earlyBirdClaimed);
  const earlyBirdCanceled = Boolean(options.earlyBirdCanceled);
  const betaWindowIsOpen = Boolean(
    isBetaUser && !earlyBirdClaimed && !earlyBirdCanceled && isEarlyBirdWindowOpen(asOf)
  );
  const activeClaim = earlyBirdClaimed && !earlyBirdCanceled;
  const tiers = (Object.keys(SUBSCRIPTION_TIERS) as TierId[]).map((tier) => ({
    tier,
    id: SUBSCRIPTION_TIERS[tier].id,
    nameTH: SUBSCRIPTION_TIERS[tier].nameTH,
    nameEN: SUBSCRIPTION_TIERS[tier].nameEN,
    monthlyPriceTHB: getPriceQuote(tier, 'month', { isBetaUser: false, asOf }).amountTHB,
    yearlyPriceTHB: getPriceQuote(tier, 'year', { isBetaUser: false, asOf }).amountTHB,
    earlyBirdMonthlyPriceTHB: getPriceQuote(tier, 'month', {
      isBetaUser,
      earlyBirdClaimed,
      earlyBirdCanceled,
      asOf,
    }).amountTHB,
    earlyBirdYearlyPriceTHB: getPriceQuote(tier, 'year', {
      isBetaUser,
      earlyBirdClaimed,
      earlyBirdCanceled,
      asOf,
    }).amountTHB,
    yearlySavingsPercentage: getYearlySavingsPercentage(tier),
    features: getTierEntitlements(tier),
  }));

  return {
    tiers,
    earlyBird: {
      eligible: activeClaim || betaWindowIsOpen,
      canClaim: betaWindowIsOpen,
      claimed: earlyBirdClaimed,
      canceled: earlyBirdCanceled,
      discountActive: activeClaim || betaWindowIsOpen,
      discountPercentage: EARLY_BIRD_DISCOUNT.discountPercentage,
      validUntil: EARLY_BIRD_DISCOUNT.validUntil,
      lifetimeDiscount: EARLY_BIRD_DISCOUNT.lifetimeDiscount,
      endsOnCancellation: EARLY_BIRD_DISCOUNT.endsOnCancellation,
    },
  };
}
