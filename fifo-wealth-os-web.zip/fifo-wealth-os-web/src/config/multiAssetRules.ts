// Backward-compatible backend import path; canonical shared rules live in @fifo/utils.
export * from '@fifo/utils/multiAssetRules';
