export const BASE_CURRENCY = 'THB' as const;

export type BaseCurrency = typeof BASE_CURRENCY;

export type Exchange = 'BITKUB' | 'IBKR' | 'STREAMING' | 'DIME' | 'BINANCE';

export type TransactionType = 'BUY' | 'SELL';

export type LotStatus = 'Hold' | 'Partial' | 'Sold';

export interface Transaction {
  id: string;
  date: string;
  symbol: string;
  qty: number;
  price: number;
  gross: number;
  comm: number;
  vat: number;
  net: number;
  type: TransactionType;
  exchange: Exchange;
  currency?: string;
  originalCurrency: string;
  originalNet: string;
  fxRate: string | null;
  netTHB: string | null;
}

export interface Lot {
  id: string;
  date: string;
  symbol: string;
  buyQty: number;
  costPerUnit: number;
  qtySold: number;
  qtyRemain: number;
  realizedGL: number;
  unrealizedGL: number;
  status: LotStatus;
}

export interface FIFOResult {
  lots: Lot[];
  totalRealizedGL: number;
  totalUnrealizedGL: number;
  totalCostSold: number;
  totalProceeds: number;
}

export interface Dividend {
  id: string;
  date: string;
  symbol: string;
  qty: number;
  divPerShare: string;
  gross: string;
  whtRate: number;
  wht: string;
  net: string;
  originalCurrency: string;
  fxRate: string | null;
  grossTHB: string | null;
  whtTHB: string | null;
  netTHB: string | null;
}

export type TaxEventType = 'CAPITAL_GAIN' | 'DIVIDEND';

export interface TaxEvent {
  id: string;
  type: TaxEventType;
  date: string;
  symbol: string;
  amountTHB: string;
  taxableIncome: string;
  taxWithheld: string;
  netTaxPayable: string;
}

export interface TaxReport {
  taxYear: number;
  capitalGains: TaxEvent[];
  dividends: TaxEvent[];
  totalTaxableIncome: string;
  totalTaxWithheld: string;
  totalTaxPayable: string;
  generatedAt: string;
}

export type AssetTaxCategory = 'THAI_EQUITY' | 'FOREIGN_EQUITY' | 'CRYPTO';

export interface SymbolTaxProfile {
  category: AssetTaxCategory;
  /**
   * Applicable to FOREIGN_EQUITY under Thai Revenue Dept Order Por. 161/2566:
   * true if proceeds/gains were remitted into Thailand within the tax year (default: true).
   */
  remittedToThailand?: boolean;
}

export interface ThaiTaxOptions {
  /**
   * Optional per-symbol tax classification (e.g. THAI_EQUITY exempt on SET,
   * FOREIGN_EQUITY subject to remittance rule, CRYPTO taxable under Sec. 40(4)(h)).
   */
  symbolProfiles?: Record<string, SymbolTaxProfile>;
  /**
   * Default asset category for symbols not explicitly listed in `symbolProfiles`.
   * Defaults to 'FOREIGN_EQUITY' with `remittedToThailand: true` (assessable).
   */
  defaultCategory?: AssetTaxCategory;
  /**
   * Default remittance flag for FOREIGN_EQUITY when not specified per symbol (defaults to true).
   */
  defaultRemittedToThailand?: boolean;
  /**
   * If true, elects Final Tax (Sec. 48(3)) for eligible 10%-WHT dividends so they are
   * excluded from progressive PIT calculation. Defaults to false (includes Gross Dividend in PIT
   * and credits WHT against tax payable).
   */
  electFinalTaxOnDividends?: boolean;
  /**
   * Optional prior net assessable income (e.g. salary after allowances) in THB as exact string
   * to position investment income into the taxpayer's actual progressive marginal bracket.
   * Defaults to '0.00'.
   */
  otherNetIncomeTHB?: string;
  /**
   * Optional deterministic timestamp override for `generatedAt` (ISO-8601).
   */
  generatedAt?: string;
}
