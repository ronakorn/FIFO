import path from 'path';
import { PrismaClient } from '@prisma/client';

let activePrismaClient: PrismaClient | null = null;

function resolveDefaultDatabaseUrl(): string {
  if (process.env['DATABASE_URL']) {
    return process.env['DATABASE_URL'];
  }
  const defaultSqlitePath = path.resolve(__dirname, '../../prisma/dev.db');
  return `file:${defaultSqlitePath}`;
}

export function getPrismaClient(): PrismaClient {
  if (!activePrismaClient) {
    activePrismaClient = new PrismaClient({
      datasources: {
        db: {
          url: resolveDefaultDatabaseUrl(),
        },
      },
    });
  }
  return activePrismaClient;
}

/**
 * Allows injecting an isolated in-memory SQLite PrismaClient during Jest testing.
 */
export function setPrismaClient(client: PrismaClient | null): void {
  activePrismaClient = client;
}
