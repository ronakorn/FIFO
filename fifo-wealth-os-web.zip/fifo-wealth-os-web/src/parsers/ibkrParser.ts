import { Transaction, TransactionType } from '../types';
import {
  Dec,
  formatExactDecimalString,
  getRequiredField,
  parseCSVDocument,
  parseDecimalField,
  parseIBKRDateToISO,
  toNumber,
} from './csvUtils';
import { CSVParserAdapter, IBKRParserOptions } from './types';

const REQUIRED_IBKR_HEADERS = [
  'TradeDate',
  'Symbol',
  'Quantity',
  'TradePrice',
  'Commission',
  'NetAmount',
  'Currency',
] as const;

function resolveIBKRTradeType(
  signedQty: InstanceType<typeof Dec>,
  signedNetAmount: InstanceType<typeof Dec>,
  tradePrice: InstanceType<typeof Dec>,
  lineNumber: number
): TransactionType {
  if (signedQty.isZero()) {
    throw new Error(`Quantity cannot be zero at IBKR CSV line ${lineNumber}.`);
  }

  // IBKR equity convention:
  // BUY:  Quantity > 0 and NetAmount < 0 (cash outflow)
  // SELL: Quantity < 0 and NetAmount > 0 (cash inflow, unless commission exceeds gross proceeds)
  if (signedQty.gt(0)) {
    if (tradePrice.gt(0) && signedNetAmount.gt(0)) {
      throw new Error(
        `Conflicting IBKR BUY signs at CSV line ${lineNumber}: Quantity (${signedQty.toString()}) > 0 but NetAmount (${signedNetAmount.toString()}) > 0.`
      );
    }
    return 'BUY';
  }

  return 'SELL';
}

/**
 * Parses Interactive Brokers (IBKR) trade history CSV content into normalized FIFO Wealth OS Transactions.
 */
export function parseIBKRCsv(
  csvContent: string,
  options?: IBKRParserOptions
): Transaction[] {
  const { headers, rows } = parseCSVDocument(csvContent);
  if (headers.length === 0 || rows.length === 0) {
    return [];
  }

  for (const requiredHeader of REQUIRED_IBKR_HEADERS) {
    if (!headers.includes(requiredHeader)) {
      throw new Error(`Missing required IBKR CSV header "${requiredHeader}".`);
    }
  }

  const idPrefix = options?.idPrefix ?? 'IBKR';

  return rows.map(({ lineNumber, data }, index) => {
    const rawDate = getRequiredField(data, 'TradeDate', lineNumber);
    const isoDate = parseIBKRDateToISO(rawDate, lineNumber);

    const symbol = getRequiredField(data, 'Symbol', lineNumber).toUpperCase();
    const currency = getRequiredField(data, 'Currency', lineNumber).toUpperCase();

    const signedQty = parseDecimalField(data, 'Quantity', lineNumber);
    const tradePrice = parseDecimalField(data, 'TradePrice', lineNumber);
    const rawCommission = parseDecimalField(data, 'Commission', lineNumber);
    const signedNetAmount = parseDecimalField(data, 'NetAmount', lineNumber);

    if (tradePrice.lt(0)) {
      throw new Error(`TradePrice cannot be negative at IBKR CSV line ${lineNumber}.`);
    }

    const type = resolveIBKRTradeType(signedQty, signedNetAmount, tradePrice, lineNumber);

    const qty = signedQty.abs();
    const gross = qty.times(tradePrice);
    const comm = rawCommission.abs();
    const vat = new Dec(0);
    const net = signedNetAmount.abs();

    const explicitId = data['TradeID']?.trim() || data['TransactionID']?.trim();
    const id = explicitId ? `${idPrefix}-${explicitId}` : `${idPrefix}-${index + 1}`;

    return {
      id,
      date: isoDate,
      symbol,
      qty: toNumber(qty),
      price: toNumber(tradePrice),
      gross: toNumber(gross),
      comm: toNumber(comm),
      vat: toNumber(vat),
      net: toNumber(net),
      type,
      exchange: 'IBKR',
      currency,
      originalCurrency: currency,
      originalNet: formatExactDecimalString(net),
      fxRate: null,
      netTHB: null,
    };
  });
}

/**
 * Convenience alias matching uppercase CSV naming convention alongside parseIBKRCsv.
 */
export const parseIBKRCSV = parseIBKRCsv;

export const ibkrParserAdapter: CSVParserAdapter<IBKRParserOptions> = {
  exchange: 'IBKR',
  parse: parseIBKRCsv,
};
