import { BASE_CURRENCY, Dividend } from '../types';
import {
  Dec,
  formatExactDecimalString,
  getRequiredField,
  parseBitkubDateToISO,
  parseCSVDocument,
  parseDecimalField,
  parseIBKRDateToISO,
  toNumber,
} from './csvUtils';

export interface DividendParserOptions {
  /**
   * Default currency when CSV does not contain an explicit `Currency` column.
   * Defaults to 'THB'.
   */
  defaultCurrency?: string;
  /**
   * Optional ID prefix for generated Dividend IDs (defaults to 'DIV').
   */
  idPrefix?: string;
}

const REQUIRED_DIVIDEND_HEADERS = [
  'Date',
  'Symbol',
  'Qty',
  'Div/Share',
  'Gross',
  'Tax',
  'Net',
] as const;

function parseDividendDateToISO(rawDate: string, lineNumber: number): string {
  const trimmed = rawDate.trim();
  if (/^\d{8}(?:[; ]\d{6})?$/.test(trimmed) || /^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    return parseIBKRDateToISO(trimmed, lineNumber);
  }
  return parseBitkubDateToISO(trimmed, lineNumber);
}

/**
 * Parses Dividend CSV content (columns: Date, Symbol, Qty, Div/Share, Gross, Tax, Net[, Currency])
 * into strictly typed Dividend objects using Decimal arithmetic only.
 */
export function parseDividends(
  csvContent: string,
  options?: DividendParserOptions
): Dividend[] {
  const { headers, rows } = parseCSVDocument(csvContent);
  if (headers.length === 0 || rows.length === 0) {
    return [];
  }

  for (const requiredHeader of REQUIRED_DIVIDEND_HEADERS) {
    if (!headers.includes(requiredHeader)) {
      throw new Error(`Missing required Dividend CSV header "${requiredHeader}".`);
    }
  }

  const defaultCurrency = (options?.defaultCurrency ?? BASE_CURRENCY).trim().toUpperCase();
  const idPrefix = options?.idPrefix ?? 'DIV';

  return rows.map(({ lineNumber, data }, index) => {
    const rawDate = getRequiredField(data, 'Date', lineNumber);
    const isoDate = parseDividendDateToISO(rawDate, lineNumber);

    const symbol = getRequiredField(data, 'Symbol', lineNumber).toUpperCase();
    const qtyDec = parseDecimalField(data, 'Qty', lineNumber);
    const divPerShareDec = parseDecimalField(data, 'Div/Share', lineNumber);
    const grossDec = parseDecimalField(data, 'Gross', lineNumber);
    const taxDec = parseDecimalField(data, 'Tax', lineNumber).abs();
    const netDec = parseDecimalField(data, 'Net', lineNumber);

    if (qtyDec.lte(0)) {
      throw new Error(`Dividend Qty must be positive at CSV line ${lineNumber}.`);
    }
    if (grossDec.lt(0) || netDec.lt(0) || divPerShareDec.lt(0)) {
      throw new Error(`Dividend amounts cannot be negative at CSV line ${lineNumber}.`);
    }

    // Calculate WHT rate strictly via Decimal (never Number / Number)
    let whtRateDec = new Dec(0);
    if (data['WHTRate'] !== undefined && data['WHTRate'].trim().length > 0) {
      whtRateDec = parseDecimalField(data, 'WHTRate', lineNumber).abs();
    } else if (grossDec.gt(0)) {
      whtRateDec = taxDec.div(grossDec).toDecimalPlaces(6, Dec.ROUND_HALF_UP);
    }

    const originalCurrency =
      data['Currency'] && data['Currency'].trim().length > 0
        ? data['Currency'].trim().toUpperCase()
        : defaultCurrency;

    const explicitId = data['ID']?.trim() || data['DividendID']?.trim();
    const id = explicitId ? `${idPrefix}-${explicitId}` : `${idPrefix}-${index + 1}`;

    return {
      id,
      date: isoDate,
      symbol,
      qty: toNumber(qtyDec),
      divPerShare: formatExactDecimalString(divPerShareDec),
      gross: formatExactDecimalString(grossDec),
      whtRate: toNumber(whtRateDec),
      wht: formatExactDecimalString(taxDec),
      net: formatExactDecimalString(netDec),
      originalCurrency,
      fxRate: null,
      grossTHB: null,
      whtTHB: null,
      netTHB: null,
    };
  });
}
