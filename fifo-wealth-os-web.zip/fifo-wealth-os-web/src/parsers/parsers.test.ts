import { calculateFIFO } from '../fifoEngine';
import { Transaction } from '../types';
import { bitkubParserAdapter, parseBitkubCSV } from './bitkubParser';
import { ibkrParserAdapter, parseIBKRCsv } from './ibkrParser';

describe('FIFO Wealth OS - Phase 2 CSV Parser Adapters', () => {
  describe('Bitkub CSV Adapter (parseBitkubCSV)', () => {
    const bitkubMockCSV = `
      วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม
      2024-10-01 10:00:00,ซื้อ,BTC/THB,2000000,0.001,2000,10
      2024-10-05 14:30:00,ขาย,BTC/THB,2100000,0.0005,1050,5.25
    `;

    it('parses Bitkub Mock CSV into strict Transaction[] with accurate BUY/SELL accounting', () => {
      const transactions: Transaction[] = parseBitkubCSV(bitkubMockCSV);

      expect(transactions).toHaveLength(2);

      // Row 1: BUY 0.001 BTC @ 2,000,000 -> gross 2000 + comm 10 + vat 0 = net 2010
      const buyTx = transactions[0]!;
      expect(buyTx).toEqual({
        id: 'BITKUB-1',
        date: '2024-10-01T10:00:00.000Z',
        symbol: 'BTC',
        qty: 0.001,
        price: 2000000,
        gross: 2000,
        comm: 10,
        vat: 0,
        net: 2010,
        type: 'BUY',
        exchange: 'BITKUB',
        currency: 'THB',
        originalCurrency: 'THB',
        originalNet: '2010.00',
        fxRate: null,
        netTHB: null,
      });

      // Row 2: SELL 0.0005 BTC @ 2,100,000 -> gross 1050 - comm 5.25 - vat 0 = net 1044.75
      const sellTx = transactions[1]!;
      expect(sellTx).toEqual({
        id: 'BITKUB-2',
        date: '2024-10-05T14:30:00.000Z',
        symbol: 'BTC',
        qty: 0.0005,
        price: 2100000,
        gross: 1050,
        comm: 5.25,
        vat: 0,
        net: 1044.75,
        type: 'SELL',
        exchange: 'BITKUB',
        currency: 'THB',
        originalCurrency: 'THB',
        originalNet: '1044.75',
        fxRate: null,
        netTHB: null,
      });
    });

    it('supports optional 7% VAT calculation (vatRate: 0.07) accurately without float drift', () => {
      const transactions = parseBitkubCSV(bitkubMockCSV, { vatRate: 0.07 });

      // BUY: gross 2000 + comm 10 + vat (10 * 0.07 = 0.7) = 2010.7
      expect(transactions[0]!.vat).toBe(0.7);
      expect(transactions[0]!.net).toBe(2010.7);

      // SELL: gross 1050 - comm 5.25 - vat (5.25 * 0.07 = 0.3675) = 1044.3825
      expect(transactions[1]!.vat).toBe(0.3675);
      expect(transactions[1]!.net).toBe(1044.3825);
    });

    it('handles UTF-8 BOM, CRLF line endings, and quoted thousand separators', () => {
      const excelExportedCSV =
        '\uFEFFวันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม\r\n' +
        '2024-10-01 10:00:00,ซื้อ,ETH/THB,"80,000.00",0.5,"40,000.00","100.00"\r\n';

      const transactions = bitkubParserAdapter.parse(excelExportedCSV);
      expect(transactions).toHaveLength(1);
      expect(transactions[0]).toMatchObject({
        symbol: 'ETH',
        currency: 'THB',
        price: 80000,
        qty: 0.5,
        gross: 40000,
        comm: 100,
        net: 40100,
        type: 'BUY',
        exchange: 'BITKUB',
      });
    });

    it('throws descriptive error on unsupported Bitkub order type', () => {
      const invalidCSV = `
        วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม
        2024-10-01 10:00:00,โอนเหรียญ,BTC/THB,2000000,0.001,2000,10
      `;

      expect(() => parseBitkubCSV(invalidCSV)).toThrow(/Unsupported Bitkub order type/);
    });
  });

  describe('IBKR CSV Adapter (parseIBKRCsv)', () => {
    const ibkrMockCSV = `
      TradeDate,Symbol,Quantity,TradePrice,Commission,NetAmount,Currency
      20241001,AAPL,10,150.50,1.00,-1506.00,USD
      20241010,AAPL,-5,160.00,1.00,799.00,USD
    `;

    it('parses IBKR Mock CSV into strict Transaction[] with accurate sign & USD currency handling', () => {
      const transactions: Transaction[] = parseIBKRCsv(ibkrMockCSV);

      expect(transactions).toHaveLength(2);

      // Row 1: Quantity +10, NetAmount -1506.00 => BUY 10 AAPL, gross 1505.00, comm 1.00, net 1506.00
      const buyTx = transactions[0]!;
      expect(buyTx).toEqual({
        id: 'IBKR-1',
        date: '2024-10-01T00:00:00.000Z',
        symbol: 'AAPL',
        qty: 10,
        price: 150.5,
        gross: 1505,
        comm: 1,
        vat: 0,
        net: 1506,
        type: 'BUY',
        exchange: 'IBKR',
        currency: 'USD',
        originalCurrency: 'USD',
        originalNet: '1506.00',
        fxRate: null,
        netTHB: null,
      });

      // Row 2: Quantity -5, NetAmount +799.00 => SELL 5 AAPL, gross 800.00, comm 1.00, net 799.00
      const sellTx = transactions[1]!;
      expect(sellTx).toEqual({
        id: 'IBKR-2',
        date: '2024-10-10T00:00:00.000Z',
        symbol: 'AAPL',
        qty: 5,
        price: 160,
        gross: 800,
        comm: 1,
        vat: 0,
        net: 799,
        type: 'SELL',
        exchange: 'IBKR',
        currency: 'USD',
        originalCurrency: 'USD',
        originalNet: '799.00',
        fxRate: null,
        netTHB: null,
      });
    });

    it('normalizes negative Commission values from IBKR Flex Queries to absolute values', () => {
      const flexQueryCSV = `
        TradeDate,Symbol,Quantity,TradePrice,Commission,NetAmount,Currency
        20241001;093015,NVDA,2,120.00,-1.25,-241.25,USD
      `;

      const transactions = ibkrParserAdapter.parse(flexQueryCSV);
      expect(transactions).toHaveLength(1);
      expect(transactions[0]).toMatchObject({
        date: '2024-10-01T09:30:15.000Z',
        symbol: 'NVDA',
        qty: 2,
        price: 120,
        gross: 240,
        comm: 1.25,
        net: 241.25,
        type: 'BUY',
        exchange: 'IBKR',
        currency: 'USD',
      });
    });

    it('throws descriptive error when IBKR BUY row has conflicting positive NetAmount', () => {
      const corruptedCSV = `
        TradeDate,Symbol,Quantity,TradePrice,Commission,NetAmount,Currency
        20241001,AAPL,10,150.50,1.00,1506.00,USD
      `;

      expect(() => parseIBKRCsv(corruptedCSV)).toThrow(/Conflicting IBKR BUY signs/);
    });
  });

  describe('End-to-End Integration: CSV Parsers -> Core FIFO Engine', () => {
    it('seamlessly feeds parsed Bitkub CSV transactions into calculateFIFO', () => {
      const csv = `
        วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม
        2024-10-01 10:00:00,ซื้อ,BTC/THB,2000000,0.001,2000,10
        2024-10-05 14:30:00,ขาย,BTC/THB,2100000,0.0005,1050,5.25
      `;

      const txs = parseBitkubCSV(csv);
      const buys = txs.filter((t) => t.type === 'BUY');
      const sells = txs.filter((t) => t.type === 'SELL');

      const result = calculateFIFO(buys, sells, { BTC: 2200000 });

      // Cost of 0.001 BTC = 2010 THB => costPerUnit = 2,010,000 THB
      // Sold 0.0005 BTC for net 1044.75 THB vs cost 1005 THB => Realized G/L = +39.75 THB
      // Remaining 0.0005 BTC @ 2,200,000 THB => Unrealized G/L = (2,200,000 - 2,010,000) * 0.0005 = +95 THB
      expect(result.lots).toHaveLength(1);
      expect(result.lots[0]).toMatchObject({
        symbol: 'BTC',
        buyQty: 0.001,
        costPerUnit: 2010000,
        qtySold: 0.0005,
        qtyRemain: 0.0005,
        realizedGL: 39.75,
        unrealizedGL: 95,
        status: 'Partial',
      });
      expect(result.totalRealizedGL).toBe(39.75);
      expect(result.totalUnrealizedGL).toBe(95);
    });

    it('seamlessly feeds parsed IBKR CSV transactions into calculateFIFO', () => {
      const csv = `
        TradeDate,Symbol,Quantity,TradePrice,Commission,NetAmount,Currency
        20241001,AAPL,10,150.50,1.00,-1506.00,USD
        20241010,AAPL,-5,160.00,1.00,799.00,USD
      `;

      const txs = parseIBKRCsv(csv);
      const buys = txs.filter((t) => t.type === 'BUY');
      const sells = txs.filter((t) => t.type === 'SELL');

      const result = calculateFIFO(buys, sells, { AAPL: 170.0 });

      // Cost of 10 AAPL = 1506 USD => costPerUnit = 150.60 USD
      // Sold 5 AAPL for net 799 USD vs cost 753 USD => Realized G/L = +46.00 USD
      // Remaining 5 AAPL @ 170.00 USD => Unrealized G/L = (170.00 - 150.60) * 5 = +97.00 USD
      expect(result.lots).toHaveLength(1);
      expect(result.lots[0]).toMatchObject({
        symbol: 'AAPL',
        buyQty: 10,
        costPerUnit: 150.6,
        qtySold: 5,
        qtyRemain: 5,
        realizedGL: 46,
        unrealizedGL: 97,
        status: 'Partial',
      });
      expect(result.totalRealizedGL).toBe(46);
      expect(result.totalUnrealizedGL).toBe(97);
    });
  });
});
