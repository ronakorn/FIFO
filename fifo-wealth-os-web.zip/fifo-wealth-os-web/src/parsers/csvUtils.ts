import Decimal from 'decimal.js';
import { ParsedCSVDocument, ParsedCSVRow } from './types';

/**
 * Isolated IEEE 754-2008 decimal128 configuration (34 significant digits)
 * shared across CSV parser adapters for exact monetary calculations.
 */
export const Dec = Decimal.clone({
  precision: 34,
  rounding: Decimal.ROUND_HALF_UP,
});

/**
 * Converts a Decimal value to a standard JS number while normalizing -0 to 0.
 */
export function toNumber(value: Decimal): number {
  const num = value.toNumber();
  return Object.is(num, -0) ? 0 : num;
}

/**
 * Formats a Decimal into an exact non-exponential decimal string with ZERO rounding,
 * preserving at least 2 decimal places for monetary consistency (e.g. '55345.50', '1044.3825').
 */
export function formatExactDecimalString(value: Decimal): string {
  const normalized = value.isZero() ? new Dec(0) : value;
  return normalized.decimalPlaces() < 2 ? normalized.toFixed(2) : normalized.toFixed();
}

/**
 * Parses a single RFC-4180 CSV line into trimmed field strings,
 * properly supporting double-quoted fields, escaped quotes (""), and commas inside quotes.
 */
export function parseCSVLine(line: string, lineNumber: number): string[] {
  const fields: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];

    if (inQuotes) {
      if (char === '"') {
        if (i + 1 < line.length && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        if (current.trim().length > 0) {
          throw new Error(`Malformed CSV quote at line ${lineNumber}.`);
        }
        current = '';
        inQuotes = true;
      } else if (char === ',') {
        fields.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
  }

  if (inQuotes) {
    throw new Error(`Unterminated quoted field in CSV at line ${lineNumber}.`);
  }

  fields.push(current.trim());
  return fields;
}

/**
 * Parses raw CSV content into headers and structured row maps.
 * Handles UTF-8 BOM, CRLF/LF line endings, and leading/trailing blank lines.
 */
export function parseCSVDocument(csvContent: string): ParsedCSVDocument {
  const cleaned = csvContent.replace(/^\uFEFF/, '');
  const rawLines = cleaned.split(/\r?\n/);

  const nonEmptyLines: Array<{ lineNumber: number; text: string }> = [];
  for (let i = 0; i < rawLines.length; i++) {
    const rawLine = rawLines[i];
    if (rawLine !== undefined && rawLine.trim().length > 0) {
      nonEmptyLines.push({ lineNumber: i + 1, text: rawLine.trim() });
    }
  }

  if (nonEmptyLines.length === 0) {
    return { headers: [], rows: [] };
  }

  const headerEntry = nonEmptyLines[0]!;
  const headers = parseCSVLine(headerEntry.text, headerEntry.lineNumber);

  const rows: Array<{ lineNumber: number; data: ParsedCSVRow }> = [];

  for (let i = 1; i < nonEmptyLines.length; i++) {
    const entry = nonEmptyLines[i]!;
    const values = parseCSVLine(entry.text, entry.lineNumber);

    if (values.length !== headers.length) {
      throw new Error(
        `CSV column count mismatch at line ${entry.lineNumber}: expected ${headers.length} columns, received ${values.length}.`
      );
    }

    const rowData: ParsedCSVRow = {};
    for (let colIdx = 0; colIdx < headers.length; colIdx++) {
      const headerName = headers[colIdx]!;
      rowData[headerName] = values[colIdx] ?? '';
    }

    rows.push({ lineNumber: entry.lineNumber, data: rowData });
  }

  return { headers, rows };
}

/**
 * Retrieves a required string field from a CSV row, throwing a descriptive error if missing.
 */
export function getRequiredField(
  row: ParsedCSVRow,
  fieldName: string,
  lineNumber: number
): string {
  const value = row[fieldName];
  if (value === undefined || value.trim().length === 0) {
    throw new Error(`Missing required field "${fieldName}" at CSV line ${lineNumber}.`);
  }
  return value.trim();
}

/**
 * Parses a numeric field (supporting thousand-separator commas) into a high-precision Decimal.
 */
export function parseDecimalField(
  row: ParsedCSVRow,
  fieldName: string,
  lineNumber: number
): Decimal {
  const raw = getRequiredField(row, fieldName, lineNumber);
  const normalized = raw.replace(/,/g, '');

  if (!/^[+-]?(\d+(\.\d+)?|\.\d+)([eE][+-]?\d+)?$/.test(normalized)) {
    throw new Error(
      `Invalid numeric value "${raw}" for field "${fieldName}" at CSV line ${lineNumber}.`
    );
  }

  return new Dec(normalized);
}

/**
 * Deterministically converts a Bitkub timestamp (e.g. "2024-10-01 10:00:00" or ISO string)
 * into a UTC ISO-8601 string ("2024-10-01T10:00:00.000Z").
 */
export function parseBitkubDateToISO(rawDate: string, lineNumber: number): string {
  const trimmed = rawDate.trim();

  // Match "YYYY-MM-DD HH:mm:ss" or "YYYY-MM-DDTHH:mm:ss" without explicit timezone
  const localMatch = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?$/.exec(
    trimmed
  );

  if (localMatch) {
    const year = Number(localMatch[1]);
    const month = Number(localMatch[2]);
    const day = Number(localMatch[3]);
    const hour = Number(localMatch[4]);
    const minute = Number(localMatch[5]);
    const second = Number(localMatch[6]);
    const ms = localMatch[7] ? Number(localMatch[7].padEnd(3, '0')) : 0;

    const date = new Date(Date.UTC(year, month - 1, day, hour, minute, second, ms));
    if (
      date.getUTCFullYear() !== year ||
      date.getUTCMonth() !== month - 1 ||
      date.getUTCDate() !== day ||
      date.getUTCHours() !== hour ||
      date.getUTCMinutes() !== minute ||
      date.getUTCSeconds() !== second
    ) {
      throw new Error(`Invalid calendar date "${rawDate}" at CSV line ${lineNumber}.`);
    }

    return date.toISOString();
  }

  // Fallback for already ISO-formatted timestamps with explicit timezone (Z or +/-HH:mm)
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error(`Invalid date format "${rawDate}" at CSV line ${lineNumber}.`);
  }

  return parsed.toISOString();
}

/**
 * Deterministically converts an IBKR TradeDate (e.g. "20241001", "20241001;143000", or "2024-10-01")
 * into a UTC ISO-8601 string ("2024-10-01T00:00:00.000Z").
 */
export function parseIBKRDateToISO(rawDate: string, lineNumber: number): string {
  const trimmed = rawDate.trim();

  // Match compact IBKR Flex format "YYYYMMDD" or "YYYYMMDD;HHMMSS"
  const compactMatch = /^(\d{4})(\d{2})(\d{2})(?:[; ](\d{2})(\d{2})(\d{2}))?$/.exec(trimmed);
  if (compactMatch) {
    const year = Number(compactMatch[1]);
    const month = Number(compactMatch[2]);
    const day = Number(compactMatch[3]);
    const hour = compactMatch[4] ? Number(compactMatch[4]) : 0;
    const minute = compactMatch[5] ? Number(compactMatch[5]) : 0;
    const second = compactMatch[6] ? Number(compactMatch[6]) : 0;

    const date = new Date(Date.UTC(year, month - 1, day, hour, minute, second, 0));
    if (
      date.getUTCFullYear() !== year ||
      date.getUTCMonth() !== month - 1 ||
      date.getUTCDate() !== day ||
      date.getUTCHours() !== hour ||
      date.getUTCMinutes() !== minute ||
      date.getUTCSeconds() !== second
    ) {
      throw new Error(`Invalid IBKR TradeDate "${rawDate}" at CSV line ${lineNumber}.`);
    }

    return date.toISOString();
  }

  // Match "YYYY-MM-DD"
  const isoDateOnlyMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
  if (isoDateOnlyMatch) {
    const year = Number(isoDateOnlyMatch[1]);
    const month = Number(isoDateOnlyMatch[2]);
    const day = Number(isoDateOnlyMatch[3]);
    const date = new Date(Date.UTC(year, month - 1, day, 0, 0, 0, 0));

    if (
      date.getUTCFullYear() !== year ||
      date.getUTCMonth() !== month - 1 ||
      date.getUTCDate() !== day
    ) {
      throw new Error(`Invalid IBKR TradeDate "${rawDate}" at CSV line ${lineNumber}.`);
    }

    return date.toISOString();
  }

  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error(`Invalid IBKR TradeDate "${rawDate}" at CSV line ${lineNumber}.`);
  }

  return parsed.toISOString();
}
