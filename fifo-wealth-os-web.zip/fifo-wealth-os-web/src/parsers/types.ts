import { Exchange, Transaction } from '../types';

export { Exchange };

export type ParsedCSVRow = Record<string, string>;

export interface ParsedCSVDocument {
  headers: string[];
  rows: Array<{
    lineNumber: number;
    data: ParsedCSVRow;
  }>;
}

export interface BitkubParserOptions {
  /**
   * Optional VAT rate applied on top of commission when no explicit VAT column exists.
   * Defaults to 0 (Bitkub's standard exported fee column is net/inclusive unless specified).
   * Pass 0.07 if fee column is pre-VAT and 7% VAT must be added separately.
   */
  vatRate?: number;
  /**
   * Optional custom ID prefix (defaults to 'BITKUB').
   */
  idPrefix?: string;
}

export interface IBKRParserOptions {
  /**
   * Optional custom ID prefix (defaults to 'IBKR').
   */
  idPrefix?: string;
}

/**
 * Common Adapter contract for all Exchange CSV Parsers in FIFO Wealth OS.
 */
export interface CSVParserAdapter<TOptions = unknown> {
  readonly exchange: Exchange;
  parse(csvContent: string, options?: TOptions): Transaction[];
}
