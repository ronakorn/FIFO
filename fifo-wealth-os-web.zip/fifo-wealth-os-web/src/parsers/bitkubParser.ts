import { Transaction, TransactionType } from '../types';
import {
  Dec,
  formatExactDecimalString,
  getRequiredField,
  parseBitkubDateToISO,
  parseCSVDocument,
  parseDecimalField,
  toNumber,
} from './csvUtils';
import { BitkubParserOptions, CSVParserAdapter, ParsedCSVRow } from './types';

const REQUIRED_BITKUB_HEADERS = [
  'วันที่',
  'ประเภทคำสั่ง',
  'คู่เหรียญ',
  'ราคา',
  'จำนวน',
  'มูลค่ารวม',
  'ค่าธรรมเนียม',
] as const;

function parseBitkubOrderType(rawOrderType: string, lineNumber: number): TransactionType {
  const normalized = rawOrderType.trim().toUpperCase();
  if (rawOrderType.trim() === 'ซื้อ' || normalized === 'BUY') {
    return 'BUY';
  }
  if (rawOrderType.trim() === 'ขาย' || normalized === 'SELL') {
    return 'SELL';
  }
  throw new Error(
    `Unsupported Bitkub order type "${rawOrderType}" at CSV line ${lineNumber}: expected "ซื้อ" or "ขาย".`
  );
}

function parseBitkubPair(
  rawPair: string,
  lineNumber: number
): { symbol: string; currency: string } {
  const trimmed = rawPair.trim().toUpperCase();
  if (trimmed.includes('/')) {
    const [base, quote] = trimmed.split('/');
    if (!base || !quote) {
      throw new Error(`Invalid Bitkub trading pair "${rawPair}" at CSV line ${lineNumber}.`);
    }
    return { symbol: base.trim(), currency: quote.trim() };
  }

  if (trimmed.length === 0) {
    throw new Error(`Empty Bitkub trading pair at CSV line ${lineNumber}.`);
  }

  return { symbol: trimmed, currency: 'THB' };
}

function resolveBitkubVat(
  row: ParsedCSVRow,
  comm: InstanceType<typeof Dec>,
  lineNumber: number,
  options?: BitkubParserOptions
) {
  const explicitVatCol =
    row['VAT'] !== undefined && row['VAT'].trim().length > 0
      ? 'VAT'
      : row['ภาษีมูลค่าเพิ่ม'] !== undefined && row['ภาษีมูลค่าเพิ่ม'].trim().length > 0
        ? 'ภาษีมูลค่าเพิ่ม'
        : null;

  if (explicitVatCol) {
    return parseDecimalField(row, explicitVatCol, lineNumber).abs();
  }

  if (options?.vatRate !== undefined) {
    if (!Number.isFinite(options.vatRate) || options.vatRate < 0) {
      throw new Error(`Invalid vatRate option (${options.vatRate}): must be a non-negative number.`);
    }
    return comm.times(options.vatRate);
  }

  return new Dec(0);
}

/**
 * Parses Bitkub trade history CSV content into normalized FIFO Wealth OS Transactions.
 */
export function parseBitkubCSV(
  csvContent: string,
  options?: BitkubParserOptions
): Transaction[] {
  const { headers, rows } = parseCSVDocument(csvContent);
  if (headers.length === 0 || rows.length === 0) {
    return [];
  }

  for (const requiredHeader of REQUIRED_BITKUB_HEADERS) {
    if (!headers.includes(requiredHeader)) {
      throw new Error(`Missing required Bitkub CSV header "${requiredHeader}".`);
    }
  }

  const idPrefix = options?.idPrefix ?? 'BITKUB';

  return rows.map(({ lineNumber, data }, index) => {
    const rawDate = getRequiredField(data, 'วันที่', lineNumber);
    const isoDate = parseBitkubDateToISO(rawDate, lineNumber);

    const rawType = getRequiredField(data, 'ประเภทคำสั่ง', lineNumber);
    const type = parseBitkubOrderType(rawType, lineNumber);

    const rawPair = getRequiredField(data, 'คู่เหรียญ', lineNumber);
    const { symbol, currency } = parseBitkubPair(rawPair, lineNumber);

    const price = parseDecimalField(data, 'ราคา', lineNumber);
    const qty = parseDecimalField(data, 'จำนวน', lineNumber);
    const gross = parseDecimalField(data, 'มูลค่ารวม', lineNumber);
    const comm = parseDecimalField(data, 'ค่าธรรมเนียม', lineNumber).abs();

    if (qty.lte(0)) {
      throw new Error(`Quantity must be positive at Bitkub CSV line ${lineNumber}.`);
    }
    if (price.lt(0) || gross.lt(0)) {
      throw new Error(`Price and gross amount must be non-negative at Bitkub CSV line ${lineNumber}.`);
    }

    const vat = resolveBitkubVat(data, comm, lineNumber, options);

    // Accounting rule:
    // BUY:  net cost paid      = gross + comm + vat
    // SELL: net proceeds rec'd = gross - comm - vat
    const net = type === 'BUY' ? gross.plus(comm).plus(vat) : gross.minus(comm).minus(vat);

    if (net.lt(0)) {
      throw new Error(
        `Calculated negative net amount (${net.toString()}) at Bitkub CSV line ${lineNumber}.`
      );
    }

    const explicitId = data['เลขที่คำสั่ง']?.trim() || data['Order ID']?.trim();
    const id = explicitId ? `${idPrefix}-${explicitId}` : `${idPrefix}-${index + 1}`;

    return {
      id,
      date: isoDate,
      symbol,
      qty: toNumber(qty),
      price: toNumber(price),
      gross: toNumber(gross),
      comm: toNumber(comm),
      vat: toNumber(vat),
      net: toNumber(net),
      type,
      exchange: 'BITKUB',
      currency,
      originalCurrency: currency,
      originalNet: formatExactDecimalString(net),
      fxRate: null,
      netTHB: null,
    };
  });
}

export const bitkubParserAdapter: CSVParserAdapter<BitkubParserOptions> = {
  exchange: 'BITKUB',
  parse: parseBitkubCSV,
};
