import bcrypt from 'bcryptjs';
import { getPrismaClient } from '../db/prisma';
import { parseBitkubCSV } from '../parsers/bitkubParser';
import { parseDividends } from '../parsers/dividendParser';
import { parseIBKRCsv } from '../parsers/ibkrParser';
import { enrichDividendsWithFX } from '../services/dividendEnricher';
import { enrichTransactionsWithFX } from '../services/transactionEnricher';
import { defaultApiFXProvider } from '../api/fxProvider';
import { mapEngineTransactionToPrismaCreate } from '../api/mappers';

async function ensureDemoExtras(userId: string): Promise<void> {
  const prisma = getPrismaClient();

  // 1. Seed FIRE Goals if missing
  const existingGoalsCount = await prisma.fireGoal.count({ where: { userId } });
  if (existingGoalsCount === 0) {
    await prisma.fireGoal.createMany({
      data: [
        {
          userId,
          name: 'อิสรภาพทางการเงินหลัก (Core FIRE @ อายุ 50)',
          targetAmount: '12000000.00',
          currentAmount: '2550000.00',
          monthlyContribution: '35000.00',
          expectedReturn: '0.085',
          inflationRate: '0.03',
          targetYear: 2044,
          currentAge: 32,
          retirementAge: 50,
        },
        {
          userId,
          name: 'กองทุน Coast FIRE & Passive Dividend',
          targetAmount: '5000000.00',
          currentAmount: '3650000.00',
          monthlyContribution: '20000.00',
          expectedReturn: '0.08',
          inflationRate: '0.03',
          targetYear: 2033,
          currentAge: 32,
          retirementAge: 39,
        },
        {
          userId,
          name: 'บ้านตากอากาศเชียงใหม่ & ท่องเที่ยวรอบโลก',
          targetAmount: '8500000.00',
          currentAmount: '1100000.00',
          monthlyContribution: '12000.00',
          expectedReturn: '0.07',
          inflationRate: '0.03',
          targetYear: 2038,
          currentAge: 32,
          retirementAge: 44,
        },
      ],
    });
  }

  // 2. Seed Wealth Journal Entries in October 2026 if missing
  const firstPortfolio = await prisma.portfolio.findFirst({
    where: { userId },
    orderBy: { createdAt: 'asc' },
  });

  const journalCount = await prisma.journalEntry.count({ where: { userId } });
  if (journalCount === 0) {
    await prisma.journalEntry.createMany({
      data: [
        {
          userId,
          portfolioId: firstPortfolio?.id ?? null,
          date: '2026-10-05',
          title: 'DCA หุ้นเทคโนโลยีสหรัฐฯ ตามวินัยต้นเดือน',
          content:
            'ทยอยสะสม NVDA และ AAPL ตามแผน DCA รายเดือน ผลประกอบการกลุ่ม AI Infrastructure ยังเติบโตแข็งแกร่ง รักษาสัดส่วนตามเป้าหมายระยะยาว',
          mood: 'BULLISH',
        },
        {
          userId,
          portfolioId: null,
          date: '2026-10-14',
          title: 'ทบทวนสัดส่วนเงินสดและอัตราแลกเปลี่ยน USD/THB',
          content:
            'ค่าเงินบาทผันผวนเล็กน้อยหลังตัวเลขเงินเฟ้อสหรัฐฯ ตรวจสอบต้นทุน FIFO ในสกุลบาทเรียบร้อย ยังไม่ต้องปรับพอร์ตเกินความจำเป็น',
          mood: 'NEUTRAL',
        },
        {
          userId,
          portfolioId: null,
          date: '2026-10-21',
          title: 'ระมัดระวังความผันผวนก่อนประกาศงบไตรมาส',
          content:
            'ชะลอการไล่ราคาสินทรัพย์ดิจิทัลระยะสั้น และสำรองสภาพคล่องเงินสด 15% เพื่อรองรับจังหวะย่อตัวของตลาด',
          mood: 'BEARISH',
        },
        {
          userId,
          portfolioId: firstPortfolio?.id ?? null,
          date: '2026-10-26',
          title: 'อัปเดตแผน FIRE และเป้าหมายครอบครัวไตรมาส 4',
          content:
            'อัตราความสำเร็จ Monte Carlo อยู่ที่ระดับ >90% และภาพรวม Household Net Worth เติบโตตามเป้าหมายประจำปี',
          mood: 'BULLISH',
        },
      ],
    });
  }

  // 3. Seed Demo Family Group ("ครอบครัวพอร์ตมั่งคั่ง") with 2 Household Members (~60% / ~40%)
  const existingFamilyMember = await prisma.familyMember.findFirst({
    where: { userId },
  });

  if (!existingFamilyMember) {
    const spouseEmail = 'spouse@wealthos.th';
    let spouse = await prisma.user.findUnique({ where: { email: spouseEmail } });
    if (!spouse) {
      const spouseHash = await bcrypt.hash('WealthOS2024!', 10);
      spouse = await prisma.user.create({
        data: {
          email: spouseEmail,
          passwordHash: spouseHash,
          name: 'คุณสมหญิง พอร์ตมั่งคั่ง (Somying Wealth)',
        },
      });

      const spousePortfolio = await prisma.portfolio.create({
        data: {
          userId: spouse.id,
          name: 'Somying Long-Term Core Wealth',
          baseCurrency: 'THB',
        },
      });

      const spouseCsv = [
        'วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม',
        '2024-10-02 10:00:00,ซื้อ,BTC/THB,2000000,0.077,154000,385',
      ].join('\n');

      const spouseTxs = await enrichTransactionsWithFX(
        parseBitkubCSV(spouseCsv),
        defaultApiFXProvider,
        'THB'
      );

      for (const tx of spouseTxs) {
        await prisma.transaction.create({
          data: mapEngineTransactionToPrismaCreate(tx, spousePortfolio.id),
        });
      }
    }

    const familyGroup = await prisma.familyGroup.upsert({
      where: { inviteCode: 'FAM-2026-THAI' },
      update: {},
      create: {
        name: 'ครอบครัวพอร์ตมั่งคั่ง (Thanakorn Family Office)',
        createdByUserId: userId,
        inviteCode: 'FAM-2026-THAI',
      },
    });

    await prisma.familyMember.upsert({
      where: {
        familyGroupId_userId: {
          familyGroupId: familyGroup.id,
          userId,
        },
      },
      update: {},
      create: {
        familyGroupId: familyGroup.id,
        userId,
        role: 'OWNER',
        permissions: JSON.stringify({
          canSeeTransactions: false,
          canSeeTotalNetWorth: true,
        }),
      },
    });

    await prisma.familyMember.upsert({
      where: {
        familyGroupId_userId: {
          familyGroupId: familyGroup.id,
          userId: spouse.id,
        },
      },
      update: {},
      create: {
        familyGroupId: familyGroup.id,
        userId: spouse.id,
        role: 'VIEWER',
        permissions: JSON.stringify({
          canSeeTransactions: false,
          canSeeTotalNetWorth: true,
        }),
      },
    });

    await prisma.portfolio.updateMany({
      where: { userId: { in: [userId, spouse.id] } },
      data: { familyGroupId: familyGroup.id },
    });
  }
}

async function seedDemoData(): Promise<void> {
  const prisma = getPrismaClient();
  const demoEmail = 'demo@wealthos.th';

  const existing = await prisma.user.findUnique({ where: { email: demoEmail } });
  if (existing) {
    await ensureDemoExtras(existing.id);
    // eslint-disable-next-line no-console
    console.log('Verified & enriched demo account (FIRE, Journal, Family):', demoEmail);
    await prisma.$disconnect();
    return;
  }

  const passwordHash = await bcrypt.hash('WealthOS2024!', 10);
  const demoUser = await prisma.user.create({
    data: {
      email: demoEmail,
      passwordHash,
      name: 'คุณธนกร พอร์ตมั่งคั่ง (Thanakorn Wealth)',
    },
  });

  // Portfolio 1: Global US Equities (IBKR -> THB)
  const usPortfolio = await prisma.portfolio.create({
    data: {
      userId: demoUser.id,
      name: 'US Tech & Flagship Equities (IBKR)',
      baseCurrency: 'THB',
    },
  });

  const ibkrCsv = [
    'TradeDate,Symbol,Quantity,TradePrice,Commission,NetAmount,Currency',
    '20241001,AAPL,10,150.50,1.00,-1506.00,USD',
    '20241002,NVDA,15,118.00,1.50,-1771.50,USD',
    '20241009,AAPL,-5,160.00,1.00,799.00,USD',
    '20241010,NVDA,-8,132.50,1.20,1058.80,USD',
  ].join('\n');

  const ibkrEnriched = await enrichTransactionsWithFX(
    parseIBKRCsv(ibkrCsv),
    defaultApiFXProvider,
    'THB'
  );

  for (const tx of ibkrEnriched) {
    await prisma.transaction.create({
      data: mapEngineTransactionToPrismaCreate(tx, usPortfolio.id),
    });
  }

  const divCsv = [
    'Date,Symbol,Qty,Div/Share,Gross,Tax,Net,Currency',
    '2024-10-15,AAPL,5,0.25,1.25,0.1875,1.0625,USD',
    '2024-10-15,NVDA,7,0.10,0.70,0.105,0.595,USD',
  ].join('\n');

  const divsEnriched = await enrichDividendsWithFX(
    parseDividends(divCsv),
    defaultApiFXProvider,
    'THB'
  );

  for (const div of divsEnriched) {
    await prisma.dividend.create({
      data: {
        portfolioId: usPortfolio.id,
        date: div.date,
        symbol: div.symbol,
        qty: div.qty,
        divPerShare: div.divPerShare,
        gross: div.gross,
        whtRate: div.whtRate,
        wht: div.wht,
        net: div.net,
        originalCurrency: div.originalCurrency,
        fxRate: div.fxRate,
        grossTHB: div.grossTHB,
        whtTHB: div.whtTHB,
        netTHB: div.netTHB,
      },
    });
  }

  // Portfolio 2: Digital Assets Thailand (Bitkub THB)
  const cryptoPortfolio = await prisma.portfolio.create({
    data: {
      userId: demoUser.id,
      name: 'Digital Assets Thailand (Bitkub)',
      baseCurrency: 'THB',
    },
  });

  const bitkubCsv = [
    'วันที่,ประเภทคำสั่ง,คู่เหรียญ,ราคา,จำนวน,มูลค่ารวม,ค่าธรรมเนียม',
    '2024-10-01 10:00:00,ซื้อ,BTC/THB,2000000,0.05,100000,250',
    '2024-10-02 11:15:00,ซื้อ,ETH/THB,82000,1.5,123000,307.50',
    '2024-10-05 14:30:00,ขาย,BTC/THB,2180000,0.025,54500,136.25',
    '2024-10-10 16:45:00,ขาย,ETH/THB,88500,0.5,44250,110.63',
  ].join('\n');

  const bitkubEnriched = await enrichTransactionsWithFX(
    parseBitkubCSV(bitkubCsv),
    defaultApiFXProvider,
    'THB'
  );

  for (const tx of bitkubEnriched) {
    await prisma.transaction.create({
      data: mapEngineTransactionToPrismaCreate(tx, cryptoPortfolio.id),
    });
  }

  await ensureDemoExtras(demoUser.id);
  // eslint-disable-next-line no-console
  console.log('Seeded demo investor account + Journal + Family:', demoEmail);
  await prisma.$disconnect();
}

seedDemoData().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});
