import path from 'path';
import { calculateFIFO } from '../fifoEngine';
import { parseDividends } from '../parsers/dividendParser';
import { enrichDividendsWithFX } from '../services/dividendEnricher';
import { MockFXRateProvider } from '../services/fxRateService';
import { generateTaxReportPDF } from '../services/taxReportGenerator';
import { calculateThaiTax } from '../services/thaiTaxEngine';
import { BASE_CURRENCY, Transaction } from '../types';

async function main(): Promise<void> {
  const baselineBuys: Transaction[] = [
    {
      id: 'LOT-1',
      date: '2024-10-01',
      symbol: 'A',
      qty: 1.0,
      price: 100.0,
      gross: 100.0,
      comm: 0,
      vat: 0,
      net: 100.0,
      type: 'BUY',
      exchange: 'IBKR',
      originalCurrency: 'THB',
      originalNet: '100.00',
      fxRate: '1.00',
      netTHB: '100.00',
    },
    {
      id: 'LOT-7',
      date: '2024-10-07',
      symbol: 'A',
      qty: 1.0,
      price: 100.0,
      gross: 100.0,
      comm: 0.3271,
      vat: 0.0229,
      net: 100.35,
      type: 'BUY',
      exchange: 'IBKR',
      originalCurrency: 'THB',
      originalNet: '100.35',
      fxRate: '1.00',
      netTHB: '100.35',
    },
    {
      id: 'LOT-9',
      date: '2024-10-09',
      symbol: 'A',
      qty: 1.0,
      price: 100.0,
      gross: 100.0,
      comm: 0.3271,
      vat: 0.0229,
      net: 100.35,
      type: 'BUY',
      exchange: 'IBKR',
      originalCurrency: 'THB',
      originalNet: '100.35',
      fxRate: '1.00',
      netTHB: '100.35',
    },
  ];

  const baselineSells: Transaction[] = [
    {
      id: 'SELL-1',
      date: '2024-10-01',
      symbol: 'A',
      qty: 3.0,
      price: 109.0,
      gross: 327.0,
      comm: 1.2056,
      vat: 0.0844,
      net: 325.71,
      type: 'SELL',
      exchange: 'IBKR',
      originalCurrency: 'THB',
      originalNet: '325.71',
      fxRate: '1.00',
      netTHB: '325.71',
    },
  ];

  const dividendCSV = `
    Date,Symbol,Qty,Div/Share,Gross,Tax,Net
    2024-10-15,A,3,1.02,3.06,0.93,2.13
  `;

  const fifoResult = calculateFIFO(baselineBuys, baselineSells, { A: 20.0 });
  const fxProvider = new MockFXRateProvider();
  const dividends = await enrichDividendsWithFX(
    parseDividends(dividendCSV),
    fxProvider,
    BASE_CURRENCY
  );

  const taxReport = calculateThaiTax(fifoResult, dividends, 2024, {
    generatedAt: '2026-10-26T12:00:00.000Z',
  });

  const outputPath = path.resolve(
    __dirname,
    '../../reports/FIFO_Wealth_OS_Tax_Report_2024.pdf'
  );

  const pdfMeta = await generateTaxReportPDF(taxReport, outputPath, {
    taxpayerName: 'คุณสมชาย นักลงทุนมั่งคั่ง (Somchai Wealth)',
    taxpayerTaxId: '1-1005-00999-88-7',
  });

  // eslint-disable-next-line no-console
  console.log(JSON.stringify({ taxReport, pdfMeta }, null, 2));
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});
