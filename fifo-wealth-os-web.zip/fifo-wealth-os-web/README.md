# FIFO Wealth OS Monorepo

Turborepo/npm-workspace repository for the existing FIFO Wealth OS API, Next.js web app, shared TypeScript packages, and Expo mobile client. The backend and canonical financial/tax engines remain at the repository root; web and mobile use shared contracts/utilities rather than duplicating calculation logic.

## Repository layout

```text
.
├── src/                    # Existing API, Prisma services, FIFO and Thai tax engines
├── prisma/                 # Existing SQLite schema and migrations
├── apps/
│   ├── web/                # Next.js application (@fifo/web)
│   └── mobile/             # Expo Router / React Native application (@fifo/mobile)
└── packages/
    ├── types/              # @fifo/types — Unified CDM, asset and API contracts
    ├── utils/              # @fifo/utils — Decimal.js wrappers and shared formatters
    └── api/                # @fifo/api — endpoint constants and authenticated Axios client
```

The root npm workspace globs are `apps/*` and `packages/*`. Turborepo coordinates shared-package builds and the workspace `build`, `typecheck`, `lint`, `test`, and `dev` tasks. Keep the root `package-lock.json` as the single dependency lockfile; do not install dependencies separately inside an app.

## Requirements and install

- Node.js **20.19+** and npm **10.8+**.
- SQLite/Prisma remains the validated backend database. A database-provider or financial-engine migration is out of scope.

```bash
npm ci
npx prisma generate
cp .env.example .env
```

Replace the placeholder `JWT_SECRET` and `ENCRYPTION_KEY` before using the API outside local development. Keep them on the server; neither key belongs in the mobile bundle or any `EXPO_PUBLIC_*` variable. For Docker Compose, the required secrets must also be present in the environment or `.env` file.

## Common commands

Run from the repository root:

| Command | Purpose |
|---|---|
| `npm run dev:api` | Build shared packages, then watch/run the existing API on port 3000 |
| `npm run dev --workspace=@fifo/web` | Start Next.js on port 3001 |
| `npm run start --workspace=@fifo/mobile` | Start Expo with a development client |
| `npm run start:go --workspace=@fifo/mobile` | Start Expo Go for limited UI inspection (no SQLCipher cache) |
| `npm run build:shared` | Build `@fifo/types`, `@fifo/utils`, and `@fifo/api` |
| `npm run typecheck` | Build shared packages and strictly typecheck the root backend |
| `npm run lint` | Root typecheck plus Turbo workspace lint/type checks |
| `npm test -- --runInBand` | Run the existing root/backend Jest suite |
| `npm run test:all` | Root, web Playwright, and mobile Jest tests in sequence |
| `npm run build` | Build the root backend |
| `npm run build:all` | Build the root backend and every workspace sequentially |
| `npm run build:check` | Run typecheck, lint, tests, and monorepo builds |

Web workspace checks can be run with `npm run typecheck --workspace=@fifo/web`, `npm run lint --workspace=@fifo/web`, `npm test --workspace=@fifo/web`, and `npm run build --workspace=@fifo/web`.

## Mobile setup

Configure the API URL in `apps/mobile/.env` (start with `apps/mobile/.env.example`). Examples ending in `/api`:

- Android emulator: `http://10.0.2.2:3000/api`
- iOS simulator: `http://127.0.0.1:3000/api`
- Physical device: the development computer's LAN IP
- EAS preview/production: an HTTPS API URL

Set `EXPO_PUBLIC_WEB_URL` to the HTTPS web-app origin (not `/api` and no locale path) for EAS preview/production. Advanced Assets opens the web app's default Thai-locale route at `/th/advanced-assets`; the Expo config requires this origin for non-development builds.

Run mobile checks from the root with:

```bash
npm run typecheck --workspace=@fifo/mobile
npm run lint --workspace=@fifo/mobile
npm test --workspace=@fifo/mobile -- --runInBand
(cd apps/mobile && npx expo export --platform android --platform ios --output-dir /tmp/fifo-mobile-export)
```

The app uses Expo Router with auth flows plus Home, Portfolios, Advanced Assets, and Profile tabs; Activity and Tax remain accessible as routed screens. Profile links to a separate NativeWind Hello World verification route and shows existing broker statuses, last-sync times, and available sync/disconnect actions. Advanced Assets has visibly labeled sample-only metric cards and does not call calculator routes; View on Web uses the configured `EXPO_PUBLIC_WEB_URL`. Portfolio detail includes a refreshable server ledger and separately marks queued Quick Add entries as local-only. NativeWind provides a persisted System/Light/Dark theme selector and the requested `#14342A` / `#FAFAFA` / `#121212` palette, while preserving FIFO dark red for negative/loss indicators. SecureStore holds issued session tokens and local secret material; local authentication enables optional biometric unlock; TanStack Query and SQLCipher-backed SQLite support offline snapshots. Home Quick Add validates decimal strings and stores pending trades in the encrypted local queue, but the current backend has no `POST /api/transactions`; these entries remain local-only and are excluded from server totals until an approved create route exists. Expo Go does not include the configured SQLCipher build; use a custom development/production client to validate encrypted offline storage and native features. Broker credentials are sent to the backend's existing encryption contract and are not stored in the app cache. The app does not contain the backend JWT signing secret.

More mobile-specific requirements, EAS setup, limitations, and device test guidance are in [`apps/mobile/README-MOBILE.md`](apps/mobile/README-MOBILE.md). The latest QA score, safe fixes, manual-review items, and check results are in [`apps/mobile/MOBILE-QA-REPORT.md`](apps/mobile/MOBILE-QA-REPORT.md).

## Build and deployment

- `docker compose up --build` builds the root API and `apps/web` frontend from the monorepo root. Set the required server secrets first. The API/SQLite volume is retained under the existing Compose volume name.
- `.github/workflows/ci.yml` validates backend, web, and mobile workspaces; `.github/workflows/deploy.yml` contains deployment workflows.
- Build production native artifacts with EAS from `apps/mobile`; review app identifiers, EAS project linkage, signing, privacy disclosures, and permission copy before store submission.

## Validation snapshot

The latest M4 validation passes **371 backend tests**, **14 web Playwright tests**, **35 mobile Jest tests across nine suites** (all 28 earlier mobile tests remain passing), mobile typecheck/lint, `npm run test:all`, `npm run build:all`, and Android/iOS JavaScript export. The Advanced Assets path and `Linking.openURL` call are unit-tested; the live web origin remains deployment configuration. `npx expo install --check` may report a monorepo root-resolution mismatch for Jest/TypeScript even though the mobile workspace's installed versions match its manifest. These checks are not substitutes for native device E2E testing or store-release review.

Known follow-ups: `npm audit` currently reports 19 advisories overall (3 high), Expo Doctor reports the documented SDK 56 Hermes V1 issue, and device-level SQLCipher/biometric/notification/PDF tests remain pending. A clean manifest-only install with `npm ci --ignore-scripts` passed (1,833 packages) and confirmed React 19.2.3 deduplication; a full script-enabled install retry exited `-1` during reification under sandbox limits. Docker is unavailable here, so the hosted CI workflow still needs to confirm full install and image builds.
