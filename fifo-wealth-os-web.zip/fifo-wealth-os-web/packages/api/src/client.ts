import axios, {
  type AxiosError,
  type AxiosInstance,
  type CreateAxiosDefaults,
  type InternalAxiosRequestConfig,
} from 'axios';

export type AccessTokenProvider = () => Promise<string | null>;
export type UnauthorizedHandler = () => void | Promise<void>;

export interface AuthenticatedApiClientOptions {
  baseURL: string;
  timeoutMs: number;
  getAccessToken: AccessTokenProvider;
  headers?: CreateAxiosDefaults['headers'];
}

export interface AuthenticatedApiClient {
  client: AxiosInstance;
  registerUnauthorizedHandler: (handler: UnauthorizedHandler) => () => void;
}

/** Creates an Axios client that attaches issued access tokens and signals authenticated 401s. */
export function createAuthenticatedApiClient(
  options: AuthenticatedApiClientOptions,
): AuthenticatedApiClient {
  const client = axios.create({
    baseURL: options.baseURL,
    timeout: options.timeoutMs,
    headers: options.headers ?? { Accept: 'application/json' },
  });

  let unauthorizedHandler: UnauthorizedHandler | null = null;

  const registerUnauthorizedHandler = (handler: UnauthorizedHandler): (() => void) => {
    unauthorizedHandler = handler;
    return () => {
      if (unauthorizedHandler === handler) unauthorizedHandler = null;
    };
  };

  client.interceptors.request.use(async (config: InternalAxiosRequestConfig) => {
    const token = await options.getAccessToken();
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  });

  client.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
      const requestHadBearer = Boolean(error.config?.headers?.Authorization);
      if (error.response?.status === 401 && requestHadBearer && unauthorizedHandler) {
        await unauthorizedHandler();
      }
      return Promise.reject(error);
    },
  );

  return { client, registerUnauthorizedHandler };
}
