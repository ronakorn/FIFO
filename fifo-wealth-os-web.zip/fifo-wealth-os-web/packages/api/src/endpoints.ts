type ThaiBrokerCode = 'BITKUB' | 'DIME' | 'STREAMING';

/**
 * Relative API paths shared by the web and native clients. The client base URL
 * already includes the API prefix (or a same-origin /api rewrite).
 */
export const API_ENDPOINTS = {
  health: '/health',
  auth: {
    login: '/auth/login',
    register: '/auth/register',
    me: '/auth/me',
  },
  portfolios: {
    collection: '/portfolios',
  },
  mobile: {
    dashboardSummary: '/mobile/dashboard-summary',
    transactions: (portfolioId: string): string =>
      `/mobile/transactions/${encodeURIComponent(portfolioId)}`,
  },
  analytics: {
    dashboard: '/analytics/dashboard',
  },
  tax: {
    summary: (portfolioId: string, year: number): string =>
      `/tax/summary/${encodeURIComponent(portfolioId)}/${year}`,
    report: (portfolioId: string, year: number): string =>
      `/tax/report/${encodeURIComponent(portfolioId)}/${year}`,
  },
  sync: {
    status: '/sync/status',
    ibkrConnect: '/sync/ibkr/connect',
    ibkrDisconnect: '/sync/ibkr/disconnect',
    ibkrTrigger: '/sync/ibkr/trigger',
  },
  thaiBrokers: {
    status: '/thai-brokers/status',
    connect: (broker: ThaiBrokerCode): string => `/thai-brokers/${broker}/connect`,
    sync: (broker: ThaiBrokerCode): string => `/thai-brokers/${broker}/sync`,
    disconnect: (broker: ThaiBrokerCode): string => `/thai-brokers/${broker}/disconnect`,
  },
} as const;

export type ApiEndpointSet = typeof API_ENDPOINTS;
