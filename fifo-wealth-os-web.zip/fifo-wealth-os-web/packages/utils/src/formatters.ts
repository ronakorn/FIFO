import { FinancialDecimal } from './decimal';

function groupInteger(integer: string): string {
  const sign = integer.startsWith('-') ? '-' : '';
  const digits = sign ? integer.slice(1) : integer;
  return `${sign}${digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}`;
}

export function formatThb(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === '') return '—';
  try {
    const [integer = '0', fraction = '00'] = new FinancialDecimal(value).toFixed(2).split('.');
    return `฿${groupInteger(integer)}.${fraction}`;
  } catch {
    return '—';
  }
}

export function formatNumber(value: string | number | null | undefined, decimals = 2): string {
  if (value === null || value === undefined || value === '') return '—';
  try {
    const [integer = '0', fraction] = new FinancialDecimal(value).toFixed(decimals).split('.');
    return fraction === undefined ? groupInteger(integer) : `${groupInteger(integer)}.${fraction}`;
  } catch {
    return '—';
  }
}

export function formatPercentRatio(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === '') return '—';
  try {
    return `${new FinancialDecimal(value).times(100).toFixed(2)}%`;
  } catch {
    return '—';
  }
}

export function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export function formatDateTime(value: string | number | Date): string {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat(undefined, {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

export function toChartNumber(value: string | number): number {
  const parsed = new FinancialDecimal(value).toNumber();
  return Number.isFinite(parsed) ? parsed : 0;
}
