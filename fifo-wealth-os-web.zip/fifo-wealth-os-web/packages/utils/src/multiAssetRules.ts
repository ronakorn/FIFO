/**
 * Multi-Asset Business Rules & Tax Regulations
 * กำหนดกฎเกณฑ์ทางบัญชีและภาษีสำหรับสินทรัพย์แต่ละประเภท
 */

import { FinancialDecimal } from './decimal';

const FinDecimal = FinancialDecimal;

// ============================================================================
// 1. BOND RULES (กฎสำหรับตราสารหนี้)
// ============================================================================
export const BOND_RULES = {
  // อัตราภาษีหัก ณ ที่จ่ายสำหรับดอกเบี้ยพันธบัตร
  withholdingTaxRate: new FinDecimal('0.15'), // 15%
  
  // Day Count Conventions
  dayCountConventions: {
    '30/360': (days: number) => days,
    'ACT/365': (days: number) => days,
    'ACT/ACT': (days: number) => days,
  },
  
  // คำนวณดอกเบี้ยค้างรับ (Accrued Interest)
  calculateAccruedInterest: (
    faceValue: string,
    couponRate: string,
    daysSinceLastCoupon: number,
    daysInYear: number = 365
  ): string => {
    const fv = new FinDecimal(faceValue);
    const rate = new FinDecimal(couponRate);
    const days = new FinDecimal(daysSinceLastCoupon);
    const year = new FinDecimal(daysInYear);
    
    return fv.times(rate).times(days).dividedBy(year).toFixed(2, FinancialDecimal.ROUND_HALF_UP);
  },
};

// ============================================================================
// 2. FUND RULES (กฎสำหรับกองทุนรวม)
// ============================================================================
export const FUND_RULES = {
  // ระยะเวลาถือครองขั้นต่ำสำหรับกองทุนลดหย่อนภาษี
  holdingPeriodRequirements: {
    'SSF': 365 * 10,      // 10 ปี
    'RMF': 365 * 5,       // 5 ปี (และอายุ 55 ปี)
    'THAI_ESG': 365 * 8,  // 8 ปี
  },
  
  // วงเงินลดหย่อนภาษีสูงสุดต่อปี
  taxDeductionLimits: {
    'SSF': new FinDecimal('200000'),      // 200,000 THB
    'RMF': new FinDecimal('500000'),      // 500,000 THB หรือ 30% ของรายได้
    'THAI_ESG': new FinDecimal('300000'), // 300,000 THB
  },
  
  // ตรวจสอบว่าถือครองครบกำหนดหรือไม่
  validateHoldingPeriod: (
    purchaseDate: string,
    saleDate: string,
    fundType: 'SSF' | 'RMF' | 'THAI_ESG'
  ): { isValid: boolean; requiredDays: number; actualDays: number } => {
    const requiredDays = FUND_RULES.holdingPeriodRequirements[fundType];
    const purchase = new Date(purchaseDate);
    const sale = new Date(saleDate);
    const actualDays = Math.floor((sale.getTime() - purchase.getTime()) / (1000 * 60 * 60 * 24));
    
    return {
      isValid: actualDays >= requiredDays,
      requiredDays,
      actualDays,
    };
  },
};

// ============================================================================
// 3. COMMODITY RULES (กฎสำหรับสินค้าโภคภัณฑ์)
// ============================================================================
export const COMMODITY_RULES = {
  // มาตรฐานน้ำหนักและความบริสุทธิ์
  standards: {
    GOLD: {
      purity: '96.5',
      weightUnit: 'THAI_BAHT',
      gramsPerUnit: 15.244,
    },
    SILVER: {
      purity: '99.9',
      weightUnit: 'TROY_OUNCE',
      gramsPerUnit: 31.1034768,
    },
    PLATINUM: {
      purity: '99.95',
      weightUnit: 'TROY_OUNCE',
      gramsPerUnit: 31.1034768,
    },
  },
  
  // คำนวณต้นทุนรวม (รวมค่าพรีเมียมและค่าเก็บรักษา)
  calculateTotalCost: (
    spotPrice: string,
    premium: string,
    storageFee: string,
    weight: string
  ): string => {
    const spot = new FinDecimal(spotPrice);
    const prem = new FinDecimal(premium);
    const storage = new FinDecimal(storageFee);
    const w = new FinDecimal(weight);
    
    return spot.plus(prem).times(w).plus(storage).toFixed(2, FinancialDecimal.ROUND_HALF_UP);
  },
};

// ============================================================================
// 4. FOREX RULES (กฎสำหรับเงินตราต่างประเทศ)
// ============================================================================
export const FOREX_RULES = {
  // คำนวณ Realized FX Gain/Loss
  calculateRealizedFxGainLoss: (
    amount: string,
    fxRateAtPurchase: string,
    fxRateAtTransaction: string
  ): string => {
    const amt = new FinDecimal(amount);
    const ratePurchase = new FinDecimal(fxRateAtPurchase);
    const rateTransaction = new FinDecimal(fxRateAtTransaction);
    
    const costBasisTHB = amt.times(ratePurchase);
    const proceedsTHB = amt.times(rateTransaction);
    const fxGainLoss = proceedsTHB.minus(costBasisTHB);
    
    return fxGainLoss.toFixed(2, FinancialDecimal.ROUND_HALF_UP);
  },
};

// ============================================================================
// 5. TAX TREATMENT SUMMARY (สรุปการปฏิบัติทางภาษี)
// ============================================================================
export const TAX_TREATMENT = {
  EQUITY: {
    capitalGainsTax: 'EXEMPT_TH', // หุ้นไทยยกเว้นภาษี
    dividendTax: '10% WHT',
  },
  BOND: {
    interestIncomeTax: '15% WHT',
    capitalGainsTax: '15% WHT',
  },
  FUND: {
    capitalGainsTax: 'EXEMPT_IF_HOLDING_PERIOD_MET',
    dividendTax: '10% WHT',
    taxDeduction: 'SSF/RMF/ThaiESG eligible',
  },
  COMMODITY: {
    capitalGainsTax: 'EXEMPT_PHYSICAL_GOLD_TH',
    futuresTax: '15% WHT',
  },
  FOREX: {
    realizedFxGainLoss: 'TAXABLE_AS_INCOME',
  },
  OPTION: {
    premiumTax: '15% WHT',
    capitalGainsTax: '15% WHT',
  },
  REIT: {
    distributionTax: '10% WHT',
    capitalGainsTax: 'EXEMPT_TH',
  },
};
