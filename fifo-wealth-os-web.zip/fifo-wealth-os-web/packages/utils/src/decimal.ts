import Decimal from 'decimal.js';

/**
 * Shared high-precision Decimal constructor for client-side calculations.
 * Values remain Decimal instances; convert to strings only at API/presentation boundaries.
 */
export const FinancialDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type FinancialDecimalValue = Decimal.Value;
export type FinancialDecimalInstance = InstanceType<typeof FinancialDecimal>;

export function decimal40(value: FinancialDecimalValue = 0): FinancialDecimalInstance {
  return new FinancialDecimal(value);
}
