import Decimal from 'decimal.js';
import type {
  AssetClass,
  MultiAssetTransaction,
  OptionExtension as CoreOptionExtension,
  REITExtension as CoreREITExtension,
} from './multiAsset';

/** Financial arithmetic for advanced-asset helpers is configured to 40 significant digits. */
export const AdvancedAssetDecimal = Decimal.clone({
  precision: 40,
  rounding: Decimal.ROUND_HALF_UP,
});

export type OptionStyle = 'AMERICAN' | 'EUROPEAN' | 'BERMUDAN';
export type OptionMoneyness = 'ITM' | 'ATM' | 'OTM';
export type OptionUnderlyingAssetClass = 'EQUITY' | 'INDEX' | 'COMMODITY' | 'FOREX';
export type OptionExerciseStyle = 'PHYSICAL' | 'CASH';

/** Additive Option extension: remains structurally compatible with the original protected CDM extension. */
export interface OptionExtension extends CoreOptionExtension {
  optionStyle: OptionStyle;
  underlyingAssetClass: OptionUnderlyingAssetClass;
  contractSize: number;
  multiplier?: string;
  exerciseStyle?: OptionExerciseStyle;
  greeks?: {
    delta: string;
    gamma: string;
    theta: string;
    vega: string;
    rho: string;
    impliedVolatility: string;
  };
  exercised?: boolean;
  assigned?: boolean;
  exerciseDate?: string;
}

export type PropertyType =
  | 'OFFICE'
  | 'RETAIL'
  | 'INDUSTRIAL'
  | 'RESIDENTIAL'
  | 'HOSPITALITY'
  | 'DATA_CENTER'
  | 'LOGISTICS'
  | 'MIXED';
export type REITStructure = 'EQUITY_REIT' | 'MORTGAGE_REIT' | 'HYBRID_REIT';
export type REITDistributionFrequency = 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL';

/** Widened REIT details are kept in the advanced payload, leaving the original Core REITExtension unchanged. */
export type REITExtension = Omit<CoreREITExtension, 'propertyType'> & {
  structure: REITStructure;
  propertyType: PropertyType;
  distributionYield: string;
  distributionFrequency: REITDistributionFrequency;
  navPerUnit: string;
  lastDistributionPerUnit: string;
  lastDistributionDate?: string;
  managementFee?: string;
  occupancyRate?: string;
  geographicFocus?: string;
};

export type PEStage = 'VENTURE' | 'GROWTH' | 'BUYOUT' | 'MEZZANINE' | 'DISTRESSED';
export type PEStatus = 'COMMITTED' | 'CALLED' | 'INVESTED' | 'DISTRIBUTED' | 'WRITTEN_OFF';

export interface PrivateEquityExtension {
  stage: PEStage;
  status: PEStatus;
  committedCapital: string;
  calledCapital: string;
  investedCapital: string;
  distributedCapital: string;
  residualValue: string;
  tvpi?: string;
  dpi?: string;
  rvpi?: string;
  irr?: string;
  moic?: string;
  fundName?: string;
  fundVintage?: number;
  managementFee?: string;
  carriedInterest?: string;
  investmentDate?: string;
  expectedExitDate?: string;
}

export type FuturesSide = 'LONG' | 'SHORT';
export type FuturesStatus = 'OPEN' | 'CLOSED' | 'EXPIRED' | 'DELIVERED';
export type FuturesDeliveryMethod = 'CASH' | 'PHYSICAL';

export interface FuturesExtension {
  side: FuturesSide;
  status: FuturesStatus;
  contractMonth: string;
  contractSize: number;
  multiplier: string;
  /** Per-contract initial margin in THB. */
  initialMargin: string;
  /** Per-contract maintenance margin in THB. */
  maintenanceMargin: string;
  settlementPrice?: string;
  markToMarket?: string;
  variationMargin?: string;
  deliveryMethod?: FuturesDeliveryMethod;
  underlyingIndex?: string;
  rolloverGroupId?: string;
  rolloverFee?: string;
}

/**
 * Advanced CDM wrapper. The base transaction is not rewritten; advanced-only extensions live beside it.
 * Futures is an additive AssetClass union member, while its extension remains outside MultiAssetTransaction.
 */
export type AdvancedTransaction = Omit<
  MultiAssetTransaction,
  'optionExtension' | 'reitExtension'
> & {
  assetClass: AssetClass;
  optionExtension?: OptionExtension;
  reitExtension?: REITExtension;
  privateEquityExtension?: PrivateEquityExtension;
  futuresExtension?: FuturesExtension;
};

export interface PECashFlow {
  date: string;
  amount: string;
  type: 'CALL' | 'DISTRIBUTION' | 'FEE' | 'WRITE_OFF';
}

export interface PEPerformanceMetrics {
  tvpi: string;
  dpi: string;
  rvpi: string;
  moic: string;
  irr: string;
  paidInCapital: string;
  totalDistributions: string;
  residualValue: string;
  committedCapital: string;
  uncalledCapital: string;
}
