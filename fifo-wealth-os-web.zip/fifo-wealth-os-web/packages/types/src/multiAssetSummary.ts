import type { FundExtension, MultiAssetLot } from './multiAsset';

/** Public response contract returned by the backend's existing multi-asset summary. */
export interface BondCouponPayment {
  date: string;
  grossTHB: string;
  withholdingTaxTHB: string;
  netTHB: string;
}

export interface BondPositionSummary {
  symbol: string;
  issuer: string | null;
  creditRating: string | null;
  quantity: string;
  costBasisTHB: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
  accruedInterestPerBondTHB: string;
  accruedInterestTotalTHB: string;
  yieldToMaturity: string | null;
  nextCouponDate: string | null;
  couponSchedule: BondCouponPayment[];
}

export interface BondPortfolioSummary {
  positions: BondPositionSummary[];
  lots: MultiAssetLot[];
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
  totalAccruedInterestTHB: string;
  couponIncomeTHB: string;
  couponWithholdingTaxTHB: string;
  upcomingCoupons: Array<BondCouponPayment & { symbol: string }>;
}

export interface FundLotStatus {
  transactionId: string;
  symbol: string;
  fundType: FundExtension['fundType'];
  purchaseDate: string;
  quantityRemaining: string;
  holdingPeriodDays: number;
  requiredHoldingPeriodDays: number;
  holdingPeriodComplete: boolean;
  ageAtAsOf: number | null;
  ageConditionMet: boolean | null;
  ageEligibleDate: string | null;
  taxDeductible: boolean;
  dividendPolicy: FundExtension['dividendPolicy'];
}

export interface FundRedemptionCheck {
  transactionId: string;
  symbol: string;
  fundType: FundExtension['fundType'];
  saleDate: string;
  purchaseDate: string;
  quantitySold: string;
  actualHoldingDays: number;
  requiredHoldingDays: number;
  holdingPeriodMet: boolean;
  ageAtSale: number | null;
  ageConditionMet: boolean | null;
  ageEligibleDate: string | null;
}

export type TaxDeductibleFundType = 'SSF' | 'RMF' | 'THAI_ESG';

export interface FundTaxDeductionSummary {
  taxYear: number;
  annualIncomeTHB: string | null;
  contributionsTHB: Record<TaxDeductibleFundType, string>;
  configuredLimitsTHB: Record<TaxDeductibleFundType, string>;
  appliedLimitsTHB: Record<TaxDeductibleFundType, string>;
  eligibleDeductionTHB: Record<TaxDeductibleFundType, string>;
  remainingLimitTHB: Record<TaxDeductibleFundType, string>;
  totalEligibleDeductionTHB: string;
  note: string;
}

export interface FundPosition {
  symbol: string;
  fundType: FundExtension['fundType'];
  quantity: string;
  costBasisTHB: string;
  navPerUnit: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
  dividendPolicy: FundExtension['dividendPolicy'];
  reinvestedDividendUnits: string;
}

export interface FundPortfolioSummary {
  positions: FundPosition[];
  holdingLots: FundLotStatus[];
  redemptionChecks: FundRedemptionCheck[];
  rmfAgeCondition: {
    ageAtAsOf: number;
    isEligible: boolean;
    ageEligibleDate: string;
  } | null;
  taxDeduction: FundTaxDeductionSummary;
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
  cashDividendsTHB: string;
  dripReinvestedUnits: string;
}

export type MetalGroup = 'GOLD' | 'SILVER' | 'PLATINUM' | 'OTHER';

export interface CommodityPosition {
  symbol: string;
  metal: MetalGroup;
  weightGrams: string;
  fineWeightGrams: string;
  costBasisTHB: string;
  spotPricePerGramTHB: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
  purity: string | null;
}

export interface MultiMetalDashboardRow {
  metal: MetalGroup;
  positionCount: number;
  weightGrams: string;
  fineWeightGrams: string;
  costBasisTHB: string;
  marketValueTHB: string;
  realizedGLTHB: string;
  unrealizedGLTHB: string;
}

export interface CommodityPortfolioSummary {
  positions: CommodityPosition[];
  lots: MultiAssetLot[];
  multiMetalDashboard: MultiMetalDashboardRow[];
  totalWeightGrams: string;
  totalFineWeightGrams: string;
  totalCostBasisTHB: string;
  totalMarketValueTHB: string;
  totalRealizedGLTHB: string;
  totalUnrealizedGLTHB: string;
}

export interface ForexCurrencyBalance {
  currency: string;
  amount: string;
  costBasisTHB: string;
  averageCostRateTHB: string;
  currentRateTHB: string;
  currentValueTHB: string;
  unrealizedFxGainLossTHB: string;
}

export interface RealizedFxEvent {
  transactionId: string;
  currency: string;
  amountDisposed: string;
  proceedsTHB: string;
  costBasisTHB: string;
  averageCostBasisTHB: string;
  realizedFxGainLossTHB: string;
}

export interface ForexPortfolioSummary {
  balances: ForexCurrencyBalance[];
  realizedEvents: RealizedFxEvent[];
  totalCashValueTHB: string;
  totalCostBasisTHB: string;
  totalRealizedFxGainLossTHB: string;
  totalUnrealizedFxGainLossTHB: string;
}

export interface MultiAssetPortfolioSummary {
  asOfDate: string;
  taxYear: number;
  bonds: BondPortfolioSummary;
  funds: FundPortfolioSummary;
  commodities: CommodityPortfolioSummary;
  forex: ForexPortfolioSummary;
}
