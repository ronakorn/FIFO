/** Portfolio contract used by the authenticated mobile dashboard and portfolio endpoints. */
export interface FifoLot {
  id: string;
  date: string;
  symbol: string;
  buyQty: number;
  costPerUnit: number;
  qtySold: number;
  qtyRemain: number;
  realizedGL: number;
  unrealizedGL: number;
  status: 'Hold' | 'Partial' | 'Sold';
}

export interface PortfolioFifoSummary {
  totalRealizedGL: number;
  totalUnrealizedGL: number;
  totalCostSold: number;
  totalProceeds: number;
  openCostBasisTHB: number;
  marketValueTHB: number;
  lots: FifoLot[];
}

export interface Portfolio {
  id: string;
  userId: string;
  name: string;
  baseCurrency: string;
  createdAt: string;
  transactionCount?: number;
  dividendCount?: number;
  fifoSummary?: PortfolioFifoSummary;
}

export type ManualTransactionSide = 'BUY' | 'SELL';

/** Client-side manual trade draft. Decimal values remain strings to avoid binary rounding. */
export interface ManualTransactionDraft {
  portfolioId: string;
  symbol: string;
  type: ManualTransactionSide;
  qty: string;
  price: string;
  /** Local calendar date in YYYY-MM-DD form. */
  date: string;
}

/** Encrypted local queue item; this is not a server-confirmed transaction. */
export interface PendingManualTransaction extends ManualTransactionDraft {
  id: string;
  createdAt: string;
  syncStatus: 'queued';
}

export type BrokerSyncStatus = 'CONNECTED' | 'SYNCING' | 'ERROR' | 'DISCONNECTED';

export interface IbkrConnection {
  id: string | null;
  brokerName: 'IBKR';
  flexQueryId: string | null;
  portfolioId: string | null;
  status: BrokerSyncStatus;
  connected: boolean;
  lastSyncedAt: string | null;
  createdAt: string | null;
  readOnly: true;
  encryption: 'AES-256-GCM';
}

export type ThaiBrokerId = 'BITKUB' | 'DIME' | 'STREAMING';

export type ThaiBrokerConnectionMode =
  | 'READ_ONLY_API'
  | 'OPEN_API_HYBRID'
  | 'SECURE_STATEMENT_AUTOMATION';

export type ThaiBrokerDataSource = 'NOT_TESTED' | 'SANDBOX_MOCK' | 'LIVE_PARTNER_API';

export interface ThaiBrokerConnection {
  id: string | null;
  broker: ThaiBrokerId;
  displayName: string;
  regulatoryBadge: string;
  partnerBadge: 'Official Partner Integration Ready';
  connectionMode: ThaiBrokerConnectionMode;
  dataSource: ThaiBrokerDataSource;
  maskedAccountRef: string | null;
  portfolioId: string | null;
  status: BrokerSyncStatus;
  connected: boolean;
  readOnly: true;
  encryption: 'AES-256-GCM';
  pdpaConsented: boolean;
  pdpaConsentedAt: string | null;
  pdpaConsentVersion: string | null;
  lastSyncedAt: string | null;
  futureRoadmapNote: string | null;
}

export interface ThaiBrokerStatusResponse {
  connections: ThaiBrokerConnection[];
  currentConsentVersion?: string;
  hubBadge?: string;
  regulatoryFramework?: string;
  streamingRoadmapNotice?: string;
}

export interface ThaiBrokerSyncResult {
  broker: ThaiBrokerId;
  connectionMode: ThaiBrokerConnectionMode;
  dataSource: ThaiBrokerDataSource;
  portfolioId: string;
  addedTransactions: number;
  addedDividends: number;
  skippedTransactions: number;
  skippedDividends: number;
  status: BrokerSyncStatus;
  lastSyncedAt: string;
}

export type AdvancedAssetSampleId = 'options' | 'reits' | 'private-equity' | 'futures';
export type AdvancedAssetMetricFormat = 'signed-decimal' | 'percent-ratio' | 'multiple';

/** Clearly illustrative data only; this must not be presented as account-derived metrics. */
export interface AdvancedAssetSampleSummary {
  id: AdvancedAssetSampleId;
  title: string;
  metricLabel: string;
  value: string;
  metricFormat: AdvancedAssetMetricFormat;
  detail: string;
  tone: 'positive' | 'warning' | 'neutral';
  isSample: true;
}
