/**
 * FIFO Wealth OS - Multi-Asset Canonical Data Model (CDM)
 * Version: 1.0.0
 * 
 * หลักการออกแบบ:
 * 1. BaseTransaction = โครงสร้างพื้นฐานที่ใช้ร่วมกันทุกสินทรัพย์
 * 2. Asset-Specific Extensions = ฟิลด์เพิ่มเติมเฉพาะสินทรัพย์แต่ละประเภท
 * 3. Unified Transaction = รวม Base + Extensions เข้าด้วยกัน
 * 4. ห้ามแก้ไข Core Types เดิม (Transaction, Lot, Dividend) ใน shared.ts
 */

// ============================================================================
// 1. ASSET CLASS ENUM (ประเภทสินทรัพย์ทั้งหมด)
// ============================================================================
export type AssetClass = 
  | 'EQUITY'           // หุ้นสามัญ
  | 'BOND'             // พันธบัตร, หุ้นกู้
  | 'FUND'             // กองทุนรวม, ETF
  | 'COMMODITY'        // ทองคำ, เงิน, สินค้าโภคภัณฑ์
  | 'FOREX'            // เงินตราต่างประเทศ
  | 'OPTION'           // Options, Warrants
  | 'REIT'             // กองทุนอสังหาริมทรัพย์
  | 'PRIVATE_EQUITY'   // Private Equity, Venture Capital
  | 'FUTURES';         // Futures and forwards (extension payload lives outside the base CDM)

// ============================================================================
// 2. BASE TRANSACTION (โครงสร้างพื้นฐาน - ใช้ร่วมกันทุกสินทรัพย์)
// ============================================================================
export interface BaseTransaction {
  id: string;
  portfolioId: string;
  date: string;                    // ISO 8601 (YYYY-MM-DD)
  symbol: string;                  // เช่น 'AAPL', 'BOND-TH-2025', 'GOLD965'
  assetClass: AssetClass;
  type: 'BUY' | 'SELL' | 'DIVIDEND' | 'COUPON' | 'INTEREST' | 'FEE' | 'CONVERT';
  
  // จำนวนและราคา
  qty: number;                     // จำนวนหน่วย (หุ้น, พันธบัตร, ทองคำ)
  price: string;                   // ราคาต่อหน่วย (Decimal string)
  gross: string;                   // มูลค่ารวมก่อนค่าธรรมเนียม
  comm: string;                    // ค่าธรรมเนียม
  vat: string;                     // ภาษีมูลค่าเพิ่ม
  net: string;                     // มูลค่าสุทธิ (gross ± comm ± vat)
  
  // สกุลเงินและอัตราแลกเปลี่ยน
  originalCurrency: string;        // เช่น 'USD', 'THB', 'EUR'
  originalNet: string;             // มูลค่าสุทธิเป็นสกุลเดิม (Decimal string)
  fxRate: string | null;           // อัตราแลกเปลี่ยน ณ วันที่ทำรายการ
  netTHB: string | null;           // มูลค่าสุทธิเป็น THB (Decimal string)
  
  // Metadata
  exchange?: string;               // เช่น 'SET', 'NASDAQ', 'BITKUB'
  notes?: string;                  // หมายเหตุเพิ่มเติม
  createdAt: Date;
}

// ============================================================================
// 3. ASSET-SPECIFIC EXTENSIONS (ฟิลด์เพิ่มเติมเฉพาะสินทรัพย์)
// ============================================================================

// 3.1 Bond & Fixed Income Extension
export interface BondExtension {
  couponRate: string;              // อัตราดอกเบี้ยหน้าตั๋ว (เช่น "0.0500" = 5%)
  paymentFrequency: 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'ANNUAL';
  maturityDate: string;            // วันครบกำหนดไถ่ถอน (ISO 8601)
  faceValue: string;               // มูลค่าหน้าตั๋ว (Decimal string, THB)
  accruedInterest: string;         // ดอกเบี้ยค้างรับ (Decimal string, THB)
  yieldToMaturity?: string;        // YTM (Decimal string, เช่น "0.0450" = 4.5%)
  creditRating?: string;           // เช่น 'AAA', 'BBB+', 'NR'
  issuer?: string;                 // ชื่อผู้ออก (เช่น 'รัฐบาลไทย', 'PTT')
}

// 3.2 Mutual Fund & ETF Extension
export interface FundExtension {
  fundType: 'SSF' | 'RMF' | 'THAI_ESG' | 'GENERAL' | 'GLOBAL_ETF';
  holdingPeriodDays: number;       // จำนวนวันที่ถือครอง
  taxDeductible: boolean;          // สามารถลดหย่อนภาษีได้หรือไม่
  dividendPolicy: 'DRIP' | 'CASH_PAYOUT';  // นโยบายเงินปันผล
  navPerUnit: string;              // NAV ต่อหน่วย (Decimal string)
  managementFee?: string;          // ค่าธรรมเนียมการจัดการ (Decimal string)
  purchaseDate?: string;           // วันที่ซื้อครั้งแรก (สำหรับคำนวณ Holding Period)
}

// 3.3 Commodity Extension (Silver, Platinum, etc.)
export interface CommodityExtension {
  weight: string;                  // น้ำหนัก (Decimal string)
  weightUnit: 'TROY_OUNCE' | 'GRAM' | 'KILOGRAM' | 'THAI_BAHT';
  purity?: string;                 // ความบริสุทธิ์ (เช่น "99.9" สำหรับเงิน)
  storageFee: string;              // ค่าเก็บรักษา (Decimal string, THB)
  premium: string;                 // ค่าพรีเมียม (Decimal string, THB)
  spotPricePerUnit: string;        // ราคา Spot ต่อหน่วย (Decimal string)
}

// 3.4 Forex Extension
export interface ForexExtension {
  fromCurrency: string;            // สกุลเงินต้นทาง (เช่น 'USD')
  toCurrency: string;              // สกุลเงินปลายทาง (เช่น 'THB')
  fxRateAtTransaction: string;     // อัตราแลกเปลี่ยน ณ วันที่ทำรายการ
  realizedFxGainLoss: string;      // กำไร/ขาดทุนจากอัตราแลกเปลี่ยน (Decimal string, THB)
  avgCostBasisTHB?: string;        // ต้นทุนเฉลี่ยเป็น THB (สำหรับการคำนวณ FX Gain/Loss)
}

// 3.5 Option Extension (Warrants, CB, Options)
export interface OptionExtension {
  optionType: 'CALL' | 'PUT';
  strikePrice: string;             // ราคาใช้สิทธิ (Decimal string)
  expirationDate: string;          // วันหมดอายุ (ISO 8601)
  underlyingAsset: string;         // สินทรัพย์อ้างอิง (เช่น 'AAPL')
  premium: string;                 // ค่าพรีเมียมที่จ่าย/รับ (Decimal string)
  contractSize?: number;           // จำนวนหน่วยต่อสัญญา (เช่น 100 หุ้น)
  greeks?: {
    delta: string;
    gamma: string;
    theta: string;
    vega: string;
  };
}

// 3.6 REIT Extension
export interface REITExtension {
  propertyType: 'OFFICE' | 'RETAIL' | 'INDUSTRIAL' | 'RESIDENTIAL' | 'MIXED';
  distributionYield: string;       // อัตราผลตอบแทนจากการแจกจ่าย (Decimal string)
  navPerUnit: string;              // NAV ต่อหน่วย (Decimal string)
  managementFee?: string;          // ค่าธรรมเนียมการจัดการ
}

// ============================================================================
// 4. UNIFIED TRANSACTION (รวม Base + Extensions)
// ============================================================================
export interface MultiAssetTransaction extends BaseTransaction {
  // Extensions (Optional - ใช้เฉพาะสินทรัพย์ที่เกี่ยวข้อง)
  bondExtension?: BondExtension;
  fundExtension?: FundExtension;
  commodityExtension?: CommodityExtension;
  forexExtension?: ForexExtension;
  optionExtension?: OptionExtension;
  reitExtension?: REITExtension;
}

// ============================================================================
// 5. ASSET-SPECIFIC LOT (สำหรับ FIFO Tracking)
// ============================================================================
export interface MultiAssetLot {
  id: string;
  transactionId: string;
  symbol: string;
  assetClass: AssetClass;
  buyQty: number;
  costPerUnit: string;             // ต้นทุนต่อหน่วย (Decimal string)
  qtySold: number;
  qtyRemain: number;
  realizedGL: string;              // กำไร/ขาดทุนที่รับรู้แล้ว (Decimal string)
  unrealizedGL: string;            // กำไร/ขาดทุนที่ยังไม่รับรู้ (Decimal string)
  status: 'Hold' | 'Partial' | 'Sold';
  daysHeld: number;
  
  // Asset-Specific Lot Data
  bondLotData?: {
    faceValue: string;
    couponRate: string;
    maturityDate: string;
  };
  
  fundLotData?: {
    fundType: 'SSF' | 'RMF' | 'THAI_ESG' | 'GENERAL' | 'GLOBAL_ETF';
    purchaseDate: string;
    holdingPeriodDays: number;
  };
  
  commodityLotData?: {
    weight: string;
    weightUnit: string;
    purity?: string;
  };
}

// ============================================================================
// 6. UTILITY TYPES & HELPERS
// ============================================================================
export type AssetClassConfig = {
  [key in AssetClass]: {
    displayNameTH: string;
    displayNameEN: string;
    defaultCurrency: string;
    requiresExtension: boolean;
    extensionKey: keyof MultiAssetTransaction;
  };
};

export const ASSET_CLASS_CONFIG: AssetClassConfig = {
  EQUITY: {
    displayNameTH: 'หุ้นสามัญ',
    displayNameEN: 'Equity',
    defaultCurrency: 'THB',
    requiresExtension: false,
    extensionKey: 'bondExtension', // ไม่มี Extension เฉพาะ
  },
  BOND: {
    displayNameTH: 'ตราสารหนี้',
    displayNameEN: 'Bond',
    defaultCurrency: 'THB',
    requiresExtension: true,
    extensionKey: 'bondExtension',
  },
  FUND: {
    displayNameTH: 'กองทุนรวม',
    displayNameEN: 'Mutual Fund',
    defaultCurrency: 'THB',
    requiresExtension: true,
    extensionKey: 'fundExtension',
  },
  COMMODITY: {
    displayNameTH: 'สินค้าโภคภัณฑ์',
    displayNameEN: 'Commodity',
    defaultCurrency: 'USD',
    requiresExtension: true,
    extensionKey: 'commodityExtension',
  },
  FOREX: {
    displayNameTH: 'เงินตราต่างประเทศ',
    displayNameEN: 'Forex',
    defaultCurrency: 'USD',
    requiresExtension: true,
    extensionKey: 'forexExtension',
  },
  OPTION: {
    displayNameTH: 'อนุพันธ์',
    displayNameEN: 'Option',
    defaultCurrency: 'THB',
    requiresExtension: true,
    extensionKey: 'optionExtension',
  },
  REIT: {
    displayNameTH: 'กองทุนอสังหา',
    displayNameEN: 'REIT',
    defaultCurrency: 'THB',
    requiresExtension: true,
    extensionKey: 'reitExtension',
  },
  PRIVATE_EQUITY: {
    displayNameTH: 'ไพรเวท อิควิตี้',
    displayNameEN: 'Private Equity',
    defaultCurrency: 'THB',
    requiresExtension: false,
    extensionKey: 'bondExtension', // ใช้โครงสร้างพื้นฐานชั่วคราว
  },
  FUTURES: {
    displayNameTH: 'สัญญาซื้อขายล่วงหน้า',
    displayNameEN: 'Futures',
    defaultCurrency: 'THB',
    requiresExtension: false,
    extensionKey: 'bondExtension', // Legacy registry has no Futures key; the advanced extension is kept outside the base CDM.
  },
};

// ============================================================================
// 7. VALIDATION HELPERS (สำหรับตรวจสอบความถูกต้องของข้อมูล)
// ============================================================================
export function validateMultiAssetTransaction(tx: MultiAssetTransaction): {
  isValid: boolean;
  errors: string[];
} {
  const errors: string[] = [];
  
  // ตรวจสอบ Base Fields
  if (!tx.id) errors.push('Missing id');
  if (!tx.portfolioId) errors.push('Missing portfolioId');
  if (!tx.date) errors.push('Missing date');
  if (!tx.symbol) errors.push('Missing symbol');
  if (!tx.assetClass) errors.push('Missing assetClass');
  if (!tx.type) errors.push('Missing type');
  if (tx.qty <= 0) errors.push('qty must be > 0');
  
  // ตรวจสอบ Extension ตาม Asset Class
  if (tx.assetClass === 'BOND' && !tx.bondExtension) {
    errors.push('Bond requires bondExtension');
  }
  if (tx.assetClass === 'FUND' && !tx.fundExtension) {
    errors.push('Fund requires fundExtension');
  }
  if (tx.assetClass === 'COMMODITY' && !tx.commodityExtension) {
    errors.push('Commodity requires commodityExtension');
  }
  if (tx.assetClass === 'FOREX' && !tx.forexExtension) {
    errors.push('Forex requires forexExtension');
  }
  if (tx.assetClass === 'OPTION' && !tx.optionExtension) {
    errors.push('Option requires optionExtension');
  }
  
  return {
    isValid: errors.length === 0,
    errors,
  };
}
