import type { AssetClass } from './multiAsset';

/** Bloomberg security suffixes used by Terminal-exported security identifiers. */
export type BloombergAssetType =
  | 'Equity'
  | 'Corp'
  | 'Govt'
  | 'Curncy'
  | 'Comdty'
  | 'Index'
  | 'Option'
  | 'Future'
  | 'Mortgage'
  | 'Muni'
  | 'Pfd'
  | 'Warrant';

export interface BloombergTicker {
  symbol: string;
  /** Empty when the export uses a two-part ticker, e.g. `XAU Curncy`. */
  market: string;
  assetType: BloombergAssetType;
  fullTicker: string;
  isin?: string;
  cusip?: string;
  sedol?: string;
}

export interface BloombergTrade {
  tradeId: string;
  ticker: BloombergTicker;
  tradeDate: string;
  settleDate: string;
  side: 'BUY' | 'SELL';
  quantity: string;
  price: string;
  grossAmount: string;
  commission: string;
  taxes: string;
  netAmount: string;
  currency: string;
  exchange: string;
  accountNumber?: string;
  broker?: string;
}

export type BloombergCorporateActionType =
  | 'STOCK_SPLIT'
  | 'REVERSE_SPLIT'
  | 'DIVIDEND'
  | 'SPIN_OFF'
  | 'MERGER'
  | 'TENDER';

export interface BloombergCorporateAction {
  actionId: string;
  ticker: BloombergTicker;
  effectiveDate: string;
  announcementDate: string;
  actionType: BloombergCorporateActionType;
  ratio?: string;
  cashAmount?: string;
  currency?: string;
  description: string;
}

export interface BloombergPosition {
  ticker: BloombergTicker;
  quantity: string;
  marketValue: string;
  costBasis: string;
  unrealizedPL: string;
  realizedPL: string;
  currency: string;
}

export interface BloombergPortConfig {
  portfolioId: string;
  environment: 'LIVE' | 'SANDBOX';
}

export interface BloombergPortTransport {
  fetchPositions(portfolioId: string): Promise<BloombergPosition[]>;
  fetchTradeHistory(portfolioId: string, startDate: string, endDate: string): Promise<BloombergTrade[]>;
  fetchCorporateActions(effectiveDateFrom: string, effectiveDateTo: string): Promise<BloombergCorporateAction[]>;
}

export interface BloombergCDMMapping {
  assetClass: AssetClass;
  supportedByCurrentCDM: boolean;
  note?: string;
}
